# agent-library

The platform's global library: the skills, prompts, workflow definitions and plugins curated for the whole organization, released as signed OCI artifacts ([Libraries and registration](../architecture/design/repositories.md#libraries-and-registration)). Team libraries and a workload's own `.agents/` directory are the tiers below it. An artifact moves up a tier by merge request, reviewed by this tier's owners.

The design is in [Distribution](../architecture/design/distribution.md#the-distribution-design), and what build phase B6 adds in [the local build plan](../architecture/plan/local-build.md#b6-in-detail). These links, and the others in this repository's documents, are relative to the workspace, which mirrors the GitLab group.

```text
agent-library/
├── library.yaml          # owner and tier
├── skills/<name>/        # SKILL.md, the skill's files, artifact.yaml
├── prompts/<name>/       # prompt.md, artifact.yaml
├── workflows/<name>/
├── plugins/<name>/
├── .gitlab-ci.yml        # ci-components' library-release
└── AGENTS.md
```

Each directory under a kind's directory is one artifact, named after it, with its `artifact.yaml` ([Metadata per artifact](../architecture/design/distribution.md#metadata-per-artifact)).

| Artifact | Kind | What it is |
| --- | --- | --- |
| [`platform-conventions`](skills/platform-conventions/SKILL.md) | skill | The platform's conventions for an agent changing its repositories: branches, commits, merges, images and artifacts by digest, release tags and the gateway's routes, from the [project standards](../architecture/standards.md) and the design |
| [`summarise-changes`](prompts/summarise-changes/prompt.md) | prompt | Summarises a merge request's changes for its reviewers, as JSON with a summary and whether a change is breaking: the output schema of `workflow-pipeline`'s step of the same name ([A bounded model step](../architecture/design/workflows.md#a-bounded-model-step)) |

## Releases

Each artifact is released on its own tag, `<kind>/<name>/vX.Y.Z`, annotated, on a `main` merge commit whose pipeline passed ([Release tags](../architecture/design/distribution.md#release-tags)). The tag's version is the one in the artifact's `artifact.yaml`.

`devkit/ci-components`' `library-release` component runs the pipeline (its `templates/library-release/README.md`):

- **Every pipeline** renders `library.yaml` and each `artifact.yaml` and checks them against `agent-sdk`'s spec. A merge request builds nothing, and a release whose check fails stops there, before anything is built, pushed or signed.
- **A release** builds the artifact's directory as an image from scratch for `linux/amd64` and `linux/arm64`, with `artifact.yaml` among its files and its `provenance` filled by CI. It pushes the image with ORAS to `library/<kind>/<name>:v<X.Y.Z>`, as the role `ci-library-release`. It then signs the image with the release key and attests an SBOM per platform and SLSA provenance naming the tag's commit.

Consumers pin the image's digest, never the tag. `agentctl install <name>` fetches an artifact by digest from the signed catalog index, verifies its signature and provenance with the release key before writing anything, and records it in `.agents/lock.yaml` ([Installing into local harnesses](../architecture/design/distribution.md#installing-into-local-harnesses)). A skill goes to `.agents/skills/<name>`, linked into `.claude/skills/<name>` for Claude Code, and a prompt to `.agents/prompts/<name>`.

## Registration

The library is registered by its project ID in `aws-foundation`'s `registrations/<environment>.yaml`, under `ci-library-release` ([D41](../architecture/plan/open-items.md#close-by-decision)). The role trusts that project's protected tags, and the nightly catalog build reads the registered projects. Each artifact's ECR repository, `library/<kind>/<name>`, is created there too, so a new artifact's first release waits for a merge request in `aws-foundation`.
