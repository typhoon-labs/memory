# Commits

From the project standards (`standards.md`, "Commits" and "Merging"), after [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/).

```text
<type>(<scope>): <description>

<body: what changed and why>

Refs: T12, Q15
```

| Part | Rule |
| --- | --- |
| Type | `feat`, `fix`, `docs`, `refactor`, `test`, `ci`, `build`, `chore`, `perf` or `revert`. Branches prefixed `decision/` and `spike/` use these types too: they have none of their own |
| Scope | The area changed, in lowercase kebab-case, such as `docs(identity)`, `docs(decisions)`, `feat(sts)` or `ci(conformance)`. Use one whenever the repository has more than one area |
| Description | Imperative, lowercase, no trailing period. The whole first line is at most 72 characters |
| Body | Why the change was made and what it changes, wrapped at 72 characters. Leave it out only when the first line says everything |
| Footers | `Refs:` with the IDs of the decisions (Q), spikes (T), vendors (V) or open decisions (D) the change touches. `BREAKING CHANGE:`, or `!` after the type or scope, for a change that breaks a contract |

## The rest

- **One logical change per commit.** Each leaves the repository consistent: it builds, its tests pass and its links resolve. Move files and change their content in separate commits where possible, so history can follow the move.
- **No attribution lines.** No `Co-Authored-By`, "Generated with" or similar trailers, from people or tools, even when a tool adds one by default.
- **The repository's configured identity.** Never set, change or guess `user.name` or `user.email`.
- **No rewriting shared history.** No amend, rebase or force-push once a commit has left your machine, and locally only when asked.
- **Merge commits keep GitLab's default message.** Commit linting skips them.

## Checking a message

Refused:

```text
Fixed the JWKS cache.
```

It has no type, the verb is past tense and capitalised, and it ends with a period.

```text
feat(sts): add token exchange

Co-Authored-By: someone <someone@example.com>
```

It has an attribution trailer.

Accepted, with the form shown and nothing after the footers:

```text
fix(jwks): refresh the key set when a token names an unknown key

Tokens signed after a key rotation were refused until the cache
expired. The cache now fetches the key set again, at most once a
minute, when a token names a key it does not hold.
```
