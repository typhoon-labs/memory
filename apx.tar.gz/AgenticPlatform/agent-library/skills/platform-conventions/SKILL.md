---
name: platform-conventions
description: The agentic platform's conventions for changing its repositories. Covers branch names, Conventional Commits with no attribution lines, merge requests merged with a merge commit, images and artifacts pinned by digest, release tags, and which gateway and token a client uses for models, MCP servers and agents. Use it before you create a branch, write a commit message, open a merge request, reference an image or artifact, or point a client at a model, tool or agent.
---

# Platform conventions

These rules apply to people and agents alike in every repository of the agentic platform. They come from the architecture repository's project standards (`standards.md`) and its design (`design/distribution.md`, `design/conformance.md`, `design/repositories.md`, `design/charts.md`, `design/gateway.md`, `design/harnesses.md`). Follow a repository's own `AGENTS.md` too: it adds that repository's rules.

## Before you act

- Read a file before changing it, and check the result before committing.
- Propose structural or large changes first, and wait for a go-ahead.
- Ask before anything destructive or outward-facing: deleting files or branches, rewriting history, pushing, opening merge requests, or sending content to an external service.
- Report what you checked and what you did not.

## Branches

- Never commit to `main`. Start every change on a branch off the latest `main`.
- Name it `<type>/<description>`: a prefix, then a short lowercase kebab-case description, with the ID first when one exists, as in `spike/t12-kagent-outbound-identity`.
- Prefixes: `feat/`, `fix/`, `docs/`, `decision/` (a decision record), `spike/` (a time-boxed investigation), `refactor/`, `test/`, `ci/`, `chore/`.
- One concern per branch. Delete the branch once it is merged.

## Commits

[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/). The full rules and examples are in [commits.md](commits.md).

- `<type>(<scope>): <description>`: imperative, lowercase, no trailing period, the whole line at most 72 characters.
- A body saying why the change was made and what it changes, wrapped at 72.
- `Refs:` with the decision (Q), spike (T), vendor (V) or open-decision (D) IDs it touches. `BREAKING CHANGE:`, or `!` after the type or scope, when it breaks a contract.
- **No attribution lines:** no `Co-Authored-By`, "Generated with" or similar trailers, from people or tools.
- Use the repository's configured identity. Never set, change or guess `user.name` or `user.email`.
- One logical change per commit, each leaving the repository consistent: it builds, its tests pass and its links resolve.
- Never amend, rebase or force-push a commit once it has left your machine.

## Merging

- Changes reach `main` through a merge request, and only once it is approved.
- Merge with a merge commit, never a squash, so each commit survives. Rebase a branch onto `main` only while it is yours alone.

## Instructions files

`AGENTS.md` is the only instructions file. Never add a `CLAUDE.md`, `CLAUDE.local.md` or `.claude/CLAUDE.md`: any of them, in a directory or above it, stops Claude Code reading that directory's `AGENTS.md`.

## Images, artifacts and releases

The details are in [images-and-routes.md](images-and-routes.md).

- Reference every image and artifact by digest, `<registry host>/<repository>@sha256:<digest>`, never by a tag and never `latest`. For a multi-platform image, use the digest of its index.
- A release starts from an annotated, protected tag on a `main` merge commit whose pipeline passed. Its pipeline publishes, signs and attests it.

## The gateway

The details are in [images-and-routes.md](images-and-routes.md).

- Models, MCP servers and agents are reached only through the gateway, never directly.
- People and their harnesses call `gateway`. Agents and automation call `workloads-gateway`, which only pods reach.
- A person's token is refused on `workloads-gateway`, and an agent's chain token on `gateway`. An agent never forwards its caller's token.
- Ask for a model by the gateway's alias, never by a provider's model ID.
