# Images, releases and the gateway's routes

From the platform's design: distribution (`design/distribution.md`), conformance (`design/conformance.md`), the repositories' layouts (`design/repositories.md`), the charts (`design/charts.md`), the gateway (`design/gateway.md`) and the harnesses (`design/harnesses.md`); the library's repositories from the local build plan (`plan/local-build.md`, "B6 in detail").

## By digest

- **Every consumer pins a digest:** a workload's release in an environment, a lockfile, the catalog index (`design/distribution.md`, "The distribution design"; `design/repositories.md`, "Repository layouts"). An image reference is `<registry host>/<repository>@sha256:<64 hex>`. For a multi-platform image, the digest is that of its index, the one a pod names.
- **Never a tag, never `latest`.** ECR keeps tags immutable in dev, but locally floci's tags can move, so a tag proves nothing about content.
- **Charts are pinned by version and digest, images by digest:** conformance's supply-chain control pins chart and image by digest (`design/conformance.md`, "Suites"), and the architecture's Versions reference (`reference/versions.md`) records each chart's version with its digest. Each environment's `versions.yaml` takes its pins from there.
- **Releases are signed.** The release pipeline signs each image with the release key, a KMS key, and attests an SPDX SBOM per platform and SLSA provenance naming the tag's commit. Kyverno verifies images at admission.
- **Library artifacts** (skills, prompts, workflow definitions, plugins) are images too, in `library/<kind>/<name>`, tagged `v<X.Y.Z>`. `agentctl install` fetches one by digest, verifies it with the release key, and records it in `.agents/lock.yaml`.

## Release tags

A release starts from a tag: annotated, protected, on a `main` merge commit whose pipeline passed. The tag's pipeline publishes.

| Where | Tag | Example |
| --- | --- | --- |
| A workload's own repository | `vX.Y.Z` | `v1.4.0` |
| A workload added to an existing repository | `<workload>/vX.Y.Z` | `payments-mcp/v0.3.0` |
| Library artifacts | `<kind>/<name>/vX.Y.Z` | `skill/payments-refund-runbook/v1.4.0` |
| `agent-sdk` | `<part>/vX.Y.Z` | `python/v2.1.0`, `spec/v1.2.0` |
| `ci-components` | `X.Y.Z` | `1.7.0` |
| `workload-charts` | `<chart>/vX.Y.Z` | `app-base/v0.1.0` |
| `delegation-sts`, `agentctl`, templates | `vX.Y.Z` | `v0.9.2` |

## The gateway's routes

All model, tool and agent traffic goes through the gateway. Developer model traffic goes to Bedrock through it, with no direct Anthropic or OpenAI subscription (decision Q7), and workloads reach models and tools only through it.

| Gateway | Called by | Routes | Accepts |
| --- | --- | --- | --- |
| `gateway`, the developer deployment, at `gateway.<platform domain>` | People and their harnesses | `/v1`, the model route; `/mcp/<name>` and `/a2a/<name>` that people call; Agentregistry's read API | Keycloak tokens, from the clients people use: `agentctl` and the harnesses' clients |
| `workloads-gateway`, the hosted-workloads deployment, at `workloads-gateway.<platform domain>` from pods only | Agents and automation | `/v1`; `/mcp/<name>` and `/a2a/<name>` that agents call; kagent's API; Agentregistry's write API | Chain tokens from the delegation STS; Substrate actor tokens on kagent agents' routes alone; a Keycloak client-credentials token only on a route whose access file names that client |

- **A token works on one deployment only.** A chain token is refused on `gateway` and a person's token on `workloads-gateway`, so an agent that forwards its caller's token is refused.
- **One audience:** the token carries the URL of the route it calls as its only audience, is typed `at+jwt`, and is signed RS256 or ES256. Substrate's actor tokens, on their own listener, are the one exception.
- **Model aliases.** Ask for a model by the gateway's alias, never by a provider's model ID.
- **Claude Code** is configured by `agentctl harness setup`, in managed settings: `ANTHROPIC_BASE_URL` on the gateway, `allowedProviders: ["customEndpoint"]`, an `apiKeyHelper` that runs `agentctl token`, and the aliases in `ANTHROPIC_MODEL` and `ANTHROPIC_DEFAULT_*_MODEL`. Never route around them with another base URL or key.
- **In `artifact.yaml` and `workload.yaml`,** a route is written `<gateway>/<route>`: `gateway/v1`, `workloads-gateway/mcp/<name>`, `gateway/a2a/<name>`.
- **A workload's own routes** are `/mcp/<workload>` and `/a2a/<workload>`, rendered by the `agent-integration` chart (`design/charts.md`), or for a kagent agent by the platform from its access file. Admission (`design/gateway.md`, "Bypass prevention": `route-claims` and `backend-targets`) refuses a workload's route that sets a hostname, claims another path, matches on a header, query parameter or method, or rewrites or redirects. It also refuses a backend outside the workload's namespace, at a static host, or for an AI provider.
