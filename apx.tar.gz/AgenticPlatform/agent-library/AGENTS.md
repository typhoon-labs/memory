# Agent instructions: agent-library

This repository holds the platform's global library: skills, prompts, workflow definitions and plugins, each released as a signed OCI artifact. Follow the [project standards](../architecture/standards.md) for branches, commits, merges and when to ask before acting. The design is in [Libraries and registration](../architecture/design/repositories.md#libraries-and-registration) and [Distribution](../architecture/design/distribution.md#metadata-per-artifact). How releases run is in the [README](README.md). The rules below are specific to this repository.

## Rules for this repository

- **One directory per artifact,** `<kind>s/<name>/`, named after the artifact, with its `artifact.yaml`. Names are lowercase kebab-case, at most 63 characters, and unique across every kind and tier. The global library has no prefix.
- **Never commit `provenance`** in an `artifact.yaml`: CI fills it in the released copy.
- **A new artifact starts `support: experimental`,** owned by a team in `infra/environments`' `access/teams.yaml`. `supported` needs its `evaluation`, and `deprecated` its `deprecation`. `compatibility` lists only the harnesses and model aliases it was tested with.
- **A changed artifact is a new version.** Raise `version` in its `artifact.yaml` in the same merge request. Its release tag, `<kind>/<name>/vX.Y.Z`, goes on the merge commit once `main`'s pipeline has passed. Tags are annotated, never moved or reused, and made only when asked.
- **A new artifact needs its ECR repository first,** `library/<kind>/<name>`, created by a merge request in `infra/aws-foundation`. Until then its release fails at the push.
- **Artifacts are files only.** A link or special file stops the build. An artifact ships alone, so its files link only to each other, never outside its directory, and name a source document instead of linking to it.
- **Skills follow the Agent Skills format.** A skill is `SKILL.md`, whose frontmatter has `name`, equal to the directory's name, and `description`, which says what the skill does and when to use it, at most 1024 characters. The frontmatter uses only the portable fields: `name`, `description`, `license`, `compatibility`, `metadata` and `allowed-tools`. Keep `SKILL.md` short, under 500 lines, and put detail in files beside it that it names.
- **A skill restates the platform's rules for agents that cannot read the architecture repository.** It draws only from the standards and the design, names the documents it draws from, and gets a new version when they change.
- **`ci-components` is included by a commit on its `main`** until its 1.1.0 release, then by `@1`.

## Before committing

- `agentctl validate` passes on each changed `artifact.yaml`. The merge request's `library-release:check` job then runs the whole check, against the spec `ci-components` vendors: `library.yaml`, each artifact's directory and name, and a skill's `SKILL.md`. It must pass before the merge.
- `python3 ../architecture/tools/check_docs.py .` reports no problems.
