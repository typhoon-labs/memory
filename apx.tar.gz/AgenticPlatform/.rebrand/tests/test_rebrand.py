"""Tests for rebrand.py.

Run: uv run --no-project --with git-filter-repo==2.47.0 python -m unittest discover -s tests
from the directory holding rebrand.py.
"""
import contextlib
import importlib.util
import io
import os
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("rebrand", HERE / "rebrand.py")
rb = importlib.util.module_from_spec(spec)
sys.modules["rebrand"] = rb
spec.loader.exec_module(rb)

SANDBOX = "typhoon_labs/agentic-platform-sandbox"


def config(tmp: Path, body: str) -> rb.Config:
    p = tmp / "rebrand.toml"
    p.write_text(textwrap.dedent(body))
    return rb.load_config(p)


BASE = """
root = "ws"
watch = ["typhoon", "halcyon"]
[[namespace]]
host = "gitlab.com"
from = "typhoon_labs"
to = "<company>"
paths = ["docs/*"]
[[namespace]]
host = "gitlab.com"
from = "typhoon_labs/agentic-platform-sandbox"
to = "acme/platform/agentic"
[[namespace]]
host = "gitlab.com"
from = "typhoon_labs"
to = "acme"
[[namespace]]
host = "github.com"
from = "typhoon-labs"
to = "acme-gh"
bare = false
[[handle]]
from = "typhoon-labs"
to = "platform-team"
[[identity]]
emails = ["typhoon@localhost"]
names = ["Typhoon"]
name = "Dev One"
email = "dev1@example.com"
[[identity]]
emails = ["halcyon.blue@outlook.com"]
names = ["Typhoon Labs"]
name = "Platform Bot"
email = "bot@example.com"
[[literal]]
from = "gitName: Typhoon"
to = "gitName: Dev One"
paths = ["sbxenv.yaml"]
"""


class EngineTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.cfg = config(self.tmp, BASE)
        self.rules = rb.Rules(self.cfg)

    def rw(self, text, rel="code/x.txt", mr="keep"):
        new, events, _ = rb.process_text(self.rules, rel, text, mr)
        return new, events

    def test_path_forms(self):
        cases = {
            f"module gitlab.com/{SANDBOX}/devkit/agentctl":
                "module gitlab.com/acme/platform/agentic/devkit/agentctl",
            f"git@gitlab.com:{SANDBOX}/infra/environments.git":
                "git@gitlab.com:acme/platform/agentic/infra/environments.git",
            f"- component: $CI_SERVER_FQDN/{SANDBOX}/devkit/ci-components/workload@1":
                "- component: $CI_SERVER_FQDN/acme/platform/agentic/devkit/ci-components/workload@1",
            "url = \"https://gitlab.com/api/v4/projects/typhoon_labs%2Fagentic-platform-sandbox%2Fdevkit%2Fagent-sdk/x\"":
                "url = \"https://gitlab.com/api/v4/projects/acme%2Fplatform%2Fagentic%2Fdevkit%2Fagent-sdk/x\"",
            "projects/typhoon_labs%2fagentic-platform-sandbox%2fx":
                "projects/acme%2fplatform%2fagentic%2fx",
            f"gitlab_root: {SANDBOX}": "gitlab_root: acme/platform/agentic",
            "glab api namespaces/typhoon_labs": "glab api namespaces/acme",
            "the `typhoon_labs` group.": "the `acme` group.",
            f"CODEOWNERS: @{SANDBOX}/team": "CODEOWNERS: @acme/platform/agentic/team",
        }
        for old, want in cases.items():
            with self.subTest(old=old):
                self.assertEqual(self.rw(old)[0], want)

    def test_segment_boundaries(self):
        # a longer segment is another subgroup: only the root group's rule applies
        for text in (f"{SANDBOX}2/x", f"{SANDBOX}.bak/x"):
            with self.subTest(text=text):
                self.assertEqual(self.rw(text)[0], "acme/" + text.removeprefix("typhoon_labs/"))
        # not the group at all: leave it, and report it
        for text in ("typhoon_labsx/y", "xtyphoon_labs/y"):
            with self.subTest(text=text):
                new, events = self.rw(text)
                self.assertEqual(new, text)
                self.assertTrue(any(e.kind == "unresolved" for e in events))

    def test_hosts(self):
        self.assertEqual(self.rw("git@github.com:typhoon-labs/memory.git")[0],
                         "git@github.com:acme-gh/memory.git")
        # a GitLab group path on another host is not the GitLab group
        new, events = self.rw("https://github.com/typhoon_labs/x")
        self.assertEqual(new, "https://github.com/typhoon_labs/x")
        self.assertTrue(any(e.kind == "unresolved" for e in events))

    def test_handle_vs_email_and_github(self):
        self.assertEqual(self.rw("* @typhoon-labs")[0], "* @platform-team")
        self.assertEqual(self.rw("/x/ @typhoon-labs @other")[0], "/x/ @platform-team @other")
        new, events = self.rw("mail me@typhoon-labs.com")
        self.assertEqual(new, "mail me@typhoon-labs.com")
        self.assertTrue(any(e.kind == "unresolved" for e in events))

    def test_scoped_rule_wins(self):
        text = f"`typhoon_labs` and `{SANDBOX}`, `namespaces/typhoon_labs%2Fagentic-platform-sandbox`"
        self.assertEqual(self.rw(text, rel="docs/research/n.md")[0],
                         "`<company>` and `<company>/agentic-platform-sandbox`, "
                         "`namespaces/<company>%2Fagentic-platform-sandbox`")
        self.assertEqual(self.rw(text)[0],
                         "`acme` and `acme/platform/agentic`, `namespaces/acme%2Fplatform%2Fagentic`")

    def test_identities(self):
        self.assertEqual(self.rw("Co-authored-by: Typhoon Labs <halcyon.blue@outlook.com>")[0],
                         "Co-authored-by: Platform Bot <bot@example.com>")
        self.assertEqual(self.rw("gitEmail: typhoon@localhost")[0], "gitEmail: dev1@example.com")
        new, _ = self.rw("gitName: Typhoon\ngitEmail: typhoon@localhost\n", rel="sbxenv.yaml")
        self.assertEqual(new, "gitName: Dev One\ngitEmail: dev1@example.com\n")
        new, events = self.rw("gitName: Typhoon\n", rel="other.yaml")  # literal is scoped
        self.assertEqual(new, "gitName: Typhoon\n")
        self.assertTrue(any(e.kind == "unresolved" for e in events))

    def test_merge_request_refs(self):
        msg = f"Merge branch 'x' into 'main'\n\nSee merge request {SANDBOX}/devkit/ci-components!12\n"
        kept, events = self.rw(msg, mr="keep")
        self.assertEqual(kept, msg)
        self.assertEqual([e.kind for e in events], ["mr-ref"])
        self.assertIn("acme/platform/agentic/devkit/ci-components!12", self.rw(msg, mr="rewrite")[0])
        stripped, n = self.rules.strip_mr("code/", msg)
        self.assertEqual((stripped, n), ("Merge branch 'x' into 'main'\n", 1))

    def test_unset_target_blocks(self):
        cfg = config(self.tmp, BASE.replace('to = "acme/platform/agentic"', 'to = ""'))
        new, events, _ = rb.process_text(rb.Rules(cfg), "code/x", f"root: {SANDBOX}", "keep")
        self.assertEqual(new, f"root: {SANDBOX}")
        self.assertEqual([e.kind for e in events], ["unset"])
        with self.assertRaises(rb.Fail):
            rb.check_unset(cfg, events)

    def test_go_sum_drops_changed_lines(self):
        text = (f"gitlab.com/{SANDBOX}/x v1.0.0 h1:abc=\n"
                "golang.org/x/text v0.14.0 h1:def=\n")
        new, _, notes = rb.process_text(self.rules, "code/go.sum", text, "keep")
        self.assertEqual(new, "golang.org/x/text v0.14.0 h1:def=\n")
        self.assertTrue(notes)

    def test_literal_regex_and_keep(self):
        cfg = config(self.tmp, BASE + textwrap.dedent("""
            [[literal]]
            from = '(?i)typhoon-(\\w+)-svc'
            to = 'acme-\\1-svc'
            regex = true
            [keep]
            patterns = ['typhoon-legacy\\b']
            """))
        new, events, _ = rb.process_text(rb.Rules(cfg), "x", "TYPHOON-api-svc typhoon-legacy", "keep")
        self.assertEqual(new, "acme-api-svc typhoon-legacy")
        self.assertEqual(sorted(e.kind for e in events), ["keep", "literal"])

    def test_idempotent(self):
        text = f"gitlab.com/{SANDBOX}/x @typhoon-labs typhoon@localhost"
        once = self.rw(text)[0]
        self.assertEqual(self.rw(once)[0], once)


class ShaTest(unittest.TestCase):
    def setUp(self):
        self.idx = rb.ShaIndex({
            "3ae61a862dc506293b490ea27702f4f6374ad8cf": ("1111111111111111111111111111111111111111", "a"),
            "becb745f28a0aaaaaaaaaaaaaaaaaaaaaaaaaaaa": ("2222222222222222222222222222222222222222", "a"),
            "becb745f28a0bbbbbbbbbbbbbbbbbbbbbbbbbbbb": ("3333333333333333333333333333333333333333", "b"),
            "1234567aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa": ("4444444444444444444444444444444444444444", "b"),
        })
        self.art = rb.re.compile("(?:sha-)$")

    def test_remap(self):
        ev = []
        out = self.idx.remap("workload@3ae61a862dc506293b490ea27702f4f6374ad8cf, at `3ae61a8`", self.art, ev)
        self.assertEqual(out, "workload@1111111111111111111111111111111111111111, at `1111111`")
        self.assertEqual([e.kind for e in ev], ["sha", "sha"])

    def test_artifact_ambiguous_digits(self):
        text = "image `sha-3ae61a862dc5`; `becb745f28a0` is ambiguous; 1234567 is a number"
        ev = []
        self.assertEqual(self.idx.remap(text, self.art, ev), text)
        self.assertEqual([e.kind for e in ev], ["artifact"])

    def test_not_inside_longer_hex(self):
        text = "trace 3ae61a862dc506293b490ea27702f4f6374ad8cf00 and sha256:abcdef3ae61a86"
        self.assertEqual(self.idx.remap(text, self.art), text)


TESTER = {"GIT_AUTHOR_NAME": "Tester", "GIT_AUTHOR_EMAIL": "tester@example.com",
          "GIT_COMMITTER_NAME": "Tester", "GIT_COMMITTER_EMAIL": "tester@example.com"}


def sh(cwd, *args, env=None):
    return subprocess.run(args, cwd=cwd, check=True, capture_output=True, text=True,
                          env={**os.environ, **(env or {})}).stdout


def commit(repo, msg, name, email, files):
    for path, text in files.items():
        p = Path(repo) / path
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    sh(repo, "git", "add", "-A")
    ident = {"GIT_AUTHOR_NAME": name, "GIT_AUTHOR_EMAIL": email,
             "GIT_COMMITTER_NAME": name, "GIT_COMMITTER_EMAIL": email}
    sh(repo, "git", "commit", "-q", "-m", msg, env=ident)
    return sh(repo, "git", "rev-parse", "HEAD").strip()


def run(*args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = rb.main(list(args))
    return code, out.getvalue() + err.getvalue()


class EndToEndTest(unittest.TestCase):
    """Two repositories, one pinning the other's commit, through history, apply, restore."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        (self.tmp / "rebrand.toml").write_text(textwrap.dedent(BASE))
        self.cfgpath = str(self.tmp / "rebrand.toml")
        ws = self.tmp / "ws"
        self.comp, self.user = ws / "group" / "comp", ws / "group" / "user"
        for r in (self.comp, self.user):
            r.mkdir(parents=True)
            sh(r, "git", "init", "-q", "-b", "main")
        mod = f"module gitlab.com/{SANDBOX}/group/comp\n"
        commit(self.comp, "feat: start", "Typhoon", "typhoon@localhost", {"go.mod": mod})
        sh(self.comp, "git", "checkout", "-q", "-b", "feat/x")
        commit(self.comp, "feat: x", "Typhoon", "typhoon@localhost", {"x.go": "package x\n"})
        sh(self.comp, "git", "checkout", "-q", "main")
        sh(self.comp, "git", "merge", "-q", "--no-ff", "feat/x", "-m",
           f"Merge branch 'feat/x' into 'main'\n\nSee merge request {SANDBOX}/group/comp!1",
           env={"GIT_COMMITTER_NAME": "Typhoon Labs", "GIT_COMMITTER_EMAIL": "halcyon.blue@outlook.com",
                "GIT_AUTHOR_NAME": "Typhoon Labs", "GIT_AUTHOR_EMAIL": "halcyon.blue@outlook.com"})
        self.comp_head = sh(self.comp, "git", "rev-parse", "HEAD").strip()
        sh(self.comp, "git", "tag", "-a", "1.0.0", "-m", "release",
           env={"GIT_COMMITTER_NAME": "Typhoon Labs", "GIT_COMMITTER_EMAIL": "halcyon.blue@outlook.com"})
        sh(self.comp, "git", "remote", "add", "origin", f"git@gitlab.com:{SANDBOX}/group/comp.git")
        sh(self.comp, "git", "update-ref", "refs/remotes/origin/main", self.comp_head)
        sh(self.comp, "git", "update-ref", "refs/remotes/origin/fix/remote-only", self.comp_head + "~1")
        sh(self.comp, "git", "symbolic-ref", "refs/remotes/origin/HEAD", "refs/remotes/origin/main")
        sh(self.comp, "git", "config", "branch.main.remote", "origin")
        sh(self.comp, "git", "config", "branch.main.merge", "refs/heads/main")
        self.ci = (f"include:\n  - component: $CI_SERVER_FQDN/{SANDBOX}/group/comp/w@{self.comp_head}\n"
                   f"# image built from comp: sha-{self.comp_head[:12]}\n")
        commit(self.user, "ci: pin comp", "Typhoon", "typhoon@localhost", {
            ".gitlab-ci.yml": self.ci,
            "CODEOWNERS": "* @typhoon-labs\n",
            "pyproject.toml": 'url = "https://gitlab.com/api/v4/projects/'
                              'typhoon_labs%2Fagentic-platform-sandbox%2Fgroup%2Fsdk/pypi/simple"\n',
        })
        (ws / "sbxenv.yaml").write_text("gitName: Typhoon\ngitEmail: typhoon@localhost\n")
        self.before = {r: sh(r, "git", "for-each-ref", "--format=%(refname) %(objectname)")
                       for r in (self.comp, self.user)}

    def test_full_cycle(self):
        code, out = run("--config", self.cfgpath, "scan")
        self.assertEqual(code, 0, out)
        self.assertIn("Unresolved: no rule accounts for these; add a rule, or a [keep] pattern\n  none", out)

        code, out = run("--config", self.cfgpath, "history")
        self.assertEqual(code, 1, out)  # without --yes nothing happens
        self.assertEqual(self.before[self.comp],
                         sh(self.comp, "git", "for-each-ref", "--format=%(refname) %(objectname)"))

        code, out = run("--config", self.cfgpath, "history", "--yes")
        self.assertEqual(code, 0, out)
        self.assertNotIn("PROBLEMS", out)
        idents = sh(self.comp, "git", "log", "--all", "--format=%an <%ae>|%cn <%ce>")
        self.assertNotIn("typhoon", idents.lower())
        self.assertNotIn("halcyon", idents.lower())
        self.assertIn("Platform Bot <bot@example.com>", idents)
        self.assertEqual(sh(self.comp, "git", "for-each-ref", "refs/tags", "--format=%(taggeremail)").strip(),
                         "<bot@example.com>")
        # merge request reference kept, by the default policy
        self.assertIn(f"See merge request {SANDBOX}/group/comp!1",
                      sh(self.comp, "git", "log", "-1", "--format=%B", "main"))
        # remote and upstream restored as they were; remote-only branch kept locally
        self.assertEqual(sh(self.comp, "git", "remote", "get-url", "origin").strip(),
                         f"git@gitlab.com:{SANDBOX}/group/comp.git")
        self.assertEqual(sh(self.comp, "git", "config", "branch.main.merge").strip(), "refs/heads/main")
        self.assertIn("refs/heads/fix/remote-only", sh(self.comp, "git", "for-each-ref"))
        # the pin follows the rewritten commit; the image tag does not
        new_head = sh(self.comp, "git", "rev-parse", "main").strip()
        self.assertNotEqual(new_head, self.comp_head)
        ci = (self.user / ".gitlab-ci.yml").read_text()
        self.assertIn(f"/w@{new_head}\n", ci)
        self.assertIn(f"sha-{self.comp_head[:12]}", ci)

        sh(self.user, "git", "commit", "-qam", "chore: remap pins", env=TESTER)
        code, out = run("--config", self.cfgpath, "apply", "--workspace")
        self.assertEqual(code, 0, out)
        self.assertEqual((self.comp / "go.mod").read_text(),
                         "module gitlab.com/acme/platform/agentic/group/comp\n")
        self.assertEqual((self.user / "CODEOWNERS").read_text(), "* @platform-team\n")
        self.assertIn("acme%2Fplatform%2Fagentic%2Fgroup%2Fsdk", (self.user / "pyproject.toml").read_text())
        self.assertEqual(sh(self.comp, "git", "remote", "get-url", "origin").strip(),
                         "git@gitlab.com:acme/platform/agentic/group/comp.git")
        self.assertEqual((self.tmp / "ws" / "sbxenv.yaml").read_text(),
                         "gitName: Dev One\ngitEmail: dev1@example.com\n")

        # restore puts refs, config and files back
        sh(self.comp, "git", "commit", "-qam", "chore: move", env=TESTER)
        runs = sorted((self.tmp / "state" / "runs").iterdir())
        code, out = run("--config", self.cfgpath, "restore", str(runs[-1]), "--yes")
        self.assertEqual(code, 0, out)
        for r in (self.comp, self.user):
            self.assertEqual(self.before[r], sh(r, "git", "for-each-ref", "--format=%(refname) %(objectname)"))
        self.assertEqual(sh(self.comp, "git", "remote", "get-url", "origin").strip(),
                         f"git@gitlab.com:{SANDBOX}/group/comp.git")
        self.assertEqual(sh(self.comp, "git", "symbolic-ref", "refs/remotes/origin/HEAD").strip(),
                         "refs/remotes/origin/main")
        self.assertEqual((self.user / ".gitlab-ci.yml").read_text(), self.ci)

    def test_refuses_dirty_tree(self):
        (self.user / "CODEOWNERS").write_text("changed\n")
        code, out = run("--config", self.cfgpath, "history", "--yes")
        self.assertEqual(code, 2)
        self.assertIn("uncommitted changes", out)
        self.assertFalse((self.tmp / "state").exists())


if __name__ == "__main__":
    unittest.main()
