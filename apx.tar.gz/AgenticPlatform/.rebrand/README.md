# rebrand

Moves the workspace's repositories off the `typhoon` names: the GitLab group path, the CODEOWNERS account, the git identities in history, and the sandbox's own identity. Every rule is in `rebrand.toml`; every match no rule accounts for is reported, never guessed at.

Sandbox tooling, like `mise.toml`: not versioned. Needs `uv` and git 2.36 or later; `uv` fetches `git-filter-repo` 2.47.0, pinned by hash in `rebrand.py.lock`.

## Commands

Run from this directory.

| Command | Does | Changes |
| --- | --- | --- |
| `uv run rebrand.py scan` | Every planned change by rule, notes on files that need a follow-up, what `history` would touch, the commit SHAs cited across repositories, and everything unresolved. `--diff` prints unified diffs, `--verbose` every change with its line | Nothing |
| `uv run rebrand.py apply` | Rewrites tracked files and remote URLs. `--workspace` also edits files outside the repositories (`sbxenv.yaml`); `--no-remotes` leaves the URLs | Working trees, `.git/config`; no commits |
| `uv run rebrand.py history --yes` | Rewrites authors, committers and taggers, and commit and tag messages, in every ref, then remaps cited commit SHAs in the working trees | Every commit SHA; bundles first |
| `uv run rebrand.py restore <run> --yes` | Puts a `history` run's repositories back: refs, `.git/config`, working tree | Discards uncommitted changes |

`--repo <glob>` limits a command to some repositories, such as `--repo 'devkit/*'`.

## What makes it context-aware

- **Paths are matched as paths.** A rule maps a GitLab path prefix on whole segments, so `typhoon_labs/agentic-platform-sandbox2` is not the sandbox group. It recognises the path bare (`gitlab_root:`), in https and SSH URLs, in Go module and import paths, in `$CI_SERVER_FQDN/…@1` component references and `@group` mentions, and `%2F`-encoded in API and package-registry URLs. The longest prefix wins, so the change of depth from `typhoon_labs/agentic-platform-sandbox` to, say, `acme/agentic-platform` is one rule.
- **Rules can be scoped to paths.** The architecture repository writes the company as `<company>` and keeps the sandbox's name in research notes that record checks against it; its rule says so, and the other repositories get the real group.
- **Kinds of name stay apart.** `@typhoon-labs` (an account, in CODEOWNERS) is not `typhoon_labs` (the group); an email is not a path; a path on github.com is not a GitLab path.
- **Merge request references are a policy.** GitLab's merge commits end `See merge request <path>!N`. Repositories pushed to a new group leave their merge requests behind, so a rewritten reference would link to a different merge request. `merge_request_refs` keeps, rewrites or strips them.
- **File types get what they need.** `go.sum` lines whose module path changes are dropped, since their hashes cover the path. Lockfiles, `.copier-answers.yml`, `go.mod` and `CODEOWNERS` get a note on the follow-up they need. Binary and oversized files are reported, not edited; symlinks are rewritten as links.
- **Commit SHAs follow the rewrite.** A history rewrite gives every commit a new SHA, and 337 references in these repositories cite their commits: pins in `copier.yml` and CI includes, deploy-file comments, research notes. `history` remaps each one that is a unique prefix of a rewritten commit, across repositories. It leaves the `sha-…` image tags, whose images were built and pushed under the old SHAs.
- **Unset targets block.** A rule with an empty `to` shows its matches in `scan`; `apply` and `history` refuse while it matches anything.

## Order for the swap

1. Fill in the empty targets in `rebrand.toml`. Run `scan`, and read what is unresolved and what the notes say.
2. Decide whether to rewrite history at all (below). If so, commit or stash everything, run `history --yes`, review, and commit the SHA remaps in each repository. The run's directory under `state/runs/` holds a bundle of each repository's old refs and its commit map.
3. Run `apply --workspace`, review with `git diff`, and commit each repository on a branch: the plan's "root path changes in one commit per repository".
4. Follow up by hand. Regenerate `uv.lock` once the SDK is served from the new path, and run `go build ./...` and `go vet ./...` in each Go module. Put the new projects' IDs, not the sandbox's, in AWS trust policies. Publish the CI components from the new group before anything includes them.

Nothing is pushed. After `history`, the remote-tracking branches are gone (filter-repo turns them into local branches) and the old SHAs no longer exist locally. Pushing to the sandbox needs `--force` and orphans its merge requests and pipelines; pushing to fresh projects in the new group does not.

## Rewriting history, or not

Rewriting is the only way to remove the old names and the personal email from the commits themselves. Its costs: every SHA changes, signatures (there are none here) would be lost, and anyone holding a clone must re-clone. A `.mailmap` would change how `git log` and `git blame` show the identities without any of that, but it keeps the old email in the repository. That is why `history` rewrites instead.

## Checked

- `tests/`: 16 tests, unit cases for every rule form and a full history, apply and restore cycle on throwaway repositories. Run with `uv run --no-project --with git-filter-repo==2.47.0 python -I -m unittest discover -s tests`.
- 2026-11-19, on copies of all 12 repositories with sample targets. `history` rewrote 1,167 commits, each with an identical tree and none left with an old identity. It remapped 337 SHA references, every one resolving to the same tree, and left 43 `sha-` tags. `apply` made 340 changes, leaving no `typhoon` or `halcyon` in tracked files. All four Go modules build and vet, and every changed YAML, JSON and TOML file parses. `restore` brought all 12 back exactly.

`state/` holds full copies of the old history, personal email included: delete a run's directory once its repositories are pushed and checked.
