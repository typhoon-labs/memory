#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# dependencies = ["git-filter-repo==2.47.0"]
# ///
"""rebrand: context-aware renaming across a workspace of git repositories.

  scan     report every planned change and every unresolved match; changes nothing
  apply    rewrite tracked files and remote URLs in the working trees
  history  rewrite authors, committers, taggers and messages in all history
  restore  put repositories back from a history run's bundles

The rules live in rebrand.toml beside this file; README.md explains them.
"""
from __future__ import annotations

import argparse
import bisect
import datetime
import difflib
import fnmatch
import json
import os
import re
import shutil
import subprocess
import sys
import tomllib
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

HERE = Path(__file__).resolve().parent
SEG = r"A-Za-z0-9_.\-"  # characters of a GitLab or GitHub path segment
START = rf"(?<![{SEG}])"
# A path ends where no segment character follows, allowing a `.git` suffix
# and a sentence's full stop.
END = rf"(?=\.git(?![{SEG}])|(?![A-Za-z0-9_\-])(?!\.[A-Za-z0-9_\-]))"
EMAIL_CHARS = r"A-Za-z0-9._%+\-"
HEX = re.compile(r"(?<![0-9A-Za-z])[0-9a-f]{7,40}(?![0-9A-Za-z])")
LOCKFILES = {"uv.lock", "poetry.lock", "Pipfile.lock", "package-lock.json",
             "pnpm-lock.yaml", "yarn.lock", "Cargo.lock", "Gemfile.lock",
             "composer.lock"}
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__"}
KNOWN_HOSTS = {"github.com", "gitlab.com", "bitbucket.org"}
MAX_BYTES = 20 * 1024 * 1024
ENC = {"encoding": "utf-8", "errors": "surrogateescape"}


class Fail(Exception):
    pass


def git(repo: Path, *args: str, check: bool = True) -> str:
    r = subprocess.run(["git", "-C", str(repo), *args], capture_output=True, **ENC)
    if check and r.returncode:
        raise Fail(f"git {' '.join(args)} in {repo}: {r.stderr.strip()}")
    return r.stdout


# ── Rules ────────────────────────────────────────────────────────────────


@dataclass
class Alt:
    """One alternative of an engine's combined pattern."""
    pattern: str
    order: tuple
    kind: str
    label: str
    fn: Callable[[re.Match], str | None] | None  # None: leave the match as is


def _scope(paths) -> int:
    return 0 if paths else 1  # rules limited to paths are tried first


def _flags_scoped(pat: str) -> str:
    """Turn a leading `(?i)` into `(?i:…)` so the pattern can be embedded."""
    m = re.match(r"\(\?([aiLmsux]+)\)", pat)
    return f"(?{m.group(1)}:{pat[m.end():]})" if m else pat


@dataclass
class Namespace:
    host: str
    frm: str
    to: str
    bare: bool = True
    paths: tuple = ()
    kind: str = "namespace"

    def alts(self, hosts):
        label = f"{self.frm} → {self.to or '(unset)'}"
        f = re.escape(self.frm)
        to = self.to or None
        base = (5, _scope(self.paths), -len(self.frm))
        out = [Alt(rf"(?<={re.escape(self.host + sep)}){f}{END}", base + (0,),
                   self.kind, label, lambda m: to) for sep in "/:"]
        if "/" in self.frm:
            def encoded(m, to=to):
                if to is None:
                    return None
                return to.replace("/", "%2f" if "%2f" in m.group() else "%2F")
            out.append(Alt(START + f.replace("/", "%2[Ff]") + END, base + (1,),
                           self.kind, label, encoded))
        if self.bare:
            other = "".join(rf"(?<!{re.escape(h)}/)(?<!{re.escape(h)}:)"
                            for h in sorted(hosts) if h != self.host)
            out.append(Alt(START + other + f + END, base + (2,), self.kind, label,
                           lambda m: to))
        return out

    def mr_alt(self):
        """A merge request or issue reference: `<path>!12`, `<path>#12`."""
        return Alt(START + re.escape(self.frm) + rf"(?:/[{SEG}]+)*[!#][0-9]+(?![0-9])",
                   (1, _scope(self.paths), -len(self.frm)), "mr-ref",
                   f"{self.frm}…!N", None)


@dataclass
class Handle:
    frm: str
    to: str
    paths: tuple = ()
    kind: str = "handle"

    def alts(self, hosts):
        to = self.to or None
        return [Alt(rf"(?<![{SEG}@])@{re.escape(self.frm)}(?![A-Za-z0-9_\-])(?!\.[A-Za-z0-9_\-])",
                    (6, _scope(self.paths), -len(self.frm)), self.kind,
                    f"@{self.frm} → @{self.to or '(unset)'}",
                    lambda m: None if to is None else "@" + to)]


@dataclass
class Identity:
    emails: tuple
    names: tuple
    name: str
    email: str
    paths: tuple = ()
    kind: str = "identity"

    @property
    def label(self):
        return f"{', '.join(self.emails)} → {self.name or '(unset)'} <{self.email or '(unset)'}>"

    def alts(self, hosts):
        emails = "|".join(re.escape(e) for e in sorted(self.emails, key=len, reverse=True))
        out = []
        if self.names:
            names = "|".join(re.escape(n) for n in sorted(self.names, key=len, reverse=True))
            pair = None if not (self.name and self.email) else f"{self.name} <{self.email}>"
            out.append(Alt(rf"(?<![A-Za-z0-9_\-])(?:{names}) <(?i:{emails})>",
                           (3, _scope(self.paths), 0), self.kind, self.label,
                           lambda m: pair))
        email = self.email or None
        out.append(Alt(rf"(?<![{EMAIL_CHARS}])(?i:{emails})(?![A-Za-z0-9_\-])(?!\.[A-Za-z0-9])",
                       (4, _scope(self.paths), 0), self.kind, self.label,
                       lambda m: email))
        return out

    def mailmap(self) -> str:
        return "".join(f"{self.name} <{self.email}> <{e}>\n" for e in self.emails)


@dataclass
class Literal:
    frm: str
    to: str
    regex: bool = False
    paths: tuple = ()
    kind: str = "literal"

    def alts(self, hosts):
        if self.regex:
            pat = _flags_scoped(self.frm)
            rx = re.compile(self.frm)
        else:
            pat = re.escape(self.frm)
            if re.match(r"\w", self.frm):
                pat = r"(?<!\w)" + pat
            if re.search(r"\w$", self.frm):
                pat += r"(?!\w)"
            rx = None
        to = self.to or None

        def rep(m):
            if to is None:
                return None
            if rx is None:
                return to
            m2 = rx.match(m.string, m.start())
            return m2.expand(to) if m2 and m2.end() == m.end() else m.group()
        return [Alt(pat, (2, _scope(self.paths), -len(self.frm)), self.kind,
                    f"{self.frm} → {self.to or '(unset)'}", rep)]


@dataclass
class Keep:
    pattern: str
    paths: tuple = ()
    kind: str = "keep"

    def alts(self, hosts):
        return [Alt(f"(?:{_flags_scoped(self.pattern)})", (0, _scope(self.paths), 0),
                    self.kind, self.pattern, None)]


def applies(rule, rel: str) -> bool:
    return not rule.paths or any(fnmatch.fnmatchcase(rel, p) for p in rule.paths)


@dataclass
class Event:
    kind: str  # a rule kind, or keep, mr-ref, unset, unresolved, sha, artifact
    label: str
    old: str
    new: str | None
    pos: int


class Engine:
    def __init__(self, alts: list[Alt]):
        self.alts = sorted(alts, key=lambda a: a.order)
        self.rx = re.compile("|".join(f"(?P<a{i}>{a.pattern})" for i, a in enumerate(self.alts))) \
            if self.alts else None

    def rewrite(self, text: str, preview: bool = False) -> tuple[str, list[Event]]:
        events: list[Event] = []
        if not self.rx:
            return text, events

        def sub(m):
            a = self.alts[int(m.lastgroup[1:])]
            old = m.group()
            if a.fn is None:
                events.append(Event(a.kind, a.label, old, None, m.start()))
                return old
            new = a.fn(m)
            if new is None:
                events.append(Event("unset", a.label, old, None, m.start()))
                return f"⟨unset:{old}⟩" if preview else old
            if new != old:
                events.append(Event(a.kind, a.label, old, new, m.start()))
            return new
        return self.rx.sub(sub, text), events


@dataclass
class Config:
    path: Path
    root: Path
    state: Path
    watch: list[str]
    namespaces: list[Namespace]
    handles: list[Handle]
    identities: list[Identity]
    literals: list[Literal]
    keeps: list[Keep]
    keep_paths: list[str]
    exclude_repos: list[str]
    h_identities: bool
    h_messages: bool
    h_contents: bool
    mr_policy: str
    artifact_prefixes: list[str]
    artifact_rx: re.Pattern | None


def _check_keys(table: dict, allowed: set, where: str):
    extra = set(table) - allowed
    if extra:
        raise Fail(f"{where}: unknown key(s) {', '.join(sorted(extra))}")


def load_config(path: Path) -> Config:
    raw = tomllib.loads(path.read_text())
    _check_keys(raw, {"root", "state", "watch", "exclude_repos", "namespace", "handle",
                      "identity", "literal", "keep", "history", "shas"}, str(path))
    t = lambda v: tuple(v or ())  # noqa: E731

    def items(key, allowed):
        out = raw.get(key, [])
        for i, item in enumerate(out):
            _check_keys(item, allowed, f"[[{key}]] #{i + 1}")
        return out

    keep = raw.get("keep", {})
    _check_keys(keep, {"patterns", "paths"}, "[keep]")
    hist = raw.get("history", {})
    _check_keys(hist, {"identities", "messages", "contents", "merge_request_refs"}, "[history]")
    shas = raw.get("shas", {})
    _check_keys(shas, {"artifact_prefixes"}, "[shas]")
    mr = hist.get("merge_request_refs", "keep")
    if mr not in ("keep", "rewrite", "strip"):
        raise Fail("[history] merge_request_refs: one of keep, rewrite, strip")
    prefixes = shas.get("artifact_prefixes", ["sha-"])
    cfg = Config(
        path=path,
        root=(path.parent / raw.get("root", "..")).resolve(),
        state=(path.parent / raw.get("state", "state")).resolve(),
        watch=raw.get("watch", []),
        namespaces=[Namespace(n["host"], n["from"], n.get("to", ""), n.get("bare", True), t(n.get("paths")))
                    for n in items("namespace", {"host", "from", "to", "bare", "paths"})],
        handles=[Handle(h["from"], h.get("to", ""), t(h.get("paths")))
                 for h in items("handle", {"from", "to", "paths"})],
        identities=[Identity(t(i["emails"]), t(i.get("names")), i.get("name", ""), i.get("email", ""),
                             t(i.get("paths")))
                    for i in items("identity", {"emails", "names", "name", "email", "paths"})],
        literals=[Literal(x["from"], x.get("to", ""), x.get("regex", False), t(x.get("paths")))
                  for x in items("literal", {"from", "to", "regex", "paths"})],
        keeps=[Keep(p) for p in keep.get("patterns", [])],
        keep_paths=keep.get("paths", []),
        exclude_repos=raw.get("exclude_repos", []),
        h_identities=hist.get("identities", True),
        h_messages=hist.get("messages", True),
        h_contents=hist.get("contents", False),
        mr_policy=mr,
        artifact_prefixes=prefixes,
        artifact_rx=re.compile("(?:" + "|".join(prefixes) + r")$") if prefixes else None,
    )
    for r in [*cfg.literals, *cfg.keeps]:
        try:
            re.compile(_flags_scoped(r.frm if isinstance(r, Literal) and r.regex else
                                     getattr(r, "pattern", "") or "x"))
        except re.error as e:
            raise Fail(f"bad pattern {r}: {e}") from e
    return cfg


class Rules:
    """Builds and caches an engine for each set of rules a path is in scope of."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.rules = [*cfg.keeps, *cfg.literals, *cfg.identities, *cfg.namespaces, *cfg.handles]
        self.hosts = {n.host for n in cfg.namespaces} | KNOWN_HOSTS
        self.watch = (Alt("(?i:" + "|".join(re.escape(w) for w in cfg.watch) + ")", (9,),
                          "unresolved", "", None) if cfg.watch else None)
        self._cache: dict = {}

    def engine(self, rel: str, mr: str = "keep", kinds: frozenset | None = None) -> Engine:
        active = tuple(i for i, r in enumerate(self.rules)
                       if applies(r, rel) and (kinds is None or r.kind in kinds))
        key = (active, mr, kinds)
        if key not in self._cache:
            alts = [a for i in active for a in self.rules[i].alts(self.hosts)]
            if mr != "rewrite":
                alts += [self.rules[i].mr_alt() for i in active if self.rules[i].kind == "namespace"]
            if self.watch and (kinds is None or "unresolved" in kinds):
                alts.append(self.watch)
            self._cache[key] = Engine(alts)
        return self._cache[key]

    def strip_mr(self, rel: str, text: str) -> tuple[str, int]:
        """Drop GitLab's `See merge request <path>!N` lines for mapped paths."""
        paths = [re.escape(r.frm) for r in self.rules if r.kind == "namespace" and applies(r, rel)]
        if not paths:
            return text, 0
        rx = re.compile(rf"^See merge request (?:{'|'.join(paths)})(?:/[{SEG}]+)*![0-9]+[ \t]*\n?", re.M)
        new, n = rx.subn("", text)
        if n:
            new = new.rstrip("\n") + "\n"
        return new, n


URL_KINDS = frozenset({"keep", "literal", "namespace", "unresolved"})
PATH_KINDS = frozenset({"keep", "literal", "unresolved"})


def file_notes(rel: str) -> list[str]:
    base = rel.rsplit("/", 1)[-1]
    if base == "go.mod":
        return ["module path changed; the imports change with it: run `go build ./...` and `go vet ./...`"]
    if base in LOCKFILES:
        return ["lockfile edited in place: only URLs change and the artifact hashes still hold; "
                "regenerate it once the packages are served from the new path"]
    if base == ".copier-answers.yml":
        return ["Copier answers: `copier update` fetches the template from `_src_path`, "
                "so the template must exist at the new path first"]
    if base == "CODEOWNERS":
        return ["code owners changed: the new handles need access to the project"]
    return []


def process_text(rules: Rules, rel: str, text: str, mr: str, preview=False):
    eng = rules.engine(rel, "keep" if mr == "strip" else mr)
    if rel.rsplit("/", 1)[-1] == "go.sum":
        out, events, dropped, off = [], [], 0, 0
        for line in text.splitlines(keepends=True):
            new, ev = eng.rewrite(line, preview)
            for e in ev:
                e.pos += off
            off += len(line)
            if new != line:
                dropped += 1
                for e in ev:
                    e.new = "(line dropped)" if e.new is not None else e.new
            else:
                out.append(line)
            events += ev
        notes = [f"dropped {dropped} line(s) whose module path changed (their h1: hashes cover the path): "
                 "run `go mod tidy` once the new path resolves"] if dropped else []
        return "".join(out), events, notes
    new, events = eng.rewrite(text, preview)
    return new, events, (file_notes(rel) if new != text else [])


# ── Commit SHA references ────────────────────────────────────────────────


class ShaIndex:
    """Old commit SHA → (new SHA, repository), looked up by unique prefix."""

    def __init__(self, mapping: dict[str, tuple[str, str]]):
        self.map = mapping
        self.keys = sorted(mapping)

    def lookup(self, token: str) -> str | None:
        i = bisect.bisect_left(self.keys, token)
        hits = [k for k in self.keys[i:i + 2] if k.startswith(token)]
        return hits[0] if len(hits) == 1 else None

    def remap(self, text: str, artifact_rx, events: list[Event] | None = None) -> str:
        def sub(m):
            tok = m.group()
            if not re.search("[a-f]", tok):
                return tok  # all digits: a number, not a SHA
            key = self.lookup(tok)
            if key is None:
                return tok
            new, repo = self.map[key]
            if artifact_rx and artifact_rx.search(text[max(0, m.start() - 40):m.start()]):
                if events is not None:
                    events.append(Event("artifact", repo, tok, None, m.start()))
                return tok
            if events is not None:
                events.append(Event("sha", repo, tok, new[:len(tok)], m.start()))
            return new[:len(tok)]
        return HEX.sub(sub, text)

    @classmethod
    def load(cls, run: Path) -> "ShaIndex":
        mapping = {}
        for f in sorted(run.glob("*.commit-map")):
            repo = f.name.removesuffix(".commit-map").replace("__", "/")
            for line in f.read_text().splitlines()[1:]:
                old, new = line.split()
                mapping[old] = (new, repo)
        return cls(mapping)


# ── Workspace ────────────────────────────────────────────────────────────


def discover(cfg: Config, only: list[str] | None = None) -> tuple[list[Path], list[Path]]:
    """Git repositories under the root, and the files outside them."""
    repos, loose = [], []
    for dirpath, dirnames, filenames in os.walk(cfg.root):
        d = Path(dirpath)
        if (d / ".git").exists() and d != cfg.root:
            repos.append(d)
            dirnames[:] = []
            continue
        dirnames[:] = sorted(n for n in dirnames if n not in SKIP_DIRS and not n.startswith("."))
        loose += [d / f for f in sorted(filenames)]
    rel = lambda p: p.relative_to(cfg.root).as_posix()  # noqa: E731
    repos = [r for r in repos if not any(fnmatch.fnmatchcase(rel(r), g) for g in cfg.exclude_repos)]
    if only:
        repos = [r for r in repos if any(fnmatch.fnmatchcase(rel(r), g) for g in only)]
    return sorted(repos), loose


def tracked(repo: Path) -> list[str]:
    return [p for p in git(repo, "ls-files", "-z").split("\0") if p]


def read_text(path: Path) -> tuple[str | None, str | None]:
    """(text, why-skipped). Symlinks yield their target, never the file behind."""
    try:
        st = path.lstat()
    except FileNotFoundError:
        return None, "missing"
    if os.path.islink(path):
        return os.readlink(path), None
    if st.st_size > MAX_BYTES:
        return None, "larger than 20 MB"
    data = path.read_bytes()
    if b"\0" in data[:8192]:
        return None, "binary"
    return data.decode(**ENC), None


def write_text(path: Path, text: str):
    if os.path.islink(path):
        path.unlink()
        os.symlink(text, path)
    else:
        path.write_bytes(text.encode(**ENC))


@dataclass
class FileChange:
    rel: str
    path: Path
    old: str
    new: str
    events: list[Event]
    notes: list[str]


@dataclass
class RepoPlan:
    repo: Path
    rel: str
    files: list[FileChange] = field(default_factory=list)
    renames: list[tuple[str, str]] = field(default_factory=list)
    path_events: list[tuple[str, Event]] = field(default_factory=list)
    remotes: list[tuple[str, str, str, list[Event]]] = field(default_factory=list)
    skipped: list[tuple[str, str]] = field(default_factory=list)
    kept_paths: int = 0
    dirty: bool = False


def watched(cfg: Config, data: bytes) -> bool:
    low = data.lower()
    return any(w.lower().encode() in low for w in cfg.watch)


def plan_file(rules: Rules, cfg: Config, rel: str, path: Path, preview: bool, skipped: list):
    text, why = read_text(path)
    if text is None:
        if why in ("binary", "larger than 20 MB") and watched(cfg, path.read_bytes()):
            skipped.append((rel, f"{why}, contains a watched word: not edited"))
        return None
    new, events, notes = process_text(rules, rel, text, cfg.mr_policy, preview)
    return FileChange(rel, path, text, new, events, notes) if events else None


def plan_repo(rules: Rules, cfg: Config, repo: Path, preview=False) -> RepoPlan:
    rel = repo.relative_to(cfg.root).as_posix()
    plan = RepoPlan(repo, rel)
    plan.dirty = bool(git(repo, "status", "--porcelain", "--untracked-files=no").strip())
    for f in tracked(repo):
        wrel = f"{rel}/{f}"
        if any(fnmatch.fnmatchcase(wrel, g) for g in cfg.keep_paths):
            plan.kept_paths += 1
            continue
        fc = plan_file(rules, cfg, wrel, repo / f, preview, plan.skipped)
        if fc:
            plan.files.append(fc)
        new, events = rules.engine(wrel, kinds=PATH_KINDS).rewrite(f)
        plan.path_events += [(f, e) for e in events]
        if new != f and not any(e.kind == "unset" for e in events):
            plan.renames.append((f, new))
    remotes = git(repo, "config", "--get-regexp", r"^remote\..*\.(url|pushurl)$", check=False)
    for line in remotes.splitlines():
        key, _, url = line.partition(" ")
        new, events = rules.engine(rel + "/", kinds=URL_KINDS).rewrite(url, preview)
        if events:
            plan.remotes.append((key, url, new, events))
    return plan


# ── Reports ──────────────────────────────────────────────────────────────


def line_of(text: str, pos: int) -> tuple[int, str]:
    start = text.rfind("\n", 0, pos) + 1
    end = text.find("\n", pos)
    line = text[start:end if end != -1 else len(text)]
    return text.count("\n", 0, pos) + 1, line.strip()


def clip(s: str, n: int = 150) -> str:
    return s if len(s) <= n else s[:n - 1] + "…"


CHANGE_KINDS = ("namespace", "handle", "identity", "literal")


def summarize(events: list[Event]) -> list[str]:
    by_label: dict[str, Counter] = {}
    for e in events:
        if e.kind in CHANGE_KINDS or e.kind == "unset":
            by_label.setdefault(e.label, Counter())[(e.old, e.new)] += 1
    out = []
    for label, pairs in sorted(by_label.items()):
        out.append(f"    {label}: {sum(pairs.values())}")
        if len(pairs) > 1:
            for (old, new), n in pairs.most_common(6):
                out.append(f"        {n:4}  {clip(old, 70)}" + (f"  →  {clip(new, 70)}" if new else ""))
    return out


def print_plan(plan: RepoPlan, verbose: bool, show_diff: bool) -> dict:
    events = [e for fc in plan.files for e in fc.events]
    changes = [e for e in events if e.kind in CHANGE_KINDS]
    files_changed = sum(1 for fc in plan.files if fc.new != fc.old)
    print(f"\n{plan.rel}" + ("   (uncommitted changes)" if plan.dirty else ""))
    for key, url, new, ev in plan.remotes:
        print(f"  remote   {key.removeprefix('remote.')}  {url}")
        if new != url:
            print(f"           → {new}")
        elif any(e.kind == "unset" for e in ev):
            print("           → (waits for an unset target)")
    pending = [e for e in events if e.kind == "unset"]
    if changes or pending:
        waiting = f", {len(pending)} match(es) waiting for an unset target" if pending else ""
        print(f"  files    {len(changes)} change(s) in {files_changed} file(s){waiting}")
        for line in summarize(events):
            print(line)
    kept = Counter(e.kind for e in events if e.kind in ("keep", "mr-ref"))
    if kept:
        print("  kept     " + ", ".join(f"{n} {k}" for k, n in sorted(kept.items())))
    for old, new in plan.renames:
        print(f"  rename   {old} → {new}")
    notes = sorted({f"{fc.rel.removeprefix(plan.rel + '/')}: {n}" for fc in plan.files for n in fc.notes})
    for n in notes:
        print(f"  note     {n}")
    for rel, why in plan.skipped:
        print(f"  skipped  {rel}: {why}")
    if verbose:
        for fc in plan.files:
            for e in fc.events:
                if e.kind in CHANGE_KINDS:
                    ln, _ = line_of(fc.old, e.pos)
                    print(f"    {fc.rel}:{ln}: {clip(e.old, 60)} → {clip(e.new or '', 60)}")
    if show_diff:
        for fc in plan.files:
            if fc.new != fc.old:
                sys.stdout.writelines(difflib.unified_diff(
                    fc.old.splitlines(keepends=True), fc.new.splitlines(keepends=True),
                    f"a/{fc.rel}", f"b/{fc.rel}", n=1))
    unresolved = [(fc.rel, *line_of(fc.old, e.pos)) for fc in plan.files for e in fc.events
                  if e.kind == "unresolved"]
    unresolved += [(f"{plan.rel}/{p}", 0, p) for p, e in plan.path_events if e.kind == "unresolved"]
    unresolved += [(f"{plan.rel}: {key}", 0, url) for key, url, _, ev in plan.remotes
                   for e in ev if e.kind == "unresolved"]
    unset = [e for e in events if e.kind == "unset"] + \
            [e for _, _, _, ev in plan.remotes for e in ev if e.kind == "unset"]
    return {"unresolved": unresolved, "unset": unset}


def history_report(rules: Rules, cfg: Config, repo: Path, rel: str) -> dict:
    emails = {e.lower() for i in cfg.identities for e in i.emails}
    watch_rx = re.compile("|".join(re.escape(w) for w in cfg.watch), re.I) if cfg.watch else None
    log = git(repo, "log", "--all", "--format=%an%x1f%ae%x1f%cn%x1f%ce%x1f%B%x1e")
    tags = git(repo, "for-each-ref", "refs/tags",
               "--format=%(objecttype)%1f%(taggername)%1f%(taggeremail)%1f%(contents)%1e")
    rep = {"commits": 0, "mapped": 0, "tags_mapped": 0, "unknown": Counter(),
           "messages": Counter(), "msg_unresolved": [], "stripped": 0}
    eng = rules.engine(rel + "/", "keep" if cfg.mr_policy == "strip" else cfg.mr_policy)

    def message(body):
        if cfg.mr_policy == "strip":
            body, n = rules.strip_mr(rel + "/", body)
            rep["stripped"] += n
        _, ev = eng.rewrite(body)
        for e in ev:
            rep["messages"][e.kind] += 1
            if e.kind == "unresolved" and len(rep["msg_unresolved"]) < 5:
                rep["msg_unresolved"].append(line_of(body, e.pos)[1])

    for rec in log.split("\x1e"):
        rec = rec.lstrip("\n")
        if not rec:
            continue
        an, ae, cn, ce, body = rec.split("\x1f", 4)
        rep["commits"] += 1
        rep["mapped"] += ae.lower() in emails or ce.lower() in emails
        for n, e in ((an, ae), (cn, ce)):
            if e.lower() not in emails and watch_rx and watch_rx.search(n + e):
                rep["unknown"][f"{n} <{e}>"] += 1
        message(body)
    for rec in tags.split("\x1e"):
        rec = rec.lstrip("\n")
        if not rec:
            continue
        kind, tn, te, body = rec.split("\x1f", 3)
        if kind == "tag":
            rep["tags_mapped"] += te.strip("<>").lower() in emails
            message(body)
    refs = git(repo, "for-each-ref", "--format=%(refname)")
    rep["refs"] = [r for r in refs.splitlines() if watch_rx and watch_rx.search(r)]
    return rep


def all_commits(repos: list[Path], root: Path) -> ShaIndex:
    mapping = {}
    for r in repos:
        rel = r.relative_to(root).as_posix()
        for sha in git(r, "rev-list", "--all").split():
            mapping[sha] = (sha, rel)
    return ShaIndex(mapping)


def sha_references(cfg: Config, repos: list[Path], idx: ShaIndex) -> dict:
    """References to the repositories' own commits in their tracked files."""
    refs, deps, commits = Counter(), {}, set()
    for r in repos:
        rel = r.relative_to(cfg.root).as_posix()
        deps[rel] = Counter()
        for f in tracked(r):
            text, _ = read_text(r / f)
            if not text or not HEX.search(text):
                continue
            ev: list[Event] = []
            idx.remap(text, cfg.artifact_rx, ev)
            for e in ev:
                refs[e.kind] += 1
                commits.add(idx.lookup(e.old))
                if e.label != rel:
                    deps[rel][e.label] += 1
    return {"git_refs": refs["sha"], "artifacts": refs["artifact"],
            "commits": len(commits), "deps": deps}


# ── Commands ─────────────────────────────────────────────────────────────


def cmd_scan(cfg: Config, args) -> int:
    rules = Rules(cfg)
    repos, loose = discover(cfg, args.repo)
    print(f"Workspace {cfg.root}: {len(repos)} repositories (config {cfg.path.name})")
    unresolved, unset, hist = [], [], {}
    for repo in repos:
        plan = plan_repo(rules, cfg, repo, preview=args.diff)
        res = print_plan(plan, args.verbose, args.diff)
        unresolved += res["unresolved"]
        unset += res["unset"]
        h = history_report(rules, cfg, repo, plan.rel)
        hist[plan.rel] = h
        msg = ", ".join(f"{n} {k}" for k, n in sorted(h["messages"].items()))
        print(f"  history  {h['mapped']}/{h['commits']} commits and {h['tags_mapped']} tag(s) "
              f"by mapped identities" + (f"; messages: {msg}" if msg else "")
              + (f"; {h['stripped']} merge request line(s) stripped" if h["stripped"] else ""))
        for ident, n in h["unknown"].items():
            print(f"  history  unmapped identity {ident}: {n} commit(s)")
        for r in h["refs"]:
            print(f"  history  ref with a watched word: {r}")

    if loose:
        print("\nWorkspace files outside the repositories (`apply --workspace` edits them):")
        for p in loose:
            rel = p.relative_to(cfg.root).as_posix()
            fc = plan_file(rules, cfg, rel, p, args.diff, [])
            if not fc:
                continue
            n = sum(1 for e in fc.events if e.kind in CHANGE_KINDS)
            waiting = sum(1 for e in fc.events if e.kind == "unset")
            print(f"  {rel}: {n} change(s)" + (f", {waiting} waiting for an unset target" if waiting else ""))
            for line in summarize(fc.events):
                print(line)
            unresolved += [(rel, *line_of(fc.old, e.pos)) for e in fc.events if e.kind == "unresolved"]
            unset += [e for e in fc.events if e.kind == "unset"]

    print("\nCommit SHAs cited in tracked files")
    idx = all_commits(repos, cfg.root)
    refs = sha_references(cfg, repos, idx)
    print(f"  {refs['git_refs'] + refs['artifacts']} references to {refs['commits']} commits of these "
          f"repositories. A history rewrite gives every commit a new SHA: `history` remaps the "
          f"{refs['git_refs']} git references in the working trees and leaves the {refs['artifacts']} "
          f"artifact tags (after {', '.join(repr(p) for p in cfg.artifact_prefixes)}), "
          f"whose images and packages were built under the old SHAs.")

    print("\nUnresolved: no rule accounts for these; add a rule, or a [keep] pattern")
    for rel, ln, line in unresolved or [("none", 0, "")]:
        print(f"  {rel}{':' + str(ln) if ln else ''}  {clip(line)}")
    for rel, h in hist.items():
        for line in h["msg_unresolved"]:
            print(f"  {rel} (commit message)  {clip(line)}")

    labels = sorted({e.label for e in unset})
    if labels:
        print("\nTargets still unset in the config (apply and history refuse while they match):")
        for label in labels:
            print(f"  {label}: {sum(1 for e in unset if e.label == label)} match(es)")
    return 0


def check_unset(cfg: Config, unset: list[Event]):
    if unset:
        labels = sorted({e.label for e in unset})
        raise Fail("these rules match but have no target yet; set them in "
                   f"{cfg.path.name}:\n  " + "\n  ".join(labels))


def cmd_apply(cfg: Config, args) -> int:
    rules = Rules(cfg)
    repos, loose = discover(cfg, args.repo)
    plans = [plan_repo(rules, cfg, r) for r in repos]
    unset = [e for p in plans for fc in p.files for e in fc.events if e.kind == "unset"]
    unset += [e for p in plans for _, _, _, ev in p.remotes for e in ev if e.kind == "unset"]
    loose_changes = []
    if args.workspace:
        for p in loose:
            fc = plan_file(rules, cfg, p.relative_to(cfg.root).as_posix(), p, False, [])
            if fc:
                loose_changes.append(fc)
                unset += [e for e in fc.events if e.kind == "unset"]
    check_unset(cfg, unset)
    total = 0
    for plan in plans:
        written = [fc for fc in plan.files if fc.new != fc.old]
        for fc in written:
            write_text(fc.path, fc.new)
        for old, new in plan.renames:
            (plan.repo / new).parent.mkdir(parents=True, exist_ok=True)
            git(plan.repo, "mv", "--", old, new)
            try:
                (plan.repo / old).parent.removedirs()
            except OSError:
                pass
        remotes = 0
        if not args.no_remotes:
            for key, url, new, _ in plan.remotes:
                if new != url:
                    git(plan.repo, "config", "--fixed-value", "--replace-all", key, new, url)
                    remotes += 1
        n = sum(1 for fc in written for e in fc.events if e.kind in CHANGE_KINDS)
        total += n
        if written or plan.renames or remotes:
            print(f"{plan.rel}: {n} change(s) in {len(written)} file(s), "
                  f"{len(plan.renames)} rename(s), {remotes} remote URL(s)"
                  + ("  [had uncommitted changes before]" if plan.dirty else ""))
            for note in sorted({f"{fc.rel}: {x}" for fc in written for x in fc.notes}):
                print(f"  note  {note}")
    for fc in loose_changes:
        if fc.new != fc.old:
            write_text(fc.path, fc.new)
            print(f"{fc.rel}: {sum(1 for e in fc.events if e.kind in CHANGE_KINDS)} change(s)")
    print(f"\n{total} change(s) written. Review with `git diff`, then commit each repository on a branch.")
    return 0


def preflight(repo: Path) -> list[str]:
    gd = Path(git(repo, "rev-parse", "--absolute-git-dir").strip())
    problems = []
    if git(repo, "rev-parse", "--is-shallow-repository").strip() == "true":
        problems.append("shallow clone")
    if git(repo, "worktree", "list", "--porcelain").count("\nworktree ") > 0:
        problems.append("has linked worktrees")
    if git(repo, "status", "--porcelain", "--untracked-files=no").strip():
        problems.append("uncommitted changes to tracked files")
    for marker in ("MERGE_HEAD", "rebase-merge", "rebase-apply", "CHERRY_PICK_HEAD", "REVERT_HEAD"):
        if (gd / marker).exists():
            problems.append(f"operation in progress ({marker})")
    if not git(repo, "for-each-ref", "--count=1").strip():
        problems.append("no refs")
    if git(repo, "stash", "list").strip():
        problems.append("has stashes (pop or drop them first)")
    return problems


def order_repos(rels: list[str], deps: dict[str, Counter]) -> list[str]:
    """Referenced repositories first, so their maps exist when citers are rewritten."""
    pending, done = set(rels), []
    while pending:
        ready = sorted(r for r in pending if not (set(deps.get(r, {})) & pending))
        pick = ready[0] if ready else min(
            sorted(pending), key=lambda r: len(set(deps.get(r, {})) & pending))
        done.append(pick)
        pending.remove(pick)
    return done


def config_lines(repo: Path) -> list[tuple[str, str]]:
    out = git(repo, "config", "--local", "--get-regexp", r"^(remote|branch)\.", check=False)
    return [tuple(line.split(" ", 1)) if " " in line else (line, "") for line in out.splitlines()]


def cmd_history(cfg: Config, args) -> int:
    if not (cfg.h_identities or cfg.h_messages or cfg.h_contents):
        raise Fail("[history] enables nothing")
    if cfg.h_identities:
        missing = [i.label for i in cfg.identities if not (i.name and i.email)]
        if missing:
            raise Fail("identities without a target name and email:\n  " + "\n  ".join(missing))
    rules = Rules(cfg)
    repos, _ = discover(cfg, args.repo)
    problems = {r: preflight(r) for r in repos}
    if any(problems.values()):
        raise Fail("not rewriting anything; fix these first:\n" + "\n".join(
            f"  {r.relative_to(cfg.root)}: {', '.join(p)}" for r, p in problems.items() if p))
    if cfg.h_messages or cfg.h_contents:
        unset = []
        for r in repos:
            rel = r.relative_to(cfg.root).as_posix()
            unset += [e for e in history_events(rules, cfg, r, rel) if e.kind == "unset"]
            if cfg.h_contents:
                p = plan_repo(rules, cfg, r)
                unset += [e for fc in p.files for e in fc.events if e.kind == "unset"]
        check_unset(cfg, unset)

    rels = [r.relative_to(cfg.root).as_posix() for r in repos]
    pre = all_commits(repos, cfg.root)
    refs = sha_references(cfg, repos, pre)
    order = order_repos(rels, refs["deps"])
    total = sum(int(git(r, "rev-list", "--all", "--count")) for r in repos)
    parts = [x for x, on in (("identities", cfg.h_identities), ("messages", cfg.h_messages),
                             ("file contents", cfg.h_contents)) if on]
    print(f"Rewriting {', '.join(parts)} in {len(repos)} repositories ({total} commits). Every commit "
          f"gets a new SHA; the old ones survive only in this run's bundles and wherever they "
          f"were pushed.")
    if not args.yes:
        print("Nothing changed. Run again with --yes to rewrite.")
        return 1

    run = cfg.state / "runs" / datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    run.mkdir(parents=True)
    if cfg.h_identities:
        (run / "mailmap").write_text("".join(i.mailmap() for i in cfg.identities))
    manifest = {"root": str(cfg.root), "config": str(cfg.path), "repos": []}
    for rel in order:
        repo = cfg.root / rel
        slug = rel.replace("/", "__")
        gd = Path(git(repo, "rev-parse", "--absolute-git-dir").strip())
        entry = {"rel": rel, "slug": slug, "status": "started",
                 "head": git(repo, "symbolic-ref", "-q", "HEAD", check=False).strip(),
                 "symrefs": {}}
        manifest["repos"].append(entry)
        for ref in git(repo, "for-each-ref", "--format=%(refname) %(symref)", "refs/remotes").splitlines():
            name, _, target = ref.partition(" ")
            if target:
                entry["symrefs"][name] = target
        before_count = int(git(repo, "rev-list", "--all", "--count"))
        trees = dict(l.split() for l in git(repo, "log", "--all", "--format=%H %T").splitlines())
        cfg_before = config_lines(repo)
        shutil.copy2(gd / "config", run / f"{slug}.git-config")
        git(repo, "bundle", "create", str(run / f"{slug}.bundle"), "--all")
        git(repo, "bundle", "verify", "--quiet", str(run / f"{slug}.bundle"))
        if (gd / "filter-repo").exists():
            shutil.move(gd / "filter-repo", run / f"{slug}.filter-repo-before")
            entry["filter_repo_before"] = True
        (run / "manifest.json").write_text(json.dumps(manifest, indent=2))

        r = subprocess.run([sys.executable, __file__, "--config", str(cfg.path), "_filter",
                            "--repo", rel, "--run", str(run)], capture_output=True, **ENC)
        if r.returncode:
            entry["status"] = "failed"
            (run / "manifest.json").write_text(json.dumps(manifest, indent=2))
            raise Fail(f"{rel}: filter-repo failed:\n{r.stdout}{r.stderr}\n"
                       f"Restore with: rebrand.py restore {run} --yes")
        shutil.copy2(gd / "filter-repo" / "commit-map", run / f"{slug}.commit-map")

        # filter-repo removes origin, and with it the branches' upstream
        # settings; put them back as they were (apply rewrites the URLs)
        for key in sorted({k for k, _ in cfg_before}):
            git(repo, "config", "--local", "--unset-all", key, check=False)
            for k, v in cfg_before:
                if k == key:
                    git(repo, "config", "--local", "--add", k, v)

        problems = verify(cfg, repo, before_count, trees, gd / "filter-repo" / "commit-map", entry)
        entry["status"] = "rewritten" if not problems else "rewritten with problems"
        entry["problems"] = problems
        (run / "manifest.json").write_text(json.dumps(manifest, indent=2))
        print(f"  {rel}: {before_count} commits rewritten"
              + ("" if not problems else "; PROBLEMS: " + "; ".join(problems)))

    idx = ShaIndex.load(run)
    remapped, artifacts = 0, 0
    for repo in repos:
        rel = repo.relative_to(cfg.root).as_posix()
        for f in tracked(repo):
            if any(fnmatch.fnmatchcase(f"{rel}/{f}", g) for g in cfg.keep_paths):
                continue
            text, _ = read_text(repo / f)
            if not text or not HEX.search(text):
                continue
            ev: list[Event] = []
            new = idx.remap(text, cfg.artifact_rx, ev)
            remapped += sum(1 for e in ev if e.kind == "sha" and e.old != e.new)
            artifacts += sum(1 for e in ev if e.kind == "artifact")
            if new != text:
                write_text(repo / f, new)
    print(f"\nRemapped {remapped} commit SHA reference(s) in the working trees (uncommitted); "
          f"left {artifacts} artifact tag(s).")
    print(f"Backups and commit maps: {run}\nUndo: uv run {Path(__file__).name} restore {run} --yes")
    print("filter-repo dropped the remote-tracking branches; their commits are now local branches. "
          "Nothing was pushed.")
    return 0


def history_events(rules: Rules, cfg: Config, repo: Path, rel: str) -> list[Event]:
    log = git(repo, "log", "--all", "--format=%B%x1e")
    tags = git(repo, "for-each-ref", "refs/tags", "--format=%(contents)%1e")
    eng = rules.engine(rel + "/", "keep" if cfg.mr_policy == "strip" else cfg.mr_policy)
    events = []
    for body in (log + tags).split("\x1e"):
        events += eng.rewrite(body)[1]
    return events


def verify(cfg: Config, repo: Path, before: int, trees: dict, cmap: Path, entry: dict) -> list[str]:
    problems = []
    after = int(git(repo, "rev-list", "--all", "--count"))
    if after != before:
        problems.append(f"commit count {before} → {after}")
    pairs = [l.split() for l in cmap.read_text().splitlines()[1:]]
    entry["commits"] = len(pairs)
    if not cfg.h_contents:
        new_trees = dict(l.split() for l in git(repo, "log", "--all", "--format=%H %T").splitlines())
        bad = sum(1 for old, new in pairs if old in trees and trees[old] != new_trees.get(new))
        if bad:
            problems.append(f"{bad} commit(s) whose files differ from before")
    if cfg.h_identities:
        old = {e.lower() for i in cfg.identities for e in i.emails}
        seen = set(git(repo, "log", "--all", "--format=%ae%n%ce").lower().split())
        seen |= {e.strip("<>") for e in git(repo, "for-each-ref", "refs/tags",
                                             "--format=%(taggeremail)").lower().split()}
        if seen & old:
            problems.append("old identities remain: " + ", ".join(sorted(seen & old)))
    if git(repo, "status", "--porcelain", "--untracked-files=no").strip():
        problems.append("working tree differs from HEAD")
    return problems


def cmd_filter_one(cfg: Config, args) -> int:
    """Runs in its own process per repository: filter-repo keeps global state."""
    import git_filter_repo as fr

    rules = Rules(cfg)
    rel = args.repo
    repo = cfg.root / rel
    run = Path(args.run)
    idx = ShaIndex.load(run)  # repositories rewritten earlier in this run
    mr = cfg.mr_policy
    eng = rules.engine(rel + "/", "keep" if mr == "strip" else mr)

    def message_callback(msg: bytes) -> bytes:
        text = msg.decode(**ENC)
        if mr == "strip":
            text = rules.strip_mr(rel + "/", text)[0]
        text = eng.rewrite(text)[0]
        if idx.keys:
            text = idx.remap(text, cfg.artifact_rx)
        return text.encode(**ENC)

    def file_info_callback(filename, mode, blob_id, value):
        wrel = f"{rel}/{filename.decode(**ENC)}"
        if mode == b"160000" or any(fnmatch.fnmatchcase(wrel, g) for g in cfg.keep_paths):
            return filename, mode, blob_id
        key = (filename, blob_id)
        if key not in value.data:
            data = value.get_contents_by_identifier(blob_id)
            new_id = blob_id
            if len(data) <= MAX_BYTES and not value.is_binary(data):
                text = data.decode(**ENC)
                new, _, _ = process_text(rules, wrel, text, mr)
                if idx.keys:
                    new = idx.remap(new, cfg.artifact_rx)
                if new != text:
                    new_id = value.insert_file_with_contents(new.encode(**ENC))
            value.data[key] = new_id
        return filename, mode, value.data[key]

    argv = ["--force", "--quiet", "--prune-empty", "never", "--prune-degenerate", "never"]
    if cfg.h_identities:
        argv += ["--mailmap", str(run / "mailmap")]
    os.chdir(repo)
    options = fr.FilteringOptions.parse_args(argv)
    fr.RepoFilter(options,
                  message_callback=message_callback if cfg.h_messages else None,
                  file_info_callback=file_info_callback if cfg.h_contents else None).run()
    return 0


def cmd_restore(cfg: Config, args) -> int:
    run = Path(args.run).resolve()
    manifest = json.loads((run / "manifest.json").read_text())
    root = Path(manifest["root"])
    entries = [e for e in manifest["repos"] if (run / f"{e['slug']}.bundle").exists()]
    print(f"Restoring {len(entries)} repositories from {run}: refs, .git/config and working tree. "
          "Uncommitted changes to tracked files in them are discarded.")
    if not args.yes:
        print("Nothing changed. Run again with --yes to restore.")
        return 1
    for e in entries:
        repo, bundle = root / e["rel"], run / f"{e['slug']}.bundle"
        gd = Path(git(repo, "rev-parse", "--absolute-git-dir").strip())
        git(repo, "fetch", "--quiet", "--force", "--prune", "--update-head-ok", "--no-write-fetch-head",
            str(bundle), "+refs/*:refs/*", "^refs/remotes/*/HEAD")
        shutil.copy2(run / f"{e['slug']}.git-config", gd / "config")
        for name, target in e.get("symrefs", {}).items():
            git(repo, "symbolic-ref", name, target)
        if e.get("head"):
            git(repo, "symbolic-ref", "HEAD", e["head"])
        git(repo, "reset", "--quiet", "--hard")
        shutil.rmtree(gd / "filter-repo", ignore_errors=True)
        if e.get("filter_repo_before"):
            shutil.move(run / f"{e['slug']}.filter-repo-before", gd / "filter-repo")
        print(f"  {e['rel']}: restored")
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="rebrand.py", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=str(HERE / "rebrand.toml"))
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("scan", help="report planned changes; changes nothing")
    s.add_argument("--diff", action="store_true", help="print unified diffs (unset targets shown as ⟨unset:…⟩)")
    s.add_argument("--verbose", action="store_true", help="list every change with file and line")
    s.add_argument("--repo", action="append", help="only repositories matching this glob")
    a = sub.add_parser("apply", help="rewrite tracked files and remote URLs")
    a.add_argument("--repo", action="append")
    a.add_argument("--workspace", action="store_true", help="also edit files outside the repositories")
    a.add_argument("--no-remotes", action="store_true", help="leave remote URLs as they are")
    h = sub.add_parser("history", help="rewrite identities and messages in all history")
    h.add_argument("--repo", action="append")
    h.add_argument("--yes", action="store_true", help="really rewrite")
    r = sub.add_parser("restore", help="restore repositories from a history run")
    r.add_argument("run")
    r.add_argument("--yes", action="store_true")
    f = sub.add_parser("_filter")
    f.add_argument("--repo", required=True)
    f.add_argument("--run", required=True)
    args = ap.parse_args(argv)
    try:
        cfg = load_config(Path(args.config).resolve())
        return {"scan": cmd_scan, "apply": cmd_apply, "history": cmd_history,
                "restore": cmd_restore, "_filter": cmd_filter_one}[args.cmd](cfg, args)
    except Fail as e:
        print(f"rebrand: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
