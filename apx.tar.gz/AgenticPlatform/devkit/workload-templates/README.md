# workload-templates

The platform's workload templates, the settings of the projects made from them, and the generation job that makes those projects ([Development](../../architecture/design/development.md#project-generation-and-updates), [Repositories](../../architecture/design/repositories.md#project-creation-and-settings)). A developer never runs it directly: `agentctl new` starts it.

```text
workload-templates/
├── copier.yml            # the questions, the naming rules and the pins of all four templates
├── adk-agent/            # an ADK agent served over A2A
├── mcp-server-python/    # an MCP server over streamable HTTP
├── kagent-agent/         # a declarative kagent agent
├── workflow-pipeline/    # a GitLab pipeline with a bounded model step
├── reference/            # the reference workloads' own files, over their templates
├── project-settings.yml  # Free settings of every workload project, applied with gitlabform
├── generator/            # the generation job: generate.py and its pinned tools
├── tools/relock.py       # writes the Python templates' uv.lock
├── tests/                # the generator against a fake GitLab API; the templates rendered
└── .gitlab-ci.yml        # tests on merge requests and main; the generation job on inputs
```

## The templates

One Copier template per directory, chosen by the `template` answer through [`copier.yml`](copier.yml)'s `_subdirectory`, so that one `vX.Y.Z` tag versions all four and `copier update` brings a project to a newer one. A generated project's `.copier-answers.yml` records the template, its version and the answers.

| Template | Makes | Built on |
| --- | --- | --- |
| [`mcp-server-python`](mcp-server-python) | An MCP server: MCP SDK 2.x's `MCPServer` over streamable HTTP, stateless; each tool call through the SDK's `ToolGuard` (idempotency by task ID, approval of a destructive tool, one audit record per call), the approval route when a tool needs one, tools' annotations from `workload.yaml` | `agentic-agent-sdk[mcp,postgres]` |
| [`adk-agent`](adk-agent) | An ADK agent over A2A: `OpenAILlm` with `fast-default` through the gateway, the limits plugin, an `McpToolset` per server `workload.yaml` names with a token per route, exchanged at the STS for the caller; ADK's sessions in Postgres when a database is given | `agentic-agent-sdk-adk` |
| [`kagent-agent`](kagent-agent) | A kagent 1.0.1 `AgentTemplate` with its `ModelConfig` and `RemoteMCPServer` bindings, the prompt in `.agents/prompts/system.md`, skills as directories packaged as scratch images (D28) | The `workload` umbrella's kagent mode |
| [`workflow-pipeline`](workflow-pipeline) | A pipeline whose job runs a bounded model step (agent-sdk's `spec/step/`) through ci-components' `step` component; manual until D27 | The `step` component |

Every one carries `workload.yaml`, `AGENTS.md`, `.agents/`, `evals/`, a `.gitlab-ci.yml` with `workflow: rules` and one ci-components component at its 1.x release (`@1`), and, but for the workflow, `deploy/` values for `app-base` and `agent-integration` and an access file to propose in `environments`. The Python ones carry a Dockerfile the `build` component builds without network (no `RUN`; each platform's wheels copied in) and a `uv.lock`; their pipelines read the SDK from agent-sdk's registry, the index `agentic` of `pyproject.toml`, with the job token, and `build:wheels`, which installs from the lock's export, from `AGENTIC_PYPI_INDEX_URL`. Their `deploy/app-base.yaml` names the database image environments pins; the backups' bucket is the environment's.

**Pins** live in `copier.yml`'s `pins`: ci-components' commit, the SDK's dev build, the charts' commit and dev versions, and the Python base image by digest. After a change to a pin or to a Python template's `pyproject.toml.jinja`, write the locks again, the SDK's registry readable by uv:

```sh
tools/relock.py --sdk-index-url <agent-sdk's PyPI simple URL>
```

## The reference workloads

[`reference/`](reference) holds what each reference workload adds to its template (plan/local-build.md, "The reference workloads"): its answers (`answers.yml`), its own files (`files/`), and files it removes (`remove.txt`). [`reference/apply.py`](reference/apply.py) renders one and lays its files over it, or, with `--overlay-only`, lays them over a checkout of the project the generation job made, for its first merge request.

| Workload | Template | Adds |
| --- | --- | --- |
| `reference-mcp` | `mcp-server-python` | Notes in Postgres (in memory without a database): `list_notes` and `get_note` read-only, `add_note` destructive with approval and idempotency by task ID; its tests run check 8's approval cases on both stores |
| `reference-agent` | `adk-agent` | Questions about notes, granted `list_notes` and `get_note` alone on `reference-mcp`, which it calls with a token exchanged for the caller |
| `reference-notes-agent` | `kagent-agent` | The same questions, declaratively: `list_notes` and `get_note` bound, `add_note` bound with `requireApproval`, `reference-mcp`'s listing, and one skill |

## The generation job

`agentctl new` starts a pipeline on this project's protected `main` with four pipeline inputs, never variables ([agentctl](https://gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl), "new"):

| Input | Holds |
| --- | --- |
| `template` | `adk-agent`, `mcp-server-python`, `kagent-agent` or `workflow-pipeline` |
| `name` | The workload's name: lowercase kebab-case, at most 63 characters, ending in the template's suffix (`-agent`, `-mcp`, `-workflow`), never a framework or runtime as a word ([Naming](../../architecture/design/repositories.md#naming)) |
| `team` | The owning team's slug, the workload's `owner`; its group `workloads/<team>` must exist |
| `placement` | `team` for `workloads/<team>/<name>`, `shared` for `workloads/shared/<name>`, `incubator` for `incubator/<name>` |

The requester is the pipeline's user. The job, [`generator/generate.py`](generator/generate.py), then:

1. checks the naming rules, that no project under the group's root has the name, and that aws-foundation has not registered its repository, before it writes anything;
2. creates the project, empty and private;
3. renders the template with Copier from this project's URL at the pipeline's commit, Copier's unsafe features trusted for that URL alone (an exact `trust` entry in Copier's settings), the clone authenticated by the job token, so that `.copier-answers.yml` records the plain URL;
4. pushes the first commit to `main` as the bot;
5. applies [`project-settings.yml`](project-settings.yml) with gitlabform, after the first push, since the settings leave `main` open to no push;
6. makes the requester a Maintainer, unless they are one already;
7. opens the registration merge request in `infra/aws-foundation` (D4): the project's ID under `ci-workload-release` in `registrations/<stack>.yaml`, and in `stacks/<stack>/main.tf` its ECR repository, the project's path under the root, in `workload_images`, and for a container workload in `scratch_projects`, the contract stage's scratch repository. A workflow has no image and registers nothing.

A rerun resumes a project the bot created and did not finish, and skips each step already done. The job's report, `out/generation/report.json`, and gitlabform's log are its artifacts.

**Its credential** is `GENERATION_TOKEN`, a bot user's personal access token, the only kind GitLab.com's Free plan offers ([B5 desk check](../../architecture/research/2026-11-17-b5-desk-check.md#gitlab-components-the-catalog-and-the-group)), set by the user as a protected, masked CI/CD variable of this project (D8). The bot needs to create projects under `workloads/` and `incubator/` and to open merge requests in `infra/aws-foundation`. Without the variable the job stops before any request.

**Who may start it:** starting a pipeline on protected `main` needs merge rights there, so in B5 a Maintainer of this project starts it; how others do is T17.

### A dry run

`--dry-run` checks and renders as the job would and prints each step it would take, the gitlabform configuration and the registration's diff, without a single write: its API client refuses every method but `GET`. `--offline` sends no request at all and takes aws-foundation's files from a checkout:

```sh
python3 generator/generate.py --dry-run --offline \
  --template mcp-server-python --name notes-mcp --team reference \
  --root <root> --templates-url <this project's URL> --vcs-ref main \
  --sdk-index-url <agent-sdk's PyPI simple URL> --aws-foundation-dir ../../infra/aws-foundation
```

## Project settings

[`project-settings.yml`](project-settings.yml) holds Free settings only, as `environments`' `gitlab/platform-projects.yml` does for the platform's projects, plus what a workload needs: protected `v*` release tags, merges only after a green pipeline, the `agentic-workload` topic and a cleanup policy for merge requests' images. `<root>` stands for the group's root. The Ultimate overlay is written at the swap to dev.

## Tests

- [`tests/test_generator.py`](tests/test_generator.py) runs the job against [a fake GitLab API](tests/fake_gitlab.py) on loopback, with the real Copier and git and [a stub of gitlabform](tests/stub_gitlabform.py): each naming refusal, a taken name, the requester's access, a rerun after a failure, the dry runs, and Copier's trust both ways.
- [`tests/test_templates.py`](tests/test_templates.py) renders each template and reference workload from the checkout with fixed answers and checks what a generated project must hold, without the SDK, and runs the job's dry run on each template; in CI, [`tests/ci_dry_run.sh`](tests/ci_dry_run.sh) runs it once more as the job does, Copier cloning this project's own URL at the pipeline's commit with the job token.
- [`tests/python.sh`](tests/python.sh), CI's `test:python`, runs the rendered Python projects' own tests as their pipelines do, `reference-mcp`'s against Postgres, and validates every `workload.yaml` and step definition with the SDK's copy of agent-sdk's spec. It reads the SDK with the job token, which agent-sdk's job-token allowlist admits.

From the repository root:

```sh
uv venv /tmp/gen && uv pip install --python /tmp/gen --require-hashes -r generator/requirements.txt
PATH=/tmp/gen/bin:$PATH python -m unittest discover -s tests
```

GitLab's CI lint API refuses the job token, so the generated pipelines are linted through it from a workstation, not in CI. Not tested here: gitlabform against GitLab, and the job against GitLab itself, which wait for the bot user (D8).
