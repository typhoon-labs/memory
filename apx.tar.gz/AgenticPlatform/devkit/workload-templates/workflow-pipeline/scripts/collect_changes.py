"""Writes the summarise-changes step's input: the subjects of the commits
since the last tag, or the last 20, as {"changes": [...]}. Standard library
only."""

import json
import subprocess
import sys
from pathlib import Path

out = Path(sys.argv[1] if len(sys.argv) > 1 else "out/step/input.json")
tag = subprocess.run(["git", "describe", "--tags", "--abbrev=0"], capture_output=True, text=True).stdout.strip()
span = [f"{tag}..HEAD"] if tag else ["-20"]
log = subprocess.run(["git", "log", "--format=%s", *span], capture_output=True, text=True, check=True).stdout
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps({"changes": [s for s in log.splitlines() if s.strip()]}, indent=2) + "\n")
print(f"{out}: {len(log.splitlines())} changes")
