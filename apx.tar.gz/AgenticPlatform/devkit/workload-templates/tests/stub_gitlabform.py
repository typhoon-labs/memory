#!/usr/bin/env python3
"""Stands in for gitlabform in the generator tests: records its arguments,
its configuration and whether a token reached it, then exits with
$STUB_GITLABFORM_EXIT."""
import json
import os
import sys

argv = sys.argv[1:]
config = open(argv[argv.index("-c") + 1]).read()
with open(os.environ["STUB_GITLABFORM_LOG"], "a") as f:
    f.write(json.dumps({"argv": argv, "config": config, "token_set": bool(os.environ.get("GITLAB_TOKEN")),
                        "url": os.environ.get("GITLAB_URL")}) + "\n")
print("gitlabform stub: applied" if os.environ.get("STUB_GITLABFORM_EXIT", "0") == "0" else "gitlabform stub: failed")
sys.exit(int(os.environ.get("STUB_GITLABFORM_EXIT", "0")))
