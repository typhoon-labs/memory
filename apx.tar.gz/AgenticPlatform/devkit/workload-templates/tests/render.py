#!/usr/bin/env python3
"""Renders every template and every reference workload into one directory,
as the generation job renders them, for CI's python job (python.sh):

    tests/render.py <out dir> --gitlab-root <root> --sdk-index-url <url>

Each goes to <out dir>/<template or reference name>/. Standard library and
PyYAML, with copier on PATH."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent / "reference"))

import apply  # noqa: E402
from test_templates import TEMPLATES, render, snapshot  # noqa: E402


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("out", type=Path)
    p.add_argument("--gitlab-root", required=True)
    p.add_argument("--sdk-index-url", required=True)
    a = p.parse_args()
    if a.out.exists():
        shutil.rmtree(a.out)
    a.out.mkdir(parents=True)
    src = snapshot(a.out / ".src")
    common = {"gitlab_root": a.gitlab_root}
    for template, name in TEMPLATES.items():
        extra = {"sdk_index_url": a.sdk_index_url} if template in ("mcp-server-python", "adk-agent") else {}
        render(src, a.out / template, template, name, **common, **extra)
        print(f"{template}: {name}")
    for ref in ("reference-mcp", "reference-agent", "reference-notes-agent"):
        answers = yaml.safe_load((HERE.parent / "reference" / ref / "answers.yml").read_text())
        extra = {"sdk_index_url": a.sdk_index_url} if answers["template"] in ("mcp-server-python", "adk-agent") else {}
        render(src, a.out / ref, answers.pop("template"), answers.pop("name"), **common, **extra,
               **{k: v for k, v in answers.items()})
        apply.overlay(ref, a.out / ref)
        print(f"{ref}: rendered and overlaid")
    shutil.rmtree(a.out / ".src")
    return 0


if __name__ == "__main__":
    sys.exit(main())
