#!/usr/bin/env python3
"""Validates each workload.yaml and step definition under the given
directories against agent-sdk's spec, as the SDK carries it
(agentic_sdk._spec): run with a rendered Python project's interpreter.

    python tests/validate.py <dir>...
"""

import sys
from pathlib import Path

import yaml
from agentic_sdk import contract

problems = 0
for root in map(Path, sys.argv[1:]):
    for f in sorted([*root.rglob("workload.yaml"), *root.rglob("*.step.yaml")]):
        if ".venv" in f.parts:
            continue
        schema = "step/step.schema.json" if f.name.endswith(".step.yaml") else "schemas/workload.schema.json"
        error = contract.first_error(schema, yaml.safe_load(f.read_text()))
        print(f"{f}: {'valid' if error is None else 'INVALID: ' + str(error)}")
        problems += error is not None
sys.exit(1 if problems else 0)
