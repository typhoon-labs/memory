"""The generation job's logic against a fake GitLab API (fake_gitlab.py):
naming refusals, uniqueness, the project, the first commit, the settings
(gitlabform stubbed), the requester, the registration merge request, a
rerun after a failure, the dry run, and Copier's trust. Run from the
repository root: python -m unittest discover -s tests -t ."""

from __future__ import annotations

import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
sys.path.insert(0, str(REPO / "generator"))
sys.path.insert(0, str(HERE))

import generate  # noqa: E402
from fake_gitlab import TOKEN, FakeGitLab  # noqa: E402

JOB_TOKEN = "fake-job-token-fedcba9876543210"
ROOT = "acme/agentic"
REGISTRATIONS = """\
# Registrations for the local stack.
ci-aws-foundation:
  - id: 1
    path: infra/aws-foundation
# B5: every registered workload project's release.
ci-workload-release: []
"""
MAIN_TF = """\
locals {
  workload_images = []

  scratch_projects = ["devkit/ci-components"]
}
"""


def git(*args: str, cwd: Path | None = None) -> str:
    env = {**os.environ, "GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@example.com",
           "GIT_COMMITTER_NAME": "t", "GIT_COMMITTER_EMAIL": "t@example.com"}
    return subprocess.run(["git", *args], cwd=cwd, env=env, check=True, capture_output=True, text=True).stdout


def uncommented(yaml_text: str) -> str:
    """A YAML file without its comment lines, whose prose may name <root>."""
    return "\n".join(line for line in yaml_text.splitlines() if not line.lstrip().startswith("#"))


def template_repo(tmp: Path, source: Path = HERE / "fixtures" / "template") -> Path:
    """The template as a Git repository, as Copier clones it."""
    repo = tmp / "workload-templates.git"
    shutil.copytree(source, repo)
    git("init", "-q", "-b", "main", cwd=repo)
    git("add", "-A", cwd=repo)
    git("commit", "-qm", "templates", cwd=repo)
    return repo


class GeneratorTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="gen-test-"))
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        self.fake = FakeGitLab(self.tmp, ROOT)
        self.api_url = self.fake.serve()
        self.addCleanup(self.fake.stop)
        self.fake.files[(self.fake.af["id"], "main", "registrations/local.yaml")] = REGISTRATIONS
        self.fake.files[(self.fake.af["id"], "main", "stacks/local/main.tf")] = MAIN_TF
        self.templates = template_repo(self.tmp)
        self.gf_log = self.tmp / "gitlabform.jsonl"
        os.environ["STUB_GITLABFORM_LOG"] = str(self.gf_log)
        os.environ["STUB_GITLABFORM_EXIT"] = "0"

    def run_job(self, *extra: str, template="mcp-server-python", name="notes-mcp", team="reference",
                placement="team", token=TOKEN, env=None):
        environ = {"GENERATION_TOKEN": token, "GITLAB_USER_ID": "42", "GITLAB_USER_LOGIN": "alice",
                   "CI_JOB_TOKEN": JOB_TOKEN, "CI_PIPELINE_URL": "https://gitlab.example/p/1", **(env or {})}
        old = {k: os.environ.get(k) for k in environ}
        os.environ.update(environ)
        out, err = io.StringIO(), io.StringIO()
        try:
            with redirect_stdout(out), redirect_stderr(err):
                code = generate.main([
                    "--template", template, "--name", name, "--team", team, "--placement", placement,
                    "--root", ROOT, "--templates-url", str(self.templates), "--vcs-ref", "main",
                    "--api-url", self.api_url, "--gitlabform", f"{sys.executable} {HERE / 'stub_gitlabform.py'}",
                    "--out", str(self.tmp / "out"), *extra])
        finally:
            for k, v in old.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
        self.assertNotIn(TOKEN, out.getvalue() + err.getvalue())
        self.assertNotIn(JOB_TOKEN, out.getvalue() + err.getvalue())
        return code, out.getvalue(), err.getvalue()

    def project(self, path=f"{ROOT}/workloads/reference/notes-mcp"):
        return self.fake.project(path)

    def pushed(self, p) -> Path:
        work = self.tmp / f"clone-{p['id']}"
        if not work.exists():
            git("clone", "-q", p["http_url_to_repo"], str(work))
        return work

    # --- the whole job ---------------------------------------------------
    def test_generates_a_container_workload(self):
        code, out, err = self.run_job()
        self.assertEqual(code, 0, err)
        p = self.project()
        self.assertIsNotNone(p)
        self.assertEqual(p["creator_id"], 7)
        work = self.pushed(p)
        answers = (work / ".copier-answers.yml").read_text()
        self.assertIn(f"_src_path: {self.templates}", answers)
        self.assertIn("name: notes-mcp", answers)
        self.assertIn(f"sdk_index_url: {self.api_url}/projects/", answers)
        # The trusted task ran: Copier took the settings' trust for this URL.
        self.assertEqual((work / "task-ran.txt").read_text().strip(), "rendered-by-a-trusted-task")
        log = git("log", "--format=%an <%ae>%n%B", cwd=work)
        self.assertIn("Workload Bot <bot@example.com>", log)
        self.assertIn("feat: generate notes-mcp from mcp-server-python", log)
        for line in log.splitlines():
            self.assertLessEqual(len(line), 72)
        self.assertNotRegex(log, r"(?im)^(co-authored-by|signed-off-by|generated)")
        history = git("log", "-p", "--all", cwd=work)
        self.assertNotIn(TOKEN, history)
        self.assertNotIn(JOB_TOKEN, history)
        # The settings, rendered for this root, applied to this project alone.
        gf = [json.loads(x) for x in self.gf_log.read_text().splitlines()]
        self.assertEqual(len(gf), 1)
        self.assertEqual(gf[0]["argv"][-1], f"{ROOT}/workloads/reference/notes-mcp")
        self.assertIn(f'"{ROOT}/workloads/*"', gf[0]["config"])
        self.assertNotIn("<root>", uncommented(gf[0]["config"]))
        self.assertTrue(gf[0]["token_set"])
        # The requester, a Maintainer.
        self.assertEqual(self.fake.direct[(p["id"], 42)], 40)
        # The registration: one commit on a branch, one merge request.
        self.assertEqual(len(self.fake.mrs), 1)
        mr = self.fake.mrs[0]
        self.assertEqual(mr["source_branch"], "feat/register-workloads-reference-notes-mcp")
        self.assertEqual(mr["title"], "feat(registrations): register workloads/reference/notes-mcp")
        commit = self.fake.commits_api[0]
        self.assertTrue(commit["commit_message"].rstrip().endswith("Refs: D4"))
        for line in commit["commit_message"].splitlines():
            self.assertLessEqual(len(line), 72)
        files = {a["file_path"]: a["content"] for a in commit["actions"]}
        self.assertIn(f"  - id: {p['id']}\n    path: workloads/reference/notes-mcp\n",
                      files["registrations/local.yaml"])
        self.assertIn('  workload_images = [\n    "workloads/reference/notes-mcp",\n  ]', files["stacks/local/main.tf"])
        self.assertIn('"devkit/ci-components",\n    "workloads/reference/notes-mcp",', files["stacks/local/main.tf"])
        report = json.loads((self.tmp / "out" / "report.json").read_text())
        self.assertEqual(report["registration"], mr["web_url"])

    def test_kagent_agent_registers_no_scratch_repository(self):
        code, _, err = self.run_job(template="kagent-agent", name="notes-agent")
        self.assertEqual(code, 0, err)
        files = {a["file_path"]: a["content"] for a in self.fake.commits_api[0]["actions"]}
        self.assertIn('"workloads/reference/notes-agent"', files["stacks/local/main.tf"])
        self.assertIn('scratch_projects = ["devkit/ci-components"]', files["stacks/local/main.tf"])
        answers = (self.pushed(self.project(f"{ROOT}/workloads/reference/notes-agent")) / ".copier-answers.yml").read_text()
        self.assertNotIn("sdk_index_url", answers.replace("sdk_index_url: ''", ""))

    def test_workflow_opens_no_registration(self):
        code, out, err = self.run_job(template="workflow-pipeline", name="release-notes-workflow")
        self.assertEqual(code, 0, err)
        self.assertEqual(self.fake.mrs, [])
        self.assertIn("no registration: a workflow has no image", out)

    def test_shared_and_incubator_paths(self):
        self.assertEqual(self.run_job(placement="shared")[0], 0)
        self.assertIsNotNone(self.project(f"{ROOT}/workloads/shared/notes-mcp"))
        self.assertIn('"workloads/shared/notes-mcp"', self.fake.commits_api[0]["actions"][1]["content"])
        self.assertEqual(self.run_job(name="ideas-mcp", placement="incubator")[0], 0)
        self.assertIsNotNone(self.project(f"{ROOT}/incubator/ideas-mcp"))

    def test_settings_admit_the_platform_readers_alone(self):
        # Every placement's job token admits infra/environments' catalog
        # build and infra/conformance, by path under this root, and enforce
        # drops anything else from the allowlist.
        import yaml  # gitlabform's and Copier's dependency, in the job's venv
        self.assertEqual(self.run_job(name="ideas-mcp", placement="incubator")[0], 0)
        gf = [json.loads(x) for x in self.gf_log.read_text().splitlines()]
        self.assertEqual(gf[0]["argv"][-1], f"{ROOT}/incubator/ideas-mcp")
        self.assertNotIn("<root>", uncommented(gf[0]["config"]))
        settings = yaml.safe_load(gf[0]["config"])["projects_and_groups"]
        for placement in (f"{ROOT}/workloads/*", f"{ROOT}/incubator/*"):
            scope = settings[placement]["job_token_scope"]
            self.assertIs(scope["limit_access_to_this_project"], True)
            self.assertEqual(scope["allowlist"], {
                "enforce": True,
                "projects": [f"{ROOT}/infra/environments", f"{ROOT}/infra/conformance"]})

    # --- refusals --------------------------------------------------------
    def test_naming_refusals_send_nothing(self):
        cases = [
            ("mcp-server-python", "Notes-mcp", "reference", "team", "lowercase kebab-case"),
            ("mcp-server-python", "notes--mcp", "reference", "team", "lowercase kebab-case"),
            ("mcp-server-python", "notes-agent", "reference", "team", "ends in -mcp"),
            ("mcp-server-python", "mcp", "reference", "team", "ends in -mcp"),
            ("adk-agent", "notes-adk-agent", "reference", "team", "framework or runtime (adk)"),
            ("kagent-agent", "kagent-agent", "reference", "team", "framework or runtime (kagent)"),
            ("kagent-agent", "agent", "reference", "team", "ends in -agent"),
            ("kagent-agent", "notes-kagent-agent", "reference", "team", "framework or runtime (kagent)"),
            ("mcp-server-python", "a" * 60 + "-mcp", "reference", "team", "at most 63"),
            ("go-agent", "notes-agent", "reference", "team", "unknown template"),
            ("mcp-server-python", "notes-mcp", "", "incubator", "no team given"),
            ("mcp-server-python", "notes-mcp", "Ref", "team", "not a team's slug"),
            ("mcp-server-python", "notes-mcp", "reference", "elsewhere", "unknown placement"),
        ]
        for template, name, team, placement, why in cases:
            with self.subTest(name=name, template=template):
                code, _, err = self.run_job(template=template, name=name, team=team, placement=placement)
                self.assertEqual(code, 3, err)
                self.assertIn(why, err)
        self.assertEqual(self.fake.calls, [], "a naming refusal reads nothing")

    def test_taken_names(self):
        self.fake.add_project(f"{ROOT}/workloads/reference/notes-mcp", creator=99, empty=False)
        code, _, err = self.run_job()
        self.assertEqual((code, "is taken"), (3, err[err.index("is taken"):][:8]))
        # The same name elsewhere under the root.
        self.fake.add_group(f"{ROOT}/workloads/payments")
        code, _, err = self.run_job(team="payments")
        self.assertEqual(code, 3)
        self.assertIn("unique across the organization", err)
        # An unknown team.
        code, _, err = self.run_job(name="other-mcp", team="nobody")
        self.assertEqual(code, 3)
        self.assertIn("has no group", err)
        self.assertEqual(self.fake.writes(), [])

    def test_name_registered_already(self):
        self.fake.files[(self.fake.af["id"], "main", "registrations/local.yaml")] = REGISTRATIONS.replace(
            "ci-workload-release: []", "ci-workload-release:\n  - id: 5\n    path: workloads/reference/notes-mcp")
        code, _, err = self.run_job()
        self.assertEqual(code, 3)
        self.assertIn("registered already", err)
        self.assertEqual(self.fake.writes(), [], "refused before any write")
        self.assertIsNone(self.project())

    def test_rerun_after_the_registration_merged(self):
        self.assertEqual(self.run_job()[0], 0)
        p = self.project()
        # The registration merges: main holds the project, the MR is merged.
        merged = {a["file_path"]: a["content"] for a in self.fake.commits_api[0]["actions"]}
        for path, content in merged.items():
            self.fake.files[(self.fake.af["id"], "main", path)] = content
        self.fake.mrs[0]["state"] = "merged"
        # As if the job had stopped before its last step.
        p["description"] = f"notes-mcp {generate.PENDING.format(42)}"
        before = len(self.fake.writes())
        code, out, err = self.run_job()
        self.assertEqual(code, 0, err)
        self.assertIn("registered already: the registration merge request has merged", out)
        self.assertEqual(len(self.fake.mrs), 1)
        self.assertEqual(len(self.fake.commits_api), 1)
        self.assertEqual([w for w in self.fake.writes()[before:] if "aws-foundation" in w[1] or "/merge_requests" in w[1]], [])
        self.assertEqual(self.project()["id"], p["id"])

    def test_another_requester_cannot_take_over(self):
        # alice's generation stops halfway: the project is hers to resume.
        os.environ["STUB_GITLABFORM_EXIT"] = "2"
        self.assertEqual(self.run_job()[0], 1)
        os.environ["STUB_GITLABFORM_EXIT"] = "0"
        mallory = {"GITLAB_USER_ID": "43", "GITLAB_USER_LOGIN": "mallory"}
        before = len(self.fake.writes())
        code, _, err = self.run_job(env=mallory)
        self.assertEqual(code, 3, err)
        self.assertIn("is taken", err)
        self.assertEqual(len(self.fake.writes()), before, "nothing written for another requester")
        self.assertNotIn((self.project()["id"], 43), self.fake.direct)
        # alice finishes it; then it is taken for everyone, her included.
        self.assertEqual(self.run_job()[0], 0)
        for env in (mallory, None):
            code, _, err = self.run_job(env=env)
            self.assertEqual(code, 3, err)
        self.assertNotIn((self.project()["id"], 43), self.fake.direct)

    def test_a_long_name_keeps_the_subjects_short(self):
        name = "a" * 59 + "-mcp"
        self.assertEqual(len(name), 63)
        code, _, err = self.run_job(name=name)
        self.assertEqual(code, 0, err)
        log = git("log", "--format=%B", cwd=self.pushed(self.project(f"{ROOT}/workloads/reference/{name}")))
        for line in log.splitlines() + self.fake.commits_api[0]["commit_message"].splitlines() + [self.fake.mrs[0]["title"]]:
            self.assertLessEqual(len(line), 72, line)

    def test_missing_token_is_never_substituted(self):
        code, _, err = self.run_job(token="")
        self.assertEqual(code, 1)
        self.assertIn("GENERATION_TOKEN is not set", err)
        self.assertEqual(self.fake.calls, [])

    # --- the requester ---------------------------------------------------
    def test_requester_with_inherited_access(self):
        self.fake.inherited[(f"{ROOT}/workloads", 42)] = 50
        code, out, err = self.run_job()
        self.assertEqual(code, 0, err)
        self.assertNotIn((self.project()["id"], 42), self.fake.direct)
        self.assertIn("the requester is a Maintainer already", out)

    def test_requester_raised_from_developer(self):
        self.fake.inherited[(f"{ROOT}/workloads", 42)] = 30
        code, _, err = self.run_job()
        self.assertEqual(code, 0, err)
        self.assertEqual(self.fake.direct[(self.project()["id"], 42)], 40)

    # --- reruns ------------------------------------------------------------
    def test_rerun_after_a_failure_resumes(self):
        os.environ["STUB_GITLABFORM_EXIT"] = "2"
        code, _, err = self.run_job()
        self.assertEqual(code, 1)
        self.assertIn("gitlabform exited 2", err)
        p = self.project()
        first = git("ls-remote", p["http_url_to_repo"])
        self.assertEqual(self.fake.mrs, [])
        os.environ["STUB_GITLABFORM_EXIT"] = "0"
        code, out, err = self.run_job()
        self.assertEqual(code, 0, err)
        self.assertIn("resuming an unfinished project", out)
        self.assertIn("the first commit is there already", out)
        self.assertEqual(git("ls-remote", p["http_url_to_repo"]), first)
        self.assertEqual(len([x for x in self.fake.projects.values() if x["path"] == "notes-mcp"]), 1)
        self.assertEqual(len(self.fake.mrs), 1)
        self.assertIn("finished: the project's description no longer marks it pending", out)
        self.assertNotIn("pending", self.project()["description"])
        # A third run finds it finished: taken, and nothing is written.
        before = len(self.fake.writes())
        code, out, err = self.run_job()
        self.assertEqual(code, 3, err)
        self.assertIn("is taken", err)
        self.assertEqual(len(self.fake.writes()), before)
        self.assertEqual(len(self.fake.mrs), 1)
        self.assertEqual(len(self.fake.commits_api), 1)

    def test_rerun_after_create_before_push(self):
        p = self.fake.add_project(f"{ROOT}/workloads/reference/notes-mcp", creator=7,
                                  description=f"notes-mcp {generate.PENDING.format(42)}")
        code, out, err = self.run_job()
        self.assertEqual(code, 0, err)
        self.assertIn("resuming an unfinished project", out)
        self.assertTrue((self.pushed(p) / "workload.yaml").exists())

    # --- the dry run -------------------------------------------------------
    def test_dry_run_sends_no_write(self):
        code, out, err = self.run_job("--dry-run")
        self.assertEqual(code, 0, err)
        self.assertEqual(self.fake.writes(), [])
        self.assertIsNone(self.project())
        for what in ("would create the project", "would push the first commit", "would apply project-settings.yml",
                     "would make the requester a Maintainer", "would open the registration merge request",
                     "+  - id: <new project ID>", '+    "workloads/reference/notes-mcp",'):
            self.assertIn(what, out)
        rendered = self.tmp / "out" / "rendered" / "notes-mcp" / "workload.yaml"
        self.assertEqual(rendered.read_text(), "name: notes-mcp\nowner: reference\n")

    def test_dry_run_api_refuses_writes(self):
        api = generate.Api(self.api_url, TOKEN, read_only=True)
        with self.assertRaises(RuntimeError):
            api.post("projects", {"name": "x"})
        self.assertEqual(self.fake.calls, [])

    def test_offline_dry_run(self):
        af = self.tmp / "af"
        (af / "registrations").mkdir(parents=True)
        (af / "stacks" / "local").mkdir(parents=True)
        (af / "registrations" / "local.yaml").write_text(REGISTRATIONS)
        (af / "stacks" / "local" / "main.tf").write_text(MAIN_TF)
        code, out, err = self.run_job("--dry-run", "--offline", "--aws-foundation-dir", str(af),
                                      "--sdk-index-url", "https://pypi.example/simple", token="")
        self.assertEqual(code, 0, err)
        self.assertEqual(self.fake.calls, [])
        self.assertIn("not checked: whether the name is free (offline)", out)
        self.assertIn("would open the registration merge request", out)

    # --- Copier's trust ------------------------------------------------------
    def test_copier_refuses_the_task_from_an_untrusted_source(self):
        cfg = generate.Config(template="mcp-server-python", name="notes-mcp", team="reference", placement="team",
                              root=ROOT, templates_url=str(self.templates), vcs_ref="main", api_url=self.api_url,
                              requester_id=42, requester_login="alice", pipeline_url="")
        job = generate.Job(cfg, None, log=lambda *_: None)
        job.render(self.tmp / "trusted")
        self.assertTrue((self.tmp / "trusted" / "task-ran.txt").exists())
        other = template_repo(self.tmp / "other")
        cfg.templates_url = str(other)
        settings_trusting_the_first = {"trust": [str(self.templates)]}
        job.answers = lambda: {"template": "mcp-server-python", "name": "notes-mcp", "team": "reference",
                               "placement": "team", "gitlab_root": ROOT}
        # Render from another source with the settings that trust the first
        # one alone: Copier stops with its unsafe-template code, 4.
        settings = self.tmp / "settings.yml"
        settings.write_text(json.dumps(settings_trusting_the_first))
        r = subprocess.run(["copier", "copy", "--defaults", "--quiet", "--data", "template=x", "--data", "name=y",
                            "--data", "team=z", "--data", f"gitlab_root={ROOT}", str(other), str(self.tmp / "untrusted")],
                           env={**os.environ, "COPIER_SETTINGS_PATH": str(settings)}, capture_output=True, text=True)
        self.assertEqual(r.returncode, 4, r.stderr)
        self.assertFalse((self.tmp / "untrusted" / "task-ran.txt").exists())


class RegistrationEditTest(unittest.TestCase):
    def test_lists(self):
        tf = add = generate.add_to_hcl_list
        out = add(MAIN_TF, "workload_images", "workloads/a/x-mcp")
        out = add(out, "workload_images", "workloads/a/y-mcp")
        self.assertIn('workload_images = [\n    "workloads/a/x-mcp",\n    "workloads/a/y-mcp",\n  ]', out)
        self.assertEqual(add(out, "workload_images", "workloads/a/y-mcp"), out)
        with self.assertRaises(generate.Refused):
            tf("locals {\n  x = concat([], local.y)\n}\n", "workload_images", "a")

    def test_registrations(self):
        out = generate.add_registration(REGISTRATIONS, "ci-workload-release", 11, "workloads/a/x-mcp")
        out = generate.add_registration(out, "ci-workload-release", 12, "workloads/a/y-mcp")
        self.assertTrue(out.endswith("ci-workload-release:\n  - id: 11\n    path: workloads/a/x-mcp\n"
                                     "  - id: 12\n    path: workloads/a/y-mcp\n"))
        self.assertEqual(generate.add_registration(out, "ci-workload-release", 12, "workloads/a/y-mcp"), out)
        try:
            import yaml
        except ImportError:
            return
        self.assertEqual([e["id"] for e in yaml.safe_load(out)["ci-workload-release"]], [11, 12])


if __name__ == "__main__":
    unittest.main()
