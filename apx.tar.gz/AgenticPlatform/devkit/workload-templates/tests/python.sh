#!/bin/sh
# python.sh <out dir>: renders every template and reference workload
# (render.py), runs each Python one's own tests with uv as its pipeline
# does, against Postgres for reference-mcp when AGENTIC_TEST_DATABASE_URL
# is set, then validates every rendered workload.yaml and step definition
# with the SDK's copy of agent-sdk's spec. uv reads the SDK from agent-sdk's
# registry with the job token (UV_INDEX_AGENTIC_USERNAME and _PASSWORD).
set -eu
out=$1
python3 tests/render.py "$out" --gitlab-root "$GITLAB_ROOT" --sdk-index-url "$SDK_INDEX_URL"
for p in mcp-server-python adk-agent reference-mcp reference-agent; do
  echo "== $p"
  (cd "$out/$p" && uv sync --locked --quiet && uv run --locked pytest -q -rs)
done
"$out/mcp-server-python/.venv/bin/python" tests/validate.py "$out"
