"""The templates, rendered with Copier from this checkout with fixed
answers, and the reference workloads' overlays on top: what a generated
project must hold, checked without the SDK (the generated projects' own
tests run in CI's python job, tests/python.sh). Run from the repository
root: python -m unittest discover -s tests."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import yaml

HERE = Path(__file__).resolve().parent
REPO = HERE.parent
sys.path.insert(0, str(REPO / "reference"))
sys.path.insert(0, str(HERE))

ROOT = "acme/agentic"
INDEX = "https://gitlab.example/api/v4/projects/1/packages/pypi/simple"
PINS = yaml.safe_load((REPO / "copier.yml").read_text())["pins"]["default"]
TEMPLATES = {
    "mcp-server-python": "notes-mcp",
    "adk-agent": "notes-agent",
    "kagent-agent": "notes-agent",
    "workflow-pipeline": "release-notes-workflow",
}
PYTHON = {"mcp-server-python", "adk-agent"}


def snapshot(tmp: Path) -> Path:
    """This checkout, committed as it stands, as Copier clones a template."""
    repo = tmp / "templates"
    shutil.copytree(REPO, repo, ignore=shutil.ignore_patterns(".git", "out", "__pycache__", ".venv"))
    env = {"GIT_AUTHOR_NAME": "t", "GIT_AUTHOR_EMAIL": "t@example.com", "GIT_COMMITTER_NAME": "t",
           "GIT_COMMITTER_EMAIL": "t@example.com", "PATH": "/usr/local/bin:/usr/bin:/bin"}
    for cmd in (["init", "-q", "-b", "main"], ["add", "-A"], ["commit", "-qm", "snapshot"]):
        subprocess.run(["git", "-C", str(repo), *cmd], check=True, env=env)
    return repo


def render(src: Path, dest: Path, template: str, name: str, **extra: str) -> Path:
    data = {"template": template, "name": name, "team": "reference", "gitlab_root": ROOT}
    data.update(extra)
    if template in PYTHON:
        data.setdefault("sdk_index_url", INDEX)
    args = [x for k, v in data.items() for x in ("--data", f"{k}={v}")]
    subprocess.run(["copier", "copy", "--quiet", "--defaults", "--vcs-ref", "HEAD", *args, str(src), str(dest)],
                   check=True, capture_output=True, text=True)
    return dest


class TemplatesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = Path(tempfile.mkdtemp(prefix="templates-test-"))
        cls.src = snapshot(cls.tmp)
        cls.out = {t: render(cls.src, cls.tmp / t / n, t, n) for t, n in TEMPLATES.items()}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def files(self, template):
        return [p for p in self.out[template].rglob("*") if p.is_file()]

    def test_nothing_left_unrendered(self):
        for t in TEMPLATES:
            for f in self.files(t):
                with self.subTest(file=str(f.relative_to(self.tmp))):
                    self.assertFalse(f.name.endswith(".jinja"))
                    self.assertNotRegex(f.read_text(), r"\{\{|\{%|\{#")

    def test_required_files(self):
        common = ["workload.yaml", "AGENTS.md", "README.md", ".copier-answers.yml", ".gitlab-ci.yml", "evals/README.md"]
        extra = {
            "mcp-server-python": ["pyproject.toml", "uv.lock", "Dockerfile", "src/notes_mcp/app.py",
                                  "src/notes_mcp/tools.py", "tests/test_server.py", "deploy/app-base.yaml",
                                  "deploy/agent-integration.yaml", "deploy/access.yaml", ".agents/README.md"],
            "adk-agent": ["pyproject.toml", "uv.lock", "Dockerfile", "src/notes_agent/agent.py",
                          ".agents/prompts/system.md", "tests/test_agent.py", "deploy/app-base.yaml",
                          "deploy/agent-integration.yaml", "deploy/access.yaml"],
            "kagent-agent": ["config/agent.yaml", ".agents/prompts/system.md", ".agents/skills/answer-style/SKILL.md",
                             "deploy/agent-integration.yaml", "deploy/access.yaml"],
            "workflow-pipeline": ["steps/summarise-changes.step.yaml", "scripts/collect_changes.py"],
        }
        for t, files in extra.items():
            for f in common + files:
                with self.subTest(template=t, file=f):
                    self.assertTrue((self.out[t] / f).is_file())

    def test_answers_name_the_source_and_never_a_credential(self):
        for t, n in TEMPLATES.items():
            answers = yaml.safe_load((self.out[t] / ".copier-answers.yml").read_text())
            with self.subTest(template=t):
                self.assertEqual(answers["_src_path"], str(self.src))
                self.assertIn("_commit", answers)
                self.assertEqual((answers["template"], answers["name"], answers["team"]), (t, n, "reference"))
                self.assertNotIn("pins", answers)
                self.assertNotRegex(json.dumps(answers), r"(?i)token|password|glpat-")

    def test_workload_files(self):
        kinds = {"mcp-server-python": ("mcp-server", "container"), "adk-agent": ("agent", "container"),
                 "kagent-agent": ("agent", "kagent"), "workflow-pipeline": ("workflow", "pipeline")}
        for t, n in TEMPLATES.items():
            text = (self.out[t] / "workload.yaml").read_text()
            w = yaml.safe_load(text)
            with self.subTest(template=t):
                self.assertEqual((w["name"], w["owner"], w["support"]), (n, "reference", "experimental"))
                self.assertEqual((w["kind"], w["runtime"]), kinds[t])
                # Dates are written quoted (YAML 1.1 reads an unquoted one as a timestamp).
                self.assertNotRegex(text, r":\s*\d{4}-\d{2}-\d{2}\s*$")

    def test_pipelines(self):
        for t in TEMPLATES:
            ci = yaml.safe_load((self.out[t] / ".gitlab-ci.yml").read_text())
            with self.subTest(template=t):
                ifs = [r["if"] for r in ci["workflow"]["rules"]]
                self.assertEqual(ifs, ['$CI_PIPELINE_SOURCE == "merge_request_event"', "$CI_COMMIT_TAG",
                                       "$CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH"])
                components = [i["component"] for i in ci["include"]]
                self.assertEqual(len(components), 1)
                kind = "step" if t == "workflow-pipeline" else "workload"
                self.assertEqual(components[0],
                                 f"$CI_SERVER_FQDN/{ROOT}/devkit/ci-components/{kind}@{PINS['ci_components']}")
                inputs = ci["include"][0]["inputs"]
                if kind == "workload":
                    self.assertEqual(inputs["repository"], f"workloads/reference/{TEMPLATES[t]}")
                if t in PYTHON:
                    # The index for build:wheels alone; uv sync takes pyproject.toml's.
                    self.assertNotIn("UV_INDEX", ci["variables"])
                    self.assertEqual(ci["build:wheels"]["variables"]["UV_INDEX"], "agentic=$AGENTIC_PYPI_INDEX_URL")
                    self.assertEqual(ci["variables"]["UV_INDEX_AGENTIC_PASSWORD"], "$CI_JOB_TOKEN")
                for job in (v for k, v in ci.items() if isinstance(v, dict) and "script" in v and k != "build:wheels"):
                    self.assertEqual(job["tags"], ["local-build"])

    def test_placements_name_the_repository(self):
        for placement, repo in (("shared", "workloads/shared/notes-mcp"), ("incubator", "incubator/notes-mcp")):
            out = render(self.src, self.tmp / placement / "notes-mcp", "mcp-server-python", "notes-mcp", placement=placement)
            ci = yaml.safe_load((out / ".gitlab-ci.yml").read_text())
            self.assertEqual(ci["include"][0]["inputs"]["repository"], repo)

    def test_python_images_build_without_network(self):
        for t in PYTHON:
            dockerfile = (self.out[t] / "Dockerfile").read_text()
            with self.subTest(template=t):
                self.assertNotRegex(dockerfile, r"(?m)^\s*RUN\b")
                self.assertRegex(dockerfile, r"(?m)^FROM \S+@sha256:[0-9a-f]{64}$")
                self.assertIn("COPY wheels/${TARGETARCH}/ /opt/app/site/", dockerfile)
                self.assertNotRegex(dockerfile, r"(?m)^COPY .*workload\.yaml")

    def test_python_locks_match_their_projects(self):
        for t, n in TEMPLATES.items():
            if t not in PYTHON:
                continue
            lock, pyproject = (self.out[t] / "uv.lock").read_text(), (self.out[t] / "pyproject.toml").read_text()
            with self.subTest(template=t):
                self.assertIn(f'name = "{n}"', lock)
                self.assertIn(f'source = {{ registry = "{INDEX}" }}', lock)
                self.assertNotIn("127.0.0.1", lock)
                self.assertIn(f'url = "{INDEX}"', pyproject)
                sdk = re.search(r'name = "agentic-agent-sdk"\nversion = "([^"]+)"', lock).group(1)
                self.assertEqual(sdk, PINS["agentic_agent_sdk"])
                for wheel in re.findall(r'url = "([^"]*agentic_agent_sdk[^"]*\.whl)"', lock):
                    self.assertTrue(wheel.startswith(INDEX.removesuffix("/simple") + "/files/"), wheel)

    def test_kagent_definition(self):
        d = yaml.safe_load((self.out["kagent-agent"] / "config/agent.yaml").read_text())
        self.assertEqual((d["apiVersion"], d["kind"]), ("api.kagent.dev/v1alpha3", "AgentTemplate"))
        self.assertEqual(d["spec"]["modelConfig"]["name"], "notes-agent")
        self.assertNotIn("systemPrompt", d["spec"])

    def test_step_definition(self):
        s = yaml.safe_load((self.out["workflow-pipeline"] / "steps/summarise-changes.step.yaml").read_text())
        w = yaml.safe_load((self.out["workflow-pipeline"] / "workload.yaml").read_text())
        self.assertEqual(s["model"], "fast-default")
        for k, v in s["limits"].items():
            self.assertLessEqual(v, w["limits"][k])

    def test_naming_rules(self):
        for t, bad in (("mcp-server-python", "notes-agent"), ("adk-agent", "notes-adk-agent"),
                       ("kagent-agent", "Notes-agent"), ("workflow-pipeline", "release-notes")):
            with self.subTest(template=t, name=bad), self.assertRaises(subprocess.CalledProcessError):
                render(self.src, self.tmp / "bad" / bad, t, bad)


class DryRunTest(unittest.TestCase):
    """The generation job's dry run on each real template: offline, it checks
    the name, renders from this checkout and prints what it would do."""

    def test_each_template(self):
        import io
        from contextlib import redirect_stdout

        sys.path.insert(0, str(REPO / "generator"))
        import generate
        from test_generator import MAIN_TF, REGISTRATIONS

        tmp = Path(tempfile.mkdtemp(prefix="dry-run-test-"))
        self.addCleanup(shutil.rmtree, tmp, ignore_errors=True)
        src = snapshot(tmp)
        af = tmp / "aws-foundation"
        (af / "registrations").mkdir(parents=True)
        (af / "stacks" / "local").mkdir(parents=True)
        (af / "registrations" / "local.yaml").write_text(REGISTRATIONS)
        (af / "stacks" / "local" / "main.tf").write_text(MAIN_TF)
        for template, name in TEMPLATES.items():
            out = io.StringIO()
            with self.subTest(template=template), redirect_stdout(out):
                code = generate.main(["--dry-run", "--offline", "--template", template, "--name", name,
                                      "--team", "reference", "--root", ROOT, "--templates-url", str(src),
                                      "--vcs-ref", "HEAD", "--api-url", "https://gitlab.example/api/v4",
                                      "--aws-foundation-dir", str(af), "--out", str(tmp / "out" / template)])
            self.assertEqual(code, 0, out.getvalue())
            rendered = tmp / "out" / template / "rendered" / name
            self.assertTrue((rendered / "workload.yaml").is_file())
            text = out.getvalue()
            if template == "workflow-pipeline":
                self.assertIn("no registration: a workflow has no image", text)
            else:
                self.assertIn(f'+    "workloads/reference/{name}",', text)
            if template in PYTHON:
                answers = yaml.safe_load((rendered / ".copier-answers.yml").read_text())
                self.assertEqual(answers["sdk_index_url"],
                                 "https://gitlab.example/api/v4/projects/acme%2Fagentic%2Fdevkit%2Fagent-sdk/packages/pypi/simple")


class ReferenceTest(unittest.TestCase):
    """Each reference workload: its template, then its own files."""

    def test_overlays_apply(self):
        import apply

        tmp = Path(tempfile.mkdtemp(prefix="reference-test-"))
        self.addCleanup(shutil.rmtree, tmp, ignore_errors=True)
        src = snapshot(tmp)
        for name in ("reference-mcp", "reference-agent", "reference-notes-agent"):
            answers = yaml.safe_load((REPO / "reference" / name / "answers.yml").read_text())
            with self.subTest(reference=name):
                dest = render(src, tmp / name, answers.pop("template"), answers.pop("name"),
                              **{k: v for k, v in answers.items() if k != "placement"})
                apply.overlay(name, dest)
                w = yaml.safe_load((dest / "workload.yaml").read_text())
                self.assertEqual((w["name"], w["owner"]), (name, "reference"))
                ci = yaml.safe_load((dest / ".gitlab-ci.yml").read_text())
                self.assertEqual(ci["include"][0]["inputs"]["repository"], f"workloads/reference/{name}")
                if name == "reference-notes-agent":
                    self.assertFalse((dest / ".agents/skills/answer-style").exists())
                    self.assertTrue((dest / ".agents/skills/notes-style/SKILL.md").exists())
                    listing = yaml.safe_load((dest / "config/tools/reference-mcp.yaml").read_text())
                    mcp = yaml.safe_load((REPO / "reference/reference-mcp/files/workload.yaml").read_text())
                    self.assertEqual(listing["tools"], mcp["tools"], "the listing is reference-mcp's own")
                if name == "reference-agent":
                    granted = w["requires"]["tools"][0]["tools"]
                    self.assertEqual(granted, ["list_notes", "get_note"])


if __name__ == "__main__":
    unittest.main()
