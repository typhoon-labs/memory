#!/bin/sh
# ci_dry_run.sh: in CI only. The generation job's dry run with CI's own
# defaults: Copier clones this project's URL at this pipeline's commit with
# the job token, as the real job does. Offline, so it sends no request to
# the API; checks that .copier-answers.yml records the plain URL and that
# the token reached no rendered file.
set -eu
out=out/ci-dry-run
rm -rf "$out" && mkdir -p "$out/af/registrations" "$out/af/stacks/local"
printf 'ci-workload-release: []\n' > "$out/af/registrations/local.yaml"
printf 'locals {\n  workload_images = []\n\n  scratch_projects = ["devkit/ci-components"]\n}\n' > "$out/af/stacks/local/main.tf"
python3 generator/generate.py --dry-run --offline --template mcp-server-python --name ci-dry-run-mcp \
  --team reference --copier "$(command -v copier)" --aws-foundation-dir "$out/af" --out "$out/job"
answers="$out/job/rendered/ci-dry-run-mcp/.copier-answers.yml"
want="_src_path: $CI_SERVER_URL/$CI_PROJECT_PATH.git"
grep -qx "$want" "$answers" || { echo "error: $answers does not hold '$want'" >&2; exit 1; }
if grep -rqF "$CI_JOB_TOKEN" "$out/job"; then echo "error: the job token reached a rendered file" >&2; exit 1; fi
echo "dry run from $CI_SERVER_URL/$CI_PROJECT_PATH.git at $CI_COMMIT_SHA: $(grep '^_commit:' "$answers")"
