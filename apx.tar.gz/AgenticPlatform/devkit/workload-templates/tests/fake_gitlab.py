"""A fake of the GitLab REST API endpoints the generation job uses, in
memory, on a loopback port, with each project's repository a local bare Git
repository. Every request is recorded, so a test can assert what was (and
was not) sent. Standard library only."""

from __future__ import annotations

import json
import subprocess
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

TOKEN = "glpat-fake-bot-token-0123456789abcdef"


class FakeGitLab:
    def __init__(self, tmp: Path, root: str = "acme/agentic"):
        self.tmp, self.root = tmp, root
        self.calls: list[tuple[str, str]] = []
        self.users = {
            7: {"id": 7, "username": "workload-bot", "name": "Workload Bot", "commit_email": "bot@example.com"},
            42: {"id": 42, "username": "alice", "name": "Alice"},
            43: {"id": 43, "username": "mallory", "name": "Mallory"},
        }
        self.groups: dict[str, dict[str, Any]] = {}
        self.projects: dict[int, dict[str, Any]] = {}
        self.direct: dict[tuple[int, int], int] = {}  # (project, user) -> access level
        self.inherited: dict[tuple[str, int], int] = {}  # (group path, user) -> access level
        self.files: dict[tuple[int, str, str], str] = {}  # (project, branch, path) -> content
        self.mrs: list[dict[str, Any]] = []
        self.commits_api: list[dict[str, Any]] = []
        self._next = 1000
        for g in ["", "/devkit", "/infra", "/workloads", "/workloads/shared", "/workloads/reference", "/incubator"]:
            self.add_group(root + g)
        self.add_project(f"{root}/devkit/agent-sdk", creator=1)
        self.af = self.add_project(f"{root}/infra/aws-foundation", creator=1)

    # --- state ----------------------------------------------------------
    def nid(self) -> int:
        self._next += 1
        return self._next

    def add_group(self, path: str) -> dict[str, Any]:
        g = {"id": self.nid(), "full_path": path, "path": path.rsplit("/", 1)[-1]}
        self.groups[path] = g
        return g

    def add_project(self, path: str, creator: int, empty: bool = True, description: str = "") -> dict[str, Any]:
        pid = self.nid()
        bare = self.tmp / "repos" / f"{pid}.git"
        subprocess.run(["git", "init", "-q", "--bare", "-b", "main", str(bare)], check=True)
        p = {"id": pid, "path": path.rsplit("/", 1)[-1], "path_with_namespace": path, "creator_id": creator,
             "default_branch": "main", "web_url": f"https://gitlab.example/{path}",
             "http_url_to_repo": bare.as_uri(), "_bare": bare, "description": description}
        self.projects[pid] = p
        if not empty:
            work = self.tmp / f"seed-{pid}"
            subprocess.run(["git", "init", "-q", "-b", "main", str(work)], check=True)
            (work / "README.md").write_text("someone else's\n")
            env = {"GIT_AUTHOR_NAME": "x", "GIT_AUTHOR_EMAIL": "x@example.com", "GIT_COMMITTER_NAME": "x",
                   "GIT_COMMITTER_EMAIL": "x@example.com", "PATH": "/usr/bin:/bin"}
            for c in (["add", "-A"], ["commit", "-qm", "init"], ["push", "-q", bare.as_uri(), "main"]):
                subprocess.run(["git", "-C", str(work), *c], check=True, env=env)
        return p

    def project(self, ref: str) -> dict[str, Any] | None:
        if ref.isdigit():
            return self.projects.get(int(ref))
        return next((p for p in self.projects.values() if p["path_with_namespace"] == ref), None)

    def empty(self, p: dict[str, Any]) -> bool:
        r = subprocess.run(["git", "--git-dir", str(p["_bare"]), "rev-parse", "--verify", "-q", "refs/heads/main"],
                           capture_output=True)
        return r.returncode != 0

    def public(self, p: dict[str, Any]) -> dict[str, Any]:
        out = {k: v for k, v in p.items() if not k.startswith("_")}
        out["empty_repo"] = self.empty(p)
        return out

    def access(self, p: dict[str, Any], uid: int) -> int:
        levels = [self.direct.get((p["id"], uid), 0)]
        levels += [lvl for (g, u), lvl in self.inherited.items()
                   if u == uid and p["path_with_namespace"].startswith(g + "/")]
        return max(levels)

    def writes(self) -> list[tuple[str, str]]:
        return [c for c in self.calls if c[0] != "GET"]

    # --- HTTP -----------------------------------------------------------
    def handle(self, method: str, raw_path: str, body: Any) -> tuple[int, Any]:
        url = urllib.parse.urlsplit(raw_path)
        query = dict(urllib.parse.parse_qsl(url.query))
        parts = [urllib.parse.unquote(x) for x in url.path.removeprefix("/api/v4/").split("/")]
        m = method
        if parts == ["user"] and m == "GET":
            return 200, self.users[7]
        if parts[0] == "groups":
            g = next((g for g in self.groups.values() if str(g["id"]) == parts[1]), None) or self.groups.get(parts[1])
            if g is None:
                return 404, {"message": "404 Group Not Found"}
            if len(parts) == 2:
                return 200, g
            if parts[2] == "projects":
                hits = [self.public(p) for p in self.projects.values()
                        if p["path_with_namespace"].startswith(g["full_path"] + "/")
                        and query.get("search", "") in p["path"]]
                return 200, hits
        if parts[0] == "projects":
            if len(parts) == 1 and m == "POST":
                ns = next(g for g in self.groups.values() if g["id"] == body["namespace_id"])
                path = f"{ns['full_path']}/{body['path']}"
                if self.project(path):
                    return 400, {"message": {"path": ["has already been taken"]}}
                return 201, self.public(self.add_project(path, creator=7, description=body.get("description", "")))
            p = self.project(parts[1])
            if p is None:
                return 404, {"message": "404 Project Not Found"}
            rest = parts[2:]
            if not rest and m == "GET":
                return 200, self.public(p)
            if not rest and m == "PUT":
                p.update({k: v for k, v in body.items() if k == "description"})
                return 200, self.public(p)
            if rest[:2] == ["repository", "commits"] and m == "GET":
                if self.empty(p):
                    return 200, []
                log = subprocess.run(["git", "--git-dir", str(p["_bare"]), "log", "--format=%H%x09%ae", "main"],
                                     capture_output=True, text=True).stdout.split("\n")
                return 200, [{"id": x.split("\t")[0], "author_email": x.split("\t")[1]} for x in log if x]
            if rest[:2] == ["repository", "commits"] and m == "POST":
                start = {k[2]: v for k, v in self.files.items() if k[0] == p["id"] and k[1] == body["start_branch"]}
                for path, v in start.items():
                    self.files[(p["id"], body["branch"], path)] = v
                for a in body["actions"]:
                    self.files[(p["id"], body["branch"], a["file_path"])] = a["content"]
                self.commits_api.append(body)
                return 201, {"id": "c0ffee"}
            if rest[:2] == ["repository", "files"] and m == "GET":
                content = self.files.get((p["id"], query.get("ref", "main"), rest[2]))
                return (200, content) if content is not None else (404, {"message": "404 File Not Found"})
            if rest[:1] == ["members"]:
                if rest[1:2] == ["all"]:
                    lvl = self.access(p, int(rest[2]))
                    return (200, {"id": int(rest[2]), "access_level": lvl}) if lvl else (404, {"message": "404"})
                if len(rest) == 2:
                    uid = int(rest[1])
                    if m == "GET":
                        lvl = self.direct.get((p["id"], uid))
                        return (200, {"id": uid, "access_level": lvl}) if lvl else (404, {"message": "404"})
                    if m == "PUT":
                        self.direct[(p["id"], uid)] = body["access_level"]
                        return 200, {"id": uid, "access_level": body["access_level"]}
                if len(rest) == 1 and m == "POST":
                    uid = body["user_id"]
                    if self.access(p, uid) > body["access_level"]:
                        return 400, {"message": {"access_level": ["should be greater than or equal to the inherited level"]}}
                    self.direct[(p["id"], uid)] = body["access_level"]
                    return 201, {"id": uid, "access_level": body["access_level"]}
            if rest == ["merge_requests"] and m == "GET":
                return 200, [mr for mr in self.mrs if mr["project_id"] == p["id"]
                             and mr["state"] == query.get("state", mr["state"])
                             and mr["source_branch"] == query.get("source_branch", mr["source_branch"])]
            if rest == ["merge_requests"] and m == "POST":
                mr = {**body, "project_id": p["id"], "state": "opened", "iid": len(self.mrs) + 1,
                      "web_url": f"{p['web_url']}/-/merge_requests/{len(self.mrs) + 1}"}
                self.mrs.append(mr)
                return 201, mr
        return 404, {"message": f"fake: no route for {method} {url.path}"}

    def serve(self) -> str:
        fake = self

        class Handler(BaseHTTPRequestHandler):
            def _do(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n)) if n else None
                fake.calls.append((self.command, self.path))
                if self.headers.get("PRIVATE-TOKEN") != TOKEN:
                    status, out = 401, {"message": "401 Unauthorized"}
                else:
                    status, out = fake.handle(self.command, self.path, body)
                data = out.encode() if isinstance(out, str) else json.dumps(out).encode()
                self.send_response(status)
                self.send_header("Content-Type", "text/plain" if isinstance(out, str) else "application/json")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            do_GET = do_POST = do_PUT = do_DELETE = _do

            def log_message(self, *a):
                pass

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        return f"http://127.0.0.1:{self.server.server_address[1]}/api/v4"

    def stop(self) -> None:
        self.server.shutdown()
        self.server.server_close()
