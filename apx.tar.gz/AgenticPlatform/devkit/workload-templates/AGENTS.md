# Agent instructions: workload-templates

This repository holds the platform's workload templates, the settings of the projects made from them, and the generation job that makes them. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. The design is in [Development](../../architecture/design/development.md#project-generation-and-updates) and [Repositories](../../architecture/design/repositories.md#project-creation-and-settings); what the templates are and how the job runs is in the [README](README.md).

## Rules for this repository

- **The generation job's credential is the user's.** `GENERATION_TOKEN` is the bot user's personal access token, a protected and masked CI/CD variable the user creates (D8). Never create, request or substitute another credential, never run the job for real without it, and never send a request from a test or a dry run to GitLab.com: the sandbox's proxy would add its own credential. Tests use the fake API in `tests/fake_gitlab.py`, on loopback.
- **A dry run never writes.** Its API client refuses every method but `GET`, and `--offline` sends nothing.
- **No GitLab root or project ID in the code.** The job reads the root from its own project's path, and every other project by path under it.
- **Templates pin what they use by release:** `ci-components` by its major version in the CI/CD catalog (`@1`), the SDK's packages and the charts by their exact released versions, and `workload-charts` by the commit those charts were released from. Tags only when asked.
- **The job's commits and merge requests follow the project standards** too: Conventional Commits, lines of at most 72 characters, `Refs:` with decision IDs only, and no attribution or trailer lines.
- **A Python template's `uv.lock.jinja` is written by `tools/relock.py`,** never by hand, after any change to its `pyproject.toml.jinja` or to the pins.
- **A reference workload's code is files over its template** (`reference/<name>/files/`), never a template of its own.
- **Python:** the standard library first. A new dependency of the generator goes into `generator/requirements.in` with its reason in the commit message, and `generator/requirements.txt` is compiled again with hashes.

## Before committing

- `python -m unittest discover -s tests` passes in a virtual environment made from `generator/requirements.txt` (the README shows how).
- For a change to a Python template, a reference workload or the pins: `tests/python.sh` passes with the SDK's registry readable.
- `sh -n` on changed shell scripts.
- `python3 ../../architecture/tools/check_docs.py .` reports no problems.
