#!/usr/bin/env python3
"""Writes each Python template's uv.lock.jinja: renders the template with a
placeholder name, locks it with uv against the SDK's index, and turns the
lock back into a template, the name and the index Copier answers.

    tools/relock.py --sdk-index-url <agent-sdk's PyPI simple URL> [template ...]

Run it after a change to a template's pyproject.toml.jinja or to the pins in
copier.yml; the templates' tests then check each lock with uv's --locked.
uv reads the index's credentials from UV_INDEX_AGENTIC_USERNAME and
UV_INDEX_AGENTIC_PASSWORD. Standard library only, with copier and uv on
PATH."""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
PYTHON_TEMPLATES = {"mcp-server-python": "lock-placeholder-mcp", "adk-agent": "lock-placeholder-agent"}


def relock(template: str, index: str) -> Path:
    placeholder = PYTHON_TEMPLATES[template]
    with tempfile.TemporaryDirectory() as tmp:
        dest = Path(tmp) / placeholder
        subprocess.run(["copier", "copy", "--quiet", "--defaults", "--vcs-ref", "HEAD",
                        "--data", f"template={template}", "--data", f"name={placeholder}",
                        "--data", "team=placeholder", "--data", "gitlab_root=example/root",
                        "--data", f"sdk_index_url={index}", str(REPO), str(dest)], check=True)
        (dest / "uv.lock").unlink(missing_ok=True)
        subprocess.run(["uv", "lock", "--quiet", "--directory", str(dest)], check=True)
        lock = (dest / "uv.lock").read_text()
    if "{{" in lock or "{%" in lock or "{#" in lock:
        sys.exit(f"{template}: the lock holds Jinja's delimiters")
    files = re.sub(r"/simple/?$", "", index)
    lock = lock.replace(f'name = "{placeholder}"', 'name = "{{ name }}"')
    if placeholder in lock:
        sys.exit(f"{template}: the placeholder name is left elsewhere in the lock")
    lock = lock.replace(index, "{{ sdk_index_url }}")
    lock = lock.replace(files + "/", "{{ sdk_index_url | regex_replace('/simple/?$', '') }}/")
    # GitLab's simple index links each file by the project's numeric ID,
    # whatever path the index was read by (seen 2026-11-18). The lock names
    # them under the index's own path, which GitLab answers as well, so the
    # index's credentials, which uv matches by URL prefix, reach them.
    api = files.split("/projects/", 1)[0] + "/projects/"
    lock = re.sub(re.escape(api) + r'[^/"]+/packages/pypi/files/',
                  lambda _: "{{ sdk_index_url | regex_replace('/simple/?$', '') }}/files/", lock)
    out = REPO / template / "uv.lock.jinja"
    out.write_text(lock)
    return out


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("--sdk-index-url", required=True)
    p.add_argument("templates", nargs="*", default=sorted(PYTHON_TEMPLATES))
    a = p.parse_args()
    for t in a.templates:
        print(relock(t, a.sdk_index_url.rstrip("/")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
