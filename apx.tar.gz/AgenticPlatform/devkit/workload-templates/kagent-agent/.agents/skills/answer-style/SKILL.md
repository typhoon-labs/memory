---
name: answer-style
description: How to shape an answer for the person asking.
---

Answer in a few plain sentences. Name what each fact came from, by the
tool and the record, so that the person can check it.
