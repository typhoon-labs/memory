#!/usr/bin/env python3
"""The generation job (design/development.md, "Project generation and
updates"; design/repositories.md, "Project creation and settings").

From the pipeline inputs template, name, team and placement, and the
pipeline's user as the requester, it:

1. checks the naming rules, and that the name is free across the group's
   root, in GitLab and in aws-foundation's registrations;
2. creates the empty project at <root>/workloads/<team>/<name>
   (workloads/shared/<name>, incubator/<name>);
3. renders the template with Copier from this project's own URL at this
   pipeline's commit, its unsafe features trusted for that URL alone;
4. pushes the first commit to main as the bot;
5. applies project-settings.yml with gitlabform: after the first push,
   since the settings protect main from every push;
6. makes the requester a Maintainer;
7. opens the registration merge request in aws-foundation: the project's
   ID for ci-workload-release and its ECR repository, the path under the
   root (D4); a container workload's contract-stage scratch repository too.
   A workflow has no image and opens none.

Every step can be run again: a rerun after a failure resumes a project the
bot created and has not finished, and skips what is done.

The GitLab credential is GENERATION_TOKEN, the bot user's personal access
token, a protected and masked CI/CD variable the user sets (D8). It is sent
only as a request header and never printed or written to a file. The
templates project is cloned with the job's own CI_JOB_TOKEN.

--dry-run renders the template and prints what the job would do. It sends
no write: with a token its API client refuses every method but GET, and
with --offline it makes no request at all.

Standard library only, besides the copier and gitlabform commands, and
PyYAML, which both bring, to read YAML back.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
REPO = HERE.parent

# The templates, and what a workload made from each one is
# (design/repositories.md, "Naming"; agent-sdk's spec/schemas/workload).
TEMPLATES: dict[str, dict[str, Any]] = {
    "adk-agent": {"suffix": "-agent", "kind": "agent", "runtime": "container"},
    "mcp-server-python": {"suffix": "-mcp", "kind": "mcp-server", "runtime": "container"},
    "kagent-agent": {"suffix": "-agent", "kind": "agent", "runtime": "kagent"},
    "workflow-pipeline": {"suffix": "-workflow", "kind": "workflow", "runtime": "pipeline"},
}
PLACEMENTS = ("team", "shared", "incubator")
SLUG = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
# Never the framework or runtime as a word of the name (agent-sdk's
# workload schema; agentctl's checkName).
RUNTIME_WORDS = {"adk", "kagent"}
MAINTAINER = 40
BRANCH_PREFIX = "feat/register-"
# While a generation is unfinished, the project's description names its
# requester; the last step removes it. Only that requester resumes it.
PENDING = "[generation pending for user {}]"


class Refused(Exception):
    """The request breaks a rule: the job fails and says which."""


class ApiError(Exception):
    def __init__(self, method: str, path: str, status: int, body: str):
        super().__init__(f"{method} {path}: HTTP {status}: {body[:300]}")
        self.status = status


# --- naming -----------------------------------------------------------------

def check_request(template: str, name: str, team: str, placement: str) -> None:
    """The naming rules, before anything is read or written."""
    if template not in TEMPLATES:
        raise Refused(f"unknown template {template!r}: use {', '.join(sorted(TEMPLATES))}")
    if not name:
        raise Refused("no name given")
    if len(name) > 63 or not SLUG.match(name):
        raise Refused(f"{name!r} is not a workload name: lowercase kebab-case, at most 63 characters")
    suffix = TEMPLATES[template]["suffix"]
    if not name.endswith(suffix) or name == suffix.lstrip("-"):
        raise Refused(f"{name!r}: a {template} workload's name ends in {suffix}")
    words = set(name.split("-")) & RUNTIME_WORDS
    if words:
        raise Refused(f"{name!r}: a name never holds the framework or runtime ({', '.join(sorted(words))})")
    if placement not in PLACEMENTS:
        raise Refused(f"unknown placement {placement!r}: use {', '.join(PLACEMENTS)}")
    if not team:
        raise Refused("no team given: every workload names its owning team (workload.yaml's owner), "
                      "an incubator workload too")
    if len(team) > 63 or not SLUG.match(team):
        raise Refused(f"{team!r} is not a team's slug, as in environments' access/teams.yaml")
    if placement == "team" and team == "shared":
        raise Refused("'shared' is a placement, not a team: use placement shared with the owning team")


def target_path(root: str, name: str, team: str, placement: str) -> str:
    """The project's full path; the part under the root is its ECR repository (D4)."""
    return {
        "team": f"{root}/workloads/{team}/{name}",
        "shared": f"{root}/workloads/shared/{name}",
        "incubator": f"{root}/incubator/{name}",
    }[placement]


# --- GitLab -----------------------------------------------------------------

def q(path_or_id: str | int) -> str:
    return urllib.parse.quote(str(path_or_id), safe="")


class Api:
    """GitLab's REST API with a personal access token in PRIVATE-TOKEN."""

    def __init__(self, base: str, token: str, *, read_only: bool = False):
        self.base = base.rstrip("/")
        self._token = token
        self.read_only = read_only
        # A loopback API (the tests' fake) is reached directly, never
        # through a proxy from the environment.
        host = urllib.parse.urlsplit(self.base).hostname or ""
        handlers = [urllib.request.ProxyHandler({})] if host in ("127.0.0.1", "localhost", "::1") else []
        self._open = urllib.request.build_opener(*handlers).open

    def request(self, method: str, path: str, body: Any = None, *, raw: bool = False) -> Any:
        if self.read_only and method != "GET":
            raise RuntimeError(f"dry run: refused to send {method} {path}")
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(f"{self.base}/{path}", data=data, method=method)
        req.add_header("PRIVATE-TOKEN", self._token)
        req.add_header("Accept", "application/json")
        req.add_header("User-Agent", "workload-templates-generator")
        if data is not None:
            req.add_header("Content-Type", "application/json")
        try:
            with self._open(req, timeout=60) as r:
                payload = r.read()
        except urllib.error.HTTPError as e:
            raise ApiError(method, path, e.code, e.read().decode(errors="replace")) from None
        if raw:
            return payload.decode()
        return json.loads(payload) if payload else None

    def get(self, path: str, **kw: Any) -> Any:
        return self.request("GET", path, **kw)

    def find(self, path: str) -> Any:
        """GET, or None on 404."""
        try:
            return self.get(path)
        except ApiError as e:
            if e.status == 404:
                return None
            raise

    def post(self, path: str, body: Any) -> Any:
        return self.request("POST", path, body)

    def put(self, path: str, body: Any) -> Any:
        return self.request("PUT", path, body)


# --- the registration (aws-foundation) ---------------------------------------

def add_registration(text: str, role: str, project_id: int | str, path: str) -> str:
    """registrations/<stack>.yaml with the project under role; unchanged if it
    is there. Text-level, so that comments and layout stay as reviewed."""
    entry = [f"  - id: {project_id}", f"    path: {path}"]
    lines = text.splitlines()
    for i, line in enumerate(lines):
        m = re.match(rf"^{re.escape(role)}:\s*(\[\s*\])?\s*(#.*)?$", line)
        if not m:
            continue
        if m.group(1):  # flow-style empty list
            lines[i] = f"{role}:" + (f"  {m.group(2)}" if m.group(2) else "")
            lines[i + 1:i + 1] = entry
            return "\n".join(lines) + "\n"
        end = i + 1
        while end < len(lines) and (lines[end].startswith((" ", "-")) or lines[end].strip() == ""):
            if re.match(rf"^\s*-\s*id:\s*{re.escape(str(project_id))}\s*$", lines[end]):
                return text
            end += 1
        while end > i + 1 and lines[end - 1].strip() == "":
            end -= 1
        lines[end:end] = entry
        return "\n".join(lines) + "\n"
    raise Refused(f"no {role}: list in the registrations file")


def registered(text: str, role: str = "ci-workload-release") -> dict[str, Any]:
    """{path: project ID} of the projects registered under role."""
    import yaml

    return {e.get("path"): e.get("id") for e in (yaml.safe_load(text) or {}).get(role) or [] if isinstance(e, dict)}


def add_to_hcl_list(text: str, local: str, item: str) -> str:
    """stacks/<stack>/main.tf with item in the list assigned to local; unchanged
    if it is there. Only a plain list of string literals is edited."""
    m = re.search(rf"^(?P<indent>[ \t]*){re.escape(local)}\s*=\s*\[(?P<body>[^\]]*)\]", text, re.M)
    if not m:
        raise Refused(f"no `{local} = [...]` in the stack's main.tf")
    body, indent = m.group("body"), m.group("indent")
    if f'"{item}"' in body:
        return text
    inner = indent + "  "
    if "\n" not in body:
        items = re.findall(r'"([^"]*)"', body)
        rest = re.sub(r'"[^"]*"|,|\s', "", body)
        if rest:
            raise Refused(f"{local} holds more than string literals; edit it by hand")
        new = f"{indent}{local} = [\n" + "".join(f'{inner}"{x}",\n' for x in [*items, item]) + f"{indent}]"
    else:
        # Multi-line: the new item goes on a line of its own before the
        # closing bracket, after a trailing comma on the last item.
        head, _, _ = body.rstrip(" \t").rpartition("\n")
        last = head.rstrip()
        sep = "" if last.endswith(",") or last.endswith("[") or last.strip() == "" or last.lstrip().startswith("#") else ","
        new = f"{indent}{local} = [{head}{sep}\n{inner}\"{item}\",\n{indent}]"
    return text[:m.start()] + new + text[m.end():]


# --- the run ------------------------------------------------------------------

@dataclass
class Config:
    template: str
    name: str
    team: str
    placement: str
    root: str
    templates_url: str
    vcs_ref: str
    api_url: str
    requester_id: int | None
    requester_login: str
    pipeline_url: str
    stack: str = "local"
    settings_file: Path = REPO / "project-settings.yml"
    gitlabform: list[str] = field(default_factory=lambda: ["gitlabform"])
    copier: list[str] = field(default_factory=lambda: ["copier"])
    clone_token: str | None = None
    sdk_index_url: str | None = None
    out: Path = Path("out/generation")
    dry_run: bool = False
    offline: bool = False
    aws_foundation_dir: Path | None = None

    @property
    def path(self) -> str:
        return target_path(self.root, self.name, self.team, self.placement)

    @property
    def repository(self) -> str:
        return self.path[len(self.root) + 1:]

    @property
    def spec(self) -> dict[str, Any]:
        return TEMPLATES[self.template]


class Job:
    def __init__(self, cfg: Config, api: Api | None, log=print):
        self.cfg, self.api, self.log = cfg, api, log
        self.report: dict[str, Any] = {"template": cfg.template, "path": cfg.path, "dry_run": cfg.dry_run,
                                       "steps": []}
        self.bot: dict[str, Any] | None = None
        self._af: dict[str, Any] | None = None

    def step(self, what: str, **detail: Any) -> None:
        self.report["steps"].append({"step": what, **detail})
        self.log(f"- {what}" + (f": {json.dumps(detail, sort_keys=True)}" if detail else ""))

    # 1. naming and uniqueness
    def check_free(self) -> dict[str, Any] | None:
        """The project to resume, if the bot created it and left it unfinished;
        None when the name is free. Refused when taken."""
        cfg, api = self.cfg, self.api
        if api is None:
            self.step("not checked: whether the name is free (offline)")
            return None
        self.bot = api.get("user")
        team_group = api.find(f"groups/{q(f'{cfg.root}/workloads/{cfg.team}')}")
        if team_group is None:
            raise Refused(f"team {cfg.team!r} has no group {cfg.root}/workloads/{cfg.team}: "
                          "a team's group comes from the platform's settings first")
        parent = cfg.path.rsplit("/", 1)[0]
        if api.find(f"groups/{q(parent)}") is None:
            raise Refused(f"{parent} does not exist")
        existing = api.find(f"projects/{q(cfg.path)}")
        resume = None
        if existing is not None:
            if not self._resumable(existing):
                raise Refused(f"{cfg.path} is taken: {existing.get('web_url')}")
            resume = existing
        root_group = api.get(f"groups/{q(cfg.root)}")
        page = 1
        while True:
            hits = api.get(f"groups/{root_group['id']}/projects?include_subgroups=true&simple=true"
                           f"&search={q(cfg.name)}&per_page=100&page={page}")
            for p in hits:
                if p.get("path") == cfg.name and p.get("path_with_namespace") != cfg.path:
                    raise Refused(f"{cfg.name!r} is taken under {cfg.root}: {p.get('web_url')}; "
                                  "a workload's name is unique across the organization")
            if len(hits) < 100:
                break
            page += 1
        # The repository registered already, before anything is written:
        # by another project, refused; by this one, a rerun after its
        # registration merged.
        if cfg.spec["runtime"] != "pipeline":
            owner = registered(self.af_file(f"registrations/{cfg.stack}.yaml")).get(cfg.repository)
            if owner is not None and (resume is None or str(owner) != str(resume["id"])):
                raise Refused(f"{cfg.repository} is registered already in aws-foundation's "
                              f"registrations/{cfg.stack}.yaml, for project {owner}")
        self.step("name free" if resume is None else "resuming an unfinished project",
                  path=cfg.path, **({"project_id": resume["id"]} if resume else {}))
        return resume

    def af_project(self) -> dict[str, Any]:
        if self._af is None:
            self._af = self.api.get(f"projects/{q(f'{self.cfg.root}/infra/aws-foundation')}")
        return self._af

    def af_file(self, path: str) -> str:
        """A file of aws-foundation's default branch, or of --aws-foundation-dir offline."""
        if self.api is None or self.cfg.offline:
            return (self.cfg.aws_foundation_dir / path).read_text()
        af = self.af_project()
        return self.api.get(f"projects/{af['id']}/repository/files/{q(path)}/raw?ref={q(af['default_branch'])}", raw=True)

    def _resumable(self, project: dict[str, Any]) -> bool:
        """A generation this requester started and the job did not finish:
        the bot's project, its description still naming this requester as
        pending, with nothing pushed or only the bot's first commit. A
        finished project, or another requester's, is taken."""
        if project.get("creator_id") != self.bot["id"] or self.cfg.requester_id is None:
            return False
        if PENDING.format(self.cfg.requester_id) not in (project.get("description") or ""):
            return False
        if project.get("empty_repo"):
            return True
        commits = self.api.get(f"projects/{project['id']}/repository/commits?ref_name=main&per_page=2")
        return len(commits) == 1 and commits[0].get("author_email") == self._bot_email()

    def description(self, pending: bool) -> str:
        cfg = self.cfg
        base = f"{cfg.name}: a {cfg.spec['kind']} from workload-templates' {cfg.template}"
        return f"{base} {PENDING.format(cfg.requester_id)}" if pending else base

    def _bot_email(self) -> str:
        b = self.bot or {}
        return b.get("commit_email") or b.get("public_email") or f"{b.get('id')}-{b.get('username')}@users.noreply.gitlab.com"

    # 2. the project
    def create(self, resume: dict[str, Any] | None) -> dict[str, Any] | None:
        cfg, api = self.cfg, self.api
        if resume is not None:
            return resume
        if cfg.dry_run:
            self.step("would create the project", path=cfg.path, visibility="private")
            return None
        parent = api.get(f"groups/{q(cfg.path.rsplit('/', 1)[0])}")
        project = api.post("projects", {
            "name": cfg.name, "path": cfg.name, "namespace_id": parent["id"], "visibility": "private",
            "initialize_with_readme": False, "default_branch": "main",
            "description": self.description(pending=True),
        })
        self.step("created the project", project_id=project["id"], path=project["path_with_namespace"])
        return project

    # 3. Copier
    def answers(self) -> dict[str, Any]:
        cfg = self.cfg
        a = {"template": cfg.template, "name": cfg.name, "team": cfg.team, "placement": cfg.placement,
             "gitlab_root": cfg.root}
        if cfg.sdk_index_url:
            a["sdk_index_url"] = cfg.sdk_index_url
        return a

    def render(self, dest: Path) -> None:
        cfg = self.cfg
        with tempfile.TemporaryDirectory() as tmp:
            settings = Path(tmp) / "copier-settings.yml"
            # Copier's unsafe features (tasks, migrations, Jinja extensions)
            # are trusted for this project's own URL alone: an exact entry,
            # not a prefix (Copier's settings, "trust").
            settings.write_text(json.dumps({"trust": [cfg.templates_url]}))
            data = Path(tmp) / "answers.yml"
            data.write_text(json.dumps(self.answers()))
            env = {**os.environ, "COPIER_SETTINGS_PATH": str(settings)}
            if cfg.clone_token:
                # The job token reaches git as a header for this URL alone,
                # so that _src_path in .copier-answers.yml stays the plain URL.
                basic = base64.b64encode(f"gitlab-ci-token:{cfg.clone_token}".encode()).decode()
                env.update({"GIT_CONFIG_COUNT": "1",
                            "GIT_CONFIG_KEY_0": f"http.{cfg.templates_url}.extraHeader",
                            "GIT_CONFIG_VALUE_0": f"Authorization: Basic {basic}"})
            cmd = [*cfg.copier, "copy", "--vcs-ref", cfg.vcs_ref, "--data-file", str(data), "--defaults",
                   "--quiet", cfg.templates_url, str(dest)]
            r = subprocess.run(cmd, env=env, capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"copier exited {r.returncode}: {(r.stderr or r.stdout)[-2000:]}")
        answers = (dest / ".copier-answers.yml").read_text()
        self.step("rendered", template=cfg.template, vcs_ref=cfg.vcs_ref, files=sum(1 for p in dest.rglob("*") if p.is_file()))
        for line in answers.splitlines():
            if line.startswith(("_commit:", "_src_path:")):
                self.log(f"  {line}")

    # 4. the first commit
    def push(self, project: dict[str, Any], tree: Path) -> None:
        cfg = self.cfg
        git = ["git", "-C", str(tree)]
        email, name = self._bot_email(), (self.bot or {}).get("name") or (self.bot or {}).get("username")
        subject = next(x for x in (f"feat: generate {cfg.name} from {cfg.template}", f"feat: generate {cfg.name}",
                                   f"feat: generate the workload from {cfg.template}") if len(x) <= 72)
        message = (f"{subject}\n\n"
                   + textwrap.fill(f"Rendered by {cfg.root}/devkit/workload-templates' generation job "
                                   f"from {cfg.template} at {cfg.vcs_ref[:12]}, for {cfg.requester_login}.",
                                   72) + "\n")
        env = {**os.environ, "GIT_AUTHOR_NAME": name, "GIT_AUTHOR_EMAIL": email,
               "GIT_COMMITTER_NAME": name, "GIT_COMMITTER_EMAIL": email}
        url = project["http_url_to_repo"]
        if url.startswith("https://"):
            basic = base64.b64encode(f"oauth2:{self.api._token}".encode()).decode()
            env.update({"GIT_CONFIG_COUNT": "1", "GIT_CONFIG_KEY_0": f"http.{url}.extraHeader",
                        "GIT_CONFIG_VALUE_0": f"Authorization: Basic {basic}"})
        for cmd in (["init", "-q", "-b", "main"], ["add", "-A"], ["commit", "-q", "-m", message],
                    ["push", "-q", url, "main:main"]):
            r = subprocess.run([*git, *cmd], env=env, capture_output=True, text=True)
            if r.returncode != 0:
                raise RuntimeError(f"git {cmd[0]} exited {r.returncode}: {r.stderr[-1000:]}")
        sha = subprocess.run([*git, "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip()
        self.step("pushed the first commit", sha=sha)

    # 5. settings
    def settings_config(self) -> str:
        return self.cfg.settings_file.read_text().replace('"<root>/', f'"{self.cfg.root}/')

    def apply_settings(self) -> None:
        cfg = self.cfg
        config = self.settings_config()
        if cfg.dry_run:
            self.step("would apply project-settings.yml with gitlabform", target=cfg.path)
            self.log(textwrap.indent(config, "    "))
            return
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.yml"
            path.write_text(config)
            env = {**os.environ, "GITLAB_TOKEN": self.api._token, "GITLAB_URL": cfg.api_url.rsplit("/api/v4", 1)[0]}
            r = subprocess.run([*cfg.gitlabform, "-k", "-t", "-c", str(path), cfg.path], env=env,
                               capture_output=True, text=True)
        cfg.out.mkdir(parents=True, exist_ok=True)
        (cfg.out / "gitlabform.log").write_text(r.stdout + r.stderr)
        if r.returncode != 0:
            raise RuntimeError(f"gitlabform exited {r.returncode}; its report is {cfg.out}/gitlabform.log")
        self.step("applied project-settings.yml", report=str(cfg.out / "gitlabform.log"))

    # 6. the requester
    def maintainer(self, project: dict[str, Any] | None) -> None:
        cfg, api = self.cfg, self.api
        if cfg.requester_id is None:
            raise Refused("no requester: GITLAB_USER_ID is not set")
        if self.bot is not None and cfg.requester_id == self.bot["id"]:
            self.step("the requester is the bot: no member added")
            return
        have = direct = None
        if project is not None and api is not None:
            have = api.find(f"projects/{project['id']}/members/all/{cfg.requester_id}")
            if have and have.get("access_level", 0) >= MAINTAINER:
                self.step("the requester is a Maintainer already", access_level=have["access_level"])
                return
            direct = api.find(f"projects/{project['id']}/members/{cfg.requester_id}")
        if cfg.dry_run or project is None:
            self.step("would make the requester a Maintainer", user_id=cfg.requester_id, login=cfg.requester_login)
            return
        if direct:
            api.put(f"projects/{project['id']}/members/{cfg.requester_id}", {"access_level": MAINTAINER})
        else:
            api.post(f"projects/{project['id']}/members", {"user_id": cfg.requester_id, "access_level": MAINTAINER})
        self.step("made the requester a Maintainer", login=cfg.requester_login)

    # 7. the registration
    def registration_files(self, project_id: int | str, read) -> dict[str, tuple[str, str]]:
        """{path: (before, after)} of the files the registration changes."""
        cfg = self.cfg
        reg_path, tf_path = f"registrations/{cfg.stack}.yaml", f"stacks/{cfg.stack}/main.tf"
        reg, tf = read(reg_path), read(tf_path)
        for line in reg.splitlines():
            if re.match(rf"^\s*path:\s*{re.escape(cfg.repository)}\s*$", line):
                raise Refused(f"{cfg.repository} is registered already in aws-foundation's {reg_path}")
        new_reg = add_registration(reg, "ci-workload-release", project_id, cfg.repository)
        new_tf = add_to_hcl_list(tf, "workload_images", cfg.repository)
        if cfg.spec["runtime"] == "container":
            new_tf = add_to_hcl_list(new_tf, "scratch_projects", cfg.repository)
        return {reg_path: (reg, new_reg), tf_path: (tf, new_tf)}

    def registration_message(self, project_id: int | str) -> tuple[str, str]:
        cfg = self.cfg
        subject = f"feat(registrations): register {cfg.repository}"
        if len(subject) > 72:
            subject = f"feat(registrations): register {cfg.name}"
        if len(subject) > 72:
            subject = "feat(registrations): register a new workload project"
        scratch = (" and its contract stage's scratch repository" if cfg.spec["runtime"] == "container" else "")
        body = textwrap.fill(
            f"Registers {cfg.path} (project {project_id}) for ci-workload-release, so that its protected "
            f"tags may push and sign its releases, and adds its ECR repository {cfg.repository}{scratch} "
            f"to the {cfg.stack} stack (D4). Opened by workload-templates' generation job for "
            f"{cfg.requester_login}.", 72)
        return subject, f"{subject}\n\n{body}\n\nRefs: D4\n"

    def register(self, project: dict[str, Any] | None) -> None:
        cfg, api = self.cfg, self.api
        if cfg.spec["runtime"] == "pipeline":
            self.step("no registration: a workflow has no image")
            return
        pid = project["id"] if project else "<new project ID>"
        if (cfg.offline or api is None) and cfg.aws_foundation_dir is None:
            self.step("not shown: the registration (offline, no --aws-foundation-dir)")
            return
        if project is not None and str(registered(self.af_file(f"registrations/{cfg.stack}.yaml"))
                                       .get(cfg.repository)) == str(project["id"]):
            self.step("registered already: the registration merge request has merged")
            return
        af = None if (cfg.offline or api is None) else self.af_project()
        branch = BRANCH_PREFIX + cfg.repository.replace("/", "-")
        if af is not None:
            open_mrs = api.get(f"projects/{af['id']}/merge_requests?state=opened&source_branch={q(branch)}")
            if open_mrs:
                self.step("the registration merge request is open already", url=open_mrs[0]["web_url"])
                self.report["registration"] = open_mrs[0]["web_url"]
                return
        files = self.registration_files(pid, self.af_file)
        subject, message = self.registration_message(pid)
        if cfg.dry_run or af is None:
            self.step("would open the registration merge request in aws-foundation", branch=branch, title=subject)
            for path, (before, after) in files.items():
                self.log(f"    --- {path}")
                self.log(textwrap.indent(_diff(before, after, path), "    "))
            return
        api.post(f"projects/{af['id']}/repository/commits", {
            "branch": branch, "start_branch": af["default_branch"], "commit_message": message,
            "actions": [{"action": "update", "file_path": p, "content": after} for p, (_, after) in files.items()],
        })
        mr = api.post(f"projects/{af['id']}/merge_requests", {
            "source_branch": branch, "target_branch": af["default_branch"], "title": subject,
            "remove_source_branch": True,
            "description": textwrap.dedent(f"""\
                Registers the workload project `{cfg.path}` ({pid}), generated from `{cfg.template}`
                for {cfg.requester_login} by the generation job: {cfg.pipeline_url}

                - `registrations/{cfg.stack}.yaml`: the project under `ci-workload-release`
                - `stacks/{cfg.stack}/main.tf`: the ECR repository `{cfg.repository}`"""
                + (" in `workload_images` and `scratch_projects`" if cfg.spec["runtime"] == "container"
                   else " in `workload_images`") + "\n"),
        })
        self.report["registration"] = mr["web_url"]
        self.step("opened the registration merge request", url=mr["web_url"])

    # the whole job
    def run(self) -> dict[str, Any]:
        cfg = self.cfg
        check_request(cfg.template, cfg.name, cfg.team, cfg.placement)
        self.step("naming rules pass", template=cfg.template, name=cfg.name, team=cfg.team, placement=cfg.placement)
        resume = self.check_free()
        project = self.create(resume)
        if project is not None:
            self.report.update(project_id=project["id"], web_url=project.get("web_url"))
        pushed = project is not None and not project.get("empty_repo", True)
        if pushed:
            self.step("the first commit is there already")
        else:
            with tempfile.TemporaryDirectory() as tmp:
                tree = Path(tmp) / cfg.name
                self.render(tree)
                if cfg.dry_run:
                    keep = cfg.out / "rendered" / cfg.name
                    if keep.exists():
                        shutil.rmtree(keep)
                    shutil.copytree(tree, keep)
                    self.step("would push the first commit to main", rendered=str(keep))
                else:
                    self.push(project, tree)
        self.apply_settings()
        self.maintainer(project)
        self.register(project)
        if project is not None and not cfg.dry_run:
            # Finished: no one resumes it from here, the requester included.
            self.api.put(f"projects/{project['id']}", {"description": self.description(pending=False)})
            self.step("finished: the project's description no longer marks it pending")
        cfg.out.mkdir(parents=True, exist_ok=True)
        (cfg.out / "report.json").write_text(json.dumps(self.report, indent=2) + "\n")
        return self.report


def _diff(before: str, after: str, path: str) -> str:
    import difflib

    return "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), f"a/{path}", f"b/{path}"))


def main(argv: list[str] | None = None) -> int:
    env = os.environ
    p = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    p.add_argument("--template", required=True)
    p.add_argument("--name", required=True)
    p.add_argument("--team", default="")
    p.add_argument("--placement", default="team")
    p.add_argument("--root", default=env.get("CI_PROJECT_NAMESPACE", "/").rsplit("/", 1)[0] or None,
                   help="the group's root; by default the parent of this project's namespace")
    p.add_argument("--templates-url", default=(f"{env['CI_SERVER_URL']}/{env['CI_PROJECT_PATH']}.git"
                                               if env.get("CI_SERVER_URL") and env.get("CI_PROJECT_PATH") else None),
                   help="Copier's source: this project's own URL")
    p.add_argument("--vcs-ref", default=env.get("CI_COMMIT_SHA", "HEAD"))
    p.add_argument("--api-url", default=env.get("CI_API_V4_URL", "https://gitlab.com/api/v4"))
    p.add_argument("--stack", default=env.get("GENERATION_REGISTRATION_STACK", "local"))
    p.add_argument("--sdk-index-url", default=None,
                   help="agent-sdk's PyPI simple URL; by default its project's, by path under the root")
    p.add_argument("--gitlabform", default=env.get("GENERATION_GITLABFORM", "gitlabform"))
    p.add_argument("--copier", default=env.get("GENERATION_COPIER", "copier"))
    p.add_argument("--out", default="out/generation")
    p.add_argument("--dry-run", action="store_true", help="render and print what would be done; send no write")
    p.add_argument("--offline", action="store_true", help="with --dry-run: no request at all")
    p.add_argument("--aws-foundation-dir", type=Path, help="offline: aws-foundation's checkout for the registration diff")
    a = p.parse_args(argv)
    if a.offline and not a.dry_run:
        p.error("--offline needs --dry-run")
    if not a.root or not a.templates_url:
        p.error("--root and --templates-url are needed outside CI")

    token = env.get("GENERATION_TOKEN", "")
    api = None
    if not a.offline:
        if not token:
            print("error: GENERATION_TOKEN is not set: the bot user's token, a protected and masked CI/CD "
                  "variable of this project that the user creates (D8). Nothing else stands in for it.",
                  file=sys.stderr)
            return 1
        api = Api(a.api_url, token, read_only=a.dry_run)
    requester = env.get("GITLAB_USER_ID")
    try:
        check_request(a.template, a.name, a.team, a.placement)
    except Refused as e:
        print(f"refused: {e}", file=sys.stderr)
        return 3
    cfg = Config(
        template=a.template, name=a.name, team=a.team, placement=a.placement, root=a.root,
        templates_url=a.templates_url, vcs_ref=a.vcs_ref, api_url=a.api_url,
        requester_id=int(requester) if requester and requester.isdigit() else None,
        requester_login=env.get("GITLAB_USER_LOGIN", "the requester"),
        pipeline_url=env.get("CI_PIPELINE_URL", ""), stack=a.stack,
        gitlabform=a.gitlabform.split(), copier=a.copier.split(),
        clone_token=env.get("CI_JOB_TOKEN") or None, out=Path(a.out), dry_run=a.dry_run, offline=a.offline,
        aws_foundation_dir=a.aws_foundation_dir,
    )
    if a.dry_run and cfg.requester_id is None:
        cfg.requester_id = 0
    try:
        check_request(cfg.template, cfg.name, cfg.team, cfg.placement)
        if cfg.template in ("adk-agent", "mcp-server-python"):
            # agent-sdk's PyPI registry, by the project's path under the root:
            # GitLab takes a URL-encoded path wherever it takes a project ID.
            cfg.sdk_index_url = a.sdk_index_url or (
                f"{a.api_url.rstrip('/')}/projects/{q(cfg.root + '/devkit/agent-sdk')}/packages/pypi/simple")
        report = Job(cfg, api).run()
    except Refused as e:
        print(f"refused: {e}", file=sys.stderr)
        return 3
    except (ApiError, RuntimeError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(json.dumps({k: v for k, v in report.items() if k != "steps"}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
