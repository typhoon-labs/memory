"""reference-mcp's notes: each note an ID, a title, its text and a version
that every change raises. In Postgres, in the same database and the same
transaction as the SDK's approval and idempotency records, when
AGENTIC_DATABASE_URL is set; in memory otherwise, for tests and a contract
stage without a database."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from agentic_sdk.approvals import Target
from agentic_sdk.store import MemoryStore

SCHEMA = """
create table if not exists reference_notes (
  id text primary key,
  title text not null,
  body text not null,
  version bigint not null,
  updated_by text,
  updated_at timestamptz not null default now()
);
"""


@dataclass(frozen=True)
class Note:
    id: str
    title: str
    text: str
    version: int

    def summary(self) -> dict[str, Any]:
        return {"id": self.id, "title": self.title, "version": str(self.version)}

    def full(self) -> dict[str, Any]:
        return {**self.summary(), "text": self.text}


def _added(note: Note | None, note_id: str, text: str) -> Note:
    """The note after add_note: its text with one more line, its version
    one higher; a new note takes its title from the text's first line."""
    if note is None:
        return Note(note_id, text.splitlines()[0][:120] if text.strip() else note_id, text, 1)
    return Note(note.id, note.title, f"{note.text}\n{text}" if note.text else text, note.version + 1)


class MemoryNotes:
    def __init__(self) -> None:
        self.notes: dict[str, Note] = {}

    async def list(self, tx: Any = None) -> list[Note]:
        return sorted(self.notes.values(), key=lambda n: n.id)

    async def get(self, note_id: str, tx: Any = None, *, lock: bool = False) -> Note | None:
        return self.notes.get(note_id)

    async def add(self, tx: Any, note_id: str, text: str, by: str | None) -> Note:
        new = _added(self.notes.get(note_id), note_id, text)

        def commit() -> None:
            self.notes[note_id] = new

        # Applied only if the guard's transaction commits.
        tx.after_commit(commit)
        return new

    async def put(self, note: Note) -> None:
        self.notes[note.id] = note


class PostgresNotes:
    """Every query through the store's acquire(): inside a tool call it is
    the guard's own transaction's connection, so a note read and changed in
    a call commits or rolls back with the call's idempotency key and
    approval; outside one, a connection from the pool."""

    def __init__(self, store: Any) -> None:
        self.store = store
        self._ready = False
        self._lock = asyncio.Lock()

    async def _schema(self) -> None:
        if not self._ready:
            async with self._lock:
                if not self._ready:
                    async with self.store.acquire() as conn:
                        await conn.execute(SCHEMA)
                    self._ready = True

    @staticmethod
    def _note(row) -> Note | None:
        return Note(row["id"], row["title"], row["body"], row["version"]) if row else None

    async def list(self, tx: Any = None) -> list[Note]:
        await self._schema()
        async with self.store.acquire() as conn:
            rows = await conn.fetch("select id, title, body, version from reference_notes order by id")
        return [self._note(r) for r in rows]

    async def get(self, note_id: str, tx: Any = None, *, lock: bool = False) -> Note | None:
        # lock: inside the transaction that changes the note, so that the
        # version checked is the version changed.
        await self._schema()
        query = "select id, title, body, version from reference_notes where id = $1" + (" for update" if lock else "")
        async with self.store.acquire() as conn:
            return self._note(await conn.fetchrow(query, note_id))

    async def add(self, tx: Any, note_id: str, text: str, by: str | None) -> Note:
        new = _added(await self.get(note_id, tx, lock=True), note_id, text)
        async with self.store.acquire() as conn:
            await conn.execute(
                "insert into reference_notes (id, title, body, version, updated_by) values ($1, $2, $3, $4, $5) "
                "on conflict (id) do update set body = excluded.body, version = excluded.version, "
                "updated_by = excluded.updated_by, updated_at = now()",
                new.id, new.title, new.text, new.version, by)
        return new

    async def put(self, note: Note) -> None:
        await self._schema()
        async with self.store.acquire() as conn:
            await conn.execute(
                "insert into reference_notes (id, title, body, version) values ($1, $2, $3, $4) "
                "on conflict (id) do update set title = excluded.title, body = excluded.body, version = excluded.version",
                note.id, note.title, note.text, note.version)


def notes_for(store: Any) -> MemoryNotes | PostgresNotes:
    return MemoryNotes() if isinstance(store, MemoryStore) else PostgresNotes(store)


async def target(notes: MemoryNotes | PostgresNotes, note_id: str, tx: Any = None) -> Target | None:
    note = await notes.get(note_id, tx, lock=tx is not None)
    return Target(note.id, str(note.version)) if note else None
