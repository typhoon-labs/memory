"""reference-mcp's tools (plan/local-build.md, "The reference workloads"):
notes in its own database. list_notes and get_note read; add_note changes
a note, so it is destructive: it needs an approval by a person other than
the proposer, bound to its parameters and the note's version, single use
and short-lived, through the approval route; it takes the task ID as its
idempotency key; and every call, refused or not, leaves a tool audit
record. All of it is the SDK's ToolGuard; this file says what each tool
does."""

from __future__ import annotations

import json

from mcp.types import CallToolResult

from agentic_sdk import context
from agentic_sdk.approvals import Target
from agentic_sdk.runtime import Runtime

from .app import McpWorkload
from .app import text as answer
from .notes import notes_for, target


def not_found(note_id: str) -> dict:
    return {"isError": True, "content": [{"type": "text", "text": f"No note {note_id}."}],
            "structuredContent": {"error": "not_found", "message": f"No note {note_id}."}}


class NotesWorkload(McpWorkload):
    def __init__(self, runtime: Runtime):
        super().__init__(runtime)
        self.notes = notes_for(runtime.store)

    async def current_target(self, tool: str, target_id: str) -> Target | None:
        return await target(self.notes, target_id)


def build(runtime: Runtime) -> NotesWorkload:
    w = NotesWorkload(runtime)

    @w.tool
    async def list_notes() -> CallToolResult:
        """Lists the notes: each one's ID, title and version."""

        async def apply(tx) -> dict:
            notes = [n.summary() for n in await w.notes.list(tx)]
            return answer(json.dumps(notes), {"notes": notes})

        return await w.call("list_notes", {}, apply)

    @w.tool
    async def get_note(note_id: str) -> CallToolResult:
        """Reads one note: its title, text and version."""

        async def apply(tx) -> dict:
            note = await w.notes.get(note_id, tx)
            return answer(json.dumps(note.full()), note.full()) if note else not_found(note_id)

        return await w.call("get_note", {"note_id": note_id}, apply)

    @w.tool
    async def add_note(note_id: str, text: str, approval_id: str | None = None) -> CallToolResult:
        """Adds a line of text to a note, creating the note if it is new.
        Needs a person's approval: the first call answers with an
        approval_id; once someone else has approved it, call again with the
        same arguments and that approval_id."""
        arguments = {"note_id": note_id, "text": text}
        if approval_id is not None:
            arguments["approval_id"] = approval_id

        async def apply(tx) -> dict:
            inv = context.require()
            note = await w.notes.add(tx, note_id, text, inv.principal.user_id)
            return {"isError": False, "content": [{"type": "text", "text": f"Added to {note.id}, now version {note.version}."}],
                    "structuredContent": {"id": note.id, "version": str(note.version)}}

        return await w.call("add_note", arguments, apply,
                            target=lambda tx: target(w.notes, note_id, tx))

    return w
