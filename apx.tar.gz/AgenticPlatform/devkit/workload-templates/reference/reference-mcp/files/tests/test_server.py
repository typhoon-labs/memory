"""reference-mcp over real HTTP, with the notes in memory and, when
AGENTIC_TEST_DATABASE_URL names a throwaway Postgres database, in Postgres:
the tools it lists, refusals without a token, each call's own caller, and
check 8's approvals and idempotency (plan/local-build.md, "B5 in detail")."""

from __future__ import annotations

import asyncio
import os
import time
import uuid

import httpx2
import pytest
import yaml
from mcp import Client
from mcp.client.streamable_http import streamable_http_client

from agentic_sdk.audit import AuditEmitter
from agentic_sdk.runtime import Runtime
from conftest import AUDIENCE, ROOT, Issuer, environment, records, serving
from reference_mcp.notes import Note
from reference_mcp.tools import build

DATABASE = os.environ.get("AGENTIC_TEST_DATABASE_URL")
BACKENDS = ["memory", pytest.param("postgres", marks=pytest.mark.skipif(
    not DATABASE, reason="AGENTIC_TEST_DATABASE_URL names no throwaway database"))]


@pytest.fixture(params=BACKENDS)
def runtime(request, jwks_uri, audit) -> Runtime:
    extra = {"AGENTIC_APPROVAL_TTL_SECONDS": "2"}
    if request.param == "postgres":
        extra["AGENTIC_DATABASE_URL"] = DATABASE
    rt = Runtime(environ=environment(jwks_uri, **extra), workload_file=str(ROOT / "workload.yaml"))
    rt.__dict__["audit"] = AuditEmitter("reference-mcp", stream=audit)
    return rt


class Caller:
    """One person's MCP calls, each under a task ID the test gives."""

    def __init__(self, base: str, issuer: Issuer, who: str):
        self.base, self.issuer, self.who = base, issuer, who

    async def call(self, tool: str, arguments: dict, task: str | None = None):
        headers = {"Authorization": f"Bearer {self.issuer.token(self.who)}"}
        if task:
            headers["Agentic-Task-Id"] = task
        http = httpx2.AsyncClient(headers=headers, trust_env=False, timeout=10)
        async with http, Client(streamable_http_client(f"{self.base}/mcp", http_client=http)) as client:
            return await client.call_tool(tool, arguments)

    def approval(self, method: str, approval_id: str, body: dict | None = None):
        url = f"{self.base}/approvals/reference-mcp/{approval_id}"
        headers = {"Authorization": f"Bearer {self.issuer.token(self.who, aud=AUDIENCE)}"}
        return httpx2.request(method, url, headers=headers, json=body, trust_env=False)


def error(result) -> str | None:
    return (result.structured_content or {}).get("error") if result.is_error else None


def seed(runtime: Runtime, workload, note: Note) -> None:
    """Puts a note as it stands, beside the running server: in memory
    directly, in Postgres through a connection of the test's own."""
    from reference_mcp.notes import MemoryNotes, PostgresNotes

    if isinstance(workload.notes, MemoryNotes):
        asyncio.run(workload.notes.put(note))
        return

    async def go():
        from agentic_sdk.store_postgres import PostgresStore

        store = PostgresStore(DATABASE)
        try:
            await PostgresNotes(store).put(note)
        finally:
            await store.close()

    asyncio.run(go())


def test_lists_the_declared_tools(runtime, issuer):
    declared = {t["name"]: t["annotations"] for t in yaml.safe_load((ROOT / "workload.yaml").read_text())["tools"]}

    async def go(base):
        http = httpx2.AsyncClient(headers={"Authorization": f"Bearer {issuer.token('alice')}"}, trust_env=False)
        async with http, Client(streamable_http_client(f"{base}/mcp", http_client=http)) as client:
            return (await client.list_tools()).tools

    with serving(runtime, build) as base:
        listed = asyncio.run(go(base))
    assert {t.name: t.annotations.model_dump(by_alias=True, exclude_none=True) for t in listed} == declared


def test_refuses_a_call_without_a_token(runtime):
    with serving(runtime, build) as base:
        r = httpx2.post(f"{base}/mcp", headers={"Accept": "application/json, text/event-stream"},
                        json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"}, trust_env=False)
        approvals = httpx2.get(f"{base}/approvals/reference-mcp/nope-nope-nope-nope", trust_env=False)
    assert r.status_code == 401 and r.headers["www-authenticate"].startswith("Bearer")
    assert approvals.status_code == 401


def test_reads_under_concurrent_callers(runtime, issuer, audit):
    built = {}

    def keep(rt):
        built["w"] = build(rt)
        return built["w"]

    with serving(runtime, keep) as base:
        note = f"note-{uuid.uuid4().hex[:8]}"
        seed(runtime, built["w"], Note(note, "Ingest", "Restart the ingest job", 7))

        async def go():
            people = [Caller(base, issuer, f"person-{i}") for i in range(12)]
            return await asyncio.gather(*[p.call("get_note", {"note_id": note}, task=f"t-{p.who}") for p in people])

        results = asyncio.run(go())
    assert all(r.structured_content["version"] == "7" for r in results)
    recs = [r for r in records(audit) if r.get("tool.name") == "get_note"]
    assert sorted(r["user.id"] for r in recs) == sorted(f"person-{i}" for i in range(12))


def test_approvals_and_idempotency(runtime, issuer, audit):
    """Check 8: without an approval, with changed parameters, a newer note
    version, an expired or reused approval, or the proposer as approver,
    refused; with a valid one, applied once; a retry under the same task
    writes once; every call leaves one audit record."""
    built = {}

    def keep(rt):
        built["w"] = build(rt)
        return built["w"]

    with serving(runtime, keep) as base:
        w = built["w"]
        note = f"note-{uuid.uuid4().hex[:8]}"
        seed(runtime, w, Note(note, "Ingest", "Restart the ingest job", 7))
        alice, bob = Caller(base, issuer, "alice"), Caller(base, issuer, "bob")
        args = {"note_id": note, "text": "Then check the lag."}
        run = asyncio.run

        # Without an approval: a pending proposal.
        r = run(alice.call("add_note", args, task="t1"))
        assert error(r) == "approval_missing"
        aid = r.structured_content["approval_id"]
        assert error(run(alice.call("add_note", {**args, "approval_id": aid}, task="t1"))) == "approval_pending"

        # The route: read it, refuse the proposer and a changed hash or version, approve.
        got = bob.approval("GET", aid)
        assert got.status_code == 200 and got.json()["target"] == {"id": note, "version": "7"}
        phash = got.json()["parameters_hash"]
        assert alice.approval("POST", aid, {"parameters_hash": phash, "target_version": "7"}).json()["error"] == "approval_self"
        assert bob.approval("POST", aid, {"parameters_hash": "sha256:" + "0" * 64, "target_version": "7"}).json()["error"] == "approval_parameters"
        assert bob.approval("POST", aid, {"parameters_hash": phash, "target_version": "6"}).json()["error"] == "approval_version"
        ok = bob.approval("POST", aid, {"parameters_hash": phash, "target_version": "7"})
        assert ok.status_code == 200 and ok.json()["approver"]["user.id"] == "bob"

        # Another caller, or changed parameters: refused.
        carol = Caller(base, issuer, "carol")
        assert error(run(carol.call("add_note", {**args, "approval_id": aid}, task="t1"))) == "approval_caller"
        assert error(run(alice.call("add_note", {**args, "text": "other", "approval_id": aid}, task="t1"))) == "approval_parameters"

        # Applied once; the same task replays it, with or without the approval.
        r = run(alice.call("add_note", {**args, "approval_id": aid}, task="t1"))
        assert not r.is_error and r.structured_content == {"id": note, "version": "8"}
        assert run(alice.call("add_note", {**args, "approval_id": aid}, task="t1")).structured_content == r.structured_content
        assert run(alice.call("add_note", args, task="t1")).structured_content == r.structured_content
        got = run(alice.call("get_note", {"note_id": note}))
        assert got.structured_content["version"] == "8"
        assert got.structured_content["text"] == "Restart the ingest job\nThen check the lag."
        # Reused under another task: refused.
        assert error(run(alice.call("add_note", {**args, "approval_id": aid}, task="t2"))) == "approval_used"

        # A newer version of the note after the approval: refused.
        args3 = {**args, "text": "And page the owner."}
        a3 = run(alice.call("add_note", args3, task="t3")).structured_content["approval_id"]
        h3 = bob.approval("GET", a3).json()["parameters_hash"]
        assert bob.approval("POST", a3, {"parameters_hash": h3, "target_version": "8"}).status_code == 200
        seed(runtime, w, Note(note, "Ingest", "Edited meanwhile", 9))
        assert error(run(alice.call("add_note", {**args3, "approval_id": a3}, task="t3"))) == "approval_version"

        # Expired: the approval lives AGENTIC_APPROVAL_TTL_SECONDS, 2 here.
        args4 = {**args, "text": "Too late."}
        a4 = run(alice.call("add_note", args4, task="t4")).structured_content["approval_id"]
        h4 = bob.approval("GET", a4).json()["parameters_hash"]
        assert bob.approval("POST", a4, {"parameters_hash": h4, "target_version": "9"}).status_code == 200
        time.sleep(2.2)
        assert error(run(alice.call("add_note", {**args4, "approval_id": a4}, task="t4"))) == "approval_expired"
        assert run(alice.call("get_note", {"note_id": note})).structured_content["version"] == "9"

    recs = [r for r in records(audit) if r.get("tool.name") == "add_note"]
    outcomes = [r["tool.call.outcome"] for r in recs]
    assert outcomes.count("completed") == 1
    assert outcomes.count("replayed") == 2
    reasons = {r.get("refusal.reason") for r in recs}
    assert {"approval_missing", "approval_pending", "approval_caller", "approval_parameters", "approval_used",
            "approval_version", "approval_expired"} <= reasons
    assert all("Then check" not in str(r) for r in recs), "a record never carries the arguments"
