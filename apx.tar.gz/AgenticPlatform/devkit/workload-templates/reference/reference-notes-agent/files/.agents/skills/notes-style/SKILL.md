---
name: notes-style
description: How to quote a note in an answer.
---

Quote a note by its title and the line that answers the question, then
name it by its ID and version, such as `note-42 (version 7)`, so that the
person can read it with get_note.
