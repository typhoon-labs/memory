"""reference-agent end to end, with the tests' stand-ins for the gateway
(conftest.Gateway): reference-mcp's route lists list_notes, get_note and a
tool the agent is not granted. The agent is offered list_notes and get_note
alone, calls reference-mcp with a token the STS exchanged for the person
asking, for that route alone, and answers from the tool's result."""

from __future__ import annotations

import asyncio
import json
from urllib.parse import parse_qsl

import httpx

from conftest import RESOURCE_BASE, claims
from test_agent import answer_text, send


def test_answers_from_reference_mcp_as_the_caller(agent, gateway, sts, issuer):
    async def go():
        async with httpx.AsyncClient(trust_env=False) as c:
            return await asyncio.gather(*[send(c, agent, issuer.token(p), "What should I do about ingest?", f"task-{p}")
                                          for p in ("alice", "bob")])

    for r in asyncio.run(go()):
        assert r.status_code == 200, r.text
        state, text = answer_text(r)
        assert state == "TASK_STATE_COMPLETED", r.text
        assert "reference-mcp says: the result of " in text

    offered = {t["function"]["name"] for call in gateway.model_calls() for t in (json.loads(call["body"]).get("tools") or [])}
    assert offered == {"list_notes", "get_note"}

    assert len(gateway.mcp_calls) == 2
    assert all(s == "reference-mcp" and t in {"list_notes", "get_note"} for s, t, _ in gateway.mcp_calls)
    subjects = []
    for _, _, auth in gateway.mcp_calls:
        c = claims(auth.removeprefix("Bearer "))
        assert c["aud"] == f"{RESOURCE_BASE}/mcp/reference-mcp"
        subjects.append(c["sub"])
    assert sorted(subjects) == ["alice", "bob"]
    resources = {dict(parse_qsl(s["body"].decode()))["resource"] for s in sts.seen}
    assert resources == {f"{RESOURCE_BASE}/mcp/reference-mcp", f"{RESOURCE_BASE}/v1"}
