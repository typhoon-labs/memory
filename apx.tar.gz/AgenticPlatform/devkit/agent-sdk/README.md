# agent-sdk

The platform's shared SDK: `spec/`, the language-neutral contracts that the delegation STS, its interoperability suite and every SDK language core load, and `python/`, the Python core (build phase B5).

The design is in [Development: The shared SDK](../../architecture/design/development.md#the-shared-sdk-agent-sdk), and the repository's place in the group in [Repositories](../../architecture/design/repositories.md#repository-layouts). These links, and the others in this repository's documents, are relative to the workspace, which mirrors the GitLab group.

| Path | Holds |
| --- | --- |
| `spec/` | The canonical contracts, as JSON and JSON Schema. Its README lists each area |
| `python/` | The Python packages, one uv workspace with one lock file: `core/`, the core, published as `agentic-agent-sdk` ([its README](python/core/README.md)), and `adk/`, its Google ADK adapter, `agentic-agent-sdk-adk` ([its README](python/adk/README.md)) |
| `tools/` | `check_spec.py`, the spec's own checks |
| `.gitlab-ci.yml` | The pipeline: the spec's checks, the packages' tests with the fake model server and Postgres, and publishing to the project's PyPI registry |
| `AGENTS.md` | Instructions for agents working here |

**Releases.** `spec/` is released on its own `spec/vX.Y.Z` tags and pinned by its consumers. The first tag, `spec/v0.1.0`, is made in build phase B1 once the STS's interoperability suite uses the spec ([the local build plan](../../architecture/plan/local-build.md#b1-in-detail)).

The Python packages are released on `python/vX.Y.Z` tags to the project's own PyPI registry, the first `python/v0.1.0`. `main`'s pipeline publishes each build as a dev build of the next release, `X.Y.Z.devN` from the `X.Y.Z.dev0` both `pyproject.toml` files declare, so that templates and workloads can pin an exact one and it sorts above the last release.
