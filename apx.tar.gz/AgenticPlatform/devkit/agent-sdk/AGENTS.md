# Agent instructions: agent-sdk

This repository holds the platform's shared SDK; today only `spec/`, the canonical home of the platform's contracts. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. The design is in [Development](../../architecture/design/development.md#the-shared-sdk-agent-sdk) and, for the STS's contracts, [Identity](../../architecture/design/identity.md#refusals-and-audit-records). The rules below are specific to this repository.

## The spec

- **The design states the rules; `spec/` holds the shapes and codes.** Until the first `spec/` tag, the tables in Identity are canonical and `spec/` transcribes them, so change both together. From `spec/v0.1.0` on, `spec/` is canonical and Identity links to it.
- **Machine-readable first.** JSON, and JSON Schema draft 2020-12 for shapes, so any language loads them with its standard library and a schema validator. Each area has a short README naming its files and the design section that holds its rules.
- **Each fact has one home.** The pairs of `error` and `reason` live only in `spec/refusals/refusals.json`, a tool's refusals only in `spec/audit/tool/refusals.json`, and the approval route's own only in `spec/audit/approval/route.json`; other files refer to them instead of repeating the lists.
- **Examples are test vectors.** Every file under an `examples/` directory validates against its schema, and every file under an `invalid/` directory fails it, as `spec/README.md`'s conventions name the schema. Nothing but STS records goes in `spec/audit/examples/`, and nothing but the chain token's header and claims in `spec/claims/examples/`: the STS's contract tests read them.
- **Versions.** SemVer on `spec/vX.Y.Z` tags. An addition, such as a new reason or a new optional audit field, is a minor version; a rename, a removal or a tightened rule is a major one. Tag only when asked.
- **No GitLab root path** in spec files or documents: it changes at the swap to dev.

## Python

- **One uv workspace in `python/`,** one lock file, `python/uv.lock`, made with the uv that `required-version` names. Python 3.14. The core is `core/`: the distribution `agentic-agent-sdk`, the import package `agentic_sdk`. The ADK adapter is `adk/`: `agentic-agent-sdk-adk`, `agentic_sdk_adk`, which pins core `==` its own version when it is published.
- **The standard library first,** where it is reasonable. A new dependency needs its reason in the commit message, a range in its `pyproject.toml` and its exact version, with hashes, in `uv.lock`.
- **The core imports no agent framework:** not ADK, A2A, Starlette or a model provider's SDK. The MCP SDK only behind the `mcp` extra, imported when a step calls a tool. Adapters build on the core, and stay thin: what is not ADK-specific goes in the core.
- **The adapter supports the ADK minor ranges its `pyproject.toml` names,** tested against the versions `uv.lock` pins. A new ADK minor is a change of its own, with the adapter's tests run against it.
- **Contracts come from `spec/`,** through the core's copy in `agentic_sdk/_spec/`, which `python/core/tools/vendor_spec.py` writes. Never edit the copy by hand; a test fails when it differs from `spec/`.
- **Never log or record a token,** nor a tool call's arguments or result. An inbound token's refusal names its `spec/` reason in the log, never in the response.
- **Versions.** `python/vX.Y.Z` tags release both packages; `main` publishes dev builds of the next release, `X.Y.Z.devN`, from the `X.Y.Z.dev0` both `pyproject.toml` files declare. After a release, move both to the next version's `.dev0` in a merge request. Tag only when asked.

## Before committing

- Every JSON file parses: `python3 -c 'import json,sys; [json.load(open(f)) for f in sys.argv[1:]]' $(git ls-files '*.json')`.
- The schemas compile and every example validates: run the contract tests of `delegation-sts`'s interoperability suite against this checkout, as its `interop/README.md` describes.
- Those tests cover the STS's files only. For the rest, `uv run --locked tools/check_spec.py` compiles every `*.schema.json` as draft 2020-12, checks `examples/`, `invalid/` and `spec/vectors/` against their schemas with formats asserted, and compiles each step example's own schemas; its dependencies are pinned in `tools/check_spec.py.lock`. The token-profile vectors also pass a verifier that follows `spec/vectors/README.md`: the Python core's, in `python/core/tests/test_identity_vectors.py`.
- `python3 ../../architecture/tools/check_docs.py .` reports no problems.
- For `python/`: `uv lock --check` and `uv run --locked pytest`, from `python/`. For a change to `identity`, `delegation`, `clients`, `runtime`, `step` or the adapter, also `python/core/tests/integration.sh`, with Postgres for a change to the stores (`AGENTIC_TEST_DATABASE_URL`).
