# /// script
# requires-python = ">=3.14"
# dependencies = ["jsonschema[format-nongpl]==4.26.0"]
# ///
"""Checks spec/ as AGENTS.md asks, for every file the STS's contract tests
do not cover: every JSON file parses; every *.schema.json compiles as draft
2020-12; every file under an examples/ directory validates against its
schema, and every file under an invalid/ directory fails it, with formats
asserted; the token-profile vectors validate against their schema; and a
step definition's own input and output schemas compile.

Run from the repository root: uv run tools/check_spec.py [SPEC_DIR]
"""

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from referencing import Registry, Resource

# Directories that predate the <case>.<schema>.json rule (spec/README.md).
LEGACY = {
    "audit/examples": lambda name: "audit/sts-record.schema.json",
    "claims/examples": lambda name: (
        "claims/chain-token-header.schema.json"
        if name.endswith(".header.json")
        else "claims/chain-token.schema.json"
    ),
}


def main() -> int:
    spec = Path(sys.argv[1] if len(sys.argv) > 1 else "spec").resolve()
    problems: list[str] = []
    docs: dict[Path, object] = {}
    for path in sorted(spec.rglob("*.json")):
        try:
            docs[path] = json.loads(path.read_text(encoding="utf-8"))
        except (ValueError, UnicodeDecodeError) as e:
            problems.append(f"{path.relative_to(spec)}: does not parse: {e}")

    schemas = {p: d for p, d in docs.items() if p.name.endswith(".schema.json")}
    registry = Registry().with_resources(
        (p.as_uri(), Resource.from_contents(d)) for p, d in schemas.items()
    )
    for path, schema in schemas.items():
        try:
            Draft202012Validator.check_schema(schema)
        except SchemaError as e:
            problems.append(f"{path.relative_to(spec)}: not a valid schema: {e.message}")

    def validator(schema_path: Path) -> Draft202012Validator:
        return Draft202012Validator(
            {"$ref": schema_path.as_uri()},
            registry=registry,
            format_checker=Draft202012Validator.FORMAT_CHECKER,
        )

    checked = 0
    for path, doc in docs.items():
        rel = path.relative_to(spec)
        parent = rel.parent.as_posix()
        if parent in LEGACY:
            schema_path, expect_valid = spec / LEGACY[parent](path.name), True
        elif rel.parent.name in ("examples", "invalid"):
            kind = path.name.removesuffix(".json").rsplit(".", 1)
            if len(kind) != 2:
                problems.append(f"{rel}: not named <case>.<schema>.json")
                continue
            schema_path = path.parent.parent / f"{kind[1]}.schema.json"
            expect_valid = rel.parent.name == "examples"
        elif path.name.endswith(".json") and not path.name.endswith(".schema.json"):
            schema_path = path.with_name(path.name.removesuffix(".json") + ".schema.json")
            if not schema_path.exists():
                continue
            expect_valid = True
        else:
            continue
        if schema_path not in schemas:
            problems.append(f"{rel}: no schema {schema_path.relative_to(spec)}")
            continue
        errors = list(validator(schema_path).iter_errors(doc))
        checked += 1
        if expect_valid and errors:
            problems.append(f"{rel}: does not validate: {errors[0].message}")
        elif not expect_valid and not errors:
            problems.append(f"{rel}: validates, but must not")
        if expect_valid and not errors and path.name.endswith(".step.json"):
            for member in ("input_schema", "output_schema"):
                try:
                    Draft202012Validator.check_schema(doc[member])
                except SchemaError as e:
                    problems.append(f"{rel}: {member} is not a valid schema: {e.message}")

    for p in problems:
        print(p)
    print(f"{len(docs)} JSON files, {len(schemas)} schemas, {checked} instances checked, {len(problems)} problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
