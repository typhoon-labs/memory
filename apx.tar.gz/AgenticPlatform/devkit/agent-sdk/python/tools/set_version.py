"""Sets the version of both packages before a build that is published, and
pins the adapter to the core of the same version, so an adapter build
always installs the core it was built and tested with.

    python3 tools/set_version.py VERSION      (from python/)
    python3 tools/set_version.py --dev N      (from python/)

VERSION is a PEP 440 version: X.Y.Z on a python/vX.Y.Z tag, or X.Y.Z.devN.
Only the published copy changes; nothing is committed.

--dev N prints, and changes nothing, the version of main's dev build N:
the next release that both pyproject.toml files name, X.Y.Z.dev0, as
X.Y.Z.devN. After python/vA.B.C both name a later version's .dev0, so
every dev build sorts above the last release and below the next."""

import re
import sys
from pathlib import Path

PEP440 = re.compile(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(\.dev(0|[1-9][0-9]*))?")
DEV0 = re.compile(r"((?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*))\.dev0")
HERE = Path(__file__).resolve().parent.parent
PACKAGES = (HERE / "core" / "pyproject.toml", HERE / "adk" / "pyproject.toml")


def declared(path: Path) -> str:
    m = re.search(r'(?m)^version = "([^"]*)"$', path.read_text(encoding="utf-8"))
    if not m:
        sys.exit(f"{path}: no version line")
    return m.group(1)


def dev_version(n: str) -> str:
    versions = {declared(p) for p in PACKAGES}
    if len(versions) != 1:
        sys.exit(f"the packages declare different versions: {sorted(versions)}")
    (version,) = versions
    m = DEV0.fullmatch(version)
    if not m:
        sys.exit(f"pyproject.toml declares {version}; it must be the next release's X.Y.Z.dev0")
    if not re.fullmatch(r"0|[1-9][0-9]*", n):
        sys.exit(f"--dev {n!r}: not a build number")
    return f"{m.group(1)}.dev{n}"


def set_version(path: Path, version: str, pin_core: bool) -> None:
    text = path.read_text(encoding="utf-8")
    text, n = re.subn(r'(?m)^version = "[^"]*"$', f'version = "{version}"', text, count=1)
    if n != 1:
        sys.exit(f"{path}: no version line")
    if pin_core:
        text, n = re.subn(r'(?m)^  "agentic-agent-sdk",$', f'  "agentic-agent-sdk=={version}",', text, count=1)
        if n != 1:
            sys.exit(f"{path}: no unpinned agentic-agent-sdk dependency")
    path.write_text(text, encoding="utf-8")


def main() -> None:
    if len(sys.argv) == 3 and sys.argv[1] == "--dev":
        print(dev_version(sys.argv[2]))
        return
    if len(sys.argv) != 2 or not PEP440.fullmatch(sys.argv[1]):
        sys.exit("usage: set_version.py X.Y.Z[.devN] | set_version.py --dev N")
    version = sys.argv[1]
    set_version(PACKAGES[0], version, pin_core=False)
    set_version(PACKAGES[1], version, pin_core=True)
    print(f"agentic-agent-sdk and agentic-agent-sdk-adk set to {version}")


if __name__ == "__main__":
    main()
