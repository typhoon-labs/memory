# agentic-agent-sdk-adk

The platform's SDK for Google ADK agents: the import package `agentic_sdk_adk`, a thin adapter on the core, `agentic-agent-sdk` ([its README](../core/README.md)). It is tested against ADK 2.14.1 with `a2a-sdk` 1.3.1, `mcp` 2.3.0, `openai` 2.54.0 and `anthropic` 2.10.0, as `python/uv.lock` pins them. What ADK offers each part is in [the B5 desk check](../../../../architecture/research/2026-11-17-b5-desk-check.md#google-adk-2141).

| Module | Gives |
| --- | --- |
| `settings` | ADK's legacy content attributes off (`ADK_CAPTURE_MESSAGE_CONTENT_IN_SPANS=false`), GenAI content on spans only; applied when the package is imported, so import it before ADK. ADK's own cap on model calls kept above the workload's |
| `limits` | `LimitsPlugin`: every model call, tool call and response's tokens counted on the invocation's task, stopped at its caps |
| `models` | `gateway_openai(runtime, alias)`: `OpenAILlm` on the gateway's Chat Completions with a key callable that returns the invocation's token for the model route; `gateway_anthropic(runtime, model)`: `AnthropicLlm` whose client's transport sets that token. The provider's SDK retries a call at most 3 times, honouring `Retry-After`, and nothing else retries it |
| `tools` | `gateway_mcp(runtime, server, tool_filter=…)`: `McpToolset` on the gateway's route for the server, whose `header_provider` gives a token for that route alone |
| `a2a` | `a2a_app(agent, runtime)` and `serve(agent)`: the agent over A2A at `/a2a/<name>` (`AGENTIC_WORKLOAD_NAME`), its card at `/a2a/<name>/.well-known/agent-card.json`, both also at `/` for direct callers, its card naming the bearer scheme every call needs, behind inbound authentication and probes; each message a task with the workload's limits, wall time included, and a task they stop ends failed with the limit error as a data part. On SIGTERM, `serve` lets the tasks in flight end and flushes their spans before the process ends ([the core's shutdown](../core/README.md#shutdown)) |

```python
import agentic_sdk_adk  # before ADK
from google.adk.agents import LlmAgent

from agentic_sdk.runtime import Runtime
from agentic_sdk_adk.a2a import serve
from agentic_sdk_adk.models import gateway_openai
from agentic_sdk_adk.tools import gateway_mcp

runtime = Runtime()
agent = LlmAgent(
    name="reference_agent",
    model=gateway_openai(runtime, "fast-default"),
    instruction="Answer questions about notes.",
    tools=[gateway_mcp(runtime, "reference-mcp", tool_filter=["list_notes", "get_note"])],
)
# asyncio.run(serve(agent))
```

The caller's token reaches the key callable and the header provider through the core's invocation context, set per request by the inbound authentication. The tests prove it under concurrent callers through the real A2A app: every model and MCP call carries a token for its own person and route.

The caller's trace continues: the inbound `traceparent` is the parent of the task's spans, and every model and MCP request carries the trace in its `traceparent` header, which the gateway's tracing reads. MCP requests get it from their HTTP client's request hook, which copies the JSON-RPC message's `_meta` trace context into the header, since ADK keeps one MCP session per distinct set of headers and a per-call header in the header provider would open a session for every call.

**Parallel tool calls.** ADK 2.14 runs the function calls of one model response concurrently and cancels the rest of the batch when one raises. So a tool call past the `tool_calls` cap is answered with the limit's error instead of being made, the calls within the cap beside it finish and keep their effect, and the next model call ends the task with `limit_exceeded` ([`spec/limits/`](../../spec/limits/README.md)).
