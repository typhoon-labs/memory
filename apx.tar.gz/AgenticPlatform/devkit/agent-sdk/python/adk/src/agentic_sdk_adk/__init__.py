"""agentic_sdk_adk: the platform's SDK for Google ADK agents, on the core
(agentic_sdk). Import it before ADK, or call settings.apply() first: ADK
reads its content settings when it is imported.

- settings: ADK's content capture off, GenAI content on spans only
- limits: LimitsPlugin, the workload's caps on every model and tool call
- models: OpenAILlm and AnthropicLlm through the gateway, with the
  invocation's token for the model route
- tools: McpToolset through the gateway, with a token per MCP route
- a2a: an agent served over A2A behind inbound authentication, with the
  limit error on the A2A surface
"""

from . import settings

settings.apply()

__all__ = ["settings"]
