"""MCP servers through the gateway, as McpToolsets whose header_provider
gives each request a token for that server's route alone, exchanged for
the current invocation's caller, with the task's headers; and whose HTTP
client puts each request's trace context in its traceparent header."""

from __future__ import annotations

import json
from typing import Any

import httpx2
from opentelemetry import propagate
from google.adk.agents.readonly_context import ReadonlyContext
from google.adk.tools.mcp_tool import McpToolset, StreamableHTTPConnectionParams

from agentic_sdk.clients import headers_for
from agentic_sdk.runtime import Runtime


TRACE_HEADERS = ("traceparent", "tracestate")


async def trace_headers(request: httpx2.Request) -> None:
    """An httpx2 request hook: the request's W3C trace context in its
    traceparent (and tracestate) header, which the gateway's tracing and
    the server read. The JSON-RPC message's _meta holds the context of the
    call that sent it (the MCP SDK writes it there); a message without one
    takes the current context's."""
    carrier: dict[str, str] = {}
    try:
        message = json.loads(request.content)
        meta = message.get("params", {}).get("_meta") if isinstance(message, dict) else None
        if isinstance(meta, dict) and isinstance(meta.get("traceparent"), str):
            carrier = {k: meta[k] for k in TRACE_HEADERS if isinstance(meta.get(k), str)}
    except (httpx2.RequestNotRead, ValueError, AttributeError, TypeError):
        pass
    if not carrier:
        propagate.inject(carrier)
    for k in TRACE_HEADERS:
        if k in carrier:
            request.headers[k] = carrier[k]


def gateway_mcp(runtime: Runtime, server: str, *, tool_filter: list[str] | None = None, **toolset_args: Any) -> McpToolset:
    """McpToolset for the MCP server named server (its workload name), at
    <AGENTIC_GATEWAY_URL>/mcp/<server>. tool_filter keeps to the tools the
    agent's access file grants, so the model sees no other."""
    route = f"mcp/{server}"

    async def header_provider(_: ReadonlyContext) -> dict[str, str]:
        # Without traceparent: ADK keeps one MCP session per distinct set of
        # headers, so a per-call value here would open a session for every
        # call. The client's request hook (trace_headers) sets it instead.
        headers = await headers_for(runtime, route)
        headers.pop("traceparent", None)
        headers.pop("tracestate", None)
        return headers

    def client_factory(headers: dict[str, str] | None = None, timeout: httpx2.Timeout | None = None,
                       auth: httpx2.Auth | None = None) -> httpx2.AsyncClient:
        return httpx2.AsyncClient(headers=headers, auth=auth, verify=runtime.ssl_context(), trust_env=False,
                                  timeout=timeout or httpx2.Timeout(30.0, read=300.0),
                                  event_hooks={"request": [trace_headers]})

    params = StreamableHTTPConnectionParams(url=runtime.url(route), httpx_client_factory=client_factory)
    return McpToolset(connection_params=params, tool_filter=tool_filter, header_provider=header_provider, **toolset_args)
