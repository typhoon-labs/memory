"""An ADK agent served over A2A as the platform runs it: ADK's to_a2a app
behind the core's inbound authentication and probes, each message a task
with the workload's limits, and a task stopped by them ended as spec/limits'
a2a surface says: state failed, its final message holding the error object
as a data part beside a text part for people."""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from a2a.server.events import EventQueue
from a2a.types import HTTPAuthSecurityScheme, SecurityScheme, TaskStatusUpdateEvent
from google.adk.a2a import _compat
from google.adk.a2a.executor.a2a_agent_executor import A2aAgentExecutor
from google.adk.a2a.utils.agent_to_a2a import to_a2a
from google.adk.agents.base_agent import BaseAgent
from google.adk.apps import App
from google.adk.runners import Runner
from google.adk.sessions import BaseSessionService, InMemorySessionService
from google.adk.artifacts import InMemoryArtifactService
from google.adk.memory import InMemoryMemoryService
from google.adk.auth.credential_service.in_memory_credential_service import InMemoryCredentialService

from agentic_sdk import context
from agentic_sdk.limits import Caps, LimitExceeded, TaskLimits
from agentic_sdk.runtime import Runtime
from agentic_sdk.serve import DRAIN_SECONDS, IN_FLIGHT, prepare, workload_app

from . import settings
from .limits import LimitsPlugin

log = logging.getLogger("agentic_sdk_adk.a2a")


def _limit_status(e: LimitExceeded, task_id: str, context_id: str) -> TaskStatusUpdateEvent:
    message = _compat.make_message(
        message_id=str(uuid.uuid4()), role=_compat.ROLE_AGENT,
        parts=[_compat.make_text_part(e.message()), _compat.make_data_part(data=e.error())])
    return _compat.make_task_status_update_event(
        task_id=task_id, context_id=context_id,
        status=_compat.make_task_status(_compat.TS_FAILED, message=message), final=True)


class _Queue:
    """The executor's event queue, with the final failed status of a task its
    limits stopped replaced by the limit error's."""

    def __init__(self, inner: EventQueue, limits: TaskLimits, task_id: str, context_id: str):
        self.inner, self.limits, self.task_id, self.context_id = inner, limits, task_id, context_id
        self.final_sent = False

    async def enqueue_event(self, event: Any) -> None:
        if isinstance(event, TaskStatusUpdateEvent) and _is_final(event) and self.limits.stopped is not None \
                and event.status.state == _compat.TS_FAILED:
            event = _limit_status(self.limits.stopped, self.task_id, self.context_id)
        if isinstance(event, TaskStatusUpdateEvent) and _is_final(event):
            self.final_sent = True
        await self.inner.enqueue_event(event)

    def __getattr__(self, name: str) -> Any:
        return getattr(self.inner, name)


def _is_final(event: TaskStatusUpdateEvent) -> bool:
    final = getattr(event, "final", None)
    if final is not None:
        return bool(final)
    return event.status.state in (_compat.TS_FAILED, _compat.TS_COMPLETED, _compat.TS_CANCELED)


class LimitedExecutor(A2aAgentExecutor):
    """A2aAgentExecutor where each A2A message is a task for limits: counted
    by LimitsPlugin, bounded in wall time here, and ended with the limit
    error on the A2A surface when a limit stops it."""

    def __init__(self, *, runner: Runner, caps: Caps, **kw: Any):
        super().__init__(runner=runner, **kw)
        self.caps = caps

    async def execute(self, context_: Any, event_queue: EventQueue) -> None:
        inv = context.current()
        if inv is None:  # served without InboundAuth: no caller, so no task of ours
            raise context.NoInvocation("the A2A app must run behind the SDK's inbound authentication")
        limits = TaskLimits(self.caps, inv.task.task_id)
        queue = _Queue(event_queue, limits, context_.task_id, context_.context_id)
        # In flight until the run has unwound, after its answer: a shutdown
        # waits for it, so its last spans end before the flush (T31).
        with IN_FLIGHT.track(), context.use(inv.with_limits(limits)):
            try:
                await limits.bounded(super().execute(context_, queue))
            except LimitExceeded as e:  # wall time: the run was cancelled mid-flight
                if not queue.final_sent:
                    await event_queue.enqueue_event(_limit_status(e, context_.task_id, context_.context_id))


BEARER = "bearer"


def _security_schemes() -> dict[str, SecurityScheme]:
    return {BEARER: SecurityScheme(http_auth_security_scheme=HTTPAuthSecurityScheme(
        scheme="Bearer", bearer_format="JWT",
        description="A token for this agent's route on the gateway: a person's from the realm, or a chain token from the STS"))}


class CardSecurity:
    """Adds the card's top-level securityRequirements, which ADK's card
    builder leaves unset (it sets them per skill): every call needs the
    bearer scheme. Wraps the to_a2a app; only the card's GET is touched."""

    def __init__(self, app: Any, card_path: str):
        self.app, self.card_path = app, card_path

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] != "http" or scope.get("path") != self.card_path or scope.get("method") != "GET":
            return await self.app(scope, receive, send)
        start: dict[str, Any] = {}
        body = bytearray()

        async def capture(message):
            if message["type"] == "http.response.start":
                start.update(message)
            elif message["type"] == "http.response.body":
                body.extend(message.get("body", b""))

        await self.app(scope, receive, capture)
        data = bytes(body)
        if start.get("status") == 200:
            try:
                card = json.loads(data)
                card.setdefault("securityRequirements", [{"schemes": {BEARER: {}}}])
                data = json.dumps(card).encode()
            except ValueError:
                log.warning("agent card is not JSON; sent unchanged")
        headers = [(k, v) for k, v in start.get("headers", []) if k.lower() != b"content-length"]
        await send({**start, "headers": [*headers, (b"content-length", str(len(data)).encode())]})
        await send({"type": "http.response.body", "body": data})


def a2a_app(agent: BaseAgent, runtime: Runtime, *, session_service: BaseSessionService | None = None,
            plugins: list | None = None, **to_a2a_args: Any):
    """agent as an A2A Starlette app at /a2a/<name>, name being the workload's
    (AGENTIC_WORKLOAD_NAME): JSON-RPC there and the card at
    /a2a/<name>/.well-known/agent-card.json, as the gateway forwards them,
    and at / for direct callers; wrapped in the core's probes and inbound
    authentication (runtime.verifier). The caps are the workload file's,
    lowered by the environment; ADK's own cap on model calls is kept above
    them. The card's URL is the address served here; the gateway rewrites it.
    The card names the bearer scheme every call needs."""
    caps = runtime.caps()
    name = runtime.require_workload_name()
    settings.keep_adk_cap_above(caps.model_calls)
    runner = Runner(app=App(name=agent.name, root_agent=agent, plugins=[LimitsPlugin(), *(plugins or [])]),
                    session_service=session_service or InMemorySessionService(),
                    artifact_service=InMemoryArtifactService(), memory_service=InMemoryMemoryService(),
                    credential_service=InMemoryCredentialService())
    host, port = runtime.listen
    to_a2a_args.setdefault("security_schemes", _security_schemes())
    to_a2a_args.setdefault("default_skill_security", [{BEARER: []}])
    app = to_a2a(agent, host=host if host != "0.0.0.0" else "localhost", port=port, runner=runner,
                 rpc_path=f"a2a/{name}", agent_executor_factory=lambda r: LimitedExecutor(runner=r, caps=caps),
                 **to_a2a_args)
    return workload_app(CardSecurity(app, f"/a2a/{name}/.well-known/agent-card.json"), runtime.verifier, a2a_name=name)


async def serve(agent: BaseAgent, runtime: Runtime | None = None, **kw: Any) -> None:
    """Runs the A2A app with uvicorn on AGENTIC_LISTEN, after the core's
    prepare(): settings checked, the SDK's log lines on standard error,
    tracing set up and exported. On SIGTERM it stops taking requests,
    answers those in flight and lets their tasks end, within the core's
    drain period, then flushes the spans and audit records before the
    process ends (agentic_sdk.serve)."""
    import uvicorn

    runtime = runtime or Runtime()
    prepare(runtime)
    host, port = runtime.listen
    app = a2a_app(agent, runtime, **kw)

    class Server(uvicorn.Server):
        async def shutdown(self, sockets=None) -> None:
            # The drain period counts from here, where uvicorn starts waiting
            # for the requests in flight, not from the lifespan's shutdown.
            app.begin_shutdown()
            await super().shutdown(sockets)

    config = uvicorn.Config(app, host=host, port=port, lifespan="on", timeout_graceful_shutdown=int(DRAIN_SECONDS))
    await Server(config).serve()


__all__ = ["LimitedExecutor", "a2a_app", "serve"]
