"""The workload's limits as an ADK plugin: it counts the task's model calls,
tool calls and tokens (usage_metadata) on the invocation's TaskLimits, and
stops the task with the spec's limit_exceeded at the first check that fails.
A tool call past its cap is answered with the error, not made, and the next
model call ends the task, so the calls beside it in the same response finish.
Wall time is bounded around the whole run by the A2A executor (a2a.py)."""

from __future__ import annotations

from typing import Any

from google.adk.agents.callback_context import CallbackContext
from google.adk.models.llm_request import LlmRequest
from google.adk.models.llm_response import LlmResponse
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.tools.base_tool import BaseTool
from google.adk.tools.tool_context import ToolContext
from opentelemetry import trace

from agentic_sdk import context
from agentic_sdk.limits import LimitExceeded, TaskLimits, tokens_of
from agentic_sdk.telemetry import mark_limit_exceeded


def _limits() -> TaskLimits | None:
    inv = context.current()
    return inv.limits if inv is not None else None


def _stop(e: LimitExceeded) -> LimitExceeded:
    mark_limit_exceeded(trace.get_current_span())
    return e


class LimitsPlugin(BasePlugin):
    """Register on the Runner: plugins=[LimitsPlugin()]. A task without
    limits (no TaskLimits on its invocation) is not counted."""

    def __init__(self, name: str = "agentic_limits"):
        super().__init__(name)

    async def before_model_callback(self, *, callback_context: CallbackContext,
                                    llm_request: LlmRequest) -> LlmResponse | None:
        if (limits := _limits()) is not None:
            try:
                limits.before_model_call()
            except LimitExceeded as e:
                raise _stop(e) from None
        return None

    async def after_model_callback(self, *, callback_context: CallbackContext,
                                   llm_response: LlmResponse) -> LlmResponse | None:
        limits = _limits()
        usage = llm_response.usage_metadata
        if limits is None or usage is None or llm_response.partial:
            return None
        try:
            limits.after_model_response(tokens_of(usage.model_dump(exclude_none=True)))
        except LimitExceeded as e:
            raise _stop(e) from None
        return None

    async def before_tool_callback(self, *, tool: BaseTool, tool_args: dict[str, Any],
                                   tool_context: ToolContext) -> dict | None:
        if (limits := _limits()) is not None:
            try:
                limits.before_tool_call()
            except LimitExceeded as e:
                if e.limit == "wall_time_seconds":
                    raise _stop(e) from None
                # ADK 2.14 runs a response's function calls concurrently and
                # cancels the whole batch when one raises, which would take
                # the calls within the cap, in flight beside this one, down
                # with it. So this call is answered with the error instead of
                # being made; the task is stopped (limits.stopped), and the
                # next model call ends it with limit_exceeded.
                _stop(e)
                return e.error()
        return None
