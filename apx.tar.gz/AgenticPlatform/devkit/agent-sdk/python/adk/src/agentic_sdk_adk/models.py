"""Models through the gateway's model route, with no provider key: each
request carries a token for the route, exchanged for the current
invocation's caller, and the task's headers and trace context. Always
construct the model object: a bare "claude-*" string resolves to ADK's
Vertex-only Claude class."""

from __future__ import annotations

import httpx
import httpx2
from anthropic import AsyncAnthropic
from google.adk.integrations.openai import OpenAILlm
from google.adk.models.anthropic_llm import AnthropicLlm
from openai import AsyncOpenAI

from agentic_sdk import context
from agentic_sdk.runtime import Runtime

MODEL_ROUTE = "v1"
# Retries of one model call by the provider's SDK, which honours
# Retry-After: so a call makes at most four attempts, and counts once
# for limits (spec/limits). Nothing else retries a model call.
MAX_RETRIES = 3


def _client(runtime: Runtime) -> httpx.AsyncClient:
    async def headers(request: httpx.Request) -> None:
        for k, v in context.outbound_headers().items():
            request.headers[k] = v

    return httpx.AsyncClient(verify=runtime.ssl_context(), trust_env=False, event_hooks={"request": [headers]},
                             timeout=httpx.Timeout(600.0, connect=10.0))


def gateway_openai(runtime: Runtime, model: str, *, route: str = MODEL_ROUTE, max_tokens: int = 4096) -> OpenAILlm:
    """OpenAILlm on the gateway's Chat Completions, model being an alias
    (fast-default). The key callable returns the invocation's token for the
    model route, which AsyncOpenAI asks for on every request."""

    async def key() -> str:
        return await runtime.token_for(route)

    client = AsyncOpenAI(base_url=runtime.url(route), api_key=key, http_client=_client(runtime), max_retries=MAX_RETRIES)
    return OpenAILlm(model=model, max_tokens=max_tokens, client=client)


class _Bearer(httpx2.Auth):
    """The model route's token as a bearer, in place of Anthropic's x-api-key."""

    def __init__(self, runtime: Runtime, route: str):
        self.runtime, self.route = runtime, route

    async def async_auth_flow(self, request: httpx2.Request):
        request.headers.pop("x-api-key", None)
        request.headers["Authorization"] = f"Bearer {await self.runtime.token_for(self.route)}"
        for k, v in context.outbound_headers().items():
            request.headers[k] = v
        yield request


def gateway_anthropic(runtime: Runtime, model: str, *, route: str = MODEL_ROUTE, max_tokens: int = 8192) -> AnthropicLlm:
    """AnthropicLlm on the gateway's Messages API, for an agent that needs
    Claude-specific features; the client's transport sets the token. The
    Anthropic SDK 2.x runs on httpx2."""
    http = httpx2.AsyncClient(verify=runtime.ssl_context(), trust_env=False, auth=_Bearer(runtime, route),
                              timeout=httpx2.Timeout(600.0, connect=10.0))
    client = AsyncAnthropic(base_url=runtime.url(route).removesuffix("/v1"), api_key="unused", http_client=http,
                            max_retries=MAX_RETRIES)
    return AnthropicLlm(model=model, max_tokens=max_tokens, client=client)
