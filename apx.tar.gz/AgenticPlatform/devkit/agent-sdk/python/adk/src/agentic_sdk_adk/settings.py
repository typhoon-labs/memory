"""Telemetry settings for ADK (B5 desk check, Google ADK 2.14.1): ADK's
legacy content attributes (gcp.vertex.agent.llm_request and the like) off,
and GenAI content on spans only, never in log events. Set before ADK is
imported, without overriding what the environment already says, except the
legacy capture, which the platform requires off."""

from __future__ import annotations

import os

from agentic_sdk.telemetry import CONTENT_ENVIRONMENT

ENVIRONMENT = {"ADK_CAPTURE_MESSAGE_CONTENT_IN_SPANS": "false", **CONTENT_ENVIRONMENT}


def apply() -> None:
    os.environ["ADK_CAPTURE_MESSAGE_CONTENT_IN_SPANS"] = "false"
    for k, v in CONTENT_ENVIRONMENT.items():
        os.environ.setdefault(k, v)


def keep_adk_cap_above(model_calls: int | None) -> None:
    """ADK's own cap on model calls per run (ADK_MAX_LLM_CALLS, 500 by default)
    is kept above the workload's, so the declared cap is the one that stops a
    task and the error is the spec's."""
    if model_calls is None:
        return
    current = int(os.environ.get("ADK_MAX_LLM_CALLS", "500") or 500)
    if current <= model_calls:
        os.environ["ADK_MAX_LLM_CALLS"] = str(model_calls + 1)
