"""A local stack for the adapter's tests: a gateway stand-in that sends the
model route to the fake model and an MCP route to an MCP server, both
recording the credentials and task IDs they see, and the agent's A2A app,
each on uvicorn in a thread of its own."""

from __future__ import annotations

import base64
import json
import socket
import threading
import time
import uuid
from dataclasses import dataclass, field

import httpx
import uvicorn


def free_port() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def claims(token: str) -> dict:
    part = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))


@dataclass
class Seen:
    model: list[tuple[str, str]] = field(default_factory=list)  # (authorization, task id)
    mcp: list[tuple[str, str, str]] = field(default_factory=list)  # (authorization, task id, method)
    traces: list[tuple[str, str, str]] = field(default_factory=list)  # (route, task id, traceparent header)


def gateway_app(model_url: str, seen: Seen, *, jwks: dict | None = None, sts=None):
    """jwks, when given, is served at /jwks; sts, an Issuer, answers token
    exchanges at /sts/token as a stand-in STS, with chain tokens for the
    subject's sub and the request's resource."""
    from mcp.server.mcpserver import MCPServer
    from mcp.types import ToolAnnotations

    server = MCPServer("reference-mcp")

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def list_notes() -> str:
        """Lists the notes."""
        return "note-1: rotate the keys"

    mcp_app = server.streamable_http_app(streamable_http_path="/mcp/reference-mcp", stateless_http=True, json_response=True)

    async def app(scope, receive, send):
        if scope["type"] == "lifespan":
            return await mcp_app(scope, receive, send)
        h = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        body = b""
        while True:
            m = await receive()
            body += m.get("body", b"")
            if not m.get("more_body"):
                break
        if scope["path"] == "/jwks" and jwks is not None:
            data = json.dumps(jwks).encode()
            await send({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"application/json")]})
            await send({"type": "http.response.body", "body": data})
            return
        if scope["path"] == "/sts/token" and sts is not None:
            import urllib.parse
            form = dict(urllib.parse.parse_qsl(body.decode()))
            tok = sts.chain(claims(form["subject_token"])["sub"], form["resource"], "agentic-local/reference-agent/reference-agent")
            data = json.dumps({"access_token": tok, "issued_token_type": "urn:ietf:params:oauth:token-type:access_token",
                               "token_type": "Bearer", "expires_in": 300}).encode()
            await send({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"application/json")]})
            await send({"type": "http.response.body", "body": data})
            return
        if scope["path"].startswith("/v1/"):
            seen.model.append((h.get("authorization", ""), h.get("agentic-task-id", "")))
            seen.traces.append(("v1", h.get("agentic-task-id", ""), h.get("traceparent", "")))
            async with httpx.AsyncClient(trust_env=False) as c:
                fwd = {k: v for k, v in h.items() if k in ("content-type", "anthropic-version", "anthropic-beta")}
                r = await c.post(model_url + scope["path"], content=body, headers=fwd, timeout=60)
            back = [(k.encode(), v.encode()) for k, v in r.headers.items() if k in ("content-type", "retry-after")]
            await send({"type": "http.response.start", "status": r.status_code, "headers": back})
            await send({"type": "http.response.body", "body": r.content})
            return
        try:
            method = json.loads(body).get("method", "")
        except ValueError:
            method = ""
        seen.mcp.append((h.get("authorization", ""), h.get("agentic-task-id", ""), method))
        seen.traces.append((f"mcp {method}", h.get("agentic-task-id", ""), h.get("traceparent", "")))
        sent = False

        async def replay():
            nonlocal sent
            if sent:
                return {"type": "http.disconnect"}
            sent = True
            return {"type": "http.request", "body": body, "more_body": False}

        await mcp_app(scope, replay, send)

    return app


class Server:
    def __init__(self, app, port: int | None = None):
        self.port = port or free_port()
        self.server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=self.port, log_level="warning",
                                                    lifespan="on"))
        self.thread = threading.Thread(target=self.server.run, daemon=True)
        self.thread.start()
        for _ in range(200):
            if self.server.started:
                break
            time.sleep(0.05)
        self.url = f"http://127.0.0.1:{self.port}"

    def stop(self):
        self.server.should_exit = True
        self.thread.join(10)


def send_message(url: str, token: str, text: str, task_id: str | None = None, timeout: float = 60, path: str = "/") -> dict:
    body = {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {
        "messageId": str(uuid.uuid4()), "role": "ROLE_USER", "parts": [{"text": text}]}}}
    headers = {"Authorization": f"Bearer {token}", "A2A-Version": "1.0"}
    if task_id:
        headers["Agentic-Task-Id"] = task_id
    r = httpx.post(url + path, json=body, headers=headers, timeout=timeout, trust_env=False)
    return {"status": r.status_code, "body": r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text}


async def asend_message(client: httpx.AsyncClient, url: str, token: str, text: str, task_id: str,
                        path: str = "/a2a/reference-agent") -> dict:
    body = {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {
        "messageId": str(uuid.uuid4()), "role": "ROLE_USER", "parts": [{"text": text}]}}}
    r = await client.post(url + path, json=body, timeout=60, headers={
        "Authorization": f"Bearer {token}", "A2A-Version": "1.0", "Agentic-Task-Id": task_id})
    return {"status": r.status_code, "body": r.json()}
