import sys
from pathlib import Path

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor

# The core's test helpers: the test issuer, the fake model, the STS harness.
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "core" / "tests"))

def pytest_configure(config):
    from adk_spans import SPANS
    from agentic_sdk import telemetry

    provider = trace.get_tracer_provider()
    if not isinstance(provider, TracerProvider):
        provider = TracerProvider()
        trace.set_tracer_provider(provider)
    provider.add_span_processor(telemetry.InvocationSpanProcessor())
    provider.add_span_processor(SimpleSpanProcessor(telemetry.RedactingSpanExporter(SPANS)))

@pytest.fixture
def anyio_backend():
    return "asyncio"
