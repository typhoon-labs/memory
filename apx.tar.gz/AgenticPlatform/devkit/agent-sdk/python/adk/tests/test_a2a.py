"""The adapter end to end: an ADK agent served by a2a_app, its model and
MCP calls through a gateway stand-in to the fake model and an MCP server,
its tokens from an STS stand-in (or the real STS, test_sts.py)."""

import asyncio
import json

import httpx
import pytest

import agentic_sdk_adk  # noqa: F401  (settings before ADK)
from google.adk.agents import LlmAgent

from agentic_sdk import contract
from agentic_sdk.delegation import Exchanger
from agentic_sdk.identity import KEYCLOAK, IssuerTrust, StaticKeys, Verifier
from agentic_sdk.runtime import Runtime
from agentic_sdk_adk.a2a import a2a_app
from agentic_sdk_adk.models import gateway_openai
from agentic_sdk_adk.tools import gateway_mcp

from adk_spans import SPANS
from fake_model import fake_model  # noqa: F401
from issuer import Issuer
from stack import Seen, Server, asend_message, claims, gateway_app, send_message
from test_delegation import FakeSTS

KC = Issuer("https://keycloak.agentic.internal/realms/agentic")
ROUTE = "https://gateway.agentic.internal/a2a/reference-agent"
BASE = "https://workloads-gateway.agentic.internal"
WORKLOAD = {"name": "reference-agent", "kind": "agent", "runtime": "container", "owner": "reference",
            "support": "experimental", "limits": {"model_calls": 10, "tool_calls": 20, "tokens": 100000, "wall_time_seconds": 120}}


@pytest.fixture(scope="module")
def gateway(fake_model):  # noqa: F811
    seen = Seen()
    server = Server(gateway_app(fake_model, seen))
    yield server.url, seen
    server.stop()


def agent_server(tmp_path, gateway_url, env=None, sts=None, person_issuer=KC):
    """The agent's A2A app; its tokens from an STS stand-in, or from sts, a
    real STS (sts_harness), whose Keycloak stand-in then signs people's tokens."""
    wf = tmp_path / "workload.yaml"
    wf.write_text(json.dumps(WORKLOAD))
    (tmp_path / "actor").write_text(sts.actor_token() if sts else KC.token(sub="system:serviceaccount:reference-agent:reference-agent"))
    sts_env = {"AGENTIC_STS_TOKEN_ENDPOINT": sts.token_endpoint, "AGENTIC_CA_FILE": sts.ca_file} if sts else {
        "AGENTIC_STS_TOKEN_ENDPOINT": "https://sts/token"}
    rt = Runtime(environ={"AGENTIC_GATEWAY_URL": gateway_url, "AGENTIC_RESOURCE_BASE": BASE, **sts_env,
                          "AGENTIC_ACTOR_TOKEN_FILE": str(tmp_path / "actor"), **(env or {})}, workload_file=str(wf))
    rt.__dict__["verifier"] = Verifier([IssuerTrust(person_issuer.iss, KEYCLOAK, StaticKeys(person_issuer.jwks()), ROUTE)])
    exchanger = None if sts is None else rt.exchanger
    if exchanger is None:
        sts = FakeSTS()
        client = httpx.AsyncClient(transport=httpx.MockTransport(sts.handler))
        exchanger = Exchanger("https://sts/token", lambda: (tmp_path / "actor").read_text(), lambda: client)
    rt.__dict__["exchanger"] = exchanger
    agent = LlmAgent(name="reference_agent", model=gateway_openai(rt, "fast-default"),
                     instruction="Answer questions about notes.", tools=[gateway_mcp(rt, "reference-mcp")])
    return Server(a2a_app(agent, rt)), rt


def final(resp: dict) -> dict:
    task = resp["body"]["result"]["task"]
    return task["status"]


def test_people_keep_their_own_tokens_under_concurrency(tmp_path, gateway):
    gw, seen = gateway
    server, rt = agent_server(tmp_path, gw, {"AGENTIC_LIMIT_MODEL_CALLS": "3"})
    people = {f"person-{i}": KC.person(f"person-{i}", ROUTE) for i in range(12)}

    async def go():
        async with httpx.AsyncClient(trust_env=False) as c:
            return await asyncio.gather(*(
                asend_message(c, server.url, tok, f"[[fake-model id={name}-x tool=list_notes delay=100ms]] notes?",
                              f"task-{name}") for name, tok in people.items()))

    try:
        results = asyncio.run(go())
    finally:
        server.stop()
    assert all(r["status"] == 200 for r in results)
    by_task = {f"task-{n}": n for n in people}
    model = [(by_task[t], claims(a.removeprefix("Bearer "))) for a, t in seen.model if t in by_task]
    mcp = [(by_task[t], claims(a.removeprefix("Bearer "))) for a, t, _ in seen.mcp if t in by_task]
    assert len(model) == 3 * len(people) and len(mcp) >= 2 * len(people)
    assert all(c["sub"] == who and c["aud"] == f"{BASE}/v1" for who, c in model)
    assert all(c["sub"] == who and c["aud"] == f"{BASE}/mcp/reference-mcp" for who, c in mcp)
    assert rt.exchanger.exchanges == 2 * len(people)  # one per person and route, cached across calls


@pytest.mark.parametrize("env,directive,limit", [
    ({"AGENTIC_LIMIT_MODEL_CALLS": "2"}, "tool=list_notes", "model_calls"),
    ({"AGENTIC_LIMIT_TOOL_CALLS": "1"}, "tool=list_notes", "tool_calls"),
    ({"AGENTIC_LIMIT_TOKENS": "200"}, "tokens=400", "tokens"),
    ({"AGENTIC_LIMIT_WALL_TIME_SECONDS": "1"}, "delay=3s", "wall_time_seconds"),
])
def test_limits_end_the_task_with_the_spec_error(tmp_path, gateway, env, directive, limit):
    gw, _ = gateway
    server, _ = agent_server(tmp_path, gw, env)
    SPANS.clear()
    try:
        resp = send_message(server.url, KC.person("ana", ROUTE), f"[[fake-model id=lim-{limit} {directive}]] go",
                            task_id=f"lim-{limit}")
    finally:
        server.stop()
    status = final(resp)
    assert status["state"] == "TASK_STATE_FAILED", status
    parts = status["message"]["parts"]
    data = [p["data"] for p in parts if "data" in p]
    assert data and data[0]["error"] == "limit_exceeded" and data[0]["limit"] == limit, parts
    assert data[0]["task_id"] == f"lim-{limit}"
    err = {k: (int(v) if isinstance(v, float) else v) for k, v in data[0].items()}
    assert contract.first_error("limits/error.schema.json", err) is None
    assert any("text" in p for p in parts)
    task_spans = [s for s in SPANS.get_finished_spans() if s.name.startswith("invoke_agent")]
    assert task_spans and all(s.status.status_code.name == "ERROR" and s.attributes["error.type"] == "limit_exceeded"
                              for s in task_spans), [(s.name, dict(s.attributes)) for s in task_spans]


def test_no_token_no_task(tmp_path, gateway):
    gw, _ = gateway
    server, _ = agent_server(tmp_path, gw)
    try:
        assert send_message(server.url, "junk", "hi")["status"] == 401
        assert send_message(server.url, KC.person("ana", "https://gateway.agentic.internal/a2a/other"), "hi")["status"] == 401
        for card_path in ("/.well-known/agent-card.json", "/a2a/reference-agent/.well-known/agent-card.json"):
            card = httpx.get(server.url + card_path, trust_env=False)
            assert card.status_code == 200 and card.json()["name"] == "reference_agent"
            c = card.json()
            assert c["securitySchemes"]["bearer"]["httpAuthSecurityScheme"]["scheme"] == "Bearer"
            assert c["securityRequirements"] == [{"schemes": {"bearer": {}}}]
            assert [i["protocolVersion"] for i in c["supportedInterfaces"]] == ["1.0"]
        assert send_message(server.url, "junk", "hi", path="/a2a/reference-agent")["status"] == 401
        ok = send_message(server.url, KC.person("ana", ROUTE), "[[fake-model tokens=3]] hi", path="/a2a/reference-agent")
        assert final(ok)["state"] == "TASK_STATE_COMPLETED"
        assert httpx.get(server.url + "/healthz", trust_env=False).status_code == 200
    finally:
        server.stop()


def test_a_response_past_the_token_cap_starts_no_tool(tmp_path, gateway):
    gw, seen = gateway
    server, _ = agent_server(tmp_path, gw, {"AGENTIC_LIMIT_TOKENS": "5"})
    try:
        resp = send_message(server.url, KC.person("ana", ROUTE), "[[fake-model id=tok-tool tool=list_notes]] notes",
                            task_id="tok-tool", path="/a2a/reference-agent")
    finally:
        server.stop()
    data = [p["data"] for p in final(resp)["message"]["parts"] if "data" in p]
    assert data[0]["limit"] == "tokens"
    assert not [m for _, t, m in seen.mcp if t == "tok-tool" and m == "tools/call"]


def test_limits_on_adks_extension_path(tmp_path, gateway):
    """A client that asks for ADK's own A2A extension runs ADK's other
    executor; a limit still ends the task failed with the data part."""
    gw, _ = gateway
    server, _ = agent_server(tmp_path, gw, {"AGENTIC_LIMIT_MODEL_CALLS": "1"})
    try:
        body = {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {
            "messageId": "m-ext", "role": "ROLE_USER", "parts": [{"text": "[[fake-model tool=list_notes]] go"}]}}}
        r = httpx.post(server.url + "/a2a/reference-agent", json=body, timeout=60, trust_env=False, headers={
            "Authorization": f"Bearer {KC.person('ana', ROUTE)}", "A2A-Version": "1.0", "Agentic-Task-Id": "ext-1",
            "A2A-Extensions": "https://google.github.io/adk-docs/a2a/a2a-extension/"})
    finally:
        server.stop()
    status = r.json()["result"]["task"]["status"]
    assert status["state"] == "TASK_STATE_FAILED", status
    data = [p["data"] for p in status["message"]["parts"] if "data" in p]
    assert data and data[0]["limit"] == "model_calls"


def test_the_callers_trace_continues_on_every_call(tmp_path, gateway):
    """The inbound traceparent is the parent of the task's spans, and its
    trace reaches the gateway in the traceparent header of every model and
    MCP request, the header the gateway's own tracing reads; MCP's _meta
    carries it too, but the gateway does not look there."""
    gw, seen = gateway
    # The directive asks for list_notes on every turn: two model calls and
    # one tool call between them, then the model-call cap ends the task.
    server, _ = agent_server(tmp_path, gw, {"AGENTIC_LIMIT_MODEL_CALLS": "2"})
    SPANS.clear()
    trace_id, span_id = "0af7651916cd43dd8448eb211c80319c", "b7ad6b7169203331"
    body = {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {
        "messageId": "m-trace", "role": "ROLE_USER", "parts": [{"text": "[[fake-model id=trace-1 tool=list_notes]] notes?"}]}}}
    try:
        r = httpx.post(server.url + "/a2a/reference-agent", json=body, timeout=60, trust_env=False, headers={
            "Authorization": f"Bearer {KC.person('ana', ROUTE)}", "A2A-Version": "1.0",
            "Agentic-Task-Id": "task-trace", "traceparent": f"00-{trace_id}-{span_id}-01"})
    finally:
        server.stop()
    assert r.status_code == 200, r.text
    calls = [(route, tp) for route, task, tp in seen.traces if task == "task-trace"]
    assert any(route == "v1" for route, _ in calls) and any(route == "mcp tools/call" for route, _ in calls), calls
    assert all(tp.split("-")[1:2] == [trace_id] for _, tp in calls), calls
    # The header is set per request, outside the header set ADK keys its
    # MCP sessions by: still one session for the task.
    assert sum(route == "mcp initialize" for route, _ in calls) == 1, calls
    spans = [s for s in SPANS.get_finished_spans() if s.name.startswith("invoke_agent")]
    assert spans and all(format(s.context.trace_id, "032x") == trace_id for s in spans)
