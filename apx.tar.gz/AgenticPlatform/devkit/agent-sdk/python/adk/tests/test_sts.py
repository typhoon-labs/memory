"""The adapter with the real delegation STS (sts_harness): concurrent people
through the A2A app, every token at the gateway a chain token the STS signed
for that person and that route."""

import asyncio

import httpx
import pytest

from agentic_sdk.identity import CHAIN, IssuerTrust, JwksCache, Verifier

from fake_model import fake_model  # noqa: F401
from sts_harness import AGENT, sts  # noqa: F401
from stack import asend_message
from test_a2a import BASE, ROUTE, agent_server, gateway  # noqa: F401


def test_chain_tokens_from_the_real_sts(tmp_path, gateway, sts):  # noqa: F811
    gw, seen = gateway
    server, rt = agent_server(tmp_path, gw, {"AGENTIC_LIMIT_MODEL_CALLS": "2"}, sts=sts, person_issuer=sts.keycloak)
    people = {f"sts-person-{i}": sts.person(f"sts-person-{i}") for i in range(8)}

    async def go():
        async with httpx.AsyncClient(trust_env=False) as c:
            return await asyncio.gather(*(asend_message(c, server.url, tok, f"[[fake-model id={n} tool=list_notes]] q", f"t-{n}")
                                          for n, tok in people.items()))

    try:
        assert all(r["status"] == 200 for r in asyncio.run(go()))
    finally:
        server.stop()

    async def verify_all():
        out = []
        async with httpx.AsyncClient(verify=rt.ssl_context(), trust_env=False) as http:
            for route, records in (("v1", [(a, t) for a, t in seen.model]), ("mcp/reference-mcp", [(a, t) for a, t, _ in seen.mcp])):
                v = Verifier([IssuerTrust(sts.issuer, CHAIN, JwksCache(sts.issuer + "/jwks", lambda: http), f"{BASE}/{route}")])
                for auth, task in records:
                    if task.startswith("t-sts-person-"):
                        p = await v.verify(auth.removeprefix("Bearer "))
                        out.append((task.removeprefix("t-"), p.user_id, p.actor_sub))
        return out

    checked = asyncio.run(verify_all())
    assert len(checked) >= 3 * len(people)
    assert all(who == sub and actor == AGENT for who, sub, actor in checked)
