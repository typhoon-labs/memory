"""Parallel tool calls in one model response: each is counted before it
starts, so a tool_calls cap of 2 lets two of three run and never starts
the third."""

import asyncio

import pytest

import agentic_sdk_adk  # noqa: F401
from google.adk.agents import LlmAgent
from google.adk.apps import App
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from agentic_sdk import context, headers
from agentic_sdk.limits import Caps, TaskLimits
from agentic_sdk_adk.limits import LimitsPlugin

started: list[str] = []


def lookup(key: str) -> str:
    """Looks a key up."""
    started.append(key)
    return f"value of {key}"


class ThreeCalls(BaseLlm):
    model: str = "three-calls"

    async def generate_content_async(self, llm_request, stream=False):
        parts = [types.Part(function_call=types.FunctionCall(name="lookup", args={"key": k}, id=f"c{k}")) for k in "abc"]
        yield LlmResponse(content=types.Content(role="model", parts=parts),
                          usage_metadata=types.GenerateContentResponseUsageMetadata(total_token_count=10))


def test_the_third_parallel_call_never_starts():
    agent = LlmAgent(name="parallel", model=ThreeCalls(), tools=[lookup])
    runner = Runner(app=App(name="parallel", root_agent=agent, plugins=[LimitsPlugin()]),
                    session_service=InMemorySessionService())
    limits = TaskLimits(Caps(model_calls=2, tool_calls=2), "t-par")

    async def go():
        session = await runner.session_service.create_session(app_name="parallel", user_id="u")
        with context.use(context.Invocation(task=headers.TaskHeaders("t-par"), limits=limits)):
            try:
                async for _ in runner.run_async(user_id="u", session_id=session.id,
                                                new_message=types.Content(role="user", parts=[types.Part(text="go")])):
                    pass
            except Exception:
                pass

    asyncio.run(go())
    assert limits.stopped is not None and (limits.stopped.limit, limits.stopped.used) == ("tool_calls", 2)
    assert limits.model_calls == 1 and limits.tool_calls == 2
    assert len(started) == 2 and "c" not in started


finished: list[str] = []


async def slow_lookup(key: str) -> str:
    """Looks a key up, taking a while, as an MCP call through the gateway does."""
    await asyncio.sleep(0.3)
    finished.append(key)
    return f"value of {key}"


class ThreeSlowCalls(BaseLlm):
    model: str = "three-slow-calls"

    async def generate_content_async(self, llm_request, stream=False):
        parts = [types.Part(function_call=types.FunctionCall(name="slow_lookup", args={"key": k}, id=f"s{k}"))
                 for k in "abc"]
        yield LlmResponse(content=types.Content(role="model", parts=parts),
                          usage_metadata=types.GenerateContentResponseUsageMetadata(total_token_count=10))


def test_the_calls_within_the_cap_complete_beside_the_refused_one():
    """ADK 2.14 runs a response's function calls concurrently and cancels
    the batch when one raises: the call past the cap must not take the
    calls within it, already in flight, down with it (spec/limits: a
    finished call keeps its effect; the call past the cap is not made)."""
    finished.clear()
    agent = LlmAgent(name="parallel_slow", model=ThreeSlowCalls(), tools=[slow_lookup])
    runner = Runner(app=App(name="parallel_slow", root_agent=agent, plugins=[LimitsPlugin()]),
                    session_service=InMemorySessionService())
    limits = TaskLimits(Caps(model_calls=2, tool_calls=2), "t-par-slow")
    error: list[BaseException] = []

    async def go():
        session = await runner.session_service.create_session(app_name="parallel_slow", user_id="u")
        with context.use(context.Invocation(task=headers.TaskHeaders("t-par-slow"), limits=limits)):
            try:
                async for _ in runner.run_async(user_id="u", session_id=session.id,
                                                new_message=types.Content(role="user", parts=[types.Part(text="go")])):
                    pass
            except Exception as e:
                error.append(e)

    asyncio.run(go())
    assert limits.stopped is not None and (limits.stopped.limit, limits.stopped.cap, limits.stopped.used) == ("tool_calls", 2, 2)
    assert limits.tool_calls == 2
    assert len(finished) == 2, f"the calls within the cap were cancelled: finished {finished}"
    # The task ends at the next model call, which is not made.
    assert limits.model_calls == 1
    assert error, "the run ended without the limit's error"
