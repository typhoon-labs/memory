"""The adapter's model classes through the gateway, and its telemetry settings."""

import asyncio
import os

import httpx
import pytest

import agentic_sdk_adk  # noqa: F401
from google.adk.models.llm_request import LlmRequest
from google.genai import types

from agentic_sdk import context, headers
from agentic_sdk.runtime import Runtime
from agentic_sdk_adk import settings
from agentic_sdk_adk.models import gateway_anthropic, gateway_openai

from adk_spans import SPANS
from fake_model import fake_model  # noqa: F401
from stack import Seen, Server, claims, gateway_app


class Tokens:
    exchanges = 0

    async def token(self, subject, resource):
        self.exchanges += 1
        return f"tok-for-{subject}-{resource.rsplit('/', 1)[-1]}"


@pytest.fixture(scope="module")
def gateway(fake_model):  # noqa: F811
    seen = Seen()
    server = Server(gateway_app(fake_model, seen))
    yield server.url, seen
    server.stop()


def runtime(url):
    rt = Runtime(environ={"AGENTIC_GATEWAY_URL": url, "AGENTIC_RESOURCE_BASE": "https://workloads-gateway.agentic.internal"})
    rt.__dict__["exchanger"] = Tokens()
    return rt


def ask(llm, text, who, task):
    async def go():
        req = LlmRequest(model=llm.model, contents=[types.Content(role="user", parts=[types.Part(text=text)])])
        with context.use(context.Invocation(task=headers.TaskHeaders(task), token=who)):
            return [r async for r in llm.generate_content_async(req)]
    return asyncio.run(go())


def test_openai_through_the_gateway(gateway):
    url, seen = gateway
    out = ask(gateway_openai(runtime(url), "fast-default"), "[[fake-model tokens=7]] hi", "alice", "m-openai")
    assert out[-1].usage_metadata.total_token_count > 0
    assert ("Bearer tok-for-alice-v1", "m-openai") in seen.model


def test_anthropic_through_the_gateway(gateway):
    url, seen = gateway
    out = ask(gateway_anthropic(runtime(url), "claude-default"), "[[fake-model tokens=5]] hi", "bob", "m-anthropic")
    assert out[-1].content.parts[0].text
    assert ("Bearer tok-for-bob-v1", "m-anthropic") in seen.model


def test_content_settings():
    assert os.environ["ADK_CAPTURE_MESSAGE_CONTENT_IN_SPANS"] == "false"
    assert os.environ["OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"] == "SPAN_ONLY"
    assert os.environ["OTEL_SEMCONV_STABILITY_OPT_IN"] == "gen_ai_latest_experimental"
    os.environ.pop("ADK_MAX_LLM_CALLS", None)
    settings.keep_adk_cap_above(10)
    assert "ADK_MAX_LLM_CALLS" not in os.environ
    settings.keep_adk_cap_above(800)
    assert os.environ.pop("ADK_MAX_LLM_CALLS") == "801"


def test_spans_carry_genai_content_not_adk_legacy_content(gateway):
    url, _ = gateway
    SPANS.clear()
    ask(gateway_openai(runtime(url), "fast-default"), "marker-41 [[fake-model tokens=3]]", "carol", "m-content")
    attrs = [dict(s.attributes) for s in SPANS.get_finished_spans()]
    assert not any(k.startswith("gcp.vertex.agent.llm_") or k.startswith("gcp.vertex.agent.tool_") for a in attrs for k in a)


def test_a_model_call_retries_at_most_three_times_honouring_retry_after(gateway):
    import time

    url, seen = gateway
    llm = gateway_openai(runtime(url), "fast-default")
    t0 = time.monotonic()
    out = ask(llm, "[[fake-model id=retry-ok status=429 retry-after=1 times=2]] hi", "dora", "m-retry-ok")
    assert out[-1].usage_metadata.total_token_count > 0 and time.monotonic() - t0 >= 1.8
    assert sum(1 for _, t in seen.model if t == "m-retry-ok") == 3
    with pytest.raises(Exception):
        ask(llm, "[[fake-model id=retry-never status=503]] hi", "dora", "m-retry-never")
    assert sum(1 for _, t in seen.model if t == "m-retry-never") == 4
