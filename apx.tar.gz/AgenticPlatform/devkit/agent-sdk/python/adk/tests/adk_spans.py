"""The spans the adapter's tests export, through the core's redaction."""

from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

SPANS = InMemorySpanExporter()
