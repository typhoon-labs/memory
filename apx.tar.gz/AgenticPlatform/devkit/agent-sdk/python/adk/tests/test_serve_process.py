"""The adapter's README example as its own process, served by serve(): its
spans reach an OTLP collector stand-in with the invocation's attributes,
the secret patterns masked and the limit's span surface, and its refusal
reasons reach standard error. And on SIGTERM, a task still in flight
completes and its spans reach the collector before the process ends (T31)."""

import json
import os
import signal
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import httpx
import pytest
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import ExportTraceServiceRequest

from fake_model import fake_model  # noqa: F401
from issuer import Issuer
from stack import Seen, Server, free_port, gateway_app, send_message

KC = Issuer("https://keycloak.agentic.internal/realms/agentic", kid="kc-e2e")
STS = Issuer("https://delegation-sts.agentic.internal", kid="sts-e2e")
ROUTE = "https://gateway.agentic.internal/a2a/reference-agent"
CANARY = "glpat-" + "e2eCanary0123456789abcd"
AGENT = '''
import asyncio, sys
import agentic_sdk_adk
from google.adk.agents import LlmAgent
from agentic_sdk.runtime import Runtime
from agentic_sdk_adk.a2a import serve
from agentic_sdk_adk.models import gateway_openai
from agentic_sdk_adk.tools import gateway_mcp

runtime = Runtime(workload_file=sys.argv[1])
agent = LlmAgent(
    name="reference_agent",
    model=gateway_openai(runtime, "fast-default"),
    instruction="Answer questions about notes.",
    tools=[gateway_mcp(runtime, "reference-mcp", tool_filter=["list_notes"])],
)
asyncio.run(serve(agent, runtime))
'''
traces: list[bytes] = []


class Collector(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        body = self.rfile.read(int(self.headers["Content-Length"]))
        if self.path == "/v1/traces":
            traces.append(body)
        self.send_response(200)
        self.send_header("Content-Type", "application/x-protobuf")
        self.send_header("Content-Length", "0")
        self.end_headers()


def spans():
    out = []
    for body in traces:
        for rs in ExportTraceServiceRequest.FromString(body).resource_spans:
            res = {a.key: a.value.string_value for a in rs.resource.attributes}
            for ss in rs.scope_spans:
                for s in ss.spans:
                    attrs = {a.key: (a.value.string_value or a.value.int_value) for a in s.attributes}
                    out.append((res, s.name, s.status.code, attrs))
    return out


def start_agent(tmp_path, gw, collector, **extra_env):
    """The README agent in a process of its own, ready; its output in files,
    not pipes: ADK logs whole tracebacks, and an undrained pipe's buffer,
    once full, would block the agent."""
    (tmp_path / "agent.py").write_text(AGENT)
    (tmp_path / "workload.yaml").write_text(json.dumps({
        "name": "reference-agent", "kind": "agent", "runtime": "container", "owner": "reference", "support": "experimental",
        "limits": {"model_calls": 10, "tool_calls": 20, "tokens": 100000, "wall_time_seconds": 120}}))
    (tmp_path / "actor").write_text(KC.token(sub="system:serviceaccount:reference-agent:reference-agent"))
    port = free_port()
    env = {k: v for k, v in os.environ.items() if "proxy" not in k.lower() and not k.startswith(("AGENTIC_", "OTEL_"))}
    env.update({
        "AGENTIC_WORKLOAD_NAME": "reference-agent", "AGENTIC_LISTEN": f"127.0.0.1:{port}",
        "AGENTIC_TRUST": json.dumps([{"issuer": KC.iss, "profile": "keycloak", "jwks_uri": gw.url + "/jwks", "audience": ROUTE}]),
        "AGENTIC_GATEWAY_URL": gw.url, "AGENTIC_RESOURCE_BASE": "https://workloads-gateway.agentic.internal",
        "AGENTIC_STS_TOKEN_ENDPOINT": gw.url + "/sts/token", "AGENTIC_ACTOR_TOKEN_FILE": str(tmp_path / "actor"),
        "OTEL_EXPORTER_OTLP_ENDPOINT": f"http://127.0.0.1:{collector.server_port}",
        **extra_env,
    })
    out, err_file = open(tmp_path / "agent.out", "w"), open(tmp_path / "agent.err", "w")
    proc = subprocess.Popen([sys.executable, str(tmp_path / "agent.py"), str(tmp_path / "workload.yaml")], env=env,
                            stdout=out, stderr=err_file)
    out.close()
    err_file.close()
    url = f"http://127.0.0.1:{port}"
    for _ in range(200):
        try:
            if httpx.get(url + "/healthz", trust_env=False).status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.1)
    return proc, url


def start_collector():
    collector = ThreadingHTTPServer(("127.0.0.1", 0), Collector)
    threading.Thread(target=collector.serve_forever, daemon=True).start()
    return collector


def test_the_readme_agent_as_a_process(tmp_path, fake_model):  # noqa: F811
    collector = start_collector()
    gw = Server(gateway_app(fake_model, Seen(), jwks=KC.jwks(), sts=STS))
    proc, url = start_agent(tmp_path, gw, collector, AGENTIC_LIMIT_MODEL_CALLS="2", OTEL_BSP_SCHEDULE_DELAY="200")
    try:
        ok = send_message(url, KC.person("ana", ROUTE), f"{CANARY} [[fake-model tokens=5]]", task_id="e2e-ok",
                          path="/a2a/reference-agent")
        assert ok["body"]["result"]["task"]["status"]["state"] == "TASK_STATE_COMPLETED", ok
        stopped = send_message(url, KC.person("ana", ROUTE), "[[fake-model tool=list_notes]] go", task_id="e2e-limit")
        assert stopped["body"]["result"]["task"]["status"]["state"] == "TASK_STATE_FAILED"
        assert send_message(url, "not-a-token", "hi")["status"] == 401
        # The answer comes back when the task's final status is queued; the
        # agent's run unwinds, and its spans end, a moment later. Wait for
        # the evidence the test judges, the stopped task's invoke_agent span,
        # before stopping the process.
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and not any(
                n.startswith("invoke_agent") and a.get("task.id") == "e2e-limit" for _, n, _, a in spans()):
            time.sleep(0.1)
    finally:
        proc.terminate()
        proc.wait(timeout=30)
        err = (tmp_path / "agent.err").read_text()
        gw.stop()
        collector.shutdown()
    assert "inbound token refused: subject_signature" in err
    assert "not-a-token" not in err
    got = spans()
    assert got, "no spans reached the collector"
    assert all(res.get("service.name") == "reference-agent" for res, *_ in got)
    assert any(a.get("task.id") == "e2e-ok" and a.get("user.id") == "ana" for *_, a in got)
    assert not any(CANARY in str(v) for *_, a in got for v in a.values())
    assert any("****" in str(v) for *_, a in got if a.get("task.id") == "e2e-ok" for v in a.values())
    limited = [(name, code, a) for _, name, code, a in got if name.startswith("invoke_agent") and a.get("task.id") == "e2e-limit"]
    assert limited and all(code == 2 and a.get("error.type") == "limit_exceeded" for _, code, a in limited), limited


def test_a_task_in_flight_at_sigterm_completes_and_exports_its_spans(tmp_path, fake_model):  # noqa: F811
    """T31: SIGTERM arrives while a task's model call is in flight. The task
    still completes, and its spans, its invoke_agent span among them, reach
    the collector before the process ends. The batch processor's own export
    is a minute away, so only the shutdown's flush can send them."""
    collector = start_collector()
    seen = Seen()
    gw = Server(gateway_app(fake_model, seen, jwks=KC.jwks(), sts=STS))
    proc, url = start_agent(tmp_path, gw, collector, OTEL_BSP_SCHEDULE_DELAY="60000")
    task = "t31-in-flight"
    answer: dict = {}

    def ask():
        answer.update(send_message(url, KC.person("ana", ROUTE), "Take your time. [[fake-model delay=4s tokens=5]]",
                                   task_id=task, path="/a2a/reference-agent", timeout=60))

    asker = threading.Thread(target=ask)
    try:
        asker.start()
        # SIGTERM once the gateway stand-in holds the task's model call, which
        # the fake model answers 4 seconds later.
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and not any(t == task for _, t in seen.model):
            time.sleep(0.05)
        assert any(t == task for _, t in seen.model), "the task's model call never reached the gateway stand-in"
        assert not any(a.get("task.id") == task for *_, a in spans()), "a span was exported before SIGTERM"
        proc.send_signal(signal.SIGTERM)
        asker.join(60)
        proc.wait(timeout=40)
    finally:
        if proc.poll() is None:
            proc.kill()
        gw.stop()
        collector.shutdown()
    assert answer["body"]["result"]["task"]["status"]["state"] == "TASK_STATE_COMPLETED", answer
    mine = [(name, a) for _, name, _, a in spans() if a.get("task.id") == task]
    assert any(name.startswith("invoke_agent") for name, _ in mine), (mine, (tmp_path / "agent.err").read_text()[-2000:])
    assert any(a.get("gen_ai.operation.name") not in (None, "invoke_agent") for _, a in mine), mine
