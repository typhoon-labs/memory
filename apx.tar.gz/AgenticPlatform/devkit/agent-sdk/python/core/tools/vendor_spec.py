"""Copies the repository's spec/ into the core package, so the package
carries the contracts it implements. Examples, invalid cases and vectors
stay out: the tests read them from spec/ itself. Run from python/core:
python3 tools/vendor_spec.py. tests/test_contract.py fails when the copy
and spec/ differ."""

import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
SPEC = HERE.parent.parent / "spec"
DEST = HERE / "src" / "agentic_sdk" / "_spec"
SKIP = {"examples", "invalid", "vectors"}


def wanted(spec: Path) -> list[Path]:
    return sorted(
        p.relative_to(spec)
        for p in spec.rglob("*.json")
        if not SKIP.intersection(p.relative_to(spec).parts)
    )


def main() -> int:
    if DEST.exists():
        shutil.rmtree(DEST)
    for rel in wanted(SPEC):
        (DEST / rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SPEC / rel, DEST / rel)
    print(f"copied {len(wanted(SPEC))} files to {DEST}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
