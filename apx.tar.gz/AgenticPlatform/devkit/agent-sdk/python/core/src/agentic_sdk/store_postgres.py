"""The tool records in Postgres, through asyncpg (the `postgres` extra): the
database app-base provides with CloudNativePG. Tables are created when
missing.

A tool that keeps its own data in the same database takes its connections
from the store's acquire(): inside a guarded call's transaction (apply and
target) that is the transaction's own connection, so the change, its
idempotency key and its approval's use commit together, and a call never
waits for a second connection while it holds one, which would deadlock
once concurrent calls reach the pool's size. Outside a transaction it is a
pooled connection, waited for at most acquire_timeout seconds; a call that
cannot get one fails with StoreBusy instead of hanging. A connection goes
back to the pool reset within release_timeout seconds, or is closed: a
call cancelled mid-query (its wall time) never returns a connection still
busy, nor holds one forever."""

from __future__ import annotations

import asyncio
import contextlib
import contextvars
import json
from collections.abc import AsyncIterator, Callable
from typing import Any

import asyncpg

from .store import IN_PROGRESS_SECONDS, RETENTION_SECONDS_MINIMUM, KeyState

POOL_SIZE = 10
ACQUIRE_TIMEOUT = 10.0
RELEASE_TIMEOUT = 10.0
_TX_CONNECTION: contextvars.ContextVar[asyncpg.Connection | None] = contextvars.ContextVar(
    "agentic_store_transaction", default=None)


class StoreBusy(Exception):
    """No database connection became free within the store's acquire timeout."""

SCHEMA = """
create table if not exists agentic_idempotency (
  key text primary key,
  state text not null check (state in ('in_progress', 'completed')),
  result jsonb,
  updated_at timestamptz not null default now()
);
create table if not exists agentic_approvals (
  id text primary key,
  proposal_key text not null,
  record jsonb not null,
  created_at timestamptz not null default now()
);
create unique index if not exists agentic_approvals_pending
  on agentic_approvals (proposal_key) where not (record ? 'approver');
"""


class PgTransaction:
    def __init__(self, conn: asyncpg.Connection):
        self.connection = conn

    async def complete_key(self, key: str, result: dict[str, Any]) -> None:
        await self.connection.execute(
            "update agentic_idempotency set state = 'completed', result = $2::jsonb, updated_at = now() where key = $1",
            key, json.dumps(result))

    async def use_approval(self, approval_id: str, used_at: int) -> bool:
        row = await self.connection.fetchrow(
            "update agentic_approvals set record = record || jsonb_build_object('used_at', $2::bigint) "
            "where id = $1 and not (record ? 'used_at') and (record ? 'approver') returning id",
            approval_id, used_at)
        return row is not None


class PostgresStore:
    """Connects when first used, not at start, so a workload starts while its
    database is still coming up; a failed connection fails that call only,
    and the next call tries again."""

    def __init__(self, dsn: str, *, acquire_timeout: float = ACQUIRE_TIMEOUT,
                 release_timeout: float = RELEASE_TIMEOUT, **pool_args: Any):
        self._dsn = dsn
        self.acquire_timeout = acquire_timeout
        self.release_timeout = release_timeout
        self._pool_args = {"min_size": 1, "max_size": POOL_SIZE, **pool_args}
        self._pool: asyncpg.Pool | None = None
        self._lock = asyncio.Lock()

    @classmethod
    async def connect(cls, dsn: str, **pool_args: Any) -> PostgresStore:
        """A store connected now, its tables created."""
        store = cls(dsn, **pool_args)
        await store.ready()
        return store

    async def ready(self) -> asyncpg.Pool:
        if self._pool is None:
            async with self._lock:
                if self._pool is None:
                    pool = await asyncpg.create_pool(self._dsn, **self._pool_args)
                    try:
                        async with pool.acquire() as conn:
                            await conn.execute(SCHEMA)
                    except BaseException:
                        await pool.close()
                        raise
                    self._pool = pool
        return self._pool

    @contextlib.asynccontextmanager
    async def acquire(self) -> AsyncIterator[asyncpg.Connection]:
        """A connection: the current guarded transaction's, inside one;
        otherwise one from the pool, waited for at most acquire_timeout."""
        current = _TX_CONNECTION.get()
        if current is not None:
            yield current
            return
        pool = await self.ready()
        try:
            conn = await pool.acquire(timeout=self.acquire_timeout)
        except TimeoutError:
            raise StoreBusy(f"no database connection free within {self.acquire_timeout:g} s "
                            f"(pool of {self._pool_args['max_size']})") from None
        try:
            yield conn
        finally:
            # asyncpg waits for a cancelled query's cancellation and resets
            # the connection within the timeout, else closes it.
            await pool.release(conn, timeout=self.release_timeout)

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    async def reserve_key(self, key: str) -> KeyState:
        async with self.acquire() as conn, conn.transaction():
            row = await conn.fetchrow(
                "insert into agentic_idempotency (key, state) values ($1, 'in_progress') "
                "on conflict (key) do nothing returning key", key)
            if row is not None:
                return KeyState("new")
            row = await conn.fetchrow(
                "select state, result, now() - updated_at > make_interval(secs => $2) as stale "
                "from agentic_idempotency where key = $1 for update", key, IN_PROGRESS_SECONDS)
            if row is None:  # released between the two statements
                await conn.execute("insert into agentic_idempotency (key, state) values ($1, 'in_progress')", key)
                return KeyState("new")
            if row["state"] == "completed":
                return KeyState("completed", json.loads(row["result"]))
            if row["stale"]:
                await conn.execute("update agentic_idempotency set updated_at = now() where key = $1", key)
                return KeyState("new")
            return KeyState("in_progress")

    async def release_key(self, key: str) -> None:
        async with self.acquire() as conn:
            await conn.execute("delete from agentic_idempotency where key = $1 and state = 'in_progress'", key)

    async def proposal(self, proposal_key: str, make: Callable[[], dict[str, Any]]) -> dict[str, Any]:
        async with self.acquire() as conn:
            for _ in range(3):
                row = await conn.fetchrow(
                    "select record from agentic_approvals where proposal_key = $1 and not (record ? 'approver')",
                    proposal_key)
                if row is not None:
                    return json.loads(row["record"])
                rec = make()
                inserted = await conn.fetchrow(
                    "insert into agentic_approvals (id, proposal_key, record) values ($1, $2, $3::jsonb) "
                    "on conflict do nothing returning id", rec["id"], proposal_key, json.dumps(rec))
                if inserted is not None:
                    return rec
        raise RuntimeError("could not create a proposal")

    async def approval(self, approval_id: str) -> dict[str, Any] | None:
        async with self.acquire() as conn:
            row = await conn.fetchrow("select record from agentic_approvals where id = $1", approval_id)
        return json.loads(row["record"]) if row is not None else None

    async def approve(self, approval_id, approver, approved_at, expires_at):
        patch = {"approver": approver, "approved_at": approved_at, "expires_at": expires_at}
        async with self.acquire() as conn:
            row = await conn.fetchrow(
                "update agentic_approvals set record = record || $2::jsonb "
                "where id = $1 and not (record ? 'approver') returning record", approval_id, json.dumps(patch))
        return json.loads(row["record"]) if row is not None else None

    @contextlib.asynccontextmanager
    async def transaction(self) -> AsyncIterator[PgTransaction]:
        async with self.acquire() as conn, conn.transaction():
            token = _TX_CONNECTION.set(conn)
            try:
                yield PgTransaction(conn)
            finally:
                _TX_CONNECTION.reset(token)

    async def purge(self, older_than_seconds: int = RETENTION_SECONDS_MINIMUM) -> int:
        older_than_seconds = max(older_than_seconds, RETENTION_SECONDS_MINIMUM)
        async with self.acquire() as conn:
            res = await conn.execute(
                "delete from agentic_idempotency where state = 'completed' and updated_at < now() - make_interval(secs => $1)",
                older_than_seconds)
        return int(res.split()[-1])
