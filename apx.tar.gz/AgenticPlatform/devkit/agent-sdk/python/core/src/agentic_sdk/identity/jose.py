"""Compact JWS parsing and signature checks for RS256 and ES256, on the
cryptography package's primitives. Keys come only from a JWK set: nothing in
a token's header is ever used as a key."""

from __future__ import annotations

import base64
import binascii
import json
from dataclasses import dataclass
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature


class Malformed(ValueError):
    """Not a compact JWS whose header and claims are JSON objects."""


def b64url_decode(s: str) -> bytes:
    if not s.isascii() or "=" in s or "+" in s or "/" in s:
        raise Malformed("not base64url")
    try:
        return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))
    except (binascii.Error, ValueError) as e:
        raise Malformed("not base64url") from e


def b64url_int(s: str) -> int:
    return int.from_bytes(b64url_decode(s), "big")


@dataclass(frozen=True)
class Jws:
    header: dict[str, Any]
    claims: dict[str, Any]
    signing_input: bytes
    signature: bytes


def parse(token: str) -> Jws:
    parts = token.split(".")
    if len(parts) != 3 or not all(parts[:2]):
        raise Malformed("not three parts")
    try:
        header = json.loads(b64url_decode(parts[0]))
        claims = json.loads(b64url_decode(parts[1]))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise Malformed("not JSON") from e
    if not isinstance(header, dict) or not isinstance(claims, dict):
        raise Malformed("not JSON objects")
    return Jws(header, claims, f"{parts[0]}.{parts[1]}".encode("ascii"), b64url_decode(parts[2]))


def unverified_claims(token: str) -> dict[str, Any] | None:
    """The claims of a JWT without checking anything: for cache keys and
    expiry hints only, never for a decision."""
    try:
        return parse(token).claims
    except Malformed:
        return None


def public_key(jwk: dict[str, Any]):
    """The public key a JWK describes, or None for a type this module does not take."""
    try:
        if jwk.get("kty") == "RSA":
            return rsa.RSAPublicNumbers(b64url_int(jwk["e"]), b64url_int(jwk["n"])).public_key()
        if jwk.get("kty") == "EC" and jwk.get("crv") == "P-256":
            return ec.EllipticCurvePublicNumbers(
                b64url_int(jwk["x"]), b64url_int(jwk["y"]), ec.SECP256R1()
            ).public_key()
    except (KeyError, ValueError, TypeError, Malformed):
        return None
    return None


def verify(jws: Jws, alg: str, jwk: dict[str, Any]) -> bool:
    """Whether jws's signature verifies with jwk under alg (RS256 or ES256)."""
    if jwk.get("alg") not in (None, alg) or jwk.get("use") not in (None, "sig"):
        return False
    key = public_key(jwk)
    try:
        if alg == "RS256" and isinstance(key, rsa.RSAPublicKey):
            key.verify(jws.signature, jws.signing_input, padding.PKCS1v15(), hashes.SHA256())
            return True
        if alg == "ES256" and isinstance(key, ec.EllipticCurvePublicKey):
            if len(jws.signature) != 64:
                return False
            r = int.from_bytes(jws.signature[:32], "big")
            s = int.from_bytes(jws.signature[32:], "big")
            key.verify(encode_dss_signature(r, s), jws.signing_input, ec.ECDSA(hashes.SHA256()))
            return True
    except InvalidSignature:
        return False
    return False
