"""delegation: the RFC 8693 exchange at the delegation STS, with one resource
per target (spec/exchange/), and the client-side cache Identity describes:
keyed by a hash of the subject token, the target and the actor; kept until
about 30 seconds before the issued token expires; never shared across
subjects; one exchange in flight per key."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import time
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass

import httpx

from . import context, contract
from .identity.jose import unverified_claims

log = logging.getLogger("agentic_sdk.delegation")

_EX = contract.load("exchange/exchange.json")
_PARAM = {p["name"]: p for p in _EX["request"]["parameters"]}
GRANT_TYPE = _PARAM["grant_type"]["value"]
SUBJECT_TOKEN_TYPE = _PARAM["subject_token_type"]["value"]
ACTOR_TOKEN_TYPE = _PARAM["actor_token_type"]["value"]
EARLY_SECONDS = 30
MAX_ENTRIES = 1024


class ExchangeRefused(Exception):
    """The STS refused: error and reason as spec/refusals/refusals.json has them."""

    def __init__(self, status: int, error: str, reason: str | None):
        super().__init__(f"{status} {error} {reason}")
        self.status, self.error, self.reason = status, error, reason


class ExchangeFailed(Exception):
    """The STS could not be reached, or answered something that is not an exchange response."""


class ActorTokenFile:
    """The workload's projected service-account token, read from its file when
    needed: the kubelet rotates it in place, so the file is re-read whenever
    it changes. A missing file fails only the exchange that needs it."""

    def __init__(self, path: str):
        self.path = path
        self._cache: tuple[float, str] | None = None

    def __call__(self) -> str:
        try:
            mtime = os.stat(self.path).st_mtime
            if self._cache is None or self._cache[0] != mtime:
                with open(self.path, encoding="ascii") as f:
                    self._cache = (mtime, f.read().strip())
        except OSError as e:
            raise ExchangeFailed(f"actor token unreadable: {self.path}: {e.strerror}") from None
        if not self._cache[1]:
            raise ExchangeFailed(f"actor token empty: {self.path}")
        return self._cache[1]


def _hash(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _actor_identity(actor_token: str) -> str:
    """The actor's stable name for the cache key: its sub, so a rotated
    projected token keeps the entries; the token's hash if it has none."""
    claims = unverified_claims(actor_token) or {}
    sub = claims.get("sub")
    return f"sub:{sub}" if isinstance(sub, str) and sub else f"token:{_hash(actor_token)}"


@dataclass(frozen=True)
class Issued:
    access_token: str
    expires_at: float  # seconds since the epoch


class Exchanger:
    """Exchanges a subject token for a token for one resource, and caches the result."""

    def __init__(self, token_endpoint: str, actor_token: Callable[[], str],
                 client: Callable[[], httpx.AsyncClient], *,
                 clock: Callable[[], float] = time.time, early_seconds: float = EARLY_SECONDS,
                 max_entries: int = MAX_ENTRIES):
        self.token_endpoint = token_endpoint
        self._actor_token = actor_token
        self._client = client
        self._clock = clock
        self._early = early_seconds
        self._max = max_entries
        self._cache: OrderedDict[tuple[str, str, str], Issued] = OrderedDict()
        self._inflight: dict[tuple[str, str, str], asyncio.Future[Issued]] = {}
        self.exchanges = 0  # requests sent to the STS, for tests and metrics

    def _fresh(self, issued: Issued) -> bool:
        return self._clock() < issued.expires_at - self._early

    def invalidate(self, subject_token: str, resource: str) -> None:
        """Forgets every cached token for this subject and resource, as after a 401."""
        sub = _hash(subject_token)
        for key in [k for k in self._cache if k[0] == sub and k[1] == resource]:
            del self._cache[key]

    async def token(self, subject_token: str, resource: str) -> str:
        """A token for resource, acting for subject_token's subject."""
        actor = self._actor_token()
        key = (_hash(subject_token), resource, _actor_identity(actor))
        while True:
            hit = self._cache.get(key)
            if hit is not None and self._fresh(hit):
                self._cache.move_to_end(key)
                return hit.access_token
            pending = self._inflight.get(key)
            if pending is None:
                break
            try:
                return (await asyncio.shield(pending)).access_token
            except asyncio.CancelledError:
                # The caller that led this exchange was cancelled, not this
                # one: try again, unless this task is being cancelled too.
                task = asyncio.current_task()
                if not pending.cancelled() or (task is not None and task.cancelling()):
                    raise
        fut: asyncio.Future[Issued] = asyncio.get_running_loop().create_future()
        self._inflight[key] = fut
        try:
            issued = await self._exchange(subject_token, actor, resource)
        except asyncio.CancelledError:
            fut.cancel()
            raise
        except Exception as e:
            fut.set_exception(e)
            fut.exception()  # retrieved, so a future nobody awaited logs nothing
            raise
        else:
            fut.set_result(issued)
        finally:
            del self._inflight[key]
        if self._fresh(issued):
            self._cache[key] = issued
            self._cache.move_to_end(key)
            self._evict()
        return issued.access_token

    def _evict(self) -> None:
        for k in [k for k, v in self._cache.items() if not self._fresh(v)]:
            del self._cache[k]
        while len(self._cache) > self._max:
            self._cache.popitem(last=False)

    async def _exchange(self, subject_token: str, actor_token: str, resource: str) -> Issued:
        form = {
            "grant_type": GRANT_TYPE,
            "subject_token": subject_token,
            "subject_token_type": SUBJECT_TOKEN_TYPE,
            "actor_token": actor_token,
            "actor_token_type": ACTOR_TOKEN_TYPE,
            "resource": resource,
        }
        hdrs = {"Accept": "application/json", **context.outbound_headers()}
        self.exchanges += 1
        try:
            resp = await self._client().post(self.token_endpoint, data=form, headers=hdrs)
        except httpx.HTTPError as e:
            raise ExchangeFailed(f"STS unreachable: {type(e).__name__}: {e}") from None
        try:
            body = resp.json()
        except ValueError:
            body = None
        if resp.status_code != 200:
            if isinstance(body, dict) and isinstance(body.get("error"), str):
                reason = body.get("reason") if isinstance(body.get("reason"), str) else None
                if reason is not None and reason not in contract.sts_reasons():
                    log.warning("STS refusal with a reason outside spec/refusals: %s", reason)
                raise ExchangeRefused(resp.status_code, body["error"], reason)
            raise ExchangeFailed(f"STS answered {resp.status_code}")
        if not isinstance(body, dict) or not isinstance(body.get("access_token"), str):
            raise ExchangeFailed("STS answer has no access_token")
        claims = unverified_claims(body["access_token"]) or {}
        exp = claims.get("exp")
        if not isinstance(exp, int):
            expires_in = body.get("expires_in")
            exp = self._clock() + (expires_in if isinstance(expires_in, int | float) else 0)
        # Never past the subject's own expiry: a chain token never outlives it.
        sub_exp = (unverified_claims(subject_token) or {}).get("exp")
        if isinstance(sub_exp, int):
            exp = min(exp, sub_exp)
        return Issued(body["access_token"], float(exp))


async def token_for(exchanger: Exchanger, resource: str) -> str:
    """A token for resource, for the current invocation's caller."""
    inv = context.require()
    if not inv.token:
        raise context.NoInvocation("the current invocation has no subject token to exchange")
    return await exchanger.token(inv.token, resource)
