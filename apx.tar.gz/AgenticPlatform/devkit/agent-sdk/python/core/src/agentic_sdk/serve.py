"""Composes a workload's ASGI app the way the platform runs it: probes,
inbound authentication around the app, for an MCP server the approval
route beside it at /approvals/<name>/, and for an agent the A2A paths
/a2a/<name> as the gateway forwards them, with / for direct callers.
Pure ASGI; serve it with any ASGI server (uvicorn) on Runtime.listen.

Its shutdown, at the lifespan's shutdown event, which an ASGI server sends
once it has stopped taking requests and the ones in flight are answered:
first the tasks still running for them (IN_FLIGHT) end, within the drain
period, the rest cancelled; then the app's own shutdown; then the tracer
and the audit records' exporter are flushed, within the flush period. So a
task in flight at SIGTERM exports its spans: nothing after the server
returns runs, since uvicorn raises SIGTERM again as it returns (T31)."""

from __future__ import annotations

import asyncio
import logging
import sys
import time
from collections.abc import Awaitable, Callable, Collection, Iterator
from contextlib import contextmanager
from typing import Any

from . import telemetry

from .approvals import ApprovalRoute
from .identity.asgi import DEFAULT_PUBLIC, InboundAuth
from .identity.verifier import Verifier

ASGIApp = Callable[[dict[str, Any], Callable, Callable], Awaitable[None]]


log = logging.getLogger("agentic_sdk.serve")

# A shutdown's bounds, from its start: the drain, then the flush. Together
# within app-base's terminationGracePeriodSeconds, 30, with room to exit.
DRAIN_SECONDS = 20.0
FLUSH_SECONDS = 5.0
# How long cancelled tasks get to unwind, so that their spans end.
UNWIND_SECONDS = 1.0


class InFlight:
    """The tasks a workload runs for its callers that may outlive the request
    that started them, such as an A2A task, whose run unwinds after its answer
    is sent. An adapter runs each task under track(); a shutdown waits for
    them, then cancels what is left."""

    def __init__(self) -> None:
        self._tasks: set[asyncio.Task] = set()

    @contextmanager
    def track(self) -> Iterator[None]:
        """Counts the current asyncio task as in flight until the block ends."""
        task = asyncio.current_task()
        if task is not None:
            self._tasks.add(task)
        try:
            yield
        finally:
            if task is not None:
                self._tasks.discard(task)

    def __len__(self) -> int:
        return sum(1 for t in self._tasks if not t.done())

    async def drain(self, deadline: float, unwind_seconds: float = UNWIND_SECONDS) -> int:
        """Waits until no tracked task is left or time.monotonic() reaches
        deadline; then cancels the ones left and gives them unwind_seconds to
        end. Returns how many it cancelled."""
        me = asyncio.current_task()
        while True:
            pending = {t for t in self._tasks if t is not me and not t.done()}
            remaining = deadline - time.monotonic()
            if not pending or remaining <= 0:
                break
            await asyncio.wait(pending, timeout=remaining)
        if pending:
            log.warning("shutdown: cancelling %d task(s) still running after the drain period", len(pending))
            for t in pending:
                t.cancel()
            await asyncio.wait(pending, timeout=unwind_seconds)
        return len(pending)


IN_FLIGHT = InFlight()


class Probes:
    """/healthz answers while the process serves; /readyz until shutdown begins.
    At the lifespan's shutdown, drains in_flight within drain_seconds of the
    shutdown's start, passes the shutdown on, then flushes the telemetry
    within flush_seconds (the module's docstring)."""

    def __init__(self, app: ASGIApp, *, in_flight: InFlight | None = None,
                 drain_seconds: float = DRAIN_SECONDS, flush_seconds: float = FLUSH_SECONDS):
        self.app = app
        self.ready = True
        self.in_flight = IN_FLIGHT if in_flight is None else in_flight
        self.drain_seconds = drain_seconds
        self.flush_seconds = flush_seconds
        self.shutdown_started: float | None = None

    def begin_shutdown(self) -> None:
        """Marks the shutdown's start, as the server stops taking requests:
        /readyz answers 503 from now, and the drain period counts from here.
        A server that does not call it starts the shutdown at the lifespan's
        shutdown event."""
        if self.shutdown_started is None:
            self.shutdown_started = time.monotonic()
        self.ready = False

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] == "lifespan":
            return await self._lifespan(scope, receive, send)
        if scope["type"] == "http" and scope.get("path") in ("/healthz", "/readyz"):
            ok = scope["path"] == "/healthz" or self.ready
            body = b"ok" if ok else b"shutting down"
            await send({"type": "http.response.start", "status": 200 if ok else 503,
                        "headers": [(b"content-type", b"text/plain"), (b"content-length", str(len(body)).encode())]})
            await send({"type": "http.response.body", "body": body})
            return
        await self.app(scope, receive, send)

    async def _lifespan(self, scope, receive, send) -> None:
        flushed = False

        async def flush() -> None:
            nonlocal flushed
            if not flushed:
                flushed = True
                if not await telemetry.flush_async(self.flush_seconds):
                    log.warning("shutdown: telemetry not flushed within %.0f s", self.flush_seconds)

        async def watching_receive():
            message = await receive()
            if message["type"] == "lifespan.shutdown":
                self.begin_shutdown()
                await self.in_flight.drain(self.shutdown_started + self.drain_seconds)
            return message

        async def flushing_send(message):
            if message["type"] in ("lifespan.shutdown.complete", "lifespan.shutdown.failed"):
                await flush()
            await send(message)

        try:
            await self.app(scope, watching_receive, flushing_send)
        finally:
            # An app that ends its lifespan without answering the shutdown.
            if self.shutdown_started is not None:
                await flush()


class Prefix:
    """Sends requests whose path starts with prefix to one app, the rest to another."""

    def __init__(self, prefix: str, inner: ASGIApp, rest: ASGIApp):
        self.prefix, self.inner, self.rest = prefix, inner, rest

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] == "http" and scope.get("path", "").startswith(self.prefix):
            return await self.inner(scope, receive, send)
        await self.rest(scope, receive, send)


CARD = "/.well-known/agent-card.json"


class A2APaths:
    """For an agent served at /a2a/<name> (the gateway forwards the route's
    full path, with no rewrite): also answers direct callers at / and at
    /.well-known/agent-card.json, as if they had used the route's path."""

    def __init__(self, app: ASGIApp, name: str):
        self.app = app
        self.base = f"/a2a/{name}"

    async def __call__(self, scope, receive, send) -> None:
        if scope["type"] == "http" and scope.get("path") in ("/", CARD, self.base + "/"):
            # JSON-RPC is served at /a2a/<name> itself: / and a trailing slash map there.
            path = self.base + CARD if scope["path"] == CARD else self.base
            scope = {**scope, "path": path, "raw_path": path.encode()}
        await self.app(scope, receive, send)


def workload_app(app: ASGIApp, verifier: Verifier, *, approvals: ApprovalRoute | None = None,
                 a2a_name: str | None = None, public_paths: Collection[str] = DEFAULT_PUBLIC) -> Probes:
    """app behind inbound authentication, with probes; the approval route at
    /approvals/<name>/ when given (it checks the approver's token itself);
    and for an agent served at /a2a/<a2a_name>, its card public there and
    both paths answered at / too."""
    public = set(public_paths)
    if a2a_name:
        public.add(f"/a2a/{a2a_name}{CARD}")
    authed: ASGIApp = InboundAuth(app, verifier, public_paths=public)
    if a2a_name:
        authed = A2APaths(authed, a2a_name)
    if approvals is not None:
        authed = Prefix(approvals.prefix, approvals, authed)
    return Probes(authed)


def prepare(runtime: Any) -> telemetry.Telemetry:
    """What a workload's process does once at start, before it serves: check
    every setting (a bad one stops the start), send the SDK's own log lines
    (refusal reasons, warnings; never a token) to standard error at INFO when
    the process has configured no logging, and set up tracing, exported over
    OTLP when OTEL_EXPORTER_OTLP_ENDPOINT is set. Without it, spans and the
    tool audit records that name them carry no trace IDs."""
    runtime.check()
    if not logging.getLogger().handlers:
        logging.basicConfig(stream=sys.stderr, level=logging.WARNING,
                            format="%(asctime)s %(levelname)s %(name)s %(message)s")
    logging.getLogger("agentic_sdk").setLevel(logging.INFO)
    logging.getLogger("agentic_sdk_adk").setLevel(logging.INFO)
    return telemetry.configure(runtime.name)
