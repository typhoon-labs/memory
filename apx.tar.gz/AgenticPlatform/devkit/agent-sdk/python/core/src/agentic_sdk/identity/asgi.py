"""Inbound authentication for any ASGI app: verifies the bearer token, refuses
with RFC 6750's 401, and makes the request an invocation (agentic_sdk.context)
for everything the app does with it, inside the caller's trace (W3C
traceparent). No web framework is imported."""

from __future__ import annotations

import json
import logging
from collections.abc import Awaitable, Callable, Collection
from typing import Any

from opentelemetry import context as otel_context
from opentelemetry import propagate

from .. import context, headers
from .jwks import KeysUnavailable
from .verifier import Principal, TokenRefused, Verifier

log = logging.getLogger("agentic_sdk.identity")

Scope = dict[str, Any]
ASGIApp = Callable[[Scope, Callable, Callable], Awaitable[None]]

# Paths answered without a token: probes, and the A2A agent card, which
# names no secret and which the gateway fetches to rewrite its URL.
DEFAULT_PUBLIC = frozenset({"/healthz", "/readyz", "/.well-known/agent-card.json", "/.well-known/agent.json"})


class AuthenticatedUser:
    """What Starlette's AuthenticationMiddleware would put in scope["user"]:
    a2a-sdk reads is_authenticated and display_name from it, so ADK runs the
    request as the verified user.id (or actor.sub)."""

    def __init__(self, principal: Principal):
        self.principal = principal

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def display_name(self) -> str:
        return self.principal.display_name

    @property
    def identity(self) -> str:
        return self.principal.display_name


def trace_parent(scope: Scope) -> otel_context.Context:
    """The OpenTelemetry context of the request's W3C trace headers
    (traceparent, tracestate), through the configured propagator: empty when
    it sends none or a malformed one."""
    carrier: dict[str, str] = {}
    for k, v in scope.get("headers", []):
        name = k.decode("latin-1").lower()
        if name in ("traceparent", "tracestate"):
            carrier[name] = v.decode("latin-1")
    return propagate.extract(carrier, context=otel_context.Context())


def bearer(scope: Scope) -> tuple[str | None, bool]:
    """The bearer token and whether an Authorization header was sent at all.
    Two Authorization headers, or another scheme, give no token."""
    values = [v for k, v in scope.get("headers", []) if k.lower() == b"authorization"]
    if len(values) != 1:
        return None, bool(values)
    scheme, _, token = values[0].decode("latin-1").partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        return None, True
    return token.strip(), True


async def _answer(send: Callable, status: int, extra: list[tuple[bytes, bytes]], body: dict) -> None:
    data = json.dumps(body).encode()
    await send({"type": "http.response.start", "status": status,
                "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(data)).encode()), *extra]})
    await send({"type": "http.response.body", "body": data})


async def refuse(send: Callable, sent: bool) -> None:
    """401 with WWW-Authenticate: Bearer, and error="invalid_token" when a token was sent (RFC 6750)."""
    challenge = b'Bearer error="invalid_token"' if sent else b"Bearer"
    await _answer(send, 401, [(b"www-authenticate", challenge)], {"error": "invalid_token"} if sent else {"error": "unauthorized"})


async def unavailable(send: Callable) -> None:
    await _answer(send, 503, [(b"retry-after", b"5")], {"error": "temporarily_unavailable"})


class InboundAuth:
    """Wraps an ASGI app: every HTTP request outside public_paths must carry a
    token the verifier accepts. The app then runs inside the request's
    invocation: its principal, its token and its task (a new task ID when the
    request carried no valid one).

    A request under one of the verifier's routes (Verifier.routes) is
    verified by that route's verifier instead, and reaches the app with the
    route's prefix removed; nothing under a route is public. So Substrate's
    actor tokens are accepted on the route the gateway's listener for
    Substrate calls, and nowhere else (D30)."""

    def __init__(self, app: ASGIApp, verifier: Verifier, *, public_paths: Collection[str] = DEFAULT_PUBLIC):
        self.app = app
        self.verifier = verifier
        self.public_paths = frozenset(public_paths)

    async def __call__(self, scope: Scope, receive: Callable, send: Callable) -> None:
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        path = scope.get("path", "")
        verifier = self.verifier
        route = next((r for r in getattr(verifier, "routes", ()) if r.matches(path)), None)
        if route is not None:
            verifier = route.verifier
            inner = path[len(route.prefix):] or "/"
            scope = {**scope, "path": inner, "raw_path": inner.encode()}
        elif path in self.public_paths:
            return await self.app(scope, receive, send)
        token, sent = bearer(scope)
        try:
            principal = await verifier.verify(token)
        except TokenRefused as e:
            log.info("inbound token refused: %s", e.reason)
            return await refuse(send, sent and e.token_sent)
        except KeysUnavailable as e:
            log.warning("inbound token not checked: keys unavailable for %s", e)
            return await unavailable(send)
        scope["user"] = AuthenticatedUser(principal)
        scope["auth"] = principal
        inv = context.Invocation(task=headers.read(scope["headers"]).started(), principal=principal, token=token)
        # The caller's trace is the parent of every span of the work, and of
        # the trace context sent on with each outbound call. MCP's _meta,
        # where a client sends one, still takes precedence in the MCP SDK.
        attached = otel_context.attach(trace_parent(scope))
        try:
            with context.use(inv):
                await self.app(scope, receive, send)
        finally:
            otel_context.detach(attached)
