"""The task and workflow headers (spec/headers/): read them, start a task
when there is none, and send them on."""

from __future__ import annotations

import re
import uuid
from collections.abc import Iterable, Mapping
from dataclasses import dataclass

from . import contract

_SPEC = {h["name"].lower(): h for h in contract.load("headers/headers.json")["headers"]}
TASK_ID = "Agentic-Task-Id"
WORKFLOW_NAME = "Agentic-Workflow-Name"
WORKFLOW_VERSION = "Agentic-Workflow-Version"
_PATTERNS = {name: re.compile(h["pattern"]) for name, h in _SPEC.items()}


def valid(name: str, value: str | None) -> bool:
    """Whether value matches the header's pattern whole (re.fullmatch)."""
    return value is not None and value.isascii() and _PATTERNS[name.lower()].fullmatch(value) is not None


def new_task_id() -> str:
    """A new task ID: a version 7 UUID, lowercase and hyphenated."""
    return str(uuid.uuid7())


@dataclass(frozen=True)
class TaskHeaders:
    """The valid values a request carried; None for each that counts as absent."""

    task_id: str | None = None
    workflow_name: str | None = None
    workflow_version: str | None = None

    def started(self) -> TaskHeaders:
        """These headers, with a new task ID when the request carried no valid one."""
        if self.task_id is not None:
            return self
        return TaskHeaders(new_task_id(), self.workflow_name, self.workflow_version)

    def outbound(self) -> dict[str, str]:
        """The headers to send on every request made for the task."""
        out = {}
        if self.task_id:
            out[TASK_ID] = self.task_id
        if self.workflow_name and self.workflow_version:
            out[WORKFLOW_NAME] = self.workflow_name
            out[WORKFLOW_VERSION] = self.workflow_version
        return out

    def attributes(self) -> dict[str, str]:
        """The record attributes they fill: task.id, workflow.name, workflow.version."""
        out = {}
        for name, value in ((TASK_ID, self.task_id), (WORKFLOW_NAME, self.workflow_name),
                            (WORKFLOW_VERSION, self.workflow_version)):
            if value is not None:
                out[_SPEC[name.lower()]["attribute"]] = value
        return out


def read(headers: Mapping[str, str] | Iterable[tuple[str | bytes, str | bytes]]) -> TaskHeaders:
    """Reads the three headers. One that is missing, sent more than once, or
    does not match its pattern counts as absent."""
    pairs = headers.items() if isinstance(headers, Mapping) else headers
    seen: dict[str, list[str]] = {}
    for k, v in pairs:
        key = (k.decode("latin-1") if isinstance(k, bytes) else k).lower()
        if key in _SPEC:
            seen.setdefault(key, []).append(v.decode("latin-1") if isinstance(v, bytes) else v)

    def one(name: str) -> str | None:
        values = seen.get(name.lower(), [])
        return values[0] if len(values) == 1 and valid(name, values[0]) else None

    return TaskHeaders(one(TASK_ID), one(WORKFLOW_NAME), one(WORKFLOW_VERSION))


def from_values(task_id: str | None, workflow_name: str | None = None,
                workflow_version: str | None = None) -> TaskHeaders:
    """From values given otherwise, such as environment variables; invalid ones count as absent."""
    return TaskHeaders(
        task_id if valid(TASK_ID, task_id) else None,
        workflow_name if valid(WORKFLOW_NAME, workflow_name) else None,
        workflow_version if valid(WORKFLOW_VERSION, workflow_version) else None,
    )
