"""The platform's contracts, from the copy of agent-sdk's spec/ this package
carries (tools/vendor_spec.py writes it, a test keeps it equal to spec/)."""

from __future__ import annotations

import functools
import json
from importlib.resources import files
from typing import Any

from jsonschema import Draft202012Validator
from referencing import Registry, Resource

# A hierarchical URI per file, so the schemas' relative $refs resolve
# (spec/schemas/README.md). Nothing is fetched from it.
_BASE = "file:///agentic-spec/"


def _root():
    return files("agentic_sdk") / "_spec"


def _walk(node, prefix=""):
    for child in node.iterdir():
        rel = f"{prefix}{child.name}"
        if child.is_dir():
            yield from _walk(child, rel + "/")
        elif child.name.endswith(".json"):
            yield rel, child


@functools.cache
def load(rel: str) -> Any:
    """One spec file, parsed: load("refusals/refusals.json")."""
    return json.loads((_root() / rel).read_text(encoding="utf-8"))


@functools.cache
def registry() -> Registry:
    return Registry().with_resources(
        (_BASE + rel, Resource.from_contents(json.loads(f.read_text(encoding="utf-8"))))
        for rel, f in _walk(_root())
        if rel.endswith(".schema.json")
    )


@functools.cache
def validator(schema_rel: str) -> Draft202012Validator:
    """A draft 2020-12 validator for one spec schema, formats asserted."""
    return Draft202012Validator(
        {"$ref": _BASE + schema_rel},
        registry=registry(),
        format_checker=Draft202012Validator.FORMAT_CHECKER,
    )


def first_error(schema_rel: str, instance: Any) -> str | None:
    """The first validation error's message, or None when the instance is valid."""
    err = next(iter(validator(schema_rel).iter_errors(instance)), None)
    if err is None:
        return None
    where = "/".join(str(p) for p in err.absolute_path)
    return f"{where}: {err.message}" if where else err.message


def sts_reasons() -> frozenset[str]:
    return frozenset(r["reason"] for r in load("refusals/refusals.json")["refusals"])


def tool_refusals() -> list[str]:
    return [r["error"] for r in load("audit/tool/refusals.json")["refusals"]]
