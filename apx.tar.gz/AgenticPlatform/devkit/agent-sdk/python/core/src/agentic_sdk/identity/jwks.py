"""Issuers' signing keys, cached by Identity's rules: at most 5 minutes old;
on an unknown kid, refetched at most once per 30 seconds per issuer; keys
that disappear are dropped; on fetch errors the last good set is served for
at most 15 minutes after the last successful fetch, then nothing is."""

from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Callable
from typing import Any, Protocol

import httpx

log = logging.getLogger("agentic_sdk.identity")

MAX_AGE = 300.0
UNKNOWN_KID_INTERVAL = 30.0
LAST_GOOD = 900.0


class KeysUnavailable(Exception):
    """No key set to check a token against: the issuer's JWKS could not be
    fetched and the last good set, if any, is past its bound."""


class KeySource(Protocol):
    async def key(self, kid: str) -> dict[str, Any] | None: ...


def _index(jwks: Any) -> dict[str, dict[str, Any]]:
    keys = jwks.get("keys") if isinstance(jwks, dict) else None
    if not isinstance(keys, list):
        raise ValueError("not a JWK set")
    out = {}
    for k in keys:
        if isinstance(k, dict) and isinstance(k.get("kid"), str) and not any(m in k for m in ("d", "p", "q")):
            out[k["kid"]] = k
    return out


class StaticKeys:
    """A fixed JWK set, for tests and vectors."""

    def __init__(self, jwks: dict[str, Any]):
        self._keys = _index(jwks)

    async def key(self, kid: str) -> dict[str, Any] | None:
        return self._keys.get(kid)


class JwksCache:
    """One issuer's JWK set, fetched from its jwks_uri when first needed."""

    def __init__(self, uri: str, client: Callable[[], httpx.AsyncClient], *,
                 clock: Callable[[], float] = time.monotonic,
                 max_age: float = MAX_AGE, unknown_kid_interval: float = UNKNOWN_KID_INTERVAL,
                 last_good: float = LAST_GOOD):
        self.uri = uri
        self._client = client
        self._clock = clock
        self._max_age = max_age
        self._unknown_kid_interval = unknown_kid_interval
        self._last_good = last_good
        self._keys: dict[str, dict[str, Any]] | None = None
        self._fetched_at: float | None = None  # last successful fetch
        self._attempted_at: float | None = None  # last attempt, successful or not
        self._unknown_kid_at: float | None = None
        self._last_failed = False
        self._lock = asyncio.Lock()

    async def _refresh(self) -> None:
        self._attempted_at = self._clock()
        try:
            resp = await self._client().get(self.uri, headers={"Accept": "application/json"})
            resp.raise_for_status()
            keys = _index(resp.json())
        except (httpx.HTTPError, ValueError) as e:
            log.warning("JWKS fetch failed for %s: %s", self.uri, type(e).__name__)
            self._last_failed = True
            return
        self._last_failed = False
        self._keys = keys
        self._fetched_at = self._clock()

    def _usable(self) -> dict[str, dict[str, Any]]:
        if self._keys is None or self._fetched_at is None or self._clock() - self._fetched_at > self._last_good:
            raise KeysUnavailable(self.uri)
        return self._keys

    async def key(self, kid: str) -> dict[str, Any] | None:
        async with self._lock:
            now = self._clock()
            stale = self._fetched_at is None or now - self._fetched_at >= self._max_age
            # A failed attempt is not repeated on every request: at most once per
            # unknown-kid interval while the set is stale.
            recently_tried = self._attempted_at is not None and now - self._attempted_at < self._unknown_kid_interval
            refreshed = False
            if stale and not (recently_tried and self._last_failed):
                await self._refresh()
                refreshed = True
            keys = self._usable()
            if kid in keys or refreshed:
                return keys.get(kid)
            if self._unknown_kid_at is None or now - self._unknown_kid_at >= self._unknown_kid_interval:
                self._unknown_kid_at = now
                await self._refresh()
                keys = self._usable()
            return keys.get(kid)
