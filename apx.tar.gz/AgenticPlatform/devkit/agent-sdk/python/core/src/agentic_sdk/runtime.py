"""The workload's settings, read from the environment the platform gives it
(the seams in agent-sdk's B5 decisions: app-base sets them in a pod, the
contract stage in CI), and the objects built from them. Nothing here makes
a network call: keys, tokens and the collector are reached when first needed."""

from __future__ import annotations

import json
import logging
import os
import re
import ssl
from collections.abc import Mapping
from dataclasses import dataclass, field
from functools import cached_property
from typing import Any

import httpx

from . import context
from .approvals import approval_lifetime
from .audit import AuditEmitter
from .delegation import ActorTokenFile, Exchanger
from .identity import PROFILES, IssuerTrust, JwksCache, Route, Verifier
from .limits import WORKLOAD_FILE, Caps, ConfigError, environment_caps, read_workload

log = logging.getLogger("agentic_sdk.runtime")

DEFAULT_ACTOR_TOKEN_FILE = "/var/run/secrets/agentic/sts/token"
_NAME = re.compile(r"[a-z0-9]+(-[a-z0-9]+)*")
DEFAULT_LISTEN = "0.0.0.0:8080"


@dataclass(frozen=True)
class TrustEntry:
    issuer: str
    profile: str
    jwks_uri: str
    audience: str
    atespaces: tuple[str, ...] | None = None


_FIELDS = {"issuer", "profile", "jwks_uri", "audience"}
_NAMESPACE = re.compile(r"[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?")
# AGENTIC_SUBSTRATE_ROUTE: one path segment that none of the paths the SDK
# serves begins with.
_ROUTE = re.compile(r"/[a-z0-9]+(-[a-z0-9]+)*")
_RESERVED = {"/mcp", "/a2a", "/approvals", "/healthz", "/readyz"}


def parse_trust(raw: str, *, substrate_route: str | None = None) -> list[TrustEntry]:
    """AGENTIC_TRUST: a JSON array of {issuer, profile, jwks_uri, audience}; a
    substrate-actor entry also names atespaces, a non-empty array of the
    kagent agents' namespaces its route admits, and needs substrate_route,
    the path that route reaches the workload under (D30)."""
    try:
        doc = json.loads(raw)
    except ValueError:
        raise ConfigError("AGENTIC_TRUST: not JSON") from None
    if not isinstance(doc, list) or not doc:
        raise ConfigError("AGENTIC_TRUST: not a non-empty JSON array")
    out = []
    for i, e in enumerate(doc):
        actor = isinstance(e, dict) and e.get("profile") == "substrate-actor"
        want = _FIELDS | {"atespaces"} if actor else _FIELDS
        if not isinstance(e, dict) or set(e) != want or not all(isinstance(e[k], str) and e[k] for k in _FIELDS):
            raise ConfigError(f"AGENTIC_TRUST[{i}]: needs exactly issuer, profile, jwks_uri and audience, as strings"
                              + (", and atespaces" if actor else ""))
        if e["profile"] not in PROFILES:
            raise ConfigError(f"AGENTIC_TRUST[{i}]: unknown profile {e['profile']!r}")
        if actor:
            ns = e["atespaces"]
            if not isinstance(ns, list) or not ns or not all(isinstance(n, str) and _NAMESPACE.fullmatch(n) for n in ns):
                raise ConfigError(f"AGENTIC_TRUST[{i}]: atespaces is not a non-empty array of namespace names")
            if not substrate_route:
                raise ConfigError(f"AGENTIC_TRUST[{i}]: Substrate actor tokens need AGENTIC_SUBSTRATE_ROUTE, "
                                  "the path their route on Substrate's listener calls (D30)")
            out.append(TrustEntry(e["issuer"], e["profile"], e["jwks_uri"], e["audience"], tuple(ns)))
        else:
            out.append(TrustEntry(**e))
    if len({e.issuer for e in out}) != len(out):
        raise ConfigError("AGENTIC_TRUST: an issuer appears twice")
    if substrate_route and not any(e.profile == "substrate-actor" for e in out):
        raise ConfigError("AGENTIC_SUBSTRATE_ROUTE is set, but AGENTIC_TRUST names no substrate-actor issuer")
    return out


@dataclass
class Runtime:
    """Settings and shared objects for one workload process."""

    environ: Mapping[str, str] = field(default_factory=lambda: dict(os.environ))
    workload_file: str = WORKLOAD_FILE

    # --- settings -------------------------------------------------------------
    @cached_property
    def workload(self) -> dict[str, Any] | None:
        """The workload file, or None when it is missing (a workload that applies
        limits then calls caps(), which refuses to start without it)."""
        if not os.path.exists(self.workload_file):
            return None
        return read_workload(self.workload_file)

    @cached_property
    def name(self) -> str | None:
        """The service's name in telemetry: OTEL_SERVICE_NAME, else the workload's name."""
        return self.environ.get("OTEL_SERVICE_NAME") or self.workload_name

    @cached_property
    def workload_name(self) -> str | None:
        """AGENTIC_WORKLOAD_NAME, else the workload file's name: the name in the
        paths the workload serves, /a2a/<name> and /approvals/<name>/."""
        v = self.environ.get("AGENTIC_WORKLOAD_NAME") or (self.workload or {}).get("name")
        if v is not None and not _NAME.fullmatch(v):
            raise ConfigError(f"AGENTIC_WORKLOAD_NAME={v!r}: not lowercase kebab-case of at most 63 characters")
        return v

    def require_workload_name(self) -> str:
        if not self.workload_name:
            raise ConfigError("neither AGENTIC_WORKLOAD_NAME nor a workload file names the workload")
        return self.workload_name

    def caps(self) -> Caps:
        """The caps in force: the workload file's, lowered by AGENTIC_LIMIT_*."""
        if self.workload is None:
            raise ConfigError(f"no workload file at {self.workload_file}")
        return environment_caps(Caps.from_declaration(self.workload.get("limits")), self.environ)

    @cached_property
    def gateway_url(self) -> str | None:
        v = self.environ.get("AGENTIC_GATEWAY_URL", "").rstrip("/")
        return v or None

    @cached_property
    def resource_base(self) -> str | None:
        v = self.environ.get("AGENTIC_RESOURCE_BASE", "").rstrip("/")
        return v or self.gateway_url

    def url(self, route: str) -> str:
        """Where to call route (v1, mcp/<name>, a2a/<name>)."""
        if not self.gateway_url:
            raise ConfigError("AGENTIC_GATEWAY_URL is not set")
        return f"{self.gateway_url}/{route}"

    def resource(self, route: str) -> str:
        """The RFC 8707 resource, and so the audience, of route."""
        if not self.resource_base:
            raise ConfigError("neither AGENTIC_RESOURCE_BASE nor AGENTIC_GATEWAY_URL is set")
        return f"{self.resource_base}/{route}"

    @cached_property
    def leeway(self) -> int:
        raw = self.environ.get("AGENTIC_TOKEN_LEEWAY_SECONDS", "")
        if raw == "":
            return 60
        if not (raw.isdigit() and int(raw) <= 60):
            raise ConfigError(f"AGENTIC_TOKEN_LEEWAY_SECONDS={raw!r}: not 0 to 60")
        return int(raw)

    @cached_property
    def substrate_route(self) -> str | None:
        """AGENTIC_SUBSTRATE_ROUTE: the path prefix the gateway's route on
        Substrate's listener calls this workload under (/substrate, so its MCP
        endpoint at /substrate/mcp), the one place where AGENTIC_TRUST's
        substrate-actor issuer is accepted; unset, nowhere (D30)."""
        v = self.environ.get("AGENTIC_SUBSTRATE_ROUTE", "")
        if not v:
            return None
        if not _ROUTE.fullmatch(v) or v in _RESERVED:
            raise ConfigError(f"AGENTIC_SUBSTRATE_ROUTE={v!r}: not one lowercase path segment, such as /substrate, "
                              f"outside {', '.join(sorted(_RESERVED))}")
        return v

    @cached_property
    def trust(self) -> list[TrustEntry]:
        raw = self.environ.get("AGENTIC_TRUST", "")
        if not raw:
            raise ConfigError("AGENTIC_TRUST is not set: no issuer to verify inbound tokens against")
        return parse_trust(raw, substrate_route=self.substrate_route)

    @cached_property
    def listen(self) -> tuple[str, int]:
        host, _, port = self.environ.get("AGENTIC_LISTEN", DEFAULT_LISTEN).rpartition(":")
        if not port.isdigit():
            raise ConfigError("AGENTIC_LISTEN: not host:port")
        return host or "0.0.0.0", int(port)

    def check(self) -> None:
        """Reads every setting given, so a bad one stops the workload at start."""
        _ = self.substrate_route
        _ = self.trust if self.environ.get("AGENTIC_TRUST") else None
        if self.substrate_route and not self.environ.get("AGENTIC_TRUST"):
            raise ConfigError("AGENTIC_SUBSTRATE_ROUTE is set, but AGENTIC_TRUST is not")
        _ = self.leeway, self.listen, self.workload_name
        if self.environ.get("AGENTIC_APPROVAL_TTL_SECONDS"):
            try:
                approval_lifetime(self.environ)
            except ValueError as e:
                raise ConfigError(str(e)) from None
        if self.workload is not None:
            self.caps()

    # --- shared objects --------------------------------------------------------
    def ssl_context(self) -> ssl.SSLContext:
        """TLS for the platform's endpoints: the system's roots and AGENTIC_CA_FILE."""
        ctx = ssl.create_default_context()
        ca = self.environ.get("AGENTIC_CA_FILE")
        if ca:
            ctx.load_verify_locations(cafile=ca)
        return ctx

    @cached_property
    def http(self) -> httpx.AsyncClient:
        """One HTTP client for the platform's endpoints, trusting AGENTIC_CA_FILE
        besides the system's roots. Made when first used."""
        return httpx.AsyncClient(verify=self.ssl_context(), timeout=httpx.Timeout(10.0), trust_env=False)

    @cached_property
    def _keys(self) -> dict[str, JwksCache]:
        """One key cache per issuer, shared by the verifiers that trust it."""
        return {e.issuer: JwksCache(e.jwks_uri, lambda: self.http) for e in self.trust}

    def _verifier(self, entries: list[TrustEntry], audience: str | None = None, **kw: Any) -> Verifier:
        return Verifier([IssuerTrust(e.issuer, PROFILES[e.profile], self._keys[e.issuer], audience or e.audience,
                                     frozenset(e.atespaces) if e.atespaces else None) for e in entries],
                        leeway=self.leeway, **kw)

    @cached_property
    def verifier(self) -> Verifier:
        """The inbound verifier: AGENTIC_TRUST's issuers but Substrate's; and,
        under AGENTIC_SUBSTRATE_ROUTE alone, Substrate's and no other, for
        actor tokens of the atespaces its entry names, as the gateway's route
        on Substrate's listener admits nothing else (D30)."""
        rest = [e for e in self.trust if e.profile != "substrate-actor"]
        if not self.substrate_route:
            return self._verifier(rest)
        actors = [e for e in self.trust if e.profile == "substrate-actor"]
        return self._verifier(rest, routes=[Route(self.substrate_route, self._verifier(actors))])

    @cached_property
    def approval_verifier(self) -> Verifier:
        """The approval route's verifier: AGENTIC_TRUST's Keycloak issuers, with
        AGENTIC_APPROVAL_AUDIENCE in place of their audience."""
        aud = self.environ.get("AGENTIC_APPROVAL_AUDIENCE")
        if not aud:
            raise ConfigError("AGENTIC_APPROVAL_AUDIENCE is not set")
        people = [e for e in self.trust if e.profile == "keycloak"]
        if not people:
            raise ConfigError("AGENTIC_TRUST names no keycloak issuer for approvers")
        return self._verifier(people, aud)

    @cached_property
    def approval_lifetime(self) -> int:
        return approval_lifetime(self.environ)

    @cached_property
    def exchanger(self) -> Exchanger:
        endpoint = self.environ.get("AGENTIC_STS_TOKEN_ENDPOINT")
        if not endpoint:
            raise ConfigError("AGENTIC_STS_TOKEN_ENDPOINT is not set")
        actor = ActorTokenFile(self.environ.get("AGENTIC_ACTOR_TOKEN_FILE") or DEFAULT_ACTOR_TOKEN_FILE)
        return Exchanger(endpoint, actor, lambda: self.http)

    async def token_for(self, route: str) -> str:
        """A token for route (v1, mcp/<name>, a2a/<name>), exchanged at the STS
        for the current invocation's caller."""
        inv = context.require()
        if not inv.token:
            raise context.NoInvocation("the current invocation has no subject token to exchange")
        return await self.exchanger.token(inv.token, self.resource(route))

    @cached_property
    def audit(self) -> AuditEmitter:
        from .telemetry import resource

        return AuditEmitter.from_env(self.name or "unknown", self.environ, resource=resource(self.name))

    @cached_property
    def store(self):
        """The approval and idempotency store: Postgres at AGENTIC_DATABASE_URL,
        connected when first used, or in memory, with a warning, when it is unset."""
        dsn = self.environ.get("AGENTIC_DATABASE_URL")
        if not dsn:
            from .store import MemoryStore

            log.warning("AGENTIC_DATABASE_URL is not set: approvals and idempotency keys are kept in memory")
            return MemoryStore()
        from .store_postgres import PostgresStore

        return PostgresStore(dsn)
