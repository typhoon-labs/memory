"""The current invocation: who called, with which token, for which task.

Set once per inbound request (by identity's ASGI middleware, or by an
adapter), and read wherever the work for that request needs it: the model
route's key callable, an MCP client's header provider, the exchange. It is
a context variable, so tasks the request starts inherit it and concurrent
requests never see each other's."""

from __future__ import annotations

import contextlib
import contextvars
from collections.abc import Iterator
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

from opentelemetry import propagate

from .headers import TaskHeaders

if TYPE_CHECKING:
    from .identity import Principal
    from .limits import TaskLimits


@dataclass(frozen=True)
class Invocation:
    """One request's work. token is the inbound bearer token, the subject of
    any exchange; it never leaves the process except to the STS."""

    task: TaskHeaders
    principal: Principal | None = None
    token: str | None = None
    limits: TaskLimits | None = None

    @property
    def task_id(self) -> str | None:
        return self.task.task_id

    def with_limits(self, limits: TaskLimits | None) -> Invocation:
        return replace(self, limits=limits)

    def attributes(self) -> dict[str, object]:
        """What spans and records carry for this invocation: the task and
        workflow, and the caller's user.id, session.id and actor.sub."""
        out: dict[str, object] = dict(self.task.attributes())
        if self.principal is not None:
            a = self.principal.attributes()
            for k in ("user.id", "user.team", "session.id", "actor.sub"):
                if k in a:
                    out[k] = a[k]
        return out


_current: contextvars.ContextVar[Invocation | None] = contextvars.ContextVar("agentic_invocation", default=None)


class NoInvocation(RuntimeError):
    """Work that needs a caller ran outside any invocation."""


def current() -> Invocation | None:
    return _current.get()


def require() -> Invocation:
    inv = _current.get()
    if inv is None:
        raise NoInvocation("no invocation is active: set one with agentic_sdk.context.use()")
    return inv


@contextlib.contextmanager
def use(invocation: Invocation) -> Iterator[Invocation]:
    """Makes invocation the current one inside the block."""
    token = _current.set(invocation)
    try:
        yield invocation
    finally:
        _current.reset(token)


def outbound_headers(invocation: Invocation | None = None) -> dict[str, str]:
    """The task and workflow headers and the W3C trace context, for any
    request made for the invocation. No credential."""
    inv = invocation if invocation is not None else _current.get()
    out = inv.task.outbound() if inv is not None else {}
    propagate.inject(out)
    return out
