"""approvals and idempotency for an MCP server's tools (spec/audit/tool/,
spec/audit/approval/): the checks a tool makes after the token, in order
(idempotency, approval, apply), the refusal results, the tool audit record
of every call, and the approval route through which a person approves."""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any

from opentelemetry import trace

from . import context, contract
from .audit import AuditEmitter, tool_record
from .canonical import parameters_hash
from .identity import Principal, TokenRefused, Verifier
from .identity.asgi import bearer, refuse, unavailable
from .identity.jwks import KeysUnavailable
from .limits import Caps, LimitExceeded, TaskLimits
from .telemetry import mark_limit_exceeded
from .store import Apply, Store, Transaction, new_approval_id

log = logging.getLogger("agentic_sdk.approvals")
tracer = trace.get_tracer("agentic_sdk.approvals")

_ROUTE = contract.load("audit/approval/route.json")
_ROUTE_STATUS = {r["error"]: r["status"] for r in _ROUTE["refusals"]}
DEFAULT_LIFETIME = _ROUTE["expiry"]["lifetime_seconds_default"]
MAX_LIFETIME = _ROUTE["expiry"]["lifetime_seconds_maximum"]
TOOL_REFUSALS = contract.tool_refusals()
RELEASE_SECONDS = 2.0
# How long a call stopped by its wall time may take to unwind in the
# background (its transaction's rollback through a slow database, say)
# before its connection is closed, which ends the transaction unmade.
UNWIND_SECONDS = 10.0
# How long the limit's answer waits for that unwind, so that with a store
# that answers the key is free again when the caller hears of the stop.
UNWIND_GRACE_SECONDS = 0.5


@dataclass(frozen=True)
class Target:
    """The object a call changes, and its version as found now."""

    id: str
    version: str


@dataclass(frozen=True)
class ToolPolicy:
    """What a tool's MCP annotations make of it. MCP's defaults count: a tool
    is read-only only when readOnlyHint is true, and destructive unless
    destructiveHint is false."""

    name: str
    read_only: bool = False
    destructive: bool = True
    approval: bool | None = None  # None: needed when the annotations make the tool destructive

    @classmethod
    def from_annotations(cls, name: str, annotations: Mapping[str, Any] | None, *, approval: bool | None = None) -> ToolPolicy:
        a = annotations or {}
        read_only = a.get("readOnlyHint") is True
        destructive = not read_only and a.get("destructiveHint") is not False
        return cls(name, read_only, destructive, approval)

    @property
    def needs_approval(self) -> bool:
        return self.approval if self.approval is not None else (not self.read_only and self.destructive)

    @property
    def deduplicates(self) -> bool:
        return not self.read_only


def refusal_result(error: str, message: str, approval_id: str | None = None) -> dict[str, Any]:
    """The MCP result of a refusal: isError, the refusal object, and text for people."""
    sc: dict[str, Any] = {"error": error, "message": message}
    if approval_id is not None:
        sc["approval_id"] = approval_id
    return {"isError": True, "structuredContent": sc, "content": [{"type": "text", "text": message}]}


_MESSAGES = {
    "idempotency_in_progress": "The same call is still being applied; try again shortly.",
    "approval_unknown": "That approval_id names no approval for this tool.",
    "approval_caller": "That approval was proposed by someone else.",
    "approval_pending": "Nobody has approved this yet.",
    "approval_self": "The approval was given by its proposer.",
    "approval_assurance": "The approver's sign-in is not strong enough for this action.",
    "approval_used": "That approval has been used already.",
    "approval_expired": "That approval has expired.",
    "approval_parameters": "The call's parameters differ from the approved ones.",
    "approval_version": "The object changed after the approval was proposed.",
}


def _key(principal: Principal, task_id: str, tool: str, phash: str) -> str:
    parts = [principal.user_id or "", principal.actor_sub or "", task_id, tool, phash]
    return hashlib.sha256(json.dumps(parts, separators=(",", ":")).encode()).hexdigest()


class ToolGuard:
    """Runs one tools/call through the checks after the token: idempotency
    (tools not read-only, with a task ID), approval (tools that need one),
    and apply, in one transaction with the key's result and the approval's
    use. Each call is a task for limits, bounded by caps (an MCP server's
    wall_time_seconds), and has a span of its own, which its audit record
    names. The record is written before the call returns."""

    def __init__(self, store: Store, audit: AuditEmitter, *, caps: Caps | None = None,
                 clock: Callable[[], float] = time.time, unwind_seconds: float = UNWIND_SECONDS):
        self.store = store
        self.audit = audit
        self.caps = caps or Caps()
        self._clock = clock
        self.unwind_seconds = unwind_seconds
        self._unwinding: set[asyncio.Task] = set()

    async def call(self, policy: ToolPolicy, arguments: Mapping[str, Any], apply: Apply, *,
                   target: Callable[[Transaction | None], Awaitable[Target | None]] | None = None,
                   principal: Principal | None = None) -> dict[str, Any]:
        """apply(tx) makes the change and returns the MCP result; target(tx)
        reads the object's current version (tx is None outside the transaction).
        principal and the task come from the current invocation by default."""
        inv = context.require()
        principal = principal or inv.principal
        if principal is None:
            raise context.NoInvocation("a tool call needs a verified caller")
        limits = TaskLimits(self.caps, inv.task.task_id)
        call = _Call(self, policy, dict(arguments), apply, target, principal, inv.task)
        with tracer.start_as_current_span(f"execute_tool {policy.name}", kind=trace.SpanKind.INTERNAL,
                                          attributes={"gen_ai.operation.name": "execute_tool",
                                                      "gen_ai.tool.name": policy.name}) as span, \
                context.use(inv.with_limits(limits)):
            call.span = span
            # The call runs as a task of its own, so that its wall time
            # answers at the cap: a cancelled call may take long to unwind,
            # its transaction rolling back through a slow database, and
            # unwinds in the background instead, bounded (_unwind).
            run = asyncio.ensure_future(call.run())
            stopped = False
            try:
                return await limits.bounded(asyncio.shield(run))
            except LimitExceeded as e:
                # The key is released once the call has unwound, after its
                # rollback, in the background too.
                stopped = True
                await asyncio.wait({self._unwind(run, call)}, timeout=UNWIND_GRACE_SECONDS)
                mark_limit_exceeded(span)
                await call.record("failed", error_type="limit_exceeded", approval_id=call.approval_id)
                return e.mcp_result()
            except asyncio.CancelledError:
                run.cancel()
                raise
            finally:
                if not stopped:
                    await asyncio.shield(call.release_within(RELEASE_SECONDS))

    def _unwind(self, run: asyncio.Task, call: _Call) -> asyncio.Task:
        """Cancels a call stopped by its wall time and lets it unwind in the
        background: its transaction rolls back, so the call has no effect,
        and then its idempotency key is released. Past unwind_seconds its
        connection is closed, which ends the transaction unmade and returns
        nothing half-used to the pool."""
        run.cancel()

        async def unwind() -> None:
            done, _ = await asyncio.wait({run}, timeout=self.unwind_seconds)
            if run not in done:
                log.warning("tool %s still unwinding after %g s: closing its connection", call.policy.name,
                            self.unwind_seconds)
                call.abort()
                await asyncio.wait({run}, timeout=self.unwind_seconds)
            if run.done() and not run.cancelled() and run.exception() is not None:
                log.warning("tool %s unwound with %s", call.policy.name, type(run.exception()).__name__)
            # The key, now that nothing can complete it: free for the same
            # task again. Not released in time, it is taken over once stale.
            await call.release_within(self.unwind_seconds)

        task = asyncio.ensure_future(unwind())
        self._unwinding.add(task)
        task.add_done_callback(self._unwinding.discard)
        return task

    async def _propose(self, policy, arguments, phash, principal, task_id, found) -> dict[str, Any]:
        """The pending proposal for this caller, tool, parameters and target version: new, or one held already."""
        caller = principal.caller
        pkey = hashlib.sha256(json.dumps(
            [caller, policy.name, phash, found.id if found else None, found.version if found else None],
            sort_keys=True, separators=(",", ":")).encode()).hexdigest()

        def make() -> dict[str, Any]:
            rec: dict[str, Any] = {"id": new_approval_id(), "tool": policy.name, "parameters_hash": phash,
                                   "arguments": {k: v for k, v in arguments.items() if k != "approval_id"},
                                   "proposer": caller, "proposed_at": int(self._clock())}
            if found is not None:
                rec["target"] = {"id": found.id, "version": found.version}
            if task_id:
                rec["task_id"] = task_id
            return rec

        return await self.store.proposal(pkey, make)

    async def _check(self, policy, approval_id, phash, principal, found) -> str | None:
        """The first approval refusal, in refusals.json's order, or None."""
        rec = await self.store.approval(approval_id)
        if rec is None or rec.get("tool") != policy.name:
            return "approval_unknown"
        if rec["proposer"] != principal.caller:
            return "approval_caller"
        if "approver" not in rec:
            return "approval_pending"
        proposer_user = rec["proposer"].get("user.id")
        if proposer_user is not None and rec["approver"]["user.id"] == proposer_user:
            return "approval_self"
        if "required_acr" in rec and _acr(rec["approver"].get("acr")) < int(rec["required_acr"]):
            return "approval_assurance"
        if "used_at" in rec:
            return "approval_used"
        if self._clock() >= rec["expires_at"]:
            return "approval_expired"
        if rec["parameters_hash"] != phash:
            return "approval_parameters"
        if "target" in rec and (found is None or found.version != rec["target"]["version"]):
            return "approval_version"
        return None


class _Call:
    """One tools/call's state through the guard."""

    def __init__(self, guard: ToolGuard, policy: ToolPolicy, arguments: dict[str, Any], apply: Apply,
                 target, principal: Principal, task) -> None:
        self.g, self.policy, self.arguments, self.apply, self.target = guard, policy, arguments, apply, target
        self.principal, self.task = principal, task
        self.phash = parameters_hash(arguments)
        aid = arguments.get("approval_id")
        self.approval_id = aid if isinstance(aid, str) else None
        self.found: Target | None = None
        self.key = (_key(principal, task.task_id, policy.name, self.phash)
                    if policy.deduplicates and task.task_id else None)
        self.held = False  # the key is reserved by this call and neither completed nor released
        self.span: trace.Span | None = None
        self.tx: Transaction | None = None  # the open transaction, while apply runs

    def abort(self) -> None:
        """Closes the open transaction's database connection, if it has one:
        the server ends the transaction unmade, and the pool replaces the
        connection."""
        conn = getattr(self.tx, "connection", None)
        if conn is not None and hasattr(conn, "terminate"):
            try:
                conn.terminate()
            except Exception as e:  # released to the pool meanwhile: not ours to close
                log.warning("not closing the stopped call's connection: %s", type(e).__name__)

    async def release(self) -> None:
        if self.held and self.key is not None:
            await self.g.store.release_key(self.key)
            self.held = False

    async def release_within(self, seconds: float) -> None:
        """release, bounded: a call stopped by its wall time, often because the
        store is slow, answers without waiting long on the store again. A key
        not released in time is taken over once it is stale (store.py)."""
        try:
            async with asyncio.timeout(seconds):
                await self.release()
        except (TimeoutError, OSError) as e:
            log.warning("idempotency key not released: %s", type(e).__name__)

    async def record(self, outcome: str, **kw: Any) -> None:
        await self.g.audit.emit_async(tool_record(
            tool=self.policy.name, outcome=outcome, parameters_hash=self.phash, destructive=self.policy.destructive,
            principal_attributes=self.principal.attributes(), task_attributes=self.task.attributes(),
            target_id=self.found.id if self.found else None,
            target_version=self.found.version if self.found else None, span=self.span, **kw))

    async def refused(self, error: str, approval_id: str | None = None, message: str | None = None) -> dict[str, Any]:
        await self.release()
        await self.record("refused", refusal_reason=error, approval_id=approval_id)
        return refusal_result(error, message or _MESSAGES.get(error, error), approval_id if error == "approval_missing" else None)

    async def run(self) -> dict[str, Any]:
        g, policy = self.g, self.policy
        if self.key is not None:
            state = await g.store.reserve_key(self.key)
            if state.state == "completed":
                await self.record("replayed", approval_id=self.approval_id)
                return state.result
            if state.state == "in_progress":
                await self.record("refused", refusal_reason="idempotency_in_progress")
                return refusal_result("idempotency_in_progress", _MESSAGES["idempotency_in_progress"])
            self.held = True
        try:
            if policy.needs_approval:
                self.found = await self.target(None) if self.target else None
                if self.approval_id is None:
                    rec = await g._propose(policy, self.arguments, self.phash, self.principal, self.task.task_id, self.found)
                    msg = (f"{policy.name} needs an approval by someone other than you. Ask for approval {rec['id']}, "
                           f"then call again with it as approval_id.")
                    return await self.refused("approval_missing", rec["id"], msg)
                error = await g._check(policy, self.approval_id, self.phash, self.principal, self.found)
                if error:
                    return await self.refused(error, self.approval_id)
            try:
                try:
                    async with g.store.transaction() as tx:
                        self.tx = tx
                        if policy.needs_approval and self.target is not None:
                            now_found = await self.target(tx)
                            if (now_found.version if now_found else None) != (self.found.version if self.found else None):
                                raise _Refusal("approval_version")
                        result = await self.apply(tx)
                        if self.key is not None:
                            await tx.complete_key(self.key, result)
                        if policy.needs_approval and not await tx.use_approval(self.approval_id, int(g._clock())):
                            raise _Refusal("approval_used")
                finally:
                    self.tx = None  # its connection may be back in the pool
            except _Refusal as r:
                return await self.refused(r.error, self.approval_id)
            self.held = False  # completed with the transaction
        except LimitExceeded:
            raise
        except Exception as e:
            if (me := asyncio.current_task()) is not None and me.cancelling():
                # Stopped by its wall time: what the cancellation raised on
                # its way out (a driver's TimeoutError) is not the tool's
                # failure, and the guard has answered and recorded it.
                raise asyncio.CancelledError() from e
            await self.release()
            await self.record("failed", error_type=type(e).__name__, approval_id=self.approval_id)
            log.warning("tool %s failed: %s", policy.name, type(e).__name__)
            return {"isError": True, "content": [{"type": "text", "text": f"{policy.name} failed."}]}
        await self.record("completed", approval_id=self.approval_id)
        return result


class _Refusal(Exception):
    def __init__(self, error: str):
        self.error = error


def _acr(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return -1


def approval_lifetime(environ: Mapping[str, str]) -> int:
    """AGENTIC_APPROVAL_TTL_SECONDS: 1 to 900, 300 when unset."""
    raw = environ.get("AGENTIC_APPROVAL_TTL_SECONDS", "")
    if raw == "":
        return DEFAULT_LIFETIME
    if not (raw.isascii() and raw.isdigit()) or not 1 <= int(raw) <= MAX_LIFETIME:
        raise ValueError(f"AGENTIC_APPROVAL_TTL_SECONDS={raw!r}: not an integer from 1 to {MAX_LIFETIME}")
    return int(raw)


class ApprovalRoute:
    """The approval route (spec/audit/approval/route.json) as an ASGI app,
    to mount beside the MCP endpoint: GET and POST /approvals/<name>/{id},
    name being the workload's, with the approver's own token, which verifier
    must take from Keycloak alone. current_target(tool, target_id) reads a
    target's version now."""

    def __init__(self, store: Store, verifier: Verifier, *, name: str, lifetime: int = DEFAULT_LIFETIME,
                 current_target: Callable[[str, str], Awaitable[Target | None]] | None = None,
                 clock: Callable[[], float] = time.time):
        if not 1 <= lifetime <= MAX_LIFETIME:
            raise ValueError(f"an approval lives 1 to {MAX_LIFETIME} seconds")
        self.prefix = f"/approvals/{name}/"
        self.store, self.verifier, self.lifetime = store, verifier, lifetime
        self.current_target = current_target
        self._clock = clock

    @staticmethod
    async def _json(send, status: int, body: dict[str, Any]) -> None:
        data = json.dumps(body).encode()
        await send({"type": "http.response.start", "status": status,
                    "headers": [(b"content-type", b"application/json"), (b"content-length", str(len(data)).encode())]})
        await send({"type": "http.response.body", "body": data})

    async def _refuse(self, send, error: str, message: str) -> None:
        await self._json(send, _ROUTE_STATUS[error], {"error": error, "message": message})

    async def __call__(self, scope, receive, send) -> None:
        path = scope.get("path", "")
        if scope["type"] != "http" or not path.startswith(self.prefix) or scope["method"] not in ("GET", "POST"):
            return await self._json(send, 404, {"error": "not_found"})
        approval_id = path[len(self.prefix):]
        token, sent = bearer(scope)
        try:
            approver = await self.verifier.verify(token)
        except TokenRefused as e:
            log.info("approval route: token refused: %s", e.reason)
            return await refuse(send, sent and e.token_sent)
        except KeysUnavailable:
            return await unavailable(send)
        if approver.kind != "person":
            return await refuse(send, True)
        if scope["method"] == "GET":
            rec = await self.store.approval(approval_id)
            if rec is None:
                return await self._refuse(send, "approval_unknown", "No such approval.")
            return await self._json(send, 200, rec)
        body = b""
        while True:
            m = await receive()
            body += m.get("body", b"")
            if not m.get("more_body"):
                break
        try:
            req = json.loads(body)
        except ValueError:
            req = None
        if req is None or contract.first_error("audit/approval/approve.schema.json", req):
            return await self._refuse(send, "approval_request", "The body must name parameters_hash, and target_version when there is a target.")
        rec = await self.store.approval(approval_id)
        if rec is None:
            return await self._refuse(send, "approval_unknown", "No such approval.")
        if ("target" in rec) != ("target_version" in req):
            return await self._refuse(send, "approval_request", "target_version must be given exactly when the proposal names a target.")
        if "approver" in rec:
            return await self._refuse(send, "approval_decided", "This approval was given already.")
        if rec["proposer"].get("user.id") == approver.user_id:
            return await self._refuse(send, "approval_self", "You proposed this call: someone else must approve it.")
        if "required_acr" in rec and _acr(approver.acr) < int(rec["required_acr"]):
            return await self._refuse(send, "approval_assurance", "Sign in with a stronger method to approve this.")
        if req["parameters_hash"] != rec["parameters_hash"]:
            return await self._refuse(send, "approval_parameters", "The parameters you read are not the proposal's.")
        if "target" in rec:
            now = await self.current_target(rec["tool"], rec["target"]["id"]) if self.current_target else None
            if req["target_version"] != rec["target"]["version"] or now is None or now.version != rec["target"]["version"]:
                return await self._refuse(send, "approval_version", "The object changed after this was proposed.")
        at = int(self._clock())
        who = {"user.id": approver.user_id}
        if approver.acr is not None:
            who["acr"] = approver.acr
        done = await self.store.approve(approval_id, who, at, at + self.lifetime)
        if done is None:
            return await self._refuse(send, "approval_decided", "This approval was given already.")
        log.info("approval %s given", approval_id)
        return await self._json(send, 200, done)
