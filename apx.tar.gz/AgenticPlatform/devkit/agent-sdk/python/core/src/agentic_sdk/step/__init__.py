"""The bounded step's command, agentic-step (spec/step/): one schema-checked
model task with its re-prompts, tool allowlist and limits, run by agentctl
step run in a workflow's pipeline.

    agentic-step run --definition FILE --input FILE --output FILE [--workload FILE]

Exit statuses: 0 output written; 1 failed (path stop); 3 limit_exceeded;
4 failed (path human); 5 invalid, nothing called."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import ssl
import sys
import time
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, NoReturn

import httpx
import yaml
from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError
from opentelemetry import trace

from .. import context, contract, headers, telemetry
from ..identity.jose import unverified_claims
from ..limits import WORKLOAD_FILE, Caps, ConfigError, LimitExceeded, TaskLimits, environment_caps, read_workload, tokens_of

EXIT_OK, EXIT_FAILED, EXIT_LIMITS, EXIT_HUMAN, EXIT_INVALID = 0, 1, 3, 4, 5
SUBMIT = "submit_output"
EARLY_SECONDS = 30
tracer = trace.get_tracer("agentic_sdk.step")


class Invalid(Exception):
    def __init__(self, reason: str, message: str):
        super().__init__(message)
        self.reason = reason


class Failed(Exception):
    def __init__(self, reason: str, message: str):
        super().__init__(message)
        self.reason = reason


class _Parser(argparse.ArgumentParser):
    def error(self, message: str) -> NoReturn:
        raise Invalid("usage", message)


def _parser() -> argparse.ArgumentParser:
    p = _Parser(prog="agentic-step", description="Runs one bounded model step (agent-sdk spec/step/).")
    sub = p.add_subparsers(dest="command", required=True)
    run = sub.add_parser("run", help="run a step")
    run.add_argument("--definition", required=True)
    run.add_argument("--input", required=True)
    run.add_argument("--output", required=True)
    run.add_argument("--workload", default=None)
    return p


def _read(path: str, what: str, reason: str, yaml_ok: bool) -> Any:
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError as e:
        raise Invalid(reason, f"{what} {path}: {e.strerror}") from None
    try:
        return yaml.safe_load(text) if yaml_ok else json.loads(text)
    except (yaml.YAMLError, ValueError) as e:
        raise Invalid(reason, f"{what} {path}: does not parse: {e}") from None


@dataclass
class TokenSource:
    """Tokens per route scope from AGENTIC_TOKEN_COMMAND, kept until 30
    seconds before they expire. Never logged."""

    argv: list[str]
    _cache: dict[str, tuple[str, float]] = field(default_factory=dict)

    async def get(self, scope: str, *, fresh: bool = False) -> str:
        hit = self._cache.get(scope)
        if hit and not fresh and time.time() < hit[1] - EARLY_SECONDS:
            return hit[0]
        try:
            proc = await asyncio.create_subprocess_exec(*self.argv, "--scope", scope, stdin=asyncio.subprocess.DEVNULL,
                                                        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            out, err = await proc.communicate()
        except OSError as e:
            raise Failed("token_unavailable", f"token command could not run: {e.strerror}") from None
        token = out.decode(errors="replace").strip().splitlines()[0].strip() if out.strip() else ""
        if proc.returncode != 0 or not token:
            why = err.decode(errors="replace").strip().splitlines()[-1:] or ["no token printed"]
            raise Failed("token_unavailable", f"token command for {scope} failed: {why[0]}")
        exp = (unverified_claims(token) or {}).get("exp")
        self._cache[scope] = (token, float(exp) if isinstance(exp, int) else time.time() + 60)
        return token


@dataclass
class Step:
    definition: dict[str, Any]
    input: Any
    caps: Caps
    gateway: str
    tokens: TokenSource
    task: headers.TaskHeaders
    http: httpx.AsyncClient
    limits: TaskLimits = field(init=False)
    tools: dict[str, tuple[str, dict[str, Any]]] = field(default_factory=dict)  # name -> (server, MCP tool)
    verify: Any = True  # the TLS settings the gateway is trusted with

    def __post_init__(self) -> None:
        self.limits = TaskLimits(self.caps, self.task.task_id)

    async def _post(self, url: str, scope: str, body: dict[str, Any]) -> httpx.Response:
        for attempt in (0, 1):
            token = await self.tokens.get(scope, fresh=attempt == 1)
            hdrs = {"Authorization": f"Bearer {token}", **context.outbound_headers()}
            resp = await self.http.post(url, json=body, headers=hdrs)
            if resp.status_code != 401:
                return resp
        return resp

    async def model(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> dict[str, Any]:
        self.limits.before_model_call()
        body: dict[str, Any] = {"model": self.definition["model"], "messages": messages, "tools": tools}
        if "max_output_tokens" in self.definition:
            body["max_tokens"] = self.definition["max_output_tokens"]
        try:
            resp = await self.limits.bounded(self._post(f"{self.gateway}/v1/chat/completions", "models", body))
            data = resp.json()
        except httpx.HTTPError as e:
            raise Failed("model_error", f"model route unreachable: {type(e).__name__}") from None
        except ValueError:
            raise Failed("model_error", f"model route answered {resp.status_code} without JSON") from None
        if resp.status_code != 200 or not isinstance(data, dict) or not data.get("choices"):
            raise Failed("model_error", f"model route answered {resp.status_code}")
        self.limits.after_model_response(tokens_of(data.get("usage")))
        return data["choices"][0].get("message") or {}

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> str:
        server, _ = self.tools[name]
        self.limits.before_tool_call()
        from . import _mcp

        return await self.limits.bounded(_mcp.call(self, server, name, arguments))

    async def run(self) -> dict[str, Any]:
        d = self.definition
        out_schema = d["output_schema"]
        validator = Draft202012Validator(out_schema, format_checker=Draft202012Validator.FORMAT_CHECKER)
        if d.get("tools"):
            from . import _mcp

            self.tools = await self.limits.bounded(_mcp.list_tools(self, d["tools"]))
        tools = [{"type": "function", "function": {"name": n, "description": t.get("description") or n,
                                                   "parameters": t.get("inputSchema") or {"type": "object"}}}
                 for n, (_, t) in self.tools.items()]
        tools.append({"type": "function", "function": {
            "name": SUBMIT, "description": "Submit the step's output. Its parameters are the output.",
            "parameters": out_schema}})
        user = (d["prompt"].get("instructions", "") + "\n\nInput (JSON):\n" + json.dumps(self.input, ensure_ascii=False)).strip()
        messages: list[dict[str, Any]] = [{"role": "system", "content": d["prompt"]["system"]},
                                          {"role": "user", "content": user}]
        reprompts = d.get("reprompts", 2)
        problems = 0
        while True:
            msg = await self.model(messages, tools)
            messages.append({k: v for k, v in msg.items() if k in ("role", "content", "tool_calls") and v is not None}
                            | {"role": "assistant"})
            candidate, why, calls = None, None, msg.get("tool_calls") or []
            used_tool = False
            for call in calls:
                fn = call.get("function") or {}
                name, raw = fn.get("name"), fn.get("arguments") or "{}"
                try:
                    args = json.loads(raw)
                except ValueError:
                    args = None
                if name == SUBMIT:
                    candidate, why = (args, None) if isinstance(args, dict) else (None, "submit_output's arguments are not a JSON object")
                    reply = "received"
                elif name in self.tools and isinstance(args, dict):
                    reply = await self.call_tool(name, args)
                    used_tool = True
                else:
                    reply = f"Tool {name!r} is not allowed in this step."
                    used_tool = True
                messages.append({"role": "tool", "tool_call_id": call.get("id", ""), "content": reply})
            if candidate is None and not calls:
                try:
                    candidate = json.loads(msg.get("content") or "")
                except ValueError:
                    why = "the answer is neither a submit_output call nor a JSON object"
                if candidate is not None and not isinstance(candidate, dict):
                    candidate, why = None, "the answer is JSON but not an object"
            if candidate is not None:
                err = next(iter(validator.iter_errors(candidate)), None)
                if err is None:
                    return candidate
                why = f"the output does not match the output schema: {err.message}"
            elif used_tool and why is None:
                continue  # a tool's result is in; ask again, no re-prompt spent
            problems += 1
            if problems > reprompts:
                raise Failed("output_invalid", f"No valid output after {reprompts} re-prompts: {why}")
            messages.append({"role": "user", "content": f"That was not valid output: {why}. "
                             f"Call {SUBMIT} with an object that matches its parameters."})


def _write(path: str | None, obj: Mapping[str, Any]) -> None:
    if path:
        tmp = f"{path}.tmp-{os.getpid()}"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)


def _ssl(ca: str | None) -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    if ca:
        ctx.load_verify_locations(cafile=ca)
    return ctx


def _prepare(args: argparse.Namespace, environ: Mapping[str, str]) -> tuple[dict[str, Any], Any, Caps, str, list[str], headers.TaskHeaders]:
    gateway = environ.get("AGENTIC_GATEWAY_URL", "").rstrip("/")
    if not gateway:
        raise Invalid("environment_invalid", "AGENTIC_GATEWAY_URL is not set")
    try:
        argv = json.loads(environ.get("AGENTIC_TOKEN_COMMAND", ""))
    except ValueError:
        argv = None
    if not (isinstance(argv, list) and argv and all(isinstance(a, str) for a in argv)):
        raise Invalid("environment_invalid", "AGENTIC_TOKEN_COMMAND is not a JSON array of strings")
    ca = environ.get("AGENTIC_CA_FILE")
    if ca and not os.path.isfile(ca):
        raise Invalid("environment_invalid", f"AGENTIC_CA_FILE {ca}: no such file")
    definition = _read(args.definition, "definition", "definition_invalid", True)
    problem = contract.first_error("step/step.schema.json", definition)
    if problem:
        raise Invalid("definition_invalid", f"definition {args.definition}: {problem}")
    for member in ("input_schema", "output_schema"):
        try:
            Draft202012Validator.check_schema(definition[member])
        except SchemaError as e:
            raise Invalid("definition_invalid", f"definition {args.definition}: {member}: {e.message}") from None
    caps = Caps.from_declaration(definition["limits"])
    workload = args.workload or WORKLOAD_FILE
    if args.workload is not None or os.path.exists(workload):
        try:
            caps = caps.lowered(Caps.from_declaration(read_workload(workload).get("limits")))
        except ConfigError as e:
            raise Invalid("workload_invalid", str(e)) from None
    try:
        caps = environment_caps(caps, environ)
    except ConfigError as e:
        raise Invalid("environment_invalid", str(e)) from None
    data = _read(args.input, "input", "input_invalid", False)
    err = next(iter(Draft202012Validator(definition["input_schema"], format_checker=Draft202012Validator.FORMAT_CHECKER)
                    .iter_errors(data)), None)
    if err is not None:
        raise Invalid("input_invalid", f"The input does not match the step's input_schema: {err.message}")
    task = headers.from_values(environ.get("AGENTIC_TASK_ID"), environ.get("AGENTIC_WORKFLOW_NAME"),
                               environ.get("AGENTIC_WORKFLOW_VERSION")).started()
    return definition, data, caps, gateway, argv, task


async def _run(args: argparse.Namespace, environ: Mapping[str, str]) -> int:
    definition, data, caps, gateway, argv, task = _prepare(args, environ)
    on_failure = definition["on_failure"]
    tel = telemetry.configure(environ.get("AGENTIC_WORKFLOW_NAME") or definition["name"])
    try:
        return await _run_step(args, definition, data, caps, gateway, argv, task, on_failure, environ)
    finally:
        tel.tracer_provider.shutdown()  # flushes the step's spans before the process exits


async def _run_step(args, definition, data, caps, gateway, argv, task, on_failure, environ) -> int:
    verify = _ssl(environ.get("AGENTIC_CA_FILE"))
    async with httpx.AsyncClient(verify=verify, timeout=httpx.Timeout(60.0), trust_env=False) as http:
        step = Step(definition, data, caps, gateway, TokenSource(argv), task, http, verify=verify)
        inv = context.Invocation(task=task, limits=step.limits)
        with context.use(inv), tracer.start_as_current_span(f"step {definition['name']}") as span:
            span.set_attribute("gen_ai.request.model", definition["model"])
            span.set_attribute("agentic.step.prompt.version", definition["prompt"]["version"])
            try:
                output = await step.limits.bounded(step.run())
            except LimitExceeded as e:
                telemetry.mark_limit_exceeded(span)
                _write(args.output, e.error())
                print(f"agentic-step: {e}", file=sys.stderr)
                return EXIT_LIMITS
            except Failed as e:
                span.set_status(trace.Status(trace.StatusCode.ERROR, e.reason))
                span.set_attribute("error.type", e.reason)
                _write(args.output, {"error": "step_failed", "reason": e.reason, "on_failure": on_failure,
                                     "task_id": task.task_id, "message": str(e)})
                print(f"agentic-step: step_failed: {e.reason}: {e}", file=sys.stderr)
                return EXIT_HUMAN if on_failure == "human" else EXIT_FAILED
    _write(args.output, output)
    return EXIT_OK


def _output_in(argv: list[str]) -> str | None:
    """The --output path, found even when the rest of the command line is
    unusable, so a usage error still writes its step_invalid object there."""
    for i, a in enumerate(argv):
        if a == "--output" and i + 1 < len(argv):
            return argv[i + 1]
        if a.startswith("--output="):
            return a.split("=", 1)[1]
    return None


def run(argv: list[str] | None = None, environ: Mapping[str, str] | None = None) -> int:
    environ = os.environ if environ is None else environ
    output = _output_in(sys.argv[1:] if argv is None else argv)
    try:
        args = _parser().parse_args(argv)
        output = args.output
        return asyncio.run(_run(args, environ))
    except Invalid as e:
        _write(output, {"error": "step_invalid", "reason": e.reason, "message": str(e)})
        print(f"agentic-step: step_invalid: {e.reason}: {e}", file=sys.stderr)
        return EXIT_INVALID


def main() -> NoReturn:
    sys.exit(run())
