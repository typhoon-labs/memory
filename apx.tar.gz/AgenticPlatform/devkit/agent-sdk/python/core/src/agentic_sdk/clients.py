"""clients: per-target credentials for outbound calls. Each call to an MCP
server, another agent or the model route carries a token for that route
alone, exchanged for the current invocation's caller, and the task's
headers and trace context."""

from __future__ import annotations

from collections.abc import AsyncGenerator

import httpx

from . import context
from .runtime import Runtime


async def headers_for(runtime: Runtime, route: str) -> dict[str, str]:
    """Authorization for route, and the invocation's task headers and trace context."""
    token = await runtime.token_for(route)
    return {"Authorization": f"Bearer {token}", **context.outbound_headers()}


class DelegatedAuth(httpx.Auth):
    """httpx auth for one route: a token exchanged per request for the current
    invocation's caller. On a 401 it forgets the cached token and tries once more."""

    requires_response_body = False

    def __init__(self, runtime: Runtime, route: str):
        self.runtime = runtime
        self.route = route

    async def async_auth_flow(self, request: httpx.Request) -> AsyncGenerator[httpx.Request, httpx.Response]:
        for k, v in (await headers_for(self.runtime, self.route)).items():
            request.headers[k] = v
        response = yield request
        if response.status_code == 401:
            inv = context.require()
            self.runtime.exchanger.invalidate(inv.token or "", self.runtime.resource(self.route))
            request.headers["Authorization"] = f"Bearer {await self.runtime.token_for(self.route)}"
            yield request
