"""telemetry: OpenTelemetry for a workload, as Observability and Development
set it. Traces over OTLP/HTTP; GenAI content on spans only, never in logs;
W3C trace context; every span of an invocation stamped with its task,
workflow and caller; and the platform's secret patterns masked in whatever
leaves the process, as the collector masks them."""

from __future__ import annotations

import asyncio
import logging
import os
import re
import time
import weakref
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from opentelemetry import _logs, trace
from opentelemetry.context import Context
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import Event, ReadableSpan, Span, SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult
from opentelemetry.trace import Status, StatusCode

from . import context

# The collector's secret patterns (environments' 50-telemetry pipelines,
# redaction/*: blocked_values), and its mask.
SECRET_PATTERNS = (
    r"\b(AKIA|ASIA)[0-9A-Z]{16}\b",
    r"\bgl(pat|rt)-[0-9A-Za-z_.-]{20,}",
    r"\beyJ[0-9A-Za-z_-]+\.eyJ[0-9A-Za-z_-]+\.[0-9A-Za-z_-]*",
    r"-----BEGIN[A-Z ]* PRIVATE KEY-----[\s\S]*?-----END[A-Z ]* PRIVATE KEY-----",
    r"(?i)\b(bearer|basic|api-token)\s+[0-9A-Za-z._~+/=-]{8,}",
)
MASK = "****"
_SECRETS = [re.compile(p) for p in SECRET_PATTERNS]

# GenAI content on spans only (Development's telemetry row; B5 desk check).
CONTENT_ENVIRONMENT = {
    "OTEL_SEMCONV_STABILITY_OPT_IN": "gen_ai_latest_experimental",
    "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT": "SPAN_ONLY",
}


def redact(value: Any) -> Any:
    """value with every match of a secret pattern replaced by the mask, in
    strings, and in strings within sequences and mappings."""
    if isinstance(value, str):
        for p in _SECRETS:
            value = p.sub(MASK, value)
        return value
    if isinstance(value, Mapping):
        return {k: redact(v) for k, v in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, bytes | bytearray):
        return type(value)(redact(v) for v in value) if isinstance(value, tuple) else [redact(v) for v in value]
    return value


def _attrs(attributes: Mapping[str, Any] | None) -> dict[str, Any] | None:
    return None if attributes is None else {k: redact(v) for k, v in attributes.items()}


class RedactingSpanExporter(SpanExporter):
    """Masks secret patterns in span names, attributes and events, then exports."""

    def __init__(self, inner: SpanExporter):
        self.inner = inner

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        return self.inner.export([self._clean(s) for s in spans])

    @staticmethod
    def _clean(s: ReadableSpan) -> ReadableSpan:
        return ReadableSpan(
            name=redact(s.name), context=s.context, parent=s.parent, resource=s.resource,
            attributes=_attrs(s.attributes),
            events=[Event(redact(e.name), _attrs(e.attributes), e.timestamp) for e in s.events],
            links=s.links, kind=s.kind, status=Status(s.status.status_code, redact(s.status.description)),
            start_time=s.start_time, end_time=s.end_time, instrumentation_scope=s.instrumentation_scope,
        )

    def shutdown(self) -> None:
        self.inner.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self.inner.force_flush(timeout_millis)


TASK_SPAN_OPERATIONS = ("invoke_agent", "invoke_workflow")


class InvocationSpanProcessor(SpanProcessor):
    """Stamps every span started within an invocation with its attributes:
    task.id, workflow.name and .version, user.id, user.team, session.id and
    actor.sub, as the verified token and valid headers give them.

    It also gives limits.json's span surface to a framework's task span (ADK's
    invoke_agent) that ends after the task's limits stopped it: the framework
    records its own exception type there, or no error at all when wall time
    cancelled the run, so status ERROR and error.type limit_exceeded are set
    before the span is exported. Register it before any
    exporting processor."""

    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        inv = context.current()
        if inv is not None:
            span.set_attributes(inv.attributes())

    def on_end(self, span: ReadableSpan) -> None:
        inv = context.current()
        if inv is None or inv.limits is None or not inv.limits.exhausted():
            return
        attrs = span.attributes or {}
        if attrs.get("gen_ai.operation.name") in TASK_SPAN_OPERATIONS:
            # The ended span is a copy made for the processors; the exporting
            # processors after this one receive the same copy.
            span._attributes = {**attrs, "error.type": "limit_exceeded"}
            span._status = Status(StatusCode.ERROR, "limit_exceeded")

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def resource(service_name: str | None = None) -> Resource:
    """OTEL_RESOURCE_ATTRIBUTES and OTEL_SERVICE_NAME, as the OTel SDK merges
    them; service_name when OTEL_SERVICE_NAME is unset."""
    attrs = {}
    if service_name and not os.environ.get("OTEL_SERVICE_NAME"):
        attrs["service.name"] = service_name
    return Resource.create(attrs)


log = logging.getLogger("agentic_sdk.telemetry")

# What flush() flushes besides the global providers: each tracer provider
# configure() made and each audit emitter, while they live.
_FLUSHABLE: weakref.WeakSet = weakref.WeakSet()


def flushes(target: Any) -> Any:
    """Registers target, which has force_flush(timeout_millis), for flush()."""
    _FLUSHABLE.add(target)
    return target


def flush(timeout_seconds: float = 5.0) -> bool:
    """Force-flushes, within timeout_seconds in all, every tracer provider
    configure() made, every audit emitter, and the global tracer and logger
    providers when they are the OTel SDK's: what a workload's process does
    last as it stops. True when each one flushed in time."""
    deadline = time.monotonic() + timeout_seconds
    targets = list(dict.fromkeys([*_FLUSHABLE, trace.get_tracer_provider(), _logs.get_logger_provider()]))
    ok = True
    for target in targets:
        force_flush = getattr(target, "force_flush", None)
        if force_flush is None:
            continue
        try:
            ok = bool(force_flush(max(0, int((deadline - time.monotonic()) * 1000)))) and ok
        except Exception as e:  # a flush that fails is the collector's; the next one still runs
            log.warning("flush of %s failed: %s", type(target).__name__, type(e).__name__)
            ok = False
    return ok


async def flush_async(timeout_seconds: float = 5.0) -> bool:
    """flush, off the event loop, so cancelled tasks can unwind meanwhile."""
    return await asyncio.to_thread(flush, timeout_seconds)


@dataclass
class Telemetry:
    tracer_provider: TracerProvider
    resource: Resource


def configure(service_name: str | None = None, *, exporter: SpanExporter | None = None,
              set_global: bool = True) -> Telemetry:
    """Sets up tracing for the workload. exporter defaults to OTLP over HTTP,
    configured by the OTEL_EXPORTER_OTLP_* variables, when an endpoint is
    set; without one, spans are made but not exported."""
    for k, v in CONTENT_ENVIRONMENT.items():
        os.environ.setdefault(k, v)
    res = resource(service_name)
    provider = flushes(TracerProvider(resource=res))
    provider.add_span_processor(InvocationSpanProcessor())
    if exporter is None and (os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") or os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT")):
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

        exporter = OTLPSpanExporter()
    if exporter is not None:
        provider.add_span_processor(BatchSpanProcessor(RedactingSpanExporter(exporter)))
    if set_global:
        trace.set_tracer_provider(provider)
    return Telemetry(provider, res)


def mark_limit_exceeded(span: trace.Span | None = None) -> None:
    """Ends the task's span as limits.json's span surface says: status ERROR,
    error.type limit_exceeded."""
    span = span or trace.get_current_span()
    span.set_attribute("error.type", "limit_exceeded")
    span.set_status(Status(StatusCode.ERROR, "limit_exceeded"))
