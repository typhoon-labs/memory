"""RFC 8785 JSON canonicalization, and the parameters hash of a tool call
(spec/audit/tool/parameters-hash.json)."""

from __future__ import annotations

import hashlib
import math
from collections.abc import Mapping
from decimal import Decimal
from typing import Any

MAX_SAFE_INTEGER = 2**53 - 1
_ESCAPES = {'"': '\\"', "\\": "\\\\", "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r"}


def _string(s: str) -> str:
    out = ['"']
    for ch in s:
        if ch in _ESCAPES:
            out.append(_ESCAPES[ch])
        elif ord(ch) < 0x20 or 0xD800 <= ord(ch) <= 0xDFFF:  # controls, and lone surrogates as JSON.stringify writes them
            out.append(f"\\u{ord(ch):04x}")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def _number(x: int | float) -> str:
    """A number as ECMAScript's Number::toString writes it (RFC 8785, 3.2.2.3)."""
    if isinstance(x, int):
        if abs(x) > MAX_SAFE_INTEGER:
            raise ValueError("integer outside I-JSON's range: send it as a string")
        return str(x)
    if not math.isfinite(x):
        raise ValueError("NaN and Infinity have no JSON form")
    if x == 0:
        return "0"
    sign = "-" if x < 0 else ""
    _, digits, exp = Decimal(repr(abs(x))).as_tuple()
    ds = "".join(map(str, digits)).rstrip("0") or "0"
    exp += len("".join(map(str, digits))) - len(ds)
    k = len(ds)
    n = k + exp  # the decimal point's position: value = 0.ds * 10**n
    if k <= n <= 21:
        body = ds + "0" * (n - k)
    elif 0 < n <= 21:
        body = ds[:n] + "." + ds[n:]
    elif -6 < n <= 0:
        body = "0." + "0" * (-n) + ds
    else:
        e = n - 1
        mant = ds if k == 1 else ds[0] + "." + ds[1:]
        body = f"{mant}e{'+' if e >= 0 else '-'}{abs(e)}"
    return sign + body


def canonical(value: Any) -> str:
    """value's canonical JSON text."""
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int | float):
        return _number(value)
    if isinstance(value, str):
        return _string(value)
    if isinstance(value, Mapping):
        if not all(isinstance(k, str) for k in value):
            raise ValueError("object keys must be strings")
        keys = sorted(value, key=lambda k: k.encode("utf-16-be", "surrogatepass"))
        return "{" + ",".join(f"{_string(k)}:{canonical(value[k])}" for k in keys) + "}"
    if isinstance(value, list | tuple):
        return "[" + ",".join(canonical(v) for v in value) + "]"
    raise ValueError(f"not JSON: {type(value).__name__}")


def parameters_hash(arguments: Mapping[str, Any] | None) -> str:
    """sha256: and the hex SHA-256 of the canonical arguments, without approval_id."""
    args = {k: v for k, v in (arguments or {}).items() if k != "approval_id"}
    return "sha256:" + hashlib.sha256(canonical(args).encode("utf-8", "surrogatepass")).hexdigest()
