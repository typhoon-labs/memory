"""The records a tool that changes state keeps: idempotency keys with their
results, and approval records. Behind one interface, so a tool's own change,
its key and an approval's use commit in one transaction: in memory for tests,
Postgres (store_postgres) for a server."""

from __future__ import annotations

import asyncio
import contextlib
import copy
import secrets
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

RETENTION_SECONDS_MINIMUM = 86400
IN_PROGRESS_SECONDS = 300  # an in-progress key older than this was left by a crash


@dataclass(frozen=True)
class KeyState:
    state: Literal["new", "in_progress", "completed"]
    result: dict[str, Any] | None = None


def new_approval_id() -> str:
    """128 random bits, base64url without padding: 22 characters."""
    return secrets.token_urlsafe(16)


class Transaction(Protocol):
    """One transaction: a tool's own change, then its key's result and its
    approval's use, all committed or none."""

    async def complete_key(self, key: str, result: dict[str, Any]) -> None: ...

    async def use_approval(self, approval_id: str, used_at: int) -> bool:
        """Sets used_at if it is unset; False if the approval was used meanwhile."""
        ...


class Store(Protocol):
    async def reserve_key(self, key: str) -> KeyState:
        """Takes the key for a new call (state new), or says it is in progress
        or completed, with the completed call's result."""
        ...

    async def release_key(self, key: str) -> None:
        """Drops an in-progress key: the call was refused, or failed without a change."""
        ...

    async def proposal(self, proposal_key: str, make: Callable[[], dict[str, Any]]) -> dict[str, Any]:
        """The pending approval record for proposal_key, or a new one from make()."""
        ...

    async def approval(self, approval_id: str) -> dict[str, Any] | None: ...

    async def approve(self, approval_id: str, approver: dict[str, str], approved_at: int, expires_at: int) -> dict[str, Any] | None:
        """Sets the approver if nobody has approved yet; the record, or None if someone had."""
        ...

    def transaction(self) -> contextlib.AbstractAsyncContextManager[Transaction]: ...

    async def purge(self, older_than_seconds: int = RETENTION_SECONDS_MINIMUM) -> int: ...


@dataclass
class _MemTx:
    store: MemoryStore
    keys: dict[str, dict[str, Any]] = field(default_factory=dict)
    used: dict[str, int] = field(default_factory=dict)
    on_commit: list[Callable[[], None]] = field(default_factory=list)

    async def complete_key(self, key: str, result: dict[str, Any]) -> None:
        self.keys[key] = result

    async def use_approval(self, approval_id: str, used_at: int) -> bool:
        rec = self.store._approvals.get(approval_id)
        if rec is None or "used_at" in rec or approval_id in self.used:
            return False
        self.used[approval_id] = used_at
        return True

    def after_commit(self, fn: Callable[[], None]) -> None:
        """For an in-memory tool's own change: applied only if the transaction commits."""
        self.on_commit.append(fn)


class MemoryStore:
    """Keeps everything in this process. For tests and single-replica trials:
    a restart forgets every key and approval."""

    def __init__(self, clock: Callable[[], float] = time.time):
        self._clock = clock
        self._keys: dict[str, tuple[str, dict[str, Any] | None, float]] = {}
        self._approvals: dict[str, dict[str, Any]] = {}
        self._proposals: dict[str, str] = {}
        self._lock = asyncio.Lock()

    async def reserve_key(self, key: str) -> KeyState:
        async with self._lock:
            now = self._clock()
            entry = self._keys.get(key)
            if entry is not None:
                state, result, at = entry
                if state == "completed":
                    return KeyState("completed", copy.deepcopy(result))
                if now - at < IN_PROGRESS_SECONDS:
                    return KeyState("in_progress")
            self._keys[key] = ("in_progress", None, now)
            return KeyState("new")

    async def release_key(self, key: str) -> None:
        async with self._lock:
            if key in self._keys and self._keys[key][0] == "in_progress":
                del self._keys[key]

    async def proposal(self, proposal_key: str, make: Callable[[], dict[str, Any]]) -> dict[str, Any]:
        async with self._lock:
            pid = self._proposals.get(proposal_key)
            rec = self._approvals.get(pid) if pid else None
            if rec is not None and "approver" not in rec:
                return copy.deepcopy(rec)
            rec = make()
            self._approvals[rec["id"]] = rec
            self._proposals[proposal_key] = rec["id"]
            return copy.deepcopy(rec)

    async def approval(self, approval_id: str) -> dict[str, Any] | None:
        rec = self._approvals.get(approval_id)
        return copy.deepcopy(rec) if rec is not None else None

    async def approve(self, approval_id, approver, approved_at, expires_at):
        async with self._lock:
            rec = self._approvals.get(approval_id)
            if rec is None or "approver" in rec:
                return None
            rec.update(approver=dict(approver), approved_at=approved_at, expires_at=expires_at)
            return copy.deepcopy(rec)

    @contextlib.asynccontextmanager
    async def transaction(self) -> AsyncIterator[_MemTx]:
        tx = _MemTx(self)
        yield tx
        async with self._lock:
            if any("used_at" in self._approvals.get(a, {}) for a in tx.used):
                raise RuntimeError("approval used meanwhile")
            for fn in tx.on_commit:
                fn()
            now = self._clock()
            for key, result in tx.keys.items():
                self._keys[key] = ("completed", copy.deepcopy(result), now)
            for a, at in tx.used.items():
                self._approvals[a]["used_at"] = at

    async def purge(self, older_than_seconds: int = RETENTION_SECONDS_MINIMUM) -> int:
        older_than_seconds = max(older_than_seconds, RETENTION_SECONDS_MINIMUM)
        async with self._lock:
            cutoff = self._clock() - older_than_seconds
            gone = [k for k, (s, _, at) in self._keys.items() if s == "completed" and at < cutoff]
            for k in gone:
                del self._keys[k]
            return len(gone)


Apply = Callable[[Transaction], Awaitable[dict[str, Any]]]
