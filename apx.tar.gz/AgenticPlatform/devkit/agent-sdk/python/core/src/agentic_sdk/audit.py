"""audit: the tools' audit record (spec/audit/tool/record.schema.json),
encoded as spec/audit/encoding.json says. A record is sent to the collector
before the call is answered, synchronously and within a short bound; when
the collector does not take it, it is written as a JSON line on standard
output, exports pause for a while, and the call goes on. Delivery is at
least once; no call ever fails for its record."""

from __future__ import annotations

import asyncio
import json
import logging
import sys
import threading
import time
from collections.abc import Callable, Mapping
from typing import IO, Any

from opentelemetry import trace
from opentelemetry._logs import LogRecord, SeverityNumber
from opentelemetry.sdk._logs import ReadableLogRecord
from opentelemetry.sdk._logs.export import LogRecordExporter, LogRecordExportResult
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.util.instrumentation import InstrumentationScope
from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags

from . import contract
from .telemetry import flushes, redact

log = logging.getLogger("agentic_sdk.audit")
_ENC = contract.load("audit/encoding.json")["otel"]
SCOPE = _ENC["scope_name"]
DEFAULT_TIMEOUT = 1.0
MAX_TIMEOUT = 5.0
PAUSE_SECONDS = 10.0


def tool_record(*, tool: str, outcome: str, parameters_hash: str, principal_attributes: Mapping[str, Any],
                task_attributes: Mapping[str, str], destructive: bool | None = None,
                target_id: str | None = None, target_version: str | None = None,
                approval_id: str | None = None, refusal_reason: str | None = None,
                error_type: str | None = None, span: trace.Span | None = None) -> dict[str, Any]:
    """One tool audit record, under the spec's dotted names. The caller's
    names come from the verified token; trace_id and span_id from span, the
    server's span for the call (the current span by default)."""
    span = span or trace.get_current_span()
    ctx = span.get_span_context()
    rec: dict[str, Any] = {"event.name": "tool.call", "tool.name": tool, "tool.call.outcome": outcome,
                           "tool.parameters.hash": parameters_hash}
    if destructive is not None:
        rec["tool.destructive"] = destructive
    for k in ("user.id", "user.team", "session.id", "actor.sub", "actor.chain", "client.id", "token.jti"):
        if principal_attributes.get(k) is not None:
            rec[k] = list(principal_attributes[k]) if k == "actor.chain" else principal_attributes[k]
    rec.update(task_attributes)
    for k, v in (("target.id", target_id), ("target.version", target_version), ("approval.id", approval_id),
                 ("refusal.reason", refusal_reason), ("error.type", error_type)):
        if v is not None:
            rec[k] = v
    rec["trace_id"] = format(ctx.trace_id, "032x")
    rec["span_id"] = format(ctx.span_id, "016x")
    return rec


class AuditEmitter:
    """Sends audit records: to the collector through exporter when it has one,
    else, or when the collector does not take a record, to standard output."""

    def __init__(self, service_name: str, exporter: LogRecordExporter | None = None, *,
                 resource: Resource | None = None, stream: IO[str] | None = None,
                 pause_seconds: float = PAUSE_SECONDS, clock: Callable[[], float] = time.monotonic):
        self.exporter = exporter
        self.resource = resource or Resource.create({"service.name": service_name})
        self._stream = stream
        self._pause = pause_seconds
        self._clock = clock
        self._paused_until = 0.0
        self._lock = threading.Lock()
        self.diverted = 0  # records written to standard output instead of exported
        flushes(self)

    @classmethod
    def from_env(cls, service_name: str, environ: Mapping[str, str], *, resource: Resource | None = None) -> AuditEmitter:
        """With an OTLP/HTTP log exporter when OTEL_EXPORTER_OTLP_ENDPOINT (or
        its LOGS variant) is set; its timeout is AGENTIC_AUDIT_EXPORT_TIMEOUT_SECONDS,
        1 by default, at most 5."""
        exporter = None
        endpoint = environ.get("OTEL_EXPORTER_OTLP_LOGS_ENDPOINT") or (
            environ["OTEL_EXPORTER_OTLP_ENDPOINT"].rstrip("/") + "/v1/logs" if environ.get("OTEL_EXPORTER_OTLP_ENDPOINT") else None)
        if endpoint:
            from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter

            raw = environ.get("AGENTIC_AUDIT_EXPORT_TIMEOUT_SECONDS", "")
            try:
                timeout = min(MAX_TIMEOUT, max(0.1, float(raw))) if raw else DEFAULT_TIMEOUT
            except ValueError:
                timeout = DEFAULT_TIMEOUT
            exporter = OTLPLogExporter(endpoint=endpoint, timeout=timeout)
        return cls(service_name, exporter, resource=resource)

    def _otel(self, record: Mapping[str, Any]) -> ReadableLogRecord:
        trace_id, span_id = int(record["trace_id"], 16), int(record["span_id"], 16)
        ctx = trace.set_span_in_context(NonRecordingSpan(SpanContext(trace_id, span_id, False, TraceFlags(TraceFlags.SAMPLED))))
        now = time.time_ns()
        attrs = {k: (tuple(v) if isinstance(v, list) else v) for k, v in record.items()}
        lr = LogRecord(timestamp=now, observed_timestamp=now, context=ctx, severity_text=_ENC["severity_text"],
                       severity_number=SeverityNumber(_ENC["severity_number"]), body=None, attributes=attrs,
                       event_name=record.get("event.name"))
        return ReadableLogRecord(log_record=lr, resource=self.resource, instrumentation_scope=InstrumentationScope(SCOPE))

    def _line(self, record: Mapping[str, Any]) -> None:
        out = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "severity_text": "INFO", **record}
        stream = self._stream or sys.stdout
        stream.write(json.dumps(out, separators=(",", ":"), ensure_ascii=False) + "\n")
        stream.flush()

    def emit(self, record: Mapping[str, Any]) -> None:
        """Sends one record. Never raises."""
        record = redact(dict(record))
        try:
            with self._lock:
                if self.exporter is not None and self._clock() >= self._paused_until:
                    try:
                        result = self.exporter.export([self._otel(record)])
                    except Exception as e:  # the exporter's own failure is the collector's
                        log.warning("audit export failed: %s", type(e).__name__)
                        result = LogRecordExportResult.FAILURE
                    if result == LogRecordExportResult.SUCCESS:
                        return
                    self._paused_until = self._clock() + self._pause
                    self.diverted += 1
                self._line(record)
        except Exception:  # a record is never worth a failed call
            log.exception("audit record lost")

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Waits, within the timeout, for a record being sent, then flushes the
        exporter. A record is sent before its call is answered, so none waits
        in a queue; this only lets the last one finish as the process stops."""
        if not self._lock.acquire(timeout=max(0, timeout_millis) / 1000):
            return False
        try:
            # An exporter that is not the SDK's may have no flush of its own.
            flush = getattr(self.exporter, "force_flush", None)
            return True if flush is None else bool(flush(timeout_millis))
        finally:
            self._lock.release()

    async def emit_async(self, record: Mapping[str, Any]) -> None:
        """emit, off the event loop: the export may take up to its timeout."""
        await asyncio.to_thread(self.emit, record)
