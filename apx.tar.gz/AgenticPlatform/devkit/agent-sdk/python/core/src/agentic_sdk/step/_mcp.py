"""The step's MCP tool calls, through the gateway's MCP routes, with the MCP
Python SDK (the `mcp` extra). Each request carries a token for the server's
route scope and the task's headers."""

from __future__ import annotations

import contextlib
import json
from typing import TYPE_CHECKING, Any

from .. import context

if TYPE_CHECKING:
    from . import Step


@contextlib.asynccontextmanager
async def _client(step: Step, server: str):
    try:
        import httpx2
        from mcp import Client
        from mcp.client.streamable_http import streamable_http_client
    except ImportError as e:
        from . import Failed

        raise Failed("tool_error", "this step calls tools: install agentic-agent-sdk[mcp]") from e
    scope = f"mcp/{server}"

    async def auth(request) -> None:
        request.headers["Authorization"] = f"Bearer {await step.tokens.get(scope)}"
        for k, v in context.outbound_headers().items():
            request.headers[k] = v

    async with httpx2.AsyncClient(verify=step.verify,
                                  event_hooks={"request": [auth]}, trust_env=False) as http:
        async with Client(streamable_http_client(f"{step.gateway}/{scope}", http_client=http)) as client:
            yield client


async def list_tools(step: Step, allow: list[dict[str, Any]]) -> dict[str, tuple[str, dict[str, Any]]]:
    from . import Failed

    out: dict[str, tuple[str, dict[str, Any]]] = {}
    for entry in allow:
        try:
            async with _client(step, entry["server"]) as client:
                listed = await client.list_tools()
        except Failed:
            raise
        except Exception as e:
            raise Failed("tool_error", f"MCP server {entry['server']} unreachable: {type(e).__name__}") from None
        by_name = {t.name: t.model_dump(by_alias=True, exclude_none=True) for t in listed.tools}
        for name in entry["tools"]:
            if name not in by_name:
                raise Failed("tool_error", f"MCP server {entry['server']} lists no tool {name}")
            if name in out:
                raise Failed("tool_error", f"tool {name} is allowed on two servers")
            out[name] = (entry["server"], by_name[name])
    return out


async def call(step: Step, server: str, name: str, arguments: dict[str, Any]) -> str:
    from . import Failed

    try:
        async with _client(step, server) as client:
            result = await client.call_tool(name, arguments)
    except Failed:
        raise
    except Exception as e:
        raise Failed("tool_error", f"MCP server {server} failed: {type(e).__name__}") from None
    return json.dumps(result.model_dump(by_alias=True, exclude_none=True), ensure_ascii=False)
