"""Verifies a workload's inbound token by spec/vectors/README.md's eleven
checks, in its order, and names who called under the audit records' names."""

from __future__ import annotations

import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

from . import jose
from .jwks import KeySource, KeysUnavailable

MAX_LEEWAY = 60


@dataclass(frozen=True)
class Profile:
    """A kind of token a verifier may accept, as spec/vectors' profiles."""

    name: str
    typ: tuple[str, ...]
    alg: tuple[str, ...]
    required_claims: tuple[str, ...]
    principal: Literal["person", "chain", "actor"]
    forbidden_claims: tuple[str, ...] = ()
    sub_prefix: str | None = None
    max_lifetime_seconds: int | None = None


KEYCLOAK = Profile("keycloak", typ=("at+jwt", "application/at+jwt"), alg=("ES256", "RS256"),
                   required_claims=("sub", "exp"), forbidden_claims=("act",), principal="person")
CHAIN = Profile("chain", typ=("at+jwt", "application/at+jwt"), alg=("ES256", "RS256"),
                required_claims=("sub", "exp", "act"), principal="chain")
SUBSTRATE_ACTOR = Profile("substrate-actor", typ=("JWT",), alg=("ES256",),
                          required_claims=("sub", "exp", "iat", "actor.ate.dev"), sub_prefix="actor/",
                          max_lifetime_seconds=300, principal="actor")
PROFILES = {p.name: p for p in (KEYCLOAK, CHAIN, SUBSTRATE_ACTOR)}


@dataclass(frozen=True)
class IssuerTrust:
    """One issuer a verifier trusts: its tokens follow profile, are signed by
    keys from keys, and carry exactly audience. Substrate's actor tokens also
    name an atespace, which must be one of atespaces: the kagent agents'
    namespaces the route's access file admits (D30). An actor profile needs
    at least one; no other profile takes any."""

    issuer: str
    profile: Profile
    keys: KeySource
    audience: str
    atespaces: frozenset[str] | None = None

    def __post_init__(self) -> None:
        if self.atespaces is not None:
            object.__setattr__(self, "atespaces", frozenset(self.atespaces))
        if self.profile.principal == "actor" and not self.atespaces:
            raise ValueError(f"{self.issuer}: a Substrate issuer needs the atespaces its route admits")
        if self.profile.principal != "actor" and self.atespaces is not None:
            raise ValueError(f"{self.issuer}: only a Substrate issuer takes atespaces")


@dataclass(frozen=True)
class Route:
    """Requests whose path is prefix, or under it, are verified by verifier,
    and reach the app with prefix removed: the path the gateway's route on
    Substrate's listener calls a workload under (AGENTIC_SUBSTRATE_ROUTE)."""

    prefix: str
    verifier: "Verifier"

    def matches(self, path: str) -> bool:
        return path == self.prefix or path.startswith(self.prefix + "/")


class TokenRefused(Exception):
    """The token fails a check. reason is a reason of spec/refusals: log it, never send it."""

    def __init__(self, reason: str, token_sent: bool = True):
        super().__init__(reason)
        self.reason = reason
        self.token_sent = token_sent


@dataclass(frozen=True)
class Principal:
    """Who called, from a verified token. attributes() gives the audit names."""

    kind: Literal["person", "chain", "actor"]
    issuer: str
    user_id: str | None = None
    user_team: str | None = None
    user_roles: tuple[str, ...] | None = None
    session_id: str | None = None
    client_id: str | None = None
    token_jti: str | None = None
    actor_sub: str | None = None
    actor_chain: tuple[str, ...] | None = None
    acr: str | None = None
    expires_at: int | None = None
    claims: dict[str, Any] = field(default_factory=dict, repr=False, compare=False)

    def attributes(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for name, value in (("user.id", self.user_id), ("user.team", self.user_team),
                            ("user.roles", list(self.user_roles) if self.user_roles is not None else None),
                            ("session.id", self.session_id), ("client.id", self.client_id),
                            ("token.jti", self.token_jti), ("actor.sub", self.actor_sub),
                            ("actor.chain", list(self.actor_chain) if self.actor_chain is not None else None)):
            if value is not None:
                out[name] = value
        return out

    @property
    def caller(self) -> dict[str, str]:
        """The caller as an approval's proposer names it: user.id and actor.sub, as present."""
        return {k: v for k, v in (("user.id", self.user_id), ("actor.sub", self.actor_sub)) if v}

    @property
    def display_name(self) -> str:
        return self.user_id or self.actor_sub or ""


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _str(v: Any) -> str | None:
    return v if isinstance(v, str) else None


def _atespace(c: dict[str, Any]) -> str | None:
    """A Substrate actor token's atespace: actor.ate.dev's atespace, a non-empty string."""
    a = c.get("actor.ate.dev")
    ns = a.get("atespace") if isinstance(a, dict) else None
    return ns if isinstance(ns, str) and ns else None


def _chain(act: Any) -> tuple[str, ...]:
    out = []
    while isinstance(act, dict) and isinstance(act.get("sub"), str):
        out.append(act["sub"])
        act = act.get("act")
    return tuple(out)


class Verifier:
    """Verifies inbound bearer tokens against the issuers a route accepts.
    routes are other routes of the same workload, each with a verifier of its
    own, which identity.asgi.InboundAuth uses for requests under its prefix;
    this verifier's issuers apply everywhere else."""

    def __init__(self, issuers: Sequence[IssuerTrust], *, leeway: int = MAX_LEEWAY,
                 clock: Callable[[], float] = time.time, routes: Sequence[Route] = ()):
        if not 0 <= leeway <= MAX_LEEWAY:
            raise ValueError(f"leeway must be 0 to {MAX_LEEWAY} seconds")
        if not issuers and not routes:
            raise ValueError("a verifier needs at least one issuer")
        self.routes = tuple(routes)
        self._issuers = {t.issuer: t for t in issuers}
        if len(self._issuers) != len(issuers):
            raise ValueError("an issuer appears twice")
        self._leeway = leeway
        self._clock = clock

    async def verify(self, token: str | None) -> Principal:
        """The principal, or TokenRefused with the first failing check's reason.
        KeysUnavailable when the issuer's keys cannot be had."""
        # 1. A token was sent.
        if not token:
            raise TokenRefused("request_malformed", token_sent=False)
        # 2. A compact JWS whose header and claims are JSON objects.
        try:
            jws = jose.parse(token)
        except jose.Malformed:
            raise TokenRefused("subject_signature") from None
        h, c = jws.header, jws.claims
        # 3. Its iss is exactly one of the verifier's issuers.
        trust = self._issuers.get(c.get("iss")) if isinstance(c.get("iss"), str) else None
        if trust is None:
            raise TokenRefused("subject_issuer")
        p = trust.profile
        # 4. alg allowed, no crit, kid names a key of the issuer's set, the signature verifies.
        alg, kid = h.get("alg"), h.get("kid")
        if alg not in p.alg or "crit" in h or not isinstance(kid, str):
            raise TokenRefused("subject_signature")
        jwk = await trust.keys.key(kid)  # may raise KeysUnavailable
        if jwk is None or not jose.verify(jws, alg, jwk):
            raise TokenRefused("subject_signature")
        # 5. typ, compared case-insensitively.
        typ = h.get("typ")
        if not isinstance(typ, str) or typ.lower() not in {t.lower() for t in p.typ}:
            raise TokenRefused("subject_type")
        # 6. Required claims, sub prefix, lifetime.
        for name in p.required_claims:
            if name not in c:
                raise TokenRefused("subject_type")
        if "act" in p.required_claims and not (isinstance(c["act"], dict) and isinstance(c["act"].get("sub"), str) and c["act"]["sub"]):
            raise TokenRefused("subject_type")
        if not isinstance(c.get("sub"), str) or not c["sub"]:
            raise TokenRefused("subject_type")
        for name in ("exp", "iat", "nbf"):
            if name in c and not _is_int(c[name]):
                raise TokenRefused("subject_type")
        if p.sub_prefix is not None and not c["sub"].startswith(p.sub_prefix):
            raise TokenRefused("subject_type")
        if p.max_lifetime_seconds is not None and c["exp"] - c["iat"] > p.max_lifetime_seconds:
            raise TokenRefused("subject_type")
        if p.principal == "actor" and _atespace(c) is None:
            raise TokenRefused("subject_type")
        now = self._clock()
        # 7. Not expired.
        if not now < c["exp"] + self._leeway:
            raise TokenRefused("subject_expired")
        # 8. Valid already.
        if "nbf" in c and not c["nbf"] <= now + self._leeway:
            raise TokenRefused("subject_not_yet_valid")
        # 9. No forbidden claim.
        if any(name in c for name in p.forbidden_claims):
            raise TokenRefused("subject_foreign_act")
        # 10. One audience, exactly the issuer's.
        aud = c.get("aud")
        if isinstance(aud, list) and len(aud) == 1:
            aud = aud[0]
        if not isinstance(aud, str) or aud != trust.audience:
            raise TokenRefused("subject_audience")
        # 11. An actor of an atespace the route admits, which its sub names too.
        if trust.atespaces is not None:
            ns = _atespace(c)
            if ns not in trust.atespaces or not c["sub"].startswith(f"actor/{ns}/"):
                raise TokenRefused("actor_unknown")
        return self._principal(p, trust.issuer, c)

    @staticmethod
    def _principal(p: Profile, issuer: str, c: dict[str, Any]) -> Principal:
        jti = _str(c.get("jti"))
        if p.principal == "actor":
            return Principal("actor", issuer, token_jti=jti, actor_sub=c["sub"],
                             actor_chain=(c["sub"],), expires_at=c["exp"], claims=c)
        roles = c.get("roles")
        chain = _chain(c.get("act")) if p.principal == "chain" else None
        return Principal(
            p.principal, issuer,
            user_id=c["sub"],
            user_team=_str(c.get("team")),
            user_roles=tuple(roles) if isinstance(roles, list) and all(isinstance(r, str) for r in roles) else None,
            session_id=_str(c.get("sid")),
            client_id=_str(c.get("client_id")),
            token_jti=jti,
            actor_sub=chain[0] if chain else None,
            actor_chain=chain or None,
            acr=_str(c.get("acr")),
            expires_at=c["exp"],
            claims=c,
        )


__all__ = ["CHAIN", "KEYCLOAK", "PROFILES", "SUBSTRATE_ACTOR", "IssuerTrust", "KeysUnavailable",
           "Principal", "Profile", "Route", "TokenRefused", "Verifier"]
