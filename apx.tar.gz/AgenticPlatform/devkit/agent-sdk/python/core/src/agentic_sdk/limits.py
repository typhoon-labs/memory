"""limits: per-task caps on model calls, tool calls, tokens and wall time
(spec/limits/), read from the workload's workload.yaml and lowered, never
raised, by the environment (spec/limits/runtime.json). A task stopped by
them ends with the spec's limit_exceeded, on each of its surfaces."""

from __future__ import annotations

import asyncio
import logging
import math
import os
import time
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, TypeVar

import yaml

from . import contract

log = logging.getLogger("agentic_sdk.limits")
T = TypeVar("T")

_RUNTIME = contract.load("limits/runtime.json")
_LIMITS = {entry["name"]: entry for entry in contract.load("limits/limits.json")["limits"]}
WORKLOAD_FILE = _RUNTIME["workload_file"]["path"]
ENVIRONMENT = {e["limit"]: e["name"] for e in _RUNTIME["environment"]}
NAMES = tuple(_LIMITS)
ERROR = contract.load("limits/limits.json")["error"]


class ConfigError(Exception):
    """The workload file or an environment variable is invalid: the workload does not start."""


@dataclass(frozen=True)
class Caps:
    """The caps in force; None is no cap."""

    model_calls: int | None = None
    tool_calls: int | None = None
    tokens: int | None = None
    wall_time_seconds: int | None = None

    @classmethod
    def from_declaration(cls, declared: Mapping[str, Any] | None) -> Caps:
        return cls(**{k: v for k, v in (declared or {}).items() if k in NAMES})

    def lowered(self, other: Caps) -> Caps:
        """The lower of each pair; a cap beats none."""
        out = {}
        for f in fields(self):
            a, b = getattr(self, f.name), getattr(other, f.name)
            out[f.name] = b if a is None else a if b is None else min(a, b)
        return Caps(**out)

    def as_dict(self) -> dict[str, int]:
        return {f.name: getattr(self, f.name) for f in fields(self) if getattr(self, f.name) is not None}


def read_workload(path: str | os.PathLike[str] = WORKLOAD_FILE) -> dict[str, Any]:
    """The workload file, parsed and checked against spec/schemas/workload.schema.json."""
    try:
        doc = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    except OSError as e:
        raise ConfigError(f"workload file {path}: {e.strerror}") from None
    except yaml.YAMLError as e:
        raise ConfigError(f"workload file {path}: not YAML: {e}") from None
    problem = contract.first_error("schemas/workload.schema.json", doc)
    if problem is not None:
        raise ConfigError(f"workload file {path}: {problem}")
    return doc


def environment_caps(declared: Caps, environ: Mapping[str, str] | None = None) -> Caps:
    """declared, lowered by the AGENTIC_LIMIT_* variables as runtime.json's rules say."""
    env = os.environ if environ is None else environ
    lowered = {}
    for name in NAMES:
        var = ENVIRONMENT[name]
        raw = env.get(var, "")
        if raw == "":
            continue
        minimum = _LIMITS[name]["minimum"]
        if not (raw.isascii() and raw.isdigit()) or int(raw) < minimum:
            raise ConfigError(f"{var}={raw!r}: not a decimal integer of at least {minimum}")
        value = int(raw)
        cap = getattr(declared, name)
        if cap is not None and value > cap:
            log.warning("%s=%d ignored: it would raise the declared cap of %d", var, value, cap)
            continue
        lowered[name] = value
    return declared.lowered(Caps(**lowered))


def load_caps(path: str | os.PathLike[str] = WORKLOAD_FILE, environ: Mapping[str, str] | None = None) -> Caps:
    """The caps in force for a workload: its file's, lowered by the environment."""
    return environment_caps(Caps.from_declaration(read_workload(path).get("limits")), environ)


class LimitExceeded(Exception):
    """A task stopped by its limits. error() is the spec's error object."""

    def __init__(self, limit: str, cap: int, used: int, task_id: str | None = None):
        super().__init__(f"{ERROR}: {limit} cap {cap} used {used}")
        self.limit, self.cap, self.used, self.task_id = limit, cap, used, task_id

    def error(self) -> dict[str, Any]:
        out: dict[str, Any] = {"error": ERROR, "limit": self.limit, "cap": self.cap, "used": self.used}
        if self.task_id:
            out["task_id"] = self.task_id
        out["message"] = self.message()
        return out

    def message(self) -> str:
        unit = _LIMITS[self.limit]["unit"]
        return f"The task stopped at its {self.limit} limit: {self.used} {unit} used, cap {self.cap}."

    def mcp_result(self) -> dict[str, Any]:
        """The MCP surface: a tools/call result, not a JSON-RPC error."""
        return {"isError": True, "structuredContent": self.error(),
                "content": [{"type": "text", "text": self.message()}]}

    def span_attributes(self) -> dict[str, str]:
        return {"error.type": ERROR}


def tokens_of(usage: Mapping[str, Any] | None) -> int:
    """A response's tokens as spec/limits counts them: its total, or input plus output."""
    if not usage:
        return 0
    for total in ("total_tokens", "total_token_count"):
        if isinstance(usage.get(total), int):
            return usage[total]
    parts = (("prompt_tokens", "completion_tokens"), ("input_tokens", "output_tokens"),
             ("prompt_token_count", "candidates_token_count"))
    for a, b in parts:
        if isinstance(usage.get(a), int) or isinstance(usage.get(b), int):
            return int(usage.get(a) or 0) + int(usage.get(b) or 0)
    return 0


class TaskLimits:
    """The counts of one task, in the memory of the request that runs it.

    Each check raises LimitExceeded when the task must stop, and every check
    after that raises the same error: a stopped task starts nothing more."""

    def __init__(self, caps: Caps, task_id: str | None = None, *,
                 clock: Callable[[], float] = time.monotonic):
        self.caps = caps
        self.task_id = task_id
        self._clock = clock
        self.started = clock()
        self.model_calls = 0
        self.tool_calls = 0
        self.tokens = 0
        self.stopped: LimitExceeded | None = None

    def _stop(self, limit: str, cap: int, used: int) -> LimitExceeded:
        if self.stopped is None:
            self.stopped = LimitExceeded(limit, cap, used, self.task_id)
        return self.stopped

    def elapsed(self) -> float:
        return self._clock() - self.started

    def remaining_seconds(self) -> float | None:
        cap = self.caps.wall_time_seconds
        return None if cap is None else max(0.0, cap - self.elapsed())

    def exhausted(self) -> bool:
        """Whether the task has stopped, or its wall time has run out."""
        rem = self.remaining_seconds()
        return self.stopped is not None or (rem is not None and rem <= 0)

    def wall_time_exceeded(self) -> LimitExceeded:
        """The error for a task whose wall time ran out: used is the whole
        seconds elapsed, at least the cap."""
        cap = self.caps.wall_time_seconds or 0
        return self._stop("wall_time_seconds", cap, max(cap, math.floor(self.elapsed())))

    def _check_wall(self) -> None:
        rem = self.remaining_seconds()
        if rem is not None and rem <= 0:
            raise self.wall_time_exceeded()

    def before_model_call(self) -> None:
        if self.stopped:
            raise self.stopped
        cap = self.caps.model_calls
        if cap is not None and self.model_calls >= cap:
            raise self._stop("model_calls", cap, self.model_calls)
        cap = self.caps.tokens
        if cap is not None and self.tokens >= cap:
            raise self._stop("tokens", cap, self.tokens)
        self._check_wall()
        self.model_calls += 1

    def after_model_response(self, tokens: int) -> None:
        """Adds a response's tokens; raises when the total passes the cap, so
        the response is not acted on."""
        self.tokens += max(0, tokens)
        if self.stopped:
            raise self.stopped
        cap = self.caps.tokens
        if cap is not None and self.tokens > cap:
            raise self._stop("tokens", cap, self.tokens)

    def before_tool_call(self) -> None:
        if self.stopped:
            raise self.stopped
        cap = self.caps.tool_calls
        if cap is not None and self.tool_calls >= cap:
            raise self._stop("tool_calls", cap, self.tool_calls)
        self._check_wall()
        self.tool_calls += 1

    async def bounded(self, work: Awaitable[T]) -> T:
        """Awaits work within the task's remaining wall time; when it runs out,
        the work is cancelled and LimitExceeded raised."""
        rem = self.remaining_seconds()
        if rem is None:
            return await work
        if rem <= 0:
            if asyncio.iscoroutine(work):
                work.close()
            raise self.wall_time_exceeded()
        try:
            async with asyncio.timeout(rem):
                return await work
        except TimeoutError:
            raise self.wall_time_exceeded() from None
