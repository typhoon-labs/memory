"""agentic_sdk: the platform's shared SDK, Python core. Framework-free: no
agent framework is imported here; adapters such as agentic_sdk_adk build on it.
The contracts it implements are agent-sdk's spec/, carried in agentic_sdk/_spec."""

__all__: list[str] = []
