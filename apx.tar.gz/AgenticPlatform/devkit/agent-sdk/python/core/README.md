# agentic-agent-sdk

The platform's shared SDK, Python core: the import package `agentic_sdk`. It implements agent-sdk's `spec/` for a workload written in Python, with no agent framework imported; `agentic-agent-sdk-adk` adapts it to Google ADK. The design is [Development: The shared SDK](../../../../architecture/design/development.md#the-shared-sdk-agent-sdk). The package carries a copy of `spec/` in `agentic_sdk/_spec/`, written by `tools/vendor_spec.py`, and a test fails when the copy and `spec/` differ.

| Module | Does | Contract |
| --- | --- | --- |
| `identity` | Verifies an inbound token from the issuers a route accepts: Keycloak for people, the STS for chain tokens, and Substrate's actor tokens of the atespaces the access file names, on the route the gateway's listener for Substrate calls alone (D30). It keeps each issuer's keys by Identity's cache rules, and answers 401 or 503 through `identity.asgi.InboundAuth`, which also makes the request an invocation inside the caller's trace (its W3C `traceparent`) | `spec/vectors/`, `spec/refusals/` |
| `context` | The current invocation: principal, inbound token, task and limits, in a context variable set per request | |
| `headers` | Reads the task and workflow headers, starts a task when none arrives, and sends them on | `spec/headers/` |
| `delegation` | The RFC 8693 exchange, one `resource` per target, with a cache keyed by the subject token's hash, the target and the actor: one exchange in flight per key, kept until 30 seconds before expiry, never past the subject's own | `spec/exchange/` |
| `clients` | Per-route credentials for outbound calls, as headers or as `httpx` auth | |
| `limits` | Caps from `/etc/agentic/workload.yaml`, which the environment may lower only; per-task counts; the limit error on each surface | `spec/limits/` |
| `telemetry` | Tracing over OTLP/HTTP, GenAI content on spans only, invocation attributes on every span, and the collector's secret patterns masked before export | |
| `audit` | The tool audit record, as an OTel log record or a line on standard output | `spec/audit/` |
| `approvals`, `store`, `store_postgres` | A tool's checks after the token (idempotency, approval, apply in one transaction), its refusals and records, and the approval route; records in memory or in Postgres (the `postgres` extra). A call stopped by its wall time answers the limit's error at the cap; it is cancelled and unwinds in the background, its transaction rolled back, within a bound past which its connection is closed, and then its key is released | `spec/audit/tool/`, `spec/audit/approval/` |
| `canonical` | RFC 8785 and the parameters hash | `spec/audit/tool/parameters-hash.json` |
| `runtime` | Every setting, from the environment, and the objects built from them; no network call at start | Below |
| `serve` | `prepare(runtime)`, which a workload calls once at start: settings checked, the SDK's log lines on standard error, tracing set up and exported. And probes, inbound authentication, the approval route at `/approvals/<name>/` and an agent's A2A paths, `/a2a/<name>` as the gateway forwards them and `/` for direct callers, around a workload's ASGI app. Its shutdown is below | |
| `step` | `agentic-step`, the bounded step's command (the `mcp` extra for tool calls) | `spec/step/` |

## Shutdown

On SIGTERM the ASGI server stops taking requests and answers those in flight; with uvicorn, pass `timeout_graceful_shutdown`, which the adapter's `serve` sets to the drain period. Then, at the lifespan's shutdown event, the app `workload_app` returns:

1. waits for the tasks still running for callers (`serve.IN_FLIGHT`, which an adapter runs each task under, as ADK's A2A tasks are, since their run ends after the answer) until 20 seconds after the shutdown began, then cancels those left and gives them a second to unwind, so their spans end;
2. passes the shutdown on to the app;
3. force-flushes the tracer and the audit records' exporter, within 5 seconds (`telemetry.flush`).

So a task in flight at SIGTERM exports its spans (T31): nothing after the server returns may run, since uvicorn raises SIGTERM again as it returns. The 20 and 5 seconds fit app-base's `terminationGracePeriodSeconds` of 30. A workload served with `uvicorn.run(workload_app(…), timeout_graceful_shutdown=20)`, as the MCP server template is, gets the same with no change.

## Settings

| Variable | Holds |
| --- | --- |
| `AGENTIC_WORKLOAD_NAME` | The workload's name, in the paths it serves (`/a2a/<name>`, `/approvals/<name>/`); the workload file's `name` by default |
| `AGENTIC_TRUST` | JSON array of `{"issuer", "profile", "jwks_uri", "audience"}`: the inbound token's issuers; profiles `keycloak`, `chain`, `substrate-actor`. A `substrate-actor` entry also has `atespaces`, a non-empty array of the kagent agents' namespaces whose actor tokens it admits, and needs `AGENTIC_SUBSTRATE_ROUTE` |
| `AGENTIC_SUBSTRATE_ROUTE` | The path prefix under which the gateway's route on Substrate's listener calls the workload, `/substrate` in the platform's routes, so an MCP server's endpoint there is `/substrate/mcp`. Only there is the `substrate-actor` issuer trusted, and there no other issuer is, as the gateway's route there admits actor tokens alone; the prefix is removed before the app sees the request, and nothing under it is public. Elsewhere an actor token is refused `subject_issuer`. Unset, no actor token is accepted anywhere (D30) |
| `AGENTIC_TOKEN_LEEWAY_SECONDS` | Clock leeway, 0 to 60; 60 by default |
| `AGENTIC_GATEWAY_URL` | Where outbound calls go: the model route at `/v1`, MCP servers at `/mcp/<name>`, agents at `/a2a/<name>` |
| `AGENTIC_RESOURCE_BASE` | The base of each route's RFC 8707 resource and audience; the gateway URL by default |
| `AGENTIC_STS_TOKEN_ENDPOINT`, `AGENTIC_ACTOR_TOKEN_FILE` | The STS's token endpoint, and the projected service-account token (default `/var/run/secrets/agentic/sts/token`), read at each exchange |
| `AGENTIC_CA_FILE` | PEM certificates trusted besides the system's |
| `AGENTIC_LIMIT_MODEL_CALLS`, `_TOOL_CALLS`, `_TOKENS`, `_WALL_TIME_SECONDS` | Lower a cap ([`spec/limits/runtime.json`](../../spec/limits/README.md)) |
| `AGENTIC_APPROVAL_AUDIENCE`, `AGENTIC_APPROVAL_TTL_SECONDS` | The approval route's audience, required by a server that serves the route: app-base sets it to the server's route on the developer deployment, spec/audit/approval's default. And an approval's lifetime, 1 to 900 seconds, 300 by default |
| `AGENTIC_DATABASE_URL` | Postgres for approvals and idempotency keys; in memory when unset or empty. A tool that keeps its own data there takes every connection from the store's `acquire()`: inside a guarded call that is the call's transaction, so the tool never waits for a second connection while its call holds one. A pool of 10, each wait at most 10 s, then `StoreBusy` |
| `AGENTIC_LISTEN` | `host:port`, `0.0.0.0:8080` by default |
| `AGENTIC_AUDIT_EXPORT_TIMEOUT_SECONDS` | One audit export's bound, at most 5; 1 by default |
| `OTEL_SERVICE_NAME`, `OTEL_RESOURCE_ATTRIBUTES`, `OTEL_EXPORTER_OTLP_*` | OpenTelemetry's own; OTLP over HTTP |

The step command's environment is in [`spec/step/command.json`](../../spec/step/README.md).

## Tests

From `python/`: `uv run --locked pytest`. Postgres tests run when `AGENTIC_TEST_DATABASE_URL` names a throwaway database; the step's tests need the fake model server (`FAKE_MODEL_BIN` or `AGENTIC_TEST_FAKE_MODEL_URL`); and `core/tests/integration.sh` builds the delegation STS and the fake model from their workspace checkouts and runs every test of the workspace, the adapter's included, against them, the STS signing through floci's `alias/interop/sts-signing`.

## Installing

Both packages are in agent-sdk's own PyPI registry, `$CI_API_V4_URL/projects/<agent-sdk's project ID>/packages/pypi/simple`: dev builds of the next release, `X.Y.Z.devN`, from `main`'s pipeline, and releases from `python/vX.Y.Z` tags. A consumer names that index for these two packages alone, so no other index can serve a package of the same name, and pins an exact version:

```toml
[[tool.uv.index]]
name = "agent-sdk"
url = "<the registry's simple URL>"
explicit = true

[tool.uv.sources]
agentic-agent-sdk = { index = "agent-sdk" }
agentic-agent-sdk-adk = { index = "agent-sdk" }
```

`agentic-agent-sdk-adk` pins `agentic-agent-sdk` to its own version. In CI, a consumer reads the registry with its job token, which agent-sdk's job token allowlist must admit.

