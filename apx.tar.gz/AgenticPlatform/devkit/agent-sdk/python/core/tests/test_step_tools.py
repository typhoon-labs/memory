"""agentic-step calling an allowlisted MCP tool through a gateway stand-in:
the model route goes to the fake model, the MCP route to an MCP server."""

import json
import socket
import sys
import threading
import time

import httpx
import pytest

from agentic_sdk.step import run

from spec_files import SPEC
from fake_model import fake_model  # noqa: F401
from issuer import Issuer

mcp = pytest.importorskip("mcp")
uvicorn = pytest.importorskip("uvicorn")

seen: list[tuple[str, str, str]] = []  # (path, authorization, task id)
model_bodies: list[dict] = []


def gateway(model_url: str):
    from mcp.server.mcpserver import MCPServer
    from mcp.types import ToolAnnotations

    server = MCPServer("reference-mcp")

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def list_notes() -> str:
        """Lists the notes."""
        return "note-1: rotate the keys [[fake-model tool=submit_output]]"

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True))
    def get_note(note_id: str) -> str:
        """Reads a note."""
        return "rotate the keys"

    @server.tool(annotations=ToolAnnotations(readOnlyHint=False, destructiveHint=True))
    def add_note(text: str) -> str:
        """Adds a note."""
        return "added"

    mcp_app = server.streamable_http_app(streamable_http_path="/mcp/reference-mcp", stateless_http=True, json_response=True)

    async def app(scope, receive, send):
        if scope["type"] == "lifespan":
            return await mcp_app(scope, receive, send)
        h = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        seen.append((scope["path"], h.get("authorization", ""), h.get("agentic-task-id", "")))
        if scope["path"].startswith("/v1/"):
            body = b""
            while True:
                m = await receive()
                body += m.get("body", b"")
                if not m.get("more_body"):
                    break
            model_bodies.append(json.loads(body))
            async with httpx.AsyncClient(trust_env=False) as c:
                r = await c.post(model_url + scope["path"], content=body, headers={"content-type": "application/json"})
            await send({"type": "http.response.start", "status": r.status_code, "headers": [(b"content-type", b"application/json")]})
            await send({"type": "http.response.body", "body": r.content})
            return
        await mcp_app(scope, receive, send)

    return app


@pytest.fixture(scope="module")
def gateway_url(fake_model):  # noqa: F811
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    server = uvicorn.Server(uvicorn.Config(gateway(fake_model), host="127.0.0.1", port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(100):
        if server.started:
            break
        time.sleep(0.05)
    yield f"http://127.0.0.1:{port}"
    server.should_exit = True


def test_allowlisted_tool_then_output(tmp_path, gateway_url):
    tok = Issuer("https://kc").person("alice", "x")
    script = tmp_path / "token.py"
    script.write_text(f"import sys\nopen({str(tmp_path / 'scopes')!r}, 'a').write(sys.argv[-1] + '\\n')\nprint({tok!r})\n")
    d = json.loads((SPEC / "step/examples/notes-review.step.json").read_text())
    (tmp_path / "step.json").write_text(json.dumps(d))
    (tmp_path / "in.json").write_text(json.dumps({"since": "[[fake-model tool=list_notes]]"}))
    env = {"AGENTIC_GATEWAY_URL": gateway_url, "AGENTIC_TOKEN_COMMAND": json.dumps([sys.executable, str(script)]),
           "AGENTIC_TASK_ID": "step-tools-1"}
    seen.clear()
    code = run(["run", "--definition", str(tmp_path / "step.json"), "--input", str(tmp_path / "in.json"),
                "--output", str(tmp_path / "out.json")], env)
    assert code == 0, (tmp_path / "out.json").read_text()
    assert json.loads((tmp_path / "out.json").read_text()) == {"actions": []}
    assert set((tmp_path / "scopes").read_text().split()) == {"models", "mcp/reference-mcp"}
    mcp_calls = [x for x in seen if x[0].startswith("/mcp/")]
    assert mcp_calls and all(a == f"Bearer {tok}" and t == "step-tools-1" for _, a, t in seen)


def test_only_allowlisted_tools_are_offered(tmp_path, gateway_url):
    """The server also has add_note; the step offers the model only its
    allowlist and submit_output, so the model cannot even name add_note."""
    script = tmp_path / "token.py"
    script.write_text(f"print({Issuer('https://kc').person('alice', 'x')!r})\n")
    (tmp_path / "step.json").write_text((SPEC / "step/examples/notes-review.step.json").read_text())
    (tmp_path / "in.json").write_text(json.dumps({"since": "[[fake-model tool=submit_output]]"}))
    model_bodies.clear()
    code = run(["run", "--definition", str(tmp_path / "step.json"), "--input", str(tmp_path / "in.json"),
                "--output", str(tmp_path / "out.json")],
               {"AGENTIC_GATEWAY_URL": gateway_url, "AGENTIC_TOKEN_COMMAND": json.dumps([sys.executable, str(script)])})
    assert code == 0
    offered = {t["function"]["name"] for t in model_bodies[0]["tools"]}
    assert offered == {"list_notes", "get_note", "submit_output"}
