"""The package's copy of spec/ equals spec/ (tools/vendor_spec.py)."""

from importlib.resources import files

from agentic_sdk import contract

from spec_files import SPEC

SKIP = {"examples", "invalid", "vectors"}


def test_vendored_copy_matches_spec():
    root = files("agentic_sdk") / "_spec"
    want = {p.relative_to(SPEC).as_posix(): p.read_bytes() for p in SPEC.rglob("*.json")
            if not SKIP.intersection(p.relative_to(SPEC).parts)}
    have = {}

    def walk(node, prefix=""):
        for c in node.iterdir():
            if c.is_dir():
                walk(c, f"{prefix}{c.name}/")
            else:
                have[f"{prefix}{c.name}"] = c.read_bytes()

    walk(root)
    assert sorted(have) == sorted(want), "run python3 tools/vendor_spec.py in python/core"
    assert [k for k in want if have[k] != want[k]] == []


def test_validators_resolve_relative_refs():
    workload = {"name": "x-mcp", "kind": "mcp-server", "runtime": "container", "owner": "t", "support": "experimental",
                "tools": [{"name": "a", "annotations": {"readOnlyHint": True}}], "limits": {"wall_time_seconds": 0}}
    assert "wall_time_seconds" in contract.first_error("schemas/workload.schema.json", workload)
    workload["limits"]["wall_time_seconds"] = 5
    assert contract.first_error("schemas/workload.schema.json", workload) is None


def test_every_spec_example_and_invalid_case():
    """The package's validators agree with spec/'s examples/ and invalid/ dirs."""
    n = 0
    for p in SPEC.rglob("*.json"):
        rel = p.relative_to(SPEC)
        if rel.parent.name not in ("examples", "invalid") or rel.parent.as_posix() in ("audit/examples", "claims/examples"):
            continue
        schema = (rel.parent.parent / (p.name.removesuffix(".json").rsplit(".", 1)[1] + ".schema.json")).as_posix()
        import json
        err = contract.first_error(schema, json.loads(p.read_text(encoding="utf-8")))
        assert (err is None) == (rel.parent.name == "examples"), (rel, err)
        n += 1
    assert n > 60
