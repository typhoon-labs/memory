"""agentic-step against the fake model server."""

import json
import os
import sys

import pytest

from agentic_sdk import contract
from agentic_sdk.step import run

from spec_files import SPEC
from fake_model import fake_model  # noqa: F401
from issuer import Issuer

DEFINITION = json.loads((SPEC / "step/examples/release-notes.step.json").read_text())


@pytest.fixture
def env(tmp_path, fake_model):  # noqa: F811
    tok = Issuer("https://kc").person("alice", "https://gateway.agentic.internal/v1")
    script = tmp_path / "token.py"
    script.write_text(f"import sys\nopen({str(tmp_path / 'scopes')!r}, 'a').write(sys.argv[-1] + '\\n')\nprint({tok!r})\n")
    return {"AGENTIC_GATEWAY_URL": fake_model, "AGENTIC_TOKEN_COMMAND": json.dumps([sys.executable, str(script)]),
            "AGENTIC_TASK_ID": "step-test-1", "AGENTIC_WORKFLOW_NAME": "release-notes-workflow", "AGENTIC_WORKFLOW_VERSION": "1.0.0"}


def step(tmp_path, env, input, definition=None, **extra_env):
    d = tmp_path / "step.json"
    d.write_text(json.dumps(definition or DEFINITION))
    i = tmp_path / "in.json"
    i.write_text(json.dumps(input))
    o = tmp_path / "out.json"
    code = run(["run", "--definition", str(d), "--input", str(i), "--output", str(o), "--workload", str(tmp_path / "none.yaml")]
               if extra_env.pop("missing_workload", False) else
               ["run", "--definition", str(d), "--input", str(i), "--output", str(o)], {**env, **extra_env})
    return code, (json.loads(o.read_text()) if o.exists() else None)


def changes(*directives):
    return {"version": "1.4.0", "changes": ["Add the notes tool", *directives]}


def test_output_through_submit_output(tmp_path, env):
    code, out = step(tmp_path, env, changes("[[fake-model tool=submit_output]]"))
    assert code == 0 and out == {"title": "fake", "summary": "fake"}
    assert (tmp_path / "scopes").read_text().split() == ["models"]


def test_token_limit_stops_with_status_3(tmp_path, env):
    code, out = step(tmp_path, env, changes("[[fake-model tokens=500]]"), AGENTIC_LIMIT_TOKENS="200")
    assert code == 3 and contract.first_error("limits/error.schema.json", out) is None
    assert (out["error"], out["limit"], out["cap"]) == ("limit_exceeded", "tokens", 200) and out["used"] > 200
    assert out["task_id"] == "step-test-1"


def test_model_call_limit(tmp_path, env):
    code, out = step(tmp_path, env, changes(), AGENTIC_LIMIT_MODEL_CALLS="2")
    assert code == 3 and (out["limit"], out["cap"], out["used"]) == ("model_calls", 2, 2)


def test_wall_time_limit(tmp_path, env):
    code, out = step(tmp_path, env, changes("[[fake-model delay=3s]]"), AGENTIC_LIMIT_WALL_TIME_SECONDS="1")
    assert code == 3 and out["limit"] == "wall_time_seconds" and out["used"] >= 1


@pytest.mark.parametrize("path,status", [("stop", 1), ("human", 4)])
def test_invalid_output_after_reprompts_takes_the_failure_path(tmp_path, env, path, status):
    code, out = step(tmp_path, env, changes(), {**DEFINITION, "on_failure": path})
    assert code == status and contract.first_error("step/failure.schema.json", out) is None
    assert (out["error"], out["reason"], out["on_failure"]) == ("step_failed", "output_invalid", path)


def test_invalid_input_calls_nothing(tmp_path, env):
    code, out = step(tmp_path, env, {"version": "1"})
    assert code == 5 and (out["error"], out["reason"]) == ("step_invalid", "input_invalid")
    assert not (tmp_path / "scopes").exists()


def test_invalid_definition_and_environment(tmp_path, env):
    code, out = step(tmp_path, env, changes(), {**DEFINITION, "reprompts": 3})
    assert (code, out["reason"]) == (5, "definition_invalid")
    code, out = step(tmp_path, {**env, "AGENTIC_TOKEN_COMMAND": "agentctl token"}, changes())
    assert (code, out["reason"]) == (5, "environment_invalid")
    code, out = step(tmp_path, env, changes(), AGENTIC_LIMIT_TOKENS="lots")
    assert (code, out["reason"]) == (5, "environment_invalid")
    code, out = step(tmp_path, env, changes(), missing_workload=True)
    assert (code, out["reason"]) == (5, "workload_invalid")
    assert run(["run", "--definition", "x"], env) == 5
    out = tmp_path / "usage.json"
    assert run(["run", "--definition", "x", "--bogus", "--output", str(out)], env) == 5
    assert json.loads(out.read_text())["reason"] == "usage"


def test_token_command_failure(tmp_path, env):
    code, out = step(tmp_path, {**env, "AGENTIC_TOKEN_COMMAND": json.dumps([sys.executable, "-c", "import sys; sys.exit(2)"])}, changes())
    assert code == 1 and out["reason"] == "token_unavailable"


def test_a_call_outside_the_allowlist_is_not_started(monkeypatch):
    import asyncio

    import httpx

    from agentic_sdk import headers
    from agentic_sdk.limits import Caps
    from agentic_sdk.step import Step, TokenSource

    answers = [
        {"role": "assistant", "tool_calls": [{"id": "1", "type": "function", "function": {"name": "add_note", "arguments": "{}"}}]},
        {"role": "assistant", "tool_calls": [{"id": "2", "type": "function", "function": {"name": "submit_output", "arguments": '{"title": "t", "summary": "s"}'}}]},
    ]
    seen = []

    async def model(self, messages, tools):
        self.limits.before_model_call()
        seen.append(messages[-1])
        return answers.pop(0)

    async def call_tool(self, name, arguments):
        raise AssertionError("no tool may be called")

    monkeypatch.setattr(Step, "model", model)
    monkeypatch.setattr(Step, "call_tool", call_tool)

    async def go():
        async with httpx.AsyncClient() as http:
            s = Step(DEFINITION, {}, Caps(3, 0, 1000, 60), "http://gw", TokenSource(["x"]), headers.TaskHeaders("t"), http)
            return await s.run(), s

    out, s = asyncio.run(go())
    assert out == {"title": "t", "summary": "s"} and s.limits.tool_calls == 0
    assert seen[-1]["role"] == "tool" and "not allowed" in seen[-1]["content"]
