"""The audit emitter with the real OTLP/HTTP log exporter: a collector that
takes the record, one that is down, and one that never answers."""

import io
import json
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from opentelemetry import trace
from opentelemetry.proto.collector.logs.v1.logs_service_pb2 import ExportLogsServiceRequest

from agentic_sdk.audit import AuditEmitter, tool_record

received = []


class Collector(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        received.append((self.path, self.rfile.read(int(self.headers["Content-Length"]))))
        self.send_response(200)
        self.send_header("Content-Type", "application/x-protobuf")
        self.send_header("Content-Length", "0")
        self.end_headers()


def record():
    with trace.get_tracer("t").start_as_current_span("execute_tool add_note"):
        return tool_record(tool="add_note", outcome="completed", parameters_hash="sha256:" + "1" * 64,
                           principal_attributes={"user.id": "alice", "actor.sub": "c/n/a", "actor.chain": ["c/n/a"]},
                           task_attributes={"task.id": "t1"}, destructive=True)


def emitter(endpoint, timeout="1"):
    out = io.StringIO()
    em = AuditEmitter.from_env("reference-mcp", {"OTEL_EXPORTER_OTLP_ENDPOINT": endpoint,
                                                 "AGENTIC_AUDIT_EXPORT_TIMEOUT_SECONDS": timeout})
    em._stream = out
    return em, out


def test_a_collector_takes_the_encoded_record():
    server = ThreadingHTTPServer(("127.0.0.1", 0), Collector)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        em, out = emitter(f"http://127.0.0.1:{server.server_port}")
        rec = record()
        em.emit(rec)
        assert out.getvalue() == "" and em.diverted == 0
        path, body = received[-1]
        req = ExportLogsServiceRequest.FromString(body)
        rl = req.resource_logs[0]
        sl = rl.scope_logs[0]
        lr = sl.log_records[0]
        assert path == "/v1/logs" and sl.scope.name == "audit" and lr.severity_number == 9 and lr.severity_text == "INFO"
        assert {a.key: a.value.string_value for a in rl.resource.attributes}["service.name"] == "reference-mcp"
        attrs = {a.key: a.value for a in lr.attributes}
        assert attrs["event.name"].string_value == "tool.call" and attrs["tool.destructive"].bool_value is True
        assert [v.string_value for v in attrs["actor.chain"].array_value.values] == ["c/n/a"]
        assert lr.trace_id.hex() == rec["trace_id"] and lr.span_id.hex() == rec["span_id"]
        assert not lr.HasField("body") or lr.body.WhichOneof("value") is None  # no body value
    finally:
        server.shutdown()


def test_collector_down_or_hanging_costs_one_bounded_export():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    dead = s.getsockname()[1]
    s.close()
    hang = socket.socket()
    hang.bind(("127.0.0.1", 0))
    hang.listen(8)  # accepts connections, never answers
    for port in (dead, hang.getsockname()[1]):
        em, out = emitter(f"http://127.0.0.1:{port}")
        t0 = time.monotonic()
        em.emit(record())
        first = time.monotonic() - t0
        em.emit(record())  # paused: straight to the line
        assert first < 2.5, first
        lines = [json.loads(x) for x in out.getvalue().splitlines()]
        assert len(lines) == 2 and lines[0]["event.name"] == "tool.call" and em.diverted == 1
    hang.close()
