"""The fake model server (ci-components' conformance fixture) for tests: one
already running at AGENTIC_TEST_FAKE_MODEL_URL (its model port; its
operations port at AGENTIC_TEST_FAKE_MODEL_OPS_URL), or the binary at
FAKE_MODEL_BIN started on free ports. Tests that need it skip otherwise."""

import os
import socket
import subprocess
import time
import urllib.request

import pytest


def _free() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


@pytest.fixture(scope="session")
def fake_model():
    url = os.environ.get("AGENTIC_TEST_FAKE_MODEL_URL")
    if url:
        yield url.rstrip("/")
        return
    binary = os.environ.get("FAKE_MODEL_BIN")
    if not binary:
        pytest.skip("neither AGENTIC_TEST_FAKE_MODEL_URL nor FAKE_MODEL_BIN is set")
    port, ops = _free(), _free()
    proc = subprocess.Popen([binary, "-listen", f"127.0.0.1:{port}", "-ops-listen", f"127.0.0.1:{ops}"],
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(100):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{ops}/readyz", timeout=0.2)
            break
        except OSError:
            time.sleep(0.05)
    yield f"http://127.0.0.1:{port}"
    proc.terminate()
    proc.wait(5)
