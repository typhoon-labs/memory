import asyncio

import pytest

from agentic_sdk import contract
from agentic_sdk.approvals import ToolGuard, ToolPolicy, approval_lifetime
from agentic_sdk.limits import Caps
from agentic_sdk.store import MemoryStore

from approvals_flow import APPEND, MCP_AUD, STS, AGENT, Records, World, run_flows


@pytest.mark.anyio
async def test_flows_in_memory():
    w = await run_flows(MemoryStore(clock=lambda: 0))
    assert w.applied >= 4


def test_policies_follow_mcp_defaults():
    assert ToolPolicy.from_annotations("x", None).needs_approval  # MCP's defaults: destructive
    assert ToolPolicy.from_annotations("x", {"readOnlyHint": False}).needs_approval
    assert not ToolPolicy.from_annotations("x", {"readOnlyHint": False, "destructiveHint": False}).needs_approval
    ro = ToolPolicy.from_annotations("x", {"readOnlyHint": True, "destructiveHint": True})
    assert not ro.needs_approval and not ro.deduplicates


def test_approval_lifetime():
    assert approval_lifetime({}) == 300
    assert approval_lifetime({"AGENTIC_APPROVAL_TTL_SECONDS": "5"}) == 5
    for bad in ("901", "0", "x"):
        with pytest.raises(ValueError):
            approval_lifetime({"AGENTIC_APPROVAL_TTL_SECONDS": bad})


@pytest.mark.anyio
async def test_wall_time_stops_the_call_and_frees_its_key():
    store = MemoryStore()
    w = World(store, lambda: 0)
    w.guard = ToolGuard(store, w.guard.audit, caps=Caps(wall_time_seconds=1))
    w.slow = 3
    r = await w.call(STS.chain("alice", MCP_AUD, AGENT), APPEND, {"text": "slow"}, "t-slow")
    assert r["isError"] and r["structuredContent"]["limit"] == "wall_time_seconds"
    assert contract.first_error("limits/error.schema.json", r["structuredContent"]) is None
    rec = w.audit.records[-1]
    assert (rec["tool.call.outcome"], rec["error.type"]) == ("failed", "limit_exceeded")
    assert (await store.reserve_key("anything")).state == "new"
    w.slow = 0
    assert (await w.call(STS.chain("alice", MCP_AUD, AGENT), APPEND, {"text": "slow"}, "t-slow"))["isError"] is False


@pytest.mark.anyio
async def test_a_cancelled_call_frees_its_key():
    store = MemoryStore()
    w = World(store, lambda: 0)
    w.slow = 5
    tok = STS.chain("alice", MCP_AUD, AGENT)
    t = asyncio.create_task(w.call(tok, APPEND, {"text": "c"}, "t-cancel"))
    await asyncio.sleep(0.1)
    t.cancel()
    with pytest.raises(asyncio.CancelledError):
        await t
    w.slow = 0
    assert (await w.call(tok, APPEND, {"text": "c"}, "t-cancel"))["isError"] is False


@pytest.mark.anyio
async def test_a_slow_store_does_not_hold_the_limit_answer():
    """Wall time runs out while the store is slow: the call answers the limit
    error without waiting for the slow store again past a short bound."""
    import time

    class SlowStore(MemoryStore):
        async def release_key(self, key):
            await asyncio.sleep(5)

    store = SlowStore()
    w = World(store, lambda: 0)
    w.guard = ToolGuard(store, w.guard.audit, caps=Caps(wall_time_seconds=1))
    w.slow = 3  # the change itself outlasts the wall time; the key is held
    t0 = time.monotonic()
    r = await w.call(STS.chain("alice", MCP_AUD, AGENT), APPEND, {"text": "x"}, "t-slow-store")
    assert r["structuredContent"]["limit"] == "wall_time_seconds" and time.monotonic() - t0 < 4
