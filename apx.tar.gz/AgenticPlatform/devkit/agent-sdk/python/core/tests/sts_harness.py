"""A delegation STS built from source, for integration tests: TLS from a
throwaway CA, signing through a floci KMS alias (alias/interop/sts-signing,
created by delegation-sts' interop/rotation/floci-kms.sh init and never moved
here), and a stand-in for Keycloak (JWKS and introspection) and the
Kubernetes TokenReview API, in this process. Tests that use it skip unless
DELEGATION_STS_BIN names the binary; tests/integration.sh builds it.

Environment: AWS_ENDPOINT_URL (default http://floci:4566), AWS_REGION and
credentials as floci takes them; STS_SIGNING_ALIAS to sign through another alias."""

from __future__ import annotations

import base64
import json
import os
import socket
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from issuer import Issuer

DOMAIN = "agentic.internal"
CLUSTER = "agentic-local"
AGENT_SA = "reference-agent/reference-agent"
AGENT = f"{CLUSTER}/{AGENT_SA}"
PERSON_ROUTE = f"https://gateway.{DOMAIN}/a2a/reference-agent"
MCP_RESOURCE = f"https://workloads-gateway.{DOMAIN}/mcp/reference-mcp"
MODEL_RESOURCE = f"https://workloads-gateway.{DOMAIN}/v1"

POLICY = """version: 1
max_chain: 3
token_ttl_seconds: 300
carried_claims: [idp_sub, roles, team, sid, preferred_username, acr, auth_time]
rate_limit: {per_second: 10, burst: 50}
agents:
  reference-agent:
    actor: reference-agent/reference-agent
    routes: [gateway/a2a/reference-agent]
    after: [person]
    targets: [workloads-gateway/mcp/reference-mcp, workloads-gateway/v1]
"""


def _free() -> int:
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def _claims(token: str) -> dict:
    part = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))


class _Stand(BaseHTTPRequestHandler):
    """Keycloak's JWKS and introspection, and TokenReview, as the STS calls them."""

    keycloak: Issuer
    inactive: set[str]

    def log_message(self, *args):  # quiet
        pass

    def _json(self, status: int, body: dict) -> None:
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.endswith("/protocol/openid-connect/certs"):
            return self._json(200, self.keycloak.jwks())
        self._json(404, {})

    def do_POST(self):
        body = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        if self.path.endswith("/token/introspect"):
            token = urllib.parse.parse_qs(body.decode()).get("token", [""])[0]
            c = _claims(token)
            if c.get("sub") in self.inactive:
                return self._json(200, {"active": False})
            return self._json(200, {"active": True, "token_type": "Bearer", **c})
        if self.path == "/apis/authentication.k8s.io/v1/tokenreviews":
            req = json.loads(body)
            c = _claims(req["spec"]["token"])
            k = c.get("kubernetes.io", {})
            matched = [a for a in req["spec"].get("audiences", []) if a in c.get("aud", [])]
            status = {"authenticated": bool(matched), "audiences": matched,
                      "user": {"username": f"system:serviceaccount:{k['namespace']}:{k['serviceaccount']['name']}",
                               "extra": {"authentication.kubernetes.io/pod-name": [k["pod"]["name"]]}}}
            return self._json(201, {"kind": "TokenReview", "apiVersion": "authentication.k8s.io/v1", "status": status})
        self._json(404, {})


@dataclass
class StsHarness:
    issuer: str
    token_endpoint: str
    ca_file: str
    keycloak: Issuer
    audit_file: Path
    inactive: set[str]
    _kube: Issuer

    def actor_token(self, sa: str = AGENT_SA, lifetime: int = 600) -> str:
        ns, name = sa.split("/")
        now = int(time.time())
        return self._kube.token(typ="JWT", sub=f"system:serviceaccount:{ns}:{name}", aud=[self.issuer], nbf=now,
                                exp=now + lifetime, **{"kubernetes.io": {"namespace": ns, "serviceaccount": {"name": name},
                                                                         "pod": {"name": f"{name}-pod", "uid": "u-1"}}})

    def person(self, sub: str, **claims) -> str:
        return self.keycloak.person(sub, PERSON_ROUTE, idp_sub=f"00u{sub}", roles=["developer"], **claims)

    def audit_records(self) -> list[dict]:
        return [json.loads(line) for line in self.audit_file.read_text().splitlines() if line.startswith("{")]


@pytest.fixture(scope="session")
def sts(tmp_path_factory) -> StsHarness:
    binary = os.environ.get("DELEGATION_STS_BIN")
    if not binary:
        pytest.skip("DELEGATION_STS_BIN not set: run tests/integration.sh")
    d = tmp_path_factory.mktemp("sts")
    run = lambda *a: subprocess.run(a, check=True, capture_output=True)  # noqa: E731
    run("openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256", "-nodes", "-days", "1",
        "-subj", "/CN=sdk-it-ca", "-addext", "basicConstraints=critical,CA:TRUE",
        "-addext", "keyUsage=critical,keyCertSign,cRLSign", "-keyout", d / "ca.key", "-out", d / "ca.crt")
    run("openssl", "req", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256", "-nodes", "-subj", "/CN=localhost",
        "-keyout", d / "tls.key", "-out", d / "tls.csr")
    (d / "san").write_text("subjectAltName=DNS:localhost,IP:127.0.0.1\nkeyUsage=critical,digitalSignature\n"
                           "extendedKeyUsage=serverAuth\nauthorityKeyIdentifier=keyid\nsubjectKeyIdentifier=hash\n")
    run("openssl", "x509", "-req", "-in", d / "tls.csr", "-CA", d / "ca.crt", "-CAkey", d / "ca.key", "-CAcreateserial",
        "-days", "1", "-extfile", d / "san", "-out", d / "tls.crt")

    stand_port = _free()
    keycloak = Issuer(f"http://127.0.0.1:{stand_port}/realms/sdk-it", kid="kc-it")
    inactive: set[str] = set()
    handler = type("Stand", (_Stand,), {"keycloak": keycloak, "inactive": inactive})
    server = ThreadingHTTPServer(("127.0.0.1", stand_port), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()

    public, token, ops = _free(), _free(), _free()
    (d / "policy.yaml").write_text(POLICY)
    (d / "deny.yaml").write_text("entries: []\n")
    (d / "kubeconfig.yaml").write_text(json.dumps({
        "apiVersion": "v1", "kind": "Config", "current-context": "c",
        "clusters": [{"name": "c", "cluster": {"server": f"http://127.0.0.1:{stand_port}"}}],
        "users": [{"name": "u", "user": {"token": "sdk-it"}}],
        "contexts": [{"name": "c", "context": {"cluster": "c", "user": "u"}}]}))
    (d / "sts.yaml").write_text(json.dumps({
        "issuer": f"https://127.0.0.1:{public}", "token_endpoint": f"https://127.0.0.1:{token}/token",
        "platform_domain": DOMAIN, "cluster": CLUSTER,
        "listen": {"public": f"127.0.0.1:{public}", "token": f"127.0.0.1:{token}", "ops": f"127.0.0.1:{ops}"},
        "tls": {"cert_file": str(d / "tls.crt"), "key_file": str(d / "tls.key")},
        "policy_file": str(d / "policy.yaml"), "deny_list_file": str(d / "deny.yaml"),
        "task_header": "Agentic-Task-Id",
        "keycloak": {"issuer": keycloak.iss}, "kubernetes": {"kubeconfig": str(d / "kubeconfig.yaml")},
        "kms": {"alias": os.environ.get("STS_SIGNING_ALIAS", "alias/interop/sts-signing")}}))
    env = {**{k: v for k, v in os.environ.items() if "proxy" not in k.lower()},
           "AWS_ENDPOINT_URL": os.environ.get("AWS_ENDPOINT_URL", "http://floci:4566"),
           "AWS_REGION": os.environ.get("AWS_REGION", "us-east-1"),
           "AWS_ACCESS_KEY_ID": os.environ.get("AWS_ACCESS_KEY_ID", "test"),
           "AWS_SECRET_ACCESS_KEY": os.environ.get("AWS_SECRET_ACCESS_KEY", "test")}
    audit = d / "audit.jsonl"
    with open(audit, "w") as out, open(d / "sts.log", "w") as err:
        proc = subprocess.Popen([binary, "-config", str(d / "sts.yaml")], stdout=out, stderr=err, env=env)
    for _ in range(100):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{ops}/readyz", timeout=0.2)
            break
        except OSError:
            if proc.poll() is not None:
                break
            time.sleep(0.1)
    else:
        proc.terminate()
        pytest.fail("the STS did not become ready: " + (d / "sts.log").read_text()[-2000:])
    if proc.poll() is not None:
        pytest.fail("the STS exited: " + (d / "sts.log").read_text()[-2000:])
    yield StsHarness(f"https://127.0.0.1:{public}", f"https://127.0.0.1:{token}/token", str(d / "ca.crt"), keycloak,
                     audit, inactive, Issuer("https://kubernetes.default.svc", kid="kube-it"))
    proc.terminate()
    proc.wait(10)
    server.shutdown()
