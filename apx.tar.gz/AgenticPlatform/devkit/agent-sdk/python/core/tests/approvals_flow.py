"""The Approvals and idempotency flows, against any Store: shared by the
in-memory and the Postgres tests."""

import asyncio
import json

import pytest

from agentic_sdk import context, contract, headers
from agentic_sdk.approvals import ApprovalRoute, Target, ToolGuard, ToolPolicy
from agentic_sdk.audit import AuditEmitter
from agentic_sdk.identity import CHAIN, KEYCLOAK, IssuerTrust, StaticKeys, Verifier
from opentelemetry.sdk._logs.export import LogRecordExportResult

from issuer import Issuer

KC, STS = Issuer("https://kc"), Issuer("https://sts")
MCP_AUD = "https://workloads-gateway.agentic.internal/mcp/reference-mcp"
APPROVE_AUD = "https://gateway.agentic.internal/mcp/reference-mcp"
AGENT = "agentic-local/reference-agent/reference-agent"
ADD = ToolPolicy.from_annotations("add_note", {"readOnlyHint": False, "destructiveHint": True})
LIST = ToolPolicy.from_annotations("list_notes", {"readOnlyHint": True})
APPEND = ToolPolicy.from_annotations("append_log", {"readOnlyHint": False, "destructiveHint": False})


class Records:
    def __init__(self):
        self.records = []

    def export(self, batch):
        for lr in batch:
            self.records.append({k: (list(v) if isinstance(v, tuple) else v) for k, v in lr.log_record.attributes.items()})
        return LogRecordExportResult.SUCCESS


class World:
    """A notes server's state, the guard, and the approval route."""

    def __init__(self, store, clock):
        self.store, self.clock = store, clock
        self.notes = {"note-42": {"text": "old", "version": 7}}
        self.applied = 0
        self.audit = Records()
        self.guard = ToolGuard(store, AuditEmitter("reference-mcp", self.audit), clock=clock)
        self.verifier = Verifier([IssuerTrust("https://sts", CHAIN, StaticKeys(STS.jwks()), MCP_AUD),
                                  IssuerTrust("https://kc", KEYCLOAK, StaticKeys(KC.jwks()), MCP_AUD)])
        route_verifier = Verifier([IssuerTrust("https://kc", KEYCLOAK, StaticKeys(KC.jwks()), APPROVE_AUD)])
        self.route = ApprovalRoute(store, route_verifier, name="reference-mcp", lifetime=300,
                                   current_target=self.current, clock=clock)
        self.slow = 0.0

    async def current(self, tool, target_id):
        n = self.notes.get(target_id)
        return Target(target_id, str(n["version"])) if n else None

    async def call(self, token: str, policy: ToolPolicy, args: dict, task: str | None):
        principal = await self.verifier.verify(token)

        async def target(tx):
            return await self.current(policy.name, args["note_id"]) if "note_id" in args else None

        async def apply(tx):
            await asyncio.sleep(self.slow)
            if args.get("text") == "boom":
                raise RuntimeError("boom")
            change = lambda: self._change(args)  # noqa: E731
            if hasattr(tx, "after_commit"):
                tx.after_commit(change)
            else:
                change()
            return {"isError": False, "content": [{"type": "text", "text": "ok"}], "structuredContent": {"n": self.applied + 1}}

        inv = context.Invocation(task=headers.TaskHeaders(task), principal=principal, token=token)
        with context.use(inv):
            return await self.guard.call(policy, args, apply, target=target if policy is ADD else None)

    def _change(self, args):
        self.applied += 1
        n = self.notes.setdefault(args.get("note_id", "log"), {"text": "", "version": 0})
        n["text"], n["version"] = args.get("text", ""), n["version"] + 1

    async def http(self, method: str, approval_id: str, token: str | None, body: dict | None = None):
        sent = []
        hdrs = [(b"authorization", b"Bearer " + token.encode())] if token else []
        data = json.dumps(body).encode() if body is not None else b""

        async def receive():
            return {"type": "http.request", "body": data, "more_body": False}

        async def send(m):
            sent.append(m)

        await self.route({"type": "http", "method": method, "path": f"/approvals/reference-mcp/{approval_id}", "headers": hdrs}, receive, send)
        status = sent[0]["status"]
        payload = json.loads(sent[1]["body"]) if sent[1]["body"] else None
        return status, payload


def err(result):
    return result.get("structuredContent", {}).get("error") if result.get("isError") else None


async def run_flows(store):
    clock = [1_794_830_400.0]
    w = World(store, lambda: clock[0])
    alice = STS.chain("alice", MCP_AUD, AGENT, sid="s1", team="sre")
    carol = STS.chain("carol", MCP_AUD, AGENT)
    bob = KC.person("bob", APPROVE_AUD, acr="1")
    alice_person = KC.person("alice", APPROVE_AUD)
    args = {"note_id": "note-42", "text": "Restart the ingest job"}

    # Propose: a call without an approval is refused with a pending proposal.
    r = await w.call(alice, ADD, args, "t1")
    assert err(r) == "approval_missing"
    aid = r["structuredContent"]["approval_id"]
    assert contract.first_error("audit/tool/refusal.schema.json", r["structuredContent"]) is None
    assert err(await w.call(alice, ADD, args, "t1")) == "approval_missing"
    assert (await w.call(alice, ADD, args, "t1"))["structuredContent"]["approval_id"] == aid  # same proposal

    # Not approved yet.
    assert err(await w.call(alice, ADD, {**args, "approval_id": aid}, "t1")) == "approval_pending"

    # The route: read, then refusals in order, then approve.
    status, rec = await w.http("GET", aid, bob)
    assert status == 200 and rec["arguments"] == args and contract.first_error("audit/approval/record.schema.json", rec) is None
    phash = rec["parameters_hash"]
    assert (await w.http("POST", aid, None, {"parameters_hash": phash, "target_version": "7"}))[0] == 401
    assert (await w.http("POST", aid, STS.chain("bob", APPROVE_AUD, AGENT), {"parameters_hash": phash, "target_version": "7"}))[0] == 401
    assert (await w.http("POST", aid, bob, {"parameters_hash": phash}))[1]["error"] == "approval_request"
    assert (await w.http("POST", "nope-nope-nope-nope-nope", bob, {"parameters_hash": phash}))[0] == 404
    assert (await w.http("POST", aid, alice_person, {"parameters_hash": phash, "target_version": "7"})) == (403, {"error": "approval_self", "message": "You proposed this call: someone else must approve it."})
    assert (await w.http("POST", aid, bob, {"parameters_hash": "sha256:" + "0" * 64, "target_version": "7"}))[1]["error"] == "approval_parameters"
    assert (await w.http("POST", aid, bob, {"parameters_hash": phash, "target_version": "6"}))[1]["error"] == "approval_version"
    status, rec = await w.http("POST", aid, bob, {"parameters_hash": phash, "target_version": "7"})
    assert status == 200 and rec["approver"] == {"user.id": "bob", "acr": "1"} and rec["expires_at"] == rec["approved_at"] + 300
    assert contract.first_error("audit/approval/record.schema.json", rec) is None
    assert (await w.http("POST", aid, bob, {"parameters_hash": phash, "target_version": "7"}))[1]["error"] == "approval_decided"

    # Apply-time refusals.
    assert err(await w.call(carol, ADD, {**args, "approval_id": aid}, "t1")) == "approval_caller"
    assert err(await w.call(alice, ADD, {**args, "text": "other", "approval_id": aid}, "t1")) == "approval_parameters"
    assert err(await w.call(alice, ADD, {**args, "approval_id": "unknown-unknown-unknown"}, "t1")) == "approval_unknown"

    # Applied once; the same task and parameters replay without the approval.
    r = await w.call(alice, ADD, {**args, "approval_id": aid}, "t1")
    assert r["isError"] is False and w.applied == 1 and w.notes["note-42"]["version"] == 8
    assert (await w.call(alice, ADD, {**args, "approval_id": aid}, "t1")) == r and w.applied == 1
    assert (await w.call(alice, ADD, args, "t1")) == r and w.applied == 1
    # Reused under a new task: refused.
    assert err(await w.call(alice, ADD, {**args, "approval_id": aid}, "t2")) == "approval_used"
    status, rec = await w.http("GET", aid, bob)
    assert "used_at" in rec and contract.first_error("audit/approval/record.schema.json", rec) is None

    # Expired.
    r = await w.call(alice, ADD, {**args, "text": "x"}, "t3")
    a2 = r["structuredContent"]["approval_id"]
    _, rec = await w.http("GET", a2, bob)
    await w.http("POST", a2, bob, {"parameters_hash": rec["parameters_hash"], "target_version": "8"})
    clock[0] += 300
    assert err(await w.call(alice, ADD, {**args, "text": "x", "approval_id": a2}, "t3")) == "approval_expired"

    # A newer version after approval.
    r = await w.call(alice, ADD, {**args, "text": "y"}, "t4")
    a3 = r["structuredContent"]["approval_id"]
    _, rec = await w.http("POST", a3, bob, {"parameters_hash": (await w.http("GET", a3, bob))[1]["parameters_hash"], "target_version": "8"})
    w.notes["note-42"]["version"] = 9
    assert err(await w.call(alice, ADD, {**args, "text": "y", "approval_id": a3}, "t4")) == "approval_version"

    # Read-only: no key, no approval.
    assert (await w.call(alice, LIST, {}, "t5"))["isError"] is False
    # Not destructive: no approval; without a task ID nothing is deduplicated.
    before = w.applied
    await w.call(alice, APPEND, {"text": "a"}, None)
    await w.call(alice, APPEND, {"text": "a"}, None)
    assert w.applied == before + 2
    await w.call(alice, APPEND, {"text": "a"}, "t6")
    await w.call(alice, APPEND, {"text": "a"}, "t6")
    assert w.applied == before + 3
    # A failure stores no key: a retry applies afresh.
    assert (await w.call(alice, APPEND, {"text": "boom"}, "t7"))["isError"] is True
    # Two identical calls at once: one applies, the other is in progress.
    w.slow = 0.2
    r1, r2 = await asyncio.gather(w.call(alice, APPEND, {"text": "c"}, "t8"), w.call(alice, APPEND, {"text": "c"}, "t8"))
    assert sorted([err(r1) or "ok", err(r2) or "ok"]) == ["idempotency_in_progress", "ok"]
    w.slow = 0.0
    assert err(await w.call(alice, APPEND, {"text": "c"}, "t8")) is None

    # Every call left one record, valid, never with arguments.
    outcomes = [r["tool.call.outcome"] for r in w.audit.records]
    assert {"completed", "replayed", "refused", "failed"} <= set(outcomes)
    for rec in w.audit.records:
        assert contract.first_error("audit/tool/record.schema.json", rec) is None, rec
        assert "Restart" not in json.dumps(rec)
        assert set(rec["trace_id"]) != {"0"} and set(rec["span_id"]) != {"0"}  # the call's own span
    reasons = {r.get("refusal.reason") for r in w.audit.records}
    assert {"approval_missing", "approval_pending", "approval_caller", "approval_parameters", "approval_unknown",
            "approval_used", "approval_expired", "approval_version", "idempotency_in_progress"} <= reasons
    return w
