import json

import httpx
import pytest

from agentic_sdk import context
from agentic_sdk.identity import KEYCLOAK, IssuerTrust, JwksCache, KeysUnavailable, StaticKeys, Verifier
from agentic_sdk.identity.asgi import InboundAuth

from issuer import Issuer

AUD = "https://gateway.agentic.internal/a2a/reference-agent"


class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


def jwks_server(issuer: Issuer, calls: list, fail=lambda: False):
    def handler(request):
        calls.append(request.url.path)
        if fail():
            return httpx.Response(503)
        return httpx.Response(200, json=issuer.jwks())
    return httpx.AsyncClient(transport=httpx.MockTransport(handler))


@pytest.mark.anyio
async def test_jwks_cache_bounds():
    iss, calls, clock, down = Issuer("https://kc"), [], Clock(), [False]
    client = jwks_server(iss, calls, lambda: down[0])
    cache = JwksCache("https://kc/jwks", lambda: client, clock=clock)
    assert await cache.key("k1") is not None and len(calls) == 1
    assert await cache.key("k1") is not None and len(calls) == 1          # cached
    assert await cache.key("nope") is None and len(calls) == 2            # unknown kid: one refetch
    assert await cache.key("nope2") is None and len(calls) == 2           # not again within 30 s
    clock.t += 31
    assert await cache.key("nope3") is None and len(calls) == 3
    clock.t += 300                                                        # past max age: refetch
    assert await cache.key("k1") is not None and len(calls) == 4
    down[0] = True
    clock.t += 301                                                        # stale, fetch fails: last good served
    assert await cache.key("k1") is not None and len(calls) == 5
    assert await cache.key("k1") is not None and len(calls) == 5          # failed attempt not repeated at once
    clock.t += 900 - 301 + 1                                              # past 15 min after last success
    with pytest.raises(KeysUnavailable):
        await cache.key("k1")


@pytest.mark.anyio
async def test_keys_unavailable_before_any_fetch():
    client = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(500)))
    with pytest.raises(KeysUnavailable):
        await JwksCache("https://kc/jwks", lambda: client).key("k1")


async def call(app, headers: list[tuple[bytes, bytes]], path="/"):
    sent = []

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(m):
        sent.append(m)

    await app({"type": "http", "path": path, "method": "POST", "headers": headers}, receive, send)
    start = next(m for m in sent if m["type"] == "http.response.start")
    return start["status"], dict(start["headers"])


@pytest.mark.anyio
async def test_inbound_auth():
    iss = Issuer("https://kc")
    seen = []

    async def app(scope, receive, send):
        inv = context.current()
        if inv is not None:
            seen.append((inv.principal.user_id, inv.task_id, scope["user"].display_name))
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    v = Verifier([IssuerTrust("https://kc", KEYCLOAK, StaticKeys(iss.jwks()), AUD)])
    wrapped = InboundAuth(app, v)
    status, h = await call(wrapped, [])
    assert status == 401 and h[b"www-authenticate"] == b"Bearer"
    status, h = await call(wrapped, [(b"authorization", b"Bearer junk")])
    assert status == 401 and h[b"www-authenticate"] == b'Bearer error="invalid_token"'
    tok = iss.person("u1", AUD).encode()
    status, _ = await call(wrapped, [(b"authorization", b"Bearer " + tok), (b"agentic-task-id", b"t-1")])
    assert status == 200 and seen[-1] == ("u1", "t-1", "u1")
    status, _ = await call(wrapped, [(b"authorization", b"Bearer " + iss.person("u1", AUD + "/x").encode())])
    assert status == 401
    status, _ = await call(wrapped, [], path="/healthz")
    assert status == 200 and context.current() is None


@pytest.mark.anyio
async def test_inbound_auth_503_without_keys():
    client = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(500)))
    v = Verifier([IssuerTrust("https://kc", KEYCLOAK, JwksCache("https://kc/jwks", lambda: client), AUD)])
    status, _ = await call(InboundAuth(None, v), [(b"authorization", b"Bearer " + Issuer("https://kc").person("u", AUD).encode())])
    assert status == 503


@pytest.mark.anyio
async def test_inbound_auth_continues_the_callers_trace():
    """The request's W3C traceparent is the parent of the work done for it,
    so a workload's spans, and the trace context it sends on, join the
    caller's trace (Conformance, Telemetry: inbound traceparent continues)."""
    from opentelemetry import trace

    iss = Issuer("https://kc")
    seen = []

    async def app(scope, receive, send):
        seen.append(trace.get_current_span().get_span_context())
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    v = Verifier([IssuerTrust("https://kc", KEYCLOAK, StaticKeys(iss.jwks()), AUD)])
    wrapped = InboundAuth(app, v)
    tok = b"Bearer " + iss.person("u1", AUD).encode()
    trace_id, span_id = "4bf92f3577b34da6a3ce929d0e0e4736", "00f067aa0ba902b7"
    status, _ = await call(wrapped, [(b"authorization", tok),
                                     (b"traceparent", f"00-{trace_id}-{span_id}-01".encode())])
    assert status == 200
    assert format(seen[-1].trace_id, "032x") == trace_id and format(seen[-1].span_id, "016x") == span_id
    assert seen[-1].is_remote
    # Without one, the work starts its own trace; nothing leaks between requests.
    status, _ = await call(wrapped, [(b"authorization", tok)])
    assert status == 200 and not seen[-1].is_valid
    assert not trace.get_current_span().get_span_context().is_valid
