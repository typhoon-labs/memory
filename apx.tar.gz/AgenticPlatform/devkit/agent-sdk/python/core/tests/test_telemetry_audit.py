import io
import json

from opentelemetry import trace
from opentelemetry.sdk._logs.export import LogRecordExportResult
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from agentic_sdk import context, contract, headers, telemetry
from agentic_sdk.audit import AuditEmitter, tool_record
from agentic_sdk.identity.verifier import Principal

JWT = "eyJhbGciOiJFUzI1NiJ9.eyJzdWIiOiJ4In0.c2lnbmF0dXJl"
PAT = "glpat-" + "a1B2c3D4e5F6g7H8i9J0k"


def test_redact_masks_the_platform_patterns():
    s = f"marker-1 {PAT} and {JWT} Bearer abcdefghijk AKIAABCDEFGHIJKLMNOP"
    out = telemetry.redact({"a": s, "b": [s], "n": 3})
    assert PAT not in out["a"] and JWT not in out["a"] and "abcdefghijk" not in out["a"] and "AKIA" not in out["a"]
    assert "marker-1" in out["a"] and out["b"][0] == out["a"] and out["n"] == 3


def test_spans_are_stamped_and_redacted():
    mem = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(telemetry.InvocationSpanProcessor())
    provider.add_span_processor(SimpleSpanProcessor(telemetry.RedactingSpanExporter(mem)))
    tracer = provider.get_tracer("t")
    p = Principal("chain", "https://sts", user_id="alice", session_id="s1", actor_sub="c/ns/agent", actor_chain=("c/ns/agent",))
    with context.use(context.Invocation(task=headers.TaskHeaders("task-9"), principal=p)):
        with tracer.start_as_current_span("execute_tool") as span:
            span.set_attribute("gen_ai.tool.call.result", f"marker-2 {PAT}")
            span.add_event("e", {"x": JWT})
    s = mem.get_finished_spans()[0]
    assert s.attributes["task.id"] == "task-9" and s.attributes["user.id"] == "alice" and s.attributes["actor.sub"] == "c/ns/agent"
    assert s.attributes["gen_ai.tool.call.result"] == "marker-2 ****" and s.events[0].attributes["x"] == "****"


def record():
    p = Principal("chain", "https://sts", user_id="alice", user_team="sre", actor_sub="c/ns/agent",
                  actor_chain=("c/ns/agent",), token_jti="j" * 22, client_id="c/ns/agent")
    with trace.get_tracer("t").start_as_current_span("x"):
        return tool_record(tool="add_note", outcome="completed", parameters_hash="sha256:" + "0" * 64,
                           principal_attributes=p.attributes(), task_attributes={"task.id": "t1"}, destructive=True)


def test_tool_record_validates():
    rec = record()
    assert contract.first_error("audit/tool/record.schema.json", rec) is None


class Exporter:
    def __init__(self, ok):
        self.ok, self.batches = ok, []

    def export(self, batch):
        self.batches.append(batch)
        return LogRecordExportResult.SUCCESS if self.ok else LogRecordExportResult.FAILURE


def test_emitter_exports_or_writes_the_line_and_pauses():
    rec = record()
    ok = Exporter(True)
    AuditEmitter("reference-mcp", ok).emit(rec)
    lr = ok.batches[0][0]
    assert lr.instrumentation_scope.name == "audit" and lr.log_record.severity_number.value == 9
    assert lr.log_record.body is None and dict(lr.log_record.attributes)["event.name"] == "tool.call"
    assert format(lr.log_record.trace_id, "032x") == rec["trace_id"]
    assert lr.resource.attributes["service.name"] == "reference-mcp"

    out, clock = io.StringIO(), [0.0]
    bad = Exporter(False)
    em = AuditEmitter("reference-mcp", bad, stream=out, clock=lambda: clock[0])
    em.emit(rec); em.emit(rec)
    assert len(bad.batches) == 1 and em.diverted == 1  # paused after the failure
    lines = [json.loads(x) for x in out.getvalue().splitlines()]
    assert len(lines) == 2 and all(contract.first_error("audit/tool/record.schema.json", x) is None for x in lines)
    clock[0] += 11
    em.emit(rec)
    assert len(bad.batches) == 2


def test_emitter_flush_waits_for_a_record_being_sent():
    """T31: the shutdown's flush lets a record still being sent finish, and
    flushes the exporter; every emitter is registered for telemetry.flush."""
    import threading
    import time

    class Slow(Exporter):
        def __init__(self):
            super().__init__(True)
            self.sending, self.flushed = threading.Event(), 0

        def export(self, batch):
            self.sending.set()
            time.sleep(0.5)
            return super().export(batch)

        def force_flush(self, timeout_millis=30000):
            self.flushed += 1
            return True

    slow = Slow()
    em = AuditEmitter("reference-mcp", slow)
    assert em in telemetry._FLUSHABLE
    sender = threading.Thread(target=em.emit, args=(record(),))
    sender.start()
    slow.sending.wait(5)
    assert em.force_flush(50) is False and slow.flushed == 0  # still sending: not flushed in time
    assert em.force_flush(5000) is True and slow.flushed == 1 and len(slow.batches) == 1
    sender.join(5)
    assert AuditEmitter("x").force_flush(10) is True  # no exporter: nothing to flush
    assert AuditEmitter("x", Exporter(True)).force_flush(10) is True  # an exporter with no flush of its own


def test_flush_reaches_every_registered_provider_within_its_bound(monkeypatch):
    import weakref

    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    # Only this test's registrations: other tests' emitters may still live.
    monkeypatch.setattr(telemetry, "_FLUSHABLE", weakref.WeakSet())
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(exporter, schedule_delay_millis=60000))
    telemetry.flushes(provider)
    provider.get_tracer("t").start_span("waiting in the batch").end()
    assert exporter.get_finished_spans() == ()
    assert telemetry.flush(5) is True
    assert [s.name for s in exporter.get_finished_spans()] == ["waiting in the batch"]

    class Stuck:
        def force_flush(self, timeout_millis=30000):
            return False

    stuck = telemetry.flushes(Stuck())
    assert telemetry.flush(1) is False
    del stuck


def test_emitter_never_raises():
    class Boom:
        def export(self, batch):
            raise RuntimeError("down")
    out = io.StringIO()
    AuditEmitter("x", Boom(), stream=out).emit(record())
    assert json.loads(out.getvalue())["event.name"] == "tool.call"


def test_a_task_span_ending_after_a_limit_stop_gets_the_span_surface():
    from agentic_sdk.limits import Caps, LimitExceeded, TaskLimits

    mem = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(telemetry.InvocationSpanProcessor())
    provider.add_span_processor(SimpleSpanProcessor(mem))
    tracer = provider.get_tracer("t")
    limits = TaskLimits(Caps(model_calls=0 + 1), "t1")
    with context.use(context.Invocation(task=headers.TaskHeaders("t1"), limits=limits)):
        with tracer.start_as_current_span("invoke_agent a", attributes={"gen_ai.operation.name": "invoke_agent"}):
            with tracer.start_as_current_span("generate_content m", attributes={"gen_ai.operation.name": "generate_content"}):
                limits.before_model_call()
            try:
                limits.before_model_call()
            except LimitExceeded:
                pass
        with tracer.start_as_current_span("invoke_agent b", attributes={"gen_ai.operation.name": "invoke_agent"}):
            pass
    spans = {s.name: s for s in mem.get_finished_spans()}
    assert spans["invoke_agent a"].attributes["error.type"] == "limit_exceeded"
    assert spans["invoke_agent a"].status.status_code.name == "ERROR"
    assert "error.type" not in spans["generate_content m"].attributes
