"""A test issuer: an ES256 key, its JWK set, and tokens signed with it."""

import base64
import json
import secrets
import time

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature


def b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


class Issuer:
    def __init__(self, iss: str, kid: str = "k1"):
        self.iss, self.kid = iss, kid
        self.key = ec.generate_private_key(ec.SECP256R1())

    def jwks(self) -> dict:
        n = self.key.public_key().public_numbers()
        return {"keys": [{"kty": "EC", "crv": "P-256", "kid": self.kid, "alg": "ES256", "use": "sig",
                          "x": b64(n.x.to_bytes(32, "big")), "y": b64(n.y.to_bytes(32, "big"))}]}

    def token(self, typ: str = "at+jwt", **claims) -> str:
        now = int(time.time())
        body = {"iss": self.iss, "iat": now, "exp": now + 300, "jti": secrets.token_urlsafe(16), **claims}
        head = b64(json.dumps({"alg": "ES256", "kid": self.kid, "typ": typ}).encode())
        payload = b64(json.dumps(body).encode())
        r, s = decode_dss_signature(self.key.sign(f"{head}.{payload}".encode(), ec.ECDSA(hashes.SHA256())))
        return f"{head}.{payload}.{b64(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}"

    def person(self, sub: str, aud: str, **claims) -> str:
        return self.token(**{"sub": sub, "aud": aud, "client_id": "agentctl", "sid": "s-" + sub, "team": "sre", **claims})

    def chain(self, sub: str, aud: str, actor: str, **claims) -> str:
        return self.token(sub=sub, aud=aud, client_id=actor, act={"sub": actor}, **claims)
