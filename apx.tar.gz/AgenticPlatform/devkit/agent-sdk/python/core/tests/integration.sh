#!/bin/sh
# Runs the core's tests with its integration tests on this machine: builds
# the delegation STS from its checkout (DELEGATION_STS_DIR, by default the
# workspace sibling) and the fake model server from ci-components'
# (FAKE_MODEL_DIR), makes sure the floci alias the STS signs through exists
# (it is never moved here), and runs pytest. Needs Go, openssl, the AWS CLI
# and floci (AWS_ENDPOINT_URL, default http://floci:4566). Postgres tests run
# when AGENTIC_TEST_DATABASE_URL is set. Further arguments go to pytest.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
python=$(cd "$here/../.." && pwd)
workspace=$(cd "$python/../../.." && pwd)
sts=${DELEGATION_STS_DIR:-$workspace/infra/delegation-sts}
fake=${FAKE_MODEL_DIR:-$workspace/devkit/ci-components/conformance/fixtures/fake-model}
bin=$(mktemp -d)
trap 'rm -rf "$bin"' EXIT
export AWS_ENDPOINT_URL="${AWS_ENDPOINT_URL:-http://floci:4566}" AWS_REGION="${AWS_REGION:-us-east-1}"
export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-test}" AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-test}"
(cd "$sts" && go build -o "$bin/delegation-sts" ./cmd/delegation-sts)
(cd "$fake" && go build -o "$bin/fake-model" .)
ALIAS_PREFIX="${STS_SIGNING_ALIAS:-alias/interop/sts-signing}" "$sts/interop/rotation/floci-kms.sh" init
cd "$python"
DELEGATION_STS_BIN="$bin/delegation-sts" FAKE_MODEL_BIN="$bin/fake-model" uv run --locked pytest "$@"
