"""The core against a delegation STS built from source and the fake model
server: the exchange, the chain token's verification, the cache under
concurrent people, a refusal, and a model call that passes its token cap."""

import asyncio
import json

import httpx
import pytest

from agentic_sdk import context, headers
from agentic_sdk.clients import DelegatedAuth
from agentic_sdk.delegation import ExchangeRefused
from agentic_sdk.identity import CHAIN, IssuerTrust, JwksCache, Verifier
from agentic_sdk.limits import Caps, LimitExceeded, TaskLimits, tokens_of
from agentic_sdk.runtime import Runtime

from fake_model import fake_model  # noqa: F401
from sts_harness import AGENT, MCP_RESOURCE, StsHarness, sts  # noqa: F401


@pytest.fixture
def runtime(sts: StsHarness, tmp_path, fake_model) -> Runtime:  # noqa: F811
    actor = tmp_path / "actor-token"
    actor.write_text(sts.actor_token())
    return Runtime(environ={
        "AGENTIC_STS_TOKEN_ENDPOINT": sts.token_endpoint, "AGENTIC_ACTOR_TOKEN_FILE": str(actor),
        "AGENTIC_CA_FILE": sts.ca_file, "AGENTIC_GATEWAY_URL": fake_model,
        "AGENTIC_RESOURCE_BASE": "https://workloads-gateway.agentic.internal",
    }, workload_file=str(tmp_path / "none"))


def chain_verifier(sts: StsHarness, runtime: Runtime) -> Verifier:
    return Verifier([IssuerTrust(sts.issuer, CHAIN, JwksCache(sts.issuer + "/jwks", lambda: runtime.http), MCP_RESOURCE)])


@pytest.mark.anyio
async def test_exchange_and_verify_the_chain_token(sts, runtime):  # noqa: F811
    alice = sts.person("alice", sid="s-alice", team="sre")
    with context.use(context.Invocation(task=headers.TaskHeaders("it-task-1"), token=alice)):
        tok = await runtime.token_for("mcp/reference-mcp")
        assert await runtime.token_for("mcp/reference-mcp") == tok
    p = await chain_verifier(sts, runtime).verify(tok)
    assert (p.user_id, p.user_team, p.session_id, p.actor_sub, p.actor_chain) == ("alice", "sre", "s-alice", AGENT, (AGENT,))
    issued = [r for r in sts.audit_records() if r.get("event.name") == "sts.token.issued" and r.get("task.id") == "it-task-1"]
    assert len(issued) == 1 and issued[0]["token.aud"] == MCP_RESOURCE


@pytest.mark.anyio
async def test_people_never_share_tokens_under_concurrency(sts, runtime):  # noqa: F811
    people = {f"p{i}": sts.person(f"p{i}") for i in range(16)}
    verifier = chain_verifier(sts, runtime)

    async def one(name: str, n: int):
        with context.use(context.Invocation(task=headers.TaskHeaders(f"it-{name}-{n}"), token=people[name])):
            await asyncio.sleep(0.001 * (n % 3))
            tok = await runtime.token_for("mcp/reference-mcp")
        return name, (await verifier.verify(tok)).user_id

    before = runtime.exchanger.exchanges
    results = await asyncio.gather(*(one(name, n) for n in range(5) for name in people))
    assert all(name == sub for name, sub in results)
    assert runtime.exchanger.exchanges - before == len(people)


@pytest.mark.anyio
async def test_refusals_carry_the_sts_reason(sts, runtime):  # noqa: F811
    with context.use(context.Invocation(task=headers.TaskHeaders("it-refused"), token=sts.person("bob"))):
        with pytest.raises(ExchangeRefused) as e:
            await runtime.exchanger.token(sts.person("bob"), "https://workloads-gateway.agentic.internal/mcp/other-mcp")
    assert (e.value.error, e.value.reason) == ("invalid_target", "resource_not_allowed")
    sts.inactive.add("carol")
    with pytest.raises(ExchangeRefused) as e:
        await runtime.exchanger.token(sts.person("carol"), MCP_RESOURCE)
    assert e.value.reason == "subject_inactive"


@pytest.mark.anyio
async def test_model_route_call_and_token_cap(sts, runtime, fake_model):  # noqa: F811
    limits = TaskLimits(Caps(tokens=50), "it-model")
    inv = context.Invocation(task=headers.TaskHeaders("it-model"), token=sts.person("dana"), limits=limits)
    with context.use(inv):
        async with httpx.AsyncClient(auth=DelegatedAuth(runtime, "v1"), trust_env=False) as c:
            limits.before_model_call()
            r = await c.post(f"{fake_model}/v1/chat/completions", json={
                "model": "fast-default", "messages": [{"role": "user", "content": "[[fake-model tokens=80]] go"}]})
            assert r.status_code == 200
            with pytest.raises(LimitExceeded) as e:
                limits.after_model_response(tokens_of(r.json()["usage"]))
    assert (e.value.limit, e.value.cap) == ("tokens", 50) and e.value.used > 50
    issued = [x for x in sts.audit_records() if x.get("task.id") == "it-model"]
    assert issued and issued[0]["token.aud"] == "https://workloads-gateway.agentic.internal/v1"
