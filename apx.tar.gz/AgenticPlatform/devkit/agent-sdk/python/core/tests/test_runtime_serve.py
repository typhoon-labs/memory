import asyncio
import json
import time

import pytest

from agentic_sdk import context, telemetry
from agentic_sdk.approvals import ApprovalRoute
from agentic_sdk.limits import Caps, ConfigError
from agentic_sdk.runtime import Runtime, parse_trust
from agentic_sdk.serve import InFlight, Prefix, Probes, workload_app
from agentic_sdk.store import MemoryStore
from agentic_sdk.store_postgres import PostgresStore

from spec_files import SPEC
from issuer import Issuer

KC = {"issuer": "https://kc/realms/agentic", "profile": "keycloak", "jwks_uri": "http://kc/certs", "audience": "https://gateway.x/a2a/a"}
STS = {"issuer": "https://sts", "profile": "chain", "jwks_uri": "http://sts/jwks", "audience": "https://wg.x/mcp/m"}
ATE = {"issuer": "https://idp.ate-system.svc", "profile": "substrate-actor", "jwks_uri": "http://ate/jwks", "audience": "https://wg.x/substrate"}


def test_trust_parsing():
    assert [e.profile for e in parse_trust(json.dumps([KC, STS]))] == ["keycloak", "chain"]
    for bad in ("", "{}", "[]", json.dumps([{**KC, "extra": 1}]), json.dumps([{**KC, "profile": "nope"}]),
                json.dumps([KC, KC]), json.dumps([{**KC, "audience": ""}]),
                # Only a Substrate issuer takes atespaces.
                json.dumps([{**STS, "atespaces": ["notes"]}])):
        with pytest.raises(ConfigError):
            parse_trust(bad)


ROUTE = {"AGENTIC_SUBSTRATE_ROUTE": "/substrate"}


def test_substrate_actor_tokens_need_their_route_and_atespaces():
    """D30: a substrate-actor entry is accepted only with the atespaces its
    route admits and AGENTIC_SUBSTRATE_ROUTE; each refusal has its twin."""
    ate = {**ATE, "atespaces": ["reference-notes-agent"]}
    rt = Runtime(environ={"AGENTIC_TRUST": json.dumps([STS, ate]), **ROUTE})
    assert [(e.profile, e.atespaces) for e in rt.trust] == [("chain", None), ("substrate-actor", ("reference-notes-agent",))]
    assert rt.substrate_route == "/substrate"
    rt.check()
    # No route: refused, the retired flag notwithstanding.
    for env in ({}, {"AGENTIC_ACCEPT_SUBSTRATE_ACTORS": "true"}):
        with pytest.raises(ConfigError, match="AGENTIC_SUBSTRATE_ROUTE"):
            Runtime(environ={"AGENTIC_TRUST": json.dumps([STS, ate]), **env}).trust
    # No atespaces, none, or not namespace names: refused, never "all".
    for bad in (ATE, {**ATE, "atespaces": []}, {**ATE, "atespaces": "reference-notes-agent"},
                {**ATE, "atespaces": ["Reference_Notes"]}, {**ATE, "atespaces": [""]}):
        with pytest.raises(ConfigError, match="AGENTIC_TRUST"):
            Runtime(environ={"AGENTIC_TRUST": json.dumps([STS, bad]), **ROUTE}).trust
    # A route without a Substrate issuer: refused; with one (above): accepted.
    with pytest.raises(ConfigError, match="names no substrate-actor"):
        Runtime(environ={"AGENTIC_TRUST": json.dumps([STS]), **ROUTE}).trust
    with pytest.raises(ConfigError, match="AGENTIC_TRUST is not"):
        Runtime(environ=ROUTE).check()
    # The route is one lowercase segment outside the SDK's own paths.
    for bad in ("substrate", "/substrate/", "/a/b", "/Substrate", "/mcp", "/approvals", "/healthz", "/"):
        with pytest.raises(ConfigError, match="AGENTIC_SUBSTRATE_ROUTE"):
            Runtime(environ={"AGENTIC_SUBSTRATE_ROUTE": bad}).substrate_route
    assert Runtime(environ={"AGENTIC_SUBSTRATE_ROUTE": "/kagent-route"}).substrate_route == "/kagent-route"


def test_without_a_substrate_issuer_the_verifier_has_no_route():
    rt = Runtime(environ={"AGENTIC_TRUST": json.dumps([KC, STS])})
    assert rt.verifier.routes == () and sorted(rt.verifier._issuers) == sorted([KC["issuer"], STS["issuer"]])


@pytest.mark.anyio
async def test_approval_verifier_takes_people_with_its_own_audience():
    kc = Issuer(KC["issuer"])
    rt = Runtime(environ={"AGENTIC_TRUST": json.dumps([KC, STS]), "AGENTIC_APPROVAL_AUDIENCE": "https://gateway.x/mcp/m"})
    v = rt.approval_verifier
    trust = list(v._issuers.values())
    assert [(t.issuer, t.audience) for t in trust] == [(KC["issuer"], "https://gateway.x/mcp/m")]
    with pytest.raises(ConfigError):
        Runtime(environ={"AGENTIC_TRUST": json.dumps([STS]), "AGENTIC_APPROVAL_AUDIENCE": "x"}).approval_verifier
    with pytest.raises(ConfigError):
        Runtime(environ={"AGENTIC_TRUST": json.dumps([KC])}).approval_verifier


def test_settings(tmp_path):
    w = tmp_path / "workload.yaml"
    w.write_text((SPEC / "schemas/examples/reference-agent.workload.json").read_text())
    assert Runtime(environ={"AGENTIC_WORKLOAD_NAME": "other-agent"}, workload_file=str(w)).workload_name == "other-agent"
    with pytest.raises(ConfigError):
        Runtime(environ={"AGENTIC_WORKLOAD_NAME": "Bad_Name"}).workload_name
    rt = Runtime(environ={"AGENTIC_GATEWAY_URL": "http://gw:18080/", "AGENTIC_RESOURCE_BASE": "https://wg.agentic.internal",
                          "AGENTIC_LIMIT_TOKENS": "500", "AGENTIC_LISTEN": ":9000"}, workload_file=str(w))
    assert rt.url("mcp/reference-mcp") == "http://gw:18080/mcp/reference-mcp"
    assert rt.resource("v1") == "https://wg.agentic.internal/v1"
    assert rt.caps() == Caps(10, 20, 500, 120) and rt.name == "reference-agent" and rt.listen == ("0.0.0.0", 9000)
    assert rt.workload_name == "reference-agent"
    rt.check()
    assert Runtime(environ={"AGENTIC_GATEWAY_URL": "http://gw"}).resource("v1") == "http://gw/v1"
    for env in ({"AGENTIC_TOKEN_LEEWAY_SECONDS": "61"}, {"AGENTIC_APPROVAL_TTL_SECONDS": "901"}, {"AGENTIC_LISTEN": "nope"}):
        with pytest.raises(ConfigError):
            Runtime(environ=env, workload_file=str(tmp_path / "none")).check()
    with pytest.raises(ConfigError):
        Runtime(environ={}, workload_file=str(tmp_path / "none")).caps()


def test_stores_make_no_connection_at_start():
    assert isinstance(Runtime(environ={}).store, MemoryStore)
    store = Runtime(environ={"AGENTIC_DATABASE_URL": "postgresql://u:p@127.0.0.1:1/none"}).store
    assert isinstance(store, PostgresStore) and store._pool is None


async def asgi(app, path, method="GET", headers=(), lifespan=False):
    sent, msgs = [], [{"type": "lifespan.startup"}, {"type": "lifespan.shutdown"}] if lifespan else [
        {"type": "http.request", "body": b"", "more_body": False}]

    async def receive():
        return msgs.pop(0)

    async def send(m):
        sent.append(m)

    scope = {"type": "lifespan"} if lifespan else {"type": "http", "path": path, "method": method, "headers": list(headers)}
    await app(scope, receive, send)
    return sent


async def ok(scope, receive, send):
    if scope["type"] == "lifespan":
        while (await receive())["type"] != "lifespan.shutdown":
            pass
        return
    await send({"type": "http.response.start", "status": 200, "headers": [(b"x-inner", b"1")]})
    await send({"type": "http.response.body", "body": context.require().principal.user_id.encode()})


@pytest.mark.anyio
async def test_workload_app():
    from agentic_sdk.identity import KEYCLOAK, IssuerTrust, StaticKeys, Verifier

    kc = Issuer("https://kc")
    v = Verifier([IssuerTrust("https://kc", KEYCLOAK, StaticKeys(kc.jwks()), "https://gw/a2a/a")])
    route_v = Verifier([IssuerTrust("https://kc", KEYCLOAK, StaticKeys(kc.jwks()), "https://gw/mcp/m")])
    app = workload_app(ok, v, approvals=ApprovalRoute(MemoryStore(), route_v, name="m"), a2a_name="a")
    assert (await asgi(app, "/healthz"))[0]["status"] == 200
    assert (await asgi(app, "/readyz"))[0]["status"] == 200
    assert (await asgi(app, "/"))[0]["status"] == 401
    sent = await asgi(app, "/", headers=[(b"authorization", b"Bearer " + kc.person("u1", "https://gw/a2a/a").encode())])
    assert sent[0]["status"] == 200 and sent[1]["body"] == b"u1"
    # The approval route checks its own audience: an agent-route token is refused there.
    assert (await asgi(app, "/approvals/m/x", headers=[(b"authorization", b"Bearer " + kc.person("u1", "https://gw/a2a/a").encode())]))[0]["status"] == 401
    sent = await asgi(app, "/approvals/m/xxxxxxxxxxxxxxxxxxxxxx", headers=[(b"authorization", b"Bearer " + kc.person("u1", "https://gw/mcp/m").encode())])
    assert sent[0]["status"] == 404
    # The A2A paths: /a2a/a as the gateway forwards it, / for direct callers; the card public on both.
    seen_paths = []

    async def where(scope, receive, send):
        seen_paths.append(scope["path"])
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    a2a = workload_app(where, v, a2a_name="a")
    assert (await asgi(a2a, "/.well-known/agent-card.json"))[0]["status"] == 200
    assert (await asgi(a2a, "/a2a/a/.well-known/agent-card.json"))[0]["status"] == 200
    assert (await asgi(a2a, "/a2a/a/"))[0]["status"] == 401
    tok = b"Bearer " + kc.person("u1", "https://gw/a2a/a").encode()
    await asgi(a2a, "/", "POST", headers=[(b"authorization", tok)])
    await asgi(a2a, "/a2a/a/", "POST", headers=[(b"authorization", tok)])
    await asgi(a2a, "/a2a/a", "POST", headers=[(b"authorization", tok)])
    assert seen_paths == ["/a2a/a/.well-known/agent-card.json", "/a2a/a/.well-known/agent-card.json", "/a2a/a", "/a2a/a", "/a2a/a"]
    await asgi(app, "", lifespan=True)
    assert (await asgi(app, "/readyz"))[0]["status"] == 503


@pytest.mark.anyio
async def test_prefix_routes():
    async def other(scope, receive, send):
        await send({"type": "http.response.start", "status": 204, "headers": []})
    app = Prefix("/a/", other, ok)
    assert (await asgi(app, "/a/b"))[0]["status"] == 204


@pytest.mark.anyio
async def test_shutdown_drains_then_shuts_the_app_down_then_flushes(monkeypatch):
    """T31: at the lifespan's shutdown, a task still in flight ends first,
    then the app's own shutdown runs, then the telemetry is flushed, before
    the server hears that the shutdown is complete."""
    order = []
    monkeypatch.setattr(telemetry, "flush", lambda timeout: order.append(("flush", timeout)) or True)
    flight = InFlight()

    async def app(scope, receive, send):
        assert (await receive())["type"] == "lifespan.startup"
        await send({"type": "lifespan.startup.complete"})
        assert (await receive())["type"] == "lifespan.shutdown"
        order.append("app shutdown")
        await send({"type": "lifespan.shutdown.complete"})

    async def task():
        with flight.track():
            await asyncio.sleep(0.3)
            order.append("task ended")

    probes = Probes(app, in_flight=flight, drain_seconds=5, flush_seconds=2)
    running = asyncio.create_task(task())
    await asyncio.sleep(0)
    assert len(flight) == 1
    sent = await asgi(probes, "", lifespan=True)
    assert order == ["task ended", "app shutdown", ("flush", 2)]
    assert [m["type"] for m in sent] == ["lifespan.startup.complete", "lifespan.shutdown.complete"]
    assert running.done() and not running.cancelled() and len(flight) == 0
    assert (await asgi(probes, "/readyz"))[0]["status"] == 503


@pytest.mark.anyio
async def test_shutdown_cancels_what_outlasts_the_drain_and_still_exports_its_span():
    """T31: a task still running when the drain period ends is cancelled, so
    its span ends, and the flush exports it, though the batch processor's
    own export is a minute away. The drain period counts from the shutdown's
    start, and an app that ends its lifespan without answering is flushed too."""
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(exporter, schedule_delay_millis=60000))
    telemetry.flushes(provider)
    flight = InFlight()

    async def stuck():
        with flight.track(), provider.get_tracer("t").start_as_current_span("invoke_agent stuck"):
            await asyncio.sleep(60)

    running = asyncio.create_task(stuck())
    await asyncio.sleep(0)
    probes = Probes(ok, in_flight=flight, drain_seconds=0.5, flush_seconds=5)
    probes.begin_shutdown()  # as the server stops taking requests
    assert (await asgi(probes, "/readyz"))[0]["status"] == 503
    await asyncio.sleep(0.3)
    started = time.monotonic()
    await asgi(probes, "", lifespan=True)  # ok answers no shutdown.complete
    assert time.monotonic() - started < 0.5 + 1.5  # what was left of the drain, then the unwind
    assert running.cancelled()
    (span,) = exporter.get_finished_spans()
    assert span.name == "invoke_agent stuck" and span.end_time is not None
