import asyncio
import json
import urllib.parse

import httpx
import pytest

from agentic_sdk import context, delegation, headers
from agentic_sdk.delegation import ActorTokenFile, ExchangeRefused, Exchanger
from agentic_sdk.identity.jose import unverified_claims

from issuer import Issuer

STS = "https://sts/token"
MCP = "https://workloads-gateway.agentic.internal/mcp/reference-mcp"
MODEL = "https://workloads-gateway.agentic.internal/v1"
KC = Issuer("https://kc")
STS_ISSUER = Issuer("https://sts")


class FakeSTS:
    def __init__(self, delay=0.0, ttl=300):
        self.requests, self.delay, self.ttl = [], delay, ttl

    async def handler(self, request: httpx.Request) -> httpx.Response:
        form = dict(urllib.parse.parse_qsl(request.content.decode()))
        self.requests.append((form, dict(request.headers)))
        await asyncio.sleep(self.delay)
        if form.get("grant_type") != delegation.GRANT_TYPE or form.get("actor_token_type") != delegation.ACTOR_TOKEN_TYPE:
            return httpx.Response(400, json={"error": "invalid_request", "reason": "request_malformed"})
        if "refuse" in form["resource"]:
            return httpx.Response(400, json={"error": "invalid_target", "reason": "resource_not_allowed"})
        sub = unverified_claims(form["subject_token"])["sub"]
        actor = unverified_claims(form["actor_token"])["sub"]
        tok = STS_ISSUER.chain(sub, form["resource"], actor, exp=int(self.now()) + self.ttl)
        return httpx.Response(200, json={"access_token": tok, "issued_token_type": "urn:ietf:params:oauth:token-type:access_token",
                                         "token_type": "Bearer", "expires_in": self.ttl})

    now = staticmethod(__import__("time").time)


def make(sts: FakeSTS, actor=lambda: KC.token(sub="system:serviceaccount:ref:agent"), **kw) -> Exchanger:
    client = httpx.AsyncClient(transport=httpx.MockTransport(sts.handler))
    return Exchanger(STS, actor, lambda: client, **kw)


@pytest.mark.anyio
async def test_exchange_and_cache():
    sts = FakeSTS()
    ex = make(sts)
    alice = KC.person("alice", "https://gateway.agentic.internal/a2a/reference-agent")
    t1 = await ex.token(alice, MCP)
    assert unverified_claims(t1)["sub"] == "alice" and unverified_claims(t1)["aud"] == MCP
    assert await ex.token(alice, MCP) == t1 and ex.exchanges == 1
    await ex.token(alice, MODEL)
    assert ex.exchanges == 2
    form = sts.requests[0][0]
    assert form["subject_token"] == alice and form["resource"] == MCP and "audience" not in form
    assert form["subject_token_type"] == delegation.SUBJECT_TOKEN_TYPE


@pytest.mark.anyio
async def test_refusal_carries_the_reason():
    ex = make(FakeSTS())
    with pytest.raises(ExchangeRefused) as e:
        await ex.token(KC.person("a", "x"), "https://x/refuse")
    assert (e.value.status, e.value.error, e.value.reason) == (400, "invalid_target", "resource_not_allowed")


@pytest.mark.anyio
async def test_reexchange_before_expiry():
    sts = FakeSTS(ttl=100)
    clock = [__import__("time").time()]
    ex = make(sts, clock=lambda: clock[0])
    s = KC.person("a", "x")
    await ex.token(s, MCP)
    clock[0] += 60
    await ex.token(s, MCP)
    assert ex.exchanges == 1
    clock[0] += 11  # within 30 s of exp
    await ex.token(s, MCP)
    assert ex.exchanges == 2


@pytest.mark.anyio
async def test_never_past_the_subject():
    sts = FakeSTS(ttl=300)
    ex = make(sts)
    s = KC.person("a", "x", exp=int(__import__("time").time()) + 20)  # expires in 20 s: nothing cached
    await ex.token(s, MCP)
    await ex.token(s, MCP)
    assert ex.exchanges == 2


@pytest.mark.anyio
async def test_rotated_actor_token_keeps_the_cache(tmp_path):
    f = tmp_path / "token"
    f.write_text(KC.token(sub="system:serviceaccount:ref:agent"))
    ex = make(FakeSTS(), actor=ActorTokenFile(str(f)))
    s = KC.person("a", "x")
    await ex.token(s, MCP)
    f.write_text(KC.token(sub="system:serviceaccount:ref:agent") + "\n")
    import os
    os.utime(f, (1, 1))
    await ex.token(s, MCP)
    assert ex.exchanges == 1


@pytest.mark.anyio
async def test_missing_actor_token_fails_only_the_exchange(tmp_path):
    ex = make(FakeSTS(), actor=ActorTokenFile(str(tmp_path / "absent")))
    with pytest.raises(delegation.ExchangeFailed):
        await ex.token(KC.person("a", "x"), MCP)


@pytest.mark.anyio
async def test_cache_isolation_under_concurrent_callers():
    """Many people, several targets, all at once, through the invocation
    context: each call gets a token for its own person and target only, and
    one exchange per (person, target) however many callers ask at once."""
    sts = FakeSTS(delay=0.02)
    ex = make(sts)
    people = [f"user-{i}" for i in range(40)]
    subjects = {p: KC.person(p, "https://gateway.agentic.internal/a2a/reference-agent") for p in people}
    targets = [MCP, MODEL, "https://workloads-gateway.agentic.internal/a2a/other-agent"]

    async def one(person: str, target: str, n: int):
        inv = context.Invocation(task=headers.TaskHeaders(f"{person}-{n}"), token=subjects[person])
        with context.use(inv):
            await asyncio.sleep(0.001 * (n % 5))
            tok = await delegation.token_for(ex, target)
        c = unverified_claims(tok)
        return person, target, c["sub"], c["aud"]

    results = await asyncio.gather(*(one(p, t, n) for n in range(4) for p in people for t in targets))
    assert len(results) == 480
    assert all(sub == person and aud == target for person, target, sub, aud in results)
    assert ex.exchanges == len(people) * len(targets)
    tasks_sent = {h.get("agentic-task-id") for _, h in sts.requests}
    assert None not in tasks_sent


@pytest.mark.anyio
async def test_leader_cancelled_waiters_still_get_a_token():
    sts = FakeSTS(delay=0.05)
    ex = make(sts)
    s = KC.person("a", "x")
    leader = asyncio.create_task(ex.token(s, MCP))
    await asyncio.sleep(0.01)
    waiter = asyncio.create_task(ex.token(s, MCP))
    await asyncio.sleep(0.01)
    leader.cancel()
    tok = await waiter
    assert unverified_claims(tok)["sub"] == "a"
