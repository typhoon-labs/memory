import asyncio
import json

import pytest

from agentic_sdk import contract
from agentic_sdk.limits import Caps, ConfigError, LimitExceeded, TaskLimits, environment_caps, load_caps, tokens_of

from spec_files import SPEC


def workload(tmp_path, example: str) -> str:
    p = tmp_path / "workload.yaml"
    p.write_text(json.dumps(json.loads((SPEC / "schemas/examples" / example).read_text())))  # JSON is YAML
    return str(p)


def test_caps_from_the_workload_file(tmp_path):
    assert load_caps(workload(tmp_path, "reference-agent.workload.json"), {}) == Caps(10, 20, 100000, 120)
    assert load_caps(workload(tmp_path, "reference-mcp.workload.json"), {}) == Caps(wall_time_seconds=30)


def test_environment_lowers_never_raises():
    declared = Caps(10, 20, 100000, 120)
    env = {"AGENTIC_LIMIT_MODEL_CALLS": "4", "AGENTIC_LIMIT_TOOL_CALLS": "50", "AGENTIC_LIMIT_TOKENS": "", "AGENTIC_LIMIT_WALL_TIME_SECONDS": "20"}
    assert environment_caps(declared, env) == Caps(4, 20, 100000, 20)
    assert environment_caps(Caps(wall_time_seconds=30), {"AGENTIC_LIMIT_TOKENS": "500"}) == Caps(tokens=500, wall_time_seconds=30)
    assert environment_caps(declared, {"AGENTIC_LIMIT_TOOL_CALLS": "0"}).tool_calls == 0


@pytest.mark.parametrize("env", [{"AGENTIC_LIMIT_MODEL_CALLS": "0"}, {"AGENTIC_LIMIT_TOKENS": "1e3"},
                                 {"AGENTIC_LIMIT_WALL_TIME_SECONDS": "-1"}, {"AGENTIC_LIMIT_TOKENS": " 5"}])
def test_invalid_environment_stops_start(env):
    with pytest.raises(ConfigError):
        environment_caps(Caps(10, 20, 100000, 120), env)


def test_invalid_or_missing_workload_file_stops_start(tmp_path):
    with pytest.raises(ConfigError):
        load_caps(str(tmp_path / "absent.yaml"), {})
    bad = tmp_path / "w.yaml"
    bad.write_text("name: x-agent\nkind: agent\nruntime: container\nowner: t\nsupport: experimental\n")
    with pytest.raises(ConfigError, match="limits"):
        load_caps(str(bad), {})


def valid_error(e: LimitExceeded):
    assert contract.first_error("limits/error.schema.json", e.error()) is None
    return e.error()


def test_model_calls_and_tokens():
    t = TaskLimits(Caps(model_calls=2, tokens=100), "t1")
    t.before_model_call(); t.after_model_response(40)
    t.before_model_call(); t.after_model_response(40)
    with pytest.raises(LimitExceeded) as e:
        t.before_model_call()
    assert valid_error(e.value).items() >= {"limit": "model_calls", "cap": 2, "used": 2, "task_id": "t1"}.items()
    with pytest.raises(LimitExceeded) as again:
        t.before_tool_call()
    assert again.value is e.value  # a stopped task starts nothing more

    t = TaskLimits(Caps(tokens=100))
    t.before_model_call()
    with pytest.raises(LimitExceeded) as e:
        t.after_model_response(101)
    assert (e.value.limit, e.value.cap, e.value.used) == ("tokens", 100, 101)

    t = TaskLimits(Caps(tokens=100))
    t.before_model_call(); t.after_model_response(100)  # reached, not passed: acted on
    with pytest.raises(LimitExceeded) as e:
        t.before_model_call()
    assert (e.value.limit, e.value.used) == ("tokens", 100)


def test_tool_calls_zero_allows_none():
    t = TaskLimits(Caps(tool_calls=0))
    with pytest.raises(LimitExceeded) as e:
        t.before_tool_call()
    assert valid_error(e.value)["used"] == 0


@pytest.mark.anyio
async def test_wall_time_cancels_the_call_in_flight():
    t = TaskLimits(Caps(wall_time_seconds=1))
    cancelled = []

    async def slow():
        try:
            await asyncio.sleep(5)
        except asyncio.CancelledError:
            cancelled.append(True)
            raise

    with pytest.raises(LimitExceeded) as e:
        await t.bounded(slow())
    assert cancelled and valid_error(e.value)["limit"] == "wall_time_seconds" and e.value.used >= 1


def test_surfaces():
    e = LimitExceeded("tokens", 10, 12, "t")
    r = e.mcp_result()
    assert r["isError"] is True and r["structuredContent"]["error"] == "limit_exceeded" and r["content"][0]["type"] == "text"
    assert e.span_attributes() == {"error.type": "limit_exceeded"}


def test_tokens_of():
    assert tokens_of({"total_tokens": 7, "prompt_tokens": 1}) == 7
    assert tokens_of({"input_tokens": 3, "output_tokens": 4}) == 7
    assert tokens_of({"prompt_token_count": 3, "candidates_token_count": 2}) == 5
    assert tokens_of(None) == 0
