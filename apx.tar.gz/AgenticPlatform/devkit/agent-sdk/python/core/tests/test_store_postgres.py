"""The same flows on Postgres, when AGENTIC_TEST_DATABASE_URL names one
(a throwaway database: tables are created, never dropped)."""

import asyncio
import os

import pytest

from approvals_flow import run_flows

DSN = os.environ.get("AGENTIC_TEST_DATABASE_URL")
pytestmark = pytest.mark.skipif(not DSN, reason="AGENTIC_TEST_DATABASE_URL not set")


@pytest.mark.anyio
async def test_flows_on_postgres():
    from agentic_sdk.store_postgres import PostgresStore

    store = await PostgresStore.connect(DSN)
    try:
        async with (await store.ready()).acquire() as c:
            await c.execute("truncate agentic_idempotency, agentic_approvals")
        await run_flows(store)
        assert await store.purge(1) == 0  # nothing is ever purged before 24 hours
    finally:
        await store.close()


@pytest.mark.anyio
async def test_one_key_reserved_once_under_concurrency():
    from agentic_sdk.store_postgres import PostgresStore

    store = await PostgresStore.connect(DSN, max_size=10)
    try:
        states = await asyncio.gather(*(store.reserve_key("race-key") for _ in range(20)))
        assert sorted(s.state for s in states).count("new") == 1
        await store.release_key("race-key")
    finally:
        await store.close()


@pytest.mark.anyio
async def test_calls_above_the_pool_size_through_acquire():
    """Three times as many concurrent guarded calls as the pool has
    connections, each apply() working through store.acquire(): all complete,
    since inside a transaction acquire() is the transaction's connection."""
    from agentic_sdk import context, headers
    from agentic_sdk.approvals import ToolGuard, ToolPolicy
    from agentic_sdk.audit import AuditEmitter
    from agentic_sdk.identity.verifier import Principal
    from agentic_sdk.store_postgres import PostgresStore

    store = await PostgresStore.connect(DSN, max_size=3, acquire_timeout=5)
    guard = ToolGuard(store, AuditEmitter("t", None, stream=__import__("io").StringIO()))
    policy = ToolPolicy.from_annotations("append_log", {"readOnlyHint": False, "destructiveHint": False})
    try:
        async with store.acquire() as c:
            await c.execute("create table if not exists it_log (task text primary key, n int)")
            await c.execute("truncate it_log")

        async def one(i):
            async def apply(tx):
                async with store.acquire() as c:
                    assert c is tx.connection
                    await c.execute("select pg_sleep(0.05)")
                    await c.execute("insert into it_log values ($1, $2)", f"t{i}", i)
                return {"isError": False, "content": [{"type": "text", "text": "ok"}]}
            p = Principal("chain", "https://sts", user_id=f"u{i}", actor_sub="c/n/a", actor_chain=("c/n/a",))
            with context.use(context.Invocation(task=headers.TaskHeaders(f"t{i}"), principal=p)):
                return await guard.call(policy, {"text": str(i)}, apply)

        results = await asyncio.wait_for(asyncio.gather(*(one(i) for i in range(9))), 30)
        assert all(r["isError"] is False for r in results)
        async with store.acquire() as c:
            assert await c.fetchval("select count(*) from it_log") == 9
    finally:
        await store.close()


@pytest.mark.anyio
async def test_a_busy_pool_fails_the_call_instead_of_hanging():
    from agentic_sdk.store_postgres import PostgresStore, StoreBusy

    store = await PostgresStore.connect(DSN, max_size=1, acquire_timeout=0.5)
    try:
        held = await (await store.ready()).acquire()
        with pytest.raises(StoreBusy):
            await store.approval("anything")
        await (await store.ready()).release(held)
        assert await store.approval("anything") is None
    finally:
        await store.close()


class DelayProxy:
    """A TCP proxy to the test database that can hold the database's
    answers back, as the contract stage's does (ci-components'
    contract/database.go)."""

    def __init__(self, host: str, port: int):
        self.host, self.port, self.delay = host, port, 0.0

    async def start(self) -> int:
        self.server = await asyncio.start_server(self._handle, "127.0.0.1", 0)
        return self.server.sockets[0].getsockname()[1]

    async def _handle(self, reader, writer):
        up_r, up_w = await asyncio.open_connection(self.host, self.port)

        async def pipe(src, dst, slow):
            try:
                while data := await src.read(32768):
                    held = asyncio.get_running_loop().time()
                    # Held while the delay lasts: setting it to 0 lets what
                    # is held through at once, as a database that recovers.
                    while slow and self.delay and asyncio.get_running_loop().time() - held < self.delay:
                        await asyncio.sleep(0.05)
                    dst.write(data)
                    await dst.drain()
            except (ConnectionError, asyncio.CancelledError):
                pass
            finally:
                dst.close()

        await asyncio.gather(pipe(reader, up_w, False), pipe(up_r, writer, True))

    def close(self):
        self.server.close()


@pytest.mark.anyio
async def test_wall_time_on_a_slow_database_answers_the_limit_at_the_cap():
    """The database holds its answers past the wall time: the call answers
    the spec's limit error at the cap, not a tool failure once the cancelled
    transaction has unwound through the slow database, and leaves one
    audit record (spec/limits: the call in flight is cancelled)."""
    import io
    import time
    import urllib.parse

    from agentic_sdk import context, headers
    from agentic_sdk.approvals import ToolGuard, ToolPolicy
    from agentic_sdk.audit import AuditEmitter
    from agentic_sdk.identity.verifier import Principal
    from agentic_sdk.limits import Caps
    from agentic_sdk.store_postgres import PostgresStore

    u = urllib.parse.urlsplit(DSN)
    proxy = DelayProxy(u.hostname, u.port or 5432)
    port = await proxy.start()
    store = await PostgresStore.connect(u._replace(netloc=f"{u.username}:{u.password}@127.0.0.1:{port}").geturl())
    lines = io.StringIO()
    guard = ToolGuard(store, AuditEmitter("t", None, stream=lines), caps=Caps(wall_time_seconds=1))
    policy = ToolPolicy.from_annotations("list_notes", {"readOnlyHint": True})
    p = Principal("chain", "https://sts", user_id="u1", actor_sub="c/n/a", actor_chain=("c/n/a",))

    async def apply(tx):
        await tx.connection.fetchval("select 1")
        return {"isError": False, "content": [{"type": "text", "text": "ok"}]}

    async def call(task):
        with context.use(context.Invocation(task=headers.TaskHeaders(task), principal=p)):
            return await guard.call(policy, {}, apply)

    try:
        assert (await call("t-warm"))["isError"] is False  # the pool's connections open at full speed
        proxy.delay = 3.0
        lines.seek(0)
        lines.truncate()
        t0 = time.monotonic()
        r = await call("t-slow-db")
        took = time.monotonic() - t0
        assert r["isError"] and r.get("structuredContent", {}).get("limit") == "wall_time_seconds", r
        assert took < 2.5, f"the limit's answer took {took:.1f} s at a 1-second cap"
        proxy.delay = 0
        await asyncio.sleep(4)  # the cancelled call unwinds in the background
        records = [line for line in lines.getvalue().splitlines() if "tool.call" in line]
        assert len(records) == 1 and "limit_exceeded" in records[0], records
    finally:
        proxy.delay = 0
        await store.close()
        proxy.close()


def _proxied(port: int) -> str:
    import urllib.parse

    u = urllib.parse.urlsplit(DSN)
    return u._replace(netloc=f"{u.username}:{u.password}@127.0.0.1:{port}").geturl()


def _principal():
    from agentic_sdk.identity.verifier import Principal

    return Principal("chain", "https://sts", user_id="u1", actor_sub="c/n/a", actor_chain=("c/n/a",))


@pytest.mark.anyio
async def test_a_call_stopped_by_its_wall_time_rolls_back():
    """The change a call made before its database slowed is rolled back as
    the stopped call unwinds, and its idempotency key is not completed: the
    same task applies afresh once the database answers again."""
    import io
    import urllib.parse

    from agentic_sdk import context, headers
    from agentic_sdk.approvals import ToolGuard, ToolPolicy
    from agentic_sdk.audit import AuditEmitter
    from agentic_sdk.limits import Caps
    from agentic_sdk.store_postgres import PostgresStore

    u = urllib.parse.urlsplit(DSN)
    proxy = DelayProxy(u.hostname, u.port or 5432)
    store = await PostgresStore.connect(_proxied(await proxy.start()))
    guard = ToolGuard(store, AuditEmitter("t", None, stream=io.StringIO()), caps=Caps(wall_time_seconds=1),
                      unwind_seconds=2)
    policy = ToolPolicy.from_annotations("append_log", {"readOnlyHint": False, "destructiveHint": False})
    applied = []
    task = f"t-rollback-{__import__('uuid').uuid4().hex[:8]}"  # the database outlives a run

    async def apply(tx):
        applied.append(1)
        await tx.connection.execute("insert into it_rollback values ($1)", task)
        if len(applied) == 1:
            proxy.delay = 3.0  # the database slows after the change, before the commit
        await tx.connection.fetchval("select 1")
        return {"isError": False, "content": [{"type": "text", "text": "ok"}]}

    async def call():
        with context.use(context.Invocation(task=headers.TaskHeaders(task), principal=_principal())):
            return await guard.call(policy, {"text": "x"}, apply)

    try:
        async with store.acquire() as c:
            await c.execute("create table if not exists it_rollback (task text)")
        r = await call()
        assert r["isError"] and r["structuredContent"]["limit"] == "wall_time_seconds", r
        proxy.delay = 0
        await asyncio.sleep(5)  # past the unwind's bound
        from agentic_sdk.approvals import _key
        from agentic_sdk.canonical import parameters_hash

        key = _key(_principal(), task, "append_log", parameters_hash({"text": "x"}))
        async with store.acquire() as c:
            assert await c.fetchval("select count(*) from it_rollback where task = $1", task) == 0, \
                "the stopped call's change committed"
            assert await c.fetchval("select state from agentic_idempotency where key = $1", key) != "completed"
        again = await call()
        assert again["isError"] is False and len(applied) == 2, ("not applied afresh", again, len(applied))
        async with store.acquire() as c:
            assert await c.fetchval("select count(*) from it_rollback where task = $1", task) == 1
    finally:
        proxy.delay = 0
        await store.close()
        proxy.close()


@pytest.mark.anyio
async def test_repeated_wall_time_stops_on_a_held_database_leak_no_connection():
    """A database that holds every answer back stops call after call at the
    cap; each stopped call's connection goes back to the pool or is closed
    within the unwind's bound, so the pool serves its full size after."""
    import io
    import time
    import urllib.parse

    from agentic_sdk import context, headers
    from agentic_sdk.approvals import ToolGuard, ToolPolicy
    from agentic_sdk.audit import AuditEmitter
    from agentic_sdk.limits import Caps
    from agentic_sdk.store_postgres import PostgresStore

    u = urllib.parse.urlsplit(DSN)
    proxy = DelayProxy(u.hostname, u.port or 5432)
    store = await PostgresStore.connect(_proxied(await proxy.start()), max_size=2, acquire_timeout=1,
                                        release_timeout=1.5)
    guard = ToolGuard(store, AuditEmitter("t", None, stream=io.StringIO()), caps=Caps(wall_time_seconds=1),
                      unwind_seconds=1.5)
    policy = ToolPolicy.from_annotations("list_notes", {"readOnlyHint": True})

    async def apply(tx):
        await tx.connection.fetchval("select 1")
        return {"isError": False, "content": [{"type": "text", "text": "ok"}]}

    async def call(task):
        with context.use(context.Invocation(task=headers.TaskHeaders(task), principal=_principal())):
            return await guard.call(policy, {}, apply)

    try:
        proxy.delay = 30.0  # held: no answer within any bound here
        for i in range(5):
            t0 = time.monotonic()
            r = await call(f"t-held-{i}")
            assert r["isError"] and r.get("structuredContent", {}).get("limit") == "wall_time_seconds", r
            assert time.monotonic() - t0 < 2.5
        await asyncio.sleep(4)  # every unwind past its bound, the database still held
        assert not guard._unwinding, "a stopped call is still unwinding past its bound"
        proxy.delay = 0
        pool = await store.ready()
        assert pool.get_size() <= 2
        conns = [await pool.acquire(timeout=5) for _ in range(2)]  # the pool's full size, free again
        assert [await c.fetchval("select 1") for c in conns] == [1, 1]
        for c in conns:
            await pool.release(c)
        assert (await call("t-after"))["isError"] is False
    finally:
        proxy.delay = 0
        await store.close()
        proxy.close()
