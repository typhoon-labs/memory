"""spec/vectors/token-profile.json: every vector, run as its README says."""

import pytest

from agentic_sdk.identity import PROFILES, IssuerTrust, StaticKeys, TokenRefused, Verifier

from spec_files import spec_json

DOC = spec_json("vectors/token-profile.json")


def verifier(name: str) -> Verifier:
    cfg = DOC["verifiers"][name]
    return Verifier(
        [IssuerTrust(i["issuer"], PROFILES[i["profile"]], StaticKeys(DOC["jwks"][i["jwks"]]), i["audience"],
                     frozenset(i["atespaces"]) if "atespaces" in i else None)
         for i in cfg["issuers"]],
        leeway=DOC["leeway_seconds"],
        clock=lambda: DOC["now"],
    )


def test_profiles_match_the_vectors():
    for name, spec in DOC["profiles"].items():
        p = PROFILES[name]
        assert sorted(p.typ) == sorted(spec["typ"])
        assert sorted(p.alg) == sorted(spec["alg"])
        assert sorted(p.required_claims) == sorted(spec["required_claims"])
        assert sorted(p.forbidden_claims) == sorted(spec.get("forbidden_claims", []))
        assert p.sub_prefix == spec.get("sub_prefix")
        assert p.max_lifetime_seconds == spec.get("max_lifetime_seconds")


def test_there_are_54_vectors():
    assert len(DOC["vectors"]) == 54


def test_no_vector_is_provisional():
    """D30 settled the kagent-route vectors."""
    assert [v["id"] for v in DOC["vectors"] if "provisional" in v] == []


def test_every_refused_actor_token_has_an_accepted_twin_signed_alike():
    """Each kagent-route refusal of a well-signed actor token is the twin of an
    accepted vector under the same key, so the key never decides it."""
    accepted = {v["header"]["kid"] for v in DOC["vectors"]
                if v["verifier"] == "kagent-route" and v["expect"]["verdict"] == "accept" and v["id"].startswith("actor/")}
    for v in DOC["vectors"]:
        if v["verifier"] == "kagent-route" and v["expect"]["verdict"] == "refuse" and v["id"] != "actor/forged" \
                and v["claims"].get("iss") == "https://idp.ate-system.svc":
            assert v["header"]["kid"] in accepted, v["id"]


@pytest.mark.anyio
@pytest.mark.parametrize("vector", DOC["vectors"], ids=[v["id"] for v in DOC["vectors"]])
async def test_vector(vector):
    v = verifier(vector["verifier"])
    expect = vector["expect"]
    if expect["verdict"] == "accept":
        principal = await v.verify(vector["token"])
        assert principal.attributes() == expect["principal"]
    else:
        with pytest.raises(TokenRefused) as e:
            await v.verify(vector["token"])
        assert e.value.reason == expect["reason"]
