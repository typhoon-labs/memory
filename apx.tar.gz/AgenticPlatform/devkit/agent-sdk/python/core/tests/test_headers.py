import uuid

from agentic_sdk import headers


def test_reads_valid_values_and_drops_the_rest():
    h = headers.read([(b"agentic-task-id", b"task-1"), (b"Agentic-Workflow-Name", b"release-notes-workflow"),
                      (b"agentic-workflow-version", b"1.2.0")])
    assert h == headers.TaskHeaders("task-1", "release-notes-workflow", "1.2.0")
    assert h.attributes() == {"task.id": "task-1", "workflow.name": "release-notes-workflow", "workflow.version": "1.2.0"}


def test_duplicate_or_invalid_counts_as_absent():
    assert headers.read([(b"agentic-task-id", b"a"), (b"agentic-task-id", b"b")]).task_id is None
    assert headers.read({"Agentic-Task-Id": "-starts-with-dash"}).task_id is None
    assert headers.read({"Agentic-Task-Id": "x" * 129}).task_id is None
    assert headers.read({"Agentic-Task-Id": "ok\n"}).task_id is None
    assert headers.read({"Agentic-Task-Id": "tâche"}).task_id is None


def test_new_task_is_a_uuid7():
    h = headers.read({}).started()
    assert uuid.UUID(h.task_id).version == 7 and h.task_id == h.task_id.lower()
    assert headers.read({"Agentic-Task-Id": "keep"}).started().task_id == "keep"


def test_workflow_headers_go_out_only_together():
    assert headers.TaskHeaders("t", "wf", None).outbound() == {"Agentic-Task-Id": "t"}
    assert headers.TaskHeaders("t", "wf", "1").outbound() == {
        "Agentic-Task-Id": "t", "Agentic-Workflow-Name": "wf", "Agentic-Workflow-Version": "1"}
