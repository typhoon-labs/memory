"""D30: an MCP server bound to kagent agents accepts Substrate's actor tokens
on its route on Substrate's listener alone (AGENTIC_SUBSTRATE_ROUTE), for the
listener's audience and an atespace its access file names, and refuses them
everywhere else. Every refusal has its allowed twin."""

import json
import logging
import time

import pytest

from agentic_sdk import context
from agentic_sdk.identity import CHAIN, SUBSTRATE_ACTOR, IssuerTrust, StaticKeys, TokenRefused, Verifier
from agentic_sdk.runtime import Runtime
from agentic_sdk.serve import workload_app

from issuer import Issuer

ATE_ISS = "https://idp.ate-system.svc"
STS_ISS = "https://delegation-sts.agentic.internal"
LISTENER = "https://workloads-gateway.agentic.internal/substrate"
ROUTE_AUD = "https://workloads-gateway.agentic.internal/mcp/reference-mcp"
GRANTED, OTHER = "reference-notes-agent", "kagent-outsider"

ate, sts, kc = Issuer(ATE_ISS, kid="ate-1"), Issuer(STS_ISS, kid="sts-1"), Issuer("https://keycloak.agentic.internal/realms/agentic", kid="kc-1")


def actor(atespace=GRANTED, aud=LISTENER, sub_ns=None, **claims) -> str:
    """A token in Substrate's shape (B4's minted tokens): typ JWT, aud an array."""
    now = int(time.time())
    name = "session-1"
    body = {"sub": f"actor/{sub_ns or atespace}/{name}", "aud": [aud], "nbf": now - 300,
            "actor.ate.dev": {"atespace": atespace, "actorName": name, "actorUID": "u-1"}, **claims}
    return ate.token(typ="JWT", **body)


def runtime() -> Runtime:
    trust = [
        {"issuer": STS_ISS, "profile": "chain", "jwks_uri": "https://wg/sts-jwks", "audience": ROUTE_AUD},
        {"issuer": ATE_ISS, "profile": "substrate-actor", "jwks_uri": "https://wg:9444/openid/v1/jwks",
         "audience": LISTENER, "atespaces": [GRANTED]},
    ]
    rt = Runtime(environ={"AGENTIC_TRUST": json.dumps(trust), "AGENTIC_SUBSTRATE_ROUTE": "/substrate"})
    rt.__dict__["_keys"] = {ATE_ISS: StaticKeys(ate.jwks()), STS_ISS: StaticKeys(sts.jwks())}
    return rt


async def request(app, path, token=None):
    sent = []
    headers = [(b"authorization", b"Bearer " + token.encode())] if token else []

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(m):
        sent.append(m)

    await app({"type": "http", "path": path, "raw_path": path.encode(), "method": "POST", "headers": headers}, receive, send)
    return sent[0]["status"]


@pytest.fixture
def served():
    seen = []

    async def app(scope, receive, send):
        p = context.require().principal
        seen.append((scope["path"], p.kind, p.actor_sub))
        await send({"type": "http.response.start", "status": 200, "headers": []})
        await send({"type": "http.response.body", "body": b""})

    return workload_app(app, runtime().verifier), seen


def reasons(caplog):
    return [r.getMessage().rpartition(": ")[2] for r in caplog.records if r.name == "agentic_sdk.identity"]


@pytest.mark.anyio
async def test_the_granted_atespace_on_its_route(served):
    app, seen = served
    assert await request(app, "/substrate/mcp", actor()) == 200
    # The app sees its own path, and the actor as the caller.
    assert seen == [("/mcp", "actor", f"actor/{GRANTED}/session-1")]


@pytest.mark.anyio
@pytest.mark.parametrize("path", ["/mcp", "/", "/substratex/mcp", "/approvals/reference-mcp/x"])
async def test_an_actor_token_anywhere_else_is_refused(served, caplog, path):
    app, seen = served
    caplog.set_level(logging.INFO, "agentic_sdk.identity")
    assert await request(app, path, actor()) == 401
    assert reasons(caplog) == ["subject_issuer"] and seen == []


@pytest.mark.anyio
async def test_chain_tokens_at_mcp_alone(served, caplog):
    """The twin of the refusal above: the route's chain tokens still pass at
    /mcp; the Substrate route takes actor tokens alone, as the gateway's
    route on Substrate's listener does."""
    app, seen = served
    caplog.set_level(logging.INFO, "agentic_sdk.identity")
    tok = sts.chain("user-1", ROUTE_AUD, "agentic-local/reference-agent/reference-agent")
    assert await request(app, "/mcp", tok) == 200
    assert await request(app, "/substrate/mcp", tok) == 401
    assert [s[:2] for s in seen] == [("/mcp", "chain")] and reasons(caplog) == ["subject_issuer"]


@pytest.mark.anyio
@pytest.mark.parametrize("name, token, reason", [
    ("another atespace", lambda: actor(OTHER), "actor_unknown"),
    ("sub names another atespace", lambda: actor(GRANTED, sub_ns=OTHER), "actor_unknown"),
    ("no actor.ate.dev", lambda: ate.token(typ="JWT", sub=f"actor/{GRANTED}/s", aud=[LISTENER]), "subject_type"),
    ("the route's audience", lambda: actor(aud=ROUTE_AUD), "subject_audience"),
    ("a worker-for-actor token", lambda: ate.token(typ="JWT", sub=f"worker-for-actor/{GRANTED}/s", aud=[LISTENER],
                                                  **{"actor.ate.dev": {"atespace": GRANTED}}), "subject_type"),
    ("typed at+jwt", lambda: ate.token(sub=f"actor/{GRANTED}/s", aud=[LISTENER], **{"actor.ate.dev": {"atespace": GRANTED}}), "subject_type"),
    ("a Keycloak token", lambda: kc.person("u1", LISTENER), "subject_issuer"),
    ("signed by another key under Substrate's kid", lambda: Issuer(ATE_ISS, kid="ate-1").token(
        typ="JWT", sub=f"actor/{GRANTED}/s", aud=[LISTENER], **{"actor.ate.dev": {"atespace": GRANTED}}), "subject_signature"),
])
async def test_refused_on_the_route(served, caplog, name, token, reason):
    app, seen = served
    caplog.set_level(logging.INFO, "agentic_sdk.identity")
    assert await request(app, "/substrate/mcp", token()) == 401, name
    assert reasons(caplog) == [reason] and seen == []
    # Its twin: the granted actor's token on the same route.
    assert await request(app, "/substrate/mcp", actor()) == 200


@pytest.mark.anyio
async def test_nothing_under_the_route_is_public(served):
    app, _ = served
    assert await request(app, "/healthz") == 200
    assert await request(app, "/substrate/healthz") == 401
    assert await request(app, "/substrate/.well-known/agent-card.json") == 401


@pytest.mark.anyio
async def test_add_note_style_tool_still_sees_the_actor():
    """K3's precondition: a tool's guard sees the actor as the caller, with no
    person, so its approval record is still required (the approval route
    takes only people's tokens)."""
    p = await runtime().verifier.routes[0].verifier.verify(actor())
    assert p.caller == {"actor.sub": f"actor/{GRANTED}/session-1"} and p.user_id is None


def test_a_substrate_issuer_needs_atespaces():
    keys = StaticKeys(ate.jwks())
    for none in (None, frozenset(), ()):
        with pytest.raises(ValueError, match="atespaces"):
            IssuerTrust(ATE_ISS, SUBSTRATE_ACTOR, keys, LISTENER, none)
    assert IssuerTrust(ATE_ISS, SUBSTRATE_ACTOR, keys, LISTENER, frozenset({GRANTED})).atespaces == {GRANTED}
    with pytest.raises(ValueError, match="only a Substrate issuer"):
        IssuerTrust(STS_ISS, CHAIN, keys, ROUTE_AUD, frozenset({GRANTED}))


@pytest.mark.anyio
async def test_a_verifier_of_routes_alone_refuses_everything_outside_them():
    inner = Verifier([IssuerTrust(ATE_ISS, SUBSTRATE_ACTOR, StaticKeys(ate.jwks()), LISTENER, frozenset({GRANTED}))])
    from agentic_sdk.identity import Route

    outer = Verifier([], routes=[Route("/substrate", inner)])
    with pytest.raises(TokenRefused) as e:
        await outer.verify(actor())
    assert e.value.reason == "subject_issuer"
    assert (await inner.verify(actor())).actor_sub == f"actor/{GRANTED}/session-1"
    with pytest.raises(ValueError):
        Verifier([])
