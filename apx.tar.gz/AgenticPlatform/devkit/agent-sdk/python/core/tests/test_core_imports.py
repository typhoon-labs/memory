"""The core imports no agent framework (AGENTS.md): every module, imported
in a fresh interpreter, leaves none of them in sys.modules."""

import json
import subprocess
import sys

MODULES = ["agentic_sdk." + m for m in (
    "approvals", "audit", "canonical", "clients", "context", "contract", "delegation", "headers", "identity",
    "identity.asgi", "limits", "runtime", "serve", "step", "store", "telemetry")]
FRAMEWORKS = ("google", "a2a", "mcp", "starlette", "fastapi", "openai", "anthropic", "litellm", "asyncpg")


def test_no_framework_imports():
    code = ("import json, sys\n" + "".join(f"import {m}\n" for m in MODULES)
            + "print(json.dumps(sorted({k.split('.')[0] for k in sys.modules})))")
    loaded = json.loads(subprocess.run([sys.executable, "-c", code], check=True, capture_output=True, text=True).stdout)
    assert [m for m in loaded if m in FRAMEWORKS] == []
