"""Where the tests find spec/, and a loader for its files."""

import json
from pathlib import Path

SPEC = Path(__file__).resolve().parents[3] / "spec"


def spec_json(rel: str):
    return json.loads((SPEC / rel).read_text(encoding="utf-8"))
