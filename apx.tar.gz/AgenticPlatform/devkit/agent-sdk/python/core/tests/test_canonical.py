import json

import pytest

from agentic_sdk.canonical import canonical, parameters_hash

from spec_files import SPEC

DOC = json.loads((SPEC / "audit/tool/parameters-hash.json").read_text(encoding="utf-8"))


@pytest.mark.parametrize("vector", DOC["vectors"], ids=[v["id"] for v in DOC["vectors"]])
def test_vector(vector):
    if "approval_id" not in vector["arguments"]:
        assert canonical(vector["arguments"]) == vector["canonical"]
    assert parameters_hash(vector["arguments"]) == vector["hash"]


def test_nine_vectors():
    assert len(DOC["vectors"]) == 9


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), 2**53, {1: "x"}, object()])
def test_refuses_what_has_no_canonical_form(bad):
    with pytest.raises(ValueError):
        canonical({"v": bad} if not isinstance(bad, dict) else bad)


@pytest.mark.parametrize("x,out", [(1e21, "1e+21"), (1e20, "100000000000000000000"), (1e-6, "0.000001"),
                                   (1e-7, "1e-7"), (-1.5, "-1.5"), (123456789012345680000.0, "123456789012345680000"),
                                   (5e-324, "5e-324"), (1.7976931348623157e308, "1.7976931348623157e+308")])
def test_numbers(x, out):
    assert canonical(x) == out
