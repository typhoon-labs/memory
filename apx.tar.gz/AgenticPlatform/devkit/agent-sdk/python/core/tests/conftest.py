import pytest


@pytest.fixture
def anyio_backend():
    return "asyncio"


def pytest_configure(config):
    # A recording tracer, as telemetry.configure gives a workload, so spans
    # (and the audit records that name them) carry real IDs.
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider

    trace.set_tracer_provider(TracerProvider())
