# Refusals

Every refusal from the delegation STS's token endpoint, as data. The rules behind them live in [Identity: Refusals and audit records](../../../../architecture/design/identity.md#refusals-and-audit-records).

| File | Holds |
| --- | --- |
| `refusals.json` | One entry per case: its stable `reason`, the `error` beside it, the HTTP `status`, the `stage` of the check that refuses it, any required response `headers`, and the case in words. Also `check_order`, the order of the stages |
| `response.schema.json` | The JSON Schema (draft 2020-12) of a refusal's body |

**What a refusal looks like.** An RFC 6749 error response whose JSON body carries `error` and the extra member `reason`. `error` follows RFC 8693, section 2.2.2: `invalid_request` or `invalid_target` for the checks; `temporarily_unavailable` for the two fail-closed cases, which have no stage because they can arise at any point. Tests assert `error` and `reason` together, so a case cannot pass because another check refused first.

**Check order.** The STS runs the stages in `check_order` and returns the first failure. Within a stage the order is not part of the contract, so a test request must break exactly one rule.

**Changes.** A new reason is a minor version of the spec. Renaming or removing a reason, or changing its `error` or `status`, is a major version.
