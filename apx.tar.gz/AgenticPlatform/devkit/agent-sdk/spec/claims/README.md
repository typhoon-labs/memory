# Claims

The token the delegation STS issues, the chain token, as JSON Schemas of its header and claims. The rules are in [Identity](../../../../architecture/design/identity.md): the chain token's header and claims under [The STS policy](../../../../architecture/design/identity.md#the-sts-policy), the RFC 9068 and RFC 8725 rows of [The interoperability profile](../../../../architecture/design/identity.md#the-interoperability-profile), and audiences in [Endpoints and audiences](../../../../architecture/design/identity.md#endpoints-and-audiences).

| File | Holds |
| --- | --- |
| `chain-token-header.schema.json` | The JOSE header: `alg`, `typ` and `kid`, and no header that points at keys |
| `chain-token.schema.json` | The claims: the fixed ones, the nested `act` chain, and the claims a policy may carry. Any other claim fails `additionalProperties`, which is how "nothing else passes" is checked |
| `examples/` | The header and claims of a second-hop token, matching the issuance in `../audit/examples/` |

**Rules a schema cannot state,** which consumers check in code:

- `client_id` equals the outermost `act.sub`, and `nbf` equals `iat`.
- `aud` is exactly the requested `resource`, compared as a string.
- `sub` and every carried claim present in the subject token are copied unchanged; the subject's chain is nested inside the new outermost `act` unchanged.
- `exp` is no later than the subject's `exp`, nor than `iat` plus the policy's `token_ttl_seconds`.
- `jti` is new on every issuance.
- The signature verifies with the key named by `kid` in the STS's JWKS.

**`alg`.** The platform's STS signs ES256 ([Signing keys and JWKS](../../../../architecture/design/identity.md#signing-keys-and-jwks)). The header schema admits the profile's whole allowlist, ES256 and RS256, because every verifier accepts both, and a replacement STS that signs RS256 changes nothing for agents, routes or tools.

**Carried claims.** The schema lists the seven claims the policy schema allows (`idp_sub`, `roles`, `team`, `sid`, `preferred_username`, `acr`, `auth_time`), with the types Keycloak's tokens give them. A policy carries a subset; which subset is the policy's business, not the token's.
