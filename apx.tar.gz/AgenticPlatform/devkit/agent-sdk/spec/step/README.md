# Step

A bounded model step: one model task in a workflow, with fixed limits, declared in the workflow's repository and run by the SDK's step command, which `agentctl step run` starts. The rules are in [Workflows: A bounded model step](../../../../architecture/design/workflows.md#a-bounded-model-step); the limits are [`../limits/`](../limits/README.md)'s.

| File | Holds |
| --- | --- |
| `step.schema.json` | The JSON Schema of a step's definition: model alias, prompt and its version, input and output schemas, tool allowlist, limits, re-prompts and failure path |
| `command.json` | The step command: its name, arguments and environment, how it gets tokens, and its exit statuses with what each writes |
| `failure.schema.json` | The JSON Schema of the object written when a step fails, or is invalid, for a reason other than its limits |
| `examples/`, `invalid/` | Definitions and failure objects that must validate, and ones that must not; `<case>.<schema>.json` names the schema |

## Running a step

`agentic-step run --definition <file> --input <file> --output <file> [--workload <file>]`, as `command.json` says. In order:

1. **Validate, calling nothing.** The command line, the environment (`AGENTIC_GATEWAY_URL`, and `AGENTIC_TOKEN_COMMAND` as a JSON array of strings), the definition against `step.schema.json` with its two schemas compiled as draft 2020-12, the workload file against [`../schemas/workload.schema.json`](../schemas/README.md), and the input against the definition's `input_schema`. The first that fails ends the run with exit status 5 and a `step_invalid` object.
2. **Caps.** Each cap in force is the lowest of the definition's, the workload file's and its environment variable's ([`../limits/runtime.json`](../limits/README.md)). Without `--workload` and without a file at the default path, the definition's and the environment's apply: the definition declares every cap, so a step is never unbounded. The step is a task for limits: every count starts at zero, and wall time runs from here.
3. **The task.** `AGENTIC_TASK_ID` when it is a valid task ID, or a new one ([`../headers/`](../headers/README.md)); every request carries `Agentic-Task-Id`, and the workflow headers when both are set and valid.
4. **Ask the model.** A Chat Completions request to `<AGENTIC_GATEWAY_URL>/v1/chat/completions`, with a token for the scope `models`: the definition's `model`; a system turn, `prompt.system`; a user turn, `prompt.instructions` and then the input as JSON; as tools, each allowlisted tool with its description and input schema from its server's `tools/list`, and `submit_output`, whose parameters are the `output_schema`; and `max_output_tokens` as `max_tokens`.
5. **Act on the answer.**
   - A call of `submit_output`: its arguments are the output.
   - A call of an allowlisted tool: the step calls it at `<AGENTIC_GATEWAY_URL>/mcp/<server>` with a token for the scope `mcp/<server>`, gives the model its result, and asks again (step 4). A result whose `isError` is true goes to the model as it is.
   - A call of any other tool: not started and not counted. The model is told it is not allowed, and asked again.
   - Text: parsed as a JSON object, which is then the output.
6. **Check the output** against `output_schema`. Valid: it is written to the output file, and the command exits 0. Otherwise the model is told what is wrong and asked again, at most `reprompts` times (two by default, never more); then the step fails with `output_invalid`.

**Limits** count as [`../limits/limits.json`](../limits/README.md) says: every request to the model route is a model call, re-prompts included; `tokens` adds each response's total; every allowlisted tool call started is a tool call. A step stopped by its limits writes the limit error to the output file and exits 3, and its span ends with status ERROR and `error.type` `limit_exceeded`.

**Failures.** A step that fails for another reason writes a `step_failed` object with its `reason` and exits by its failure path: 1 for `stop`, 4 for `human`, so the pipeline stops or routes the work to a person.

| `reason` | When |
| --- | --- |
| `output_invalid` | No valid output after the re-prompts |
| `model_error` | The model route answered an error, or an answer that is not a Chat Completions response, after the token retry |
| `tool_error` | An allowlisted tool's server could not be reached, or answered an error that is not a tool result |
| `token_unavailable` | The token command failed or printed no token |

`step_invalid`'s reasons are `usage` (the command line), `definition_invalid`, `input_invalid`, `workload_invalid` and `environment_invalid`.

**Tokens.** The command gets each token by running `AGENTIC_TOKEN_COMMAND` with `--scope` and the route's scope appended, never through a shell. It keeps a token until 30 seconds before its `exp`, asks once more after a 401, and never writes a token to its output, its logs or its result.
