# Schemas

The JSON Schemas of the files workloads and library artifacts carry: `workload.yaml` and `artifact.yaml`; from 0.3.0 also a library's `library.yaml`, the catalog index `catalog.json` and the lock file `.agents/lock.yaml`. The YAML files are written as YAML and validated as the JSON they parse to, by the generation job, in CI and by `agentctl`. The fields come from [Repositories: The developer workflow](../../../../architecture/design/repositories.md#the-developer-workflow) (`workload.yaml`'s required file and lifecycle), [Distribution: Metadata per artifact](../../../../architecture/design/distribution.md#metadata-per-artifact) (`artifact.yaml`), [Repositories: Naming](../../../../architecture/design/repositories.md#naming), and [Conformance: How conformance runs in CI](../../../../architecture/design/conformance.md#how-conformance-runs-in-ci) (the level); from 0.3.0, [Repositories: Libraries and registration](../../../../architecture/design/repositories.md#libraries-and-registration) (`library.yaml`, tiers and prefixes), [Distribution: The distribution design](../../../../architecture/design/distribution.md#the-distribution-design) and [R1 to R7](../../../../architecture/design/distribution.md#running-agentregistry-040-as-a-requirement) (the catalog index), and [Installing into local harnesses](../../../../architecture/design/distribution.md#installing-into-local-harnesses) (the lock file).

| File | Holds |
| --- | --- |
| `workload.schema.json` | `workload.yaml`: name, kind, runtime, owner, support status, an MCP server's tools with their annotations, what it requires, its limits, its evaluation evidence and deprecation, and the conformance level it raises itself to |
| `artifact.schema.json` | `artifact.yaml`: kind, name, version, owner, support status, compatibility, requirements, evaluation, provenance and deprecation. Its `$defs` are the definitions both files share |
| `library.schema.json` | `library.yaml`: a library's owner, its tier and, for a team's library, its name prefix |
| `catalog.schema.json` | `catalog.json`: one environment's catalog index, each entry the `workload.yaml` or `artifact.yaml` of one release with its version, source, digest and route |
| `lock.schema.json` | `.agents/lock.yaml`: each library artifact installed in a repository, by digest, with its canonical copy and each harness's link |
| `common.schema.json` | The definitions the 0.3.0 schemas share, here and in [`../attestations/`](../attestations/README.md): digests, references by digest, times, IDs and levels. It validates nothing itself |
| `examples/`, `invalid/` | Files that must validate, and ones that must not, as JSON; `<case>.<schema>.json` names the schema. The three reference workloads are among the examples |

In a workload's image, `workload.yaml` sits at `/etc/agentic/workload.yaml`, where the SDK reads its limits ([`../limits/runtime.json`](../limits/README.md)).

Access files, which [Development](../../../../architecture/design/development.md#the-shared-sdk-agent-sdk) also gives this directory, come in a later version.

**References between files.** `workload.schema.json` refers to `artifact.schema.json` and to `../limits/declaration.schema.json` by relative `$ref`, and no schema has an `$id`. Load each schema under a hierarchical URI that keeps its path within `spec/`, such as its `file://` URL, so the references resolve. In Python, put every `*.schema.json` in one `referencing.Registry` under its `file://` URL and validate against `{"$ref": <that URL>}`; a scheme Python's `urljoin` does not know, such as `spec:`, leaves relative references unresolved. Both ways were checked with `jsonschema` 4.26.0 and Go's `santhosh-tekuri/jsonschema` v6.0.3. The schemas of 0.3.0 refer to `common.schema.json` and `artifact.schema.json` the same way, and `catalog.schema.json` to `workload.schema.json` and `artifact.schema.json` for each entry's file; they and their examples were checked with both validators, formats asserted, on 2026-11-18.

**What the schema of `workload.yaml` checks.**

| Rule | How |
| --- | --- |
| One name everywhere, lowercase kebab-case, at most 63 characters | `name`; the kind's suffix: `-agent`, `-mcp` or `-workflow`; never `adk` or `kagent` as a word of it |
| Kind and runtime go together | An agent runs in a `container` or on `kagent`; an MCP server in a `container`; a workflow as a `pipeline` |
| An MCP server lists its tools | `tools`, each with `readOnlyHint` stated, and `destructiveHint` too when it is not read-only, so nothing rests on MCP's defaults. Only MCP servers have `tools`; what a workload calls goes in `requires.tools` |
| Limits ([`../limits/`](../limits/README.md)) | An agent in a container, and a workflow for each of its bounded steps, declare all four caps; an MCP server declares at least `wall_time_seconds`; a kagent agent declares none, since kagent's turn limits and the gateway's limits bound it |
| The level ([Conformance](../../../../architecture/design/conformance.md#conformance-levels)) | L1 always; L2 when `requires.permissions.write` is true or a tool has `destructiveHint`; L3 when `long_running` or `resumable` is true. `conformance.level` may raise it, and is refused below it. Consumers take the higher of the two |
| The lifecycle | `supported` needs `evaluation`; `deprecated` and `retired` need `deprecation`, and nothing else has one |

**Choices the design leaves open, fixed here.**

| Field | Choice |
| --- | --- |
| `runtime` | `container`, `kagent` or `pipeline`: where it runs, not its framework |
| Routes in `requires.permissions.routes` | `<gateway>/<route>`, as in the STS policy: `workloads-gateway/mcp/reference-mcp`, `gateway/v1` |
| `requires.tools[].server` | The MCP server's workload name |
| `data_classification` | `public`, `internal`, `confidential` or `restricted` |
| `version` | SemVer without a leading `v`, the version of the release tag |
| `support` | In `artifact.yaml`, Distribution's values: `experimental`, `community`, `supported`, `deprecated`. In `workload.yaml`, the lifecycle's: `experimental`, `supported`, `deprecated`, `retired` |
| `evaluation.dataset_digest` | `sha256:` and 64 hexadecimal digits |
| `provenance` | The repository's HTTPS URL, the full commit SHA and the pipeline's numeric ID |

**What the schemas of 0.3.0 check.**

| File | Rule | How |
| --- | --- | --- |
| `library.yaml` | A tier, and a prefix only where names need one | `tier` is `global` or `team`; a team's library has `prefix`, the global library none. Every artifact in a team's library is named `<prefix>-<rest>`, and its owner is in `access/teams.yaml`: the catalog build checks both |
| `catalog.json` | One entry per release, from its own file | `file` names `workload.yaml` or `artifact.yaml`, and `metadata` holds that file as released, validated by its schema; a retired workload is not in the index |
| `catalog.json` | Owner, support and digest on every entry (R3) | `metadata.owner` and `metadata.support`, and `reference`, by digest: required for every artifact, agent and MCP server. A workflow that is a pipeline may have none |
| `catalog.json` | Agents and MCP servers listed by their routes (D40) | `route` on the developer deployment: `gateway/a2a/…` for an agent, `gateway/mcp/…` for an MCP server; no route for a workflow or an artifact |
| `catalog.json` | Tiers | An artifact's `tier` is `global`, `team` or `project`, a workload's `.agents/` directory; a workload has none |
| `.agents/lock.yaml` | Installed by digest, in one place | `reference` by digest; `path` is `.agents/<kind>s/<name>`; each link a relative path with no `.` or `..` segment, for `claude-code` or `codex` |

Names are unique across a catalog index, and an artifact's `version` equals its entry's: the catalog build checks both, since a JSON Schema cannot.

**Choices the design leaves open, fixed here, from 0.3.0.**

| Field | Choice |
| --- | --- |
| The catalog's signature | The index is signed as a blob, `cosign sign-blob`, with the record key ([D37](../../../../architecture/plan/open-items.md#close-by-decision)); the file holds no signature of its own |
| `catalog.json`'s `timestamp` | When it was built, in [`../attestations/`](../attestations/README.md#the-timestamp)'s form; a publisher takes the newest index whose signature verifies |
| `catalog.json`'s `build` | The building pipeline's `provenance`, as `artifact.yaml` writes one |
| An entry's `source` | The registered project's numeric ID, the release tag, its full commit, and an artifact's directory |
| `.agents/lock.yaml`'s `lockfile_version` | 1. A change an older `agentctl` would misread takes 2 |
| The canonical copy | `.agents/skills/<name>`, `.agents/prompts/<name>`, `.agents/workflows/<name>`, `.agents/plugins/<name>`; Codex reads `.agents/skills` itself, so a skill's link is Claude Code's, `.claude/skills/<name>` |
