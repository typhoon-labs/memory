# Exchange

The token-exchange request an agent sends to the delegation STS, the response it gets, and the metadata it discovers the endpoint from. The rules are the RFC 8693, RFC 8707 and RFC 8414 rows of [Identity: The interoperability profile](../../../../architecture/design/identity.md#the-interoperability-profile), and the endpoints are in [Endpoints and audiences](../../../../architecture/design/identity.md#endpoints-and-audiences).

| File | Holds |
| --- | --- |
| `exchange.json` | `request`: each form parameter, whether it is required, optional or forbidden, its fixed value if it has one, and the `reason` (from `../refusals/refusals.json`) of the refusal when it is missing, wrong or present when forbidden; `max` and `max_refusal` for a parameter that may appear only so often. `response`: the fixed members of a successful response. `metadata`: where the RFC 8414 document lives, relative to the issuer, the members consumers need, and the grant type it must advertise |

**Token types.** The subject token is an access token. The actor token is the workload's credential: for the platform's STS, a projected service-account token, typed `urn:ietf:params:oauth:token-type:jwt` because it is a JWT but not an OAuth access token. The design leaves the actor token's type unnamed; this file fixes it. `requested_token_type` may be left out; when sent, it must name an access token.

**Metadata.** `required` lists the members consumers rely on. RFC 8414 also requires `response_types_supported`, which matters only for an authorization endpoint the STS does not have, so consumers do not depend on it.
