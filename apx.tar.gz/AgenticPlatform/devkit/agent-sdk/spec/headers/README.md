# Headers

The HTTP headers that carry a request's task and workflow, so that the records of every hop name them: the gateways' access and usage records, the STS's audit record and the tools' audit records. The rules are in [Observability: Audit and usage records](../../../../architecture/design/observability.md#audit-and-usage-records) and [Correlation and identity](../../../../architecture/design/observability.md#correlation-and-identity), and in [Gateway: Attribution and cost accounting](../../../../architecture/design/gateway.md#attribution-and-cost-accounting).

| File | Holds |
| --- | --- |
| `headers.json` | One entry per header: its `name` on the wire, the record `attribute` it fills, the `pattern` a value must match, who sets it (`set_by`), how a new value is made (`new_value`), whether a workload sends it on (`propagate`), and what it holds |

**Attribution only, never authorization.** The values come from the caller and nobody verifies them. No component grants, refuses, routes or rate-limits a request on them, and none takes an identity from them: identity comes from the verified token alone. A tool that keys idempotency on the task ID keys it on the verified caller too, as `audit/tool/` describes.

**Names and values.**

- Header names compare case-insensitively, as HTTP's do. HTTP/2 and agentgateway's CEL see them in lowercase: `request.headers["agentic-task-id"]`.
- A value matches its `pattern` whole. The patterns are written for RE2, Python's `re` and ECMAScript alike; in Python use `re.fullmatch`, since `$` also matches before a final newline.
- The patterns bound the length: 128 characters for a task ID, 63 for a workflow's name, 64 for its version. Values are ASCII.

**Receiving.** A header that is missing, sent more than once, or whose value does not match its pattern counts as absent. It is left out of every record, and it never refuses a request. A recorder records a valid value unchanged under its `attribute`, as in the STS's `task.id`.

**Starting a task.** A workload that receives no valid task ID starts a task of its own: it makes a random UUID (version 4 or 7, lowercase, hyphenated) and uses it as the task ID for everything it does for that request. A workflow runner may instead derive the task ID from its pipeline, so that a retried job keeps it and its tools' idempotency holds across the retry. The workflow headers are set only by a workflow runner, which sends both; nobody else makes them up.

**Propagation.** A workload sends the task's values unchanged on every outbound request it makes for the task: to the model route, to MCP servers and other agents, and to the STS's token endpoint, whose `task_header` setting is then `Agentic-Task-Id`. It never forwards a header it counted as absent.

**Not headers.** `session.id` comes from the token's `sid`, and `platform.release.id` from the workload's OTel resource, never from a header.
