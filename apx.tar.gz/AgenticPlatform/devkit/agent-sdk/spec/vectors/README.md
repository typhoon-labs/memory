# Vectors

Test vectors that every language core of the SDK passes, so that each verifies and decides alike. Each `<name>.json` here validates against `<name>.schema.json` beside it.

| File | Holds |
| --- | --- |
| `token-profile.json` | Vectors for the `identity` module, which verifies a workload's inbound token: the verifier's clock and leeway, the `profiles` of the tokens it may accept, the issuers' public keys (`jwks`), named `verifiers`, each issuer with the atespaces it admits where it is Substrate's, and signed tokens, each with the verdict it must get: accepted with a principal, or refused with a reason |
| `token-profile.schema.json` | The JSON Schema of that file |

The rules are the RFC 8725, RFC 9068 and Substrate rows of [Identity: The interoperability profile](../../../../architecture/design/identity.md#the-interoperability-profile), the audiences of [Endpoints and audiences](../../../../architecture/design/identity.md#endpoints-and-audiences), which issuers each gateway deployment accepts in [Gateway: Routes and issuers](../../../../architecture/design/gateway.md#routes-and-issuers), and the `identity` module in [Development](../../../../architecture/design/development.md#the-shared-sdk-agent-sdk). The Identity suite asserts the same refusals ([Conformance](../../../../architecture/design/conformance.md#suites)).

## Running the token-profile vectors

For each vector, set up the verifier its `verifier` names: for each of its `issuers`, trust exactly that `issuer`, with the keys of `jwks[<its jwks>]`, for tokens of `profiles[<its profile>]`, carrying exactly that `audience` and, where it names `atespaces`, an atespace among them. Fix the clock at `now`, allow `leeway_seconds`, hand it `token`, and compare: `accept` with exactly the `principal` given, or `refuse` with exactly the `reason`. `header` and `claims` are the token's own parts, decoded for reading; the token is what counts. The keys' private halves were discarded: a new vector that needs a signature needs a key of its own in `jwks`.

The three verifiers are the routes the reference workloads have: `person-route`, an agent's route on the developer deployment, where people's Keycloak tokens arrive; `workload-route`, an MCP server's route on the hosted-workloads deployment, where chain tokens arrive; and `kagent-route`, the same server's route on that deployment's listener for Substrate's egress, bound to kagent agents (D30), which takes Substrate actor tokens alone, with the listener's audience and an atespace the server's access file names, as the gateway's route there admits nothing else.

**Which route a request came by.** Every route of a workload reaches the same Service, so the workload tells its routes apart by path: the gateway's route on Substrate's listener calls it under a prefix of its own, `/substrate` by default (`/substrate/mcp` for an MCP server), which the platform's route sets and the workload's `AGENTIC_SUBSTRATE_ROUTE` names. Only there does it verify as `kagent-route`, trusting Substrate's issuer and no other, so a chain or person's token is refused there `subject_issuer` (`actor/chain-token-too`); everywhere else Substrate's issuer is not trusted, so an actor token is refused `subject_issuer`, as `chain/substrate-token` and `person/substrate-token` are. The gateway calls each route's path, whatever the caller asked for, and only the gateways reach the workload.

**The checks, in order,** and the reason each refusal gives. The first that fails decides; each vector breaks one rule.

| # | Check | Refused with |
| --- | --- | --- |
| 1 | A token was sent | `request_malformed` |
| 2 | It is a compact JWS whose header and claims are JSON objects | `subject_signature` |
| 3 | Its `iss` is exactly one of the verifier's issuers | `subject_issuer` |
| 4 | Its `alg` is in the profile's `alg`; it has no `crit`; its `kid` names a key of that issuer's set; the signature verifies with that key. Keys come only from the set: a `jwk`, `jku`, `x5u` or `x5c` in the header is never used | `subject_signature` |
| 5 | Its `typ` is one of the profile's, compared case-insensitively | `subject_type` |
| 6 | It carries the profile's `required_claims` (`act` with a `sub`; `sub` a non-empty string; times integers; `actor.ate.dev` an object whose `atespace` is a non-empty string); its `sub` starts with `sub_prefix`, and `exp` − `iat` is at most `max_lifetime_seconds`, where the profile has them | `subject_type` |
| 7 | It has not expired: `now` < `exp` + leeway | `subject_expired` |
| 8 | It is valid already: no `nbf`, or `nbf` ≤ `now` + leeway | `subject_not_yet_valid` |
| 9 | It carries none of the profile's `forbidden_claims`: no `act` in a Keycloak token | `subject_foreign_act` |
| 10 | Its `aud` is one string, or an array of one, equal to the issuer's `audience` exactly | `subject_audience` |
| 11 | Where the issuer names `atespaces`: its `actor.ate.dev` `atespace` is one of them, and its `sub` is `actor/<that atespace>/<name>` | `actor_unknown` |

**Reasons, not responses.** The reasons are `refusals/refusals.json`'s, as the STS gives them for a subject token, so a workload's log and the STS's audit name a failure alike; check 11's is the STS's for an actor its policy does not name, since the atespaces are the route's policy of actors. Their `error` and HTTP status are the STS's answer to an exchange and do not apply here: a workload refuses an inbound token with 401 and `WWW-Authenticate: Bearer`, adding `error="invalid_token"` when a token was sent (RFC 6750), and logs the reason without sending it.

**The principal,** under the audit records' names, so that the tool record takes it as it is ([`../audit/tool/`](../audit/tool/README.md#the-record)):

| Member | Keycloak and chain tokens | Substrate actor tokens |
| --- | --- | --- |
| `user.id`, `user.team`, `user.roles`, `session.id`, `client.id` | `sub`, `team`, `roles`, `sid`, `client_id`, each when present | Absent |
| `token.jti` | `jti` | `jti` |
| `actor.sub`, `actor.chain` | For a chain token, the outermost `act.sub`, and every `act.sub`, newest first; absent for a person's token | `sub`, and `[sub]` |

**Choices the design leaves open, fixed here.** An unparseable token is `subject_signature` and one without `sub` or `exp` is `subject_type`, as at the STS; so is an STS token without `act`, which the STS never issues. A missing `aud` is `subject_audience`. The leeway applies to `exp` as to `nbf`, at most 60 seconds; the STS allows none on a subject's `exp`, since a token it would issue from one would be dead on arrival. The vectors stay off the edges, at 30 seconds within the leeway and 120 beyond it, as the gateway's and the STS's suites do.

**Substrate actor tokens (D30).** The `kagent-route` vectors follow D30: an MCP server bound to kagent agents accepts Substrate's actor tokens for the listener's audience, on its route on that listener alone, from the atespaces its access file names ([Open items](../../../../architecture/plan/open-items.md#close-by-decision)). The listener's audience is every route's there (D18), so the atespace is what holds a token to its route. Three of their reasons stretch the catalogue, for want of one of their own, which would be a new refusal in `refusals.json` that the STS never gives: a `worker-for-actor` token, and a lifetime over 300 seconds, are refused `subject_type`, the nearest case; an atespace the route does not admit is `actor_unknown`, the actor not in the policy. The vectors signed by `ate-2` were added with D30; its private half was discarded too.
