# spec

The platform's contracts, as files that implementations and test suites load directly. The design that sets their rules is in the [architecture](../../../architecture/README.md); each area's README links to the section that holds them.

| Area | Holds | Consumers |
| --- | --- | --- |
| [`refusals/`](refusals/README.md) | The STS's refusal cases: `error`, `reason` and HTTP status of each, and the schema of a refusal's body | The STS, its interoperability suite, the SDK's `delegation` module |
| [`audit/`](audit/README.md) | The audit records and their encoding, as a line on standard output and as an OTel log record: the STS's record; from v0.2.0 the tools' record, their refusals for approvals and idempotency, the parameters hash and its vectors, idempotency by task ID, and the approval record and route | The STS, its interoperability suite, the collector's audit branch, every MCP server built on the SDK, the Approvals and idempotency suites |
| [`claims/`](claims/README.md) | The chain token's header and claims, as JSON Schemas, with an example | The STS, its interoperability suite, every verifier of chain tokens (the SDK's `identity` module, the gateway's checks) |
| [`exchange/`](exchange/README.md) | The token-exchange request and response: parameters, token types, and the refusal when a parameter is wrong; where the metadata lives | The STS, its interoperability suite, the SDK's `delegation` module |
| [`headers/`](headers/README.md) | The task and workflow headers: wire names, the record attributes they fill, their patterns, and how they are set and passed on | The SDK's `telemetry` and `clients` modules, the gateways' records, the STS's `task_header` |
| [`limits/`](limits/README.md) | The caps a workload declares per task, how each is counted, where a running workload reads them and how the environment may lower them, and the error a task stopped by them ends with, on A2A, MCP, a bounded step and its span | The SDK's `limits` module, `workload.yaml`'s schema, the Limits suite |
| [`schemas/`](schemas/README.md) | The JSON Schemas of `workload.yaml` and `artifact.yaml`, with valid and invalid examples; from v0.3.0 also of `library.yaml`, the catalog index `catalog.json` and the lock file `.agents/lock.yaml` | The generation job, `agentctl validate`, `ci-components`' level rule and `library-release`, the charts; `agentctl catalog`, `search`, `show`, `install`, `update` and `remove` |
| [`step/`](step/README.md) | A bounded model step: its definition's schema, the step command's arguments, environment and exit statuses, and the object a failed step writes | The SDK's step command, `agentctl step run`, the workflow template |
| [`vectors/`](vectors/README.md) | Test vectors every language core passes: today the token profile, signed tokens with the verdict and reason or principal each must get | The SDK's `identity` module in every language |
| [`attestations/`](attestations/README.md) | From v0.3.0: the in-toto statements the platform signs about a workload, the conformance attestation and the release record: their predicate types, the statement as a verifier reads it, and each predicate | `infra/conformance`, admission's image verification, `environments`' deploy job, whoever reads a release record |

**Status.** Until the first tag, `spec/v0.1.0`, the tables in [Identity](../../../architecture/design/identity.md#refusals-and-audit-records) are canonical and these files transcribe them. From that tag on, these files are canonical and Identity links here.

**Versions.** Released on `spec/vX.Y.Z` tags, SemVer. An addition is a minor version; a rename, a removal or a tightened rule is a major one. Consumers pin a tag, or a commit until the first tag exists.

| Version | Adds |
| --- | --- |
| 0.1.0 | `refusals/`, `audit/`'s STS record, `claims/` and `exchange/`: the STS's contracts |
| 0.2.0 | `headers/`, `limits/` (with where a running workload reads its caps), `schemas/`, `step/` and `vectors/`, the route bound to kagent agents among them as D30 settled it; in `audit/`, the encoding of every record as an OTel log record, the tools' record with its refusals, parameters hash and idempotency, and the approval record with its approval route. Additions only: no file, field, reason or rule of 0.1.0 is renamed, removed or tightened |
| 0.3.0 | `attestations/`: the conformance attestation's predicate and the release record's, each with a `timestamp` Kyverno reads, and the statement that carries them; in `schemas/`, `library.yaml`, the catalog index and `.agents/lock.yaml`, and `common.schema.json`, the definitions they share. Additions only: no file, field, reason or rule of 0.2.0 is renamed, removed or tightened |

This tree is 0.3.0, not yet tagged; the last release is `spec/v0.2.0`.

**Conventions.**

- **Examples are test vectors.** Beside a schema, `examples/` holds instances that must validate and `invalid/` instances that must not, each named `<case>.<schema>.json` after the schema `<schema>.schema.json` in the directory above. Two directories of 0.1.0 predate the rule: every file in `audit/examples/` is an STS record, and `claims/examples/` pairs `*.header.json` with `chain-token-header.schema.json` and `*.claims.json` with `chain-token.schema.json`. The STS's contract tests read every file in those two as such, so nothing else goes there.
- **JSON, also for YAML files.** `workload.yaml`, `artifact.yaml`, `library.yaml` and `.agents/lock.yaml` are checked as the JSON they parse to, so their examples are JSON too, and every file loads with a standard library.
- **References.** A schema may refer to another by relative `$ref`; none has an `$id`. Load each under a hierarchical URI that keeps its path within `spec/`, such as its `file://` URL ([`schemas/`](schemas/README.md)).
- **Names.** Fields that become OTel attributes keep their dotted names as JSON members: `"user.id"`, never `{"user": {"id": …}}`.
