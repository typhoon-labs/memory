# Attestations

The two in-toto statements the platform signs about a workload, from 0.3.0: the **conformance attestation**, which `infra/conformance` signs for an image digest once its integration stage passes, and the **release record**, which `environments`' deploy job signs for each workload release it applies. The rules are in [Conformance: How conformance runs in CI](../../../../architecture/design/conformance.md#how-conformance-runs-in-ci) (the attestation, threat TM13, where the level comes from) and [The deployed-configuration record](../../../../architecture/design/conformance.md#the-deployed-configuration-record) (the record's groups, its ID on every span, its storage); which keys sign them are [D37](../../../../architecture/plan/open-items.md#close-by-decision) and the conformance key in [the local build plan](../../../../architecture/plan/local-build.md#b6-in-detail).

| File | Holds |
| --- | --- |
| `statement.schema.json` | The JSON Schema of the statement as a verifier reads it from the DSSE envelope: `_type`, `subject`, `predicateType` and `predicate`, the predicate checked against its type's schema. It holds the two predicate types, and nothing else does |
| `conformance.schema.json` | The conformance attestation's predicate |
| `release-record.schema.json` | The release record's predicate |
| `examples/`, `invalid/` | Predicates and statements that must validate, and ones that must not; `<case>.<schema>.json` names the schema |

The shared definitions (digests, references by digest, times, levels) are in [`../schemas/common.schema.json`](../schemas/README.md), and the names, versions and teams in `../schemas/artifact.schema.json`.

## Predicate types

| Statement | `predicateType` | Subject | Signed by |
| --- | --- | --- | --- |
| Conformance attestation | `urn:agentic-platform:attestation:conformance:v1` | The tested image's index digest, the one a pod names | `infra/conformance`, with the conformance key, after the release's own signature and attestations |
| Release record | `urn:agentic-platform:attestation:release-record:v1` | The release's own digests: its image's index, or a kagent agent's packaged definition | The deploy job, with the record key |

Each type has one predicate schema, and a change that would break a reader takes a new type (`:v2`), since Kyverno selects attestations by type. `cosign attest --type <predicateType> --predicate <file>` takes the predicate as written and wraps it in a statement of `_type` `https://in-toto.io/Statement/v0.1`, its subject `name` the image's repository and `digest.sha256` the digest's hexadecimal digits; `cosign sign` writes `https://in-toto.io/Statement/v1`. The statement schema takes both, as B5's bundles in floci carry them (checked 2026-11-18 on `reference-agent`'s `v0.1.0`).

## The timestamp

Both predicates hold one time, `timestamp`, in UTC, RFC 3339 with an uppercase `T` and `Z`, at most to the nanosecond and with no leap second, which Go's `time.Parse` refuses: `2026-11-18T19:42:07Z`. Kyverno keeps one attestation per predicate type, the newest, and with no transparency log it takes the time from the signed statement: from the predicate's `metadata`, `runDetails.metadata` or `creationInfo.created`, then from its top-level members, `finishedOn` and `startedOn` before `timestamp`; with two candidates and no time in either, it refuses both ([B6 desk check](../../../../architecture/research/2026-11-18-b6-desk-check.md#how-it-finds-a-signature)). So neither predicate has a member of any of those names but `timestamp`, and the schemas refuse one, so that the time Kyverno reads is this one.

## The conformance attestation

| Member | Holds |
| --- | --- |
| `timestamp` | When the run finished |
| `workload` | Name, kind, runtime and owner, from `/etc/agentic/workload.yaml` inside the tested image, never from the trigger's inputs |
| `level` | `required`: the level that file implies, raised by its `conformance.level`, as [`../schemas/`](../schemas/README.md) sets. `tested`: the highest level all of whose suites ran |
| `suite_version` | The suites' version: the `ci-components` release whose suites the runner image holds; a runner built before its release writes a SemVer pre-release of it, such as `1.1.0-dev.41`, which sorts below `1.1.0` |
| `suites` | Each suite that ran, by the runner's suite name, with its cases counted as `passed`, `failed` and `skipped` |
| `runner_image` | The runner image, by digest |
| `component` | The component that ran the stage, as GitLab's `spec:component` context gives it: `name`, `sha` and `reference`, what the include names after `@`; and `version` only when that is a released version, since for an include by commit SHA or branch GitLab's `version` is null ([CI/CD YAML syntax](https://docs.gitlab.com/ci/yaml/), checked 2026-11-18) |
| `run` | The environment, the pool namespace the workload was deployed into, and `infra/conformance`'s pipeline |

**Rules the schema states.** Only a passing run is attested: every suite's `failed` is 0. A suite's results are counts alone, without messages or logs, since admission reads the whole statement at every check. No member comes from the trigger's inputs: the project ID it passes is not recorded.

**Rules for admission, which the schema cannot state.** Admission refuses a digest whose `level.tested` is below its `level.required`, or below the level the environment requires; whose `suite_version` is older than the environment's minimum for that level; or whose attestation another key signed. A run that could not test the required level is still attested as it ran, so that the refusal is admission's. The levels compare as strings (`L1` < `L2` < `L3`).

## The release record

| Member | Holds, after Conformance's groups |
| --- | --- |
| `id` | `<environment>/<workload>/<deploy job ID>`: the join key, set by `app-base` on every span of the release as `platform.release.id`. The deploy job knows it before it renders, and a retried job makes a new one |
| `timestamp` | When the release was applied |
| `workload` | Name, owner and the release's version; kind, runtime and project ID when the job knows them |
| `deployment` | Where and who: environment, cluster, namespace, `environments`' commit, pipeline and job, the deployer, and the merge request and its approvers when there is one |
| `images` | Code: every container of the release's pods by digest, sidecars and init containers included |
| `attestations` | Code: what admission verified on the release's own digests, each by its bundle's digest: the signature, SBOMs, provenance and conformance attestation |
| `charts` | Charts: each chart release by name, version and digest, with the SHA-256 of the manifest Helm stored for it (`helm get manifest`) |
| `platform` | Platform: the versions of `agentgateway`, `kagent`, `substrate` and `delegation-sts`, and any others, as `environments`' `versions.yaml` writes them |
| `frameworks` | Frameworks: versions from the workload's lock file, by package name |
| `models` | Models: each alias, its provider model ID or inference profile ARN, region and parameters |
| `artifacts` | Prompts, skills and workflows: kind, name, version and digest, a skill's being its OCI digest |
| `permissions` | Permissions: the access file's SHA-256 always; the STS policy entries' and the rendered RBAC's hashes, the IAM role and the tool allowlist where they apply |
| `evidence` | Evidence: the latest evaluation, and the conformance attestation admission took, by its bundle's digest with its predicate as signed |

Required are the members a record cannot be without in any environment: `id`, `timestamp`, `workload`, `deployment` (but the merge request and approvers), `images`, `charts`, `platform` and the access file's hash. The rest are required where they exist, which the deploy job knows and the schema cannot: a kagent agent has no lock file, and a local release has no IAM role.

## Choices the design leaves open, fixed here

| Choice | Fixed as |
| --- | --- |
| Predicate types | URNs under `urn:agentic-platform:`, like `ci-components`' build type, with no GitLab path; cosign takes them as URIs (`url.ParseRequestURI`, checked 2026-11-18) |
| The time | One top-level `timestamp`, in the form above |
| A failed run | Not attested |
| A build before its release | `suite_version` a SemVer pre-release of the coming release; `component` without `version`, its `sha` and `reference` naming the commit |
| The level | Both levels recorded; admission compares them |
| The record's ID | `<environment>/<workload>/<deploy job ID>`, safe as an `OTEL_RESOURCE_ATTRIBUTES` value and as an S3 key's path |
| Hashes | `sha256:` and 64 lowercase hexadecimal digits, of the bytes as stored: the committed access file, Helm's stored manifest |
