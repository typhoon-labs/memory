# Tool calls

What an MCP server records and answers for each `tools/call`: its audit record, its refusals, the hash that binds a call's parameters, and idempotency by task ID. The rules are in [Security: Approval expiry and revalidation](../../../../../architecture/design/security.md#approval-expiry-and-revalidation) and its [threat model](../../../../../architecture/design/security.md#threat-model-summary) (TM4, TM15), in [Observability: Audit and usage records](../../../../../architecture/design/observability.md#audit-and-usage-records), and in the Approvals, Retries and idempotency suites of [Conformance](../../../../../architecture/design/conformance.md#suites). The approval record itself is in [`../approval/`](../approval/README.md).

| File | Holds |
| --- | --- |
| `record.schema.json` | The JSON Schema of one tool audit record |
| `refusals.json` | Every refusal a tool gives for idempotency and approvals: its `error`, the `check` that gives it, whether the caller may `retry`, and the case in words. Also `check_order` |
| `refusal.schema.json` | The JSON Schema of a refusal's structured content |
| `parameters-hash.json` | How a call's parameters are hashed, and test vectors: arguments, their canonical form and the hash |
| `idempotency.json` | Which tools deduplicate, on which key, for how long, and what a repeated key gets |
| `examples/`, `invalid/` | Records and refusals that must validate, and ones that must not; `<case>.<schema>.json` names the schema |

## The record

**One record per `tools/call` that passes the token check:** completed, replayed, refused or failed, never sampled, written before the result is returned and encoded as [`../encoding.json`](../encoding.json) says. A call the token check refuses is answered 401 before the call is read, and gets no tool record; the gateway's record and the server's log keep it. Records go to the collector's general ports as the workload's own, where the collector stamps them `record.source` `workload`: they reach the SIEM and the audit bucket, never the usage table. A tool's record is only as true as the tool (TM15).

**Who, from the verified token alone,** under the names every other record uses (D17):

| Field | A person's token | A chain token | A Substrate actor token |
| --- | --- | --- | --- |
| `user.id`, `user.team`, `session.id` | `sub`, `team`, `sid` | `sub`, `team`, `sid`: the person the agents act for | Absent |
| `actor.sub` | Absent | The outermost `act.sub` | `sub` |
| `actor.chain` | Absent | Every `act.sub`, newest first | `[sub]` |
| `client.id`, `token.jti` | `client_id`, `jti` | `client_id`, `jti` | `jti` |

`task.id`, `workflow.name` and `workflow.version` come from the headers when they were valid ([`../../headers/`](../../headers/README.md)). Never record the call's arguments or its result: `tool.parameters.hash` binds them without their content.

**Outcomes.** `completed`: the tool ran. `replayed`: a call with the same idempotency key had completed, and its result went back again. `refused`: a check of `refusals.json` refused the call, named in `refusal.reason`. `failed`: the tool ran and failed, its class in `error.type`, which is `limit_exceeded` when the server's own limits stopped it ([`../../limits/`](../../limits/README.md)).

## Checks, in order

1. **The token,** by the SDK's `identity` module: a refusal is 401, before anything below.
2. **Idempotency,** for a tool whose `readOnlyHint` is not true.
3. **Approval,** for a tool that needs one: every tool its annotations make destructive (`readOnlyHint` not true and `destructiveHint` not false, MCP's defaults included), and any other the server requires it of.
4. **Apply.** The change, the idempotency key with its result, and the approval's `used_at` are stored in one transaction, so a crash leaves all of them or none.

Within each check, `refusals.json` lists the refusals in the order the tool checks them, and the first that fails answers.

**A refusal is a result, not a JSON-RPC error:** `isError` is true, `structuredContent` is the refusal object (`refusal.schema.json`), and `content` holds a text item for people, which a model can read. A tool that declares an `outputSchema` still answers a refusal this way: the MCP Python SDK 2.3.0 checks `structuredContent` against it only when `isError` is false, on the server and the client (read 2026-11-17). Suites assert `error`.

## The parameters hash

`sha256:` and the lowercase hex SHA-256 of the canonical JSON (RFC 8785) of the call's `params.arguments`, without its `approval_id` member; `{}` when the call has no arguments. The tool name is not in the hash: the approval record and the idempotency key name the tool beside it.

RFC 8785 sorts object members by their keys' UTF-16 code units, writes non-ASCII characters as themselves, escapes only `"`, `\` and control characters, and writes numbers as ECMAScript does. For arguments whose keys lie within the Basic Multilingual Plane and whose numbers are integers, that is Python's `json.dumps(…, sort_keys=True, separators=(",", ":"), ensure_ascii=False)`; the `utf16-key-order` and `numbers` vectors fail it, and in Python `key=lambda k: k.encode("utf-16-be")` sorts the keys right. Go's `encoding/json` escapes `<`, `>`, `&`, U+2028 and U+2029, which the `escapes` vector catches. Read the vectors' arguments without losing numbers' precision. Integers outside ±(2^53 − 1) are outside I-JSON: a tool takes such values as strings.

## Idempotency by task ID

A tool whose `readOnlyHint` is not true deduplicates its calls on a key of the verified caller, the task and the call: `user.id`, `actor.sub`, `task.id`, `tool.name` and `tool.parameters.hash`, as in its audit record. The task ID alone never keys it: it is the caller's to choose, and attribution only.

- **No task ID, no deduplication.** Each call applies, and no client retries it: the Retries suite's rule that a non-idempotent tool is never retried without a key.
- **Same key, completed:** the tool returns the completed call's result again, changes nothing, uses no approval, and records `replayed`. It keeps the key at least 24 hours.
- **Same key, in progress:** refused `idempotency_in_progress`; the caller may retry after a pause.
- **Same task, other parameters or tool:** another key, so another operation. A task may add two notes; it adds the same note once.
- **A refused call, or a failed one that changed nothing,** stores no key, so a retry is checked afresh.

So the Approvals suite's reused-approval case presents a used approval under a new task ID: under the first call's task ID and parameters it is a replay, which returns the first result and is not a refusal.
