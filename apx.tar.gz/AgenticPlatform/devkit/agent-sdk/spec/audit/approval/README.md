# Approvals

The record that lets a tool apply a call that changes state: proposed by the caller, approved by another person, bound to the call's parameters and to the version of what it changes, used once, within minutes. The tool that executes checks it, whoever calls. The rules are in [Security: Approval expiry and revalidation](../../../../../architecture/design/security.md#approval-expiry-and-revalidation) and [Prompt injection](../../../../../architecture/design/security.md#prompt-injection) (propose, approve, apply), and for kagent agents in [Repositories: kagent agents](../../../../../architecture/design/repositories.md#kagent-agents) (control K3); the Approvals suite is in [Conformance](../../../../../architecture/design/conformance.md#suites).

| File | Holds |
| --- | --- |
| `record.schema.json` | The JSON Schema of one approval record, from proposal to use |
| `route.json` | The approval route a server serves: its paths, the token it takes, its refusals with their HTTP status and order, and an approval's lifetime |
| `approve.schema.json` | The JSON Schema of the route's request body: what the approver read and approves |
| `examples/`, `invalid/` | Records and request bodies that must validate, and ones that must not; `<case>.<schema>.json` names the schema |

The refusals a tool gives for approvals, and the order it checks them in, are in [`../tool/refusals.json`](../tool/README.md); the parameters hash in [`../tool/parameters-hash.json`](../tool/README.md#the-parameters-hash).

**Propose, approve, apply.**

1. **Propose.** A call that needs an approval and names none is refused `approval_missing`, and the refusal's `approval_id` names a pending proposal: the server's record of this caller, tool, parameters hash and target version, new or one it already holds. The server may keep the proposed arguments in it, for the approver to read.
2. **Approve.** Another person approves the proposal through the server's approval route, with their own token: `GET /approvals/{name}/{id}` to read it, then `POST /approvals/{name}/{id}` with the `parameters_hash` and `target_version` they read. The server then sets `approver`, `approved_at` and `expires_at` and answers with the record. The route is below.
3. **Apply.** The caller calls the tool again with the same arguments and `approval_id`, an optional string argument that every tool needing approval declares in its input schema and that the parameters hash leaves out. The tool checks the record, applies the call and sets `used_at` in the same transaction.

**Rules the schema cannot state,** which the tool checks at apply time, in `refusals.json`'s order, and the approving server at approval time where they apply:

- **The caller is the proposer:** the same `user.id` and `actor.sub` as `proposer`, so an approval cannot be spent by someone else (`approval_caller`).
- **The approver is a person other than the proposer:** `approver.user.id` differs from `proposer.user.id`, and the approver's token is their own, from the realm, with no `act`: an agent never approves, whoever it acts for (`approval_self`). For a proposal from a Substrate actor token, which names no person, any person may approve.
- **Assurance:** with `required_acr`, the approver's `acr`, read as an integer, is at least it (`approval_assurance`).
- **Single use:** a record with `used_at` is refused (`approval_used`).
- **Short-lived:** `expires_at` is at most 900 seconds after `approved_at`, and a call at or after `expires_at` is refused (`approval_expired`).
- **Bound to the parameters:** the call's parameters hash equals `parameters_hash` (`approval_parameters`), and the tool is `tool` (`approval_unknown` otherwise).
- **Bound to the version:** when the record names a `target`, that object's current version equals `target.version` (`approval_version`).

Times are seconds since the epoch, compared with the server's clock, without leeway. A presented approval never skips the other checks: the token is checked first, and a call whose idempotency key had completed is a replay, which uses no approval ([`../tool/`](../tool/README.md#idempotency-by-task-id)).

## The approval route

`route.json` holds it. The server serves it beside its MCP endpoint, under its workload name, `{name}`: at the same path directly and through the gateway, where it is a route of its own on the developer deployment, since the MCP route's backend does not pass other paths on.

- **Who.** The approver's own Keycloak token, for one audience: the server's setting `AGENTIC_APPROVAL_AUDIENCE`, by default its route on the developer deployment, `https://gateway.<platform domain>/mcp/<name>`. A chain token or a Substrate actor token is refused with 401 like any token the route does not take, so no agent approves, whoever it acts for.
- **What.** The body names the parameters hash and the target's version the approver read. The server approves only if both still match the proposal and the target's current version, so an approver never approves something other than what they read.
- **Checks, in order:** the token; the body (`approval_request`); the proposal exists (`approval_unknown`); it is not approved already (`approval_decided`); the approver is not the proposer (`approval_self`); the approver's `acr` (`approval_assurance`); the parameters (`approval_parameters`); the version (`approval_version`). The first that fails answers, with the status `route.json` gives and a body of [`../tool/refusal.schema.json`](../tool/README.md)'s shape. `approval_request` and `approval_decided` are the route's alone: a tool never gives them.
- **Lifetime.** `expires_at` is `approved_at` plus the server's approval lifetime: 300 seconds unless the server sets less, never more than 900.
- **Reading.** `GET` answers any person the route's token admits, so an approver reads the proposed arguments where the server keeps them. Proposals hold no secret; a tool that takes secrets as arguments leaves `arguments` out.

