# Audit

The platform's audit records, one per request, never sampled: the delegation STS's, one per token-exchange request, issued or refused; and from v0.2.0 the tools', one per tool call, with the approval records and idempotency rules a tool that changes state follows. The STS's rules, and what each of its fields holds, are in [Identity: Refusals and audit records](../../../../architecture/design/identity.md#refusals-and-audit-records); where the records go is in [Observability: Audit and usage records](../../../../architecture/design/observability.md#audit-and-usage-records).

| File | Holds |
| --- | --- |
| `sts-record.schema.json` | The JSON Schema (draft 2020-12) of one STS record |
| `examples/` | Valid STS records: an issuance at the second hop, a refusal at the resource stage, and a refusal before the actor is known. STS records only: the STS's contract tests validate every file here against `sts-record.schema.json` |
| `encoding.json` | How every audit record is written: which `event.name` values each record has and which schema, the emitter and the collector port; the line on standard output; and the OTel log record, with its attributes, trace context, severity, body, scope and resource |
| [`tool/`](tool/README.md) | The tools' audit record, the refusals a tool gives for approvals and idempotency, the parameters hash, and idempotency by task ID |
| [`approval/`](approval/README.md) | The approval record a call that changes state needs, its rules, and the approval route through which a person approves it |

**Encoding** (`encoding.json`). A record is written in either of two encodings, which carry the same attributes under the same dotted names (`"user.id"`, not `{"user": {"id": …}}`), `event.name` among them. The line: one JSON object per line on standard output, the attributes as top-level members, as since 0.1.0; other members, such as a timestamp or a severity, may appear on it, and their names are not part of this contract. The OTel log record: the attributes one to one, `trace_id` and `span_id` also its trace context, severity INFO for every outcome, no body, the scope `audit`, and the emitter's name as the resource's `service.name`. An emitter that exports to the collector writes the line when the collector does not take a record, and carries on: delivery is at least once, and no request is refused for its record. `record.source` is the collector's to set, over any value an emitter sends ([Observability](../../../../architecture/design/observability.md#audit-and-usage-records)), so the platform's records and a workload's tool records never pass for each other.

**One name per fact.** A field that two records hold has one name in both: `user.id` is the person a record acts for or on (the Keycloak subject), as in the gateways' usage record, and `actor.sub`, `actor.chain`, `session.id`, `token.jti`, `task.id`, `trace_id` and `span_id` mean the same in every record. Records of every hop join on `token.jti`, `session.id` and `task.id`.

**The STS's record: types the design leaves open, fixed here.**

| Field | Type |
| --- | --- |
| `actor.chain` | Array of canonical names, newest first; empty for a refusal of a person's token |
| `request.resource` | Array of every `resource` value in the request, in order; empty when there is none |
| `token.exp` | Integer, seconds since the epoch, as in the token |
| `actor.pod` | The pod's name, from TokenReview's `authentication.kubernetes.io/pod-name` |
| `trace_id`, `span_id` | Lowercase hex, 32 and 16 characters, as in W3C `traceparent` |

**The STS's record: which fields are required.** Every record carries `event.name`, `request.resource`, `sts.policy.hash`, `trace_id` and `span_id`. An issuance adds the subject's `user.id`, `subject.jti` and `subject.iss`, the agent's `actor.sub`, the issued `actor.chain` and the four `token.*` fields, and never `refusal.*`. A refusal adds `refusal.error` and `refusal.reason`, and never `token.*`; it carries the subject's and actor's fields only once they are known, since a request can be refused before either is checked. `user.team`, `session.id`, `actor.pod` and `task.id` appear when their source does.
