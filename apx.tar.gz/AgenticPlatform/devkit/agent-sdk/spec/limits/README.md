# Limits

The caps a workload declares for each task, how they are counted, and the error a task stopped by them ends with. The rules are in [Development: The shared SDK](../../../../architecture/design/development.md#the-shared-sdk-agent-sdk) (the `limits` module), [Gateway: Budgets, rate limits and runaway tasks](../../../../architecture/design/gateway.md#budgets-rate-limits-and-runaway-tasks), [Workflows: A bounded model step](../../../../architecture/design/workflows.md#a-bounded-model-step), and the Limits suite in [Conformance: Suites](../../../../architecture/design/conformance.md#suites).

| File | Holds |
| --- | --- |
| `limits.json` | `limits`: each limit's `name`, its `unit` and `minimum`, what it `counts`, where it is `checked`, when it stops a task and what the error reports as `used`. `error`: the error's code. `surfaces`: where the error appears, and how, for A2A, MCP, a bounded step and the task's span |
| `declaration.schema.json` | The JSON Schema of the caps a workload declares: `workload.yaml`'s `limits` |
| `error.schema.json` | The JSON Schema of the error object |
| `runtime.json` | Where a running workload reads its caps: the path of `workload.yaml` in its image, and the environment variables that may lower a cap, with their rules |
| `examples/`, `invalid/` | Declarations and errors that must validate, and ones that must not; `<case>.<schema>.json` names the schema |

**A task,** for limits, is the work a workload does for one request it accepts: one A2A message an agent runs, one `tools/call` an MCP server serves, or one bounded step. Each starts with every count at zero. The counts live in the workload's memory for that request alone: a second request with the same task ID gets counts of its own, and the gateway's per-person and per-team limits bound the total. A workload with several replicas shares nothing.

**Counting.** The design's "steps" are `model_calls`: an agent's model calls are its steps. A call that a transport retries, such as the `resilience` module on a 429, counts once; its tokens are the final response's. `tokens` takes each response's own total, input and output, as the response reports it: ADK's `usage_metadata.total_token_count`, Chat Completions' `usage.total_tokens`, or the sum of input and output where a response gives no total. Cache reads and writes count as input, as the gateway counts them.

**Stopping.** The task stops at the first check that fails, as `limits.json` gives for each limit:

- The call that would pass a cap is not made. A response that takes `tokens` past its cap is not acted on: no tool call it asks for starts, and its text is not the answer.
- When `wall_time_seconds` runs out, the call in flight is cancelled.
- After the stop the workload starts no model or tool call for the task, and ends it with the error on its surface. A tool call already finished keeps its effect; the stop leaves no partial one of its own.

**The error.** `{"error": "limit_exceeded", "limit": …, "cap": …, "used": …}`, with the task's `task_id` and a `message` for people when the workload has them. Suites assert `error` and `limit`; `cap` and `used` say by how much. `used` is at least `cap` for `tokens` and `wall_time_seconds`, and equal to it for the call counts. Consumers ignore members they do not know, so a later minor version may add some.

**Declaring.** `workload.yaml`'s `limits` holds the caps under the limits' names; which a workload must declare depends on its kind, as [`../schemas/`](../schemas/README.md) sets. The schema sets each limit's minimum and no maximum: the platform's limits at the gateway stay the backstop. A workload's framework may have caps of its own, such as ADK's `max_llm_calls`; the SDK keeps those above the declared ones, so the declared cap is the one that stops the task and the error is this one.

**At runtime** (`runtime.json`). A workload reads its caps from its own `workload.yaml`, which its image carries at `/etc/agentic/workload.yaml`; without a valid file there, a workload that applies limits does not start. The environment may lower a cap and never raise it: `AGENTIC_LIMIT_MODEL_CALLS`, `AGENTIC_LIMIT_TOOL_CALLS`, `AGENTIC_LIMIT_TOKENS` and `AGENTIC_LIMIT_WALL_TIME_SECONDS`. The cap in force is the lower of the file's and the variable's; a variable for a limit the file does not declare sets that cap; a value above the file's is ignored and logged at start; a value that is not a decimal integer at least the limit's minimum stops the workload at start. A bounded step takes the file's path from its command line, since it runs in a pipeline job ([`../step/`](../step/README.md)).

**Checked at the desk, 2026-11-17,** in the released code, not run: in Google ADK 2.14.1, an error event the run does not recover from ends the A2A task failed with a text part (`create_error_status_event`), and an `ExecuteInterceptor`'s `after_agent` may rewrite that final event, which is where the data part goes; in the MCP Python SDK 2.3.0, neither the server nor the client checks `structuredContent` against a tool's `outputSchema` when `isError` is true.
