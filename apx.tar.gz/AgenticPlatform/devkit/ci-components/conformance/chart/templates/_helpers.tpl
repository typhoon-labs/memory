{{- define "conformance.image" -}}
{{- $root := index . 0 }}{{- $img := index . 1 }}
{{- printf "%s/%s@%s" (required "registry.host is required" $root.Values.registry.host) $img.repository (required (printf "the digest of %s is required" $img.repository) $img.digest) }}
{{- end }}

{{- define "conformance.labels" -}}
app.kubernetes.io/name: {{ . }}
app.kubernetes.io/part-of: platform-conformance
{{- end }}

{{- /* Non-root, read-only, no capabilities: as every platform pod. */}}
{{- define "conformance.podSecurity" -}}
runAsNonRoot: true
runAsUser: 65532
runAsGroup: 65532
seccompProfile: {type: RuntimeDefault}
{{- end }}

{{- define "conformance.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities: {drop: [ALL]}
{{- end }}

{{- /* A fixture's Deployment, Service and ServiceAccount: name, namespace, args, extra pod spec. */}}
{{- define "conformance.fixture" -}}
{{- $root := .root }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .sa | default .name }}
  namespace: {{ .namespace }}
  labels: {{- include "conformance.labels" .name | nindent 4 }}
automountServiceAccountToken: false
---
apiVersion: v1
kind: Service
metadata:
  name: {{ .service | default .name }}
  namespace: {{ .namespace }}
  labels: {{- include "conformance.labels" .name | nindent 4 }}
spec:
  selector: {app.kubernetes.io/name: {{ .name }}}
  ports:
    - {name: http, port: 8080, targetPort: http}
    {{- if .ops }}
    - {name: http-ops, port: 9090, targetPort: ops}
    {{- end }}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .name }}
  namespace: {{ .namespace }}
  labels: {{- include "conformance.labels" .name | nindent 4 }}
spec:
  replicas: 1
  selector:
    matchLabels: {app.kubernetes.io/name: {{ .name }}}
  template:
    metadata:
      labels: {{- include "conformance.labels" .name | nindent 8 }}
    spec:
      serviceAccountName: {{ .sa | default .name }}
      automountServiceAccountToken: false
      securityContext: {{- include "conformance.podSecurity" . | nindent 8 }}
      containers:
        - name: fixture
          image: {{ include "conformance.image" (list $root $root.Values.images.fixtures) }}
          args: {{ toJson .args }}
          ports:
            - {name: http, containerPort: 8080}
            - {name: ops, containerPort: 9090}
          readinessProbe:
            httpGet: {path: /readyz, port: ops}
          livenessProbe:
            httpGet: {path: /healthz, port: ops}
          securityContext: {{- include "conformance.containerSecurity" . | nindent 12 }}
          resources: {{- toYaml $root.Values.fixtures.resources | nindent 12 }}
          {{- with .mounts }}
          volumeMounts: {{- toYaml . | nindent 12 }}
          {{- end }}
      {{- with .volumes }}
      volumes: {{- toYaml . | nindent 8 }}
      {{- end }}
{{- end }}
