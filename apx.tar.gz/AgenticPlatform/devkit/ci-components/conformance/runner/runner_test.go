package runner

import (
	"bytes"
	"context"
	"encoding/xml"
	"strings"
	"testing"
)

type env struct{ unmet map[Need]string }

func (e env) Unmet(n Need) string { return e.unmet[n] }

func TestRun(t *testing.T) {
	e := env{unmet: map[Need]string{"cluster": "no cluster here"}}
	cases := []Case[env]{
		{ID: "s/pass", Suite: "s", Run: func(c *C[env]) { c.Logf("noted") }},
		{ID: "s/fail", Suite: "s", Run: func(c *C[env]) { c.Errorf("one"); c.Errorf("two") }},
		{ID: "s/fatal", Suite: "s", Run: func(c *C[env]) { c.Fatalf("stop"); c.Errorf("never") }},
		{ID: "s/skip", Suite: "s", Run: func(c *C[env]) { c.Skipf("not today") }},
		{ID: "s/need", Suite: "s", Needs: []Need{"cluster"}, Run: func(c *C[env]) { c.Errorf("ran") }},
		{ID: "t/panic", Suite: "t", Run: func(c *C[env]) { panic("boom") }},
	}
	var got []Result
	for _, k := range cases {
		got = append(got, Run(context.Background(), e, k))
	}
	want := []struct {
		s   Status
		msg string
	}{{Pass, ""}, {Fail, "one\ntwo"}, {Fail, "stop"}, {Skip, "not today"}, {Skip, "needs cluster: no cluster here"}, {Fail, "panic: boom"}}
	for i, w := range want {
		if got[i].Status != w.s || !strings.HasPrefix(got[i].Message, w.msg) {
			t.Errorf("%s: got %s %q", got[i].ID, got[i].Status, got[i].Message)
		}
	}
	if ok, _ := Verdict(got[:1], true); !ok {
		t.Errorf("a pass alone must be ok")
	}
	if ok, s := Verdict([]Result{got[0], got[3]}, true); ok || !strings.Contains(s, "strict") {
		t.Errorf("strict: a skip must fail the run: %s", s)
	}
	if ok, _ := Verdict([]Result{got[0], got[3]}, false); !ok {
		t.Errorf("not strict: a skip is fine")
	}
	sel, err := Select(cases, "^s/", "skip|need")
	if err != nil || len(sel) != 3 {
		t.Errorf("select: %d %v", len(sel), err)
	}
	var buf bytes.Buffer
	if err := JUnit(&buf, got); err != nil {
		t.Fatal(err)
	}
	var doc struct {
		Suites []struct {
			Name     string `xml:"name,attr"`
			Tests    int    `xml:"tests,attr"`
			Failures int    `xml:"failures,attr"`
			Skipped  int    `xml:"skipped,attr"`
		} `xml:"testsuite"`
	}
	if err := xml.Unmarshal(buf.Bytes(), &doc); err != nil || len(doc.Suites) != 2 || doc.Suites[0].Tests != 5 || doc.Suites[0].Failures != 2 || doc.Suites[0].Skipped != 2 {
		t.Errorf("JUnit: %+v %v\n%s", doc, err, buf.String())
	}
	buf.Reset()
	Text(&buf, got)
	if !strings.Contains(buf.String(), "FAIL s/fail") || !strings.Contains(buf.String(), "| noted") {
		t.Errorf("text:\n%s", buf.String())
	}
}
