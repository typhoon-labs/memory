package runner

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"sort"
	"strings"
)

// Text writes one block per result: the verdict, the ID, the time, then the
// message and logs indented.
func Text(w io.Writer, results []Result) {
	for _, r := range results {
		fmt.Fprintf(w, "%-4s %s (%s)\n", strings.ToUpper(string(r.Status)), r.ID, r.Duration.Round(1e6))
		if r.Layer != "" && r.Status != Skip {
			fmt.Fprintf(w, "     refusing layer under test: %s\n", r.Layer)
		}
		for _, l := range strings.Split(r.Message, "\n") {
			if l != "" {
				fmt.Fprintf(w, "     %s\n", l)
			}
		}
		for _, l := range r.Logs {
			fmt.Fprintf(w, "     | %s\n", l)
		}
	}
}

// JSON writes the results as one JSON document.
func JSON(w io.Writer, results []Result) error {
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(struct {
		SuiteVersion string   `json:"suite_version"`
		Results      []Result `json:"results"`
	}{Version(), results})
}

type junitSuites struct {
	XMLName xml.Name     `xml:"testsuites"`
	Suites  []junitSuite `xml:"testsuite"`
}

type junitSuite struct {
	Name     string      `xml:"name,attr"`
	Tests    int         `xml:"tests,attr"`
	Failures int         `xml:"failures,attr"`
	Skipped  int         `xml:"skipped,attr"`
	Time     string      `xml:"time,attr"`
	Cases    []junitCase `xml:"testcase"`
}

type junitCase struct {
	Name      string        `xml:"name,attr"`
	Classname string        `xml:"classname,attr"`
	Time      string        `xml:"time,attr"`
	Failure   *junitMessage `xml:"failure,omitempty"`
	Skipped   *junitMessage `xml:"skipped,omitempty"`
	SystemOut string        `xml:"system-out,omitempty"`
}

type junitMessage struct {
	Message string `xml:"message,attr"`
	Text    string `xml:",chardata"`
}

// JUnit writes the results as JUnit XML, one testsuite per suite, which
// GitLab shows on a merge request.
func JUnit(w io.Writer, results []Result) error {
	bySuite := map[string]*junitSuite{}
	var names []string
	for _, r := range results {
		s := bySuite[r.Suite]
		if s == nil {
			s = &junitSuite{Name: r.Suite}
			bySuite[r.Suite] = s
			names = append(names, r.Suite)
		}
		jc := junitCase{Name: r.ID, Classname: r.Suite, Time: fmt.Sprintf("%.3f", r.Duration.Seconds()), SystemOut: strings.Join(r.Logs, "\n")}
		first, _, _ := strings.Cut(r.Message, "\n")
		switch r.Status {
		case Fail:
			jc.Failure = &junitMessage{Message: first, Text: r.Message}
			s.Failures++
		case Skip:
			jc.Skipped = &junitMessage{Message: first}
			s.Skipped++
		}
		s.Tests++
		s.Cases = append(s.Cases, jc)
	}
	sort.Strings(names)
	var doc junitSuites
	for _, n := range names {
		s := bySuite[n]
		var total float64
		for _, c := range s.Cases {
			var t float64
			fmt.Sscanf(c.Time, "%f", &t)
			total += t
		}
		s.Time = fmt.Sprintf("%.3f", total)
		doc.Suites = append(doc.Suites, *s)
	}
	if _, err := io.WriteString(w, xml.Header); err != nil {
		return err
	}
	enc := xml.NewEncoder(w)
	enc.Indent("", "  ")
	if err := enc.Encode(doc); err != nil {
		return err
	}
	_, err := io.WriteString(w, "\n")
	return err
}
