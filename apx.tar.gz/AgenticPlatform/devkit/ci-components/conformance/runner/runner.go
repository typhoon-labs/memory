// Package runner is the start of the conformance runner (design/conformance.md):
// cases as values, each declaring what it needs beyond the environment's
// basics, run one by one with a verdict and messages, and reported as text,
// JSON and JUnit, which is what a merge request shows. The suites are
// packages that build their cases on it; build phase B2 brings the
// platform-controls suites, and B5 the workload suites and `agentctl conform`.
//
// It follows infra/delegation-sts's interop runner, whose shape B1 proved: a
// case that cannot run says which need is unmet and how to meet it, and in
// strict mode a skipped case fails the run.
package runner

import (
	"context"
	"fmt"
	"regexp"
	"runtime/debug"
	"strings"
	"time"
)

// Need is something a case requires beyond what every run has.
type Need string

// Status is a case's outcome.
type Status string

// Outcomes.
const (
	Pass Status = "pass"
	Fail Status = "fail"
	Skip Status = "skip"
)

// Env is what a suite runs against. Unmet says why a need is not met, or ""
// if it is.
type Env interface {
	Unmet(Need) string
}

// Case is one check.
type Case[E Env] struct {
	ID    string // stable, path-like: <suite>/<group>/<case>
	Suite string // the suite it belongs to, such as gateway-path
	Row   string // the claim of the suite's row in design/conformance.md it proves
	Title string // what it proves, as a refusal and its allowed twin
	Layer string // the layer whose refusal it asserts, or "" for an allowed-path check
	Needs []Need // beyond the run's basics
	// Cluster is true when the case can only run against a cluster: it
	// needs the mesh, NetworkPolicy, admission, the realm or the STS. Cases
	// with it false run against the configured URLs anywhere.
	Cluster bool
	Run     func(*C[E])
}

// Result is a case's outcome with its messages.
type Result struct {
	ID       string        `json:"id"`
	Suite    string        `json:"suite"`
	Title    string        `json:"title"`
	Layer    string        `json:"layer,omitempty"`
	Status   Status        `json:"status"`
	Message  string        `json:"message,omitempty"` // the failures, or why it was skipped
	Logs     []string      `json:"logs,omitempty"`
	Duration time.Duration `json:"duration_ns"`
}

// C is a running case.
type C[E Env] struct {
	context.Context
	Env  E
	Case Case[E]

	errs []string
	logs []string
}

type abort struct{}
type skip struct{ why string }

// Errorf records a failure and continues.
func (c *C[E]) Errorf(format string, args ...any) {
	c.errs = append(c.errs, fmt.Sprintf(format, args...))
}

// Fatalf records a failure and ends the case.
func (c *C[E]) Fatalf(format string, args ...any) {
	c.Errorf(format, args...)
	panic(abort{})
}

// Skipf ends the case as skipped.
func (c *C[E]) Skipf(format string, args ...any) { panic(skip{fmt.Sprintf(format, args...)}) }

// Logf records a note for the report.
func (c *C[E]) Logf(format string, args ...any) {
	c.logs = append(c.logs, fmt.Sprintf(format, args...))
}

// Failed reports whether the case has failed so far.
func (c *C[E]) Failed() bool { return len(c.errs) > 0 }

// Sleep waits for d or until the case's context ends, which fails the case.
func (c *C[E]) Sleep(d time.Duration) {
	select {
	case <-time.After(d):
	case <-c.Done():
		c.Fatalf("cancelled while waiting: %v", c.Err())
	}
}

// Run runs one case against env.
func Run[E Env](ctx context.Context, env E, k Case[E]) (res Result) {
	res = Result{ID: k.ID, Suite: k.Suite, Title: k.Title, Layer: k.Layer}
	start := time.Now()
	defer func() { res.Duration = time.Since(start) }()
	for _, n := range k.Needs {
		if why := env.Unmet(n); why != "" {
			res.Status, res.Message = Skip, fmt.Sprintf("needs %s: %s", n, why)
			return res
		}
	}
	c := &C[E]{Context: ctx, Env: env, Case: k}
	defer func() {
		res.Logs = c.logs
		switch r := recover().(type) {
		case nil, abort:
		case skip:
			res.Status, res.Message = Skip, r.why
			return
		default:
			c.errs = append(c.errs, fmt.Sprintf("panic: %v\n%s", r, debug.Stack()))
		}
		if len(c.errs) > 0 {
			res.Status, res.Message = Fail, strings.Join(c.errs, "\n")
		} else {
			res.Status = Pass
		}
	}()
	k.Run(c)
	return res
}

// Select keeps the cases whose ID matches run and does not match skip; an
// empty pattern matches everything for run and nothing for skip.
func Select[E Env](cases []Case[E], run, skip string) ([]Case[E], error) {
	var r, s *regexp.Regexp
	var err error
	if run != "" {
		if r, err = regexp.Compile(run); err != nil {
			return nil, fmt.Errorf("-run: %v", err)
		}
	}
	if skip != "" {
		if s, err = regexp.Compile(skip); err != nil {
			return nil, fmt.Errorf("-skip: %v", err)
		}
	}
	var out []Case[E]
	for _, k := range cases {
		if r != nil && !r.MatchString(k.ID) {
			continue
		}
		if s != nil && s.MatchString(k.ID) {
			continue
		}
		out = append(out, k)
	}
	return out, nil
}

// Verdict is a run's overall outcome: it fails on any failure, and in
// strict mode on any skip.
func Verdict(results []Result, strict bool) (ok bool, summary string) {
	counts := map[Status]int{}
	for _, r := range results {
		counts[r.Status]++
	}
	ok = counts[Fail] == 0 && (!strict || counts[Skip] == 0)
	summary = fmt.Sprintf("%d passed, %d failed, %d skipped", counts[Pass], counts[Fail], counts[Skip])
	if strict && counts[Skip] > 0 {
		summary += " (strict: a skipped case fails the run)"
	}
	return ok, summary
}
