package runner

import (
	"regexp"
	"testing"
)

// The spec's version pattern (spec/schemas/artifact.schema.json, $defs
// version), which suite_version must match.
var semver = regexp.MustCompile(`^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?$`)

func TestVersion(t *testing.T) {
	defer func(c string) { commit = c }(commit)
	for _, tc := range []struct{ commit, want string }{
		{"", "1.1.1-dev"},
		{"567edf35e7d2", "1.1.1-dev.g567edf35e7d2"},
		{"012345678901", "1.1.1-dev.g012345678901"},
	} {
		commit = tc.commit
		got := Version()
		if got != tc.want || !semver.MatchString(got) {
			t.Errorf("commit %q: version %q, want %q matching the spec's pattern", tc.commit, got, tc.want)
		}
	}
}
