package runner

import (
	_ "embed"
	"strings"
)

// base is the coming ci-components release, the one whose suites this
// runner holds once it is tagged: VERSION beside this file, raised with
// each release's first change.
//
//go:embed VERSION
var base string

// commit is the 12-hex-digit prefix of the commit the runner was built
// from, which the images' build sets with -ldflags -X (SOURCE_COMMIT);
// empty for any other build.
var commit string

// Version is the suites' version, as the conformance attestation's
// suite_version records it (agent-sdk's spec/attestations/): the coming
// release as a SemVer pre-release, <base>-dev.g<commit>, or <base>-dev
// without a commit. The images are built on main before their release is
// tagged, and the tag's pipeline builds none, so every runner reports a
// pre-release, which sorts below its release: an environment's minimum
// suite version compares pre-releases. The g keeps a commit of digits
// alone an alphanumeric identifier, which SemVer lets start with 0.
func Version() string {
	v := strings.TrimSpace(base) + "-dev"
	if commit != "" {
		v += ".g" + commit
	}
	return v
}
