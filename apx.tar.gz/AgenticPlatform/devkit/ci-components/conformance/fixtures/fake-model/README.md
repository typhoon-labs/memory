# fake-model

The fake model server: the conformance fixture that stands in for a model provider. From build phase B2, the gateway routes model traffic here instead of to Bedrock, for daily work and CI ([A model endpoint](../../../../../architecture/plan/local-build.md#1-answer-in-brief), [B2](../../../../../architecture/plan/local-build.md#6-phased-local-build)). It speaks Anthropic's Messages API and OpenAI's Chat Completions, streaming and not, and it is deterministic, so a conformance result never depends on chance ([Conformance](../../../../../architecture/design/conformance.md)). A request asks for faults in its own text, which reaches the model even when the caller is a workload under test.

This README is the fixture's contract: the B2 suites, and later the Retries and Limits suites, are written against it.

```text
fake-model/
├── main.go              # the command: flags and environment, two listeners, shutdown
├── internal/model/      # the conversation, the counting rule, directives, replies; no HTTP
├── internal/server/     # both APIs, streams, errors, faults, request records, health
├── Dockerfile           # distroless, non-root, linux/amd64 and linux/arm64
├── go.mod               # its own module, standard library only
└── README.md
```

## The API surface

Two ports. The gateway's route and the mesh's policy admit the model port only; suites and probes use the operations port.

| Port (default) | Method and path | Serves |
| --- | --- | --- |
| Model, `:8080` | `POST /v1/messages` | Anthropic's Messages API, as a body or, with `"stream": true`, as server-sent events |
| | `POST /v1/messages/count_tokens` | Anthropic's token counting: `{"input_tokens": N}` by the counting rule. Directives are not read |
| | `POST /v1/chat/completions` | OpenAI's Chat Completions, as a body or, with `"stream": true`, as data-only events |
| | anything else | 404 `Invalid URL (<method> <path>)` in Messages' error shape if the request has `anthropic-version`, else in Chat Completions' |
| Operations, `:9090` | `GET /healthz` | 200 while the process serves |
| | `GET /readyz` | 200 until shutdown begins, then 503 |
| | `GET /requests[?id=<id>]` | The request records, oldest first: all, or those of one directive id |
| | `DELETE /requests[?id=<id>]` | Forgets the records and attempt counts: all, or one directive id's. 204 |

A query string is ignored (Claude Code sends `/v1/messages?beta=true`). No credential is required, and none is checked: the records name which credential headers arrived, never their values.

### What a request must carry

The fake model checks what the real APIs require, so a request misrouted or malformed by the gateway fails with a 400 instead of passing. Validation messages imitate the real APIs' wording but are not copied from them; suites should rely on the status and the error type only.

| | Messages | Chat Completions |
| --- | --- | --- |
| Headers | `anthropic-version`, any value (2023-06-01 and 2026-10-21 are current); `anthropic-beta` is recorded, not read | None |
| Required | `model`; `max_tokens` (an integer of at least 1); `messages`, not empty, each with role `user`, `assistant` or `system` and `content` | `model`; `messages`, not empty, each with role `system`, `developer`, `user`, `assistant`, `tool` or `function` |
| Read | `system` (a string or text blocks); content as a string or blocks: `text`, `thinking`, `tool_use` and `server_tool_use` (name and input), `tool_result` (its text); `tools` (`name`, `description`, `input_schema`); `stream` | Content as a string, null or parts (`text`, `refusal`); `tool_calls` and `function_call` (name and arguments); `tools` of type `function` (`name`, `description`, `parameters`); `stream`; `stream_options.include_usage`; `max_completion_tokens`, or else `max_tokens` |
| Refused | Any other role, such as `developer` or `tool`; a block without a type | `n` other than 1 |
| Ignored | Everything else: `temperature`, `metadata`, `thinking`, `tool_choice`, `cache_control`, `stop_sequences` | Everything else |

**System entries in `messages`** are accepted from B6, an addition: the Messages API takes them for current models, and Claude Code sends them mid-conversation to model IDs it does not recognise, as a gateway's aliases are ([B6 desk check](../../../../../architecture/research/2026-11-18-b6-desk-check.md#claude-code-through-the-gateway)). Each is a system turn where it stands, as a Chat Completions `system` message is, so the same turns sent to either API are the same conversation; its place is part of the conversation, so moving it changes the reply. Before B6 the fake model refused one with a 400 naming `messages.N.role`.

Other content blocks (images, documents, search results) and parts (images, audio, files) are accepted and counted as blocks. The body is limited to 32 MiB (`-max-body`): beyond it, a 413 (`request_too_large` for Messages).

### What it answers

**Messages, as a body:** `{"id", "type": "message", "role": "assistant", "model", "content", "stop_reason", "stop_sequence": null, "usage": {"input_tokens", "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0, "output_tokens"}}`, with one content block: `text`, or `tool_use` with `id`, `name` and `input`. `stop_reason` is `end_turn`, `max_tokens` or `tool_use`. The `request-id` header carries the request's ID.

**Messages, as a stream** (`text/event-stream; charset=utf-8`), each event named and its data's `type` the same:

```text
message_start          message with empty content, stop_reason null, usage.input_tokens, usage.output_tokens 1 (0 for an empty reply)
content_block_start    index 0: {"type":"text","text":""}, or {"type":"tool_use","id","name","input":{}}
ping
content_block_delta    one per word (text_delta), or an empty input_json_delta, then one per piece of the input
content_block_stop     index 0
message_delta          delta.stop_reason, stop_sequence null, usage.output_tokens (cumulative: the body's count)
message_stop
```

**Chat Completions, as a body:** `{"id", "object": "chat.completion", "created", "model", "choices": [{"index": 0, "message": {"role": "assistant", "content", "refusal": null, "annotations": [], "tool_calls"}, "logprobs": null, "finish_reason"}], "usage": {"prompt_tokens", "completion_tokens", "total_tokens", "prompt_tokens_details": {"cached_tokens": 0}, "completion_tokens_details": {"reasoning_tokens": 0}}, "service_tier": "default", "system_fingerprint": null}`. A tool call has `content: null` and one entry in `tool_calls`. `finish_reason` is `stop`, `length` or `tool_calls`. The `x-request-id` header carries the request's ID.

**Chat Completions, as a stream:** data-only events of `chat.completion.chunk` objects with the body's `id`, `created` and `model`:

```text
delta {"role":"assistant","content":""}, or {"role":"assistant","tool_calls":[{"index":0,"id","type":"function","function":{"name","arguments":""}}]}
delta {"content":" word"}, one per word, or {"tool_calls":[{"index":0,"function":{"arguments":"<piece>"}}]}, one per piece
delta {} with finish_reason
choices [] with usage          only if stream_options.include_usage is true; then every earlier chunk has "usage": null
[DONE]
```

**IDs and time.** Every ID derives from the conversation's ID, the first 24 hex digits of a SHA-256 hash of the model, the messages and the tools: `msg_fake_<id>`, `toolu_fake_<id>`, `chatcmpl-fake<id>`, `call_fake_<id>`, and the request ID `req_fake_<id>` (from a hash of the body when the request does not parse). `created` is always 1767225600 (2026-01-01T00:00:00Z).

**Errors** use each API's shape. Messages: `{"type": "error", "error": {"type", "message"}, "request_id"}`, with the type for the status: 400 `invalid_request_error`, 401 `authentication_error`, 402 `billing_error`, 403 `permission_error`, 404 `not_found_error`, 409 `conflict_error`, 413 `request_too_large`, 429 `rate_limit_error`, 504 `timeout_error`, 529 `overloaded_error`, other 5xx `api_error`, other 4xx `invalid_request_error`. Chat Completions: `{"error": {"message", "type", "param", "code"}}`: 401 `invalid_request_error` with code `invalid_api_key`; 429 type `requests` with code `rate_limit_exceeded`; 5xx `server_error`; others `invalid_request_error`. An injected error's message ends `(injected by a fake-model directive)`.

**The context window** is 200,000 input tokens (`-context-window`, or a directive's `context`). A larger request gets a 400: Messages' `prompt is too long: N tokens > W maximum`, or Chat Completions' code `context_length_exceeded` with param `messages`.

### Determinism

The same request always gets the same response: the same status, body bytes and headers, apart from `Date`. A stream carries the same text and usage as the body. What a request is, for this rule, is its model, messages and tools; `max_tokens` only caps the reply. The fake model reduces the same turns, sent to either API with the same model name, to the same conversation, so they get the same reply and usage; the tests prove this of the fake model's own two parsers only. Whether the gateway's translation keeps the turns was not checked, and tool results never match: Messages carries them in a user turn, Chat Completions in one tool turn each.

Two things are state, both kept per process, so run one replica:

- **`times`**: the faults of a directive with `times=N` apply to the first N requests that carry it. The same sequence of requests always gets the same sequence of responses.
- **The records** observe requests; they never change a response.

## The counting rule

A text's tokens: each maximal run of letters and digits is one token, and each other character that is not white space is one token. `Hello, world!` is 4 tokens; `get_weather` is 3; `{"a":1}` is 7.

**Input tokens** are the sum over the request's messages of one token for the turn, the tokens of each text it carries, and one for each block or part that carries no text; plus, for each declared tool, the tokens of its name, its description and its schema in canonical JSON (compact, keys sorted). A system prompt is a turn: Messages' `system`, and each `system` entry in its `messages`, where it stands, or each Chat Completions `system` or `developer` message. The texts of a message are its text content, a tool call's name and its input or arguments in canonical JSON, and a tool result's text. For example, `system: "Be brief."` with one user message `Hello, world!` is 1 + 3 + 1 + 4 = 9 input tokens.

**Output tokens** are the reply's: a text reply of N words is N tokens; a tool call is its name's tokens plus its input's, in canonical JSON, and parallel calls each count. A directive's `usage` replaces that count with its own, and it alone breaks this rule. `total_tokens` is their sum.

## The reply

A text reply is words drawn from a fixed vocabulary of 64 lowercase words, each one token, chosen by a hash of the conversation: between 8 and 32 words, or exactly the number a directive's `tokens` asks for. If that exceeds `max_tokens` (Messages) or `max_completion_tokens`/`max_tokens` (Chat Completions), the reply is cut to the cap and ends with `max_tokens` or `length`. No word can form a directive.

A tool call is made only when a directive's `tool` or `call` asks for one. Its input satisfies the tool's schema: each required property takes its enum's first value, its `const`, its `default`, or a fixed value of its type (`"fake"`, `0`, `false`, `[]`, or an object built the same way, recursively). A tool `call` names that the request does not declare has no schema, so its input is `{}`. Each `arg.<name>` then sets the input's top-level member `<name>` to its value, as a string, over what the schema gave. A stream sends the canonical input in pieces of at most eight characters. Each turn's tool call has its own ID, because the conversation, and so its hash, grows with each tool result.

The fake model never produces thinking blocks, citations, cache token counts other than 0, or rate-limit headers.

## The fault-control contract

**Why the request's text.** In the workload suites the caller of the model is the workload under test; the suite controls only the task it gives the workload. A header set by the suite never reaches the model, and a marker in the model name does not survive the gateway, which maps aliases to provider models and can override the model per provider. The text of the conversation reaches the model through the workload, through the gateway's alias mapping, and through its translation between the two APIs.

**Syntax.** A directive is written anywhere in a text of the request:

```text
[[fake-model key=value key ...]]
```

Keys and values are separated by white space; a bare key takes its default. A malformed directive, an unknown key or a bad value is a 400 `invalid_request_error` naming the problem, so a typo never passes silently. `[[fake-model]]` with no keys is valid and does nothing.

**Which directive applies.** The latest: messages are searched from last to first, a message's texts from last to first, a text's directives from last to first, and Messages' top-level `system` last; a `system` entry in `messages` is searched where it stands. A directive in the user's task therefore keeps applying on every later turn of an agent loop, whose last message is a tool result, until a later directive replaces it.

**Every text is searched, tool results included.** An agent that reads a file or a tool result holding a directive carries it into its conversation, and from then on every turn obeys it, or gets a 400 if it is malformed: the syntax line above, read by an agent, is a 400 on every later turn (`key` is not a key). Keep directive examples away from what an agent under test reads, as Claude Code will through the gateway in B6.

| Key | Value | Effect |
| --- | --- | --- |
| `id` | 1 to 128 letters, digits, `.`, `_` or `-` | Names the directive: its requests are recorded under it and `times` counts them. Use a unique id per test, or `DELETE /requests?id=` first |
| `times` | integer, at least 1 | The faults apply to the first N requests carrying the directive (counted by `id`, or by the directive's text without one); later requests are answered normally. Without it, faults apply to every request |
| `status` | 400 to 599 | Answer with this HTTP error in the API's shape |
| `retry-after` | seconds, 0 to 86400 | The `retry-after` header of the error. A 429 without it gets `retry-after: 1` |
| `after` | integer | With `status`, on a stream: answer 200, send N content deltas, then the error as an in-stream event, and end. Without a stream, the error is an HTTP error |
| `delay` | duration, such as `250ms` or `2s` | Wait before the first byte (status line), for errors too |
| `interval` | duration | Wait before each content delta of a stream, overriding `-interval` |
| `cut` | integer, default 0 | Abort at the transport after N content deltas, or N bytes of a body (whose `Content-Length` is the full length): no closing events, the client reads an unexpected EOF |
| `truncate` | integer, default 0 | End cleanly after N content deltas or N bytes of a body: no closing events, no error. `truncate` on a body is a 200 with an empty body; on a stream, `truncate` still sends the opening events |
| `stall` | integer, default 0 | Send N content deltas, then nothing more, holding the connection open until the client goes away, `-max-hold` passes (then abort) or the server shuts down (abort). A body stalls before its first byte: no response at all |
| `reset` | none | Abort the connection before any byte |
| `tokens` | integer, 0 to 100000 | The text reply's length in words and tokens, before the `max_tokens` cap. A stream is rendered whole before it is sent, so the bound keeps one request to some 15 MB |
| `tool` | a declared tool's name, or `*` for the first declared | Answer with a call of that tool. A tool the request does not declare is a 400 |
| `call` | a tool's name: 1 to 128 letters, digits, `.`, `_` or `-` | Answer with a call of that tool whether or not the request declares it, as a planted instruction asks a model to call a tool outside the caller's allowlist. A declared tool's schema still shapes the input. Not with `tool` |
| `arg.<name>` | any text without white space or `]` | With `tool` or `call`: the input's top-level member `<name>` (1 to 64 letters, digits, `_` or `-`) is this text, as a string. Repeatable with different names |
| `parallel` | integer, 2 to 16 | With `tool` or `call`: the reply makes this many calls of the tool at once, as a model's parallel tool use does, each with its own ID: the first keeps the single call's, the others add `_2`, `_3` and so on. Messages gives each its own `tool_use` block, Chat Completions its own `tool_calls` entry with its `index`; a stream sends the calls one after another, each block or index opened, its pieces, and for Messages closed |
| `usage` | integer, 1 to 100000000 | The output tokens the reply reports, in the body, the stream and the record, in place of the counting rule's: a short reply that carries its caller past a token cap |
| `context` | integer, at least 1 | The context window for this request, in input tokens |
| `echo` | none | With `status`: the error's message ends with `: ` and the request's last user text, the directive included, as a provider's error that quotes its input does; in a stream's in-stream error too. Without `status`, a 400 |

`status`, `retry-after`, `after`, `delay`, `interval`, `cut`, `truncate`, `stall` and `reset` are faults: `times` limits them; `echo` shapes the `status` fault's message. `tokens`, `tool`, `call`, `arg.<name>`, `parallel`, `usage` and `context` are behaviours: they apply to every request carrying the directive.

**One ending.** At most one of `after`, `cut`, `truncate`, `stall` and `reset`, and `status` without `after` combines with none of them. `delay` and `interval` combine with anything.

**Content deltas** are what `after`, `cut`, `truncate` and `stall` count: Messages' `content_block_delta` events (for a tool call, the empty first `input_json_delta` included), and Chat Completions' chunks that carry a word or a piece of arguments; with `parallel`, every call's. If the reply has fewer deltas than N, the fault acts after the last of them, before the closing events, so it always fires. N = 0 acts after the opening events: `message_start`, `content_block_start` and `ping`, or the chunk with the role. On a body, `cut` and `truncate` stop a byte short of the end at most, so they always fire too.

**In-stream errors.** Messages: `event: error` with `{"type": "error", "error": {"type", "message"}}`, the type for the status (529 gives `overloaded_error`, as the API sends during high load). Chat Completions: a data event holding the error body, `{"error": {...}}`, and no `[DONE]`; OpenAI does not document this shape, so it is modeled on its error body. It has no `id`, `choices` or `model`, so agentgateway cannot parse it as a chunk; on a Chat Completions route it forwards it unchanged all the same (see [For the gateway configuration in B2](#for-the-gateway-configuration-in-b2)).

### Recipes for the suites

| To prove | Directive | Observe |
| --- | --- | --- |
| Retries are bounded, with backoff, and a retry succeeds | `[[fake-model id=<unique> status=429 retry-after=1 times=2]]` | `GET /requests?id=<unique>`: the attempts, their times and statuses; the third succeeds |
| Retries stop at their bound | `[[fake-model id=<unique> status=503]]` | The number of attempts never grows past the bound |
| A 5xx or an overload | `status=500`, `status=529` | |
| Wall time is capped: a model that never finishes | `stall` (no response), or `stall=3` with `stream: true` | The caller gives up within its cap; the record exists while the call hangs |
| Tokens are capped: a runaway generation | `tokens=100000 interval=10ms` with `stream: true` and a large `max_tokens`: a quarter of an hour of output | |
| Steps and tool calls are capped: a model that always calls a tool | `tool=*` | Each turn calls the tool again |
| Tool calls are capped within one turn | `tool=* parallel=3` | One reply asks for three calls at once; a cap of two lets two start |
| Tokens are capped, at once | `usage=50000` | One short reply that reports 50,000 output tokens |
| A planted instruction asks for a tool outside the allowlist | `call=add_note arg.text=<marker>`, in a tool's output or a document the caller reads | The caller gets a call of `add_note` whether or not it declared it; the tool's own records show whether the call reached it |
| A slow first byte | `delay=5s` | |
| A stream cut midway | `cut=5` | |
| An empty 200 body | `truncate` | |
| An error after a 200 | `status=529 after=3` | |
| A provider's error that quotes the prompt | `status=400 echo` | The error's message holds the request's last user text, which the caller's telemetry may then carry in an exception or a span's status |
| A connection reset | `reset` | |
| Context overflow | `context=2000` | A 400 `prompt is too long` once the conversation exceeds it. The directive stays in the conversation, so a summarising request that carries it is refused too: to test compaction, run an instance with a small `-context-window` instead. Not tested end to end |
| The caller's token never reaches the model | none | `credentials` in the record is `[]` when the gateway sends no credential |
| A trace continues to the model | none | `traceparent` in the record |

### Request records

`GET /requests` answers `{"requests": [...]}`, oldest first, the latest 10,000 (`-records`). Each record holds no content:

| Field | Holds |
| --- | --- |
| `time` | When the request arrived, UTC |
| `api` | `messages`, `chat_completions`, `count_tokens`, or `none` for an unknown path |
| `method`, `path`, `model`, `stream` | As received |
| `directive`, `directive_id` | The directive as written, and its id |
| `attempt` | The request's number among those carrying the same directive, from 1 |
| `fault` | The faults applied, comma-separated: `delay`, `interval`, then one of `status`, `after`, `cut`, `truncate`, `stall`, `reset`. Empty past `times` |
| `status` | The status answered with: 0 if nothing was ever sent (`reset`, a stalled body) |
| `error` | Why the request was refused, for a 4xx the fake model chose |
| `input_tokens`, `output_tokens` | By the counting rule |
| `credentials` | Which of `Authorization`, `X-Api-Key` and `Proxy-Authorization` arrived, never their values |
| `traceparent`, `anthropic_version`, `anthropic_beta` | As received |

A request is recorded before its response starts, so a slow or stalled request can be seen while it lasts.

## Configuration

Each flag defaults to its environment variable, then to its default; a flag beats the environment.

| Flag | Environment | Default | Sets |
| --- | --- | --- | --- |
| `-listen` | `FAKE_MODEL_LISTEN` | `:8080` | The model port |
| `-ops-listen` | `FAKE_MODEL_OPS_LISTEN` | `:9090` | The operations port |
| `-context-window` | `FAKE_MODEL_CONTEXT_WINDOW` | 200000 | The largest request in input tokens |
| `-interval` | `FAKE_MODEL_INTERVAL` | `0s` | The wait before each streamed content delta |
| `-max-hold` | `FAKE_MODEL_MAX_HOLD` | `10m` | The longest a stall holds a connection |
| `-max-body` | `FAKE_MODEL_MAX_BODY` | 33554432 | The largest request body in bytes |
| `-records` | `FAKE_MODEL_RECORDS` | 10000 | The request records kept |
| `-shutdown-grace` | `FAKE_MODEL_SHUTDOWN_GRACE` | `10s` | The time responses in progress get to finish at shutdown |
| `-log-level` | `FAKE_MODEL_LOG_LEVEL` | `info` | `debug`, `info`, `warn` or `error` |
| `-addr-file` | `FAKE_MODEL_ADDR_FILE` | none | A file the server writes, once both ports listen, with their bound addresses, the model port's then the operations port's, one a line: with `-listen` and `-ops-listen` on port 0, a caller learns the ports without racing another process for them |

**Logs** go to standard error as JSON, one line per request (`msg: request`) with the method, path, API, status, duration, model, stream, token counts, directive and attempt, fault, error, `anthropic_version` and credential header names.

**Shutdown.** On SIGTERM or SIGINT, readiness fails and every stall is aborted at once; responses in progress get the grace period to finish, and whatever is left is then closed. The servers have no read or write timeout, since long streams, stalls and slow first bytes are the point; only a client's headers must arrive within 10 seconds.

**The image** is built from this directory: `docker buildx build --platform linux/amd64,linux/arm64 .`. It runs as UID and GID 65532, so a pod can set `runAsNonRoot: true` without a `runAsUser`, and it listens on 8080 and 9090, so it needs no capability.

## For the gateway configuration in B2

Checked against agentgateway's source at tag v1.7.0 (commit `26f5aeb`, 2026-10-27) on 2026-11-16; paths are in [its repository](https://github.com/agentgateway/agentgateway/tree/v1.7.0).

- **The provider type decides what reaches the fake model.** Each backend's provider type lists the formats it accepts, and the gateway translates a client's format to the first one it supports (`CHAT_TRANSLATIONS` and `supported_chat_formats` in `crates/agentgateway/src/llm/mod.rs`):

  | Provider | Messages clients | Chat Completions clients | Responses clients (Codex) |
  | --- | --- | --- | --- |
  | `anthropic` | `/v1/messages` | translated to `/v1/messages` | refused: the gateway has no Responses-to-Messages translation |
  | `openai` | translated to `/v1/responses`, which the fake model does not serve | `/v1/chat/completions` | `/v1/responses`, not served |
  | `custom` with formats `Messages`, `Completions` and `AnthropicTokenCount` | `/v1/messages` | `/v1/chat/completions` | translated to `/v1/chat/completions` |

  In production, Bedrock's Mantle receives Claude models only as Messages (`supported_chat_formats` in `crates/llm/src/bedrock.rs`), so an `anthropic` backend mirrors production for Claude aliases. A `custom` backend with both formats is the one that exercises both of the fake model's APIs, and the only one that serves Codex. Do not use `openai` for Messages clients.
- **Set `pathPrefix: /v1` with `host` and `port`** on an `anthropic` or `openai` provider. With a host override and no path prefix, a managed provider keeps the client's path even when it translates the body (`set_default_path`), so a translated request lands on the wrong endpoint and gets a 400 or 404 here. A `custom` provider builds its paths either way.
- **Plain HTTP.** A host override skips the provider's default TLS policy (`default_connector_policies` is applied only without one), so the backend speaks HTTP to port 8080; the mesh's mTLS wraps it.
- **Headers.** The `anthropic` provider sets `anthropic-version: 2023-06-01` when the client sent none, and moves a bearer token that is not an OAuth token (`sk-ant-oat…`) into `x-api-key` (`set_required_fields`). The `custom` provider sets neither, so through it a Messages client must send `anthropic-version` itself, as the SDKs and Claude Code do. The JWT policy removes a validated `Authorization` header unless told to keep the token (`crates/agentgateway/src/http/jwt.rs`), so with `modelProvider.credentials: none` the records' `credentials` must stay `[]`: anything else means a caller's token reached the model.
- **Streamed usage.** The gateway sets `stream_options.include_usage: true` on every streamed Chat Completions request (`process_completions_request`), so the fake model always sends the usage chunk through the gateway, whatever the client asked.
- **Stream faults through a translation.** A Chat Completions stream passed through unchanged reaches the client byte for byte, the unparsable in-stream error included (`json_passthrough` in `crates/llm/src/parse/sse.rs`). A stream the gateway translates from Messages to Chat Completions (an `anthropic` backend) is different: it drops a Messages `error` event with a warning, and appends `data: [DONE]` to any stream that ends cleanly (`translate_stream` in `crates/llm/src/conversion/messages.rs`, `append_done_on_success` in `parse/sse.rs`). So through that route, `after` and `truncate` reach the client as a stream that ends with `[DONE]` and no finish reason. Read from the source; not yet run.
- **`retry-after`.** On a 429, the gateway reads `retry-after` (seconds or a date), then `retry-after-ms`, then `x-ratelimit-reset*`, to evict the backend for that long (`crates/agentgateway/src/http/outlierdetection.rs`); AI backends with several priority groups evict by default (`crates/agentgateway/src/http/health.rs`). A gateway-level retry or eviction policy changes how many attempts a suite sees in the records.
- **Not sent upstream.** The gateway answers `/v1/models` itself from its catalog (`crates/agentgateway/src/llm/model_list.rs`), so the fake model does not serve it.
- **One replica.** `times` counts and the records live in the process.
- **Cost.** Per-request cost needs price-catalog entries for the model names the aliases map to; this was not checked here.

## Sources

Checked 2026-11-16.

- agentgateway v1.7.0 source, as cited above: the request paths and headers it sends upstream (`crates/agentgateway/src/llm/mod.rs`, `crates/llm/src/anthropic.rs`, `crates/llm/src/openai.rs`, `crates/llm/src/custom.rs`), the typed models its stream parser needs (`crates/llm/src/types/messages.rs` and `completions.rs`: an event without the non-optional fields is dropped), and recorded wire samples of both APIs (`crates/llm/src/tests/response/anthropic` and `completions`).
- Anthropic: [Streaming messages](https://platform.claude.com/docs/en/build-with-claude/streaming) (event flow, ping and error events, cumulative usage in `message_delta`, the tool use stream), [Errors](https://platform.claude.com/docs/en/api/errors) (statuses, types, the error shape with `request_id`, the `request-id` header) and [Versions](https://platform.claude.com/docs/en/api/versioning) (2023-06-01 and 2026-10-21).
- OpenAI: [Chat Completions streaming events](https://developers.openai.com/api/reference/resources/chat/subresources/completions/streaming-events) (the chunk's fields; usage null but on the last chunk with `include_usage`) and [Error codes](https://developers.openai.com/api/docs/guides/error-codes) (statuses and `Retry-After`). That page does not show the error body or `data: [DONE]`; both are taken from agentgateway's recorded samples and its error type.

Not verified against a live API: the wording of validation messages, OpenAI's in-stream error, and OpenAI's error types beyond those named above. Not imitated: prompt caching, thinking, stop sequences, `n` above 1, real image token costs, rate-limit headers, version-specific validation (2026-10-21 refuses `temperature`), Responses, embeddings and model listing.

## Go and checks

Go at the version in [Versions](../../../../../architecture/reference/versions.md), with no dependencies beyond the standard library. Before committing, from this directory: `gofmt -l .` prints nothing, and `go vet ./...` and `go test -race ./...` pass. The tests cover both APIs' framing on the wire, every directive key and fault, the records, the configuration, and the shutdown.
