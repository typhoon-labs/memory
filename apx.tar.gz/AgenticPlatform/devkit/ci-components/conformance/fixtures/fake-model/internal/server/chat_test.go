package server

import (
	"bytes"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/model"
)

const chatHello = `{"model":"claude-test","messages":[{"role":"system","content":"Be brief."},{"role":"user","content":"Hello, world!"}]}`

func TestChat(t *testing.T) {
	ts := start(t, Config{})
	res := chat(t, ts, chatHello)
	if res.status != 200 || res.header.Get("Content-Type") != "application/json" {
		t.Fatalf("%d: %s", res.status, res.body)
	}
	m := object(t, res.body)
	text, _ := get(m, "choices", 0, "message", "content").(string)
	if !strings.HasPrefix(get(m, "id").(string), "chatcmpl-fake") || get(m, "object") != "chat.completion" ||
		num(get(m, "created")) != Created || get(m, "model") != "claude-test" || len(get(m, "choices").([]any)) != 1 ||
		get(m, "choices", 0, "message", "role") != "assistant" || text == "" ||
		get(m, "choices", 0, "finish_reason") != "stop" || !has(m, "choices", 0, "logprobs") {
		t.Errorf("response %s", res.body)
	}
	u := get(m, "usage")
	if num(get(u, "prompt_tokens")) != 9 || num(get(u, "completion_tokens")) != model.Count(text) ||
		num(get(u, "total_tokens")) != num(get(u, "prompt_tokens"))+num(get(u, "completion_tokens")) {
		t.Errorf("usage %v for %q", u, text)
	}
	if !strings.HasPrefix(res.header.Get("X-Request-Id"), "req_fake_") {
		t.Errorf("x-request-id %q", res.header.Get("X-Request-Id"))
	}
	if again := chat(t, ts, chatHello); !bytes.Equal(again.body, res.body) {
		t.Error("the same request got two responses")
	}
	// The same conversation through Messages gets the same reply and usage,
	// so a request the gateway translates answers as the original would.
	mm := object(t, messages(t, ts, hello).body)
	if get(mm, "content", 0, "text") != text || num(get(mm, "usage", "input_tokens")) != num(get(u, "prompt_tokens")) ||
		num(get(mm, "usage", "output_tokens")) != num(get(u, "completion_tokens")) {
		t.Errorf("Messages answered %v, Chat Completions %q %v", mm, text, u)
	}
}

// checkChunk holds a chunk to what agentgateway 1.7.0's typed model needs
// (crates/llm/src/types/completions.rs, StreamResponse): id, choices and
// model.
func checkChunk(t *testing.T, c map[string]any) {
	t.Helper()
	for _, f := range []string{"id", "choices", "model"} {
		if !has(c, f) {
			t.Errorf("chunk lacks %s: %v", f, c)
		}
	}
	if c["object"] != "chat.completion.chunk" || num(c["created"]) != Created {
		t.Errorf("chunk %v", c)
	}
}

func TestChatStream(t *testing.T) {
	ts := start(t, Config{})
	full := object(t, chat(t, ts, chatHello).body)
	text := get(full, "choices", 0, "message", "content").(string)
	words := len(strings.Fields(text))
	for _, includeUsage := range []bool{false, true} {
		body := strings.Replace(chatHello, `"messages"`, `"stream":true,"messages"`, 1)
		if includeUsage {
			body = strings.Replace(body, `"stream":true`, `"stream":true,"stream_options":{"include_usage":true}`, 1)
		}
		res := chat(t, ts, body)
		if res.status != 200 || res.header.Get("Content-Type") != "text/event-stream; charset=utf-8" || res.err != nil {
			t.Fatalf("%d %s %v", res.status, res.header.Get("Content-Type"), res.err)
		}
		events := parseSSE(t, res.body)
		want := 1 + words + 1 + 1 // role, words, finish, [DONE]
		if includeUsage {
			want++
		}
		if len(events) != want {
			t.Fatalf("include_usage %v: %d events, want %d: %s", includeUsage, len(events), want, res.body)
		}
		if last := events[len(events)-1]; last.name != "" || last.data != "[DONE]" {
			t.Errorf("the stream ends with %+v", last)
		}
		var streamed strings.Builder
		for i, e := range events[:len(events)-1] {
			if e.name != "" {
				t.Errorf("a Chat Completions event is named %q", e.name)
			}
			c := object(t, []byte(e.data))
			checkChunk(t, c)
			if c["id"] != full["id"] {
				t.Errorf("chunk %d has id %v", i, c["id"])
			}
			if _, present := c["usage"]; present != includeUsage {
				t.Errorf("include_usage %v, chunk %d: %s", includeUsage, i, e.data)
			}
			isUsage := includeUsage && i == len(events)-2
			if includeUsage && !isUsage && c["usage"] != nil {
				t.Errorf("chunk %d carries usage before the last: %s", i, e.data)
			}
			switch {
			case i == 0:
				if get(c, "choices", 0, "delta", "role") != "assistant" || get(c, "choices", 0, "delta", "content") != "" ||
					get(c, "choices", 0, "finish_reason") != nil || !has(c, "choices", 0, "finish_reason") {
					t.Errorf("first chunk %s", e.data)
				}
			case i <= words:
				streamed.WriteString(get(c, "choices", 0, "delta", "content").(string))
			case i == words+1:
				if get(c, "choices", 0, "finish_reason") != "stop" || len(get(c, "choices", 0, "delta").(map[string]any)) != 0 {
					t.Errorf("finish chunk %s", e.data)
				}
			case isUsage:
				if len(c["choices"].([]any)) != 0 || num(get(c, "usage", "prompt_tokens")) != num(get(full, "usage", "prompt_tokens")) ||
					num(get(c, "usage", "completion_tokens")) != num(get(full, "usage", "completion_tokens")) ||
					num(get(c, "usage", "total_tokens")) != num(get(full, "usage", "total_tokens")) {
					t.Errorf("usage chunk %s, want %v", e.data, get(full, "usage"))
				}
			}
		}
		if streamed.String() != text {
			t.Errorf("streamed %q, non-streaming %q", streamed.String(), text)
		}
	}
}

const chatWeatherTools = `"tools":[{"type":"function","function":{"name":"get_weather","description":"Weather now","parameters":{"type":"object","required":["city"],"properties":{"city":{"type":"string"}}}}}]`

func TestChatToolCalls(t *testing.T) {
	ts := start(t, Config{})
	body := `{"model":"m",` + chatWeatherTools + `,"messages":[{"role":"user","content":"[[fake-model tool=get_weather]]"}]}`
	m := object(t, chat(t, ts, body).body)
	call := get(m, "choices", 0, "message", "tool_calls", 0)
	if get(m, "choices", 0, "finish_reason") != "tool_calls" || get(m, "choices", 0, "message", "content") != nil ||
		!has(m, "choices", 0, "message", "content") || get(call, "type") != "function" ||
		get(call, "function", "name") != "get_weather" || get(call, "function", "arguments") != `{"city":"fake"}` ||
		!strings.HasPrefix(get(call, "id").(string), "call_fake_") {
		t.Fatalf("tool call %v", m)
	}
	res := chat(t, ts, strings.Replace(body, `"messages"`, `"stream":true,"stream_options":{"include_usage":true},"messages"`, 1))
	events := parseSSE(t, res.body)
	var args strings.Builder
	for i, e := range events[:len(events)-1] {
		c := object(t, []byte(e.data))
		tc := get(c, "choices", 0, "delta", "tool_calls", 0)
		switch {
		case i == 0:
			if get(c, "choices", 0, "delta", "role") != "assistant" || num(get(tc, "index")) != 0 || get(tc, "id") != get(call, "id") ||
				get(tc, "type") != "function" || get(tc, "function", "name") != "get_weather" || get(tc, "function", "arguments") != "" {
				t.Errorf("first chunk %s", e.data)
			}
		case tc != nil:
			if has(tc, "id") || has(tc, "function", "name") || num(get(tc, "index")) != 0 {
				t.Errorf("argument chunk %s", e.data)
			}
			args.WriteString(get(tc, "function", "arguments").(string))
		case get(c, "choices", 0, "finish_reason") != nil:
			if get(c, "choices", 0, "finish_reason") != "tool_calls" {
				t.Errorf("finish chunk %s", e.data)
			}
		}
	}
	if args.String() != `{"city":"fake"}` {
		t.Errorf("streamed arguments %q", args.String())
	}
}

func TestChatMaxTokens(t *testing.T) {
	ts := start(t, Config{})
	for body, want := range map[string]int{
		`"max_tokens":5`:                           5,
		`"max_completion_tokens":7`:                7,
		`"max_completion_tokens":7,"max_tokens":3`: 7,
	} {
		res := chat(t, ts, `{"model":"m",`+body+`,"messages":[{"role":"user","content":"[[fake-model tokens=50]]"}]}`)
		m := object(t, res.body)
		if get(m, "choices", 0, "finish_reason") != "length" || num(get(m, "usage", "completion_tokens")) != want {
			t.Errorf("%s: %s", body, res.body)
		}
	}
}

func TestChatInput(t *testing.T) {
	ts := start(t, Config{})
	body := `{"model":"m",` + chatWeatherTools + `,"messages":[
		{"role":"developer","content":[{"type":"text","text":"Be brief."}]},
		{"role":"user","content":[{"type":"text","text":"Look"},{"type":"image_url","image_url":{"url":"data:,"}}]},
		{"role":"assistant","content":null,"tool_calls":[{"id":"c1","type":"function","function":{"name":"look","arguments":"{\"b\":1,\"a\":2}"}}]},
		{"role":"tool","tool_call_id":"c1","content":"a cat"}]}`
	m := object(t, chat(t, ts, body).body)
	// developer 1+3; user 1+1+1 image; assistant 1+1 (look)+13
	// ({"a":2,"b":1}); tool 1+2; tool definition get _ weather 3 + 2 + its
	// schema
	schema, _ := model.Canonical([]byte(`{"type":"object","required":["city"],"properties":{"city":{"type":"string"}}}`))
	want := 4 + 3 + 15 + 3 + 3 + 2 + model.Count(string(schema))
	if got := num(get(m, "usage", "prompt_tokens")); got != want {
		t.Errorf("prompt tokens %d, want %d", got, want)
	}
}

func TestChatErrors(t *testing.T) {
	ts := start(t, Config{})
	check := func(name string, res *response, status int, typ, code, msg string) {
		t.Helper()
		m := object(t, res.body)
		if res.status != status || get(m, "error", "type") != typ || !strings.Contains(get(m, "error", "message").(string), msg) ||
			!has(m, "error", "param") || !has(m, "error", "code") {
			t.Errorf("%s: %d %s", name, res.status, res.body)
		}
		if c, _ := get(m, "error", "code").(string); c != code {
			t.Errorf("%s: code %q, want %q", name, c, code)
		}
	}
	check("no model", chat(t, ts, `{"messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "", "you must provide a model parameter")
	check("no messages", chat(t, ts, `{"model":"m"}`), 400, "invalid_request_error", "", "'messages' is a required property")
	check("empty messages", chat(t, ts, `{"model":"m","messages":[]}`), 400, "invalid_request_error", "", "at least one message")
	check("role", chat(t, ts, `{"model":"m","messages":[{"role":"robot","content":"x"}]}`), 400, "invalid_request_error", "", "Invalid value: 'robot'")
	check("n", chat(t, ts, `{"model":"m","n":2,"messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "", "n must be 1")
	check("context", chat(t, ts, `{"model":"m","messages":[{"role":"user","content":"a b [[fake-model context=3]]"}]}`), 400,
		"invalid_request_error", "context_length_exceeded", "maximum context length is 3 tokens. However, your messages resulted in 13 tokens")
	check("not found", post(t, ts.URL+"/v1/responses", nil, chatHello), 404, "invalid_request_error", "", "Invalid URL (POST /v1/responses)")
	if m := object(t, chat(t, ts, `{"model":"m","messages":[{"role":"user","content":"a b [[fake-model context=3]]"}]}`).body); get(m, "error", "param") != "messages" {
		t.Errorf("context_length_exceeded names param %v", get(m, "error", "param"))
	}
}

func TestStreamPacing(t *testing.T) {
	ts := start(t, Config{Interval: 20 * time.Millisecond})
	began := time.Now()
	res := chat(t, ts, `{"model":"m","stream":true,"messages":[{"role":"user","content":"[[fake-model tokens=5]]"}]}`)
	if elapsed := time.Since(began); res.status != 200 || elapsed < 100*time.Millisecond {
		t.Errorf("five deltas paced at 20ms took %v", elapsed)
	}
	began = time.Now()
	chat(t, ts, `{"model":"m","messages":[{"role":"user","content":"[[fake-model tokens=5]]"}]}`)
	if elapsed := time.Since(began); elapsed > 80*time.Millisecond {
		t.Errorf("a body was paced: %v", elapsed)
	}
}

// A call of a tool the request does not declare, with an argument, and a
// reported usage, through both APIs: what an injection canary and a token
// cap need.
func TestUndeclaredCallAndUsage(t *testing.T) {
	ts := start(t, Config{})
	directive := `[[fake-model call=add_note arg.text=planted-1 usage=30000]]`
	m := object(t, chat(t, ts, `{"model":"m",`+chatWeatherTools+`,"messages":[{"role":"user","content":"`+directive+`"}]}`).body)
	call := get(m, "choices", 0, "message", "tool_calls", 0)
	if get(call, "function", "name") != "add_note" || get(call, "function", "arguments") != `{"text":"planted-1"}` ||
		num(get(m, "usage", "completion_tokens")) != 30000 || num(get(m, "usage", "total_tokens")) != 30000+num(get(m, "usage", "prompt_tokens")) {
		t.Fatalf("chat completions: %v", m)
	}
	r := messages(t, ts, `{"model":"m","max_tokens":10,"messages":[{"role":"user","content":"`+directive+`"}]}`)
	b := object(t, r.body)
	if get(b, "content", 0, "type") != "tool_use" || get(b, "content", 0, "name") != "add_note" ||
		get(b, "content", 0, "input", "text") != "planted-1" || num(get(b, "usage", "output_tokens")) != 30000 {
		t.Fatalf("messages: %s", r.body)
	}
}

// parallel=3: one reply with three calls of the tool, in both APIs, as a
// body and as a stream, each call with its own ID and index.
func TestParallelToolCalls(t *testing.T) {
	ts := start(t, Config{})
	directive := `[[fake-model tool=get_weather parallel=3]]`
	body := `{"model":"m",` + chatWeatherTools + `,"messages":[{"role":"user","content":"` + directive + `"}]}`
	m := object(t, chat(t, ts, body).body)
	calls, _ := get(m, "choices", 0, "message", "tool_calls").([]any)
	if len(calls) != 3 || get(calls[1], "id") != get(calls[0], "id").(string)+"_2" || get(calls[2], "function", "arguments") != `{"city":"fake"}` {
		t.Fatalf("chat completions body: %v", m)
	}
	one := object(t, chat(t, ts, strings.Replace(body, " parallel=3", "", 1)).body)
	if num(get(m, "usage", "completion_tokens")) != 3*num(get(one, "usage", "completion_tokens")) {
		t.Errorf("three calls' tokens %v, one call's %v", get(m, "usage"), get(one, "usage"))
	}
	events := parseSSE(t, chat(t, ts, strings.Replace(body, `"messages"`, `"stream":true,"messages"`, 1)).body)
	args := map[int]string{}
	ids := map[int]string{}
	for _, e := range events[:len(events)-1] {
		c := object(t, []byte(e.data))
		if tc := get(c, "choices", 0, "delta", "tool_calls", 0); tc != nil {
			i := num(get(tc, "index"))
			if id, ok := get(tc, "id").(string); ok {
				ids[i] = id
			}
			args[i] += get(tc, "function", "arguments").(string)
		}
	}
	if len(args) != 3 || args[2] != `{"city":"fake"}` || ids[2] != ids[0]+"_3" {
		t.Errorf("chat completions stream: args %v, ids %v", args, ids)
	}

	mb := object(t, messages(t, ts, `{"model":"m","max_tokens":100,`+weatherTools+`,"messages":[{"role":"user","content":"`+directive+`"}]}`).body)
	blocks, _ := get(mb, "content").([]any)
	if len(blocks) != 3 || get(blocks[2], "type") != "tool_use" || get(blocks[2], "id") != get(blocks[0], "id").(string)+"_3" {
		t.Fatalf("messages body: %v", mb)
	}
	ev := parseSSE(t, messages(t, ts, `{"model":"m","max_tokens":100,"stream":true,`+weatherTools+`,"messages":[{"role":"user","content":"`+directive+`"}]}`).body)
	starts, stops := 0, 0
	for _, e := range ev {
		switch e.name {
		case "content_block_start":
			starts++
		case "content_block_stop":
			stops++
		}
	}
	if starts != 3 || stops != 3 || ev[0].name != "message_start" || ev[2].name != "ping" {
		t.Errorf("messages stream: %s", names(ev))
	}
}
