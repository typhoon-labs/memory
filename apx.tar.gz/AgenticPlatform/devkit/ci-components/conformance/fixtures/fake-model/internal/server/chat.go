package server

import (
	"encoding/json"
	"fmt"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/model"
)

// OpenAI's Chat Completions (developers.openai.com/api/reference, checked
// 2026-11-16; the wire samples in agentgateway v1.7.0's
// crates/llm/src/tests/response/completions).

var chatRoles = map[string]string{
	"system": "system", "developer": "system", // a system prompt, as in Messages
	"user": "user", "assistant": "assistant", "tool": "tool", "function": "function",
}

// parseChat reads a Chat Completions request.
func parseChat(body []byte) (*request, error) {
	top, err := fields(body)
	if err != nil {
		return nil, err
	}
	conv := &model.Conversation{}
	if conv.Model, _ = str(top["model"], "model", false); conv.Model == "" {
		return nil, fmt.Errorf("you must provide a model parameter")
	}
	req := &request{conv: conv}
	if req.stream, err = boolean(top["stream"], "stream"); err != nil {
		return nil, err
	}
	if opts := top["stream_options"]; !absent(opts) {
		var o struct {
			IncludeUsage *bool `json:"include_usage"`
		}
		if err := json.Unmarshal(opts, &o); err != nil {
			return nil, fmt.Errorf("stream_options: Input should be a valid object")
		}
		req.includeUsage = o.IncludeUsage != nil && *o.IncludeUsage
	}
	// max_completion_tokens replaces the deprecated max_tokens.
	if conv.MaxTokens, err = positive(top["max_completion_tokens"], "max_completion_tokens"); err != nil {
		return nil, err
	}
	if conv.MaxTokens == 0 {
		if conv.MaxTokens, err = positive(top["max_tokens"], "max_tokens"); err != nil {
			return nil, err
		}
	}
	if n, err := positive(top["n"], "n"); err != nil || n > 1 {
		return nil, fmt.Errorf("n: the fake model returns one choice; n must be 1")
	}
	if absent(top["messages"]) {
		return nil, fmt.Errorf("'messages' is a required property")
	}
	msgs, err := objects(top["messages"], "messages")
	if err != nil {
		return nil, err
	}
	if len(msgs) == 0 {
		return nil, fmt.Errorf("'messages' must contain at least one message")
	}
	for i, m := range msgs {
		path := fmt.Sprintf("messages[%d]", i)
		role, err := str(m["role"], path+".role", true)
		if err != nil {
			return nil, err
		}
		neutral, ok := chatRoles[role]
		if !ok {
			return nil, fmt.Errorf("Invalid value: '%s'. Supported values are: 'system', 'developer', 'user', 'assistant', 'tool' and 'function'. (%s.role)", role, path)
		}
		msg := model.Message{Role: neutral}
		if c := m["content"]; !absent(c) {
			if msg.Texts, msg.Others, err = chatContent(c, path+".content"); err != nil {
				return nil, err
			}
		}
		if calls := m["tool_calls"]; !absent(calls) {
			list, err := objects(calls, path+".tool_calls")
			if err != nil {
				return nil, err
			}
			for j, c := range list {
				name, args, err := chatFunction(c["function"], fmt.Sprintf("%s.tool_calls[%d].function", path, j))
				if err != nil {
					return nil, err
				}
				msg.Texts = append(msg.Texts, name, args)
			}
		}
		if fc := m["function_call"]; !absent(fc) {
			name, args, err := chatFunction(fc, path+".function_call")
			if err != nil {
				return nil, err
			}
			msg.Texts = append(msg.Texts, name, args)
		}
		conv.Messages = append(conv.Messages, msg)
	}
	if tools := top["tools"]; !absent(tools) {
		list, err := objects(tools, "tools")
		if err != nil {
			return nil, err
		}
		for i, t := range list {
			path := fmt.Sprintf("tools[%d]", i)
			fn := t["function"]
			if absent(fn) {
				// A tool of another type (custom tools) has only its type to count.
				typ, _ := str(t["type"], path+".type", false)
				conv.Tools = append(conv.Tools, model.Tool{Name: typ})
				continue
			}
			var f map[string]json.RawMessage
			if json.Unmarshal(fn, &f) != nil || f == nil {
				return nil, fmt.Errorf("%s.function: Input should be a valid object", path)
			}
			name, err := str(f["name"], path+".function.name", true)
			if err != nil {
				return nil, err
			}
			desc, err := str(f["description"], path+".function.description", false)
			if err != nil {
				return nil, err
			}
			tool := model.Tool{Name: name, Description: desc}
			if p := f["parameters"]; !absent(p) {
				c, ok := model.Canonical(p)
				if !ok {
					return nil, fmt.Errorf("%s.function.parameters: Input should be a valid object", path)
				}
				tool.Schema = c
			}
			conv.Tools = append(conv.Tools, tool)
		}
	}
	return req, nil
}

// chatContent reads a string or a list of content parts.
func chatContent(raw json.RawMessage, path string) (texts []string, others int, err error) {
	var s string
	if json.Unmarshal(raw, &s) == nil {
		return []string{s}, 0, nil
	}
	parts, err := objects(raw, path)
	if err != nil {
		return nil, 0, fmt.Errorf("%s: Input should be a string or a list of content parts", path)
	}
	for i, p := range parts {
		pp := fmt.Sprintf("%s[%d]", path, i)
		typ, err := str(p["type"], pp+".type", true)
		if err != nil {
			return nil, 0, err
		}
		switch typ {
		case "text", "refusal":
			t, err := str(p[typ], pp+"."+typ, true)
			if err != nil {
				return nil, 0, err
			}
			texts = append(texts, t)
		default:
			others++
		}
	}
	return texts, others, nil
}

// chatFunction reads a tool call's function: its name and its arguments in
// canonical JSON, or as sent if they are not JSON.
func chatFunction(raw json.RawMessage, path string) (name, args string, err error) {
	var f map[string]json.RawMessage
	if json.Unmarshal(raw, &f) != nil || f == nil {
		return "", "", fmt.Errorf("%s: Input should be a valid object", path)
	}
	if name, err = str(f["name"], path+".name", true); err != nil {
		return "", "", err
	}
	if args, err = str(f["arguments"], path+".arguments", false); err != nil {
		return "", "", err
	}
	if c, ok := model.Canonical([]byte(args)); ok {
		args = string(c)
	}
	return name, args, nil
}

// Response shapes, in the API's field order.

type chatUsage struct {
	PromptTokens        int `json:"prompt_tokens"`
	CompletionTokens    int `json:"completion_tokens"`
	TotalTokens         int `json:"total_tokens"`
	PromptTokensDetails struct {
		CachedTokens int `json:"cached_tokens"`
	} `json:"prompt_tokens_details"`
	CompletionTokensDetails struct {
		ReasoningTokens int `json:"reasoning_tokens"`
	} `json:"completion_tokens_details"`
}

func usageOf(r *model.Reply) *chatUsage {
	return &chatUsage{PromptTokens: r.InputTokens, CompletionTokens: r.OutputTokens, TotalTokens: r.InputTokens + r.OutputTokens}
}

type chatFunctionCall struct {
	Name      string `json:"name,omitempty"`
	Arguments string `json:"arguments"`
}

type chatToolCall struct {
	Index    *int             `json:"index,omitempty"`
	ID       string           `json:"id,omitempty"`
	Type     string           `json:"type,omitempty"`
	Function chatFunctionCall `json:"function"`
}

type chatMessage struct {
	Role        string         `json:"role"`
	Content     *string        `json:"content"`
	Refusal     *string        `json:"refusal"`
	Annotations []any          `json:"annotations"`
	ToolCalls   []chatToolCall `json:"tool_calls,omitempty"`
}

type chatChoice struct {
	Index        int         `json:"index"`
	Message      chatMessage `json:"message"`
	Logprobs     *struct{}   `json:"logprobs"`
	FinishReason string      `json:"finish_reason"`
}

type chatCompletion struct {
	ID                string       `json:"id"`
	Object            string       `json:"object"`
	Created           int64        `json:"created"`
	Model             string       `json:"model"`
	Choices           []chatChoice `json:"choices"`
	Usage             *chatUsage   `json:"usage"`
	ServiceTier       string       `json:"service_tier"`
	SystemFingerprint *string      `json:"system_fingerprint"`
}

func finishReason(r model.StopReason) string {
	switch r {
	case model.MaxTokens:
		return "length"
	case model.ToolUse:
		return "tool_calls"
	}
	return "stop"
}

func completionID(r *model.Reply) string { return "chatcmpl-fake" + r.ID }

func callID(r *model.Reply) string { return "call_fake_" + r.ID }

// chatBody is the non-streaming response.
func chatBody(req *request, r *model.Reply) []byte {
	msg := chatMessage{Role: "assistant", Annotations: []any{}}
	if r.ToolCall != nil {
		for i := range max(1, r.Calls) {
			msg.ToolCalls = append(msg.ToolCalls, chatToolCall{ID: nthID(callID(r), i), Type: "function",
				Function: chatFunctionCall{Name: r.ToolCall.Name, Arguments: string(r.ToolCall.Input)}})
		}
	} else {
		text := r.Text()
		msg.Content = &text
	}
	return mustJSON(chatCompletion{
		ID: completionID(r), Object: "chat.completion", Created: Created, Model: req.conv.Model,
		Choices:     []chatChoice{{Index: 0, Message: msg, FinishReason: finishReason(r.StopReason)}},
		Usage:       usageOf(r),
		ServiceTier: "default",
	})
}

type chatDelta struct {
	Role      string         `json:"role,omitempty"`
	Content   *string        `json:"content,omitempty"`
	ToolCalls []chatToolCall `json:"tool_calls,omitempty"`
}

type chatChunkChoice struct {
	Index        int       `json:"index"`
	Delta        chatDelta `json:"delta"`
	Logprobs     *struct{} `json:"logprobs"`
	FinishReason *string   `json:"finish_reason"`
}

// chatChunk has two forms: usage is omitted unless the request asked for
// it with stream_options.include_usage, and then it is null on every chunk
// but the last.
type chatChunk struct {
	ID                string            `json:"id"`
	Object            string            `json:"object"`
	Created           int64             `json:"created"`
	Model             string            `json:"model"`
	ServiceTier       string            `json:"service_tier"`
	SystemFingerprint *string           `json:"system_fingerprint"`
	Choices           []chatChunkChoice `json:"choices"`
}

type chatChunkWithUsage struct {
	chatChunk
	Usage *chatUsage `json:"usage"`
}

// chatOpening is the number of events before the first content delta: the
// chunk with the role.
const chatOpening = 1

// chatEvents is the streaming response: a chunk with the role, a chunk per
// content delta, a chunk with the finish reason, with include_usage a
// chunk with no choices and the usage, and data: [DONE].
func chatEvents(req *request, r *model.Reply) []event {
	chunk := func(choices []chatChunkChoice, usage *chatUsage) event {
		c := chatChunk{ID: completionID(r), Object: "chat.completion.chunk", Created: Created, Model: req.conv.Model,
			ServiceTier: "default", Choices: choices}
		if req.includeUsage {
			return event{data: mustJSON(chatChunkWithUsage{chatChunk: c, Usage: usage})}
		}
		return event{data: mustJSON(c)}
	}
	zero := 0
	first := chatDelta{Role: "assistant"}
	if r.ToolCall != nil {
		first.ToolCalls = []chatToolCall{{Index: &zero, ID: callID(r), Type: "function",
			Function: chatFunctionCall{Name: r.ToolCall.Name, Arguments: ""}}}
	} else {
		empty := ""
		first.Content = &empty
	}
	out := []event{chunk([]chatChunkChoice{{Delta: first}}, nil)}
	calls := 1
	if r.ToolCall != nil {
		calls = max(1, r.Calls)
	}
	for i := range calls {
		index := i
		if i > 0 {
			// A further parallel call opens with its ID and name, as the
			// first did with the role.
			out = append(out, chunk([]chatChunkChoice{{Delta: chatDelta{ToolCalls: []chatToolCall{{Index: &index, ID: nthID(callID(r), i),
				Type: "function", Function: chatFunctionCall{Name: r.ToolCall.Name, Arguments: ""}}}}}}, nil))
		}
		for _, d := range r.Deltas() {
			delta := chatDelta{}
			if r.ToolCall != nil {
				delta.ToolCalls = []chatToolCall{{Index: &index, Function: chatFunctionCall{Arguments: d}}}
			} else {
				text := d
				delta.Content = &text
			}
			e := chunk([]chatChunkChoice{{Delta: delta}}, nil)
			e.delta = true
			out = append(out, e)
		}
	}
	finish := finishReason(r.StopReason)
	out = append(out, chunk([]chatChunkChoice{{Delta: chatDelta{}, FinishReason: &finish}}, nil))
	if req.includeUsage {
		out = append(out, chunk([]chatChunkChoice{}, usageOf(r)))
	}
	return append(out, event{data: []byte("[DONE]")})
}
