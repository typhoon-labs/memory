package server

import (
	"sync"
	"time"
)

// Record is what the fake model keeps of a request, for suites that must
// observe the calls a workload or the gateway made: how many attempts a
// retry policy sent and how far apart, whether a caller's credential
// reached the model, whether a trace continued. It holds no content.
type Record struct {
	Time   time.Time `json:"time"`
	API    string    `json:"api"`
	Method string    `json:"method"`
	Path   string    `json:"path"`
	Model  string    `json:"model,omitempty"`
	Stream bool      `json:"stream"`
	// Directive is the directive as written, and DirectiveID its id.
	Directive   string `json:"directive,omitempty"`
	DirectiveID string `json:"directive_id,omitempty"`
	// Attempt is the request's number among those carrying the same
	// directive (by id, or as written), from 1.
	Attempt int `json:"attempt,omitempty"`
	// Fault lists the faults applied, comma-separated, in the order they
	// act: delay, interval, then status, after, cut, truncate, stall or
	// reset.
	Fault string `json:"fault,omitempty"`
	// Status is the HTTP status answered with.
	Status       int    `json:"status"`
	Error        string `json:"error,omitempty"`
	InputTokens  int    `json:"input_tokens"`
	OutputTokens int    `json:"output_tokens"`
	// Credentials names the credential headers the request carried
	// (Authorization, X-Api-Key, Proxy-Authorization), never their values.
	Credentials      []string `json:"credentials"`
	Traceparent      string   `json:"traceparent,omitempty"`
	AnthropicVersion string   `json:"anthropic_version,omitempty"`
	AnthropicBeta    string   `json:"anthropic_beta,omitempty"`

	kept bool
}

// ring keeps the latest records.
type ring struct {
	mu   sync.Mutex
	recs []Record
	next int
	full bool
}

func newRing(n int) *ring { return &ring{recs: make([]Record, n)} }

func (g *ring) add(r *Record) {
	g.mu.Lock()
	defer g.mu.Unlock()
	r.kept = true
	g.recs[g.next] = *r
	g.next = (g.next + 1) % len(g.recs)
	if g.next == 0 {
		g.full = true
	}
}

// list returns the records, oldest first, of one directive id or, if id
// is empty, all of them.
func (g *ring) list(id string) []Record {
	g.mu.Lock()
	defer g.mu.Unlock()
	var all []Record
	if g.full {
		all = append(all, g.recs[g.next:]...)
	}
	all = append(all, g.recs[:g.next]...)
	out := []Record{}
	for _, r := range all {
		if !r.Time.IsZero() && (id == "" || r.DirectiveID == id) {
			out = append(out, r)
		}
	}
	return out
}

// clear drops the records of one directive id or, if id is empty, all.
func (g *ring) clear(id string) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if id == "" {
		clear(g.recs)
		g.next, g.full = 0, false
		return
	}
	for i := range g.recs {
		if g.recs[i].DirectiveID == id {
			g.recs[i] = Record{} // its slot stays, empty, and lists as nothing
		}
	}
}

// counter counts the requests carrying each directive. It forgets
// everything once it holds a million keys, a bound no suite reaches.
type counter struct {
	mu sync.Mutex
	n  map[string]int
}

func newCounter() *counter { return &counter{n: map[string]int{}} }

func (c *counter) next(key string) int {
	c.mu.Lock()
	defer c.mu.Unlock()
	if len(c.n) >= 1_000_000 {
		clear(c.n)
	}
	c.n[key]++
	return c.n[key]
}

// reset forgets one directive's count, by its id, or every count.
func (c *counter) reset(id string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if id == "" {
		clear(c.n)
		return
	}
	delete(c.n, "id:"+id)
}
