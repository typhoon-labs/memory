package model

import (
	"strings"
	"testing"
	"time"
)

func TestCount(t *testing.T) {
	for s, want := range map[string]int{
		"":                        0,
		"   \n\t":                 0,
		"Hello, world!":           4,
		"one two  three":          3,
		"abc123def":               1,
		`{"a":1}`:                 7,
		"naïve café":              2,
		"x-y_z":                   5,
		"日本語 テキスト":                2,
		"[[fake-model tokens=5]]": 10,
	} {
		if got := Count(s); got != want {
			t.Errorf("Count(%q) = %d, want %d", s, got, want)
		}
	}
}

func TestInputTokens(t *testing.T) {
	c := &Conversation{
		Model: "m",
		Messages: []Message{
			{Role: "system", Texts: []string{"Be brief."}},              // 1 + 3
			{Role: "user", Texts: []string{"Hello, world!"}, Others: 2}, // 1 + 4 + 2
		},
		Tools: []Tool{{Name: "get_weather", Description: "Weather now", Schema: []byte(`{"type":"object"}`)}}, // get _ weather: 3, then 2 + 9
	}
	if got, want := c.InputTokens(), 4+7+14; got != want {
		t.Errorf("InputTokens = %d, want %d", got, want)
	}
}

func TestCanonical(t *testing.T) {
	got, ok := Canonical([]byte(` { "b" : [1, 2.50], "a" : "<x>" } `))
	if !ok || string(got) != `{"a":"<x>","b":[1,2.50]}` {
		t.Errorf("Canonical = %s, %v", got, ok)
	}
	if _, ok := Canonical([]byte(`{"a":1} {"b":2}`)); ok {
		t.Error("two values were accepted")
	}
	if _, ok := Canonical([]byte(`{"a":`)); ok {
		t.Error("broken JSON was accepted")
	}
}

func TestHashIgnoresMaxTokensButNotContent(t *testing.T) {
	a := &Conversation{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"hi"}}}}
	b := *a
	b.MaxTokens = 7
	if a.ID() != b.ID() {
		t.Error("max_tokens changed the conversation's ID")
	}
	for _, other := range []*Conversation{
		{Model: "n", Messages: a.Messages},
		{Model: "m", Messages: []Message{{Role: "assistant", Texts: []string{"hi"}}}},
		{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"h", "i"}}}},
		{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"hi"}, Others: 1}}},
		{Model: "m", Messages: a.Messages, Tools: []Tool{{Name: "t"}}},
	} {
		if other.ID() == a.ID() {
			t.Errorf("%+v has the same ID as %+v", other, a)
		}
	}
	if len(a.ID()) != 24 {
		t.Errorf("ID %q is not 24 hex digits", a.ID())
	}
}

func TestParse(t *testing.T) {
	d, err := Parse("raw", " id=r1 times=2 status=429 retry-after=3 delay=250ms interval=10ms tokens=5 tool=* context=100")
	if err != nil {
		t.Fatal(err)
	}
	if d.ID != "r1" || d.Times != 2 || d.Status != 429 || d.RetryAfter != 3 || d.Delay != 250*time.Millisecond ||
		d.Interval != 10*time.Millisecond || d.Tokens != 5 || d.Tool != "*" || d.Context != 100 || d.After != -1 || d.Cut != -1 {
		t.Errorf("parsed %+v", d)
	}
	for body, want := range map[string]Directive{
		" cut":                {Cut: 0, Truncate: -1, Stall: -1, After: -1},
		" cut=40":             {Cut: 40, Truncate: -1, Stall: -1, After: -1},
		" truncate":           {Cut: -1, Truncate: 0, Stall: -1, After: -1},
		" stall=3":            {Cut: -1, Truncate: -1, Stall: 3, After: -1},
		" status=529 after=2": {Cut: -1, Truncate: -1, Stall: -1, After: 2, Status: 529},
		" reset":              {Cut: -1, Truncate: -1, Stall: -1, After: -1, Reset: true},
	} {
		d, err := Parse("raw", body)
		if err != nil {
			t.Errorf("%q: %v", body, err)
			continue
		}
		if d.Cut != want.Cut || d.Truncate != want.Truncate || d.Stall != want.Stall || d.After != want.After || d.Status != want.Status || d.Reset != want.Reset {
			t.Errorf("%q parsed as %+v", body, d)
		}
	}
	for body, why := range map[string]string{
		" bogus=1":                  "unknown key",
		" status=200":               "from 400 to 599",
		" status=abc":               "from 400 to 599",
		" status":                   "needs a value",
		" times=0":                  "from 1",
		" tokens=100001":            "from 0 to 100000",
		" delay=soon":               "duration",
		" delay=-1s":                "duration",
		" id=has space":             "unknown key", // "space" is read as a bare key
		" id=a/b":                   "id must be",
		" tool=":                    "tool needs",
		" reset=yes":                "takes no value",
		" status=500 status=502":    "given twice",
		" cut=1 stall=2":            "cannot be combined",
		" echo":                     "echo needs status",
		" status=400 echo=1":        "echo takes no value",
		" after=2":                  "after needs status",
		" status=500 cut=2":         "cannot be combined with cut",
		" status=500 after=1 cut=2": "cannot be combined",
		" call=":                    "call needs",
		" call=a/b":                 "call needs",
		" tool=x call=y":            "cannot be combined",
		" arg.text=x":               "arg.* needs tool or call",
		" call=x arg.text":          "arg.text needs a value",
		" call=x arg.a/b=1":         "argument's name",
		" call=x arg.t=1 arg.t=2":   "given twice",
		" usage=0":                  "from 1 to 100000000",
		" usage":                    "needs a value",
		" parallel=2":               "parallel needs tool or call",
		" tool=x parallel=1":        "from 2 to 16",
		" tool=x parallel=17":       "from 2 to 16",
	} {
		if _, err := Parse("raw", body); err == nil || !strings.Contains(err.Error(), why) {
			t.Errorf("%q: got %v, want an error containing %q", body, err, why)
		}
	}
}

func TestFaulty(t *testing.T) {
	for body, want := range map[string]bool{
		"":                 false,
		" tokens=3 tool=x": false,
		" id=a times=2":    false,
		" delay=0s":        false,
		" delay=1ms":       true,
		" interval=0s":     true,
		" status=429":      true,
		" cut":             true,
		" truncate":        true,
		" stall":           true,
		" reset":           true,
	} {
		d, err := Parse("raw", body)
		if err != nil {
			t.Fatalf("%q: %v", body, err)
		}
		if d.Faulty() != want {
			t.Errorf("%q: Faulty = %v", body, d.Faulty())
		}
		if w := d.WithoutFaults(); w.Faulty() || w.Tokens != d.Tokens || w.Tool != d.Tool || w.ID != d.ID {
			t.Errorf("%q: WithoutFaults = %+v", body, w)
		}
	}
}

func TestFind(t *testing.T) {
	c := &Conversation{Messages: []Message{
		{Role: "system", Texts: []string{"[[fake-model id=system]]"}},
		{Role: "user", Texts: []string{"first [[fake-model id=a]] then [[fake-model id=b]]", "[[fake-model id=c]]"}},
		{Role: "assistant", Texts: []string{"no directive here"}},
		{Role: "user", Texts: []string{"a tool result"}},
	}}
	d, err := Find(c)
	if err != nil || d == nil || d.ID != "c" || d.Raw != "[[fake-model id=c]]" {
		t.Fatalf("Find = %+v, %v; want the last text's directive", d, err)
	}
	c.Messages[1].Texts = c.Messages[1].Texts[:1]
	if d, _ := Find(c); d == nil || d.ID != "b" {
		t.Errorf("Find = %+v; want a text's last directive", d)
	}
	c.Messages[1].Texts = nil
	if d, _ := Find(c); d == nil || d.ID != "system" {
		t.Errorf("Find = %+v; want the system prompt's directive", d)
	}
	c.Messages[0].Texts = nil
	if d, err := Find(c); d != nil || err != nil {
		t.Errorf("Find = %+v, %v; want none", d, err)
	}
	c.Messages[3].Texts = []string{"[[fake-model status=429"}
	if _, err := Find(c); err == nil || !strings.Contains(err.Error(), "not closed") {
		t.Errorf("an unclosed directive gave %v", err)
	}
	c.Messages[3].Texts = []string{"[[fake-model statu=429]]"}
	if _, err := Find(c); err == nil {
		t.Error("a misspelt key was accepted")
	}
	c.Messages[3].Texts = []string{"[[fake-modelx]] is not a directive"}
	if _, err := Find(c); err == nil {
		t.Error("[[fake-modelx]] was not reported")
	}
	c.Messages[3].Texts = []string{"[[fake-model]]"}
	if d, err := Find(c); err != nil || d == nil || d.Faulty() {
		t.Errorf("an empty directive gave %+v, %v", d, err)
	}
}

func TestPlanIsDeterministic(t *testing.T) {
	c := &Conversation{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"Hello"}}}}
	a, _ := Plan(c, nil)
	b, _ := Plan(c, nil)
	if a.Text() != b.Text() || a.ID != b.ID || a.OutputTokens != b.OutputTokens {
		t.Error("the same conversation got two replies")
	}
	if n := len(a.Words); n < 8 || n > 32 || a.OutputTokens != n || Count(a.Text()) != n {
		t.Errorf("%d words, %d output tokens, text counts %d", n, a.OutputTokens, Count(a.Text()))
	}
	if a.StopReason != EndTurn || a.InputTokens != c.InputTokens() {
		t.Errorf("reply %+v", a)
	}
	c2 := &Conversation{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"Hello!"}}}}
	if r, _ := Plan(c2, nil); r.Text() == a.Text() {
		t.Error("two conversations got the same reply")
	}
	if strings.Contains(a.Text(), "[[") {
		t.Error("a reply can contain a directive")
	}
}

func TestPlanTokensAndMaxTokens(t *testing.T) {
	c := &Conversation{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"Hello"}}}}
	d := &Directive{Tokens: 100, RetryAfter: -1, After: -1, Interval: -1, Cut: -1, Truncate: -1, Stall: -1}
	r, _ := Plan(c, d)
	if r.OutputTokens != 100 || len(r.Words) != 100 || Count(r.Text()) != 100 || r.StopReason != EndTurn {
		t.Errorf("tokens=100 gave %d tokens, stop %v", r.OutputTokens, r.StopReason)
	}
	if len(r.Deltas()) != 100 || strings.Join(r.Deltas(), "") != r.Text() {
		t.Error("the deltas do not add up to the text")
	}
	c.MaxTokens = 10
	r, _ = Plan(c, d)
	if r.OutputTokens != 10 || len(r.Words) != 10 || r.StopReason != MaxTokens {
		t.Errorf("max_tokens 10 gave %d tokens, stop %v", r.OutputTokens, r.StopReason)
	}
	d.Tokens = 0
	r, _ = Plan(c, d)
	if r.OutputTokens != 0 || r.Text() != "" || len(r.Deltas()) != 0 || r.StopReason != EndTurn {
		t.Errorf("tokens=0 gave %+v", r)
	}
}

func TestPlanToolCall(t *testing.T) {
	schema, _ := Canonical([]byte(`{"type":"object","required":["city","units","days","exact","tags","when","opts"],
		"properties":{"city":{"type":"string"},"units":{"enum":["c","f"]},"days":{"type":"integer"},
		"exact":{"type":["null","boolean"]},"tags":{"type":"array"},"when":{"type":"string","default":"now"},
		"opts":{"type":"object","required":["n"],"properties":{"n":{"type":"number"}}},
		"ignored":{"type":"string"}}}`))
	c := &Conversation{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"weather?"}}},
		Tools: []Tool{{Name: "noop"}, {Name: "get_weather", Schema: schema}}}
	d := &Directive{Tool: "get_weather", Tokens: -1, RetryAfter: -1, After: -1, Interval: -1, Cut: -1, Truncate: -1, Stall: -1}
	r, err := Plan(c, d)
	if err != nil {
		t.Fatal(err)
	}
	want := `{"city":"fake","days":0,"exact":false,"opts":{"n":0},"tags":[],"units":"c","when":"now"}`
	if r.ToolCall == nil || r.ToolCall.Name != "get_weather" || string(r.ToolCall.Input) != want {
		t.Fatalf("tool call %+v", r.ToolCall)
	}
	if r.StopReason != ToolUse || r.Text() != "" || r.OutputTokens != Count("get_weather")+Count(want) {
		t.Errorf("reply %+v", r)
	}
	if strings.Join(r.Deltas(), "") != want {
		t.Error("the deltas do not add up to the input")
	}
	for _, p := range r.Deltas() {
		if len([]rune(p)) > 8 {
			t.Errorf("delta %q is longer than eight characters", p)
		}
	}
	d.Tool = "*"
	if r, _ := Plan(c, d); r.ToolCall.Name != "noop" || string(r.ToolCall.Input) != "{}" {
		t.Errorf("tool=* called %+v", r.ToolCall)
	}
	d.Tool = "missing"
	if _, err := Plan(c, d); err == nil {
		t.Error("an undeclared tool was called")
	}
	c.Tools = nil
	d.Tool = "*"
	if _, err := Plan(c, d); err == nil {
		t.Error("tool=* without tools was accepted")
	}
}

// call names any tool, declared or not; args set top-level members over the
// schema's sample; usage replaces the reported output tokens.
func TestPlanCallArgsUsage(t *testing.T) {
	schema, _ := Canonical([]byte(`{"type":"object","required":["text","n"],"properties":{"text":{"type":"string"},"n":{"type":"integer"}}}`))
	c := &Conversation{Model: "m", Messages: []Message{{Role: "user", Texts: []string{"notes?"}}},
		Tools: []Tool{{Name: "list_notes"}, {Name: "add_note", Schema: schema}}}
	base := Directive{Tokens: -1, RetryAfter: -1, After: -1, Interval: -1, Cut: -1, Truncate: -1, Stall: -1}

	d := base
	d.Call, d.Args = "delete_everything", map[string]string{"why": "planted"}
	r, err := Plan(c, &d)
	if err != nil {
		t.Fatal(err)
	}
	if r.ToolCall == nil || r.ToolCall.Name != "delete_everything" || string(r.ToolCall.Input) != `{"why":"planted"}` || r.StopReason != ToolUse {
		t.Fatalf("an undeclared call: %+v", r.ToolCall)
	}
	if r.OutputTokens != Count("delete_everything")+Count(`{"why":"planted"}`) {
		t.Errorf("output tokens %d", r.OutputTokens)
	}

	d = base
	d.Call, d.Args = "add_note", map[string]string{"text": "canary-1"}
	r, _ = Plan(c, &d)
	if string(r.ToolCall.Input) != `{"n":0,"text":"canary-1"}` {
		t.Errorf("a declared tool's call keeps its schema's sample under the args: %s", r.ToolCall.Input)
	}

	d = base
	d.Tool, d.Args = "add_note", map[string]string{"text": "x"}
	r, _ = Plan(c, &d)
	if r.ToolCall.Name != "add_note" || string(r.ToolCall.Input) != `{"n":0,"text":"x"}` {
		t.Errorf("tool with args: %+v", r.ToolCall)
	}

	d = base
	d.Usage = 50000
	r, _ = Plan(c, &d)
	if r.ToolCall != nil || len(r.Words) < 8 || r.OutputTokens != 50000 {
		t.Errorf("usage on a text reply: %d words, %d output tokens", len(r.Words), r.OutputTokens)
	}
	d.Call = "list_notes"
	r, _ = Plan(c, &d)
	if r.ToolCall == nil || r.OutputTokens != 50000 {
		t.Errorf("usage on a tool call: %+v, %d", r.ToolCall, r.OutputTokens)
	}

	parsed, err := Parse("raw", " call=add_note arg.text=planted-123 arg.note_id=n-1 usage=7")
	if err != nil {
		t.Fatal(err)
	}
	if parsed.Call != "add_note" || parsed.Args["text"] != "planted-123" || parsed.Args["note_id"] != "n-1" || parsed.Usage != 7 || parsed.Faulty() {
		t.Errorf("parsed %+v", parsed)
	}
}
