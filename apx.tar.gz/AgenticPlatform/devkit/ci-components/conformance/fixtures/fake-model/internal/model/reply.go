package model

import (
	"crypto/sha256"
	"encoding/binary"
	"fmt"
	"strings"
)

// StopReason is why a reply ended, in the fake model's terms; each API
// renders it in its own words.
type StopReason int

const (
	EndTurn   StopReason = iota // Messages end_turn, Chat Completions stop
	MaxTokens                   // max_tokens, length
	ToolUse                     // tool_use, tool_calls
)

// Reply is the fake model's answer to a conversation: either text or one
// tool call, and its usage.
type Reply struct {
	// ID is the conversation's ID; response, message and tool call IDs
	// derive from it.
	ID string
	// Words are the text reply, one token each. The text is the words joined
	// by single spaces; a stream sends one word per content delta.
	Words []string
	// ToolCall is set for a tool call reply, which has no text.
	ToolCall *ToolCall
	// Calls is how many calls of ToolCall the reply makes at once, at
	// least 1 for a tool call reply: a directive's parallel.
	Calls        int
	StopReason   StopReason
	InputTokens  int
	OutputTokens int
}

// ToolCall is a call of a tool: a declared one, or with a directive's call,
// any.
type ToolCall struct {
	Name string
	// Input is the call's input in canonical JSON.
	Input []byte
}

// Text is the text reply.
func (r *Reply) Text() string { return strings.Join(r.Words, " ") }

// Deltas are the pieces a stream sends: a word each for text, with a leading
// space after the first; pieces of the canonical input of at most eight
// characters for a tool call.
func (r *Reply) Deltas() []string {
	if r.ToolCall != nil {
		var out []string
		runes := []rune(string(r.ToolCall.Input))
		for i := 0; i < len(runes); i += 8 {
			out = append(out, string(runes[i:min(i+8, len(runes))]))
		}
		return out
	}
	out := make([]string, len(r.Words))
	for i, w := range r.Words {
		if i > 0 {
			w = " " + w
		}
		out[i] = w
	}
	return out
}

// vocabulary holds the words replies are made of: lowercase letters only, so
// each is exactly one token, and none can form a directive.
var vocabulary = [64]string{
	"amber", "basin", "cedar", "delta", "ember", "fjord", "glade", "harbor",
	"inlet", "juniper", "kelp", "lagoon", "meadow", "nectar", "orchid", "prairie",
	"quartz", "river", "summit", "tundra", "upland", "valley", "willow", "yarrow",
	"zephyr", "acorn", "birch", "canyon", "dune", "estuary", "fern", "granite",
	"heather", "island", "jasper", "knoll", "lichen", "maple", "nettle", "oasis",
	"pebble", "quill", "reef", "sorrel", "thistle", "umber", "vale", "wheat",
	"alder", "brook", "clover", "dawn", "elm", "frost", "grove", "hazel",
	"iris", "jade", "kestrel", "linden", "moss", "north", "oak", "pine",
}

// Plan works out the reply to a conversation under a directive, which may be
// nil. The same conversation and directive always give the same reply.
func Plan(c *Conversation, d *Directive) (*Reply, error) {
	sum := c.Hash()
	r := &Reply{ID: c.ID(), InputTokens: c.InputTokens()}
	if d != nil && (d.Tool != "" || d.Call != "") {
		var name string
		var schema []byte
		if d.Call != "" {
			// Declared or not; a declared tool's schema still shapes the input.
			name = d.Call
			for i := range c.Tools {
				if c.Tools[i].Name == name {
					schema = c.Tools[i].Schema
					break
				}
			}
		} else {
			tool, err := pickTool(c.Tools, d.Tool)
			if err != nil {
				return nil, err
			}
			name, schema = tool.Name, tool.Schema
		}
		input := sampleInput(schema).(map[string]any)
		for k, v := range d.Args {
			input[k] = v
		}
		r.ToolCall = &ToolCall{Name: name, Input: marshal(input)}
		r.Calls = max(1, d.Parallel)
		r.StopReason = ToolUse
		r.OutputTokens = r.Calls * (Count(name) + Count(string(r.ToolCall.Input)))
		if d.Usage > 0 {
			r.OutputTokens = d.Usage
		}
		return r, nil
	}
	n := 8 + int(sum[0]%25) // 8 to 32 words
	if d != nil && d.Tokens >= 0 {
		n = d.Tokens
	}
	if c.MaxTokens > 0 && n > c.MaxTokens {
		n = c.MaxTokens
		r.StopReason = MaxTokens
	}
	r.Words = words(sum, n)
	r.OutputTokens = n
	if d != nil && d.Usage > 0 {
		r.OutputTokens = d.Usage
	}
	return r, nil
}

// words draws n words from the vocabulary with a hash stream seeded by the
// conversation's hash.
func words(seed [32]byte, n int) []string {
	out := make([]string, 0, n)
	var block [32]byte
	for i := 0; i < n; i++ {
		if i%32 == 0 {
			var counter [8]byte
			binary.BigEndian.PutUint64(counter[:], uint64(i/32))
			block = sha256.Sum256(append(seed[:], counter[:]...))
		}
		out = append(out, vocabulary[block[i%32]%64])
	}
	return out
}

func pickTool(tools []Tool, name string) (*Tool, error) {
	for i := range tools {
		if name == "*" || tools[i].Name == name {
			return &tools[i], nil
		}
	}
	if name == "*" {
		return nil, fmt.Errorf("fake-model directive: tool=* but the request declares no tools")
	}
	return nil, fmt.Errorf("fake-model directive: tool=%s but the request declares no tool of that name", name)
}

// sampleInput builds a tool input that satisfies the schema's required
// properties: each takes its enum's first value, its const, its default, or
// a fixed value of its type ("fake", 0, false, [], or an object built the
// same way).
func sampleInput(schema []byte) any {
	// Always an object (the README's rule), so a directive's args can be
	// set on it.
	var s any
	if len(schema) > 0 {
		s = decode(schema)
	}
	v := sampleValue(s)
	if _, ok := v.(map[string]any); !ok {
		return map[string]any{}
	}
	return v
}

func sampleValue(s any) any {
	obj, ok := s.(map[string]any)
	if !ok {
		return map[string]any{}
	}
	if enum, ok := obj["enum"].([]any); ok && len(enum) > 0 {
		return enum[0]
	}
	if c, ok := obj["const"]; ok {
		return c
	}
	if d, ok := obj["default"]; ok {
		return d
	}
	typ, _ := obj["type"].(string)
	if types, ok := obj["type"].([]any); ok {
		for _, t := range types {
			if t, ok := t.(string); ok && t != "null" {
				typ = t
				break
			}
		}
	}
	switch typ {
	case "string":
		return "fake"
	case "integer", "number":
		return 0
	case "boolean":
		return false
	case "array":
		return []any{}
	case "null":
		return nil
	}
	out := map[string]any{}
	props, _ := obj["properties"].(map[string]any)
	required, _ := obj["required"].([]any)
	for _, r := range required {
		name, ok := r.(string)
		if !ok {
			continue
		}
		out[name] = sampleValue(props[name])
	}
	return out
}
