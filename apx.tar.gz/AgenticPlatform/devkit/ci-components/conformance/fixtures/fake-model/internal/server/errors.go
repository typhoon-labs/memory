package server

import (
	"fmt"
	"io"
	"net/http"
	"strconv"
)

// anthropicErrorType is the Messages API's error type for a status
// (platform.claude.com/docs/en/api/errors, checked 2026-11-16): other 4xx
// statuses are invalid_request_error, other 5xx statuses api_error.
func anthropicErrorType(status int) string {
	switch status {
	case 400:
		return "invalid_request_error"
	case 401:
		return "authentication_error"
	case 402:
		return "billing_error"
	case 403:
		return "permission_error"
	case 404:
		return "not_found_error"
	case 409:
		return "conflict_error"
	case 413:
		return "request_too_large"
	case 429:
		return "rate_limit_error"
	case 504:
		return "timeout_error"
	case 529:
		return "overloaded_error"
	}
	if status >= 500 {
		return "api_error"
	}
	return "invalid_request_error"
}

// openAIError is Chat Completions' error type and code for a status:
// rate limits are type "requests" with code rate_limit_exceeded, server
// errors server_error, the rest invalid_request_error.
func openAIError(status int) (typ string, code any) {
	switch {
	case status == 401:
		return "invalid_request_error", "invalid_api_key"
	case status == 429:
		return "requests", "rate_limit_exceeded"
	case status >= 500:
		return "server_error", nil
	}
	return "invalid_request_error", nil
}

type anthropicError struct {
	Type  string `json:"type"`
	Error struct {
		Type    string `json:"type"`
		Message string `json:"message"`
	} `json:"error"`
	RequestID string `json:"request_id,omitempty"`
}

type openAIErrorBody struct {
	Error struct {
		Message string `json:"message"`
		Type    string `json:"type"`
		Param   any    `json:"param"`
		Code    any    `json:"code"`
	} `json:"error"`
}

// errorBody is an error in the API's shape. code, if not empty, replaces
// Chat Completions' default code.
func errorBody(a api, status int, id, message, code string) []byte {
	var v any
	if a == messagesAPI {
		e := anthropicError{Type: "error", RequestID: id}
		e.Error.Type, e.Error.Message = anthropicErrorType(status), message
		v = e
	} else {
		var e openAIErrorBody
		e.Error.Message = message
		e.Error.Type, e.Error.Code = openAIError(status)
		if code != "" {
			e.Error.Code = code
		}
		if code == "context_length_exceeded" {
			e.Error.Param = "messages"
		}
		v = e
	}
	return mustJSON(v)
}

// writeError answers with an error in the API's shape, with retryAfter, if
// not nil, as the retry-after header in seconds. It returns the status.
func writeError(w http.ResponseWriter, a api, status int, id, message string, retryAfter *int) int {
	return writeErrorCode(w, a, status, id, message, "", retryAfter)
}

// writeErrorCode is writeError with Chat Completions' code set.
func writeErrorCode(w http.ResponseWriter, a api, status int, id, message, code string, retryAfter *int) int {
	h := w.Header()
	h.Set("Content-Type", "application/json")
	setRequestID(h, a, id)
	if retryAfter != nil {
		h.Set("Retry-After", strconv.Itoa(*retryAfter))
	}
	body := errorBody(a, status, id, message, code)
	h.Set("Content-Length", strconv.Itoa(len(body)))
	w.WriteHeader(status)
	w.Write(body)
	return status
}

func setRequestID(h http.Header, a api, id string) {
	if id == "" {
		return
	}
	if a == messagesAPI {
		h.Set("Request-Id", id)
	} else {
		h.Set("X-Request-Id", id)
	}
}

// tooLong is each API's message for a request beyond the context window.
func tooLong(a api, tokens, window int) string {
	if a == messagesAPI {
		return fmt.Sprintf("prompt is too long: %d tokens > %d maximum", tokens, window)
	}
	return fmt.Sprintf("This model's maximum context length is %d tokens. However, your messages resulted in %d tokens. Please reduce the length of the messages.", window, tokens)
}

func readAll(r io.Reader) ([]byte, error) { return io.ReadAll(r) }
