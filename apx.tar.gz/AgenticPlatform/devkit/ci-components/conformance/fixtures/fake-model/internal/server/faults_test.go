package server

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"
	"time"
)

// say is a one-message request of either API carrying text.
func say(a api, text string, stream bool) string {
	b, _ := json.Marshal(text)
	s := ""
	if stream {
		s = `"stream":true,`
	}
	if a == messagesAPI {
		return `{"model":"m","max_tokens":1000,` + s + `"messages":[{"role":"user","content":` + string(b) + `}]}`
	}
	return `{"model":"m",` + s + `"messages":[{"role":"user","content":` + string(b) + `}]}`
}

func call(t *testing.T, ts *httptest.Server, a api, text string, stream bool) *response {
	t.Helper()
	if a == messagesAPI {
		return messages(t, ts, say(a, text, stream))
	}
	return chat(t, ts, say(a, text, stream))
}

func records(t *testing.T, ops *httptest.Server, id string) []Record {
	t.Helper()
	res, err := http.Get(ops.URL + "/requests?id=" + id)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	var out struct{ Requests []Record }
	if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
		t.Fatal(err)
	}
	return out.Requests
}

func startBoth(t *testing.T, cfg Config) (api, ops *httptest.Server) {
	t.Helper()
	s := New(cfg)
	api, ops = httptest.NewServer(s.API()), httptest.NewServer(s.Ops())
	t.Cleanup(api.Close)
	t.Cleanup(ops.Close)
	return api, ops
}

func TestStatusFaults(t *testing.T) {
	ts := start(t, Config{})
	for _, c := range []struct {
		a          api
		directive  string
		status     int
		typ, code  string
		retryAfter string
	}{
		{messagesAPI, "status=429", 429, "rate_limit_error", "", "1"},
		{messagesAPI, "status=429 retry-after=7", 429, "rate_limit_error", "", "7"},
		{messagesAPI, "status=500", 500, "api_error", "", ""},
		{messagesAPI, "status=503 retry-after=2", 503, "api_error", "", "2"},
		{messagesAPI, "status=504", 504, "timeout_error", "", ""},
		{messagesAPI, "status=529", 529, "overloaded_error", "", ""},
		{messagesAPI, "status=401", 401, "authentication_error", "", ""},
		{chatAPI, "status=429", 429, "requests", "rate_limit_exceeded", "1"},
		{chatAPI, "status=500", 500, "server_error", "", ""},
		{chatAPI, "status=503 retry-after=0", 503, "server_error", "", "0"},
	} {
		for _, stream := range []bool{false, true} {
			res := call(t, ts, c.a, "hi [[fake-model "+c.directive+"]]", stream)
			m := object(t, res.body)
			if res.status != c.status || res.header.Get("Retry-After") != c.retryAfter || res.header.Get("Content-Type") != "application/json" {
				t.Errorf("%v %s stream=%v: %d retry-after %q: %s", c.a, c.directive, stream, res.status, res.header.Get("Retry-After"), res.body)
			}
			if c.a == messagesAPI {
				if get(m, "type") != "error" || get(m, "error", "type") != c.typ || !strings.Contains(get(m, "error", "message").(string), "fake-model") ||
					res.header.Get("Request-Id") == "" || get(m, "request_id") != res.header.Get("Request-Id") {
					t.Errorf("%s: %s", c.directive, res.body)
				}
			} else if code, _ := get(m, "error", "code").(string); get(m, "error", "type") != c.typ || code != c.code {
				t.Errorf("%s: %s", c.directive, res.body)
			}
		}
	}
	a, b := call(t, ts, messagesAPI, "[[fake-model status=429]]", false), call(t, ts, messagesAPI, "[[fake-model status=429]]", false)
	if string(a.body) != string(b.body) {
		t.Error("an injected error is not deterministic")
	}
}

// TestEcho: with echo, the injected error quotes the request's last user
// text, the directive included, as a provider's error that quotes its
// input; in both APIs, as a body and in a stream.
func TestEcho(t *testing.T) {
	ts := start(t, Config{})
	text := "the canary conf-1 glpat-abc [[fake-model status=400 echo]]"
	for _, a := range []api{messagesAPI, chatAPI} {
		res := call(t, ts, a, text, false)
		msg, _ := get(object(t, res.body), "error", "message").(string)
		if res.status != 400 || !strings.HasSuffix(msg, ": "+text) || !strings.Contains(msg, "fake-model directive") {
			t.Errorf("%v: %d %s", a, res.status, res.body)
		}
	}
	res := call(t, ts, chatAPI, "the canary conf-2 [[fake-model status=500 after=1 echo]]", true)
	if !strings.Contains(string(res.body), "the canary conf-2") {
		t.Errorf("a stream's in-stream error does not quote the text: %s", res.body)
	}
	if res := call(t, ts, messagesAPI, "plain [[fake-model status=400]]", false); strings.Contains(string(res.body), "plain") {
		t.Errorf("without echo, the error quotes the text: %s", res.body)
	}
}

func TestTimesAndRecords(t *testing.T) {
	ts, ops := startBoth(t, Config{})
	text := "retry me [[fake-model id=r1 status=429 retry-after=0 times=2]]"
	for i, want := range []int{429, 429, 200, 200} {
		if res := call(t, ts, chatAPI, text, false); res.status != want {
			t.Errorf("attempt %d: %d, want %d", i+1, res.status, want)
		}
	}
	recs := records(t, ops, "r1")
	if len(recs) != 4 {
		t.Fatalf("%d records: %+v", len(recs), recs)
	}
	for i, r := range recs {
		fault := ""
		if i < 2 {
			fault = "status"
		}
		if r.Attempt != i+1 || r.DirectiveID != "r1" || r.Fault != fault || r.API != "chat_completions" || r.Model != "m" ||
			r.Path != "/v1/chat/completions" || r.Directive != "[[fake-model id=r1 status=429 retry-after=0 times=2]]" || r.Time.IsZero() {
			t.Errorf("record %d: %+v", i, r)
		}
		if i > 0 && r.Time.Before(recs[i-1].Time) {
			t.Error("records are out of order")
		}
	}
	if recs[0].Status != 429 || recs[2].Status != 200 || recs[2].OutputTokens == 0 {
		t.Errorf("records %+v", recs)
	}
	// Forgetting the id resets its attempts: the faults apply again.
	req, _ := http.NewRequest(http.MethodDelete, ops.URL+"/requests?id=r1", nil)
	if res, err := http.DefaultClient.Do(req); err != nil || res.StatusCode != 204 {
		t.Fatalf("DELETE: %v %v", res, err)
	}
	if n := len(records(t, ops, "r1")); n != 0 {
		t.Errorf("%d records after DELETE", n)
	}
	if res := call(t, ts, chatAPI, text, false); res.status != 429 {
		t.Errorf("after DELETE: %d", res.status)
	}
	// Without an id, times counts the directive as written.
	for i, want := range []int{500, 200} {
		if res := call(t, ts, messagesAPI, "[[fake-model status=500 times=1]]", false); res.status != want {
			t.Errorf("anonymous attempt %d: %d", i+1, res.status)
		}
	}
	// Behaviours outlast times.
	for i := 0; i < 2; i++ {
		m := object(t, call(t, ts, messagesAPI, "[[fake-model id=b tokens=4 status=500 times=1]]", false).body)
		if i == 1 && num(get(m, "usage", "output_tokens")) != 4 {
			t.Errorf("tokens did not outlast times: %v", m)
		}
	}
}

func TestRecordsHeadersNotValues(t *testing.T) {
	ts, ops := startBoth(t, Config{Records: 3})
	post(t, ts.URL+"/v1/messages", map[string]string{
		"anthropic-version": "2023-06-01", "anthropic-beta": "b1", "x-api-key": "secret-key", "authorization": "Bearer secret-token",
		"traceparent": "00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01",
	}, say(messagesAPI, "[[fake-model id=h]]", false))
	recs := records(t, ops, "h")
	if len(recs) != 1 {
		t.Fatalf("%+v", recs)
	}
	r := recs[0]
	if strings.Join(r.Credentials, ",") != "Authorization,X-Api-Key" || r.Traceparent != "00-0af7651916cd43dd8448eb211c80319c-b7ad6b7169203331-01" ||
		r.AnthropicVersion != "2023-06-01" || r.AnthropicBeta != "b1" {
		t.Errorf("record %+v", r)
	}
	all, _ := json.Marshal(records(t, ops, ""))
	if strings.Contains(string(all), "secret") {
		t.Error("a credential's value was recorded")
	}
	for i := 0; i < 4; i++ {
		post(t, ts.URL+"/v1/messages/count_tokens", anthropic, `{"model":"m","messages":[{"role":"user","content":"x"}]}`)
	}
	if recs := records(t, ops, ""); len(recs) != 3 || recs[0].API != "count_tokens" || recs[0].InputTokens != 2 {
		t.Errorf("a ring of 3 holds %+v", recs)
	}
	if res, _ := http.Get(ops.URL + "/v1/messages"); res.StatusCode != 404 {
		t.Error("the ops port serves the model")
	}
}

func TestDelay(t *testing.T) {
	ts, ops := startBoth(t, Config{})
	// The delay comes before the first byte: the status line and headers
	// arrive no sooner, so Do itself waits.
	for _, stream := range []bool{false, true} {
		req, _ := http.NewRequest(http.MethodPost, ts.URL+"/v1/messages", strings.NewReader(say(messagesAPI, "[[fake-model id=d delay=150ms]]", stream)))
		req.Header.Set("anthropic-version", "2023-06-01")
		began := time.Now()
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		headers := time.Since(began)
		io.Copy(io.Discard, res.Body)
		res.Body.Close()
		if res.StatusCode != 200 || headers < 150*time.Millisecond {
			t.Errorf("stream=%v: %d, headers after %v", stream, res.StatusCode, headers)
		}
	}
	began := time.Now()
	if res := call(t, ts, chatAPI, "[[fake-model delay=100ms status=503]]", false); res.status != 503 || time.Since(began) < 100*time.Millisecond {
		t.Errorf("a delayed error came after %v", time.Since(began))
	}
	if r := records(t, ops, "d"); len(r) != 2 || r[0].Fault != "delay" {
		t.Errorf("records %+v", r)
	}
}

func TestInterval(t *testing.T) {
	ts, ops := startBoth(t, Config{Interval: time.Hour})
	began := time.Now()
	res := call(t, ts, chatAPI, "[[fake-model id=i interval=30ms tokens=3]]", true)
	if elapsed := time.Since(began); res.status != 200 || elapsed < 90*time.Millisecond || elapsed > 30*time.Second {
		t.Errorf("three deltas at a directive's 30ms took %v", elapsed)
	}
	began = time.Now()
	call(t, ts, chatAPI, "[[fake-model interval=0s tokens=3]]", true)
	if time.Since(began) > 10*time.Second {
		t.Error("interval=0s did not override the server's hour")
	}
	if r := records(t, ops, "i"); len(r) != 1 || r[0].Fault != "interval" {
		t.Errorf("records %+v", r)
	}
}

// streamEvents counts what a stream carried: its content deltas and
// whether it reached its proper end.
func streamEvents(t *testing.T, a api, body []byte) (deltas int, last sse, events []sse) {
	t.Helper()
	events = parseSSE(t, body)
	for _, e := range events {
		if a == messagesAPI && e.name == "content_block_delta" {
			deltas++
		}
		if a == chatAPI && e.data != "[DONE]" {
			c := object(t, []byte(e.data))
			if _, ok := get(c, "choices", 0, "delta", "content").(string); ok && get(c, "choices", 0, "delta", "role") == nil {
				deltas++
			}
		}
	}
	if len(events) > 0 {
		last = events[len(events)-1]
	}
	return deltas, last, events
}

func TestCut(t *testing.T) {
	ts, ops := startBoth(t, Config{})
	for _, a := range []api{messagesAPI, chatAPI} {
		for n, want := range map[int]int{0: 0, 3: 3, 1000: 10} {
			res := call(t, ts, a, "[[fake-model id=c tokens=10 cut="+strconv.Itoa(n)+"]]", true)
			if res.status != 200 || !errors.Is(res.err, io.ErrUnexpectedEOF) {
				t.Errorf("%v cut=%d: %d, read error %v; want the transport cut", a, n, res.status, res.err)
			}
			deltas, last, events := streamEvents(t, a, res.body)
			if deltas != want {
				t.Errorf("%v cut=%d: %d deltas, want %d", a, n, deltas, want)
			}
			opening := messagesOpening
			if a == chatAPI {
				opening = chatOpening
			}
			if len(events) != opening+want || last.name == "message_stop" || last.data == "[DONE]" {
				t.Errorf("%v cut=%d: events %s", a, n, res.body)
			}
		}
		// A body: the first bytes of a declared length, then the cut. The
		// second request, past times, gets the whole body.
		text := "[[fake-model cut=20 times=1 id=body-" + a.String() + "]]"
		res := call(t, ts, a, text, false)
		full := call(t, ts, a, text, false)
		if res.status != 200 || !errors.Is(res.err, io.ErrUnexpectedEOF) || string(res.body) != string(full.body[:20]) ||
			res.header.Get("Content-Length") != strconv.Itoa(len(full.body)) {
			t.Errorf("%v body cut: %d %v %q", a, res.status, res.err, res.body)
		}
	}
	// N beyond the body still cuts it: the last byte never comes.
	whole := call(t, ts, chatAPI, "[[fake-model cut=0 truncate=0 times=1 id=long]]", false)
	if whole.status != 400 {
		t.Fatalf("cut and truncate together: %d", whole.status)
	}
	text := "[[fake-model cut=100000 times=1 id=long-cut]]"
	res, full := call(t, ts, chatAPI, text, false), call(t, ts, chatAPI, text, false)
	if !errors.Is(res.err, io.ErrUnexpectedEOF) || string(res.body) != string(full.body[:len(full.body)-1]) {
		t.Errorf("cut beyond the body: %v %q", res.err, res.body)
	}
	if r := records(t, ops, "c"); len(r) != 6 || r[0].Fault != "cut" || r[0].Status != 200 {
		t.Errorf("records %+v", r)
	}
}

func TestTruncate(t *testing.T) {
	ts := start(t, Config{})
	for _, a := range []api{messagesAPI, chatAPI} {
		res := call(t, ts, a, "[[fake-model tokens=10 truncate=4]]", true)
		if res.status != 200 || res.err != nil {
			t.Errorf("%v: %d %v; want a clean end", a, res.status, res.err)
		}
		deltas, last, _ := streamEvents(t, a, res.body)
		if deltas != 4 || last.name == "message_stop" || last.name == "content_block_stop" || last.data == "[DONE]" {
			t.Errorf("%v truncate=4: %d deltas: %s", a, deltas, res.body)
		}
		// truncate on a body is an empty 200; beyond the body, it still
		// falls a byte short.
		text := "[[fake-model truncate=100000 times=1 id=long-" + a.String() + "]]"
		res, full := call(t, ts, a, text, false), call(t, ts, a, text, false)
		if res.err != nil || string(res.body) != string(full.body[:len(full.body)-1]) {
			t.Errorf("%v truncate beyond the body: %v %q", a, res.err, res.body)
		}
		res = call(t, ts, a, "[[fake-model truncate]]", false)
		if res.status != 200 || res.err != nil || len(res.body) != 0 || res.header.Get("Content-Length") != "0" {
			t.Errorf("%v empty body: %d %v %q", a, res.status, res.err, res.body)
		}
		res = call(t, ts, a, "[[fake-model truncate=0]]", true)
		opening := messagesOpening
		if a == chatAPI {
			opening = chatOpening
		}
		if _, _, events := streamEvents(t, a, res.body); res.status != 200 || res.err != nil || len(events) != opening {
			t.Errorf("%v empty stream: %d %v %q", a, res.status, res.err, res.body)
		}
	}
}

func TestStreamErrorAfter(t *testing.T) {
	ts := start(t, Config{})
	res := call(t, ts, messagesAPI, "[[fake-model tokens=10 status=529 after=2]]", true)
	deltas, last, events := streamEvents(t, messagesAPI, res.body)
	if res.status != 200 || res.err != nil || deltas != 2 || last.name != "error" || len(events) != messagesOpening+2+1 {
		t.Fatalf("%d %v: %s", res.status, res.err, res.body)
	}
	if m := object(t, []byte(last.data)); get(m, "type") != "error" || get(m, "error", "type") != "overloaded_error" {
		t.Errorf("error event %s", last.data)
	}
	res = call(t, ts, chatAPI, "[[fake-model tokens=10 status=500 after=2]]", true)
	deltas, last, _ = streamEvents(t, chatAPI, res.body)
	if res.status != 200 || res.err != nil || deltas != 2 || last.data == "[DONE]" {
		t.Fatalf("%d %v: %s", res.status, res.err, res.body)
	}
	if m := object(t, []byte(last.data)); get(m, "error", "type") != "server_error" || !has(m, "error", "code") {
		t.Errorf("error chunk %s", last.data)
	}
	// Without a stream, after has nothing to follow: the error is HTTP.
	if res := call(t, ts, messagesAPI, "[[fake-model status=529 after=2]]", false); res.status != 529 {
		t.Errorf("a body with after: %d", res.status)
	}
}

func TestReset(t *testing.T) {
	ts, ops := startBoth(t, Config{})
	for _, stream := range []bool{false, true} {
		req, _ := http.NewRequest(http.MethodPost, ts.URL+"/v1/chat/completions", strings.NewReader(say(chatAPI, "[[fake-model id=x reset]]", stream)))
		res, err := http.DefaultClient.Do(req)
		if err == nil {
			res.Body.Close()
			t.Errorf("stream=%v: a reset answered %d", stream, res.StatusCode)
		}
	}
	if r := records(t, ops, "x"); len(r) != 2 || r[0].Fault != "reset" || r[0].Status != 0 {
		t.Errorf("records %+v", r)
	}
}

func TestStall(t *testing.T) {
	ts, ops := startBoth(t, Config{})
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, ts.URL+"/v1/messages", strings.NewReader(say(messagesAPI, "[[fake-model id=s tokens=10 stall=2]]", true)))
	req.Header.Set("anthropic-version", "2023-06-01")
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	lines := make(chan string)
	go func() {
		sc := bufio.NewScanner(res.Body)
		for sc.Scan() {
			lines <- sc.Text()
		}
		close(lines)
	}()
	deltas := 0
	for deltas < 2 {
		select {
		case l := <-lines:
			if strings.HasPrefix(l, "data: ") && strings.Contains(l, `"content_block_delta"`) {
				deltas++
			}
		case <-time.After(5 * time.Second):
			t.Fatal("the first two deltas never came")
		}
	}
	// Then nothing more but the last event's blank line: the stall holds
	// the stream open.
	quiet := time.After(300 * time.Millisecond)
wait:
	for {
		select {
		case l, ok := <-lines:
			if l != "" || !ok {
				t.Fatalf("a stalled stream sent %q (open %v)", l, ok)
			}
		case <-quiet:
			break wait
		}
	}
	if r := records(t, ops, "s"); len(r) != 1 || r[0].Fault != "stall" || r[0].Status != 200 {
		t.Errorf("a stalled request is not recorded while it lasts: %+v", r)
	}
	cancel() // the client gives up; the handler must end, or Close blocks
	for range lines {
	}
}

func TestStallBody(t *testing.T) {
	ts := start(t, Config{})
	client := &http.Client{Timeout: 300 * time.Millisecond}
	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/v1/chat/completions", strings.NewReader(say(chatAPI, "[[fake-model stall]]", false)))
	began := time.Now()
	if res, err := client.Do(req); err == nil {
		res.Body.Close()
		t.Fatalf("a stalled body answered %d", res.StatusCode)
	}
	if time.Since(began) < 300*time.Millisecond {
		t.Error("the stall did not hold")
	}
}

func TestMaxHold(t *testing.T) {
	ts := start(t, Config{MaxHold: 100 * time.Millisecond})
	res := call(t, ts, chatAPI, "[[fake-model tokens=5 stall=1]]", true)
	if deltas, _, _ := streamEvents(t, chatAPI, res.body); res.status != 200 || !errors.Is(res.err, io.ErrUnexpectedEOF) || deltas != 1 {
		t.Errorf("after MaxHold: %d %v %d deltas; want the stream aborted", res.status, res.err, deltas)
	}
	req, _ := http.NewRequest(http.MethodPost, ts.URL+"/v1/chat/completions", strings.NewReader(say(chatAPI, "[[fake-model stall]]", false)))
	if res, err := http.DefaultClient.Do(req); err == nil {
		res.Body.Close()
		t.Errorf("a body stalled past MaxHold answered %d", res.StatusCode)
	}
}

func TestFaultsAcrossTurns(t *testing.T) {
	// A directive in the user's message keeps applying on later turns,
	// whose last message is a tool result.
	ts := start(t, Config{})
	body := `{"model":"m","max_tokens":10,` + weatherTools + `,"messages":[
		{"role":"user","content":"[[fake-model status=503]]"},
		{"role":"assistant","content":[{"type":"tool_use","id":"t1","name":"get_weather","input":{}}]},
		{"role":"user","content":[{"type":"tool_result","tool_use_id":"t1","content":"sunny"}]}]}`
	if res := messages(t, ts, body); res.status != 503 {
		t.Errorf("a later turn got %d", res.status)
	}
	// A later directive wins.
	body = strings.Replace(body, `"content":"sunny"`, `"content":"sunny [[fake-model]]"`, 1)
	if res := messages(t, ts, body); res.status != 200 {
		t.Errorf("a later, empty directive got %d", res.status)
	}
}
