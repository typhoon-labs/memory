package model

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// A directive is written in a request's text as [[fake-model key=value ...]]:
// keys and values separated by white space, a bare key standing for its
// default. The README lists the keys; Parse checks them.
var directivePattern = regexp.MustCompile(`\[\[fake-model((?:\s[^\]]*)?)\]\]`)

const directivePrefix = "[[fake-model"

// maxTokens bounds a directive's tokens: a stream is rendered whole before
// it is sent, about 150 bytes a word, so 100000 words is some 15 MB, and at
// a 10ms interval a stream of a quarter of an hour.
const maxTokens = 100_000

// Directive is what a request asks of the fake model. Faults apply to every
// request that carries the directive, or, with Times, to the first Times of
// them; behaviours apply to every request.
type Directive struct {
	// Raw is the directive as written, brackets included.
	Raw string
	// ID names the directive: its requests are recorded under it, and Times
	// counts them. Without an ID, Times counts by Raw.
	ID string
	// Times limits the faults to the first Times requests; 0 means all.
	Times int

	// Status is an HTTP error status to answer with; 0 means none.
	Status int
	// RetryAfter is the retry-after header in seconds; -1 means unset (a 429
	// then gets 1).
	RetryAfter int
	// After, with Status, on a stream: send the error as an in-stream event
	// after this many content deltas instead of as an HTTP error. -1: unset.
	After int
	// Delay holds the response before its first byte.
	Delay time.Duration
	// Interval paces a stream: the wait before each content delta. -1 means
	// the server's default.
	Interval time.Duration
	// Cut aborts the connection after this many content deltas (a stream) or
	// bytes (a body): no terminal event, no clean end. -1: unset.
	Cut int
	// Truncate ends the response cleanly after this many content deltas or
	// bytes, without the closing events. -1: unset.
	Truncate int
	// Stall stops after this many content deltas and holds the connection
	// open, sending nothing more; a body stalls before its first byte. -1:
	// unset.
	Stall int
	// Reset aborts the connection before any byte is sent.
	Reset bool

	// Tokens is the reply's output tokens before the max_tokens cap; -1 means
	// derived from the conversation.
	Tokens int
	// Tool makes the reply a call of the named tool, or of the first declared
	// tool if "*"; empty means a text reply.
	Tool string
	// Call makes the reply a call of the named tool whether or not the
	// request declares it, as a planted instruction asks a model to call a
	// tool outside the caller's allowlist; empty means none. At most one of
	// Tool and Call.
	Call string
	// Args set top-level members of the tool call's input, as strings, over
	// what the tool's schema gives (arg.<name>=<value>).
	Args map[string]string
	// Parallel makes a tool call reply carry this many calls of the tool at
	// once, as a model's parallel tool use does; 0 means one.
	Parallel int
	// Usage is the output tokens the reply reports instead of its own, so a
	// short reply can carry a caller past a token cap; 0 means the reply's.
	Usage int
	// Echo, with Status, makes the error's message end with the request's
	// last user text, as a provider's error that quotes its input does.
	Echo bool
	// Context is the context window in tokens; 0 means the server's.
	Context int
}

// Key is what Times counts requests by.
func (d *Directive) Key() string {
	if d.ID != "" {
		return "id:" + d.ID
	}
	return "raw:" + d.Raw
}

// Faulty reports whether the directive injects any fault.
func (d *Directive) Faulty() bool {
	return d.Status != 0 || d.Delay > 0 || d.Interval >= 0 || d.Cut >= 0 || d.Truncate >= 0 || d.Stall >= 0 || d.Reset
}

// WithoutFaults is the directive with its behaviours only, for a request
// past Times.
func (d *Directive) WithoutFaults() *Directive {
	c := *d
	c.Status, c.RetryAfter, c.After, c.Delay, c.Interval = 0, -1, -1, 0, -1
	c.Cut, c.Truncate, c.Stall, c.Reset = -1, -1, -1, false
	return &c
}

// Find returns the directive the conversation carries, or nil. The latest
// wins: messages are searched from last to first, a message's texts from
// last to first, and a text's directives from last to first. A malformed
// directive is an error, so a typo never passes silently.
func Find(c *Conversation) (*Directive, error) {
	for i := len(c.Messages) - 1; i >= 0; i-- {
		texts := c.Messages[i].Texts
		for j := len(texts) - 1; j >= 0; j-- {
			t := texts[j]
			if !strings.Contains(t, directivePrefix) {
				continue
			}
			m := directivePattern.FindAllStringSubmatch(t, -1)
			if len(m) == 0 {
				return nil, fmt.Errorf("fake-model directive: %q is not closed by ]]", directivePrefix)
			}
			last := m[len(m)-1]
			return Parse(last[0], last[1])
		}
	}
	return nil, nil
}

var (
	idPattern       = regexp.MustCompile(`^[A-Za-z0-9._-]{1,128}$`)
	toolNamePattern = regexp.MustCompile(`^[A-Za-z0-9._-]{1,128}$`)
	argNamePattern  = regexp.MustCompile(`^[A-Za-z0-9_-]{1,64}$`)
)

// Parse reads a directive's body, the text between "[[fake-model" and "]]".
func Parse(raw, body string) (*Directive, error) {
	d := &Directive{Raw: raw, RetryAfter: -1, After: -1, Interval: -1, Cut: -1, Truncate: -1, Stall: -1, Tokens: -1}
	fail := func(format string, a ...any) (*Directive, error) {
		return nil, fmt.Errorf("fake-model directive %s: %s", raw, fmt.Sprintf(format, a...))
	}
	seen := map[string]bool{}
	ending := []string{}
	for _, field := range strings.Fields(body) {
		key, value, hasValue := strings.Cut(field, "=")
		if seen[key] {
			return fail("%s is given twice", key)
		}
		seen[key] = true
		count := func(min, max int) (int, error) {
			if !hasValue {
				return 0, fmt.Errorf("%s needs a value", key)
			}
			n, err := strconv.Atoi(value)
			if err != nil || n < min || n > max {
				return 0, fmt.Errorf("%s must be an integer from %d to %d", key, min, max)
			}
			return n, nil
		}
		optional := func(max int) (int, error) {
			if !hasValue {
				return 0, nil
			}
			return count(0, max)
		}
		duration := func() (time.Duration, error) {
			if !hasValue {
				return 0, fmt.Errorf("%s needs a value", key)
			}
			v, err := time.ParseDuration(value)
			if err != nil || v < 0 {
				return 0, fmt.Errorf("%s must be a duration such as 250ms or 2s", key)
			}
			return v, nil
		}
		var err error
		switch key {
		case "id":
			if !hasValue || !idPattern.MatchString(value) {
				return fail("id must be 1 to 128 letters, digits, '.', '_' or '-'")
			}
			d.ID = value
		case "times":
			d.Times, err = count(1, 1_000_000)
		case "status":
			d.Status, err = count(400, 599)
		case "retry-after":
			d.RetryAfter, err = count(0, 86_400)
		case "after":
			d.After, err = count(0, 1_000_000)
			ending = append(ending, key)
		case "delay":
			d.Delay, err = duration()
		case "interval":
			d.Interval, err = duration()
		case "cut":
			d.Cut, err = optional(1_000_000_000)
			ending = append(ending, key)
		case "truncate":
			d.Truncate, err = optional(1_000_000_000)
			ending = append(ending, key)
		case "stall":
			d.Stall, err = optional(1_000_000)
			ending = append(ending, key)
		case "reset":
			if hasValue {
				return fail("reset takes no value")
			}
			d.Reset = true
			ending = append(ending, key)
		case "tokens":
			d.Tokens, err = count(0, maxTokens)
		case "tool":
			if !hasValue || value == "" {
				return fail("tool needs a tool name, or *")
			}
			d.Tool = value
		case "call":
			if !hasValue || !toolNamePattern.MatchString(value) {
				return fail("call needs a tool name: 1 to 128 letters, digits, '.', '_' or '-'")
			}
			d.Call = value
		case "parallel":
			d.Parallel, err = count(2, 16)
		case "usage":
			d.Usage, err = count(1, 100_000_000)
		case "context":
			d.Context, err = count(1, 100_000_000)
		case "echo":
			if hasValue {
				return fail("echo takes no value")
			}
			d.Echo = true
		default:
			name, isArg := strings.CutPrefix(key, "arg.")
			if !isArg {
				return fail("unknown key %q", key)
			}
			if !argNamePattern.MatchString(name) {
				return fail("arg.%s: an argument's name is 1 to 64 letters, digits, '_' or '-'", name)
			}
			if !hasValue || value == "" {
				return fail("arg.%s needs a value", name)
			}
			if d.Args == nil {
				d.Args = map[string]string{}
			}
			d.Args[name] = value
		}
		if err != nil {
			return fail("%v", err)
		}
	}
	if d.Tool != "" && d.Call != "" {
		return fail("tool and call cannot be combined: a reply calls one tool")
	}
	if len(d.Args) > 0 && d.Tool == "" && d.Call == "" {
		return fail("arg.* needs tool or call")
	}
	if d.Parallel > 0 && d.Tool == "" && d.Call == "" {
		return fail("parallel needs tool or call")
	}
	if len(ending) > 1 {
		return fail("%s cannot be combined: a response ends one way", strings.Join(ending, " and "))
	}
	if d.Echo && d.Status == 0 {
		return fail("echo needs status: it shapes an error's message")
	}
	if d.After >= 0 && d.Status == 0 {
		return fail("after needs status")
	}
	if d.Status != 0 && d.After < 0 && len(ending) > 0 {
		return fail("status without after is an HTTP error and cannot be combined with %s", ending[0])
	}
	return d, nil
}
