// Package model is the fake model server's model: a request of either API in
// neutral form, the token counting rule, the directives that control a
// response, and the deterministic reply a conversation gets. It knows nothing
// of HTTP; package server renders it in each API's wire format.
package model

import (
	"bytes"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"strings"
)

// Conversation is a request of either API reduced to what the fake model
// reads: the texts it counts, finds directives in and derives its reply from.
// Both APIs reduce the same conversation to the same Conversation, so a
// request translated by the gateway counts and answers as the original would.
type Conversation struct {
	Model string
	// Messages in order. A system prompt is a message with role "system":
	// Messages' top-level system field, leading, or a system entry in its
	// messages, where it stands; or each Chat Completions system or
	// developer message.
	Messages []Message
	Tools    []Tool
	// MaxTokens caps the reply's output tokens; 0 means no cap.
	MaxTokens int
}

// Message is one turn: its role and every text it carries, in order.
type Message struct {
	Role string
	// Texts are the message's text content, a tool call's name and canonical
	// input, and a tool result's text.
	Texts []string
	// Others counts the blocks or parts that carry no text: images,
	// documents and any type the fake model does not read.
	Others int
}

// Tool is a declared tool. Schema is its input schema in canonical JSON, or
// nil for a tool without one (Anthropic's server tools).
type Tool struct {
	Name        string
	Description string
	Schema      []byte
}

// Canonical returns raw JSON in canonical form: compact, object keys sorted,
// no HTML escaping. ok is false if raw is not JSON.
func Canonical(raw []byte) (canonical []byte, ok bool) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil || dec.More() {
		return nil, false
	}
	return marshal(v), true
}

// decode reads canonical JSON, keeping numbers as written.
func decode(canonical []byte) any {
	dec := json.NewDecoder(bytes.NewReader(canonical))
	dec.UseNumber()
	var v any
	if err := dec.Decode(&v); err != nil {
		return nil
	}
	return v
}

func marshal(v any) []byte {
	var b bytes.Buffer
	enc := json.NewEncoder(&b)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(v); err != nil {
		panic(err) // only values decoded from JSON or built here are marshalled
	}
	return bytes.TrimSuffix(b.Bytes(), []byte("\n"))
}

// Hash identifies the conversation: the model, every message and every tool,
// each field length-prefixed. It does not depend on the API or on MaxTokens.
func (c *Conversation) Hash() [32]byte {
	h := sha256.New()
	field := func(s string) {
		var n [8]byte
		binary.BigEndian.PutUint64(n[:], uint64(len(s)))
		h.Write(n[:])
		h.Write([]byte(s))
	}
	field(c.Model)
	for _, m := range c.Messages {
		field("message")
		field(m.Role)
		for _, t := range m.Texts {
			field(t)
		}
		var n [8]byte
		binary.BigEndian.PutUint64(n[:], uint64(m.Others))
		h.Write(n[:])
	}
	for _, t := range c.Tools {
		field("tool")
		field(t.Name)
		field(t.Description)
		field(string(t.Schema))
	}
	var sum [32]byte
	copy(sum[:], h.Sum(nil))
	return sum
}

// ID is the conversation's identifier in responses: the first 24 hex digits
// of its hash.
func (c *Conversation) ID() string {
	sum := c.Hash()
	return hex.EncodeToString(sum[:12])
}

// LastUserText is the texts of the conversation's last user message,
// joined by a space: what a provider's error that quotes its input
// echoes.
func (c *Conversation) LastUserText() string {
	for i := len(c.Messages) - 1; i >= 0; i-- {
		if c.Messages[i].Role == "user" {
			return strings.Join(c.Messages[i].Texts, " ")
		}
	}
	return ""
}
