package model

import "unicode"

// Count is the counting rule for one text: each maximal run of letters and
// digits is one token, and each other character that is not white space is
// one token. "Hello, world!" is four tokens.
func Count(s string) int {
	n := 0
	inWord := false
	for _, r := range s {
		switch {
		case unicode.IsLetter(r) || unicode.IsDigit(r):
			if !inWord {
				n++
				inWord = true
			}
		case unicode.IsSpace(r):
			inWord = false
		default:
			n++
			inWord = false
		}
	}
	return n
}

// InputTokens is the counting rule for a request: for each message, one
// token for the turn, plus its texts, plus one for each block that carries
// no text; for each tool, its name, its description and its canonical
// schema.
func (c *Conversation) InputTokens() int {
	n := 0
	for _, m := range c.Messages {
		n++
		for _, t := range m.Texts {
			n += Count(t)
		}
		n += m.Others
	}
	for _, t := range c.Tools {
		n += Count(t.Name) + Count(t.Description) + Count(string(t.Schema))
	}
	return n
}
