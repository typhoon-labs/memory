package server

import "net/http"

// Ops is the operations handler, for a port the gateway does not route
// to: GET /healthz answers while the process serves; GET /readyz until
// shutdown begins; GET /requests lists the records (?id= for one directive
// id), and DELETE /requests forgets them and their attempt counts (?id=
// for one).
func (s *Server) Ops() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("ok\n"))
	})
	mux.HandleFunc("GET /readyz", func(w http.ResponseWriter, r *http.Request) {
		if s.notReady.Load() {
			http.Error(w, "shutting down", http.StatusServiceUnavailable)
			return
		}
		w.Write([]byte("ok\n"))
	})
	mux.HandleFunc("GET /requests", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		writeJSON(w, map[string]any{"requests": s.records.list(r.URL.Query().Get("id"))})
	})
	mux.HandleFunc("DELETE /requests", func(w http.ResponseWriter, r *http.Request) {
		id := r.URL.Query().Get("id")
		s.records.clear(id)
		s.counts.reset(id)
		w.WriteHeader(http.StatusNoContent)
	})
	return mux
}
