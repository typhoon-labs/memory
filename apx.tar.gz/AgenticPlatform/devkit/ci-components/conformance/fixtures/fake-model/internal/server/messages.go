package server

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/model"
)

// Anthropic's Messages API (platform.claude.com/docs/en/api/messages and
// /docs/en/build-with-claude/streaming, checked 2026-11-16).

// fields decodes a JSON object into its fields, or fails with the API's
// message for a body that is not one.
func fields(body []byte) (map[string]json.RawMessage, error) {
	var top map[string]json.RawMessage
	if err := json.Unmarshal(body, &top); err != nil || top == nil {
		return nil, fmt.Errorf("the request body is not a JSON object")
	}
	return top, nil
}

func absent(raw json.RawMessage) bool { return len(raw) == 0 || string(raw) == "null" }

func str(raw json.RawMessage, path string, required bool) (string, error) {
	if absent(raw) {
		if required {
			return "", fmt.Errorf("%s: Field required", path)
		}
		return "", nil
	}
	var s string
	if err := json.Unmarshal(raw, &s); err != nil {
		return "", fmt.Errorf("%s: Input should be a valid string", path)
	}
	return s, nil
}

func boolean(raw json.RawMessage, path string) (bool, error) {
	if absent(raw) {
		return false, nil
	}
	var b bool
	if err := json.Unmarshal(raw, &b); err != nil {
		return false, fmt.Errorf("%s: Input should be a valid boolean", path)
	}
	return b, nil
}

// positive reads an optional integer of at least 1; 0 means absent.
func positive(raw json.RawMessage, path string) (int, error) {
	if absent(raw) {
		return 0, nil
	}
	var n int
	if err := json.Unmarshal(raw, &n); err != nil {
		return 0, fmt.Errorf("%s: Input should be a valid integer", path)
	}
	if n < 1 {
		return 0, fmt.Errorf("%s: Input should be greater than or equal to 1", path)
	}
	return n, nil
}

func objects(raw json.RawMessage, path string) ([]map[string]json.RawMessage, error) {
	var list []map[string]json.RawMessage
	if err := json.Unmarshal(raw, &list); err != nil {
		return nil, fmt.Errorf("%s: Input should be a valid list of objects", path)
	}
	for i, o := range list {
		if o == nil {
			return nil, fmt.Errorf("%s.%d: Input should be a valid object", path, i)
		}
	}
	return list, nil
}

// parseMessages reads a Messages request, or, with countOnly, a token
// counting request, which has no max_tokens and no stream.
func parseMessages(body []byte, countOnly bool) (*request, error) {
	top, err := fields(body)
	if err != nil {
		return nil, err
	}
	conv := &model.Conversation{}
	if conv.Model, err = str(top["model"], "model", true); err != nil {
		return nil, err
	}
	if conv.Model == "" {
		return nil, fmt.Errorf("model: String should have at least 1 character")
	}
	req := &request{conv: conv}
	if !countOnly {
		if absent(top["max_tokens"]) {
			return nil, fmt.Errorf("max_tokens: Field required")
		}
		if conv.MaxTokens, err = positive(top["max_tokens"], "max_tokens"); err != nil {
			return nil, err
		}
		if req.stream, err = boolean(top["stream"], "stream"); err != nil {
			return nil, err
		}
	}
	if system := top["system"]; !absent(system) {
		texts, others, err := anthropicContent(system, "system")
		if err != nil {
			return nil, err
		}
		if len(texts) > 0 || others > 0 {
			conv.Messages = append(conv.Messages, model.Message{Role: "system", Texts: texts, Others: others})
		}
	}
	if absent(top["messages"]) {
		return nil, fmt.Errorf("messages: Field required")
	}
	msgs, err := objects(top["messages"], "messages")
	if err != nil {
		return nil, err
	}
	if len(msgs) == 0 {
		return nil, fmt.Errorf("messages: at least one message is required")
	}
	for i, m := range msgs {
		path := fmt.Sprintf("messages.%d", i)
		role, err := str(m["role"], path+".role", true)
		if err != nil {
			return nil, err
		}
		// A system entry mid-conversation, as the Messages API takes for
		// current models and Claude Code sends to a gateway's aliases: a
		// system turn where it stands, as Chat Completions' system
		// messages are.
		if role != "user" && role != "assistant" && role != "system" {
			return nil, fmt.Errorf("%s.role: Input should be 'user', 'assistant' or 'system'", path)
		}
		if absent(m["content"]) {
			return nil, fmt.Errorf("%s.content: Field required", path)
		}
		texts, others, err := anthropicContent(m["content"], path+".content")
		if err != nil {
			return nil, err
		}
		conv.Messages = append(conv.Messages, model.Message{Role: role, Texts: texts, Others: others})
	}
	if tools := top["tools"]; !absent(tools) {
		list, err := objects(tools, "tools")
		if err != nil {
			return nil, err
		}
		for i, t := range list {
			path := fmt.Sprintf("tools.%d", i)
			name, err := str(t["name"], path+".name", true)
			if err != nil {
				return nil, err
			}
			desc, err := str(t["description"], path+".description", false)
			if err != nil {
				return nil, err
			}
			tool := model.Tool{Name: name, Description: desc}
			if schema := t["input_schema"]; !absent(schema) {
				c, ok := model.Canonical(schema)
				if !ok {
					return nil, fmt.Errorf("%s.input_schema: Input should be a valid object", path)
				}
				tool.Schema = c
			}
			conv.Tools = append(conv.Tools, tool)
		}
	}
	return req, nil
}

// anthropicContent reads a string or a list of content blocks: the texts it
// carries and the number of blocks that carry none.
func anthropicContent(raw json.RawMessage, path string) (texts []string, others int, err error) {
	var s string
	if json.Unmarshal(raw, &s) == nil {
		return []string{s}, 0, nil
	}
	blocks, err := objects(raw, path)
	if err != nil {
		return nil, 0, fmt.Errorf("%s: Input should be a valid string or list of content blocks", path)
	}
	for i, b := range blocks {
		bp := fmt.Sprintf("%s.%d", path, i)
		typ, err := str(b["type"], bp+".type", true)
		if err != nil {
			return nil, 0, err
		}
		switch typ {
		case "text":
			t, err := str(b["text"], bp+".text", true)
			if err != nil {
				return nil, 0, err
			}
			texts = append(texts, t)
		case "thinking":
			t, err := str(b["thinking"], bp+".thinking", true)
			if err != nil {
				return nil, 0, err
			}
			texts = append(texts, t)
		case "tool_use", "server_tool_use":
			name, err := str(b["name"], bp+".name", true)
			if err != nil {
				return nil, 0, err
			}
			input, ok := model.Canonical(b["input"])
			if !ok {
				return nil, 0, fmt.Errorf("%s.input: Field required", bp)
			}
			texts = append(texts, name, string(input))
		case "tool_result":
			if absent(b["content"]) {
				continue
			}
			t, o, err := anthropicContent(b["content"], bp+".content")
			if err != nil {
				return nil, 0, err
			}
			texts, others = append(texts, t...), others+o
		default:
			others++
		}
	}
	return texts, others, nil
}

// countTokens answers /v1/messages/count_tokens with the counting rule.
// Directives are not read: counting has no response to shape.
func (s *Server) countTokens(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	rec := begin(r, "count_tokens")
	defer s.finish(rec, start)
	fail := func(status int, id, msg string) {
		rec.Status, rec.Error = writeError(w, messagesAPI, status, id, msg, nil), msg
	}
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		fail(http.StatusMethodNotAllowed, "", "Method Not Allowed")
		return
	}
	body, status, msg := s.readBody(w, r, messagesAPI)
	if status != 0 {
		fail(status, requestID(body), msg)
		return
	}
	req, err := parseMessages(body, true)
	if err != nil {
		fail(http.StatusBadRequest, requestID(body), err.Error())
		return
	}
	rec.Model, rec.InputTokens = req.conv.Model, req.conv.InputTokens()
	h := w.Header()
	h.Set("Content-Type", "application/json")
	setRequestID(h, messagesAPI, "req_fake_"+req.conv.ID())
	rec.Status = http.StatusOK
	writeJSON(w, map[string]int{"input_tokens": rec.InputTokens})
}

// Response shapes, in the API's field order.

type messagesUsage struct {
	InputTokens              int `json:"input_tokens"`
	CacheCreationInputTokens int `json:"cache_creation_input_tokens"`
	CacheReadInputTokens     int `json:"cache_read_input_tokens"`
	OutputTokens             int `json:"output_tokens"`
}

type messagesMessage struct {
	ID           string        `json:"id"`
	Type         string        `json:"type"`
	Role         string        `json:"role"`
	Model        string        `json:"model"`
	Content      []any         `json:"content"`
	StopReason   *string       `json:"stop_reason"`
	StopSequence *string       `json:"stop_sequence"`
	Usage        messagesUsage `json:"usage"`
}

type textBlock struct {
	Type string `json:"type"`
	Text string `json:"text"`
}

type toolUseBlock struct {
	Type  string          `json:"type"`
	ID    string          `json:"id"`
	Name  string          `json:"name"`
	Input json.RawMessage `json:"input"`
}

func anthropicStopReason(r model.StopReason) string {
	switch r {
	case model.MaxTokens:
		return "max_tokens"
	case model.ToolUse:
		return "tool_use"
	}
	return "end_turn"
}

func toolUseID(r *model.Reply) string { return "toolu_fake_" + r.ID }

// nthID is the ID of a reply's ith call (from 0): the first keeps the
// reply's own, so a single call's ID is unchanged; parallel ones add _2,
// _3 and so on.
func nthID(id string, i int) string {
	if i == 0 {
		return id
	}
	return id + "_" + strconv.Itoa(i+1)
}

// messagesBody is the non-streaming response.
func messagesBody(req *request, r *model.Reply) []byte {
	stop := anthropicStopReason(r.StopReason)
	m := messagesMessage{
		ID: "msg_fake_" + r.ID, Type: "message", Role: "assistant", Model: req.conv.Model,
		StopReason: &stop,
		Usage:      messagesUsage{InputTokens: r.InputTokens, OutputTokens: r.OutputTokens},
	}
	if r.ToolCall != nil {
		m.Content = []any{}
		for i := range max(1, r.Calls) {
			m.Content = append(m.Content, toolUseBlock{Type: "tool_use", ID: nthID(toolUseID(r), i), Name: r.ToolCall.Name, Input: r.ToolCall.Input})
		}
	} else {
		m.Content = []any{textBlock{Type: "text", Text: r.Text()}}
	}
	return mustJSON(m)
}

// Stream events, each with its type first as the API sends them.

type startEvent struct {
	Type    string          `json:"type"`
	Message messagesMessage `json:"message"`
}

type blockStartEvent struct {
	Type         string `json:"type"`
	Index        int    `json:"index"`
	ContentBlock any    `json:"content_block"`
}

type typeOnly struct {
	Type string `json:"type"`
}

type blockDeltaEvent struct {
	Type  string `json:"type"`
	Index int    `json:"index"`
	Delta any    `json:"delta"`
}

type textDelta struct {
	Type string `json:"type"`
	Text string `json:"text"`
}

type inputJSONDelta struct {
	Type        string `json:"type"`
	PartialJSON string `json:"partial_json"`
}

type blockStopEvent struct {
	Type  string `json:"type"`
	Index int    `json:"index"`
}

type messageDeltaEvent struct {
	Type  string `json:"type"`
	Delta struct {
		StopReason   string  `json:"stop_reason"`
		StopSequence *string `json:"stop_sequence"`
	} `json:"delta"`
	Usage struct {
		OutputTokens int `json:"output_tokens"`
	} `json:"usage"`
}

// messagesOpening is the number of events before the first content delta:
// message_start, content_block_start and ping.
const messagesOpening = 3

// messagesEvents is the streaming response: message_start, one content
// block with its start, a ping, its deltas and its stop, message_delta with
// the cumulative output tokens, and message_stop.
func messagesEvents(req *request, r *model.Reply) []event {
	ev := func(name string, v any) event { return event{name: name, data: mustJSON(v)} }
	start := messagesMessage{
		ID: "msg_fake_" + r.ID, Type: "message", Role: "assistant", Model: req.conv.Model, Content: []any{},
		Usage: messagesUsage{InputTokens: r.InputTokens, OutputTokens: min(1, r.OutputTokens)},
	}
	out := []event{ev("message_start", startEvent{Type: "message_start", Message: start})}
	blocks := 1
	if r.ToolCall != nil {
		blocks = max(1, r.Calls)
	}
	for i := range blocks {
		var block any = textBlock{Type: "text", Text: ""}
		if r.ToolCall != nil {
			block = toolUseBlock{Type: "tool_use", ID: nthID(toolUseID(r), i), Name: r.ToolCall.Name, Input: json.RawMessage(`{}`)}
		}
		out = append(out, ev("content_block_start", blockStartEvent{Type: "content_block_start", Index: i, ContentBlock: block}))
		if i == 0 {
			out = append(out, ev("ping", typeOnly{Type: "ping"}))
		}
		deltas := r.Deltas()
		if r.ToolCall != nil {
			deltas = append([]string{""}, deltas...) // as the API does, an empty first piece
		}
		for _, d := range deltas {
			var delta any = textDelta{Type: "text_delta", Text: d}
			if r.ToolCall != nil {
				delta = inputJSONDelta{Type: "input_json_delta", PartialJSON: d}
			}
			e := ev("content_block_delta", blockDeltaEvent{Type: "content_block_delta", Index: i, Delta: delta})
			e.delta = true
			out = append(out, e)
		}
		out = append(out, ev("content_block_stop", blockStopEvent{Type: "content_block_stop", Index: i}))
	}
	md := messageDeltaEvent{Type: "message_delta"}
	md.Delta.StopReason = anthropicStopReason(r.StopReason)
	md.Usage.OutputTokens = r.OutputTokens
	out = append(out,
		ev("message_delta", md),
		ev("message_stop", typeOnly{Type: "message_stop"}))
	return out
}
