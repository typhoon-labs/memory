package server

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/model"
)

const hello = `{"model":"claude-test","max_tokens":1024,"system":"Be brief.","messages":[{"role":"user","content":"Hello, world!"}]}`

func TestMessages(t *testing.T) {
	ts := start(t, Config{})
	res := messages(t, ts, hello)
	if res.status != 200 || res.header.Get("Content-Type") != "application/json" {
		t.Fatalf("%d %s: %s", res.status, res.header.Get("Content-Type"), res.body)
	}
	m := object(t, res.body)
	text, _ := get(m, "content", 0, "text").(string)
	if !strings.HasPrefix(get(m, "id").(string), "msg_fake_") || get(m, "type") != "message" || get(m, "role") != "assistant" ||
		get(m, "model") != "claude-test" || get(m, "content", 0, "type") != "text" || text == "" ||
		get(m, "stop_reason") != "end_turn" || !has(m, "stop_sequence") || get(m, "stop_sequence") != nil {
		t.Errorf("response %s", res.body)
	}
	// system "Be brief." 1 + 3, user 1 + 4
	if in, out := num(get(m, "usage", "input_tokens")), num(get(m, "usage", "output_tokens")); in != 9 || out != model.Count(text) {
		t.Errorf("usage %v for %q", get(m, "usage"), text)
	}
	if !has(m, "usage", "cache_creation_input_tokens") || !has(m, "usage", "cache_read_input_tokens") {
		t.Errorf("usage lacks the cache fields: %v", get(m, "usage"))
	}
	if id := res.header.Get("Request-Id"); !strings.HasPrefix(id, "req_fake_") {
		t.Errorf("request-id %q", id)
	}
	again := messages(t, ts, hello)
	if !bytes.Equal(res.body, again.body) || res.header.Get("Request-Id") != again.header.Get("Request-Id") {
		t.Error("the same request got two responses")
	}
	other := messages(t, ts, strings.Replace(hello, "Hello", "Goodbye", 1))
	if bytes.Equal(res.body, other.body) {
		t.Error("two requests got the same response")
	}
}

// requiredMessageFields are the fields agentgateway 1.7.0's typed model of
// a Messages response cannot do without (crates/llm/src/types/messages.rs,
// MessagesResponse and Usage): an event missing one is dropped.
func checkMessage(t *testing.T, m any) {
	t.Helper()
	for _, f := range []string{"id", "type", "role", "content", "model", "stop_reason", "stop_sequence", "usage"} {
		if !has(m, f) {
			t.Errorf("message lacks %s: %v", f, m)
		}
	}
	for _, f := range []string{"input_tokens", "output_tokens"} {
		if _, ok := get(m, "usage", f).(float64); !ok {
			t.Errorf("usage lacks %s: %v", f, get(m, "usage"))
		}
	}
}

func TestMessagesStream(t *testing.T) {
	ts := start(t, Config{})
	full := object(t, messages(t, ts, hello).body)
	res := messages(t, ts, strings.Replace(hello, `"max_tokens"`, `"stream":true,"max_tokens"`, 1))
	if res.status != 200 || res.header.Get("Content-Type") != "text/event-stream; charset=utf-8" || res.err != nil {
		t.Fatalf("%d %s %v", res.status, res.header.Get("Content-Type"), res.err)
	}
	events := parseSSE(t, res.body)
	text := get(full, "content", 0, "text").(string)
	words := len(strings.Fields(text))
	want := "message_start content_block_start ping" + strings.Repeat(" content_block_delta", words) +
		" content_block_stop message_delta message_stop"
	if got := names(events); got != want {
		t.Fatalf("events %s, want %s", got, want)
	}
	var streamed strings.Builder
	for _, e := range events {
		d := object(t, []byte(e.data))
		if d["type"] != e.name {
			t.Errorf("event %s carries type %v", e.name, d["type"])
		}
		switch e.name {
		case "message_start":
			msg := get(d, "message")
			checkMessage(t, msg)
			if get(msg, "stop_reason") != nil || len(get(msg, "content").([]any)) != 0 ||
				get(msg, "id") != get(full, "id") || num(get(msg, "usage", "input_tokens")) != num(get(full, "usage", "input_tokens")) {
				t.Errorf("message_start %s", e.data)
			}
		case "content_block_start":
			if num(get(d, "index")) != 0 || get(d, "content_block", "type") != "text" || get(d, "content_block", "text") != "" {
				t.Errorf("content_block_start %s", e.data)
			}
		case "content_block_delta":
			if num(get(d, "index")) != 0 || get(d, "delta", "type") != "text_delta" {
				t.Errorf("content_block_delta %s", e.data)
			}
			streamed.WriteString(get(d, "delta", "text").(string))
		case "content_block_stop":
			if !has(d, "index") {
				t.Errorf("content_block_stop %s", e.data)
			}
		case "message_delta":
			if get(d, "delta", "stop_reason") != "end_turn" || !has(d, "delta", "stop_sequence") ||
				num(get(d, "usage", "output_tokens")) != num(get(full, "usage", "output_tokens")) {
				t.Errorf("message_delta %s, want the non-streaming usage %v", e.data, get(full, "usage"))
			}
		}
	}
	if streamed.String() != text {
		t.Errorf("streamed %q, non-streaming %q", streamed.String(), text)
	}
}

func TestMessagesMaxTokens(t *testing.T) {
	ts := start(t, Config{})
	res := messages(t, ts, `{"model":"m","max_tokens":5,"messages":[{"role":"user","content":"[[fake-model tokens=50]]"}]}`)
	m := object(t, res.body)
	if get(m, "stop_reason") != "max_tokens" || num(get(m, "usage", "output_tokens")) != 5 ||
		len(strings.Fields(get(m, "content", 0, "text").(string))) != 5 {
		t.Errorf("max_tokens 5: %s", res.body)
	}
	res = messages(t, ts, `{"model":"m","max_tokens":500,"messages":[{"role":"user","content":"[[fake-model tokens=50]]"}]}`)
	if m := object(t, res.body); get(m, "stop_reason") != "end_turn" || num(get(m, "usage", "output_tokens")) != 50 {
		t.Errorf("tokens=50: %s", res.body)
	}
}

const weatherTools = `"tools":[{"name":"get_weather","description":"Weather now","input_schema":{"type":"object","required":["city"],"properties":{"city":{"type":"string"}}}}]`

func TestMessagesToolUse(t *testing.T) {
	ts := start(t, Config{})
	body := `{"model":"m","max_tokens":100,` + weatherTools + `,"messages":[{"role":"user","content":"[[fake-model tool=get_weather]]"}]}`
	m := object(t, messages(t, ts, body).body)
	block := get(m, "content", 0)
	if get(m, "stop_reason") != "tool_use" || get(block, "type") != "tool_use" || get(block, "name") != "get_weather" ||
		get(block, "input", "city") != "fake" || !strings.HasPrefix(get(block, "id").(string), "toolu_fake_") {
		t.Fatalf("tool use %v", m)
	}
	if out := num(get(m, "usage", "output_tokens")); out != model.Count("get_weather")+model.Count(`{"city":"fake"}`) {
		t.Errorf("output tokens %d", out)
	}
	res := messages(t, ts, strings.Replace(body, `"max_tokens"`, `"stream":true,"max_tokens"`, 1))
	events := parseSSE(t, res.body)
	var input strings.Builder
	deltas := 0
	for _, e := range events {
		d := object(t, []byte(e.data))
		switch e.name {
		case "content_block_start":
			cb := get(d, "content_block")
			if get(cb, "type") != "tool_use" || get(cb, "id") != get(block, "id") || get(cb, "name") != "get_weather" ||
				len(get(cb, "input").(map[string]any)) != 0 {
				t.Errorf("content_block_start %s", e.data)
			}
		case "content_block_delta":
			if get(d, "delta", "type") != "input_json_delta" {
				t.Errorf("delta %s", e.data)
			}
			if deltas == 0 && get(d, "delta", "partial_json") != "" {
				t.Errorf("the first input delta is not empty: %s", e.data)
			}
			deltas++
			input.WriteString(get(d, "delta", "partial_json").(string))
		case "message_delta":
			if get(d, "delta", "stop_reason") != "tool_use" || num(get(d, "usage", "output_tokens")) != num(get(m, "usage", "output_tokens")) {
				t.Errorf("message_delta %s", e.data)
			}
		}
	}
	if input.String() != `{"city":"fake"}` || deltas < 3 {
		t.Errorf("streamed input %q in %d deltas", input.String(), deltas)
	}
}

func TestMessagesToolLoop(t *testing.T) {
	// A looping agent: every turn calls the tool again, however long the
	// conversation, and each call has its own ID.
	ts := start(t, Config{})
	msgs := `{"role":"user","content":"go [[fake-model tool=*]]"}`
	ids := map[string]bool{}
	for i := 0; i < 5; i++ {
		body := `{"model":"m","max_tokens":100,` + weatherTools + `,"messages":[` + msgs + `]}`
		m := object(t, messages(t, ts, body).body)
		block := get(m, "content", 0)
		if get(m, "stop_reason") != "tool_use" || get(block, "name") != "get_weather" {
			t.Fatalf("turn %d: %v", i, m)
		}
		id := get(block, "id").(string)
		if ids[id] {
			t.Errorf("turn %d repeats tool call ID %s", i, id)
		}
		ids[id] = true
		input, _ := json.Marshal(get(block, "input"))
		msgs += `,{"role":"assistant","content":[{"type":"tool_use","id":"` + id + `","name":"get_weather","input":` + string(input) + `}]}` +
			`,{"role":"user","content":[{"type":"tool_result","tool_use_id":"` + id + `","content":"sunny"}]}`
	}
}

func TestMessagesContentBlocks(t *testing.T) {
	ts := start(t, Config{})
	body := `{"model":"m","max_tokens":10,
		"system":[{"type":"text","text":"Be brief."},{"type":"text","text":"Really."}],
		"messages":[
		{"role":"user","content":[{"type":"text","text":"Look"},{"type":"image","source":{"type":"base64","media_type":"image/png","data":"AAAA"}}]},
		{"role":"assistant","content":[{"type":"thinking","thinking":"hm","signature":"x"},{"type":"tool_use","id":"t1","name":"look","input":{"b":1,"a":2}}]},
		{"role":"user","content":[{"type":"tool_result","tool_use_id":"t1","content":[{"type":"text","text":"a cat"},{"type":"image","source":{}}]},{"type":"tool_result","tool_use_id":"t2"}]}]}`
	m := object(t, messages(t, ts, body).body)
	// system 1+3+2; user 1+1+1 image; assistant 1+1 (hm)+1 (look)+13
	// ({"a":2,"b":1}); user 1+2 (a cat)+1 image, and nothing for the
	// result without content
	if in := num(get(m, "usage", "input_tokens")); in != 6+3+16+4 {
		t.Errorf("input tokens %d: %v", in, m)
	}
	count := object(t, post(t, ts.URL+"/v1/messages/count_tokens", anthropic, strings.Replace(body, `"max_tokens":10,`, "", 1)).body)
	if num(count["input_tokens"]) != num(get(m, "usage", "input_tokens")) {
		t.Errorf("count_tokens %v, messages %v", count, get(m, "usage"))
	}
}

func TestMessagesErrors(t *testing.T) {
	ts := start(t, Config{MaxBody: 1024})
	check := func(name string, res *response, status int, typ, msg string) {
		t.Helper()
		m := object(t, res.body)
		if res.status != status || get(m, "type") != "error" || get(m, "error", "type") != typ ||
			!strings.Contains(get(m, "error", "message").(string), msg) || !strings.HasPrefix(get(m, "request_id").(string), "req_fake_") ||
			res.header.Get("Request-Id") != get(m, "request_id") {
			t.Errorf("%s: %d %s", name, res.status, res.body)
		}
	}
	check("no version", post(t, ts.URL+"/v1/messages", nil, hello), 400, "invalid_request_error", "anthropic-version")
	check("not JSON", messages(t, ts, `{`), 400, "invalid_request_error", "JSON object")
	check("no model", messages(t, ts, `{"max_tokens":1,"messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "model: Field required")
	check("no max_tokens", messages(t, ts, `{"model":"m","messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "max_tokens: Field required")
	check("max_tokens 0", messages(t, ts, `{"model":"m","max_tokens":0,"messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "greater than or equal to 1")
	check("no messages", messages(t, ts, `{"model":"m","max_tokens":1}`), 400, "invalid_request_error", "messages: Field required")
	check("empty messages", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[]}`), 400, "invalid_request_error", "at least one")
	check("other role", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"developer","content":"x"}]}`), 400, "invalid_request_error", "messages.0.role")
	check("tool role", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user","content":"x"},{"role":"tool","content":"y"}]}`), 400, "invalid_request_error", "messages.1.role")
	check("no content", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user"}]}`), 400, "invalid_request_error", "messages.0.content")
	check("block type", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user","content":[{"text":"x"}]}]}`), 400, "invalid_request_error", "messages.0.content.0.type")
	check("stream type", messages(t, ts, `{"model":"m","max_tokens":1,"stream":"yes","messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "stream")
	check("tool name", messages(t, ts, `{"model":"m","max_tokens":1,"tools":[{}],"messages":[{"role":"user","content":"x"}]}`), 400, "invalid_request_error", "tools.0.name")
	check("too large", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user","content":"`+strings.Repeat("x", 2048)+`"}]}`), 413, "request_too_large", "maximum")
	check("directive", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user","content":"[[fake-model statsu=429]]"}]}`), 400, "invalid_request_error", "unknown key")
	check("undeclared tool", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user","content":"[[fake-model tool=x]]"}]}`), 400, "invalid_request_error", "declares no tool")
	check("context", messages(t, ts, `{"model":"m","max_tokens":1,"messages":[{"role":"user","content":"one two three [[fake-model context=5]]"}]}`), 400, "invalid_request_error", "prompt is too long: 14 tokens > 5 maximum")
	check("not found", post(t, ts.URL+"/v1/complete", anthropic, hello), 404, "not_found_error", "Invalid URL (POST /v1/complete)")

	get := func(path string) *response {
		res, err := ts.Client().Get(ts.URL + path)
		if err != nil {
			t.Fatal(err)
		}
		defer res.Body.Close()
		var b bytes.Buffer
		b.ReadFrom(res.Body)
		return &response{status: res.StatusCode, header: res.Header, body: b.Bytes()}
	}
	if res := get("/v1/messages"); res.status != 405 || res.header.Get("Allow") != "POST" {
		t.Errorf("GET /v1/messages: %d %v", res.status, res.header)
	}
}

func TestMessagesContextWindow(t *testing.T) {
	ts := start(t, Config{ContextWindow: 8})
	if res := messages(t, ts, hello); res.status != 400 || !strings.Contains(string(res.body), "prompt is too long: 9 tokens > 8 maximum") {
		t.Errorf("%d %s", res.status, res.body)
	}
	if res := messages(t, ts, strings.Replace(hello, "Hello, world!", "[[fake-model context=100]]", 1)); res.status != 200 {
		t.Errorf("a directive's context did not override the server's: %d %s", res.status, res.body)
	}
}

func TestMessagesAcceptsWhatTheGatewaySends(t *testing.T) {
	ts := start(t, Config{})
	// Claude Code adds ?beta=true; clients send any API version, and
	// fields the fake model ignores.
	for _, version := range []string{"2023-06-01", "2026-10-21"} {
		res := post(t, ts.URL+"/v1/messages?beta=true", map[string]string{"anthropic-version": version, "anthropic-beta": "x", "x-api-key": "k"},
			`{"model":"m","max_tokens":10,"temperature":0.5,"metadata":{"user_id":"u"},"thinking":{"type":"adaptive"},
			"tool_choice":{"type":"auto"},"messages":[{"role":"user","content":[{"type":"text","text":"hi","cache_control":{"type":"ephemeral"}}]}]}`)
		if res.status != 200 {
			t.Errorf("%s: %d %s", version, res.status, res.body)
		}
	}
}

// Claude Code sends system entries in messages to a gateway's aliases, as
// the Messages API takes them for current models: each is a system turn
// where it stands, counted and searched as one, and the same turns sent to
// Chat Completions as system messages get the same reply and usage.
func TestMessagesSystemEntries(t *testing.T) {
	ts := start(t, Config{})
	body := `{"model":"m","max_tokens":100,"system":"Be brief.","messages":[
		{"role":"user","content":"Hello, world!"},
		{"role":"system","content":[{"type":"text","text":"Answer in French."}]},
		{"role":"user","content":"Again."}]}`
	res := messages(t, ts, body)
	if res.status != 200 {
		t.Fatalf("%d %s", res.status, res.body)
	}
	m := object(t, res.body)
	// system 1+3, user 1+4, system entry 1+4, user 1+2
	if in := num(get(m, "usage", "input_tokens")); in != 17 {
		t.Errorf("input tokens %d: %s", in, res.body)
	}
	count := object(t, post(t, ts.URL+"/v1/messages/count_tokens", anthropic, strings.Replace(body, `"max_tokens":100,`, "", 1)).body)
	if num(count["input_tokens"]) != 17 {
		t.Errorf("count_tokens %v", count)
	}
	c := object(t, chat(t, ts, `{"model":"m","max_tokens":100,"messages":[
		{"role":"system","content":"Be brief."},
		{"role":"user","content":"Hello, world!"},
		{"role":"system","content":"Answer in French."},
		{"role":"user","content":"Again."}]}`).body)
	if get(c, "choices", 0, "message", "content") != get(m, "content", 0, "text") ||
		num(get(c, "usage", "prompt_tokens")) != 17 || num(get(c, "usage", "completion_tokens")) != num(get(m, "usage", "output_tokens")) {
		t.Errorf("Chat Completions answered %v, Messages %v", c, m)
	}
	// Its place matters: the same texts with the entry moved are another
	// conversation.
	moved := object(t, messages(t, ts, `{"model":"m","max_tokens":100,"system":"Be brief.","messages":[
		{"role":"system","content":[{"type":"text","text":"Answer in French."}]},
		{"role":"user","content":"Hello, world!"},
		{"role":"user","content":"Again."}]}`).body)
	if get(moved, "id") == get(m, "id") {
		t.Errorf("a system entry's place did not change the conversation: %v", moved)
	}
	// A directive in a system entry applies when no later text carries one,
	// and a later one in the user's turn wins.
	directed := `{"model":"m","max_tokens":100,"messages":[
		{"role":"user","content":"Hello."},
		{"role":"system","content":"[[fake-model tokens=3]]"},
		{"role":"user","content":"Go on.LATER"}]}`
	d := object(t, messages(t, ts, strings.Replace(directed, "LATER", "", 1)).body)
	if text, _ := get(d, "content", 0, "text").(string); model.Count(text) != 3 {
		t.Errorf("the system entry's directive did not apply: %q", text)
	}
	d = object(t, messages(t, ts, strings.Replace(directed, "LATER", " [[fake-model tokens=5]]", 1)).body)
	if text, _ := get(d, "content", 0, "text").(string); model.Count(text) != 5 {
		t.Errorf("the user's later directive did not win: %q", text)
	}
}
