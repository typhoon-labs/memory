package server

import (
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestHealthAndDrain(t *testing.T) {
	s := New(Config{})
	api, ops := httptest.NewServer(s.API()), httptest.NewServer(s.Ops())
	defer api.Close()
	defer ops.Close()
	status := func(path string) int {
		res, err := http.Get(ops.URL + path)
		if err != nil {
			t.Fatal(err)
		}
		res.Body.Close()
		return res.StatusCode
	}
	if status("/healthz") != 200 || status("/readyz") != 200 {
		t.Fatal("not healthy and ready from the start")
	}
	// A stall in progress ends when the server drains.
	done := make(chan error)
	go func() {
		req, _ := http.NewRequest(http.MethodPost, api.URL+"/v1/chat/completions", strings.NewReader(say(chatAPI, "[[fake-model stall=1]]", true)))
		res, err := http.DefaultClient.Do(req)
		if err == nil {
			_, err = io.ReadAll(res.Body)
			res.Body.Close()
		}
		done <- err
	}()
	time.Sleep(100 * time.Millisecond)
	s.Drain()
	s.Drain() // twice is harmless
	select {
	case err := <-done:
		if err == nil {
			t.Error("a stall drained as a complete response")
		}
	case <-time.After(5 * time.Second):
		t.Fatal("draining did not end the stall")
	}
	if status("/readyz") != 503 || status("/healthz") != 200 {
		t.Error("draining did not fail readiness alone")
	}
	// Other responses still complete while draining.
	if res := call(t, api, chatAPI, "hi", true); res.status != 200 || res.err != nil {
		t.Errorf("while draining: %d %v", res.status, res.err)
	}
}
