package server

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func start(t *testing.T, cfg Config) *httptest.Server {
	t.Helper()
	ts := httptest.NewServer(New(cfg).API())
	t.Cleanup(ts.Close)
	return ts
}

type response struct {
	status int
	header http.Header
	body   []byte
	err    error // from reading the body
}

func post(t *testing.T, url string, header map[string]string, body string) *response {
	t.Helper()
	req, err := http.NewRequest(http.MethodPost, url, strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Content-Type", "application/json")
	for k, v := range header {
		req.Header.Set(k, v)
	}
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	b, err := io.ReadAll(res.Body)
	return &response{status: res.StatusCode, header: res.Header, body: b, err: err}
}

var anthropic = map[string]string{"anthropic-version": "2023-06-01"}

func messages(t *testing.T, ts *httptest.Server, body string) *response {
	t.Helper()
	return post(t, ts.URL+"/v1/messages", anthropic, body)
}

func chat(t *testing.T, ts *httptest.Server, body string) *response {
	t.Helper()
	return post(t, ts.URL+"/v1/chat/completions", nil, body)
}

func object(t *testing.T, b []byte) map[string]any {
	t.Helper()
	var m map[string]any
	if err := json.Unmarshal(b, &m); err != nil {
		t.Fatalf("not a JSON object: %v: %s", err, b)
	}
	return m
}

// get walks a decoded JSON value by keys and indexes.
func get(v any, path ...any) any {
	for _, p := range path {
		switch k := p.(type) {
		case string:
			m, ok := v.(map[string]any)
			if !ok {
				return nil
			}
			v = m[k]
		case int:
			l, ok := v.([]any)
			if !ok || k >= len(l) {
				return nil
			}
			v = l[k]
		}
	}
	return v
}

func has(v any, path ...any) bool {
	parent := get(v, path[:len(path)-1]...)
	m, ok := parent.(map[string]any)
	if !ok {
		return false
	}
	_, ok = m[path[len(path)-1].(string)]
	return ok
}

type sse struct {
	name string
	data string
}

// parseSSE reads a stream strictly: every event is an optional
// "event: <name>" line, one "data: <payload>" line and a blank line, and
// nothing else appears.
func parseSSE(t *testing.T, b []byte) []sse {
	t.Helper()
	var out []sse
	rest := string(b)
	for rest != "" {
		block, after, ok := strings.Cut(rest, "\n\n")
		if !ok {
			t.Fatalf("the stream ends inside an event: %q", rest)
		}
		rest = after
		lines := strings.Split(block, "\n")
		var e sse
		if strings.HasPrefix(lines[0], "event: ") {
			e.name = strings.TrimPrefix(lines[0], "event: ")
			lines = lines[1:]
		}
		if len(lines) != 1 || !strings.HasPrefix(lines[0], "data: ") {
			t.Fatalf("malformed event %q", block)
		}
		e.data = strings.TrimPrefix(lines[0], "data: ")
		out = append(out, e)
	}
	return out
}

func names(events []sse) string {
	var b bytes.Buffer
	for i, e := range events {
		if i > 0 {
			b.WriteByte(' ')
		}
		b.WriteString(e.name)
	}
	return b.String()
}

func num(v any) int {
	f, _ := v.(float64)
	return int(f)
}
