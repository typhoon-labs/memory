// Package server serves the fake model over HTTP: Anthropic's Messages API
// and OpenAI's Chat Completions, each streaming and not, in each API's wire
// format and error shapes, with the faults a request's directive asks for,
// and a record of each request for the suites to inspect.
package server

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"log/slog"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/model"
)

// Created is the "created" timestamp of every Chat Completions response,
// fixed so that responses are deterministic: 2026-01-01T00:00:00Z.
const Created = 1767225600

// Config is the server's configuration. Zero values take the defaults.
type Config struct {
	// ContextWindow is the largest request, in input tokens, the model
	// accepts; a directive's context key overrides it. Default 200000.
	ContextWindow int
	// Interval paces streams: the wait before each content delta. A
	// directive's interval key overrides it.
	Interval time.Duration
	// MaxBody is the largest request body in bytes. Default 32 MiB.
	MaxBody int64
	// MaxHold bounds a stall: after it, the connection is aborted. Default
	// 10 minutes.
	MaxHold time.Duration
	// Records is how many request records are kept, oldest dropped first.
	// Default 10000.
	Records int
	// Log receives one line per request.
	Log *slog.Logger
}

// Server is the fake model.
type Server struct {
	cfg     Config
	log     *slog.Logger
	counts  *counter
	records *ring
	// draining is closed when shutdown begins: it ends every stall.
	draining  chan struct{}
	drainOnce sync.Once
	notReady  atomic.Bool
}

// New returns a server with the configuration's defaults filled in.
func New(cfg Config) *Server {
	if cfg.ContextWindow <= 0 {
		cfg.ContextWindow = 200_000
	}
	if cfg.MaxBody <= 0 {
		cfg.MaxBody = 32 << 20
	}
	if cfg.MaxHold <= 0 {
		cfg.MaxHold = 10 * time.Minute
	}
	if cfg.Records <= 0 {
		cfg.Records = 10_000
	}
	log := cfg.Log
	if log == nil {
		log = slog.New(slog.DiscardHandler)
	}
	return &Server{cfg: cfg, log: log, counts: newCounter(), records: newRing(cfg.Records), draining: make(chan struct{})}
}

// Drain begins shutdown: readiness fails, and every stalled response is
// aborted at once, since it would otherwise hold the shutdown for the
// whole grace period. Responses in progress finish as they would.
func (s *Server) Drain() {
	s.drainOnce.Do(func() {
		s.notReady.Store(true)
		close(s.draining)
	})
}

// API is the model's HTTP handler: the paths each API's clients call, and
// what agentgateway sends upstream with its default /v1 base path.
func (s *Server) API() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/v1/messages", func(w http.ResponseWriter, r *http.Request) { s.serve(w, r, messagesAPI) })
	mux.HandleFunc("/v1/messages/count_tokens", s.countTokens)
	mux.HandleFunc("/v1/chat/completions", func(w http.ResponseWriter, r *http.Request) { s.serve(w, r, chatAPI) })
	mux.HandleFunc("/", s.notFound)
	return mux
}

type api int

const (
	messagesAPI api = iota
	chatAPI
)

func (a api) String() string {
	if a == messagesAPI {
		return "messages"
	}
	return "chat_completions"
}

// request is a parsed request of either API.
type request struct {
	conv   *model.Conversation
	stream bool
	// includeUsage is Chat Completions' stream_options.include_usage.
	includeUsage bool
}

// begin starts a request's record from what its headers say.
func begin(r *http.Request, apiName string) *Record {
	return &Record{
		Time: time.Now().UTC(), API: apiName, Method: r.Method, Path: r.URL.Path,
		Credentials:      credentialHeaders(r.Header),
		Traceparent:      r.Header.Get("traceparent"),
		AnthropicVersion: r.Header.Get("anthropic-version"),
		AnthropicBeta:    r.Header.Get("anthropic-beta"),
	}
}

// finish keeps the record, if it is not kept yet, and logs the request.
func (s *Server) finish(rec *Record, start time.Time) {
	if !rec.kept {
		s.records.add(rec)
	}
	attrs := []any{
		"method", rec.Method, "path", rec.Path, "api", rec.API, "status", rec.Status,
		"duration_ms", time.Since(start).Milliseconds(),
	}
	if rec.Model != "" {
		attrs = append(attrs, "model", rec.Model, "stream", rec.Stream,
			"input_tokens", rec.InputTokens, "output_tokens", rec.OutputTokens)
	}
	if rec.Directive != "" {
		attrs = append(attrs, "directive", rec.Directive, "attempt", rec.Attempt)
	}
	if rec.Fault != "" {
		attrs = append(attrs, "fault", rec.Fault)
	}
	if rec.Error != "" {
		attrs = append(attrs, "error", rec.Error)
	}
	if rec.AnthropicVersion != "" {
		attrs = append(attrs, "anthropic_version", rec.AnthropicVersion)
	}
	attrs = append(attrs, "credentials", rec.Credentials)
	s.log.Info("request", attrs...)
}

// credentialHeaders names the credential headers a request carries, never
// their values: what a gateway forwarded to the model.
func credentialHeaders(h http.Header) []string {
	names := []string{}
	for _, n := range []string{"Authorization", "X-Api-Key", "Proxy-Authorization"} {
		if h.Get(n) != "" {
			names = append(names, http.CanonicalHeaderKey(n))
		}
	}
	return names
}

// serve answers a model request of either API.
func (s *Server) serve(w http.ResponseWriter, r *http.Request, a api) {
	start := time.Now()
	rec := begin(r, a.String())
	defer s.finish(rec, start)
	fail := func(status int, id, msg, code string) {
		rec.Status, rec.Error = writeErrorCode(w, a, status, id, msg, code, nil), msg
	}
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		fail(http.StatusMethodNotAllowed, "", "Method Not Allowed", "")
		return
	}
	body, status, msg := s.readBody(w, r, a)
	if status != 0 {
		fail(status, requestID(body), msg, "")
		return
	}
	var req *request
	var err error
	if a == messagesAPI {
		req, err = parseMessages(body, false)
	} else {
		req, err = parseChat(body)
	}
	if err != nil {
		fail(http.StatusBadRequest, requestID(body), err.Error(), "")
		return
	}
	rec.Model, rec.Stream = req.conv.Model, req.stream
	id := "req_fake_" + req.conv.ID()
	d, err := model.Find(req.conv)
	if err != nil {
		fail(http.StatusBadRequest, id, err.Error(), "")
		return
	}
	if d != nil {
		rec.Directive, rec.DirectiveID = d.Raw, d.ID
		rec.Attempt = s.counts.next(d.Key())
		if d.Times > 0 && rec.Attempt > d.Times {
			d = d.WithoutFaults()
		}
	}
	window := s.cfg.ContextWindow
	if d != nil && d.Context > 0 {
		window = d.Context
	}
	if n := req.conv.InputTokens(); n > window {
		fail(http.StatusBadRequest, id, tooLong(a, n, window), "context_length_exceeded")
		return
	}
	reply, err := model.Plan(req.conv, d)
	if err != nil {
		fail(http.StatusBadRequest, id, err.Error(), "")
		return
	}
	rec.InputTokens, rec.OutputTokens = reply.InputTokens, reply.OutputTokens
	s.respond(w, r, a, req, reply, d, id, rec)
}

// readBody reads a POST body within the size limit and checks the API's
// required headers. A non-zero status is the error to answer with.
func (s *Server) readBody(w http.ResponseWriter, r *http.Request, a api) (body []byte, status int, msg string) {
	if a == messagesAPI && r.Header.Get("anthropic-version") == "" {
		return nil, http.StatusBadRequest, "anthropic-version: header is required"
	}
	body, err := readAll(http.MaxBytesReader(w, r.Body, s.cfg.MaxBody))
	if err != nil {
		var tooLarge *http.MaxBytesError
		if errors.As(err, &tooLarge) {
			return nil, http.StatusRequestEntityTooLarge, "Request exceeds the maximum allowed number of bytes."
		}
		return nil, http.StatusBadRequest, "could not read the request body"
	}
	return body, 0, ""
}

// requestID is a request's ID before it parses: from a hash of its body.
func requestID(body []byte) string {
	sum := sha256.Sum256(body)
	return "req_fake_" + hex.EncodeToString(sum[:12])
}

func (s *Server) notFound(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	a := chatAPI
	if r.Header.Get("anthropic-version") != "" {
		a = messagesAPI
	}
	rec := begin(r, "none")
	defer s.finish(rec, start)
	msg := "Invalid URL (" + r.Method + " " + r.URL.Path + ")"
	rec.Status, rec.Error = writeError(w, a, http.StatusNotFound, requestID(nil), msg, nil), msg
}
