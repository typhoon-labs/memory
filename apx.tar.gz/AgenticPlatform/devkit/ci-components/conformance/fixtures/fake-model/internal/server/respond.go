package server

import (
	"bytes"
	"encoding/json"
	"net/http"
	"strconv"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/model"
)

// event is one server-sent event. Messages events are named; Chat
// Completions events are data only.
type event struct {
	name string
	data []byte
	// delta marks a content delta: what pacing waits before, and what cut,
	// truncate, stall and after count.
	delta bool
}

func (e event) bytes() []byte {
	var b bytes.Buffer
	if e.name != "" {
		b.WriteString("event: ")
		b.WriteString(e.name)
		b.WriteByte('\n')
	}
	b.WriteString("data: ")
	b.Write(e.data)
	b.WriteString("\n\n")
	return b.Bytes()
}

// mustJSON marshals a response value as the APIs do, without escaping HTML.
func mustJSON(v any) []byte {
	var b bytes.Buffer
	enc := json.NewEncoder(&b)
	enc.SetEscapeHTML(false)
	if err := enc.Encode(v); err != nil {
		panic(err) // response values are built here and always marshal
	}
	return bytes.TrimSuffix(b.Bytes(), []byte("\n"))
}

func writeJSON(w http.ResponseWriter, v any) {
	body := mustJSON(v)
	w.Header().Set("Content-Length", strconv.Itoa(len(body)))
	w.WriteHeader(http.StatusOK)
	w.Write(body)
}

// noDirective stands for a request without one: no faults, no behaviours.
var noDirective = (&model.Directive{}).WithoutFaults()

// abort ends the response at the transport: an HTTP/1.1 connection is
// closed without the body's end, an HTTP/2 stream is reset. net/http
// recovers this panic without logging it.
func abort() { panic(http.ErrAbortHandler) }

// faultMessage is the message of an injected error.
func faultMessage(status int) string {
	text := http.StatusText(status)
	switch {
	case status == 529:
		text = "Overloaded"
	case text == "":
		text = "Error"
	}
	return text + " (injected by a fake-model directive)"
}

// errorMessage is an injected error's message: with echo, followed by the
// request's last user text, as a provider's error that quotes its input.
func errorMessage(d *model.Directive, req *request) string {
	msg := faultMessage(d.Status)
	if d.Echo {
		msg += ": " + req.conv.LastUserText()
	}
	return msg
}

// respond sends the reply, as a body or a stream, with the directive's
// faults. The record is kept before the response starts, so a suite sees a
// slow or stalled request while it lasts.
func (s *Server) respond(w http.ResponseWriter, r *http.Request, a api, req *request, reply *model.Reply, d *model.Directive, id string, rec *Record) {
	if d == nil {
		d = noDirective
	}
	var faults []string
	if d.Delay > 0 {
		faults = append(faults, "delay")
	}
	interval := s.cfg.Interval
	if d.Interval >= 0 {
		interval = d.Interval
		if req.stream {
			faults = append(faults, "interval")
		}
	}
	// ending is how the response ends, and n the deltas or bytes before.
	ending, n := "", 0
	switch {
	case d.Reset:
		ending = "reset"
	case d.Status != 0 && (d.After < 0 || !req.stream):
		ending = "status"
	case d.Status != 0:
		ending, n = "after", d.After
	case d.Cut >= 0:
		ending, n = "cut", d.Cut
	case d.Truncate >= 0:
		ending, n = "truncate", d.Truncate
	case d.Stall >= 0:
		ending, n = "stall", d.Stall
	}
	if ending != "" {
		faults = append(faults, ending)
	}
	rec.Fault = strings.Join(faults, ",")
	switch {
	case ending == "reset" || ending == "stall" && !req.stream:
		rec.Status = 0 // nothing is ever sent
	case ending == "status":
		rec.Status = d.Status
	default:
		rec.Status = http.StatusOK
	}
	s.records.add(rec)

	if d.Delay > 0 && !sleep(r, d.Delay) {
		return // the client went away
	}
	h := w.Header()
	switch ending {
	case "reset":
		abort()
	case "status":
		var retryAfter *int
		if d.RetryAfter >= 0 {
			retryAfter = &d.RetryAfter
		} else if d.Status == http.StatusTooManyRequests {
			one := 1
			retryAfter = &one
		}
		writeError(w, a, d.Status, id, errorMessage(d, req), retryAfter)
		return
	}
	setRequestID(h, a, id)
	rc := http.NewResponseController(w)

	if !req.stream {
		body := messagesBody(req, reply)
		if a == chatAPI {
			body = chatBody(req, reply)
		}
		h.Set("Content-Type", "application/json")
		// A cut or truncated body always falls short, by a byte at least,
		// as a stream always loses its closing events.
		short := min(n, len(body)-1)
		switch ending {
		case "stall":
			s.hold(r)
			abort()
		case "cut":
			h.Set("Content-Length", strconv.Itoa(len(body)))
			w.WriteHeader(http.StatusOK)
			w.Write(body[:short])
			rc.Flush()
			abort()
		case "truncate":
			body = body[:short]
		}
		h.Set("Content-Length", strconv.Itoa(len(body)))
		w.WriteHeader(http.StatusOK)
		w.Write(body)
		return
	}

	events, opening := messagesEvents(req, reply), messagesOpening
	if a == chatAPI {
		events, opening = chatEvents(req, reply), chatOpening
	}
	stop := len(events)
	if ending != "" {
		stop = cutPoint(events, opening, n)
	}
	h.Set("Content-Type", "text/event-stream; charset=utf-8")
	h.Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusOK)
	rc.Flush()
	for _, e := range events[:stop] {
		if e.delta && interval > 0 && !sleep(r, interval) {
			return
		}
		if _, err := w.Write(e.bytes()); err != nil {
			return
		}
		rc.Flush()
	}
	switch ending {
	case "after":
		w.Write(streamError(a, d.Status, errorMessage(d, req)).bytes())
		rc.Flush()
	case "cut":
		abort()
	case "stall":
		s.hold(r)
		abort()
	}
}

// cutPoint is the index in events just after the first n content deltas,
// or after the last delta if there are fewer. Deltas follow the opening
// events without a gap.
func cutPoint(events []event, opening, n int) int {
	deltas := 0
	for _, e := range events {
		if e.delta {
			deltas++
		}
	}
	return opening + min(n, deltas)
}

// streamError is the API's in-stream error event: Messages' error event
// (as for an overloaded_error during a stream), or for Chat Completions a
// data chunk holding the error body.
func streamError(a api, status int, message string) event {
	if a == messagesAPI {
		var e struct {
			Type  string `json:"type"`
			Error struct {
				Type    string `json:"type"`
				Message string `json:"message"`
			} `json:"error"`
		}
		e.Type = "error"
		e.Error.Type, e.Error.Message = anthropicErrorType(status), message
		return event{name: "error", data: mustJSON(e)}
	}
	return event{data: errorBody(chatAPI, status, "", message, "")}
}

// hold keeps a stalled response open, sending nothing, until the client
// goes away, MaxHold passes or the server drains.
func (s *Server) hold(r *http.Request) {
	t := time.NewTimer(s.cfg.MaxHold)
	defer t.Stop()
	select {
	case <-r.Context().Done():
	case <-t.C:
	case <-s.draining:
	}
}

// sleep waits for d, or until the client goes away; it reports whether
// the wait ran its course.
func sleep(r *http.Request, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return true
	case <-r.Context().Done():
		return false
	}
}
