package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestConfigure(t *testing.T) {
	noEnv := func(string) string { return "" }
	s, err := configure(nil, noEnv, io.Discard)
	if err != nil {
		t.Fatal(err)
	}
	if s.listen != ":8080" || s.opsListen != ":9090" || s.server.ContextWindow != 200_000 || s.server.Interval != 0 ||
		s.server.MaxHold != 10*time.Minute || s.server.MaxBody != 32<<20 || s.server.Records != 10_000 ||
		s.grace != 10*time.Second || s.logLevel != slog.LevelInfo {
		t.Errorf("defaults %+v", s)
	}
	env := map[string]string{
		"FAKE_MODEL_LISTEN": ":1", "FAKE_MODEL_OPS_LISTEN": ":2", "FAKE_MODEL_CONTEXT_WINDOW": "3",
		"FAKE_MODEL_INTERVAL": "4ms", "FAKE_MODEL_MAX_HOLD": "5s", "FAKE_MODEL_MAX_BODY": "6", "FAKE_MODEL_RECORDS": "7",
		"FAKE_MODEL_SHUTDOWN_GRACE": "8s", "FAKE_MODEL_LOG_LEVEL": "debug",
	}
	s, err = configure(nil, func(k string) string { return env[k] }, io.Discard)
	if err != nil {
		t.Fatal(err)
	}
	if s.listen != ":1" || s.opsListen != ":2" || s.server.ContextWindow != 3 || s.server.Interval != 4*time.Millisecond ||
		s.server.MaxHold != 5*time.Second || s.server.MaxBody != 6 || s.server.Records != 7 || s.grace != 8*time.Second ||
		s.logLevel != slog.LevelDebug {
		t.Errorf("from the environment %+v", s)
	}
	s, err = configure([]string{"-listen", ":9", "-records", "11", "-log-level", "warn"}, func(k string) string { return env[k] }, io.Discard)
	if err != nil || s.listen != ":9" || s.server.Records != 11 || s.opsListen != ":2" || s.logLevel != slog.LevelWarn {
		t.Errorf("flags over the environment: %+v %v", s, err)
	}
	for name, c := range map[string]struct {
		args []string
		env  map[string]string
	}{
		"bad env integer":  {env: map[string]string{"FAKE_MODEL_RECORDS": "many"}},
		"bad env duration": {env: map[string]string{"FAKE_MODEL_INTERVAL": "soon"}},
		"bad flag":         {args: []string{"-records", "x"}},
		"unknown flag":     {args: []string{"-nope"}},
		"argument":         {args: []string{"extra"}},
		"zero window":      {args: []string{"-context-window", "0"}},
		"zero body":        {args: []string{"-max-body", "0"}},
		"zero records":     {args: []string{"-records", "0"}},
		"negative grace":   {args: []string{"-shutdown-grace", "-1s"}},
		"zero hold":        {args: []string{"-max-hold", "0s"}},
		"log level":        {args: []string{"-log-level", "loud"}},
	} {
		if _, err := configure(c.args, func(k string) string { return c.env[k] }, io.Discard); err == nil {
			t.Errorf("%s: accepted", name)
		}
	}
}

// syncBuffer collects log lines from several goroutines.
type syncBuffer struct {
	mu sync.Mutex
	b  bytes.Buffer
}

func (b *syncBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.b.Write(p)
}

func (b *syncBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.b.String()
}

type instance struct {
	api, ops string
	logs     *syncBuffer
	cancel   context.CancelFunc
	done     chan error
}

func launch(t *testing.T, args ...string) *instance {
	t.Helper()
	cfg, err := configure(args, func(string) string { return "" }, io.Discard)
	if err != nil {
		t.Fatal(err)
	}
	apiLn, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	opsLn, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	logs := &syncBuffer{}
	log := slog.New(slog.NewJSONHandler(logs, nil))
	cfg.server.Log = log
	ctx, cancel := context.WithCancel(context.Background())
	in := &instance{api: "http://" + apiLn.Addr().String(), ops: "http://" + opsLn.Addr().String(), logs: logs, cancel: cancel, done: make(chan error, 1)}
	go func() { in.done <- run(ctx, cfg, apiLn, opsLn, log) }()
	t.Cleanup(func() {
		cancel()
		<-in.done
	})
	return in
}

func (in *instance) stop(t *testing.T, within time.Duration) {
	t.Helper()
	in.cancel()
	select {
	case err := <-in.done:
		if err != nil {
			t.Errorf("run: %v", err)
		}
		in.done <- nil // for the cleanup
	case <-time.After(within):
		t.Fatalf("run did not return within %v", within)
	}
}

func stream(t *testing.T, url, text string) *http.Response {
	t.Helper()
	body := `{"model":"m","max_tokens":100,"stream":true,"messages":[{"role":"user","content":` + quote(text) + `}]}`
	req, _ := http.NewRequest(http.MethodPost, url+"/v1/messages", strings.NewReader(body))
	req.Header.Set("anthropic-version", "2023-06-01")
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	return res
}

func quote(s string) string {
	b, _ := json.Marshal(s)
	return string(b)
}

func TestRunServesAndLogs(t *testing.T) {
	in := launch(t)
	for _, path := range []string{"/healthz", "/readyz"} {
		res, err := http.Get(in.ops + path)
		if err != nil || res.StatusCode != 200 {
			t.Fatalf("%s: %v %v", path, res, err)
		}
		res.Body.Close()
	}
	res := stream(t, in.api, "hello [[fake-model id=log]]")
	b, err := io.ReadAll(res.Body)
	res.Body.Close()
	if err != nil || !strings.HasSuffix(string(b), "event: message_stop\ndata: {\"type\":\"message_stop\"}\n\n") {
		t.Fatalf("%v %s", err, b)
	}
	if res, _ := http.Get(in.api + "/healthz"); res.StatusCode != 404 {
		t.Error("the model port serves operations")
	}
	in.stop(t, 5*time.Second)
	var found bool
	sc := bufio.NewScanner(strings.NewReader(in.logs.String()))
	for sc.Scan() {
		var line map[string]any
		if err := json.Unmarshal(sc.Bytes(), &line); err != nil {
			t.Fatalf("a log line is not JSON: %s", sc.Text())
		}
		if line["msg"] == "request" && line["directive"] == "[[fake-model id=log]]" {
			found = true
			for _, k := range []string{"time", "level", "method", "path", "api", "status", "duration_ms", "model", "stream", "input_tokens", "output_tokens", "attempt", "credentials"} {
				if _, ok := line[k]; !ok {
					t.Errorf("the request line lacks %s: %s", k, sc.Text())
				}
			}
		}
	}
	if !found {
		t.Errorf("no request line in %s", in.logs.String())
	}
	for _, msg := range []string{`"msg":"fake-model started"`, `"msg":"shutting down"`} {
		if !strings.Contains(in.logs.String(), msg) {
			t.Errorf("no %s line", msg)
		}
	}
}

func TestShutdownDrains(t *testing.T) {
	in := launch(t, "-shutdown-grace", "5s")
	// A paced stream in progress finishes; a stall ends at once.
	paced := stream(t, in.api, "[[fake-model tokens=6 interval=50ms]]")
	stalled := stream(t, in.api, "[[fake-model stall=1]]")
	time.Sleep(50 * time.Millisecond)
	began := time.Now()
	in.stop(t, 4*time.Second)
	if time.Since(began) > 3*time.Second {
		t.Error("a stall held the shutdown")
	}
	b, err := io.ReadAll(paced.Body)
	paced.Body.Close()
	if err != nil || !strings.Contains(string(b), "message_stop") {
		t.Errorf("the paced stream did not finish: %v %s", err, b)
	}
	if _, err := io.ReadAll(stalled.Body); err == nil {
		t.Error("the stall ended as a complete response")
	}
	stalled.Body.Close()
	if _, err := http.Get(in.api + "/v1/messages"); err == nil {
		t.Error("the model port still answers after shutdown")
	}
}

func TestShutdownGraceRunsOut(t *testing.T) {
	in := launch(t, "-shutdown-grace", "200ms")
	slow := stream(t, in.api, "[[fake-model tokens=100 interval=1s]]")
	time.Sleep(50 * time.Millisecond)
	began := time.Now()
	in.stop(t, 3*time.Second)
	if elapsed := time.Since(began); elapsed < 200*time.Millisecond {
		t.Errorf("shut down after %v, before the grace period", elapsed)
	}
	if _, err := io.ReadAll(slow.Body); err == nil {
		t.Error("a response past the grace period completed")
	}
	slow.Body.Close()
}

// TestAddrFile: asked for port 0, the server writes the ports it bound,
// both at once, before it serves.
func TestAddrFile(t *testing.T) {
	path := filepath.Join(t.TempDir(), "addrs")
	cfg, err := configure([]string{"-listen=127.0.0.1:0", "-ops-listen=127.0.0.1:0", "-addr-file=" + path}, func(string) string { return "" }, io.Discard)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- listenAndRun(ctx, cfg, slog.New(slog.DiscardHandler)) }()
	var lines []string
	for deadline := time.Now().Add(10 * time.Second); len(lines) < 2 && time.Now().Before(deadline); time.Sleep(10 * time.Millisecond) {
		b, _ := os.ReadFile(path)
		lines = strings.Fields(string(b))
	}
	if len(lines) != 2 || strings.HasSuffix(lines[0], ":0") || lines[0] == lines[1] {
		t.Fatalf("addr-file holds %q, want the two bound addresses", lines)
	}
	resp, err := http.Get("http://" + lines[1] + "/healthz")
	if err != nil || resp.StatusCode != http.StatusOK {
		t.Fatalf("the operations port in the addr-file does not answer: %v %v", resp, err)
	}
	resp.Body.Close()
	cancel()
	<-done
}

func TestListenFailure(t *testing.T) {
	taken, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer taken.Close()
	cfg, _ := configure([]string{"-listen", "127.0.0.1:0", "-ops-listen", taken.Addr().String()}, func(string) string { return "" }, io.Discard)
	if err := listenAndRun(context.Background(), cfg, slog.New(slog.DiscardHandler)); err == nil {
		t.Error("a taken port was not reported")
	}
}
