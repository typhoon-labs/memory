// Command fake-model is the conformance fixture that stands in for a model
// provider: Anthropic's Messages API and OpenAI's Chat Completions,
// deterministic, with faults asked for per request. It serves the model on
// one port and its operations (health, readiness and request records) on
// another, logs one JSON line per request to standard error, and is
// configured by flags or the environment. README.md is its contract.
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"syscall"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/fake-model/internal/server"
)

// settings is the command's configuration.
type settings struct {
	listen, opsListen string
	addrFile          string
	server            server.Config
	grace             time.Duration
	logLevel          slog.Level
}

// configure reads the flags, each defaulting to its environment variable,
// then to the built-in default: a flag beats the environment.
func configure(args []string, getenv func(string) string, usage io.Writer) (*settings, error) {
	fs := flag.NewFlagSet("fake-model", flag.ContinueOnError)
	fs.SetOutput(usage)
	var envErr error
	env := func(name, def string) string {
		if v := getenv(name); v != "" {
			return v
		}
		return def
	}
	str := func(name, envName, def, help string) *string {
		return fs.String(name, env(envName, def), help+" ("+envName+")")
	}
	integer := func(name, envName string, def int, help string) *int {
		v, err := strconv.Atoi(env(envName, strconv.Itoa(def)))
		if err != nil && envErr == nil {
			envErr = fmt.Errorf("%s: not an integer: %q", envName, getenv(envName))
		}
		return fs.Int(name, v, help+" ("+envName+")")
	}
	duration := func(name, envName string, def time.Duration, help string) *time.Duration {
		v, err := time.ParseDuration(env(envName, def.String()))
		if err != nil && envErr == nil {
			envErr = fmt.Errorf("%s: not a duration: %q", envName, getenv(envName))
		}
		return fs.Duration(name, v, help+" ("+envName+")")
	}
	listen := str("listen", "FAKE_MODEL_LISTEN", ":8080", "address of the model APIs")
	opsListen := str("ops-listen", "FAKE_MODEL_OPS_LISTEN", ":9090", "address of /healthz, /readyz and /requests")
	window := integer("context-window", "FAKE_MODEL_CONTEXT_WINDOW", 200_000, "largest request in input tokens")
	interval := duration("interval", "FAKE_MODEL_INTERVAL", 0, "wait before each streamed content delta")
	maxHold := duration("max-hold", "FAKE_MODEL_MAX_HOLD", 10*time.Minute, "longest a stall holds a connection")
	maxBody := integer("max-body", "FAKE_MODEL_MAX_BODY", 32<<20, "largest request body in bytes")
	records := integer("records", "FAKE_MODEL_RECORDS", 10_000, "request records kept")
	grace := duration("shutdown-grace", "FAKE_MODEL_SHUTDOWN_GRACE", 10*time.Second, "time responses in progress get to finish at shutdown")
	level := str("log-level", "FAKE_MODEL_LOG_LEVEL", "info", "debug, info, warn or error")
	addrFile := str("addr-file", "FAKE_MODEL_ADDR_FILE", "", "file to write the two bound addresses to, the model port's then the operations port's, once both listen")
	if envErr != nil {
		return nil, envErr
	}
	if err := fs.Parse(args); err != nil {
		return nil, err
	}
	if fs.NArg() > 0 {
		return nil, fmt.Errorf("unexpected arguments: %v", fs.Args())
	}
	s := &settings{listen: *listen, opsListen: *opsListen, addrFile: *addrFile, grace: *grace, server: server.Config{
		ContextWindow: *window, Interval: *interval, MaxHold: *maxHold, MaxBody: int64(*maxBody), Records: *records,
	}}
	switch {
	case *window < 1:
		return nil, errors.New("context-window must be at least 1")
	case *maxBody < 1:
		return nil, errors.New("max-body must be at least 1")
	case *records < 1:
		return nil, errors.New("records must be at least 1")
	case *interval < 0 || *grace < 0:
		return nil, errors.New("interval and shutdown-grace cannot be negative")
	case *maxHold <= 0:
		return nil, errors.New("max-hold must be positive")
	}
	if err := s.logLevel.UnmarshalText([]byte(*level)); err != nil {
		return nil, fmt.Errorf("log-level: %w", err)
	}
	return s, nil
}

func main() {
	cfg, err := configure(os.Args[1:], os.Getenv, os.Stderr)
	if errors.Is(err, flag.ErrHelp) {
		return
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "fake-model:", err)
		os.Exit(2)
	}
	log := slog.New(slog.NewJSONHandler(os.Stderr, &slog.HandlerOptions{Level: cfg.logLevel}))
	cfg.server.Log = log
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	if err := listenAndRun(ctx, cfg, log); err != nil {
		log.Error("fake-model stopped", "err", err)
		os.Exit(1)
	}
}

func listenAndRun(ctx context.Context, cfg *settings, log *slog.Logger) error {
	apiLn, err := net.Listen("tcp", cfg.listen)
	if err != nil {
		return err
	}
	opsLn, err := net.Listen("tcp", cfg.opsListen)
	if err != nil {
		apiLn.Close()
		return err
	}
	if cfg.addrFile != "" {
		if err := writeAddrs(cfg.addrFile, apiLn.Addr().String(), opsLn.Addr().String()); err != nil {
			apiLn.Close()
			opsLn.Close()
			return err
		}
	}
	return run(ctx, cfg, apiLn, opsLn, log)
}

// writeAddrs writes the bound addresses, one a line, whole or not at all:
// a reader that finds the file finds both, so a caller can ask for port 0
// and learn the ports, never racing another process for them.
func writeAddrs(path string, addrs ...string) error {
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, []byte(strings.Join(addrs, "\n")+"\n"), 0o600); err != nil {
		return fmt.Errorf("addr-file: %w", err)
	}
	if err := os.Rename(tmp, path); err != nil {
		return fmt.Errorf("addr-file: %w", err)
	}
	return nil
}

// run serves until ctx ends, then shuts down: readiness fails and stalls
// end at once, responses in progress get the grace period to finish, and
// whatever is left is closed.
func run(ctx context.Context, cfg *settings, apiLn, opsLn net.Listener, log *slog.Logger) error {
	s := server.New(cfg.server)
	errorLog := slog.NewLogLogger(log.Handler(), slog.LevelWarn)
	// No read or write timeout: streams, stalls and slow first bytes are
	// the point. Only a client's headers are bounded.
	apiSrv := &http.Server{Handler: s.API(), ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 2 * time.Minute, ErrorLog: errorLog}
	opsSrv := &http.Server{Handler: s.Ops(), ReadHeaderTimeout: 10 * time.Second, ErrorLog: errorLog}
	errs := make(chan error, 2)
	go func() { errs <- apiSrv.Serve(apiLn) }()
	go func() { errs <- opsSrv.Serve(opsLn) }()
	log.Info("fake-model started", "api", apiLn.Addr().String(), "ops", opsLn.Addr().String(),
		"context_window", cfg.server.ContextWindow, "interval", cfg.server.Interval.String(), "max_hold", cfg.server.MaxHold.String())
	var failed error
	select {
	case <-ctx.Done():
	case failed = <-errs:
	}
	log.Info("shutting down", "grace", cfg.grace.String())
	s.Drain()
	shutdown, cancel := context.WithTimeout(context.Background(), cfg.grace)
	defer cancel()
	if err := apiSrv.Shutdown(shutdown); err != nil {
		log.Warn("the grace period ran out; closing the responses left", "err", err)
		apiSrv.Close()
	}
	opsSrv.Close()
	if failed != nil && !errors.Is(failed, http.ErrServerClosed) {
		return failed
	}
	return nil
}
