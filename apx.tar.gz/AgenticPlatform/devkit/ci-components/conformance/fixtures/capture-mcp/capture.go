// Package capturemcp is capture-mcp, the capturing MCP server of the
// platform-controls suites (plan/local-build.md, "B2 in detail", "The
// suites' fixtures"): an MCP server over Streamable HTTP with two tools, one
// that every role may see and one that the gateway shows to
// platform-engineer alone, which records each request's headers and its
// token's claims and returns them as the tools' results.
//
// It records, never judges: it verifies no token, so a case reads what
// arrived and decides. Credential values never leave it: a credential
// header is recorded by name, and a bearer token by its decoded header and
// claims, never its signature or its text, so a record cannot be replayed.
//
// Two ports, like the fake model server's: the MCP endpoint, which the
// gateways reach, and the operations port, where only the suites' runner
// reads and clears the records.
package capturemcp

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
)

// The tools.
const (
	ToolEveryone = "whoami"
	ToolPlatform = "platform-diagnostics"
)

// MarkerHeader carries the suite's ID for a request, by which a case finds
// its records.
const MarkerHeader = "X-Conformance-Id"

// credentialHeaders are recorded by name only.
var credentialHeaders = []string{"authorization", "proxy-authorization", "x-api-key", "cookie"}

// Record is one request as it arrived.
type Record struct {
	Time        time.Time         `json:"time"`
	ID          string            `json:"id,omitempty"` // the suite's marker
	Method      string            `json:"method"`       // the JSON-RPC method, or "" when the body was not JSON-RPC
	Tool        string            `json:"tool,omitempty"`
	Version     string            `json:"protocol_version,omitempty"`
	Session     bool              `json:"session"`     // an Mcp-Session-Id arrived
	Headers     map[string]string `json:"headers"`     // first values, lower-case names; credentials as "<redacted>"
	Credentials []string          `json:"credentials"` // which credential headers arrived
	Token       *Token            `json:"token,omitempty"`
}

// Token is what a bearer token said, never the token itself.
type Token struct {
	Header map[string]any `json:"header"`
	Claims map[string]any `json:"claims"`
}

// Server is capture-mcp.
type Server struct {
	mu      sync.Mutex
	records []Record
	max     int
	mcp     *mcp.Server
	ready   func() bool
}

// New returns a server keeping the latest max records.
func New(max int, ready func() bool) *Server {
	if max <= 0 {
		max = 10000
	}
	s := &Server{max: max, ready: ready}
	readOnly := map[string]any{"readOnlyHint": true, "destructiveHint": false, "idempotentHint": true, "openWorldHint": false}
	empty := map[string]any{"type": "object", "properties": map[string]any{}, "additionalProperties": false}
	s.mcp = &mcp.Server{
		Name: "capture-mcp", Version: "0.1.0",
		Tools: []mcp.Tool{
			{Name: ToolEveryone, Description: "Returns what arrived with this call: its headers, credentials redacted, and its bearer token's claims.", InputSchema: empty, Annotations: readOnly},
			{Name: ToolPlatform, Description: "The same as whoami, for platform engineers only: the gateway hides it from every other role.", InputSchema: empty, Annotations: readOnly},
		},
		Call:      s.call,
		OnRequest: s.record,
	}
	return s
}

type recordKey struct{}

func (s *Server) record(r *http.Request, method, version, tool string) *http.Request {
	rec := Record{Time: time.Now().UTC(), ID: r.Header.Get(MarkerHeader), Method: method, Version: version, Tool: tool,
		Session: r.Header.Get("Mcp-Session-Id") != "", Headers: map[string]string{}, Credentials: []string{}}
	for k, v := range r.Header {
		name := strings.ToLower(k)
		if isCredential(name) {
			rec.Credentials = append(rec.Credentials, name)
			rec.Headers[name] = "<redacted>"
			continue
		}
		rec.Headers[name] = v[0]
	}
	if bearer, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer "); ok {
		if t, err := jose.Parse(strings.TrimSpace(bearer)); err == nil {
			rec.Token = &Token{Header: t.Header, Claims: t.Claims}
		}
	}
	s.mu.Lock()
	s.records = append(s.records, rec)
	if len(s.records) > s.max {
		s.records = s.records[len(s.records)-s.max:]
	}
	s.mu.Unlock()
	return r.WithContext(context.WithValue(r.Context(), recordKey{}, rec))
}

func isCredential(name string) bool {
	for _, c := range credentialHeaders {
		if name == c {
			return true
		}
	}
	return false
}

func (s *Server) call(ctx context.Context, r *http.Request, name string, _ json.RawMessage) (any, *mcp.RPCError) {
	rec, _ := r.Context().Value(recordKey{}).(Record)
	rec.Tool = name
	text, _ := json.Marshal(rec)
	return map[string]any{
		"content":           []map[string]any{{"type": "text", "text": string(text)}},
		"structuredContent": rec,
		"isError":           false,
	}, nil
}

// MCPHandler serves the MCP endpoint at any path.
func (s *Server) MCPHandler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet || r.Method == http.MethodDelete {
			// Legacy clients open a GET stream or end a session with DELETE;
			// this server pushes nothing and keeps no session state.
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		s.mcp.ServeHTTP(w, r)
	})
}

// OpsHandler serves health and the records.
func (s *Server) OpsHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusOK) })
	mux.HandleFunc("GET /readyz", func(w http.ResponseWriter, _ *http.Request) {
		if s.ready != nil && !s.ready() {
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	mux.HandleFunc("GET /requests", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{"requests": s.Records(r.URL.Query().Get("id"))})
	})
	mux.HandleFunc("DELETE /requests", func(w http.ResponseWriter, r *http.Request) {
		s.Forget(r.URL.Query().Get("id"))
		w.WriteHeader(http.StatusNoContent)
	})
	return mux
}

// Records returns the records, oldest first: all, or one marker's.
func (s *Server) Records(id string) []Record {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := []Record{}
	for _, r := range s.records {
		if id == "" || r.ID == id {
			out = append(out, r)
		}
	}
	return out
}

// Forget drops the records: all, or one marker's.
func (s *Server) Forget(id string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if id == "" {
		s.records = nil
		return
	}
	kept := s.records[:0]
	for _, r := range s.records {
		if r.ID != id {
			kept = append(kept, r)
		}
	}
	s.records = kept
}
