package capturemcp

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

func TestRecordsWithoutCredentials(t *testing.T) {
	s := New(0, nil)
	ts := httptest.NewServer(s.MCPHandler())
	defer ts.Close()
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tok, _ := jose.Sign(map[string]any{"alg": "ES256", "typ": "at+jwt"}, map[string]any{"sub": "person", "aud": "https://gateway.agentic.internal/mcp/capture-mcp"}, key)
	c := &mcp.Client{URL: ts.URL, Token: tok, HTTP: &outcome.Client{}, Header: map[string]string{MarkerHeader: "m1", "X-Api-Key": "secret-key", "Traceparent": "00-abc-def-01"}}
	names, call := c.ListTools(context.Background())
	if !call.OK() || strings.Join(names, ",") != ToolEveryone+","+ToolPlatform {
		t.Fatalf("tools/list: %v %s", names, call)
	}
	res := c.CallTool(context.Background(), ToolEveryone, nil)
	r, err := res.Result()
	if err != nil {
		t.Fatal(err)
	}
	if strings.Contains(r.Content[0].Text, tok) || strings.Contains(r.Content[0].Text, "secret-key") {
		t.Errorf("a credential's value left the fixture: %s", r.Content[0].Text)
	}
	var rec Record
	json.Unmarshal(r.StructuredContent, &rec)
	if rec.Token == nil || rec.Token.Claims["sub"] != "person" || rec.Tool != ToolEveryone || rec.ID != "m1" || rec.Headers["traceparent"] != "00-abc-def-01" {
		t.Errorf("the record: %+v", rec)
	}
	if strings.Join(rec.Credentials, ",") == "" || rec.Headers["authorization"] != "<redacted>" || rec.Headers["x-api-key"] != "<redacted>" {
		t.Errorf("credentials must be named, not kept: %+v", rec)
	}
	ops := httptest.NewServer(s.OpsHandler())
	defer ops.Close()
	resp, _ := http.Get(ops.URL + "/requests?id=m1")
	var doc struct{ Requests []Record }
	json.NewDecoder(resp.Body).Decode(&doc)
	resp.Body.Close()
	if len(doc.Requests) != 2 {
		t.Errorf("want 2 records for m1, got %d", len(doc.Requests))
	}
	req, _ := http.NewRequest(http.MethodDelete, ops.URL+"/requests?id=m1", nil)
	http.DefaultClient.Do(req)
	if n := len(s.Records("m1")); n != 0 {
		t.Errorf("DELETE kept %d records", n)
	}
}

func TestKeepsTheLatest(t *testing.T) {
	s := New(2, nil)
	ts := httptest.NewServer(s.MCPHandler())
	defer ts.Close()
	for _, id := range []string{"a", "b", "c"} {
		(&mcp.Client{URL: ts.URL, HTTP: &outcome.Client{}, Header: map[string]string{MarkerHeader: id}}).ListTools(context.Background())
	}
	recs := s.Records("")
	if len(recs) != 2 || recs[0].ID != "b" || recs[1].ID != "c" {
		t.Errorf("records: %+v", recs)
	}
}
