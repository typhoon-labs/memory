package relayagent

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

func token(t *testing.T, claims map[string]any) string {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	tok, err := jose.Sign(map[string]any{"alg": "ES256", "typ": "at+jwt"}, claims, key)
	if err != nil {
		t.Fatal(err)
	}
	return tok
}

func TestExchangeAndForward(t *testing.T) {
	person := token(t, map[string]any{"sub": "person", "aud": "https://gateway.agentic.internal/a2a/relay-agent"})
	chain := token(t, map[string]any{"sub": "person", "aud": "https://workloads-gateway.agentic.internal/v1", "act": map[string]any{"sub": "agentic-local/conformance/relay-agent"}})
	actor := filepath.Join(t.TempDir(), "token")
	os.WriteFile(actor, []byte("actor-token\n"), 0o600)
	var form map[string][]string
	sts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.ParseForm()
		form = r.PostForm
		if r.PostForm.Get("resource") == "https://not-allowed" {
			w.WriteHeader(400)
			json.NewEncoder(w).Encode(map[string]string{"error": "invalid_target", "reason": "resource_not_allowed"})
			return
		}
		json.NewEncoder(w).Encode(map[string]string{"access_token": chain})
	}))
	defer sts.Close()
	var got string
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		w.Write([]byte(`{"ok":true}`))
	}))
	defer target.Close()
	a := &Agent{Name: "relay-agent", TokenEndpoint: sts.URL, ActorTokenFile: actor, HTTP: &outcome.Client{}}

	rep := a.Relay(context.Background(), person, Instruction{Resource: "https://workloads-gateway.agentic.internal/v1", Call: Target{Kind: "http", URL: target.URL}})
	if got != chain {
		t.Errorf("exchange mode called on with another token")
	}
	if form["actor_token"][0] != "actor-token" || form["subject_token"][0] != person || form["actor_token_type"][0] != "urn:ietf:params:oauth:token-type:jwt" {
		t.Errorf("the exchange request: %v", form)
	}
	if rep.Exchange.Status != 200 || rep.Exchange.Claims["aud"] != "https://workloads-gateway.agentic.internal/v1" || rep.Call.Outcome.Status != 200 {
		t.Errorf("the report: %+v", rep)
	}
	raw, _ := json.Marshal(rep)
	if strings.Contains(string(raw), chain) || strings.Contains(string(raw), person) {
		t.Errorf("the report carries a token")
	}

	a.Relay(context.Background(), person, Instruction{Mode: Forward, Call: Target{Kind: "http", URL: target.URL}})
	if got != person {
		t.Errorf("forward mode did not send its caller's token on")
	}

	rep = a.Relay(context.Background(), person, Instruction{Resource: "https://not-allowed", Call: Target{Kind: "http", URL: target.URL}})
	if rep.Exchange.Reason != "resource_not_allowed" || rep.Call != nil {
		t.Errorf("a refused exchange: %+v", rep)
	}

	rep = a.Relay(context.Background(), "", Instruction{Call: Target{Kind: "http", URL: target.URL}})
	if rep.Error == "" || rep.Call != nil {
		t.Errorf("no token to exchange: %+v", rep)
	}
}

func TestA2A(t *testing.T) {
	a := &Agent{Name: "outsider-agent", HTTP: &outcome.Client{}}
	ts := httptest.NewServer(a.Handler())
	defer ts.Close()
	resp, err := http.Get(ts.URL + "/.well-known/agent-card.json")
	if err != nil || resp.StatusCode != 200 {
		t.Fatalf("agent card: %v", err)
	}
	resp.Body.Close()
	resp, _ = http.Post(ts.URL, "application/json", strings.NewReader(`{"jsonrpc":"2.0","id":7,"method":"message/send","params":{"message":{"parts":[{"kind":"data","data":{"mode":"forward","call":{"kind":"http","url":"http://127.0.0.1:1/"}}}]}}}`))
	var doc struct {
		ID     int `json:"id"`
		Result struct {
			Parts []struct {
				Data Report `json:"data"`
			} `json:"parts"`
		} `json:"result"`
	}
	json.NewDecoder(resp.Body).Decode(&doc)
	resp.Body.Close()
	if doc.ID != 7 || len(doc.Result.Parts) != 1 || doc.Result.Parts[0].Data.Agent != "outsider-agent" || doc.Result.Parts[0].Data.Call.Outcome.Kind != outcome.Refused {
		t.Errorf("message/send: %+v", doc)
	}
}
