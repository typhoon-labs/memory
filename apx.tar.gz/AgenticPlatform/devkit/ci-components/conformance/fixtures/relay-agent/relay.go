// Package relayagent is relay-agent, the fixture agent of the delegation
// suite (plan/local-build.md, "B2 in detail", "The suites' fixtures"): an
// HTTP endpoint on its A2A route that, for each request, exchanges its
// caller's token at the STS for the target the request names, calls that
// target through the hosted-workloads deployment, and returns the answer. In
// forward mode it sends its caller's token on unchanged instead: the
// delegation suite's refusal twin, an agent that forwards. outsider-agent is
// the same image under its own service account.
//
// The request is an A2A `message/send` whose data part is an Instruction;
// the answer is an A2A message whose data part is a Report. A Report holds
// the claims of the tokens involved and what became of the call, never a
// token: the suite judges what happened without being able to replay it.
// The exchange follows design/identity.md, "A delegated call, step by step",
// and B1's exchange profile (the actor token typed as a JWT).
package relayagent

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

// Modes.
const (
	Exchange = "exchange"
	Forward  = "forward"
)

// Instruction is what the suite asks the agent to do.
type Instruction struct {
	Mode     string `json:"mode"`               // exchange (default) or forward
	Resource string `json:"resource,omitempty"` // what to exchange for; default the call's URL without its path past the route
	Call     Target `json:"call"`
	Marker   string `json:"marker,omitempty"` // sent on as X-Conformance-Id
}

// Target is the call to make with the token.
type Target struct {
	Kind   string            `json:"kind"` // mcp-tool or http
	URL    string            `json:"url"`
	Tool   string            `json:"tool,omitempty"`
	Method string            `json:"method,omitempty"`
	Header map[string]string `json:"header,omitempty"`
	Body   string            `json:"body,omitempty"`
}

// Report is what the agent did.
type Report struct {
	Agent    string          `json:"agent"`
	Mode     string          `json:"mode"`
	Inbound  TokenReport     `json:"inbound"`
	Exchange *ExchangeReport `json:"exchange,omitempty"`
	Call     *CallReport     `json:"call,omitempty"`
	Error    string          `json:"error,omitempty"`
}

// TokenReport says whether a token arrived and what it claimed.
type TokenReport struct {
	Present bool           `json:"present"`
	Header  map[string]any `json:"header,omitempty"`
	Claims  map[string]any `json:"claims,omitempty"`
}

// ExchangeReport is the STS's answer.
type ExchangeReport struct {
	Resource string         `json:"resource"`
	Status   int            `json:"status"`
	Error    string         `json:"error,omitempty"`
	Reason   string         `json:"reason,omitempty"`
	Header   map[string]any `json:"header,omitempty"` // the issued token's JWS header
	Claims   map[string]any `json:"claims,omitempty"` // the issued token's claims
	Failure  string         `json:"failure,omitempty"`
}

// CallReport is what became of the call.
type CallReport struct {
	Outcome outcome.Outcome `json:"outcome"`
	Era     string          `json:"era,omitempty"`       // for an MCP call
	RPC     *mcp.RPCError   `json:"rpc_error,omitempty"` // for an MCP call
	Result  json.RawMessage `json:"result,omitempty"`    // an MCP tool's result
}

// Agent is relay-agent or outsider-agent.
type Agent struct {
	Name           string // as it reports itself
	TokenEndpoint  string // the STS's /token
	ActorTokenFile string // the projected token for the STS's audience, re-read on every exchange
	HTTP           *outcome.Client
	Log            *slog.Logger
}

// Handler serves the agent card and message/send at any path.
func (a *Agent) Handler() http.Handler {
	mux := http.NewServeMux()
	card := func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"name": a.Name, "description": "Conformance fixture agent: exchanges its caller's token and calls on, or forwards it unchanged.",
			"version": "0.1.0", "protocolVersion": "0.3.0", "url": "/", "capabilities": map[string]any{},
			"defaultInputModes": []string{"application/json"}, "defaultOutputModes": []string{"application/json"},
			"skills": []map[string]any{{"id": "relay", "name": "relay", "description": "Exchange and call on", "tags": []string{"conformance"}}},
		})
	}
	mux.HandleFunc("GET /.well-known/agent-card.json", card)
	mux.HandleFunc("GET /.well-known/agent.json", card)
	mux.HandleFunc("POST /", a.serve)
	return mux
}

type rpc struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Method  string          `json:"method"`
	Params  struct {
		Message struct {
			Parts []struct {
				Kind string          `json:"kind"`
				Data json.RawMessage `json:"data"`
			} `json:"parts"`
		} `json:"message"`
	} `json:"params"`
}

func (a *Agent) serve(w http.ResponseWriter, r *http.Request) {
	raw, _ := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	var req rpc
	if err := json.Unmarshal(raw, &req); err != nil || req.Method != "message/send" {
		writeRPCError(w, req.ID, -32600, "want a JSON-RPC message/send")
		return
	}
	var in Instruction
	found := false
	for _, p := range req.Params.Message.Parts {
		if p.Kind == "data" && json.Unmarshal(p.Data, &in) == nil && in.Call.URL != "" {
			found = true
			break
		}
	}
	if !found {
		writeRPCError(w, req.ID, -32602, "the message needs a data part with an instruction whose call has a url")
		return
	}
	rep := a.Relay(r.Context(), bearer(r), in)
	if a.Log != nil {
		a.Log.Info("relay", "mode", rep.Mode, "call", in.Call.URL, "error", rep.Error)
	}
	data, _ := json.Marshal(rep)
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"jsonrpc": "2.0", "id": req.ID, "result": map[string]any{
		"kind": "message", "role": "agent", "messageId": fmt.Sprintf("relay-%d", time.Now().UnixNano()),
		"parts": []map[string]any{{"kind": "data", "data": json.RawMessage(data)}},
	}})
}

func bearer(r *http.Request) string {
	t, _ := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
	return strings.TrimSpace(t)
}

// Relay does what the instruction says with the caller's token.
func (a *Agent) Relay(ctx context.Context, inbound string, in Instruction) Report {
	mode := in.Mode
	if mode == "" {
		mode = Exchange
	}
	rep := Report{Agent: a.Name, Mode: mode}
	if t, err := jose.Parse(inbound); err == nil {
		rep.Inbound = TokenReport{Present: true, Header: t.Header, Claims: t.Claims}
	} else if inbound != "" {
		rep.Inbound = TokenReport{Present: true}
	}
	token := inbound
	switch mode {
	case Forward:
	case Exchange:
		if inbound == "" {
			rep.Error = "no token arrived to exchange: the gateway must pass the caller's token on to this route"
			return rep
		}
		resource := in.Resource
		if resource == "" {
			resource = in.Call.URL
		}
		ex, issued := a.exchange(ctx, inbound, resource)
		rep.Exchange = &ex
		if issued == "" {
			return rep
		}
		token = issued
	default:
		rep.Error = "mode must be exchange or forward"
		return rep
	}
	rep.Call = a.call(ctx, token, in)
	return rep
}

func (a *Agent) exchange(ctx context.Context, subject, resource string) (ExchangeReport, string) {
	rep := ExchangeReport{Resource: resource}
	actor, err := os.ReadFile(a.ActorTokenFile)
	if err != nil {
		rep.Failure = "reading the actor token: " + err.Error()
		return rep, ""
	}
	form := url.Values{
		"grant_type":         {"urn:ietf:params:oauth:grant-type:token-exchange"},
		"subject_token":      {subject},
		"subject_token_type": {"urn:ietf:params:oauth:token-type:access_token"},
		"actor_token":        {strings.TrimSpace(string(actor))},
		"actor_token_type":   {"urn:ietf:params:oauth:token-type:jwt"},
		"resource":           {resource},
	}
	o := a.HTTP.Do(ctx, outcome.Request{Method: http.MethodPost, URL: a.TokenEndpoint, Body: form.Encode(),
		Header: map[string]string{"Content-Type": "application/x-www-form-urlencoded"}, Timeout: outcome.Of(15 * time.Second)})
	if o.Kind != outcome.Response {
		rep.Failure = "the STS did not answer: " + o.String()
		return rep, ""
	}
	rep.Status = o.Status
	var body struct {
		AccessToken string `json:"access_token"`
		Error       string `json:"error"`
		Reason      string `json:"reason"`
	}
	json.Unmarshal([]byte(o.Body), &body)
	rep.Error, rep.Reason = body.Error, body.Reason
	if o.Status != http.StatusOK || body.AccessToken == "" {
		return rep, ""
	}
	if t, err := jose.Parse(body.AccessToken); err == nil {
		rep.Header, rep.Claims = t.Header, t.Claims
	}
	return rep, body.AccessToken
}

func (a *Agent) call(ctx context.Context, token string, in Instruction) *CallReport {
	h := map[string]string{}
	for k, v := range in.Call.Header {
		h[k] = v
	}
	if in.Marker != "" {
		h["X-Conformance-Id"] = in.Marker
	}
	switch in.Call.Kind {
	case "mcp-tool":
		c := &mcp.Client{URL: in.Call.URL, Token: token, Header: h, HTTP: a.HTTP}
		call := c.CallTool(ctx, in.Call.Tool, nil)
		rep := &CallReport{Outcome: call.Outcome, Era: c.Era()}
		if call.Response != nil {
			rep.RPC = call.Response.Error
			rep.Result = call.Response.Result
		}
		return rep
	default:
		if token != "" {
			h["Authorization"] = "Bearer " + token
		}
		method := in.Call.Method
		if method == "" {
			method = http.MethodPost
		}
		return &CallReport{Outcome: a.HTTP.Do(ctx, outcome.Request{Method: method, URL: in.Call.URL, Header: h, Body: in.Call.Body})}
	}
}

func writeRPCError(w http.ResponseWriter, id json.RawMessage, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"jsonrpc": "2.0", "id": id, "error": map[string]any{"code": code, "message": msg}})
}
