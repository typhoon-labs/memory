// Package probe is the probe fixture (plan/local-build.md, "B2 in detail",
// "The suites' fixtures"): a pod that makes one request when the runner asks
// and reports what became of it, so the bypass suite can try a path from a
// namespace other than its own. One probe runs in conformance-probe,
// meshed with no grants, and one in conformance-nomesh, outside the mesh.
//
// The API is one call: POST /probe with an outcome.Request, answered with
// the outcome.Outcome. It carries no credential of its own and keeps no
// state; only the runner may reach it (NetworkPolicy, and in the mesh an
// AuthorizationPolicy), since anyone who can call it can make it call out.
package probe

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

// Server answers the runner's requests with what became of them.
type Server struct {
	Client *outcome.Client
	Log    *slog.Logger
}

// Handler is the probe's HTTP API.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusNoContent) })
	mux.HandleFunc("POST /probe", func(w http.ResponseWriter, r *http.Request) {
		var req outcome.Request
		dec := json.NewDecoder(io.LimitReader(r.Body, 1<<20))
		dec.DisallowUnknownFields()
		if err := dec.Decode(&req); err != nil || req.URL == "" {
			http.Error(w, fmt.Sprintf("want an outcome.Request with a url: %v", err), http.StatusBadRequest)
			return
		}
		if req.Timeout.D() > 5*time.Minute {
			http.Error(w, "timeout_ms is capped at 5 minutes", http.StatusBadRequest)
			return
		}
		o := s.Client.Do(r.Context(), req)
		if s.Log != nil {
			s.Log.Info("probe", "method", req.Method, "url", req.URL, "kind", o.Kind, "status", o.Status, "elapsed_ms", o.Elapsed)
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(o)
	})
	return mux
}

// Remote asks a probe at URL to make requests.
type Remote struct {
	URL  string // the probe's base URL, such as http://probe.conformance-probe.svc.cluster.local:8080
	HTTP *outcome.Client
}

// Do asks the probe to make r and returns what became of it. If the probe
// itself cannot be reached, the outcome is an Error naming that, so it is
// never mistaken for a refusal of r.
func (p *Remote) Do(ctx context.Context, r outcome.Request) outcome.Outcome {
	body, _ := json.Marshal(r)
	timeout := r.Timeout.D()
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	o := p.HTTP.Do(ctx, outcome.Request{Method: http.MethodPost, URL: p.URL + "/probe", Body: string(body),
		Header: map[string]string{"Content-Type": "application/json"}, Timeout: outcome.Of(timeout + 15*time.Second)})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		return outcome.Outcome{Kind: outcome.Error, Error: fmt.Sprintf("the probe at %s did not answer: %s", p.URL, o)}
	}
	var got outcome.Outcome
	dec := json.NewDecoder(bytes.NewReader([]byte(o.Body)))
	if err := dec.Decode(&got); err != nil {
		return outcome.Outcome{Kind: outcome.Error, Error: fmt.Sprintf("the probe at %s answered with something else: %v", p.URL, err)}
	}
	return got
}
