package probe

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

func TestProbe(t *testing.T) {
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(204) }))
	defer target.Close()
	p := httptest.NewServer((&Server{Client: &outcome.Client{}}).Handler())
	defer p.Close()
	r := &Remote{URL: p.URL, HTTP: &outcome.Client{}}
	if o := r.Do(context.Background(), outcome.Request{URL: target.URL}); o.Kind != outcome.Response || o.Status != 204 {
		t.Errorf("through the probe: %+v", o)
	}
	gone := &Remote{URL: "http://127.0.0.1:1", HTTP: &outcome.Client{}}
	if o := gone.Do(context.Background(), outcome.Request{URL: target.URL}); o.Kind != outcome.Error {
		t.Errorf("an unreachable probe must not look like a refusal: %+v", o)
	}
}
