package contract

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kms"
)

// STS is the token service of the contract stage: the real delegation-sts
// binary from its pinned image, or, in the suites' own tests, a stand-in.
type STS interface {
	Issuer() string
	// JWKSURL and TokenURL are where the harness reaches it.
	JWKSURL() string
	TokenURL() string
	// HTTP is a client that trusts its TLS.
	HTTP() *http.Client
	// Audit returns its audit records so far.
	Audit() []string
	// Sign signs header and claims with the STS's own signing key, for
	// chain tokens only that key can forge.
	Sign(ctx context.Context, header, claims map[string]any) (string, error)
	Close()
}

// PolicyAgent is one agent of the STS policy.
type PolicyAgent struct {
	Actor   string   `json:"actor"`
	Routes  []string `json:"routes"`
	After   []string `json:"after"`
	Targets []string `json:"targets"`
}

// Policy is the STS policy the stage runs: the workload under test and the
// runner's own caller.
type Policy struct {
	Version         int                    `json:"version"`
	MaxChain        int                    `json:"max_chain"`
	TokenTTLSeconds int                    `json:"token_ttl_seconds"`
	CarriedClaims   []string               `json:"carried_claims"`
	RateLimit       map[string]int         `json:"rate_limit"`
	Agents          map[string]PolicyAgent `json:"agents"`
}

// NewPolicy is the default policy shape with no agents.
func NewPolicy() *Policy {
	return &Policy{Version: 1, MaxChain: 3, TokenTTLSeconds: 300,
		CarriedClaims: []string{"roles", "team", "sid", "preferred_username", "acr", "auth_time"},
		RateLimit:     map[string]int{"per_second": 10, "burst": 50}, Agents: map[string]PolicyAgent{}}
}

// RealSTSOptions configure the STS binary.
type RealSTSOptions struct {
	Binary         string
	Dir            string // its files: configuration, policy, TLS, kubeconfig
	Issuer         string // https URL; also its tokens' iss
	Domain         string
	Cluster        string
	KeycloakIssuer string
	KeycloakBase   string // where the issuer's JWKS and introspection answer, http
	KubeURL        string // the fake TokenReview API
	Policy         *Policy
	DenyList       []string // subs
	TaskHeader     string
	Alias          string // the signing alias
	KMS            *kms.Client
	Ports          [3]int // public, token, ops on 127.0.0.1
	Log            io.Writer
}

type realSTS struct {
	o      RealSTSOptions
	p      *proc
	client *http.Client
	keyID  string

	kidOnce sync.Once
	kid     string
	kidErr  error
}

// StartRealSTS writes the STS's files, makes sure its signing alias exists
// in KMS, and starts it, waiting until it is ready.
func StartRealSTS(ctx context.Context, o RealSTSOptions) (STS, error) {
	if err := os.MkdirAll(o.Dir, 0o700); err != nil {
		return nil, err
	}
	host := hostOf(o.Issuer)
	ca, certPEM, keyPEM, err := tlsFiles(host)
	if err != nil {
		return nil, err
	}
	keyID, created, err := o.KMS.EnsureSigningAlias(ctx, o.Alias, "contract-stage STS signing key (devkit/ci-components conformance)")
	if err != nil {
		return nil, fmt.Errorf("the STS's signing alias %s: %w", o.Alias, err)
	}
	if created {
		fmt.Fprintf(o.Log, "harness: created KMS key %s behind %s\n", keyID, o.Alias)
	}
	policy, _ := json.MarshalIndent(o.Policy, "", "  ")
	deny := map[string]any{"entries": []any{}}
	for _, sub := range o.DenyList {
		deny["entries"] = append(deny["entries"].([]any), map[string]any{"sub": sub, "expires": time.Now().Add(2 * time.Hour).UTC().Format(time.RFC3339)})
	}
	denyJSON, _ := json.Marshal(deny)
	kubeconfig := fmt.Sprintf(`{"apiVersion":"v1","kind":"Config","clusters":[{"name":"fake","cluster":{"server":%q}}],`+
		`"users":[{"name":"sts","user":{"token":"conformance"}}],"contexts":[{"name":"fake","context":{"cluster":"fake","user":"sts"}}],"current-context":"fake"}`, o.KubeURL)
	cfg := map[string]any{
		"issuer": o.Issuer, "token_endpoint": o.Issuer + "/token", "platform_domain": o.Domain, "cluster": o.Cluster,
		"listen":      map[string]string{"public": fmt.Sprintf("127.0.0.1:%d", o.Ports[0]), "token": fmt.Sprintf("127.0.0.1:%d", o.Ports[1]), "ops": fmt.Sprintf("127.0.0.1:%d", o.Ports[2])},
		"tls":         map[string]string{"cert_file": "tls.crt", "key_file": "tls.key"},
		"policy_file": "policy.yaml", "deny_list_file": "deny.yaml",
		"keycloak": map[string]string{"issuer": o.KeycloakIssuer, "jwks_url": o.KeycloakBase + "/jwks",
			"introspection_url": o.KeycloakBase + "/introspect", "client_assertion_file": "client-assertion"},
		"kubernetes": map[string]string{"kubeconfig": "kubeconfig.yaml"},
		"kms":        map[string]string{"alias": o.Alias, "endpoint": o.KMS.Endpoint, "region": o.KMS.Region},
	}
	if o.TaskHeader != "" {
		cfg["task_header"] = o.TaskHeader
	}
	cfgJSON, _ := json.MarshalIndent(cfg, "", "  ")
	for name, body := range map[string][]byte{
		"tls.crt": certPEM, "tls.key": keyPEM, "ca.crt": ca, "policy.yaml": policy, "deny.yaml": denyJSON,
		"kubeconfig.yaml": []byte(kubeconfig), "client-assertion": []byte("conformance"), "config.yaml": cfgJSON,
	} {
		if err := os.WriteFile(filepath.Join(o.Dir, name), body, 0o600); err != nil {
			return nil, err
		}
	}
	env := []string{"HOME=" + o.Dir, "AWS_ENDPOINT_URL=" + o.KMS.Endpoint, "AWS_REGION=" + o.KMS.Region,
		"AWS_ACCESS_KEY_ID=" + o.KMS.AccessKeyID, "AWS_SECRET_ACCESS_KEY=" + o.KMS.SecretAccessKey}
	if o.KMS.SessionToken != "" {
		env = append(env, "AWS_SESSION_TOKEN="+o.KMS.SessionToken)
	}
	p, err := startProc("sts", []string{o.Binary, "-config", filepath.Join(o.Dir, "config.yaml")}, env, o.Dir, o.Log)
	if err != nil {
		return nil, err
	}
	if err := p.waitHTTP(fmt.Sprintf("http://127.0.0.1:%d/readyz", o.Ports[2]), 60*time.Second); err != nil {
		p.stop(5 * time.Second)
		return nil, err
	}
	pool := x509.NewCertPool()
	pool.AppendCertsFromPEM(ca)
	client := &http.Client{Timeout: 15 * time.Second, Transport: &http.Transport{Proxy: nil,
		TLSClientConfig: &tls.Config{RootCAs: pool, ServerName: host}}}
	return &realSTS{o: o, p: p, client: client, keyID: keyID}, nil
}

func (s *realSTS) Issuer() string     { return s.o.Issuer }
func (s *realSTS) JWKSURL() string    { return fmt.Sprintf("https://127.0.0.1:%d/jwks", s.o.Ports[0]) }
func (s *realSTS) TokenURL() string   { return fmt.Sprintf("https://127.0.0.1:%d/token", s.o.Ports[1]) }
func (s *realSTS) HTTP() *http.Client { return s.client }
func (s *realSTS) Audit() []string    { return s.p.Lines() }
func (s *realSTS) Close()             { s.p.stop(10 * time.Second) }

// Sign signs with the alias's key through KMS, under the kid the STS
// publishes for it.
func (s *realSTS) Sign(ctx context.Context, header, claims map[string]any) (string, error) {
	s.kidOnce.Do(func() { s.kid, s.kidErr = s.signingKid(ctx) })
	if s.kidErr != nil {
		return "", s.kidErr
	}
	h := map[string]any{"kid": s.kid}
	for k, v := range header {
		h[k] = v
	}
	hb, _ := json.Marshal(h)
	cb, _ := json.Marshal(claims)
	input := b64(hb) + "." + b64(cb)
	if alg, _ := h["alg"].(string); alg != "ES256" {
		return "", fmt.Errorf("the STS's key signs ES256 only, not %v", h["alg"])
	}
	digest := sha256.Sum256([]byte(input))
	sig, err := s.o.KMS.SignDigest(ctx, s.o.Alias, digest[:])
	if err != nil {
		return "", err
	}
	return input + "." + b64(sig), nil
}

// signingKid finds the kid of the STS's signing key in its key set: the
// one whose key verifies a signature KMS makes.
func (s *realSTS) signingKid(ctx context.Context) (string, error) {
	set, err := fetchJWKS(ctx, s.client, s.JWKSURL())
	if err != nil {
		return "", err
	}
	digest := sha256.Sum256([]byte("conformance kid probe"))
	sig, err := s.o.KMS.SignDigest(ctx, s.o.Alias, digest[:])
	if err != nil {
		return "", err
	}
	for _, k := range set.Keys {
		pub, err := k.Public()
		if err != nil {
			continue
		}
		if ec, ok := pub.(*ecdsa.PublicKey); ok && ecdsa.Verify(ec, digest[:], new(big.Int).SetBytes(sig[:32]), new(big.Int).SetBytes(sig[32:])) {
			return k.Kid, nil
		}
	}
	return "", fmt.Errorf("no key in the STS's set %v verifies a signature by %s", set.Kids(), s.o.Alias)
}

func fetchJWKS(ctx context.Context, c *http.Client, u string) (jose.JWKS, error) {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	resp, err := c.Do(req)
	if err != nil {
		return jose.JWKS{}, err
	}
	defer resp.Body.Close()
	var set jose.JWKS
	if resp.StatusCode != http.StatusOK {
		return set, fmt.Errorf("%s: HTTP %d", u, resp.StatusCode)
	}
	return set, json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&set)
}

func b64(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }

func hostOf(u string) string {
	p, err := url.Parse(u)
	if err != nil {
		return u
	}
	return p.Hostname()
}

// tlsFiles makes a throwaway CA and a certificate for host and 127.0.0.1.
func tlsFiles(host string) (caPEM, certPEM, keyPEM []byte, err error) {
	caKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, nil, nil, err
	}
	now := time.Now()
	caTmpl := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "conformance contract-stage CA"},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour), IsCA: true, BasicConstraintsValid: true,
		KeyUsage: x509.KeyUsageCertSign}
	caDER, err := x509.CreateCertificate(rand.Reader, caTmpl, caTmpl, &caKey.PublicKey, caKey)
	if err != nil {
		return nil, nil, nil, err
	}
	ca, _ := x509.ParseCertificate(caDER)
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, nil, nil, err
	}
	tmpl := &x509.Certificate{SerialNumber: big.NewInt(2), Subject: pkix.Name{CommonName: host}, DNSNames: []string{host, "localhost"},
		IPAddresses: []net.IP{net.ParseIP("127.0.0.1")}, NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, ca, &key.PublicKey, caKey)
	if err != nil {
		return nil, nil, nil, err
	}
	kb, _ := x509.MarshalECPrivateKey(key)
	return pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: caDER}),
		pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}),
		pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: kb}), nil
}

// FakeSTS is a stand-in STS for the suites' own tests, where no STS binary
// exists: it exchanges as the policy says, checks the subject against the
// issuer's key and introspection-free, the actor with the fake Kubernetes
// API, and signs ES256 chain tokens. It is not the STS; the real one runs
// in the contract stage.
type FakeSTS struct {
	issuer  string
	policy  *Policy
	domain  string
	cluster string
	subject *Issuer
	kube    *Kube
	deny    []string
	key     *ecdsa.PrivateKey
	kid     string
	srv     *http.Server
	ln      net.Listener

	mu    sync.Mutex
	audit []string
}

// NewFakeSTS starts the stand-in on a local port.
func NewFakeSTS(issuer, domain, cluster string, policy *Policy, subject *Issuer, kube *Kube, deny []string) (*FakeSTS, error) {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, err
	}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	f := &FakeSTS{issuer: issuer, policy: policy, domain: domain, cluster: cluster, subject: subject, kube: kube, deny: deny,
		key: key, kid: "fake-sts-" + UUID()[:8], ln: ln}
	mux := http.NewServeMux()
	mux.HandleFunc("GET /jwks", func(w http.ResponseWriter, _ *http.Request) {
		k, _ := jose.PublicJWK(&key.PublicKey, f.kid, "ES256")
		writeJSON(w, http.StatusOK, jose.JWKS{Keys: []jose.JWK{k}})
	})
	mux.HandleFunc("POST /token", f.exchange)
	f.srv = &http.Server{Handler: mux}
	go f.srv.Serve(ln)
	return f, nil
}

func (f *FakeSTS) Issuer() string   { return f.issuer }
func (f *FakeSTS) JWKSURL() string  { return "http://" + f.ln.Addr().String() + "/jwks" }
func (f *FakeSTS) TokenURL() string { return "http://" + f.ln.Addr().String() + "/token" }
func (f *FakeSTS) HTTP() *http.Client {
	return &http.Client{Timeout: 15 * time.Second, Transport: &http.Transport{Proxy: nil}}
}
func (f *FakeSTS) Close() { f.srv.Close() }

func (f *FakeSTS) Audit() []string {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]string(nil), f.audit...)
}

func (f *FakeSTS) Sign(_ context.Context, header, claims map[string]any) (string, error) {
	h := map[string]any{"kid": f.kid}
	for k, v := range header {
		h[k] = v
	}
	return jose.Sign(h, claims, f.key)
}

func (f *FakeSTS) refuse(w http.ResponseWriter, record map[string]any, status int, errCode, reason string) {
	record["event.name"], record["refusal.error"], record["refusal.reason"] = "sts.token_exchange.refused", errCode, reason
	f.record(record)
	writeJSON(w, status, map[string]string{"error": errCode, "reason": reason})
}

func (f *FakeSTS) record(r map[string]any) {
	b, _ := json.Marshal(r)
	f.mu.Lock()
	f.audit = append(f.audit, string(b))
	f.mu.Unlock()
}

func (f *FakeSTS) route(r string) string {
	gw, rest, _ := strings.Cut(r, "/")
	return "https://" + gw + "." + f.domain + "/" + rest
}

func (f *FakeSTS) exchange(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	rec := map[string]any{"task.id": r.Header.Get("Agentic-Task-Id")}
	subjectRaw, actorRaw, resource := r.PostForm.Get("subject_token"), r.PostForm.Get("actor_token"), r.PostForm["resource"]
	if r.PostForm.Get("grant_type") != "urn:ietf:params:oauth:grant-type:token-exchange" || subjectRaw == "" {
		f.refuse(w, rec, 400, "invalid_request", "request_malformed")
		return
	}
	if actorRaw == "" {
		f.refuse(w, rec, 400, "invalid_request", "actor_missing")
		return
	}
	review := f.kube.review(actorRaw, []string{f.issuer})
	if ok, _ := review["authenticated"].(bool); !ok {
		f.refuse(w, rec, 400, "invalid_request", "actor_rejected")
		return
	}
	username, _ := review["user"].(map[string]any)["username"].(string)
	parts := strings.Split(strings.TrimPrefix(username, "system:serviceaccount:"), ":")
	actor := parts[0] + "/" + parts[len(parts)-1]
	var name string
	var agent PolicyAgent
	for n, a := range f.policy.Agents {
		if a.Actor == actor {
			name, agent = n, a
		}
	}
	if name == "" {
		f.refuse(w, rec, 400, "invalid_request", "actor_unknown")
		return
	}
	actorSub := f.cluster + "/" + actor
	rec["actor.sub"] = actorSub
	t, err := jose.Parse(subjectRaw)
	if err != nil {
		f.refuse(w, rec, 400, "invalid_request", "subject_signature")
		return
	}
	iss, _ := t.Claims["iss"].(string)
	sub, _ := t.Claims["sub"].(string)
	rec["user.id"] = sub
	switch {
	case iss != f.subject.URL:
		f.refuse(w, rec, 400, "invalid_request", "subject_issuer")
		return
	case t.HeaderString("alg") != "RS256" || t.Verify(&f.subject.key.PublicKey) != nil:
		f.refuse(w, rec, 400, "invalid_request", "subject_signature")
		return
	}
	if exp, _ := number(t.Claims["exp"]); time.Now().Unix() >= exp {
		f.refuse(w, rec, 400, "invalid_request", "subject_expired")
		return
	}
	if slices.Contains(f.deny, sub) {
		f.refuse(w, rec, 400, "invalid_request", "subject_denied")
		return
	}
	aud, _ := t.Claims["aud"].(string)
	ownRoute := false
	for _, rt := range agent.Routes {
		ownRoute = ownRoute || f.route(rt) == aud
	}
	if !ownRoute {
		f.refuse(w, rec, 400, "invalid_request", "subject_audience")
		return
	}
	if len(resource) != 1 {
		f.refuse(w, rec, 400, "invalid_target", "resource_missing")
		return
	}
	allowed := false
	for _, tg := range agent.Targets {
		allowed = allowed || f.route(tg) == resource[0]
	}
	if !allowed {
		f.refuse(w, rec, 400, "invalid_target", "resource_not_allowed")
		return
	}
	now := time.Now()
	claims := map[string]any{"iss": f.issuer, "sub": sub, "aud": resource[0], "client_id": actorSub,
		"act": map[string]any{"sub": actorSub}, "iat": now.Unix(), "nbf": now.Unix(), "exp": now.Add(300 * time.Second).Unix(), "jti": UUID()}
	for _, c := range f.policy.CarriedClaims {
		if v, ok := t.Claims[c]; ok {
			claims[c] = v
		}
	}
	tok, _ := jose.Sign(map[string]any{"alg": "ES256", "kid": f.kid, "typ": "at+jwt"}, claims, f.key)
	rec["event.name"], rec["token.jti"] = "sts.token_exchange.issued", claims["jti"]
	f.record(rec)
	w.Header().Set("Cache-Control", "no-store")
	writeJSON(w, http.StatusOK, map[string]any{"access_token": tok, "issued_token_type": "urn:ietf:params:oauth:token-type:access_token",
		"token_type": "Bearer", "expires_in": 300})
}
