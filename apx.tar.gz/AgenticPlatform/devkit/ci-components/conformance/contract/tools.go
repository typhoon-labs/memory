package contract

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
)

// ForbiddenTool is a destructive tool every MCP server of the harness
// lists beside the ones the workload is allowed, which no workload's
// allowlist names: the injection canary asks for it.
const ForbiddenTool = "conformance_forbidden_write"

// End is the fake model directive that does nothing: a tool output that
// carries it ends the loop a directive in the task started, since the
// latest directive applies.
const End = "[[fake-model]]"

// ToolCall is what the harness's MCP servers saw of one request: a call,
// or a list, accepted or refused at the token check.
type ToolCall struct {
	Time      time.Time
	Server    string
	Method    string
	Tool      string
	Arguments json.RawMessage
	Token     string // the raw bearer token, kept in memory only
	Claims    map[string]any
	Refused   string // why the token was refused, or ""
	TaskID    string // Agentic-Task-Id as received
	Trace     string // traceparent as received
}

// Script answers the nth call (from 1) of a task's tool calls with a text.
type Script func(n int, tool string, args []byte) string

// Tools plays the MCP servers a workload calls through the hosted-workloads
// gateway: each server's tools as the workload's workload.yaml requires
// them, behind the check a real server makes of the chain token it
// receives (the STS's signature, its route's audience, an act), so a token
// forwarded instead of exchanged is refused here as it would be there.
// What each call answers is scripted per task.
type Tools struct {
	Domain  string
	STS     STS
	servers map[string][]mcp.Tool

	mu      sync.Mutex
	calls   []ToolCall
	scripts map[string]Script // by task ID
	counts  map[string]int
	jwks    jose.JWKS
	fetched time.Time
}

// NewTools serves servers, a map of server name to the tool names its
// callers are allowed. A tool named list_* or get_* is read-only, any
// other destructive.
func NewTools(domain string, sts STS, servers map[string][]string) *Tools {
	t := &Tools{Domain: domain, STS: sts, servers: map[string][]mcp.Tool{}, scripts: map[string]Script{}, counts: map[string]int{}}
	for server, names := range servers {
		for _, n := range append(names, ForbiddenTool) {
			readOnly := strings.HasPrefix(n, "list_") || strings.HasPrefix(n, "get_")
			ann := map[string]any{"readOnlyHint": readOnly}
			if !readOnly {
				ann["destructiveHint"] = true
			}
			t.servers[server] = append(t.servers[server], mcp.Tool{Name: n, Description: "The contract stage's " + n,
				InputSchema: map[string]any{"type": "object", "properties": map[string]any{"query": map[string]any{"type": "string"}}},
				Annotations: ann})
		}
	}
	return t
}

// Script sets how a task's calls are answered.
func (t *Tools) Script(taskID string, s Script) {
	t.mu.Lock()
	t.scripts[taskID] = s
	t.mu.Unlock()
}

// Calls returns every request seen so far.
func (t *Tools) Calls() []ToolCall {
	t.mu.Lock()
	defer t.mu.Unlock()
	return append([]ToolCall(nil), t.calls...)
}

// Audience is the route a chain token for server must name.
func (t *Tools) Audience(server string) string {
	return "https://workloads-gateway." + t.Domain + "/mcp/" + server
}

// Handler serves /mcp/<server>.
func (t *Tools) Handler(server string) http.Handler {
	srv := &mcp.Server{Name: server, Version: "conformance", Tools: t.servers[server]}
	srv.Call = func(ctx context.Context, r *http.Request, name string, args json.RawMessage) (any, *mcp.RPCError) {
		task := r.Header.Get("Agentic-Task-Id")
		t.mu.Lock()
		t.counts[task]++
		n := t.counts[task]
		script := t.scripts[task]
		t.mu.Unlock()
		text := "ok: " + name + " " + End
		if script != nil {
			text = script(n, name, args)
		}
		return map[string]any{"content": []any{map[string]any{"type": "text", "text": text}}}, nil
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		raw := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
		claims, why := t.check(r.Context(), raw, server)
		var body struct {
			Method string `json:"method"`
			Params struct {
				Name      string          `json:"name"`
				Arguments json.RawMessage `json:"arguments"`
			} `json:"params"`
		}
		buf := readBody(r)
		json.Unmarshal(buf, &body)
		call := ToolCall{Time: time.Now(), Server: server, Method: body.Method, Tool: body.Params.Name, Arguments: body.Params.Arguments,
			Token: raw, Claims: claims, Refused: why, TaskID: r.Header.Get("Agentic-Task-Id"), Trace: r.Header.Get("Traceparent")}
		if body.Method != "" && !strings.HasPrefix(body.Method, "notifications/") {
			t.mu.Lock()
			t.calls = append(t.calls, call)
			t.mu.Unlock()
		}
		if why != "" {
			w.Header().Set("WWW-Authenticate", `Bearer error="invalid_token"`)
			http.Error(w, "the contract stage's MCP server refused the token: "+why, http.StatusUnauthorized)
			return
		}
		srv.ServeHTTP(w, r)
	})
}

// check verifies a chain token for server as the server would.
func (t *Tools) check(ctx context.Context, raw, server string) (map[string]any, string) {
	if raw == "" {
		return nil, "no token"
	}
	tok, err := jose.Parse(raw)
	if err != nil {
		return nil, "not a JWS"
	}
	if iss, _ := tok.Claims["iss"].(string); iss != t.STS.Issuer() {
		return tok.Claims, fmt.Sprintf("issuer %q is not the STS", iss)
	}
	key, err := t.key(ctx, tok.HeaderString("kid"))
	if err != nil {
		return tok.Claims, err.Error()
	}
	if tok.HeaderString("alg") != "ES256" || tok.Verify(key) != nil {
		return tok.Claims, "the STS's signature does not verify"
	}
	if aud, _ := tok.Claims["aud"].(string); aud != t.Audience(server) {
		return tok.Claims, fmt.Sprintf("audience %v, not %s", tok.Claims["aud"], t.Audience(server))
	}
	if _, ok := tok.Claims["act"].(map[string]any); !ok {
		return tok.Claims, "no act: not a chain token"
	}
	if exp, _ := number(tok.Claims["exp"]); time.Now().Unix() >= exp {
		return tok.Claims, "expired"
	}
	return tok.Claims, ""
}

func (t *Tools) key(ctx context.Context, kid string) (any, error) {
	t.mu.Lock()
	set, fetched := t.jwks, t.fetched
	t.mu.Unlock()
	if k, ok := set.Key(kid); ok {
		return k.Public()
	}
	if time.Since(fetched) < 2*time.Second {
		return nil, fmt.Errorf("kid %q is not the STS's", kid)
	}
	set, err := fetchJWKS(ctx, t.STS.HTTP(), t.STS.JWKSURL())
	if err != nil {
		return nil, fmt.Errorf("the STS's key set: %v", err)
	}
	t.mu.Lock()
	t.jwks, t.fetched = set, time.Now()
	t.mu.Unlock()
	if k, ok := set.Key(kid); ok {
		return k.Public()
	}
	return nil, fmt.Errorf("kid %q is not the STS's", kid)
}
