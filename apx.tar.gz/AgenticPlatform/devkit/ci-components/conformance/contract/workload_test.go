package contract

import (
	"os"
	"os/exec"
	"reflect"
	"testing"
)

// The stand-ins' YAML and JSON files say the same, read through helm;
// the build component's own fixture parses too. Skipped without helm,
// which the runner's images carry and the Go jobs' image does not.
func TestParseWorkloadYAML(t *testing.T) {
	helm, err := exec.LookPath("helm")
	if err != nil {
		t.Skip("no helm on PATH")
	}
	for _, kind := range []string{"agent", "mcp"} {
		y, _ := os.ReadFile("../suites/workload/standin/testdata/" + kind + ".workload.yaml")
		j, _ := os.ReadFile("../suites/workload/standin/testdata/" + kind + ".workload.json")
		fromYAML, err := ParseWorkload(y, helm)
		if err != nil {
			t.Fatalf("%s YAML: %v", kind, err)
		}
		fromJSON, err := ParseWorkload(j, "")
		if err != nil {
			t.Fatalf("%s JSON: %v", kind, err)
		}
		if !reflect.DeepEqual(fromYAML, fromJSON) {
			t.Errorf("%s: YAML %+v, JSON %+v", kind, fromYAML, fromJSON)
		}
	}
	raw, err := os.ReadFile("../../tests/fixture-app/workload.yaml")
	if err != nil {
		t.Fatal(err)
	}
	w, err := ParseWorkload(raw, helm)
	if err != nil || w.Name == "" {
		t.Errorf("the build component's fixture: %+v, %v", w, err)
	}
	if _, err := ParseWorkload([]byte("name: x\nkind: [unclosed"), helm); err == nil {
		t.Error("broken YAML parsed")
	}
}

func TestLevel(t *testing.T) {
	j, _ := os.ReadFile("../suites/workload/standin/testdata/mcp.workload.json")
	w, _ := ParseWorkload(j, "")
	if w.Level() != "L2" || len(w.DestructiveTools()) != 1 || len(w.ReadOnlyTools()) != 2 {
		t.Errorf("%s %v %v", w.Level(), w.DestructiveTools(), w.ReadOnlyTools())
	}
	if !Destructive(map[string]bool{}) || Destructive(map[string]bool{"readOnlyHint": true}) || Destructive(map[string]bool{"destructiveHint": false}) {
		t.Error("MCP's defaults: a tool with no hints is destructive")
	}
}
