// Package contract is the contract stage's harness (design/conformance.md,
// "How conformance runs in CI"; plan/local-build.md, "How conformance runs
// in B5"): everything a workload under test talks to, run inside the CI
// job while the workload runs as the job's service container.
//
//   - a test issuer that plays Keycloak: people's tokens signed with a key
//     the suites hold, its key set, and introspection for the STS;
//   - the real delegation-sts, its binary from its pinned image, with a
//     test policy for the workload and the runner's own caller, signing
//     through a KMS alias of its own (D26), and a fake TokenReview API
//     for actor tokens, as the interop suite's fixture;
//   - a front that plays the hosted-workloads gateway for the workload's
//     outbound calls: the model route, ending at the fake model server,
//     and an MCP server per server the workload calls, each checking the
//     chain token it receives and recording every call;
//   - a collector with a file exporter for the workload's telemetry.
//
// The workload reaches the front at the job container's host name, which
// a service resolves on the runner's network; it is configured by its
// environment alone (the env-only surface agreed in B5's seams).
package contract

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kms"
)

// Fixed names of the stage.
const (
	KeycloakIssuer = "https://keycloak.conformance.invalid/realms/agentic"
	STSIssuer      = "https://delegation-sts.conformance.invalid"
	// CallerName is the agent the runner plays when it calls an MCP server
	// under test; OtherCallerName is a second one, for approvals made for
	// another caller.
	CallerName      = "conformance-caller"
	OtherCallerName = "conformance-other-caller"
	// CallerNamespace holds the runner's callers' service accounts.
	CallerNamespace = "conformance"
	// ElsewhereServer is an MCP route no workload serves: a token for it is
	// a token for another audience.
	ElsewhereServer = "conformance-elsewhere"
	// TaskHeader is the task header (agent-sdk's spec/headers/).
	TaskHeader = "Agentic-Task-Id"
)

// Options configure a harness.
type Options struct {
	Dir     string // working files
	Listen  string // the front, such as ":18080"
	BaseURL string // the front as the workload reaches it, such as http://<job host>:18080
	// KubeListen is the fake TokenReview API, for the STS alone.
	KubeListen string
	// OTLPListen and OTLPGRPCListen are the collector's receivers.
	OTLPListen, OTLPGRPCListen string
	Domain, Cluster            string
	Workload                   *Workload
	// ActorTokenFile, when set, receives the workload's actor token, as a
	// pod's projected token: the workload reads it at every exchange.
	ActorTokenFile string
	// FakeModel is the fake model server's binary; FakeModelPorts its
	// model and operations ports on 127.0.0.1. Zero ports: the fake model
	// binds free ones and writes them to a file the harness reads, so
	// harnesses started at once never race each other for a port.
	FakeModel      string
	FakeModelPorts [2]int
	// STSBinary is delegation-sts's binary; empty runs the stand-in STS of
	// the suites' own tests. STSPorts are its public, token and ops ports.
	STSBinary    string
	STSPorts     [3]int
	SigningAlias string
	KMS          *kms.Client
	// Collector is the collector's binary; empty runs an in-process
	// receiver of OTLP JSON, for the suites' own tests.
	Collector string
	// Denied are subs on the STS's deny list.
	Denied []string
	// DatabaseListen and DatabaseTarget run the database proxy: the
	// workload's AGENTIC_DATABASE_URL names the job's host on
	// DatabaseListen's port, and the proxy forwards to DatabaseTarget,
	// the stage's PostgreSQL. Empty, no proxy.
	DatabaseListen, DatabaseTarget string
	Log                            io.Writer
}

// ModelCall is what the model route saw of one request.
type ModelCall struct {
	Time   time.Time
	Path   string
	Token  string
	TaskID string
	Trace  string
}

// Harness is a running contract stage.
type Harness struct {
	O         Options
	Keycloak  *Issuer
	Kube      *Kube
	STS       STS
	Tools     *Tools
	Telemetry *Telemetry
	// ModelOps is the fake model server's operations URL.
	ModelOps string
	modelAPI string // and its model APIs' base URL
	// OTLPURL is the in-process receiver's URL, when there is one.
	OTLPURL string
	// Database is the proxy in front of the workload's database, when the
	// stage gives it one.
	Database *DatabaseProxy

	model *proc
	front *http.Server
	kube  *http.Server

	mu     sync.Mutex
	models []ModelCall
}

// Route is the URL of route <gateway>/<path> in the stage's domain.
func (h *Harness) Route(r string) string {
	gw, rest, _ := strings.Cut(r, "/")
	return "https://" + gw + "." + h.O.Domain + "/" + rest
}

// Policy is the STS policy for the workload under test and the callers.
func PolicyFor(w *Workload) *Policy {
	p := NewPolicy()
	if w.Kind == "agent" {
		targets := map[string]bool{}
		for _, r := range w.Requires.Permissions.Routes {
			if strings.HasPrefix(r, "workloads-gateway/") {
				targets[r] = true
			}
		}
		for _, t := range w.Requires.Tools {
			targets["workloads-gateway/mcp/"+t.Server] = true
		}
		var list []string
		for t := range targets {
			list = append(list, t)
		}
		sort.Strings(list)
		if len(list) == 0 {
			list = []string{"workloads-gateway/v1"}
		}
		p.Agents[w.Name] = PolicyAgent{Actor: w.Name + "/" + w.Name, Routes: []string{"gateway/a2a/" + w.Name, "workloads-gateway/a2a/" + w.Name},
			After: []string{"person"}, Targets: list}
	}
	proto := "mcp"
	if w.Kind == "agent" {
		proto = "a2a"
	}
	for _, c := range []string{CallerName, OtherCallerName} {
		p.Agents[c] = PolicyAgent{Actor: CallerNamespace + "/" + c, Routes: []string{"gateway/a2a/" + c}, After: []string{"person"},
			Targets: []string{"workloads-gateway/" + proto + "/" + w.Name, "workloads-gateway/mcp/" + ElsewhereServer}}
	}
	return p
}

// Start runs the harness: issuer, fake Kubernetes API, STS, fake model,
// collector and front, in that order, each ready before the next.
func Start(ctx context.Context, o Options) (h *Harness, err error) {
	if o.Log == nil {
		o.Log = io.Discard
	}
	if err := os.MkdirAll(o.Dir, 0o700); err != nil {
		return nil, err
	}
	h = &Harness{O: o}
	started := h
	defer func() {
		if err != nil {
			started.Close()
		}
	}()
	if h.Keycloak, err = NewIssuer(KeycloakIssuer); err != nil {
		return nil, err
	}
	if h.Kube, err = NewKube(); err != nil {
		return nil, err
	}
	kubeLn, err := net.Listen("tcp", o.KubeListen)
	if err != nil {
		return nil, fmt.Errorf("the fake Kubernetes API: %w", err)
	}
	h.kube = &http.Server{Handler: h.Kube}
	go h.kube.Serve(kubeLn)

	frontLn, err := net.Listen("tcp", o.Listen)
	if err != nil {
		return nil, fmt.Errorf("the front: %w", err)
	}
	if o.BaseURL == "" {
		o.BaseURL = "http://" + localAddr(frontLn)
		h.O.BaseURL = o.BaseURL
	}
	policy := PolicyFor(o.Workload)
	if o.STSBinary != "" {
		h.STS, err = StartRealSTS(ctx, RealSTSOptions{
			Binary: o.STSBinary, Dir: filepath.Join(o.Dir, "sts"), Issuer: STSIssuer, Domain: o.Domain, Cluster: o.Cluster,
			KeycloakIssuer: KeycloakIssuer, KeycloakBase: "http://" + localAddr(frontLn) + "/issuer/keycloak",
			KubeURL: "http://" + localAddr(kubeLn), Policy: policy, DenyList: o.Denied, TaskHeader: TaskHeader,
			Alias: o.SigningAlias, KMS: o.KMS, Ports: o.STSPorts, Log: o.Log,
		})
	} else {
		h.STS, err = NewFakeSTS(STSIssuer, o.Domain, o.Cluster, policy, h.Keycloak, h.Kube, o.Denied)
	}
	if err != nil {
		frontLn.Close()
		return nil, err
	}
	if o.FakeModel != "" {
		addrs := []string{fmt.Sprintf("127.0.0.1:%d", o.FakeModelPorts[0]), fmt.Sprintf("127.0.0.1:%d", o.FakeModelPorts[1])}
		args := []string{o.FakeModel, "-listen=" + addrs[0], "-ops-listen=" + addrs[1], "-log-level=warn", "-max-hold=2m"}
		addrFile := ""
		if o.FakeModelPorts == [2]int{} {
			addrFile = filepath.Join(o.Dir, "fake-model.addrs")
			os.Remove(addrFile)
			args = append(args, "-addr-file="+addrFile)
		}
		h.model, err = startProc("fake-model", args, []string{"HOME=" + o.Dir}, o.Dir, o.Log)
		if err != nil {
			frontLn.Close()
			return nil, err
		}
		if addrFile != "" {
			if addrs, err = h.model.waitAddrs(addrFile, 2, 30*time.Second); err != nil {
				frontLn.Close()
				return nil, err
			}
		}
		h.modelAPI, h.ModelOps = "http://"+addrs[0], "http://"+addrs[1]
		if err = h.model.waitHTTP(h.ModelOps+"/readyz", 30*time.Second); err != nil {
			frontLn.Close()
			return nil, err
		}
	}
	if o.Collector != "" {
		h.Telemetry, err = StartCollector(o.Collector, o.Dir, o.OTLPListen, o.OTLPGRPCListen, o.Log)
	} else {
		var ln net.Listener
		if ln, err = net.Listen("tcp", o.OTLPListen); err == nil {
			h.OTLPURL = "http://" + localAddr(ln)
			h.Telemetry, err = StartReceiver(o.Dir, ln)
		}
	}
	if err != nil {
		frontLn.Close()
		return nil, err
	}
	if o.DatabaseTarget != "" {
		if h.Database, err = StartDatabaseProxy(o.DatabaseListen, o.DatabaseTarget); err != nil {
			frontLn.Close()
			return nil, fmt.Errorf("the database proxy: %w", err)
		}
	}
	servers := map[string][]string{}
	for _, t := range o.Workload.Requires.Tools {
		servers[t.Server] = append(servers[t.Server], t.Tools...)
	}
	h.Tools = NewTools(o.Domain, h.STS, servers)

	mux := http.NewServeMux()
	h.Keycloak.register(mux, "/issuer/keycloak", o.BaseURL)
	mux.HandleFunc("GET /sts/jwks", func(w http.ResponseWriter, r *http.Request) { h.proxySTS(w, r, h.STS.JWKSURL()) })
	mux.HandleFunc("POST /sts/token", func(w http.ResponseWriter, r *http.Request) { h.proxySTS(w, r, h.STS.TokenURL()) })
	for server := range servers {
		mux.Handle("/mcp/"+server, h.Tools.Handler(server))
	}
	if o.FakeModel != "" {
		target, _ := url.Parse(h.modelAPI)
		rp := httputil.NewSingleHostReverseProxy(target)
		rp.Transport = &http.Transport{Proxy: nil}
		rp.FlushInterval = -1
		// A caller that gives up on a held request is the point of some
		// cases, not an error to log.
		rp.ErrorLog = log.New(io.Discard, "", 0)
		mux.HandleFunc("/v1/", func(w http.ResponseWriter, r *http.Request) {
			h.mu.Lock()
			h.models = append(h.models, ModelCall{Time: time.Now(), Path: r.URL.Path, Token: strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "),
				TaskID: r.Header.Get(TaskHeader), Trace: r.Header.Get("Traceparent")})
			h.mu.Unlock()
			// The hosted-workloads gateway drops the caller's token before
			// the provider; the fake model records which credentials arrive.
			r.Header.Del("Authorization")
			rp.ServeHTTP(w, r)
		})
	}
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { w.Write([]byte("ok")) })
	h.front = &http.Server{Handler: mux, ReadHeaderTimeout: 10 * time.Second}
	go h.front.Serve(frontLn)

	if o.ActorTokenFile != "" && o.Workload.Kind == "agent" {
		if err = h.WriteActorToken(); err != nil {
			return nil, err
		}
	}
	return h, nil
}

// WriteActorToken writes the workload's actor token where it reads it, as
// the kubelet projects one, atomically.
func (h *Harness) WriteActorToken() error {
	w := h.O.Workload
	tok := h.Kube.ActorToken(w.Name, w.Name, STSIssuer, time.Hour)
	if err := os.MkdirAll(filepath.Dir(h.O.ActorTokenFile), 0o755); err != nil {
		return err
	}
	tmp := h.O.ActorTokenFile + ".tmp"
	if err := os.WriteFile(tmp, []byte(tok), 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, h.O.ActorTokenFile)
}

func (h *Harness) proxySTS(w http.ResponseWriter, r *http.Request, target string) {
	body := readBody(r)
	req, _ := http.NewRequestWithContext(r.Context(), r.Method, target, bytes.NewReader(body))
	for _, k := range []string{"Content-Type", "Accept", TaskHeader, "Traceparent", "Tracestate", "Authorization"} {
		if v := r.Header.Get(k); v != "" {
			req.Header.Set(k, v)
		}
	}
	resp, err := h.STS.HTTP().Do(req)
	if err != nil {
		http.Error(w, "the contract stage could not reach its STS: "+err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	for k, v := range resp.Header {
		w.Header()[k] = v
	}
	w.WriteHeader(resp.StatusCode)
	io.Copy(w, resp.Body)
}

// ModelCalls returns the model route's requests so far.
func (h *Harness) ModelCalls() []ModelCall {
	h.mu.Lock()
	defer h.mu.Unlock()
	return append([]ModelCall(nil), h.models...)
}

// ModelRecord is one of the fake model server's request records.
type ModelRecord struct {
	Time        time.Time `json:"time"`
	API         string    `json:"api"`
	DirectiveID string    `json:"directive_id"`
	Attempt     int       `json:"attempt"`
	Fault       string    `json:"fault"`
	Status      int       `json:"status"`
	Credentials []string  `json:"credentials"`
	Traceparent string    `json:"traceparent"`
}

// ModelRecords reads the fake model server's records of a directive id.
func (h *Harness) ModelRecords(ctx context.Context, id string) ([]ModelRecord, error) {
	if h.ModelOps == "" {
		return nil, errors.New("no fake model server")
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, h.ModelOps+"/requests?id="+url.QueryEscape(id), nil)
	resp, err := (&http.Client{Timeout: 10 * time.Second, Transport: &http.Transport{Proxy: nil}}).Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var out struct {
		Requests []ModelRecord `json:"requests"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, err
	}
	return out.Requests, nil
}

// Exchange asks the STS, as the runner's caller, for a chain token for
// resource on behalf of the person with token subject.
func (h *Harness) Exchange(ctx context.Context, caller, subject, resource string) (string, int, string) {
	actor := h.Kube.ActorToken(CallerNamespace, caller, STSIssuer, 10*time.Minute)
	form := url.Values{
		"grant_type":         {"urn:ietf:params:oauth:grant-type:token-exchange"},
		"subject_token":      {subject},
		"subject_token_type": {"urn:ietf:params:oauth:token-type:access_token"},
		"actor_token":        {actor},
		"actor_token_type":   {"urn:ietf:params:oauth:token-type:jwt"},
		"resource":           {resource},
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, h.STS.TokenURL(), strings.NewReader(form.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	resp, err := h.STS.HTTP().Do(req)
	if err != nil {
		return "", 0, err.Error()
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	var out struct {
		AccessToken string `json:"access_token"`
	}
	json.Unmarshal(raw, &out)
	return out.AccessToken, resp.StatusCode, string(raw)
}

// Close stops everything the harness started.
func (h *Harness) Close() {
	if h.front != nil {
		h.front.Close()
	}
	if h.kube != nil {
		h.kube.Close()
	}
	if h.Telemetry != nil {
		h.Telemetry.Close()
	}
	if h.Database != nil {
		h.Database.Close()
	}
	if h.model != nil {
		h.model.stop(5 * time.Second)
	}
	if h.STS != nil {
		h.STS.Close()
	}
}

func localAddr(ln net.Listener) string {
	_, port, _ := net.SplitHostPort(ln.Addr().String())
	return "127.0.0.1:" + port
}

// readBody reads a request's body and puts it back for the next reader.
func readBody(r *http.Request) []byte {
	b, _ := io.ReadAll(io.LimitReader(r.Body, 8<<20))
	r.Body.Close()
	r.Body = io.NopCloser(bytes.NewReader(b))
	return b
}
