package contract

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"
)

// Telemetry is what the workload exported: the collector's file exporter
// output, one OTLP JSON export per line. In the contract stage the
// collector is the core distribution's binary with an OTLP receiver
// and a file exporter; in the suites' own tests an in-process receiver
// that takes OTLP JSON writes the same lines.
type Telemetry struct {
	Path string

	p   *proc
	srv *http.Server
	mu  sync.Mutex
}

// collectorConfig is the collector's whole configuration: OTLP in on
// listen (HTTP) and grpcListen, every signal to one file.
func collectorConfig(listen, grpcListen, path string) string {
	return fmt.Sprintf(`receivers:
  otlp:
    protocols:
      http:
        endpoint: %q
      grpc:
        endpoint: %q
exporters:
  file:
    path: %q
    flush_interval: 200ms
service:
  telemetry:
    logs:
      level: warn
    metrics:
      level: none
  pipelines:
    traces:
      receivers: [otlp]
      exporters: [file]
    logs:
      receivers: [otlp]
      exporters: [file]
    metrics:
      receivers: [otlp]
      exporters: [file]
`, listen, grpcListen, path)
}

// StartCollector runs the collector binary, writing to dir/telemetry.jsonl.
func StartCollector(binary, dir, listen, grpcListen string, log io.Writer) (*Telemetry, error) {
	path := dir + "/telemetry.jsonl"
	cfg := dir + "/collector.yaml"
	if err := os.WriteFile(cfg, []byte(collectorConfig(listen, grpcListen, path)), 0o600); err != nil {
		return nil, err
	}
	p, err := startProc("collector", []string{binary, "--config=" + cfg}, []string{"HOME=" + dir}, dir, log)
	if err != nil {
		return nil, err
	}
	deadline := time.Now().Add(30 * time.Second)
	addr := listen
	if host, port, err := net.SplitHostPort(listen); err == nil && (host == "" || host == "0.0.0.0") {
		addr = "127.0.0.1:" + port
	}
	for {
		if c, err := net.DialTimeout("tcp", addr, time.Second); err == nil {
			c.Close()
			break
		}
		if time.Now().After(deadline) {
			p.stop(time.Second)
			return nil, fmt.Errorf("the collector did not listen on %s within 30s", listen)
		}
		select {
		case <-p.done:
			return nil, fmt.Errorf("the collector exited: %v", p.err)
		case <-time.After(200 * time.Millisecond):
		}
	}
	return &Telemetry{Path: path, p: p}, nil
}

// StartReceiver serves OTLP JSON over HTTP on ln, for the suites' own
// tests, writing what arrives as the collector's file exporter would.
func StartReceiver(dir string, ln net.Listener) (*Telemetry, error) {
	t := &Telemetry{Path: dir + "/telemetry.jsonl"}
	if err := os.WriteFile(t.Path, nil, 0o600); err != nil {
		return nil, err
	}
	mux := http.NewServeMux()
	for _, p := range []string{"/v1/traces", "/v1/logs", "/v1/metrics"} {
		mux.HandleFunc("POST "+p, func(w http.ResponseWriter, r *http.Request) {
			if r.Header.Get("Content-Type") != "application/json" {
				http.Error(w, "the test receiver takes OTLP JSON only", http.StatusUnsupportedMediaType)
				return
			}
			raw, _ := io.ReadAll(io.LimitReader(r.Body, 16<<20))
			var compact bytes.Buffer
			if json.Compact(&compact, raw) != nil {
				http.Error(w, "not JSON", http.StatusBadRequest)
				return
			}
			t.mu.Lock()
			f, err := os.OpenFile(t.Path, os.O_APPEND|os.O_WRONLY, 0o600)
			if err == nil {
				f.Write(append(compact.Bytes(), '\n'))
				f.Close()
			}
			t.mu.Unlock()
			w.Header().Set("Content-Type", "application/json")
			w.Write([]byte("{}"))
		})
	}
	t.srv = &http.Server{Handler: mux}
	go t.srv.Serve(ln)
	return t, nil
}

// Close stops the collector or the receiver.
func (t *Telemetry) Close() {
	if t.p != nil {
		t.p.stop(5 * time.Second)
	}
	if t.srv != nil {
		t.srv.Close()
	}
}

// Span is a span as exported, with its resource.
type Span struct {
	TraceID, SpanID, ParentSpanID, Name string
	Kind                                int
	StatusCode                          int // 2 is ERROR
	StatusMessage                       string
	Attributes                          map[string]any
	Events                              []Event
	Resource                            map[string]any
}

// Event is a span event.
type Event struct {
	Name       string
	Attributes map[string]any
}

// LogRecord is a log record as exported, with its resource.
type LogRecord struct {
	TraceID, SpanID, EventName string
	Body                       any
	Attributes                 map[string]any
	Resource                   map[string]any
}

// Snapshot is everything exported so far.
type Snapshot struct {
	Raw   string // every line, for searches no field may hide from
	Spans []Span
	Logs  []LogRecord
}

// Read returns everything the file holds now.
func (t *Telemetry) Read() (Snapshot, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	f, err := os.Open(t.Path)
	if os.IsNotExist(err) {
		return Snapshot{}, nil
	}
	if err != nil {
		return Snapshot{}, err
	}
	defer f.Close()
	var s Snapshot
	var raw bytes.Buffer
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 64<<20)
	for sc.Scan() {
		line := sc.Bytes()
		raw.Write(line)
		raw.WriteByte('\n')
		var e export
		if json.Unmarshal(line, &e) != nil {
			continue
		}
		for _, rs := range e.ResourceSpans {
			res := attrs(rs.Resource.Attributes)
			for _, ss := range rs.ScopeSpans {
				for _, sp := range ss.Spans {
					out := Span{TraceID: sp.TraceID, SpanID: sp.SpanID, ParentSpanID: sp.ParentSpanID, Name: sp.Name, Kind: sp.Kind,
						StatusCode: sp.Status.Code, StatusMessage: sp.Status.Message, Attributes: attrs(sp.Attributes), Resource: res}
					for _, ev := range sp.Events {
						out.Events = append(out.Events, Event{Name: ev.Name, Attributes: attrs(ev.Attributes)})
					}
					s.Spans = append(s.Spans, out)
				}
			}
		}
		for _, rl := range e.ResourceLogs {
			res := attrs(rl.Resource.Attributes)
			for _, sl := range rl.ScopeLogs {
				for _, lr := range sl.LogRecords {
					s.Logs = append(s.Logs, LogRecord{TraceID: lr.TraceID, SpanID: lr.SpanID, EventName: lr.EventName,
						Body: anyValue(lr.Body), Attributes: attrs(lr.Attributes), Resource: res})
				}
			}
		}
	}
	s.Raw = raw.String()
	return s, sc.Err()
}

type keyValue struct {
	Key   string          `json:"key"`
	Value json.RawMessage `json:"value"`
}

type export struct {
	ResourceSpans []struct {
		Resource struct {
			Attributes []keyValue `json:"attributes"`
		} `json:"resource"`
		ScopeSpans []struct {
			Spans []struct {
				TraceID      string     `json:"traceId"`
				SpanID       string     `json:"spanId"`
				ParentSpanID string     `json:"parentSpanId"`
				Name         string     `json:"name"`
				Kind         int        `json:"kind"`
				Attributes   []keyValue `json:"attributes"`
				Events       []struct {
					Name       string     `json:"name"`
					Attributes []keyValue `json:"attributes"`
				} `json:"events"`
				Status struct {
					Code    int    `json:"code"`
					Message string `json:"message"`
				} `json:"status"`
			} `json:"spans"`
		} `json:"scopeSpans"`
	} `json:"resourceSpans"`
	ResourceLogs []struct {
		Resource struct {
			Attributes []keyValue `json:"attributes"`
		} `json:"resource"`
		ScopeLogs []struct {
			LogRecords []struct {
				TraceID    string          `json:"traceId"`
				SpanID     string          `json:"spanId"`
				EventName  string          `json:"eventName"`
				Body       json.RawMessage `json:"body"`
				Attributes []keyValue      `json:"attributes"`
			} `json:"logRecords"`
		} `json:"scopeLogs"`
	} `json:"resourceLogs"`
}

func attrs(kvs []keyValue) map[string]any {
	out := map[string]any{}
	for _, kv := range kvs {
		out[kv.Key] = anyValue(kv.Value)
	}
	return out
}

// anyValue decodes OTLP JSON's AnyValue into Go values: strings, bools,
// int64, float64, []any and map[string]any.
func anyValue(raw json.RawMessage) any {
	if len(raw) == 0 {
		return nil
	}
	var v struct {
		StringValue *string         `json:"stringValue"`
		BoolValue   *bool           `json:"boolValue"`
		IntValue    json.RawMessage `json:"intValue"`
		DoubleValue *float64        `json:"doubleValue"`
		ArrayValue  *struct {
			Values []json.RawMessage `json:"values"`
		} `json:"arrayValue"`
		KvlistValue *struct {
			Values []keyValue `json:"values"`
		} `json:"kvlistValue"`
		BytesValue *string `json:"bytesValue"`
	}
	if json.Unmarshal(raw, &v) != nil {
		return nil
	}
	switch {
	case v.StringValue != nil:
		return *v.StringValue
	case v.BoolValue != nil:
		return *v.BoolValue
	case len(v.IntValue) > 0:
		var s string
		if json.Unmarshal(v.IntValue, &s) == nil {
			n, _ := strconv.ParseInt(s, 10, 64)
			return n
		}
		var n int64
		json.Unmarshal(v.IntValue, &n)
		return n
	case v.DoubleValue != nil:
		return *v.DoubleValue
	case v.ArrayValue != nil:
		out := []any{}
		for _, e := range v.ArrayValue.Values {
			out = append(out, anyValue(e))
		}
		return out
	case v.KvlistValue != nil:
		return attrs(v.KvlistValue.Values)
	case v.BytesValue != nil:
		return *v.BytesValue
	}
	return nil
}
