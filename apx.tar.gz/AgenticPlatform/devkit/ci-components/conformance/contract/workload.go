package contract

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

// WorkloadPath is where a workload's image carries its workload.yaml
// (agent-sdk's spec/limits/runtime.json; the seams of build phase B5).
const WorkloadPath = "/etc/agentic/workload.yaml"

// Workload is what the stage reads of a workload's workload.yaml
// (agent-sdk's spec/schemas/workload.schema.json).
type Workload struct {
	Name     string         `json:"name"`
	Kind     string         `json:"kind"`    // agent, mcp-server or workflow
	Runtime  string         `json:"runtime"` // container, kagent or pipeline
	Tools    []WorkloadTool `json:"tools"`
	Requires struct {
		Tools []struct {
			Server string   `json:"server"`
			Tools  []string `json:"tools"`
		} `json:"tools"`
		Permissions struct {
			Routes []string `json:"routes"`
			Write  bool     `json:"write"`
		} `json:"permissions"`
	} `json:"requires"`
	Limits      map[string]int `json:"limits"`
	LongRunning bool           `json:"long_running"`
	Resumable   bool           `json:"resumable"`
	Conformance struct {
		Level string `json:"level"`
	} `json:"conformance"`
}

// WorkloadTool is one of an MCP server's own tools.
type WorkloadTool struct {
	Name        string          `json:"name"`
	Annotations map[string]bool `json:"annotations"`
}

// Destructive reports whether a tool's annotations make it destructive,
// MCP's defaults counting: readOnlyHint not true and destructiveHint not
// false (spec/audit/tool/README.md).
func Destructive(ann map[string]bool) bool {
	ro, hasRO := ann["readOnlyHint"]
	d, hasD := ann["destructiveHint"]
	return !(hasRO && ro) && !(hasD && !d)
}

// Level is the conformance level the file implies, raised by its own
// conformance.level (design/conformance.md, "How conformance runs in CI").
func (w *Workload) Level() string {
	level := "L1"
	if w.Requires.Permissions.Write || len(w.DestructiveTools()) > 0 {
		level = "L2"
	}
	if w.LongRunning || w.Resumable {
		level = "L3"
	}
	if w.Conformance.Level > level {
		level = w.Conformance.Level
	}
	return level
}

// DestructiveTools are the workload's own destructive tools.
func (w *Workload) DestructiveTools() []string {
	var out []string
	for _, t := range w.Tools {
		if Destructive(t.Annotations) {
			out = append(out, t.Name)
		}
	}
	return out
}

// ReadOnlyTools are the workload's own read-only tools.
func (w *Workload) ReadOnlyTools() []string {
	var out []string
	for _, t := range w.Tools {
		if !Destructive(t.Annotations) {
			out = append(out, t.Name)
		}
	}
	return out
}

// ParseWorkload reads workload.yaml. JSON, which YAML contains, parses
// directly; other YAML goes through helm, which the runner's image
// carries, so the module stays on the standard library: helm reads the
// file as values and prints them as JSON.
func ParseWorkload(data []byte, helm string) (*Workload, error) {
	raw := bytes.TrimSpace(data)
	if !json.Valid(raw) {
		if helm == "" {
			return nil, errors.New("workload.yaml is not JSON, and no helm binary was given to read YAML")
		}
		var err error
		if raw, err = yamlToJSON(data, helm); err != nil {
			return nil, err
		}
	}
	var w Workload
	if err := json.Unmarshal(raw, &w); err != nil {
		return nil, fmt.Errorf("workload.yaml: %v", err)
	}
	if w.Name == "" || (w.Kind != "agent" && w.Kind != "mcp-server" && w.Kind != "workflow") {
		return nil, fmt.Errorf("workload.yaml: name %q and kind %q are not a workload's", w.Name, w.Kind)
	}
	return &w, nil
}

// yamlToJSON renders data as JSON through a one-template chart.
func yamlToJSON(data []byte, helm string) ([]byte, error) {
	dir, err := os.MkdirTemp("", "workload-yaml-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	files := map[string]string{
		"chart/Chart.yaml":        "apiVersion: v2\nname: workload\nversion: 0.0.0\n",
		"chart/templates/out.txt": "{{ .Values | toJson }}\n",
		"workload.yaml":           string(data),
	}
	for name, body := range files {
		p := filepath.Join(dir, name)
		os.MkdirAll(filepath.Dir(p), 0o700)
		if err := os.WriteFile(p, []byte(body), 0o600); err != nil {
			return nil, err
		}
	}
	cmd := exec.Command(helm, "template", "w", filepath.Join(dir, "chart"), "-f", filepath.Join(dir, "workload.yaml"))
	cmd.Env = []string{"HOME=" + dir, "HELM_CACHE_HOME=" + dir, "HELM_CONFIG_HOME=" + dir, "HELM_DATA_HOME=" + dir}
	out, err := cmd.CombinedOutput()
	if err != nil {
		return nil, fmt.Errorf("reading workload.yaml with helm: %v: %s", err, strings.TrimSpace(string(out)))
	}
	for _, line := range strings.Split(string(out), "\n") {
		if strings.HasPrefix(line, "{") {
			return []byte(line), nil
		}
	}
	return nil, fmt.Errorf("helm printed no JSON for workload.yaml: %s", out)
}
