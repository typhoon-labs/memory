package contract

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"sync"
	"time"
)

// proc is a child process of the harness: the STS, the fake model server
// or the collector. Its standard output is kept line by line, which for
// the STS are its audit records; standard error goes to the harness's log.
type proc struct {
	name string
	cmd  *exec.Cmd
	done chan struct{}
	err  error

	mu    sync.Mutex
	lines []string
}

// startProc starts argv with exactly env, nothing inherited: no proxy
// variable or credential of the job reaches a child unless named.
func startProc(name string, argv, env []string, dir string, log io.Writer) (*proc, error) {
	p := &proc{name: name, done: make(chan struct{})}
	p.cmd = exec.Command(argv[0], argv[1:]...)
	p.cmd.Env = env
	p.cmd.Dir = dir
	p.cmd.Stderr = &prefixWriter{prefix: name + ": ", w: log}
	out, err := p.cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	if err := p.cmd.Start(); err != nil {
		return nil, fmt.Errorf("%s: %w", name, err)
	}
	go func() {
		sc := bufio.NewScanner(out)
		sc.Buffer(make([]byte, 64<<10), 4<<20)
		for sc.Scan() {
			p.mu.Lock()
			p.lines = append(p.lines, sc.Text())
			p.mu.Unlock()
		}
		io.Copy(io.Discard, out)
		p.err = p.cmd.Wait()
		close(p.done)
	}()
	return p, nil
}

// Lines returns what the process has written to standard output so far.
func (p *proc) Lines() []string {
	p.mu.Lock()
	defer p.mu.Unlock()
	return append([]string(nil), p.lines...)
}

// waitHTTP waits until url answers 200, or the process exits, or timeout.
func (p *proc) waitHTTP(url string, timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	c := &http.Client{Timeout: time.Second, Transport: &http.Transport{Proxy: nil}}
	for time.Now().Before(deadline) {
		select {
		case <-p.done:
			return fmt.Errorf("%s exited before it was ready: %v", p.name, p.err)
		default:
		}
		if resp, err := c.Get(url); err == nil {
			resp.Body.Close()
			if resp.StatusCode == http.StatusOK {
				return nil
			}
		}
		time.Sleep(200 * time.Millisecond)
	}
	return fmt.Errorf("%s was not ready at %s within %s", p.name, url, timeout)
}

// waitAddrs waits for the process to write n addresses, one a line, to
// path, and returns them.
func (p *proc) waitAddrs(path string, n int, timeout time.Duration) ([]string, error) {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		select {
		case <-p.done:
			return nil, fmt.Errorf("%s exited before it listened: %v", p.name, p.err)
		default:
		}
		if b, err := os.ReadFile(path); err == nil {
			if addrs := strings.Fields(string(b)); len(addrs) == n {
				return addrs, nil
			}
		}
		time.Sleep(20 * time.Millisecond)
	}
	return nil, fmt.Errorf("%s wrote no addresses to %s within %s", p.name, path, timeout)
}

// stop ends the process: SIGTERM, then SIGKILL after grace.
func (p *proc) stop(grace time.Duration) {
	if p == nil || p.cmd.Process == nil {
		return
	}
	select {
	case <-p.done:
		return
	default:
	}
	p.cmd.Process.Signal(os.Interrupt)
	select {
	case <-p.done:
	case <-time.After(grace):
		p.cmd.Process.Kill()
		<-p.done
	}
}

// prefixWriter prefixes each line it passes on.
type prefixWriter struct {
	prefix string
	w      io.Writer
	mu     sync.Mutex
	buf    []byte
}

func (pw *prefixWriter) Write(b []byte) (int, error) {
	pw.mu.Lock()
	defer pw.mu.Unlock()
	pw.buf = append(pw.buf, b...)
	for {
		i := bytes.IndexByte(pw.buf, '\n')
		if i < 0 {
			break
		}
		fmt.Fprintf(pw.w, "%s%s\n", pw.prefix, pw.buf[:i])
		pw.buf = pw.buf[i+1:]
	}
	return len(b), nil
}

// ctxDone reports whether ctx has ended.
func ctxDone(ctx context.Context) bool {
	select {
	case <-ctx.Done():
		return true
	default:
		return false
	}
}
