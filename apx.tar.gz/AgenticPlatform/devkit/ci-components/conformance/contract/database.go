package contract

import (
	"io"
	"net"
	"sync"
	"time"
)

// DatabaseProxy stands between the workload and the stage's PostgreSQL: a
// TCP proxy in the harness's own container, which the workload reaches at
// the job's host name, through which a case can hold the database's
// answers back. A tool call that waits on its database then runs past the
// workload's lowered wall-time cap, and the Limits suite sees an MCP
// server's own limit_exceeded, which nothing else in the stage can make an
// MCP server reach.
type DatabaseProxy struct {
	Target string // host:port of PostgreSQL

	ln      net.Listener
	mu      sync.Mutex
	delay   time.Duration
	traffic int64
}

// StartDatabaseProxy listens on listen and forwards to target.
func StartDatabaseProxy(listen, target string) (*DatabaseProxy, error) {
	ln, err := net.Listen("tcp", listen)
	if err != nil {
		return nil, err
	}
	p := &DatabaseProxy{Target: target, ln: ln}
	go p.serve()
	return p, nil
}

// Addr is where the proxy listens.
func (p *DatabaseProxy) Addr() string { return p.ln.Addr().String() }

// SetDelay holds each piece the database sends back for d, from now on;
// zero lets it through at once.
func (p *DatabaseProxy) SetDelay(d time.Duration) {
	p.mu.Lock()
	p.delay = d
	p.mu.Unlock()
}

// Traffic counts the bytes the workload sent its database so far, on any
// connection: a server with a pool sends its queries over connections it
// opened before, so new connections do not show that it reached its
// database.
func (p *DatabaseProxy) Traffic() int64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.traffic
}

// counted is the workload's side of a connection, counting what it sends.
type counted struct {
	net.Conn
	p *DatabaseProxy
}

func (c counted) Read(b []byte) (int, error) {
	n, err := c.Conn.Read(b)
	if n > 0 {
		c.p.mu.Lock()
		c.p.traffic += int64(n)
		c.p.mu.Unlock()
	}
	return n, err
}

func (p *DatabaseProxy) serve() {
	for {
		c, err := p.ln.Accept()
		if err != nil {
			return
		}
		go p.handle(c)
	}
}

func (p *DatabaseProxy) handle(c net.Conn) {
	defer c.Close()
	up, err := net.DialTimeout("tcp", p.Target, 10*time.Second)
	if err != nil {
		return
	}
	defer up.Close()
	go func() {
		io.Copy(up, counted{c, p})
		up.Close()
	}()
	buf := make([]byte, 32<<10)
	for {
		n, err := up.Read(buf)
		if n > 0 {
			p.mu.Lock()
			d := p.delay
			p.mu.Unlock()
			if d > 0 {
				time.Sleep(d)
			}
			if _, werr := c.Write(buf[:n]); werr != nil {
				return
			}
		}
		if err != nil {
			return
		}
	}
}

// Close stops listening; connections in progress end with their peers.
func (p *DatabaseProxy) Close() { p.ln.Close() }
