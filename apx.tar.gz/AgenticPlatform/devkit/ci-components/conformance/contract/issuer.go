package contract

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"slices"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
)

// NoTyp leaves a token's typ header out.
const NoTyp = "-"

// Person is a test user, as the realm would describe them.
type Person struct {
	Sub, Team, Sid, Username, ACR string
	Roles                         []string
}

// NewPerson makes a person with fresh identifiers in the team.
func NewPerson(team string) Person {
	return Person{Sub: UUID(), Team: team, Sid: UUID(), Username: "conformance-" + hex.EncodeToString(random(3)) + "@example.com",
		ACR: "1", Roles: []string{"developer"}}
}

// TokenOpts shape a token, each field breaking or keeping one property.
type TokenOpts struct {
	Audience  any           // a string or a list; required
	Issuer    string        // default the issuer's own
	Alg       string        // default the issuer's; "none" or "HS256" (keyed with the public key in PEM) to forge
	Kid       string        // default the signing key's
	Typ       string        // default at+jwt; NoTyp leaves it out
	IssuedAt  time.Time     // default now
	Lifetime  time.Duration // default 300 seconds
	NotBefore *time.Time    // default none, as Keycloak
	Act       map[string]any
	Extra     map[string]any // further claims; a nil value removes one
	Key       any            // sign with another private key, as an unknown signer
	Tamper    bool           // change a claim under the signature
}

// Issuer is the contract stage's stand-in for Keycloak: it signs people's
// tokens with a key the suite holds, publishes its key set, and answers
// the STS's introspection. Workloads trust it through AGENTIC_TRUST as the
// keycloak profile's issuer.
type Issuer struct {
	URL string // the issuer identifier, compared exactly

	key *rsa.PrivateKey
	kid string

	mu       sync.Mutex
	inactive map[string]bool // jti
}

// NewIssuer makes an issuer with a fresh RS256 key, Keycloak's default.
func NewIssuer(url string) (*Issuer, error) {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}
	return &Issuer{URL: url, key: key, kid: "conformance-" + hex.EncodeToString(random(4)), inactive: map[string]bool{}}, nil
}

// JWKS is the issuer's published key set.
func (i *Issuer) JWKS() jose.JWKS {
	k, _ := jose.PublicJWK(&i.key.PublicKey, i.kid, "RS256")
	return jose.JWKS{Keys: []jose.JWK{k}}
}

// Mint signs a person's token as the realm does, shaped by o.
func (i *Issuer) Mint(p Person, o TokenOpts) (string, map[string]any) {
	iat := o.IssuedAt
	if iat.IsZero() {
		iat = time.Now()
	}
	life := o.Lifetime
	if life == 0 {
		life = 300 * time.Second
	}
	iss := o.Issuer
	if iss == "" {
		iss = i.URL
	}
	claims := map[string]any{
		"iss": iss, "sub": p.Sub, "aud": o.Audience, "iat": iat.Unix(), "exp": iat.Add(life).Unix(), "jti": UUID(),
		"client_id": "agentctl", "azp": "agentctl", "typ": "Bearer", "sid": p.Sid, "team": p.Team, "roles": p.Roles,
		"preferred_username": p.Username, "acr": p.ACR, "auth_time": iat.Add(-time.Minute).Unix(), "scope": "basic acr claims",
	}
	if o.NotBefore != nil {
		claims["nbf"] = o.NotBefore.Unix()
	}
	if o.Act != nil {
		claims["act"] = o.Act
	}
	for k, v := range o.Extra {
		if v == nil {
			delete(claims, k)
		} else {
			claims[k] = v
		}
	}
	return sign(claims, "RS256", i.kid, i.key, &i.key.PublicKey, o), claims
}

// sign signs claims under the options' algorithm, kid, typ and key.
func sign(claims map[string]any, alg, kid string, key any, pub any, o TokenOpts) string {
	if o.Alg != "" {
		alg = o.Alg
	}
	if o.Kid != "" {
		kid = o.Kid
	}
	header := map[string]any{"alg": alg, "kid": kid, "typ": "at+jwt"}
	switch o.Typ {
	case "":
	case NoTyp:
		delete(header, "typ")
	default:
		header["typ"] = o.Typ
	}
	signer := key
	if o.Key != nil {
		signer = o.Key
	}
	switch alg {
	case "none":
		signer = nil
	case "HS256":
		pem, err := jose.PublicPEM(pub)
		if err != nil {
			panic(err)
		}
		signer = pem
	}
	tok, err := jose.Sign(header, claims, signer)
	if err != nil {
		panic(fmt.Sprintf("signing a test token: %v", err))
	}
	if o.Tamper {
		changed := map[string]any{}
		for k, v := range claims {
			changed[k] = v
		}
		changed["roles"] = []string{"platform-engineer"}
		changed["sub"] = UUID()
		tok, _ = jose.ReplaceClaims(tok, changed)
	}
	return tok
}

// Deactivate makes introspection answer inactive for a token's jti.
func (i *Issuer) Deactivate(jti string) { i.mu.Lock(); i.inactive[jti] = true; i.mu.Unlock() }

// register serves the key set, metadata and introspection under prefix.
func (i *Issuer) register(mux *http.ServeMux, prefix, baseURL string) {
	mux.HandleFunc("GET "+prefix+"/jwks", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Cache-Control", "max-age=300")
		writeJSON(w, http.StatusOK, i.JWKS())
	})
	mux.HandleFunc("GET "+prefix+"/.well-known/openid-configuration", func(w http.ResponseWriter, _ *http.Request) {
		writeJSON(w, http.StatusOK, map[string]any{
			"issuer": i.URL, "jwks_uri": baseURL + prefix + "/jwks",
			"introspection_endpoint":                baseURL + prefix + "/introspect",
			"id_token_signing_alg_values_supported": []string{"RS256"},
		})
	})
	mux.HandleFunc("POST "+prefix+"/introspect", func(w http.ResponseWriter, r *http.Request) {
		if err := r.ParseForm(); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "invalid_request"})
			return
		}
		claims, active := i.check(r.PostForm.Get("token"))
		if !active {
			writeJSON(w, http.StatusOK, map[string]any{"active": false})
			return
		}
		resp := map[string]any{"active": true, "token_type": "Bearer", "username": claims["preferred_username"]}
		for k, v := range claims {
			resp[k] = v
		}
		writeJSON(w, http.StatusOK, resp)
	})
}

func (i *Issuer) check(raw string) (map[string]any, bool) {
	t, err := jose.Parse(raw)
	if err != nil || t.HeaderString("kid") != i.kid || t.HeaderString("alg") != "RS256" || t.Verify(&i.key.PublicKey) != nil {
		return nil, false
	}
	if iss, _ := t.Claims["iss"].(string); iss != i.URL {
		return t.Claims, false
	}
	if exp, ok := number(t.Claims["exp"]); !ok || time.Now().Unix() >= exp {
		return t.Claims, false
	}
	jti, _ := t.Claims["jti"].(string)
	i.mu.Lock()
	defer i.mu.Unlock()
	return t.Claims, !i.inactive[jti]
}

// UnknownSigner is a key nobody trusts, for forged tokens.
func UnknownSigner(alg string) any {
	if alg == "ES256" {
		k, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
		return k
	}
	k, _ := rsa.GenerateKey(rand.Reader, 2048)
	return k
}

// Kube is the fake Kubernetes API the STS reviews actor tokens with: it
// mints pod-bound service-account tokens and answers TokenReview for them,
// as the interop suite's fixture does (delegation-sts, interop/fixture).
type Kube struct {
	key *rsa.PrivateKey
	kid string
}

// KubernetesIssuer is the service-account issuer the fake claims to be.
const KubernetesIssuer = "https://kubernetes.default.svc.cluster.local"

// NewKube makes the fake with a fresh key.
func NewKube() (*Kube, error) {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		return nil, err
	}
	return &Kube{key: key, kid: hex.EncodeToString(random(8))}, nil
}

// ActorToken mints a token for the service account <namespace>/<name>,
// bound to a pod, for audience, valid for lifetime.
func (k *Kube) ActorToken(namespace, name, audience string, lifetime time.Duration) string {
	now := time.Now()
	pod := name + "-" + strings.ToLower(hex.EncodeToString(random(3)))
	claims := map[string]any{
		"iss": KubernetesIssuer, "sub": "system:serviceaccount:" + namespace + ":" + name, "aud": []string{audience},
		"iat": now.Unix(), "nbf": now.Unix(), "exp": now.Add(lifetime).Unix(), "jti": UUID(),
		"kubernetes.io": map[string]any{
			"namespace":      namespace,
			"serviceaccount": map[string]any{"name": name, "uid": UUID()},
			"pod":            map[string]any{"name": pod, "uid": UUID()},
		},
	}
	tok, err := jose.Sign(map[string]any{"alg": "RS256", "kid": k.kid}, claims, k.key)
	if err != nil {
		panic(err)
	}
	return tok
}

// ServeHTTP answers TokenReview, as kube-apiserver does for bound tokens.
func (k *Kube) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost || r.URL.Path != "/apis/authentication.k8s.io/v1/tokenreviews" {
		http.NotFound(w, r)
		return
	}
	var req struct {
		Kind string `json:"kind"`
		Spec struct {
			Token     string   `json:"token"`
			Audiences []string `json:"audiences"`
		} `json:"spec"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.Kind != "TokenReview" {
		writeJSON(w, http.StatusBadRequest, map[string]any{"kind": "Status", "status": "Failure", "code": 400})
		return
	}
	writeJSON(w, http.StatusCreated, map[string]any{
		"kind": "TokenReview", "apiVersion": "authentication.k8s.io/v1", "metadata": map[string]any{},
		"spec": map[string]any{"audiences": req.Spec.Audiences}, "status": k.review(req.Spec.Token, req.Spec.Audiences),
	})
}

func (k *Kube) review(raw string, audiences []string) map[string]any {
	fail := func(msg string) map[string]any { return map[string]any{"authenticated": false, "error": msg} }
	t, err := jose.Parse(raw)
	if err != nil || t.HeaderString("alg") != "RS256" || t.Verify(&k.key.PublicKey) != nil {
		return fail("[invalid bearer token]")
	}
	if iss, _ := t.Claims["iss"].(string); iss != KubernetesIssuer {
		return fail("[invalid bearer token, token issuer not trusted]")
	}
	now := time.Now().Unix()
	exp, _ := number(t.Claims["exp"])
	if now > exp+60 {
		return fail("[invalid bearer token, service account token has expired]")
	}
	want := audiences
	if len(want) == 0 {
		want = []string{KubernetesIssuer}
	}
	var tokenAud []string
	if list, ok := t.Claims["aud"].([]any); ok {
		for _, a := range list {
			if s, ok := a.(string); ok {
				tokenAud = append(tokenAud, s)
			}
		}
	}
	var matched []string
	for _, a := range want {
		if slices.Contains(tokenAud, a) {
			matched = append(matched, a)
		}
	}
	if len(matched) == 0 {
		return fail("[invalid bearer token, token audiences are invalid for the target audiences]")
	}
	ki, _ := t.Claims["kubernetes.io"].(map[string]any)
	ns, _ := ki["namespace"].(string)
	sa, _ := ki["serviceaccount"].(map[string]any)
	pod, _ := ki["pod"].(map[string]any)
	saName, _ := sa["name"].(string)
	podName, _ := pod["name"].(string)
	podUID, _ := pod["uid"].(string)
	return map[string]any{
		"authenticated": true, "audiences": matched,
		"user": map[string]any{
			"username": "system:serviceaccount:" + ns + ":" + saName, "uid": sa["uid"],
			"groups": []string{"system:serviceaccounts", "system:serviceaccounts:" + ns, "system:authenticated"},
			"extra": map[string]any{
				"authentication.kubernetes.io/pod-name": []string{podName},
				"authentication.kubernetes.io/pod-uid":  []string{podUID},
			},
		},
	}
}

func number(v any) (int64, bool) {
	switch n := v.(type) {
	case json.Number:
		i, err := n.Int64()
		return i, err == nil
	case float64:
		return int64(n), true
	case int64:
		return n, true
	case int:
		return int64(n), true
	}
	return 0, false
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// UUID is a random version 4 UUID.
func UUID() string {
	b := random(16)
	b[6] = b[6]&0x0f | 0x40
	b[8] = b[8]&0x3f | 0x80
	h := hex.EncodeToString(b)
	return h[:8] + "-" + h[8:12] + "-" + h[12:16] + "-" + h[16:20] + "-" + h[20:]
}

func random(n int) []byte {
	b := make([]byte, n)
	rand.Read(b)
	return b
}
