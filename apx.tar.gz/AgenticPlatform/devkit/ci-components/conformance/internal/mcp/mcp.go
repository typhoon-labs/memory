// Package mcp is the small part of the Model Context Protocol over
// Streamable HTTP that the suites and capture-mcp need: a client that lists
// and calls tools, and a server that serves them. Both are dual-era
// (MCP 2026-07-28, "Versioning and Compatibility"): the modern, stateless
// revision, 2026-07-28, which carries its version in every request and has
// no initialize handshake, and the legacy, session-based revisions up to
// 2025-11-25 that harnesses still speak. agentgateway 1.7 supports the
// 2026-07-28 revision (design/gateway.md); what it speaks to a backend, and
// which era a client sees through it, was not checked, so both sides speak
// both.
package mcp

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"slices"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

// Versions.
const (
	Modern = "2026-07-28"
	Legacy = "2025-11-25"
)

// Supported lists the versions both sides accept, newest first.
var Supported = []string{Modern, Legacy, "2025-06-18", "2025-03-26"}

// Error codes.
const (
	CodeUnsupportedVersion = -32022
	CodeMethodNotFound     = -32601
	CodeInvalidParams      = -32602
)

// Doer makes one HTTP request from wherever it stands.
type Doer interface {
	Do(ctx context.Context, r outcome.Request) outcome.Outcome
}

// RPCError is a JSON-RPC error.
type RPCError struct {
	Code    int             `json:"code"`
	Message string          `json:"message"`
	Data    json.RawMessage `json:"data,omitempty"`
}

func (e *RPCError) Error() string { return fmt.Sprintf("JSON-RPC error %d: %s", e.Code, e.Message) }

// Response is a JSON-RPC response.
type Response struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`
	Result  json.RawMessage `json:"result,omitempty"`
	Error   *RPCError       `json:"error,omitempty"`
}

// Call is one request's outcome and, when it carried one, its JSON-RPC
// response.
type Call struct {
	Outcome  outcome.Outcome
	Response *Response
}

// OK reports whether the call got a JSON-RPC result.
func (c Call) OK() bool {
	return c.Outcome.Kind == outcome.Response && c.Outcome.Status == http.StatusOK && c.Response != nil && c.Response.Error == nil
}

func (c Call) String() string {
	if c.Response != nil && c.Response.Error != nil {
		return fmt.Sprintf("HTTP %d with %v", c.Outcome.Status, c.Response.Error)
	}
	return c.Outcome.String()
}

// Client calls one MCP endpoint. It is not safe for concurrent use.
type Client struct {
	URL    string
	Token  string            // the bearer token, or "" for none
	Header map[string]string // more headers on every request
	HTTP   Doer

	era     string // "modern" or "legacy", once known
	session string
	version string
	nextID  int
}

// Era says which era the server turned out to speak, once a call has
// succeeded.
func (c *Client) Era() string { return c.era }

// Request sends one JSON-RPC request. The first request tries the modern
// revision; a 400 or 404 that is not a recognised modern error makes the
// client fall back to the legacy handshake and retry, as the 2026-07-28
// transport's "Backward Compatibility" describes. A 401 or 403 is returned
// as it is: those are the gateway's answers the suites assert.
func (c *Client) Request(ctx context.Context, method string, params map[string]any) Call {
	if c.era == "legacy" {
		return c.send(ctx, method, params, c.version)
	}
	call := c.send(ctx, method, params, Modern)
	if c.era == "modern" || call.Outcome.Kind != outcome.Response {
		return call
	}
	switch call.Outcome.Status {
	case http.StatusOK:
		c.era = "modern"
		return call
	case http.StatusBadRequest, http.StatusNotFound, http.StatusMethodNotAllowed:
		if call.Response != nil && call.Response.Error != nil && (call.Response.Error.Code == CodeUnsupportedVersion || call.Response.Error.Code == CodeMethodNotFound) {
			if call.Response.Error.Code == CodeMethodNotFound {
				c.era = "modern"
				return call
			}
			var data struct {
				Supported []string `json:"supported"`
			}
			json.Unmarshal(call.Response.Error.Data, &data)
			if slices.Contains(data.Supported, Modern) {
				return call
			}
		}
		if init := c.initialize(ctx); !init.OK() {
			return init
		}
		return c.send(ctx, method, params, c.version)
	}
	return call
}

func (c *Client) initialize(ctx context.Context) Call {
	c.era, c.version, c.session = "legacy", Legacy, ""
	call := c.send(ctx, "initialize", map[string]any{
		"protocolVersion": Legacy,
		"capabilities":    map[string]any{},
		"clientInfo":      map[string]any{"name": "platform-conformance", "version": "0.1.0"},
	}, "")
	if !call.OK() {
		c.era = ""
		return call
	}
	var res struct {
		ProtocolVersion string `json:"protocolVersion"`
	}
	json.Unmarshal(call.Response.Result, &res)
	if res.ProtocolVersion != "" {
		c.version = res.ProtocolVersion
	}
	if s := call.Outcome.Header["mcp-session-id"]; s != "" {
		c.session = s
	}
	c.post(ctx, map[string]any{"jsonrpc": "2.0", "method": "notifications/initialized"}, "notifications/initialized", "", c.version)
	return call
}

func (c *Client) send(ctx context.Context, method string, params map[string]any, version string) Call {
	c.nextID++
	p := map[string]any{}
	for k, v := range params {
		p[k] = v
	}
	if version == Modern {
		p["_meta"] = map[string]any{
			"io.modelcontextprotocol/protocolVersion":    Modern,
			"io.modelcontextprotocol/clientInfo":         map[string]any{"name": "platform-conformance", "version": "0.1.0"},
			"io.modelcontextprotocol/clientCapabilities": map[string]any{},
		}
	}
	msg := map[string]any{"jsonrpc": "2.0", "id": c.nextID, "method": method, "params": p}
	name, _ := params["name"].(string)
	o := c.post(ctx, msg, method, name, version)
	call := Call{Outcome: o}
	if o.Kind == outcome.Response {
		call.Response = parseBody(o)
	}
	return call
}

func (c *Client) post(ctx context.Context, msg map[string]any, method, name, version string) outcome.Outcome {
	body, _ := json.Marshal(msg)
	h := map[string]string{"Content-Type": "application/json", "Accept": "application/json, text/event-stream", "Mcp-Method": method}
	if name != "" {
		h["Mcp-Name"] = name
	}
	if version != "" {
		h["MCP-Protocol-Version"] = version
	}
	if c.session != "" {
		h["Mcp-Session-Id"] = c.session
	}
	if c.Token != "" {
		h["Authorization"] = "Bearer " + c.Token
	}
	for k, v := range c.Header {
		h[k] = v
	}
	return c.HTTP.Do(ctx, outcome.Request{Method: http.MethodPost, URL: c.URL, Header: h, Body: string(body)})
}

// parseBody finds the JSON-RPC response in a JSON body or an SSE stream.
func parseBody(o outcome.Outcome) *Response {
	body := strings.TrimSpace(o.Body)
	if strings.HasPrefix(o.Header["content-type"], "text/event-stream") || strings.HasPrefix(body, "event:") || strings.HasPrefix(body, "data:") {
		var last *Response
		sc := bufio.NewScanner(strings.NewReader(body))
		sc.Buffer(make([]byte, 64<<10), outcome.MaxBody)
		for sc.Scan() {
			line := sc.Text()
			if data, ok := strings.CutPrefix(line, "data:"); ok {
				var r Response
				if json.Unmarshal([]byte(strings.TrimSpace(data)), &r) == nil && (r.Result != nil || r.Error != nil) {
					last = &r
				}
			}
		}
		return last
	}
	var r Response
	if json.Unmarshal([]byte(body), &r) != nil || (r.Result == nil && r.Error == nil) {
		return nil
	}
	return &r
}

// Tool is a tool as tools/list describes it.
type Tool struct {
	Name        string         `json:"name"`
	Description string         `json:"description,omitempty"`
	InputSchema map[string]any `json:"inputSchema"`
	Annotations map[string]any `json:"annotations,omitempty"`
}

// ListTools lists the tools the caller sees.
func (c *Client) ListTools(ctx context.Context) ([]string, Call) {
	call := c.Request(ctx, "tools/list", map[string]any{})
	if !call.OK() {
		return nil, call
	}
	var res struct {
		Tools []Tool `json:"tools"`
	}
	json.Unmarshal(call.Response.Result, &res)
	var names []string
	for _, t := range res.Tools {
		names = append(names, t.Name)
	}
	return names, call
}

// CallTool calls one tool.
func (c *Client) CallTool(ctx context.Context, name string, args map[string]any) Call {
	if args == nil {
		args = map[string]any{}
	}
	return c.Request(ctx, "tools/call", map[string]any{"name": name, "arguments": args})
}

// ToolResult is a tools/call result's content.
type ToolResult struct {
	Content []struct {
		Type string `json:"type"`
		Text string `json:"text"`
	} `json:"content"`
	StructuredContent json.RawMessage `json:"structuredContent,omitempty"`
	IsError           bool            `json:"isError,omitempty"`
}

// Result decodes a successful tools/call's result.
func (c Call) Result() (ToolResult, error) {
	var r ToolResult
	if !c.OK() {
		return r, fmt.Errorf("no result: %s", c)
	}
	err := json.Unmarshal(c.Response.Result, &r)
	return r, err
}
