package mcp

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

func server() *Server {
	return &Server{Name: "t", Version: "1", Tools: []Tool{{Name: "a", InputSchema: map[string]any{"type": "object"}}},
		Call: func(context.Context, *http.Request, string, json.RawMessage) (any, *RPCError) {
			return map[string]any{"content": []any{map[string]any{"type": "text", "text": "hi"}}}, nil
		}}
}

func TestModern(t *testing.T) {
	var versions []string
	s := server()
	s.OnRequest = func(r *http.Request, method, version, _ string) *http.Request {
		versions = append(versions, method+"@"+version)
		return r
	}
	ts := httptest.NewServer(s)
	defer ts.Close()
	c := &Client{URL: ts.URL, HTTP: &outcome.Client{}}
	names, call := c.ListTools(context.Background())
	if !call.OK() || len(names) != 1 || names[0] != "a" || c.Era() != "modern" {
		t.Fatalf("tools/list: %v %s era %s", names, call, c.Era())
	}
	if r := c.CallTool(context.Background(), "a", nil); !r.OK() {
		t.Fatalf("tools/call: %s", r)
	}
	if strings.Join(versions, " ") != "tools/list@2026-07-28 tools/call@2026-07-28" {
		t.Errorf("requests: %v", versions)
	}
}

// A legacy server refuses a request before initialize with a plain 400.
func TestLegacyFallback(t *testing.T) {
	s := server()
	session := ""
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		var m struct{ Method string }
		json.Unmarshal(body, &m)
		if m.Method != "initialize" && r.Header.Get("Mcp-Session-Id") == "" {
			http.Error(w, "Bad Request: no session", http.StatusBadRequest)
			return
		}
		r.Body = io.NopCloser(strings.NewReader(string(body)))
		rec := httptest.NewRecorder()
		s.ServeHTTP(rec, r)
		if sid := rec.Header().Get("Mcp-Session-Id"); sid != "" {
			session = sid
		}
		for k, v := range rec.Header() {
			w.Header()[k] = v
		}
		w.WriteHeader(rec.Code)
		w.Write(rec.Body.Bytes())
	}))
	defer ts.Close()
	c := &Client{URL: ts.URL, HTTP: &outcome.Client{}}
	names, call := c.ListTools(context.Background())
	if !call.OK() || len(names) != 1 || c.Era() != "legacy" || session == "" {
		t.Fatalf("fallback: %v %s era %s session %q", names, call, c.Era(), session)
	}
}

// A refusal by the gateway is returned as it is, never retried as legacy.
func TestRefusalNotRetried(t *testing.T) {
	n := 0
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n++
		http.Error(w, "authentication failure", http.StatusUnauthorized)
	}))
	defer ts.Close()
	c := &Client{URL: ts.URL, HTTP: &outcome.Client{}}
	_, call := c.ListTools(context.Background())
	if call.Outcome.Status != http.StatusUnauthorized || n != 1 {
		t.Errorf("got %s after %d requests", call, n)
	}
}

func TestSSE(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/event-stream")
		io.WriteString(w, "event: message\ndata: {\"jsonrpc\":\"2.0\",\"method\":\"notifications/progress\",\"params\":{}}\n\nevent: message\ndata: {\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{\"tools\":[{\"name\":\"s\",\"inputSchema\":{}}]}}\n\n")
	}))
	defer ts.Close()
	names, call := (&Client{URL: ts.URL, HTTP: &outcome.Client{}}).ListTools(context.Background())
	if !call.OK() || len(names) != 1 || names[0] != "s" {
		t.Errorf("SSE: %v %s", names, call)
	}
}

func TestUnsupportedVersion(t *testing.T) {
	ts := httptest.NewServer(server())
	defer ts.Close()
	o := (&outcome.Client{}).Do(context.Background(), outcome.Request{Method: "POST", URL: ts.URL,
		Header: map[string]string{"MCP-Protocol-Version": "1900-01-01"}, Body: `{"jsonrpc":"2.0","id":1,"method":"tools/list"}`})
	if o.Status != 400 || !strings.Contains(o.Body, "-32022") {
		t.Errorf("an unknown version: %s", o)
	}
}
