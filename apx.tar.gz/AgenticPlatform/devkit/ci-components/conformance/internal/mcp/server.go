package mcp

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"slices"
)

// Server serves tools over Streamable HTTP, in both eras. Every request
// reaches OnRequest first, whatever its method, so a fixture can record it.
type Server struct {
	Name, Version string
	Tools         []Tool
	// Call runs a tool. A returned *RPCError is sent as the JSON-RPC error.
	Call func(ctx context.Context, r *http.Request, name string, args json.RawMessage) (any, *RPCError)
	// OnRequest sees every request with its JSON-RPC method (or "" when the
	// body is not JSON-RPC), the protocol version it declared and, for
	// tools/call, the tool's name, and may return the request with a new
	// context for Call.
	OnRequest func(r *http.Request, method, version, tool string) *http.Request
}

type rpcRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id,omitempty"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params,omitempty"`
}

// ServeHTTP handles one POST to the MCP endpoint.
func (s *Server) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		http.Error(w, "the MCP endpoint takes POST", http.StatusMethodNotAllowed)
		return
	}
	raw, _ := io.ReadAll(io.LimitReader(r.Body, 4<<20))
	var req rpcRequest
	if err := json.Unmarshal(raw, &req); err != nil || req.JSONRPC != "2.0" || req.Method == "" {
		if s.OnRequest != nil {
			s.OnRequest(r, "", r.Header.Get("MCP-Protocol-Version"), "")
		}
		writeRPC(w, http.StatusBadRequest, nil, nil, &RPCError{Code: -32700, Message: "not a JSON-RPC 2.0 request"})
		return
	}
	var params struct {
		Meta map[string]json.RawMessage `json:"_meta"`
		Name string                     `json:"name"`
		Args json.RawMessage            `json:"arguments"`
	}
	json.Unmarshal(req.Params, &params)
	version := r.Header.Get("MCP-Protocol-Version")
	if v, ok := params.Meta["io.modelcontextprotocol/protocolVersion"]; ok {
		json.Unmarshal(v, &version)
	}
	if s.OnRequest != nil {
		tool := ""
		if req.Method == "tools/call" {
			tool = params.Name
		}
		r = s.OnRequest(r, req.Method, version, tool)
	}
	if req.ID == nil { // a notification
		w.WriteHeader(http.StatusAccepted)
		return
	}
	modern := version == Modern
	if version != "" && !slices.Contains(Supported, version) && req.Method != "initialize" {
		data, _ := json.Marshal(map[string]any{"supported": Supported, "requested": version})
		writeRPC(w, http.StatusBadRequest, req.ID, nil, &RPCError{Code: CodeUnsupportedVersion, Message: "Unsupported protocol version", Data: data})
		return
	}
	serverInfo := map[string]any{"name": s.Name, "version": s.Version}
	complete := func(result map[string]any) map[string]any {
		if modern {
			result["resultType"] = "complete"
			result["_meta"] = map[string]any{"io.modelcontextprotocol/serverInfo": serverInfo}
		}
		return result
	}
	switch req.Method {
	case "initialize":
		var p struct {
			ProtocolVersion string `json:"protocolVersion"`
		}
		json.Unmarshal(req.Params, &p)
		v := Legacy
		if slices.Contains(Supported[1:], p.ProtocolVersion) {
			v = p.ProtocolVersion
		}
		id := make([]byte, 16)
		rand.Read(id)
		w.Header().Set("Mcp-Session-Id", hex.EncodeToString(id))
		writeRPC(w, http.StatusOK, req.ID, map[string]any{"protocolVersion": v, "capabilities": map[string]any{"tools": map[string]any{}}, "serverInfo": serverInfo}, nil)
	case "server/discover":
		writeRPC(w, http.StatusOK, req.ID, complete(map[string]any{"supportedVersions": Supported, "capabilities": map[string]any{"tools": map[string]any{}}}), nil)
	case "ping":
		writeRPC(w, http.StatusOK, req.ID, map[string]any{}, nil)
	case "tools/list":
		writeRPC(w, http.StatusOK, req.ID, complete(map[string]any{"tools": s.Tools}), nil)
	case "tools/call":
		if !slices.ContainsFunc(s.Tools, func(t Tool) bool { return t.Name == params.Name }) {
			writeRPC(w, http.StatusOK, req.ID, nil, &RPCError{Code: CodeInvalidParams, Message: "unknown tool: " + params.Name})
			return
		}
		res, rerr := s.Call(r.Context(), r, params.Name, params.Args)
		if rerr != nil {
			writeRPC(w, http.StatusOK, req.ID, nil, rerr)
			return
		}
		m, ok := res.(map[string]any)
		if !ok {
			m = map[string]any{"content": res}
		}
		writeRPC(w, http.StatusOK, req.ID, complete(m), nil)
	default:
		status := http.StatusOK
		if modern {
			status = http.StatusNotFound
		}
		writeRPC(w, status, req.ID, nil, &RPCError{Code: CodeMethodNotFound, Message: "Method not found: " + req.Method})
	}
}

func writeRPC(w http.ResponseWriter, status int, id json.RawMessage, result any, rerr *RPCError) {
	msg := map[string]any{"jsonrpc": "2.0"}
	if id != nil {
		msg["id"] = id
	}
	if rerr != nil {
		msg["error"] = rerr
	} else {
		msg["result"] = result
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(msg)
}
