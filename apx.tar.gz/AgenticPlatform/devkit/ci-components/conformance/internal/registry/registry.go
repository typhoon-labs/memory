// Package registry reads files out of container images in an OCI
// registry, by digest, on the standard library: the contract stage takes
// the STS's binary from the STS's pinned image and a workload's
// workload.yaml from the image under test, without a container runtime.
//
// It reads, never writes. Registries that answer anonymously, as floci's
// does, need nothing; others get the Docker token flow (RFC 6750 bearer
// tokens from the realm a 401 names) with optional basic credentials.
package registry

import (
	"archive/tar"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"hash"
	"io"
	"net/http"
	"net/url"
	"path"
	"strings"
	"sync"
)

// Media types the client accepts for manifests and indexes.
const (
	OCIIndex       = "application/vnd.oci.image.index.v1+json"
	OCIManifest    = "application/vnd.oci.image.manifest.v1+json"
	DockerList     = "application/vnd.docker.distribution.manifest.list.v2+json"
	DockerManifest = "application/vnd.docker.distribution.manifest.v2+json"
)

// ErrNotFound is returned when an image holds no file at the path asked.
var ErrNotFound = errors.New("not in the image")

// Ref is a parsed image reference: host/repository and a tag or digest.
type Ref struct {
	Host, Repository string
	Reference        string // sha256:… or a tag
}

// ParseRef reads host/repo[:tag][@sha256:…]. The digest wins over a tag.
// A reference without a registry host is refused: the platform pins every
// image by its full name.
func ParseRef(s string) (Ref, error) {
	name, digest, hasDigest := strings.Cut(s, "@")
	host, rest, ok := strings.Cut(name, "/")
	if !ok || !(strings.ContainsAny(host, ".:") || host == "localhost") {
		return Ref{}, fmt.Errorf("image %q: name the registry host", s)
	}
	repo, tag := rest, "latest"
	if i := strings.LastIndex(rest, ":"); i > strings.LastIndex(rest, "/") {
		repo, tag = rest[:i], rest[i+1:]
	}
	r := Ref{Host: host, Repository: repo, Reference: tag}
	if hasDigest {
		if !strings.HasPrefix(digest, "sha256:") || len(digest) != 71 {
			return Ref{}, fmt.Errorf("image %q: the digest must be sha256:<64 hex>", s)
		}
		r.Reference = digest
	}
	if repo == "" {
		return Ref{}, fmt.Errorf("image %q: no repository", s)
	}
	return r, nil
}

func (r Ref) String() string {
	sep := ":"
	if strings.HasPrefix(r.Reference, "sha256:") {
		sep = "@"
	}
	return r.Host + "/" + r.Repository + sep + r.Reference
}

// Client reads from registries.
type Client struct {
	// PlainHTTP speaks HTTP, not HTTPS, to every registry, as to floci's.
	PlainHTTP bool
	// Username and Password are sent to a token realm or a basic
	// challenge, when set.
	Username, Password string
	// HTTP is the client to use; nil means one that ignores proxy
	// variables, since the contract stage never uses the sandbox proxy.
	HTTP *http.Client

	mu     sync.Mutex
	tokens map[string]string // host/repository -> bearer token
}

func (c *Client) http() *http.Client {
	if c.HTTP != nil {
		return c.HTTP
	}
	return &http.Client{Transport: &http.Transport{Proxy: nil}}
}

func (c *Client) base(r Ref) string {
	scheme := "https"
	if c.PlainHTTP {
		scheme = "http"
	}
	host := r.Host
	if host == "docker.io" {
		// Docker Hub's name; its registry API answers elsewhere.
		host = "registry-1.docker.io"
	}
	return scheme + "://" + host + "/v2/" + r.Repository
}

// get fetches a registry URL for r, answering a bearer or basic challenge
// once.
func (c *Client) get(ctx context.Context, r Ref, u string, accept []string) (*http.Response, error) {
	key := r.Host + "/" + r.Repository
	for attempt := 0; attempt < 2; attempt++ {
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
		if err != nil {
			return nil, err
		}
		for _, a := range accept {
			req.Header.Add("Accept", a)
		}
		c.mu.Lock()
		tok := c.tokens[key]
		c.mu.Unlock()
		switch {
		case tok != "":
			req.Header.Set("Authorization", "Bearer "+tok)
		case c.Username != "" && attempt > 0:
			req.SetBasicAuth(c.Username, c.Password)
		}
		resp, err := c.http().Do(req)
		if err != nil {
			return nil, err
		}
		if resp.StatusCode != http.StatusUnauthorized || attempt > 0 {
			return resp, nil
		}
		challenge := resp.Header.Get("Www-Authenticate")
		resp.Body.Close()
		if strings.HasPrefix(strings.ToLower(challenge), "bearer ") {
			t, err := c.token(ctx, challenge, r)
			if err != nil {
				return nil, err
			}
			c.mu.Lock()
			if c.tokens == nil {
				c.tokens = map[string]string{}
			}
			c.tokens[key] = t
			c.mu.Unlock()
		} else if c.Username == "" {
			return nil, fmt.Errorf("%s: 401 and no credentials (%s)", u, challenge)
		}
	}
	return nil, errors.New("unreachable")
}

// token asks the challenge's realm for a pull token.
func (c *Client) token(ctx context.Context, challenge string, r Ref) (string, error) {
	params := map[string]string{}
	for _, part := range splitChallenge(challenge[len("bearer "):]) {
		k, v, ok := strings.Cut(part, "=")
		if ok {
			params[strings.ToLower(strings.TrimSpace(k))] = strings.Trim(strings.TrimSpace(v), `"`)
		}
	}
	realm := params["realm"]
	if realm == "" {
		return "", fmt.Errorf("bearer challenge without a realm: %s", challenge)
	}
	q := url.Values{}
	if s := params["service"]; s != "" {
		q.Set("service", s)
	}
	scope := params["scope"]
	if scope == "" {
		scope = "repository:" + r.Repository + ":pull"
	}
	q.Set("scope", scope)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, realm+"?"+q.Encode(), nil)
	if err != nil {
		return "", err
	}
	if c.Username != "" {
		req.SetBasicAuth(c.Username, c.Password)
	}
	resp, err := c.http().Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("token realm %s: HTTP %d", realm, resp.StatusCode)
	}
	var body struct {
		Token       string `json:"token"`
		AccessToken string `json:"access_token"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&body); err != nil {
		return "", fmt.Errorf("token realm %s: %v", realm, err)
	}
	if body.Token != "" {
		return body.Token, nil
	}
	return body.AccessToken, nil
}

// splitChallenge splits a challenge's parameters at commas outside quotes.
func splitChallenge(s string) []string {
	var out []string
	quoted, start := false, 0
	for i, ch := range s {
		switch {
		case ch == '"':
			quoted = !quoted
		case ch == ',' && !quoted:
			out = append(out, s[start:i])
			start = i + 1
		}
	}
	return append(out, s[start:])
}

// Descriptor names content by digest.
type Descriptor struct {
	MediaType string `json:"mediaType"`
	Digest    string `json:"digest"`
	Size      int64  `json:"size"`
	Platform  *struct {
		OS           string `json:"os"`
		Architecture string `json:"architecture"`
		Variant      string `json:"variant,omitempty"`
	} `json:"platform,omitempty"`
}

// Manifest is an image manifest or an index, whichever arrived.
type Manifest struct {
	MediaType string       `json:"mediaType"`
	Config    Descriptor   `json:"config"`
	Layers    []Descriptor `json:"layers"`
	Manifests []Descriptor `json:"manifests"`
}

// Config is the part of an image's configuration a runner reads.
type Config struct {
	Config struct {
		User         string              `json:"User"`
		Env          []string            `json:"Env"`
		Entrypoint   []string            `json:"Entrypoint"`
		Cmd          []string            `json:"Cmd"`
		WorkingDir   string              `json:"WorkingDir"`
		ExposedPorts map[string]struct{} `json:"ExposedPorts"`
	} `json:"config"`
}

// manifest fetches a manifest by tag or digest and checks a digest
// reference against what arrived.
func (c *Client) manifest(ctx context.Context, r Ref, reference string) (Manifest, string, error) {
	resp, err := c.get(ctx, r, c.base(r)+"/manifests/"+reference, []string{OCIIndex, OCIManifest, DockerList, DockerManifest})
	if err != nil {
		return Manifest{}, "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return Manifest{}, "", fmt.Errorf("%s@%s: manifest: HTTP %d", r.Host+"/"+r.Repository, reference, resp.StatusCode)
	}
	raw, err := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	if err != nil {
		return Manifest{}, "", err
	}
	sum := sha256.Sum256(raw)
	got := "sha256:" + hex.EncodeToString(sum[:])
	if strings.HasPrefix(reference, "sha256:") && got != reference {
		return Manifest{}, "", fmt.Errorf("%s: the registry sent %s for %s", r.Repository, got, reference)
	}
	var m Manifest
	if err := json.Unmarshal(raw, &m); err != nil {
		return Manifest{}, "", fmt.Errorf("%s: manifest: %v", r, err)
	}
	if m.MediaType == "" {
		m.MediaType = resp.Header.Get("Content-Type")
	}
	return m, got, nil
}

// Resolve returns the digest a reference names now: its manifest's or
// index's, as a registry addresses it.
func (c *Client) Resolve(ctx context.Context, ref string) (string, error) {
	r, err := ParseRef(ref)
	if err != nil {
		return "", err
	}
	_, d, err := c.manifest(ctx, r, r.Reference)
	return d, err
}

// Manifest fetches ref's manifest or index, and the digest it has.
func (c *Client) Manifest(ctx context.Context, ref string) (Manifest, string, error) {
	r, err := ParseRef(ref)
	if err != nil {
		return Manifest{}, "", err
	}
	return c.manifest(ctx, r, r.Reference)
}

// Exists reports whether ref names a manifest the registry has: false
// for its 404, an error for any other failure.
func (c *Client) Exists(ctx context.Context, ref string) (bool, error) {
	r, err := ParseRef(ref)
	if err != nil {
		return false, err
	}
	resp, err := c.get(ctx, r, c.base(r)+"/manifests/"+r.Reference, []string{OCIIndex, OCIManifest, DockerList, DockerManifest})
	if err != nil {
		return false, err
	}
	resp.Body.Close()
	switch resp.StatusCode {
	case http.StatusOK:
		return true, nil
	case http.StatusNotFound:
		return false, nil
	}
	return false, fmt.Errorf("%s: manifest: HTTP %d", ref, resp.StatusCode)
}

// Artifact reads the one layer of an OCI artifact under ref, such as
// kagent-package's packaged definition, its digest checked, at most max
// bytes.
func (c *Client) Artifact(ctx context.Context, ref string, max int64) ([]byte, error) {
	r, err := ParseRef(ref)
	if err != nil {
		return nil, err
	}
	m, _, err := c.manifest(ctx, r, r.Reference)
	if err != nil {
		return nil, err
	}
	if len(m.Layers) != 1 {
		return nil, fmt.Errorf("%s: want an artifact of one layer, got %d", ref, len(m.Layers))
	}
	rc, err := c.blob(ctx, r, m.Layers[0])
	if err != nil {
		return nil, err
	}
	defer rc.Close()
	data, err := io.ReadAll(io.LimitReader(rc, max+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > max {
		return nil, fmt.Errorf("%s: its layer is larger than %d bytes", ref, max)
	}
	return data, nil
}

// image finds the platform's image manifest under ref, through an index if
// ref names one.
func (c *Client) image(ctx context.Context, ref, platform string) (Ref, Manifest, error) {
	r, err := ParseRef(ref)
	if err != nil {
		return r, Manifest{}, err
	}
	m, _, err := c.manifest(ctx, r, r.Reference)
	if err != nil {
		return r, m, err
	}
	if len(m.Manifests) == 0 {
		return r, m, nil
	}
	osName, arch, _ := strings.Cut(platform, "/")
	for _, d := range m.Manifests {
		if d.Platform != nil && d.Platform.OS == osName && d.Platform.Architecture == arch {
			im, _, err := c.manifest(ctx, r, d.Digest)
			return r, im, err
		}
	}
	return r, m, fmt.Errorf("%s has no %s image", ref, platform)
}

// blob opens a blob, to be read once.
func (c *Client) blob(ctx context.Context, r Ref, d Descriptor) (io.ReadCloser, error) {
	resp, err := c.get(ctx, r, c.base(r)+"/blobs/"+d.Digest, nil)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode != http.StatusOK {
		resp.Body.Close()
		return nil, fmt.Errorf("%s: blob %s: HTTP %d", r.Repository, d.Digest, resp.StatusCode)
	}
	return &verified{rc: resp.Body, h: sha256.New(), want: d.Digest}, nil
}

// verified checks a blob's digest as it is read to the end.
type verified struct {
	rc   io.ReadCloser
	h    hash.Hash
	want string
}

func (v *verified) Read(p []byte) (int, error) {
	n, err := v.rc.Read(p)
	v.h.Write(p[:n])
	if err == io.EOF {
		if got := "sha256:" + hex.EncodeToString(v.h.Sum(nil)); got != v.want {
			return n, fmt.Errorf("blob %s arrived as %s", v.want, got)
		}
	}
	return n, err
}

func (v *verified) Close() error { return v.rc.Close() }

// ImageConfig reads the platform's image configuration under ref.
func (c *Client) ImageConfig(ctx context.Context, ref, platform string) (Config, error) {
	r, m, err := c.image(ctx, ref, platform)
	if err != nil {
		return Config{}, err
	}
	rc, err := c.blob(ctx, r, m.Config)
	if err != nil {
		return Config{}, err
	}
	defer rc.Close()
	var cfg Config
	raw, err := io.ReadAll(io.LimitReader(rc, 4<<20))
	if err != nil {
		return cfg, err
	}
	return cfg, json.Unmarshal(raw, &cfg)
}

// ReadFile returns the file at name in the platform's image under ref, as
// the image's layers leave it: the topmost layer that holds or deletes it
// decides. A symbolic link is not followed. The file is at most max bytes.
func (c *Client) ReadFile(ctx context.Context, ref, platform, name string, max int64) ([]byte, error) {
	r, m, err := c.image(ctx, ref, platform)
	if err != nil {
		return nil, err
	}
	want := strings.TrimPrefix(path.Clean("/"+name), "/")
	for i := len(m.Layers) - 1; i >= 0; i-- {
		data, state, err := c.findInLayer(ctx, r, m.Layers[i], want, max)
		if err != nil {
			return nil, err
		}
		switch state {
		case found:
			return data, nil
		case deleted:
			return nil, fmt.Errorf("%s: %s: %w", ref, name, ErrNotFound)
		}
	}
	return nil, fmt.Errorf("%s: %s: %w", ref, name, ErrNotFound)
}

type layerState int

const (
	absent layerState = iota
	found
	deleted
)

func (c *Client) findInLayer(ctx context.Context, r Ref, d Descriptor, want string, max int64) ([]byte, layerState, error) {
	switch {
	case strings.HasSuffix(d.MediaType, "tar+gzip"), strings.HasSuffix(d.MediaType, ".tar.gzip"):
	case strings.HasSuffix(d.MediaType, "tar"):
	default:
		return nil, absent, fmt.Errorf("%s: layer %s is %s, which this client does not read", r.Repository, d.Digest, d.MediaType)
	}
	rc, err := c.blob(ctx, r, d)
	if err != nil {
		return nil, absent, err
	}
	defer rc.Close()
	var src io.Reader = rc
	if strings.Contains(d.MediaType, "gzip") {
		gz, err := gzip.NewReader(rc)
		if err != nil {
			return nil, absent, fmt.Errorf("%s: layer %s: %v", r.Repository, d.Digest, err)
		}
		defer gz.Close()
		src = gz
	}
	dir, base := path.Split(want)
	whiteout := dir + ".wh." + base
	tr := tar.NewReader(src)
	var data []byte
	state := absent
	for {
		h, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, absent, fmt.Errorf("%s: layer %s: %v", r.Repository, d.Digest, err)
		}
		n := strings.TrimPrefix(path.Clean("/"+h.Name), "/")
		switch {
		case n == whiteout:
			state, data = deleted, nil
		case n == want && h.Typeflag == tar.TypeReg:
			if h.Size > max {
				return nil, absent, fmt.Errorf("%s: %s is %d bytes, more than %d", r.Repository, want, h.Size, max)
			}
			if data, err = io.ReadAll(tr); err != nil {
				return nil, absent, err
			}
			state = found
		case n == want:
			return nil, absent, fmt.Errorf("%s: %s is not a regular file in layer %s", r.Repository, want, d.Digest)
		}
	}
	// Read to the end, so the digest is checked.
	if _, err := io.Copy(io.Discard, rc); err != nil {
		return nil, absent, err
	}
	return data, state, nil
}
