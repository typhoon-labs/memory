package registry

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

type fakeRegistry struct {
	blobs     map[string][]byte
	manifests map[string][]byte // by digest and by tag
	types     map[string]string
	token     string // when set, a bearer token is required
}

func digest(b []byte) string { s := sha256.Sum256(b); return "sha256:" + hex.EncodeToString(s[:]) }

func layer(t *testing.T, files map[string]string) []byte {
	var buf bytes.Buffer
	gz := gzip.NewWriter(&buf)
	tw := tar.NewWriter(gz)
	for name, body := range files {
		if err := tw.WriteHeader(&tar.Header{Name: name, Mode: 0o755, Size: int64(len(body)), Typeflag: tar.TypeReg}); err != nil {
			t.Fatal(err)
		}
		tw.Write([]byte(body))
	}
	tw.Close()
	gz.Close()
	return buf.Bytes()
}

func (f *fakeRegistry) add(b []byte) Descriptor {
	d := digest(b)
	f.blobs[d] = b
	return Descriptor{Digest: d, Size: int64(len(b))}
}

func (f *fakeRegistry) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path == "/token" {
		if u, p, _ := r.BasicAuth(); u != "ci" || p != "secret" || r.URL.Query().Get("scope") != "repository:team/app:pull" {
			http.Error(w, "no", http.StatusUnauthorized)
			return
		}
		json.NewEncoder(w).Encode(map[string]string{"token": f.token})
		return
	}
	if f.token != "" && r.Header.Get("Authorization") != "Bearer "+f.token {
		w.Header().Set("Www-Authenticate", `Bearer realm="http://`+r.Host+`/token",service="fake",scope="repository:team/app:pull"`)
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	rest, ok := strings.CutPrefix(r.URL.Path, "/v2/team/app/")
	if !ok {
		http.NotFound(w, r)
		return
	}
	kind, ref, _ := strings.Cut(rest, "/")
	switch kind {
	case "manifests":
		b, ok := f.manifests[ref]
		if !ok {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", f.types[ref])
		w.Write(b)
	case "blobs":
		b, ok := f.blobs[ref]
		if !ok {
			http.NotFound(w, r)
			return
		}
		w.Write(b)
	}
}

// newFake serves team/app:v1, an index of one amd64 image with two layers:
// the second replaces /bin/tool and deletes /etc/old.
func newFake(t *testing.T) (*fakeRegistry, string) {
	f := &fakeRegistry{blobs: map[string][]byte{}, manifests: map[string][]byte{}, types: map[string]string{}}
	cfg, _ := json.Marshal(map[string]any{"config": map[string]any{"User": "65532", "Entrypoint": []string{"/bin/tool"}, "Env": []string{"A=1"}}})
	cd := f.add(cfg)
	cd.MediaType = "application/vnd.oci.image.config.v1+json"
	l1 := f.add(layer(t, map[string]string{"bin/tool": "old", "etc/old": "x", "etc/agentic/workload.yaml": "name: a"}))
	l1.MediaType = "application/vnd.oci.image.layer.v1.tar+gzip"
	l2 := f.add(layer(t, map[string]string{"bin/tool": "new", "etc/.wh.old": ""}))
	l2.MediaType = "application/vnd.oci.image.layer.v1.tar+gzip"
	m, _ := json.Marshal(Manifest{MediaType: OCIManifest, Config: cd, Layers: []Descriptor{l1, l2}})
	md := digest(m)
	f.manifests[md], f.types[md] = m, OCIManifest
	idx := map[string]any{"schemaVersion": 2, "mediaType": OCIIndex, "manifests": []any{
		map[string]any{"mediaType": OCIManifest, "digest": md, "size": len(m), "platform": map[string]string{"os": "linux", "architecture": "amd64"}},
	}}
	ib, _ := json.Marshal(idx)
	id := digest(ib)
	f.manifests[id], f.manifests["v1"], f.types[id], f.types["v1"] = ib, ib, OCIIndex, OCIIndex
	return f, id
}

func TestReadFile(t *testing.T) {
	f, id := newFake(t)
	srv := httptest.NewServer(f)
	defer srv.Close()
	host := strings.TrimPrefix(srv.URL, "http://")
	c := &Client{PlainHTTP: true}
	ctx := context.Background()
	ref := host + "/team/app@" + id
	got, err := c.ReadFile(ctx, ref, "linux/amd64", "/bin/tool", 1<<20)
	if err != nil || string(got) != "new" {
		t.Fatalf("the top layer's file: %q, %v", got, err)
	}
	if got, err := c.ReadFile(ctx, ref, "linux/amd64", "etc/agentic/workload.yaml", 1<<20); err != nil || string(got) != "name: a" {
		t.Errorf("a lower layer's file: %q, %v", got, err)
	}
	if _, err := c.ReadFile(ctx, ref, "linux/amd64", "/etc/old", 1<<20); !errors.Is(err, ErrNotFound) {
		t.Errorf("a deleted file: %v", err)
	}
	if _, err := c.ReadFile(ctx, ref, "linux/amd64", "/nope", 1<<20); !errors.Is(err, ErrNotFound) {
		t.Errorf("a missing file: %v", err)
	}
	if _, err := c.ReadFile(ctx, ref, "linux/arm64", "/bin/tool", 1<<20); err == nil {
		t.Error("an absent platform was found")
	}
	if _, err := c.ReadFile(ctx, ref, "linux/amd64", "/bin/tool", 2); err == nil {
		t.Error("a file over the bound was read")
	}
	cfg, err := c.ImageConfig(ctx, host+"/team/app:v1", "linux/amd64")
	if err != nil || cfg.Config.User != "65532" || cfg.Config.Entrypoint[0] != "/bin/tool" {
		t.Errorf("config %+v, %v", cfg, err)
	}
	if d, err := c.Resolve(ctx, host+"/team/app:v1"); err != nil || d != id {
		t.Errorf("resolve: %s, %v", d, err)
	}
	// A digest the registry does not hold under that name.
	if _, err := c.ReadFile(ctx, host+"/team/app@sha256:"+strings.Repeat("0", 64), "linux/amd64", "/bin/tool", 1<<20); err == nil {
		t.Error("an unknown digest was read")
	}
}

func TestBearerChallenge(t *testing.T) {
	f, id := newFake(t)
	f.token = "tok"
	srv := httptest.NewServer(f)
	defer srv.Close()
	host := strings.TrimPrefix(srv.URL, "http://")
	ctx := context.Background()
	if _, err := (&Client{PlainHTTP: true}).ReadFile(ctx, host+"/team/app@"+id, "linux/amd64", "/bin/tool", 1<<20); err == nil {
		t.Error("read without credentials from a registry that wants them")
	}
	c := &Client{PlainHTTP: true, Username: "ci", Password: "secret"}
	if got, err := c.ReadFile(ctx, host+"/team/app@"+id, "linux/amd64", "/bin/tool", 1<<20); err != nil || string(got) != "new" {
		t.Errorf("with a token: %q, %v", got, err)
	}
}

func TestParseRef(t *testing.T) {
	for in, want := range map[string]Ref{
		"floci:4566/000000000000/us-east-1/platform/x@sha256:" + strings.Repeat("a", 64): {"floci:4566", "000000000000/us-east-1/platform/x", "sha256:" + strings.Repeat("a", 64)},
		"registry.gitlab.com/g/p/app:p12":                                                {"registry.gitlab.com", "g/p/app", "p12"},
		"127.0.0.1:4566/a/b":                                                             {"127.0.0.1:4566", "a/b", "latest"},
		"localhost:4566/a/b:t@sha256:" + strings.Repeat("b", 64):                         {"localhost:4566", "a/b", "sha256:" + strings.Repeat("b", 64)},
	} {
		got, err := ParseRef(in)
		if err != nil || got != want {
			t.Errorf("%s: %+v, %v", in, got, err)
		}
	}
	for _, bad := range []string{"busybox", "library/busybox:1", "floci:4566/x@sha256:abc", "floci:4566/"} {
		if _, err := ParseRef(bad); err == nil {
			t.Errorf("%s was accepted", bad)
		}
	}
}

func TestArtifactAndExists(t *testing.T) {
	f, _ := newFake(t)
	srv := httptest.NewServer(f)
	defer srv.Close()
	host := strings.TrimPrefix(srv.URL, "http://")
	body := []byte(`{"kind":"Agent"}`)
	l := f.add(body)
	l.MediaType = "application/json"
	m, _ := json.Marshal(Manifest{MediaType: OCIManifest, Config: Descriptor{MediaType: "application/vnd.oci.empty.v1+json"}, Layers: []Descriptor{l}})
	md := digest(m)
	f.manifests[md], f.types[md] = m, OCIManifest
	f.manifests["sha256-"+strings.TrimPrefix(md, "sha256:")], f.types["sha256-"+strings.TrimPrefix(md, "sha256:")] = m, OCIManifest
	c := &Client{PlainHTTP: true}
	got, err := c.Artifact(context.Background(), host+"/team/app@"+md, 100)
	if err != nil || string(got) != string(body) {
		t.Fatalf("artifact: %q %v", got, err)
	}
	if _, err := c.Artifact(context.Background(), host+"/team/app@"+md, 3); err == nil {
		t.Error("an artifact past max must be an error")
	}
	if ok, err := c.Exists(context.Background(), host+"/team/app:sha256-"+strings.TrimPrefix(md, "sha256:")); !ok || err != nil {
		t.Errorf("an existing tag: %v %v", ok, err)
	}
	if ok, err := c.Exists(context.Background(), host+"/team/app:sha256-0000"); ok || err != nil {
		t.Errorf("a missing tag: %v %v", ok, err)
	}
	if _, d, err := c.Manifest(context.Background(), host+"/team/app@"+md); err != nil || d != md {
		t.Errorf("manifest: %s %v", d, err)
	}
}
