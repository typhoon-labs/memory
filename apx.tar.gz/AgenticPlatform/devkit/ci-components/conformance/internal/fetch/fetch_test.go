package fetch

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestDo(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Got", r.Header.Get("X-Send"))
		w.Write([]byte(strings.Repeat("a", 100)))
	}))
	defer srv.Close()
	c := &Client{Max: 100}
	resp, err := c.Do(context.Background(), http.MethodGet, srv.URL, map[string]string{"X-Send": "yes"}, nil)
	if err != nil || resp.Status != 200 || len(resp.Body) != 100 || resp.Header.Get("X-Got") != "yes" {
		t.Fatalf("a body of exactly Max: %v %+v", err, resp)
	}
	c.Max = 99
	if _, err := c.Do(context.Background(), http.MethodGet, srv.URL, nil, nil); err == nil || !strings.Contains(err.Error(), "larger than 99") {
		t.Fatalf("a body past Max must be an error, never a truncated body: %v", err)
	}
}

func TestLines(t *testing.T) {
	body := "one\r\ntwo\n\nthree, cut"
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/missing" {
			http.Error(w, "no such sink", http.StatusNotFound)
			return
		}
		w.Write([]byte(body))
	}))
	defer srv.Close()
	c := &Client{}
	var got []string
	if err := c.Lines(context.Background(), srv.URL+"/siem", int64(len(body)), func(l []byte) { got = append(got, string(l)) }); err != nil {
		t.Fatal(err)
	}
	if strings.Join(got, "|") != "one|two||three, cut" {
		t.Errorf("lines: %q", got)
	}
	if err := c.Lines(context.Background(), srv.URL+"/siem", int64(len(body))-1, func([]byte) {}); err == nil || !strings.Contains(err.Error(), "larger than") {
		t.Errorf("an answer past max must be an error: %v", err)
	}
	if err := c.Lines(context.Background(), srv.URL+"/missing", 1<<20, func([]byte) {}); err == nil || !strings.Contains(err.Error(), "404 no such sink") {
		t.Errorf("a 404 must be an error naming it: %v", err)
	}
}
