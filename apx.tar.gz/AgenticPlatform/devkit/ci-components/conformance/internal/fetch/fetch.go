// Package fetch reads what the platform's stores hold, for the cases that
// judge by what arrived where: the usage table, Langfuse's API and the
// buckets (plan/local-build.md, "B3 in detail", The checks). It is not
// outcome's client, whose bodies stop at outcome.MaxBody: a check that a
// secret is absent must never pass on a truncated read, so a body larger
// than Max is an error, never a shorter body. Proxy variables are never
// read, as in outcome.
package fetch

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io"
	"net"
	"net/http"
	"time"
)

// DefaultMax is the largest body a Client reads unless told otherwise.
const DefaultMax = 32 << 20

// Client makes requests from the process it runs in.
type Client struct {
	Roots *x509.CertPool // trusted CAs; nil means the system's
	// Dial overrides how connections are made, for tests that map hostnames
	// to local servers.
	Dial    func(ctx context.Context, network, addr string) (net.Conn, error)
	Max     int64         // the largest body read; default DefaultMax
	Timeout time.Duration // a whole request; default 30s
}

// Response is a whole answer.
type Response struct {
	Status int
	Header http.Header
	Body   []byte
}

// Do makes one request and reads its whole answer. It never follows
// redirects.
func (c *Client) Do(ctx context.Context, method, url string, header map[string]string, body []byte) (*Response, error) {
	timeout := c.Timeout
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	max := c.Max
	if max <= 0 {
		max = DefaultMax
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	hc, done := c.client()
	defer done()
	var rd io.Reader
	if body != nil {
		rd = bytes.NewReader(body)
	}
	req, err := http.NewRequestWithContext(ctx, method, url, rd)
	if err != nil {
		return nil, err
	}
	for k, v := range header {
		if http.CanonicalHeaderKey(k) == "Host" {
			req.Host = v
			continue
		}
		req.Header.Set(k, v)
	}
	resp, err := hc.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(io.LimitReader(resp.Body, max+1))
	if err != nil {
		return nil, fmt.Errorf("%s %s: reading the answer: %v", method, url, err)
	}
	if int64(len(raw)) > max {
		return nil, fmt.Errorf("%s %s: the answer is larger than %d bytes; refusing to judge a part of it", method, url, max)
	}
	return &Response{Status: resp.StatusCode, Header: resp.Header, Body: raw}, nil
}

// Lines GETs url and passes each line of a 200 answer to each as it
// streams in, without its line ending; a last line without one is passed
// too. It holds no more of the answer than a line, so an answer of many
// megabytes costs little memory, but past max bytes it is an error, never
// a shorter answer. Any other status is an error naming it.
func (c *Client) Lines(ctx context.Context, url string, max int64, each func(line []byte)) error {
	timeout := c.Timeout
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	hc, done := c.client()
	defer done()
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return err
	}
	resp, err := hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		start, _ := io.ReadAll(io.LimitReader(resp.Body, 512))
		return fmt.Errorf("GET %s: %d %s", url, resp.StatusCode, bytes.TrimSpace(start))
	}
	r := bufio.NewReaderSize(io.LimitReader(resp.Body, max+1), 64<<10)
	var n int64
	for {
		line, err := r.ReadBytes('\n')
		n += int64(len(line))
		if n > max {
			return fmt.Errorf("GET %s: the answer is larger than %d bytes; refusing to judge a part of it", url, max)
		}
		if len(line) > 0 {
			each(bytes.TrimRight(line, "\r\n"))
		}
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return fmt.Errorf("GET %s: reading the answer: %v", url, err)
		}
	}
}

// client is an HTTP client that never reads proxy variables or follows a
// redirect, and a function that closes its connections.
func (c *Client) client() (*http.Client, func()) {
	tr := &http.Transport{
		Proxy:             nil,
		TLSClientConfig:   &tls.Config{RootCAs: c.Roots, MinVersion: tls.VersionTLS12},
		DisableKeepAlives: true,
	}
	if c.Dial != nil {
		tr.DialContext = c.Dial
	} else {
		tr.DialContext = (&net.Dialer{Timeout: 10 * time.Second}).DialContext
	}
	hc := &http.Client{Transport: tr, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	return hc, tr.CloseIdleConnections
}
