// Package signin signs a persona in as a person does, without a browser:
// Okta (password and TOTP) through Keycloak's Okta broker, with the
// authorization code flow and PKCE on the agentctl client
// (design/identity.md, "The realm"), then refreshes for one route scope at a
// time. It is a port of environments' checks/persona-sign-in.py, which B1
// ran against the Integrator org; the suites sign in this way
// (plan/local-build.md, "How the suites run locally").
//
// Okta is driven through its Identity Engine API (IDX), step by step as its
// sign-in page would: identify, password, TOTP.
package signin

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/base32"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"html"
	"io"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Redirect is the loopback redirect the agentctl client registers.
const Redirect = "http://127.0.0.1/cb"

const idxType = "application/ion+json; okta-version=1.0.0"

// Entry is a persona's credentials, as in the personas file.
type Entry struct {
	Password string `json:"password"`
	TOTP     string `json:"totp"`
}

// Tokens are a token endpoint's answer.
type Tokens struct {
	Access  string `json:"access_token"`
	Refresh string `json:"refresh_token"`
}

// Refused is a sign-in that Okta or Keycloak refused.
type Refused struct {
	By     string // okta or keycloak
	Detail string
}

func (e *Refused) Error() string { return e.By + " refused: " + e.Detail }

// Client signs personas in.
type Client struct {
	Okta     string // the Okta org's URL, such as https://<org>.okta.com
	Realm    string // the realm's issuer, such as https://keycloak.agentic.internal/realms/agentic
	ClientID string // agentctl
	Roots    *x509.CertPool
	// Transport overrides the HTTP transport, for tests.
	Transport http.RoundTripper
	// Now is the clock for TOTP codes; default time.Now.
	Now func() time.Time
	// Wait sleeps; default time.Sleep. Okta accepts each TOTP code once, so
	// a second sign-in in the same 30-second window waits for the next.
	Wait func(time.Duration)

	mu   sync.Mutex
	used map[string]int64 // per TOTP secret, the last window used
}

func (c *Client) now() time.Time {
	if c.Now != nil {
		return c.Now()
	}
	return time.Now()
}

func (c *Client) http() *http.Client {
	jar, _ := cookiejar.New(nil)
	tr := c.Transport
	if tr == nil {
		tr = &http.Transport{Proxy: nil, TLSClientConfig: &tls.Config{RootCAs: c.Roots, MinVersion: tls.VersionTLS12}}
	}
	return &http.Client{Transport: tr, Jar: jar, Timeout: 30 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
}

// TOTP is RFC 6238's code for secret at t: HMAC-SHA1, 30-second steps, six
// digits.
func TOTP(secret string, t time.Time) (string, error) {
	s := strings.ToUpper(strings.TrimSpace(secret))
	if pad := len(s) % 8; pad != 0 {
		s += strings.Repeat("=", 8-pad)
	}
	key, err := base32.StdEncoding.DecodeString(s)
	if err != nil {
		return "", fmt.Errorf("TOTP secret is not base32: %v", err)
	}
	var msg [8]byte
	binary.BigEndian.PutUint64(msg[:], uint64(t.Unix()/30))
	m := hmac.New(sha1.New, key)
	m.Write(msg[:])
	sum := m.Sum(nil)
	off := sum[len(sum)-1] & 15
	n := binary.BigEndian.Uint32(sum[off:off+4]) & 0x7fffffff
	return fmt.Sprintf("%06d", n%1000000), nil
}

// SignIn signs login in with scope (space-separated) and returns its
// tokens.
func (c *Client) SignIn(ctx context.Context, login string, e Entry, scope string) (Tokens, error) {
	hc := c.http()
	verifier := randomString(48)
	sum := sha256.Sum256([]byte(verifier))
	challenge := base64.RawURLEncoding.EncodeToString(sum[:])
	q := url.Values{"client_id": {c.ClientID}, "response_type": {"code"}, "redirect_uri": {Redirect}, "scope": {scope},
		"state": {randomString(8)}, "code_challenge": {challenge}, "code_challenge_method": {"S256"}}
	next := strings.TrimRight(c.Realm, "/") + "/protocol/openid-connect/auth?" + q.Encode()
	oktaHost := hostOf(c.Okta)
	for range 20 {
		status, loc, body, err := send(ctx, hc, http.MethodGet, next, nil, nil)
		if err != nil {
			return Tokens{}, err
		}
		if loc != "" {
			base, _ := url.Parse(next)
			ref, err := url.Parse(loc)
			if err != nil {
				return Tokens{}, fmt.Errorf("bad redirect %q: %v", loc, err)
			}
			next = base.ResolveReference(ref).String()
			if strings.HasPrefix(next, Redirect) {
				u, _ := url.Parse(next)
				if e := u.Query().Get("error"); e != "" {
					return Tokens{}, &Refused{"keycloak", e + ": " + u.Query().Get("error_description")}
				}
				return c.token(ctx, hc, url.Values{"grant_type": {"authorization_code"}, "code": {u.Query().Get("code")},
					"redirect_uri": {Redirect}, "client_id": {c.ClientID}, "code_verifier": {verifier}})
			}
			continue
		}
		if hostOf(next) == oktaHost && status == http.StatusOK {
			if next, err = c.okta(ctx, hc, body, login, e); err != nil {
				return Tokens{}, err
			}
			continue
		}
		return Tokens{}, &Refused{"keycloak", fmt.Sprintf("stopped at HTTP %d: %s", status, pageMessage(body))}
	}
	return Tokens{}, errors.New("too many redirects")
}

// Refresh exchanges a refresh token for tokens narrowed to scope. Keycloak
// rotates refresh tokens and a reused one ends the session, so callers keep
// only the latest.
func (c *Client) Refresh(ctx context.Context, refresh, scope string) (Tokens, error) {
	return c.token(ctx, c.http(), url.Values{"grant_type": {"refresh_token"}, "refresh_token": {refresh}, "client_id": {c.ClientID}, "scope": {scope}})
}

func (c *Client) token(ctx context.Context, hc *http.Client, form url.Values) (Tokens, error) {
	status, _, body, err := send(ctx, hc, http.MethodPost, strings.TrimRight(c.Realm, "/")+"/protocol/openid-connect/token",
		strings.NewReader(form.Encode()), map[string]string{"Content-Type": "application/x-www-form-urlencoded"})
	if err != nil {
		return Tokens{}, err
	}
	var t struct {
		Tokens
		Error       string `json:"error"`
		Description string `json:"error_description"`
	}
	json.Unmarshal([]byte(body), &t)
	if status != http.StatusOK || t.Access == "" {
		return Tokens{}, &Refused{"keycloak", fmt.Sprintf("token endpoint HTTP %d: %s %s", status, t.Error, t.Description)}
	}
	return t.Tokens, nil
}

var stateTokenRe = []*regexp.Regexp{regexp.MustCompile(`stateToken\s*=\s*'([^']+)'`), regexp.MustCompile(`"stateToken"\s*:\s*"([^"]+)"`)}

type idx struct {
	StateHandle string `json:"stateHandle"`
	Success     *struct {
		Href string `json:"href"`
	} `json:"success"`
	Remediation struct {
		Value []struct {
			Name string `json:"name"`
			Href string `json:"href"`
		} `json:"value"`
	} `json:"remediation"`
	Authenticators struct {
		Value []struct {
			Key string `json:"key"`
			ID  string `json:"id"`
		} `json:"value"`
	} `json:"authenticators"`
	CurrentAuthenticatorEnrollment *struct {
		Value struct {
			Key string `json:"key"`
		} `json:"value"`
	} `json:"currentAuthenticatorEnrollment"`
	CurrentAuthenticator *struct {
		Value struct {
			Key string `json:"key"`
		} `json:"value"`
	} `json:"currentAuthenticator"`
	Messages *struct {
		Value []struct {
			Message string `json:"message"`
		} `json:"value"`
	} `json:"messages"`
}

func (r idx) messages() string {
	if r.Messages == nil {
		return ""
	}
	var out []string
	for _, m := range r.Messages.Value {
		out = append(out, m.Message)
	}
	return strings.Join(out, "; ")
}

// okta drives Okta's sign-in page's IDX steps and returns the success
// redirect.
func (c *Client) okta(ctx context.Context, hc *http.Client, page, login string, e Entry) (string, error) {
	var state string
	for _, re := range stateTokenRe {
		if m := re.FindStringSubmatch(page); m != nil {
			state = unescapeJS(m[1])
			break
		}
	}
	if state == "" {
		return "", &Refused{"okta", "no stateToken on the sign-in page"}
	}
	okta := strings.TrimRight(c.Okta, "/")
	r, status, err := c.idx(ctx, hc, okta+"/idp/idx/introspect", map[string]any{"stateToken": state})
	if err != nil {
		return "", err
	}
	done := map[string]bool{}
	for range 12 {
		if r.Success != nil {
			return r.Success.Href, nil
		}
		rem := map[string]string{}
		for _, v := range r.Remediation.Value {
			rem[v.Name] = v.Href
		}
		auths := map[string]string{}
		for _, a := range r.Authenticators.Value {
			auths[a.Key] = a.ID
		}
		current := ""
		if r.CurrentAuthenticatorEnrollment != nil {
			current = r.CurrentAuthenticatorEnrollment.Value.Key
		} else if r.CurrentAuthenticator != nil {
			current = r.CurrentAuthenticator.Value.Key
		}
		sh := r.StateHandle
		var body map[string]any
		var href string
		switch {
		case rem["identify"] != "":
			href, body = rem["identify"], map[string]any{"identifier": login, "stateHandle": sh}
		case rem["challenge-authenticator"] != "" && current == "okta_password":
			href, body = rem["challenge-authenticator"], map[string]any{"credentials": map[string]any{"passcode": e.Password}, "stateHandle": sh}
			done["okta_password"] = true
		case rem["challenge-authenticator"] != "" && current == "google_otp":
			code, err := c.code(e.TOTP)
			if err != nil {
				return "", err
			}
			href, body = rem["challenge-authenticator"], map[string]any{"credentials": map[string]any{"passcode": code}, "stateHandle": sh}
			done["google_otp"] = true
		case rem["select-authenticator-authenticate"] != "":
			// The password first, then TOTP: the two factors the app's policy asks.
			want := "google_otp"
			if _, ok := auths["okta_password"]; ok && !done["okta_password"] {
				want = "okta_password"
			}
			id, ok := auths[want]
			if !ok {
				return "", &Refused{"okta", fmt.Sprintf("no usable authenticator among %v: %s", keys(auths), r.messages())}
			}
			href, body = rem["select-authenticator-authenticate"], map[string]any{"authenticator": map[string]any{"id": id}, "stateHandle": sh}
		default:
			return "", &Refused{"okta", fmt.Sprintf("stopped at HTTP %d with remediation %v: %s", status, keys(rem), r.messages())}
		}
		if r, status, err = c.idx(ctx, hc, href, body); err != nil {
			return "", err
		}
		if status >= 400 && len(r.Remediation.Value) == 0 {
			return "", &Refused{"okta", fmt.Sprintf("HTTP %d: %s", status, r.messages())}
		}
	}
	return "", &Refused{"okta", "too many steps"}
}

// code returns the current TOTP code, waiting for the next window when
// this secret's code for the current one was already used.
func (c *Client) code(secret string) (string, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.used == nil {
		c.used = map[string]int64{}
	}
	now := c.now()
	window := now.Unix() / 30
	if c.used[secret] == window {
		wait := time.Duration(30-now.Unix()%30+1) * time.Second
		if c.Wait != nil {
			c.Wait(wait)
		} else {
			time.Sleep(wait)
		}
		now = c.now()
		window = now.Unix() / 30
	}
	c.used[secret] = window
	return TOTP(secret, now)
}

func (c *Client) idx(ctx context.Context, hc *http.Client, href string, body map[string]any) (idx, int, error) {
	raw, _ := json.Marshal(body)
	status, _, text, err := send(ctx, hc, http.MethodPost, href, strings.NewReader(string(raw)), map[string]string{"Content-Type": idxType, "Accept": idxType})
	if err != nil {
		return idx{}, 0, err
	}
	var r idx
	json.Unmarshal([]byte(text), &r)
	return r, status, nil
}

func send(ctx context.Context, hc *http.Client, method, u string, body io.Reader, h map[string]string) (int, string, string, error) {
	req, err := http.NewRequestWithContext(ctx, method, u, body)
	if err != nil {
		return 0, "", "", err
	}
	for k, v := range h {
		req.Header.Set(k, v)
	}
	resp, err := hc.Do(req)
	if err != nil {
		return 0, "", "", err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	return resp.StatusCode, resp.Header.Get("Location"), string(raw), nil
}

var errorRe = []*regexp.Regexp{regexp.MustCompile(`(?s)id="kc-error-message"[^>]*>\s*<p[^>]*>(.*?)</p>`), regexp.MustCompile(`(?s)<title>(.*?)</title>`)}

func pageMessage(body string) string {
	for _, re := range errorRe {
		if m := re.FindStringSubmatch(body); m != nil {
			return html.UnescapeString(strings.TrimSpace(m[1]))
		}
	}
	if len(body) > 200 {
		body = body[:200]
	}
	return body
}

// unescapeJS undoes the \xNN and \uNNNN escapes Okta's page writes into a
// JavaScript string.
func unescapeJS(s string) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		if s[i] == '\\' && i+1 < len(s) {
			switch s[i+1] {
			case 'x':
				if i+3 < len(s) {
					if v, err := strconv.ParseUint(s[i+2:i+4], 16, 8); err == nil {
						b.WriteByte(byte(v))
						i += 3
						continue
					}
				}
			case 'u':
				if i+5 < len(s) {
					if v, err := strconv.ParseUint(s[i+2:i+6], 16, 16); err == nil {
						b.WriteRune(rune(v))
						i += 5
						continue
					}
				}
			}
		}
		b.WriteByte(s[i])
	}
	return b.String()
}

func hostOf(u string) string {
	p, err := url.Parse(u)
	if err != nil {
		return ""
	}
	return p.Host
}

func keys(m map[string]string) []string {
	var out []string
	for k := range m {
		out = append(out, k)
	}
	return out
}

func randomString(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)[:n]
}
