package signin

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"
)

// RFC 6238, appendix B: the SHA-1 secret "12345678901234567890" gives
// 94287082 at T = 59; six digits keep 287082.
func TestTOTP(t *testing.T) {
	code, err := TOTP("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", time.Unix(59, 0))
	if err != nil || code != "287082" {
		t.Errorf("got %q, %v", code, err)
	}
}

type script struct {
	t        *testing.T
	login    string
	password string
	secret   string
	now      time.Time
	steps    []string
	refused  bool // refuse the password
}

func (s *script) RoundTrip(r *http.Request) (*http.Response, error) {
	rec := httptest.NewRecorder()
	var body []byte
	if r.Body != nil {
		body, _ = io.ReadAll(r.Body)
	}
	var in map[string]any
	json.Unmarshal(body, &in)
	idx := func(v any) { rec.Header().Set("Content-Type", idxType); json.NewEncoder(rec).Encode(v) }
	rem := func(name string) map[string]any {
		return map[string]any{"value": []any{map[string]any{"name": name, "href": "https://okta.test/idp/idx/" + name}}}
	}
	auths := map[string]any{"value": []any{map[string]any{"key": "okta_password", "id": "p1"}, map[string]any{"key": "google_otp", "id": "g1"}}}
	path := r.URL.Host + r.URL.Path
	s.steps = append(s.steps, path)
	switch path {
	case "kc.test/realms/agentic/protocol/openid-connect/auth":
		if r.URL.Query().Get("code_challenge_method") != "S256" || r.URL.Query().Get("scope") != "openid models" {
			s.t.Errorf("authorize request: %v", r.URL.Query())
		}
		rec.Header().Set("Location", "https://okta.test/oauth2/v1/authorize?client_id=broker")
		rec.WriteHeader(302)
	case "okta.test/oauth2/v1/authorize":
		io.WriteString(rec, `<script>var stateToken = 'st\x2D1';</script>`)
	case "okta.test/idp/idx/introspect":
		if in["stateToken"] != "st-1" {
			s.t.Errorf("stateToken %v", in["stateToken"])
		}
		idx(map[string]any{"stateHandle": "sh", "remediation": rem("identify")})
	case "okta.test/idp/idx/identify":
		if in["identifier"] != s.login {
			s.t.Errorf("identifier %v", in["identifier"])
		}
		idx(map[string]any{"stateHandle": "sh", "remediation": rem("select-authenticator-authenticate"), "authenticators": auths})
	case "okta.test/idp/idx/select-authenticator-authenticate":
		key := map[string]string{"p1": "okta_password", "g1": "google_otp"}[in["authenticator"].(map[string]any)["id"].(string)]
		idx(map[string]any{"stateHandle": "sh", "remediation": rem("challenge-authenticator"), "currentAuthenticatorEnrollment": map[string]any{"value": map[string]any{"key": key}}})
	case "okta.test/idp/idx/challenge-authenticator":
		pass := in["credentials"].(map[string]any)["passcode"]
		if pass == s.password {
			if s.refused {
				rec.WriteHeader(401)
				idx(map[string]any{"messages": map[string]any{"value": []any{map[string]any{"message": "Password is incorrect"}}}})
				return rec.Result(), nil
			}
			idx(map[string]any{"stateHandle": "sh", "remediation": rem("select-authenticator-authenticate"), "authenticators": auths})
			return rec.Result(), nil
		}
		want, _ := TOTP(s.secret, s.now)
		if pass != want {
			s.t.Errorf("passcode %v, want the password or %s", pass, want)
		}
		idx(map[string]any{"success": map[string]any{"href": "https://okta.test/login/token/redirect?stateToken=st-1"}})
	case "okta.test/login/token/redirect":
		rec.Header().Set("Location", "https://kc.test/realms/agentic/broker/okta/endpoint?code=okta")
		rec.WriteHeader(302)
	case "kc.test/realms/agentic/broker/okta/endpoint":
		rec.Header().Set("Location", Redirect+"?code=kc-code&state=x")
		rec.WriteHeader(302)
	case "kc.test/realms/agentic/protocol/openid-connect/token":
		f, _ := url.ParseQuery(string(body))
		switch f.Get("grant_type") {
		case "authorization_code":
			if f.Get("code") != "kc-code" || f.Get("code_verifier") == "" {
				s.t.Errorf("token request: %v", f)
			}
			json.NewEncoder(rec).Encode(map[string]string{"access_token": "wide", "refresh_token": "r1"})
		case "refresh_token":
			if f.Get("refresh_token") != "r1" || f.Get("scope") != "openid models" {
				rec.WriteHeader(400)
				json.NewEncoder(rec).Encode(map[string]string{"error": "invalid_grant"})
				return rec.Result(), nil
			}
			json.NewEncoder(rec).Encode(map[string]string{"access_token": "narrow", "refresh_token": "r2"})
		}
	default:
		rec.WriteHeader(404)
	}
	return rec.Result(), nil
}

func TestSignIn(t *testing.T) {
	now := time.Unix(1_800_000_000, 0)
	s := &script{t: t, login: "agentic.developer@example.com", password: "pw", secret: "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", now: now}
	c := &Client{Okta: "https://okta.test", Realm: "https://kc.test/realms/agentic", ClientID: "agentctl", Transport: s, Now: func() time.Time { return now }}
	tok, err := c.SignIn(context.Background(), s.login, Entry{Password: "pw", TOTP: s.secret}, "openid models")
	if err != nil || tok.Access != "wide" || tok.Refresh != "r1" {
		t.Fatalf("sign-in: %+v %v\nsteps %v", tok, err, s.steps)
	}
	got, err := c.Refresh(context.Background(), tok.Refresh, "openid models")
	if err != nil || got.Access != "narrow" || got.Refresh != "r2" {
		t.Errorf("refresh: %+v %v", got, err)
	}
	if _, err := c.Refresh(context.Background(), "r1-reused", "openid models"); err == nil || !strings.Contains(err.Error(), "invalid_grant") {
		t.Errorf("a refused refresh: %v", err)
	}
	// A second sign-in in the same window waits for the next code.
	var waited time.Duration
	c.Wait = func(d time.Duration) { waited = d; now = now.Add(d); s.now = now }
	if _, err := c.SignIn(context.Background(), s.login, Entry{Password: "pw", TOTP: s.secret}, "openid models"); err != nil {
		t.Fatalf("second sign-in: %v", err)
	}
	if waited == 0 {
		t.Errorf("the second sign-in reused the window's TOTP code")
	}
}

func TestRefused(t *testing.T) {
	s := &script{t: t, login: "agentic.developer@example.com", password: "pw", secret: "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", now: time.Now(), refused: true}
	c := &Client{Okta: "https://okta.test", Realm: "https://kc.test/realms/agentic", ClientID: "agentctl", Transport: s}
	_, err := c.SignIn(context.Background(), s.login, Entry{Password: "pw", TOTP: s.secret}, "openid models")
	var r *Refused
	if err == nil || !strings.Contains(err.Error(), "Password is incorrect") {
		t.Errorf("want Okta's refusal, got %v (%T)", err, r)
	}
}
