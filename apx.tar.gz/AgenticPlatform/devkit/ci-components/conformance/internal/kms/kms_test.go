package kms

import (
	"context"
	"encoding/asn1"
	"encoding/json"
	"math/big"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestSign(t *testing.T) {
	c := &Client{Region: "us-east-1", AccessKeyID: "AKID", SecretAccessKey: "secret",
		Now: func() time.Time { return time.Date(2026, 11, 17, 12, 0, 0, 0, time.UTC) }}
	req, _ := http.NewRequest(http.MethodPost, "http://floci:4566/", nil)
	req.Header.Set("Content-Type", "application/x-amz-json-1.1")
	req.Header.Set("X-Amz-Target", "TrentService.DescribeKey")
	c.sign(req, "floci:4566", []byte(`{"KeyId":"alias/x"}`))
	auth := req.Header.Get("Authorization")
	if !strings.HasPrefix(auth, "AWS4-HMAC-SHA256 Credential=AKID/20261117/us-east-1/kms/aws4_request, SignedHeaders=content-type;host;x-amz-date;x-amz-target, Signature=") ||
		req.Header.Get("X-Amz-Date") != "20261117T120000Z" {
		t.Fatalf("headers %v", req.Header)
	}
	again, _ := http.NewRequest(http.MethodPost, "http://floci:4566/", nil)
	again.Header = req.Header.Clone()
	c.sign(again, "floci:4566", []byte(`{"KeyId":"alias/y"}`))
	if again.Header.Get("Authorization") == auth {
		t.Error("another body signs the same")
	}
}

type fakeKMS struct {
	aliases map[string]string
	keys    map[string][2]string // spec, usage
	calls   []string
}

func (f *fakeKMS) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	op := strings.TrimPrefix(r.Header.Get("X-Amz-Target"), "TrentService.")
	f.calls = append(f.calls, op)
	if !strings.HasPrefix(r.Header.Get("Authorization"), "AWS4-HMAC-SHA256 ") {
		w.WriteHeader(400)
		return
	}
	var in map[string]string
	json.NewDecoder(r.Body).Decode(&in)
	switch op {
	case "DescribeKey":
		id, ok := f.aliases[in["KeyId"]]
		if !ok {
			w.WriteHeader(400)
			w.Write([]byte(`{"__type":"com.amazonaws.kms#NotFoundException","message":"no such alias"}`))
			return
		}
		k := f.keys[id]
		json.NewEncoder(w).Encode(map[string]any{"KeyMetadata": map[string]string{"KeyId": id, "KeySpec": k[0], "KeyUsage": k[1], "KeyState": "Enabled"}})
	case "CreateKey":
		id := "key-" + string(rune('a'+len(f.keys)))
		f.keys[id] = [2]string{in["KeySpec"], in["KeyUsage"]}
		json.NewEncoder(w).Encode(map[string]any{"KeyMetadata": map[string]string{"KeyId": id}})
	case "CreateAlias":
		f.aliases[in["AliasName"]] = in["TargetKeyId"]
		w.Write([]byte(`{}`))
	}
}

func TestEnsureSigningAlias(t *testing.T) {
	f := &fakeKMS{aliases: map[string]string{"alias/rsa": "k0"}, keys: map[string][2]string{"k0": {"RSA_2048", "SIGN_VERIFY"}}}
	srv := httptest.NewServer(f)
	defer srv.Close()
	c := &Client{Endpoint: srv.URL, Region: "us-east-1", AccessKeyID: "test", SecretAccessKey: "test"}
	ctx := context.Background()
	id, created, err := c.EnsureSigningAlias(ctx, "alias/conformance/sts-signing", "test")
	if err != nil || !created || f.aliases["alias/conformance/sts-signing"] != id || f.keys[id] != [2]string{"ECC_NIST_P256", "SIGN_VERIFY"} {
		t.Fatalf("first: %s %v %v %v", id, created, err, f.keys)
	}
	again, created, err := c.EnsureSigningAlias(ctx, "alias/conformance/sts-signing", "test")
	if err != nil || created || again != id {
		t.Errorf("second: %s %v %v", again, created, err)
	}
	if _, _, err := c.EnsureSigningAlias(ctx, "alias/rsa", "test"); err == nil || !strings.Contains(err.Error(), "not an enabled ECC_NIST_P256") {
		t.Errorf("an alias of another kind: %v", err)
	}
	if _, _, err := c.EnsureSigningAlias(ctx, "conformance", "test"); err == nil {
		t.Error("a name that is no alias was taken")
	}
}

func TestDERToJOSE(t *testing.T) {
	der, _ := asn1.Marshal(struct{ R, S *big.Int }{big.NewInt(1), big.NewInt(258)})
	got, err := derToJOSE(der)
	if err != nil || len(got) != 64 || got[31] != 1 || got[62] != 1 || got[63] != 2 {
		t.Fatalf("%x %v", got, err)
	}
	if _, err := derToJOSE([]byte{1, 2, 3}); err == nil {
		t.Error("garbage converted")
	}
}
