// Package kms is the little of AWS KMS the contract stage needs, on the
// standard library: it makes sure the alias the stage's STS signs through
// names an ECC P-256 signing key, creating both when absent, as the
// interop suite's floci-kms.sh does for its own alias (decision D26: the
// contract stage's key lives outside OpenTofu). Requests are signed with
// Signature Version 4, so the same calls work against AWS.
package kms

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/asn1"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// Client calls KMS's JSON API.
type Client struct {
	Endpoint string // such as http://floci:4566, or https://kms.<region>.amazonaws.com
	Region   string
	// Static credentials; SessionToken may be empty.
	AccessKeyID, SecretAccessKey, SessionToken string
	HTTP                                       *http.Client
	Now                                        func() time.Time
}

// Error is KMS's error answer.
type Error struct {
	Status  int
	Type    string `json:"__type"`
	Message string `json:"message"`
}

func (e *Error) Error() string { return fmt.Sprintf("KMS %d %s: %s", e.Status, e.Type, e.Message) }

// NotFound reports whether err is KMS's NotFoundException.
func NotFound(err error) bool {
	e, ok := err.(*Error)
	return ok && strings.HasSuffix(e.Type, "NotFoundException")
}

func (c *Client) call(ctx context.Context, op string, in, out any) error {
	body, err := json.Marshal(in)
	if err != nil {
		return err
	}
	u, err := url.Parse(c.Endpoint)
	if err != nil || u.Host == "" {
		return fmt.Errorf("KMS endpoint %q is not a URL", c.Endpoint)
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(c.Endpoint, "/")+"/", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-amz-json-1.1")
	req.Header.Set("X-Amz-Target", "TrentService."+op)
	c.sign(req, u.Host, body)
	hc := c.HTTP
	if hc == nil {
		hc = &http.Client{Transport: &http.Transport{Proxy: nil}, Timeout: 30 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK {
		e := &Error{Status: resp.StatusCode}
		json.Unmarshal(raw, e)
		if i := strings.LastIndex(e.Type, "#"); i >= 0 {
			e.Type = e.Type[i+1:]
		}
		return e
	}
	if out != nil {
		return json.Unmarshal(raw, out)
	}
	return nil
}

// sign adds Signature Version 4 headers for service kms.
func (c *Client) sign(req *http.Request, host string, body []byte) {
	now := time.Now
	if c.Now != nil {
		now = c.Now
	}
	t := now().UTC()
	amzDate, day := t.Format("20060102T150405Z"), t.Format("20060102")
	payload := sha256.Sum256(body)
	req.Header.Set("X-Amz-Date", amzDate)
	req.Header.Set("Host", host)
	if c.SessionToken != "" {
		req.Header.Set("X-Amz-Security-Token", c.SessionToken)
	}
	names := []string{"content-type", "host", "x-amz-date", "x-amz-target"}
	if c.SessionToken != "" {
		names = []string{"content-type", "host", "x-amz-date", "x-amz-security-token", "x-amz-target"}
	}
	var canonHeaders strings.Builder
	for _, n := range names {
		v := req.Header.Get(n)
		if n == "host" {
			v = host
		}
		canonHeaders.WriteString(n + ":" + strings.TrimSpace(v) + "\n")
	}
	signed := strings.Join(names, ";")
	canonical := strings.Join([]string{"POST", "/", "", canonHeaders.String(), signed, hex.EncodeToString(payload[:])}, "\n")
	scope := day + "/" + c.Region + "/kms/aws4_request"
	cr := sha256.Sum256([]byte(canonical))
	toSign := "AWS4-HMAC-SHA256\n" + amzDate + "\n" + scope + "\n" + hex.EncodeToString(cr[:])
	key := mac([]byte("AWS4"+c.SecretAccessKey), day)
	key = mac(key, c.Region)
	key = mac(key, "kms")
	key = mac(key, "aws4_request")
	sig := hex.EncodeToString(mac(key, toSign))
	req.Header.Set("Authorization", "AWS4-HMAC-SHA256 Credential="+c.AccessKeyID+"/"+scope+", SignedHeaders="+signed+", Signature="+sig)
}

func mac(key []byte, s string) []byte {
	h := hmac.New(sha256.New, key)
	h.Write([]byte(s))
	return h.Sum(nil)
}

type keyMetadata struct {
	KeyMetadata struct {
		KeyID    string `json:"KeyId"`
		KeySpec  string `json:"KeySpec"`
		KeyUsage string `json:"KeyUsage"`
		KeyState string `json:"KeyState"`
	} `json:"KeyMetadata"`
}

// EnsureSigningAlias makes alias name an enabled ECC_NIST_P256 SIGN_VERIFY
// key, creating the key and the alias when the alias does not exist. It
// returns the key's ID and whether it created them. An alias that names a
// key of another kind is an error, never moved.
func (c *Client) EnsureSigningAlias(ctx context.Context, alias, description string) (string, bool, error) {
	if !strings.HasPrefix(alias, "alias/") {
		return "", false, fmt.Errorf("%q is not a KMS alias", alias)
	}
	var m keyMetadata
	err := c.call(ctx, "DescribeKey", map[string]string{"KeyId": alias}, &m)
	switch {
	case err == nil:
		k := m.KeyMetadata
		if k.KeySpec != "ECC_NIST_P256" || k.KeyUsage != "SIGN_VERIFY" || (k.KeyState != "" && k.KeyState != "Enabled") {
			return "", false, fmt.Errorf("%s names key %s (%s, %s, %s), not an enabled ECC_NIST_P256 signing key", alias, k.KeyID, k.KeySpec, k.KeyUsage, k.KeyState)
		}
		return k.KeyID, false, nil
	case !NotFound(err):
		return "", false, err
	}
	if err := c.call(ctx, "CreateKey", map[string]string{"KeySpec": "ECC_NIST_P256", "KeyUsage": "SIGN_VERIFY", "Description": description}, &m); err != nil {
		return "", false, err
	}
	id := m.KeyMetadata.KeyID
	if err := c.call(ctx, "CreateAlias", map[string]string{"AliasName": alias, "TargetKeyId": id}, nil); err != nil {
		return "", false, fmt.Errorf("created key %s, but not %s: %w", id, alias, err)
	}
	return id, true, nil
}

// SignDigest signs a SHA-256 digest with the key an alias or ID names,
// ECDSA_SHA_256, and returns the signature as JOSE's ES256 form: R and S,
// 32 bytes each. The contract stage forges chain tokens with it that only
// the STS's own key can sign: expired, typed otherwise, or for two
// audiences.
func (c *Client) SignDigest(ctx context.Context, keyID string, digest []byte) ([]byte, error) {
	var out struct {
		Signature []byte `json:"Signature"`
	}
	in := map[string]any{"KeyId": keyID, "Message": digest, "MessageType": "DIGEST", "SigningAlgorithm": "ECDSA_SHA_256"}
	if err := c.call(ctx, "Sign", in, &out); err != nil {
		return nil, err
	}
	return derToJOSE(out.Signature)
}

// derToJOSE converts an ASN.1 DER ECDSA signature to R||S.
func derToJOSE(der []byte) ([]byte, error) {
	var sig struct{ R, S *big.Int }
	if rest, err := asn1.Unmarshal(der, &sig); err != nil || len(rest) > 0 {
		return nil, fmt.Errorf("KMS signature is not DER: %v", err)
	}
	out := make([]byte, 64)
	sig.R.FillBytes(out[:32])
	sig.S.FillBytes(out[32:])
	return out, nil
}
