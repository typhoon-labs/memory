package kube

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestDryRunCreate(t *testing.T) {
	var seen *http.Request
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seen = r
		if r.URL.Path == "/apis/gateway.networking.k8s.io/v1/namespaces/conformance/httproutes" {
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]any{"kind": "Status", "reason": "BadRequest", "message": `admission webhook "x" denied the request: route-claims: no`})
			return
		}
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte(`{"kind":"NetworkPolicy"}`))
	}))
	defer ts.Close()
	tok := filepath.Join(t.TempDir(), "token")
	os.WriteFile(tok, []byte("t0k\n"), 0o600)
	c := &Client{Server: ts.URL, TokenFile: tok, Impersonate: "system:serviceaccount:ci-deploy:deploy-job", HTTP: ts.Client()}
	st, err := c.DryRunCreate(context.Background(), "httproutes", map[string]any{"apiVersion": "gateway.networking.k8s.io/v1", "kind": "HTTPRoute",
		"metadata": map[string]any{"name": "r", "namespace": "conformance"}})
	if err != nil || st.Admitted() || st.Reason != "BadRequest" || st.Message == "" {
		t.Errorf("a denial: %+v %v", st, err)
	}
	if seen.URL.Query().Get("dryRun") != "All" || seen.Header.Get("Authorization") != "Bearer t0k" || seen.Header.Get("Impersonate-User") == "" {
		t.Errorf("the request: %v %v", seen.URL, seen.Header)
	}
	st, _ = c.DryRunCreate(context.Background(), "networkpolicies", map[string]any{"apiVersion": "networking.k8s.io/v1", "metadata": map[string]any{"namespace": "conformance"}})
	if !st.Admitted() {
		t.Errorf("an admission: %+v", st)
	}
	if got := Path("v1", "configmaps", "x"); got != "/api/v1/namespaces/x/configmaps" {
		t.Errorf("core path %s", got)
	}
	if got := Path("apiextensions.k8s.io/v1", "customresourcedefinitions", ""); got != "/apis/apiextensions.k8s.io/v1/customresourcedefinitions" {
		t.Errorf("cluster path %s", got)
	}
}

func TestLogs(t *testing.T) {
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/api/v1/namespaces/gateway/pods":
			if r.URL.Query().Get("labelSelector") != "app=gw" {
				t.Errorf("selector %v", r.URL.Query())
			}
			w.Write([]byte(`{"items":[{"metadata":{"name":"p1"}}]}`))
		case "/api/v1/namespaces/gateway/pods/p1/log":
			if r.URL.Query().Get("container") != "proxy" || r.URL.Query().Get("sinceTime") == "" || r.URL.Query().Get("timestamps") != "true" {
				t.Errorf("log query %v", r.URL.Query())
			}
			w.Write([]byte("2026-11-17T20:06:32.965458183Z {\"a\":1}\n\n2026-11-17T20:06:33Z {\"b\": 2}\n"))
		}
	}))
	defer ts.Close()
	lines, err := (&Client{Server: ts.URL, HTTP: ts.Client()}).Logs(context.Background(), "gateway", "app=gw", "proxy", time.Now())
	if err != nil || len(lines) != 2 {
		t.Fatalf("lines %v %v", lines, err)
	}
	want := time.Date(2026, 11, 17, 20, 6, 32, 965458183, time.UTC)
	if lines[0].Pod != "p1" || !lines[0].Time.Equal(want) || lines[0].Text != `{"a":1}` || lines[1].Text != `{"b": 2}` {
		t.Errorf("lines %+v", lines)
	}
}

func TestPodsAndDelete(t *testing.T) {
	var deleted string
	ts := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodGet && r.URL.Path == "/api/v1/namespaces/ns/pods" && r.URL.Query().Get("labelSelector") == "app=a":
			w.Write([]byte(`{"items": [
				{"metadata": {"name": "a-1"}, "status": {"conditions": [{"type": "Ready", "status": "True"}]}},
				{"metadata": {"name": "a-0", "deletionTimestamp": "2026-11-18T00:00:00Z"}, "status": {"conditions": [{"type": "Ready", "status": "False"}]}}]}`))
		case r.Method == http.MethodDelete && r.URL.Path == "/api/v1/namespaces/ns/pods/a-1" && r.Header.Get("Authorization") == "Bearer tok":
			deleted = "a-1"
			w.Write([]byte(`{}`))
		default:
			http.Error(w, "no", http.StatusForbidden)
		}
	}))
	defer ts.Close()
	dir := t.TempDir()
	os.WriteFile(dir+"/token", []byte("tok\n"), 0o600)
	c := &Client{Server: ts.URL, TokenFile: dir + "/token", HTTP: ts.Client()}
	pods, err := c.Pods(context.Background(), "ns", "app=a")
	if err != nil || len(pods) != 2 || !pods[0].Ready || pods[0].Deleting || pods[1].Ready || !pods[1].Deleting {
		t.Fatalf("%+v %v", pods, err)
	}
	if err := c.DeletePod(context.Background(), "ns", "a-1"); err != nil || deleted != "a-1" {
		t.Errorf("delete: %v %q", err, deleted)
	}
	if err := c.DeletePod(context.Background(), "ns", "other"); err == nil {
		t.Error("a refused delete passed")
	}
}
