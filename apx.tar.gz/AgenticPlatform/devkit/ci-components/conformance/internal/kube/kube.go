// Package kube is the one Kubernetes API call the bypass suite makes: a
// server-side dry run of creating an object (design/conformance.md, the
// bypass suite: "each admission rule, by a server-side dry run"), which
// runs every admission webhook and writes nothing. Standard library only;
// in a pod it uses the pod's service account, elsewhere a server, a token
// file and a CA file.
package kube

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

const saDir = "/var/run/secrets/kubernetes.io/serviceaccount"

// maxRead bounds one answer: a pod's log since a time, or a pod list.
const maxRead = 64 << 20

// Client calls one API server.
type Client struct {
	Server      string // https://host:port
	TokenFile   string // re-read on every call: projected tokens rotate
	Impersonate string // a user to act as, such as system:serviceaccount:ci-deploy:deploy-job; "" for none
	HTTP        *http.Client
}

// New returns a client for server, or the in-cluster API server when
// server is "".
func New(server, tokenFile, caFile string) (*Client, error) {
	if server == "" {
		host, port := os.Getenv("KUBERNETES_SERVICE_HOST"), os.Getenv("KUBERNETES_SERVICE_PORT")
		if host == "" {
			return nil, fmt.Errorf("not in a pod: set kube.server, kube.token_file and kube.ca_file")
		}
		server = "https://" + net.JoinHostPort(host, port)
		if tokenFile == "" {
			tokenFile = saDir + "/token"
		}
		if caFile == "" {
			caFile = saDir + "/ca.crt"
		}
	}
	roots := x509.NewCertPool()
	if caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return nil, err
		}
		roots.AppendCertsFromPEM(pem)
	}
	return &Client{Server: strings.TrimRight(server, "/"), TokenFile: tokenFile, HTTP: &http.Client{Timeout: 30 * time.Second,
		Transport: &http.Transport{Proxy: nil, TLSClientConfig: &tls.Config{RootCAs: roots, MinVersion: tls.VersionTLS12}}}}, nil
}

// Status is the API server's answer to a create.
type Status struct {
	HTTP    int    // the response's status
	Reason  string // the Status object's reason, such as Forbidden or Invalid
	Message string
}

// Admitted reports whether the dry run created the object.
func (s Status) Admitted() bool { return s.HTTP == http.StatusOK || s.HTTP == http.StatusCreated }

func (s Status) String() string {
	if s.Admitted() {
		return fmt.Sprintf("admitted (HTTP %d)", s.HTTP)
	}
	return fmt.Sprintf("HTTP %d %s: %s", s.HTTP, s.Reason, s.Message)
}

// Path is the collection URL path of a kind: /api/v1 for the core group,
// /apis/<group>/<version> otherwise, then the namespace if any.
func Path(apiVersion, plural, namespace string) string {
	base := "/apis/" + apiVersion
	if !strings.Contains(apiVersion, "/") {
		base = "/api/" + apiVersion
	}
	if namespace != "" {
		return base + "/namespaces/" + namespace + "/" + plural
	}
	return base + "/" + plural
}

// DryRunCreate asks the API server to create obj with dryRun=All.
func (c *Client) DryRunCreate(ctx context.Context, plural string, obj map[string]any) (Status, error) {
	apiVersion, _ := obj["apiVersion"].(string)
	meta, _ := obj["metadata"].(map[string]any)
	ns, _ := meta["namespace"].(string)
	body, err := json.Marshal(obj)
	if err != nil {
		return Status{}, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.Server+Path(apiVersion, plural, ns)+"?dryRun=All&fieldManager=platform-conformance", strings.NewReader(string(body)))
	if err != nil {
		return Status{}, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	if c.TokenFile != "" {
		tok, err := os.ReadFile(c.TokenFile)
		if err != nil {
			return Status{}, err
		}
		req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(string(tok)))
	}
	if c.Impersonate != "" {
		req.Header.Set("Impersonate-User", c.Impersonate)
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return Status{}, err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	st := Status{HTTP: resp.StatusCode}
	var s struct {
		Kind    string `json:"kind"`
		Reason  string `json:"reason"`
		Message string `json:"message"`
	}
	if json.Unmarshal(raw, &s) == nil && s.Kind == "Status" {
		st.Reason, st.Message = s.Reason, s.Message
	}
	return st, nil
}

// LogLine is one line of a pod's log, with the time the kubelet stamped
// on it as it read it from the container.
type LogLine struct {
	Pod  string
	Time time.Time // zero if the line carried no stamp
	Text string
}

// Logs returns the log lines since a time of the pods selector picks in
// namespace, from one container ("" for the pod's only one), each with its
// pod and its kubelet timestamp. The telemetry cases read what reached the
// Dynatrace and SIEM stand-ins this way, as B1's suite read the STS's
// audit records. A log larger than the client reads is an error, never a
// shorter log. The kubelet serves only a container's current log file:
// lines it has rotated away are not among them, whatever since says.
func (c *Client) Logs(ctx context.Context, namespace, selector, container string, since time.Time) ([]LogLine, error) {
	var pods struct {
		Items []struct {
			Metadata struct {
				Name string `json:"name"`
			} `json:"metadata"`
		} `json:"items"`
	}
	if err := c.get(ctx, "/api/v1/namespaces/"+namespace+"/pods?labelSelector="+url.QueryEscape(selector), &pods, nil); err != nil {
		return nil, err
	}
	var lines []LogLine
	for _, p := range pods.Items {
		q := url.Values{"sinceTime": {since.UTC().Format(time.RFC3339)}, "timestamps": {"true"}}
		if container != "" {
			q.Set("container", container)
		}
		var text string
		if err := c.get(ctx, "/api/v1/namespaces/"+namespace+"/pods/"+p.Metadata.Name+"/log?"+q.Encode(), nil, &text); err != nil {
			return nil, err
		}
		for _, l := range strings.Split(text, "\n") {
			if strings.TrimSpace(l) == "" {
				continue
			}
			line := LogLine{Pod: p.Metadata.Name, Text: l}
			if stamp, rest, ok := strings.Cut(l, " "); ok {
				if t, err := time.Parse(time.RFC3339Nano, stamp); err == nil {
					line.Time, line.Text = t, rest
				}
			}
			lines = append(lines, line)
		}
	}
	return lines, nil
}

func (c *Client) get(ctx context.Context, path string, into any, text *string) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, c.Server+path, nil)
	if err != nil {
		return err
	}
	if c.TokenFile != "" {
		tok, err := os.ReadFile(c.TokenFile)
		if err != nil {
			return err
		}
		req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(string(tok)))
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, maxRead+1))
	if len(raw) > maxRead {
		// A log cut short could hide what a case looks for in it.
		return fmt.Errorf("GET %s: more than %d bytes; refusing to judge a part of it", path, maxRead)
	}
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("GET %s: HTTP %d: %s", path, resp.StatusCode, strings.TrimSpace(string(raw)))
	}
	if text != nil {
		*text = string(raw)
		return nil
	}
	return json.Unmarshal(raw, into)
}

// Get reads an API path's JSON answer into into, such as a list of pods
// with their specs.
func (c *Client) Get(ctx context.Context, path string, into any) error {
	return c.get(ctx, path, into, nil)
}

// Pod is what the integration stage reads of a pod.
type Pod struct {
	Name     string
	Ready    bool
	Deleting bool
}

// Pods lists the pods selector picks in namespace.
func (c *Client) Pods(ctx context.Context, namespace, selector string) ([]Pod, error) {
	var list struct {
		Items []struct {
			Metadata struct {
				Name              string  `json:"name"`
				DeletionTimestamp *string `json:"deletionTimestamp"`
			} `json:"metadata"`
			Status struct {
				Conditions []struct {
					Type   string `json:"type"`
					Status string `json:"status"`
				} `json:"conditions"`
			} `json:"status"`
		} `json:"items"`
	}
	if err := c.get(ctx, "/api/v1/namespaces/"+namespace+"/pods?labelSelector="+url.QueryEscape(selector), &list, nil); err != nil {
		return nil, err
	}
	var out []Pod
	for _, p := range list.Items {
		pod := Pod{Name: p.Metadata.Name, Deleting: p.Metadata.DeletionTimestamp != nil}
		for _, cond := range p.Status.Conditions {
			pod.Ready = pod.Ready || (cond.Type == "Ready" && cond.Status == "True")
		}
		out = append(out, pod)
	}
	return out, nil
}

// DeletePod deletes a pod with its own grace period, as a node drain or a
// rollout does: the kubelet sends its containers SIGTERM. The workload
// suites' integration stage uses it for the Lifecycle suite's drain case,
// in a workload's namespace the environment lets the runner delete pods in.
func (c *Client) DeletePod(ctx context.Context, namespace, name string) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodDelete, c.Server+"/api/v1/namespaces/"+namespace+"/pods/"+name, nil)
	if err != nil {
		return err
	}
	if c.TokenFile != "" {
		tok, err := os.ReadFile(c.TokenFile)
		if err != nil {
			return err
		}
		req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(string(tok)))
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusAccepted {
		raw, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
		return fmt.Errorf("DELETE pod %s/%s: HTTP %d: %s", namespace, name, resp.StatusCode, strings.TrimSpace(string(raw)))
	}
	return nil
}
