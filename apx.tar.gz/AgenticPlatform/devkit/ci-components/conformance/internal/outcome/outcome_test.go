package outcome

import (
	"context"
	"net"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestRefuser(t *testing.T) {
	meshed := Source{Meshed: true, MeshConnectTimeout: 10 * time.Second}
	plain := Source{}
	for _, tc := range []struct {
		name string
		o    Outcome
		src  Source
		want Layer
	}{
		{"a sidecar's RBAC denial", Outcome{Kind: Response, Status: 403, Body: "RBAC: access denied"}, meshed, AuthorizationPolicy},
		{"the same from outside the mesh", Outcome{Kind: Response, Status: 403, Body: "RBAC: access denied\n"}, plain, AuthorizationPolicy},
		{"the gateway's 401", Outcome{Kind: Response, Status: 401, Body: "authentication failure"}, plain, Gateway},
		{"the gateway's 403", Outcome{Kind: Response, Status: 403, Body: "authorization failed"}, meshed, Gateway},
		{"an answer", Outcome{Kind: Response, Status: 200}, meshed, None},
		{"a 404 is an answer", Outcome{Kind: Response, Status: 404}, plain, None},
		{"a dropped SYN from outside the mesh", Outcome{Kind: Timeout, Elapsed: 5000}, plain, NetworkPolicy},
		{"a timeout can't happen for a meshed source", Outcome{Kind: Timeout}, meshed, Unknown},
		{"the sidecar's 503 after its connect timeout", Outcome{Kind: Response, Status: 503, Elapsed: 10000, Body: "upstream connect error or disconnect/reset before headers. reset reason: connection timeout"}, meshed, NetworkPolicy},
		{"a 503 too soon is an answer", Outcome{Kind: Response, Status: 503, Elapsed: 100, Body: "reset reason: connection timeout"}, meshed, None},
		{"the sidecar's reset after its connect timeout", Outcome{Kind: Reset, Elapsed: 9000}, meshed, NetworkPolicy},
		{"an immediate reset by the client's sidecar", Outcome{Kind: Reset, Elapsed: 3}, meshed, MeshEgress},
		{"STRICT mTLS refusing plain text", Outcome{Kind: Reset, Elapsed: 2}, plain, MTLS},
		{"nothing listening", Outcome{Kind: Refused}, plain, Unknown},
	} {
		if got := Refuser(tc.o, tc.src); got != tc.want {
			t.Errorf("%s: got %s, want %s", tc.name, got, tc.want)
		}
	}
}

func TestDo(t *testing.T) {
	cl := &Client{}
	ok := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Seen", r.Header.Get("X-Sent"))
		w.WriteHeader(418)
		w.Write([]byte("short and stout"))
	}))
	defer ok.Close()
	o := cl.Do(context.Background(), Request{URL: ok.URL, Header: map[string]string{"X-Sent": "yes"}})
	if o.Kind != Response || o.Status != 418 || o.Body != "short and stout" || o.Header["x-seen"] != "yes" {
		t.Errorf("an answer: %+v", o)
	}

	closed, _ := net.Listen("tcp", "127.0.0.1:0")
	addr := closed.Addr().String()
	closed.Close()
	if o := cl.Do(context.Background(), Request{URL: "http://" + addr}); o.Kind != Refused {
		t.Errorf("a closed port: %+v", o)
	}

	reset := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		conn, _, _ := w.(http.Hijacker).Hijack()
		conn.(*net.TCPConn).SetLinger(0)
		conn.Close()
	}))
	defer reset.Close()
	if o := cl.Do(context.Background(), Request{URL: reset.URL}); o.Kind != Reset {
		t.Errorf("a reset: %+v", o)
	}

	slow := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		select {
		case <-time.After(2 * time.Second):
		case <-r.Context().Done():
		}
	}))
	defer slow.Close()
	if o := cl.Do(context.Background(), Request{URL: slow.URL, Timeout: 200}); o.Kind != Stalled {
		t.Errorf("a stalled answer: %+v", o)
	}

	if o := cl.Do(context.Background(), Request{URL: "http://no-such-host.invalid"}); o.Kind != DNS {
		t.Errorf("an unknown host: %+v", o)
	}

	blackhole := &Client{Dial: func(ctx context.Context, _, _ string) (net.Conn, error) {
		<-ctx.Done()
		return nil, &net.OpError{Op: "dial", Err: ctx.Err()}
	}}
	if o := blackhole.Do(context.Background(), Request{URL: "http://dropped.example:80", Connect: 100}); o.Kind != Timeout {
		t.Errorf("a dropped connection: %+v", o)
	}
}
