// Package outcome describes what became of one HTTP request, in terms that
// tell the platform's refusing layers apart (design/conformance.md, "The
// platform-controls suites"): an answer and its status, a connection that
// timed out, one reset or closed before any answer, or one refused. Probes
// send their outcomes back to the runner in this shape, and the runner
// classifies them with Refuser.
package outcome

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"sync/atomic"
	"syscall"
	"time"
)

// Request is one HTTP request to make, from wherever the caller stands.
type Request struct {
	Method  string            `json:"method"`
	URL     string            `json:"url"`
	Header  map[string]string `json:"header,omitempty"`
	Body    string            `json:"body,omitempty"`
	Timeout Millis            `json:"timeout_ms,omitempty"`         // the whole request; default 30s
	Connect Millis            `json:"connect_timeout_ms,omitempty"` // the TCP connection; default 5s
}

// Millis is a duration sent as whole milliseconds.
type Millis int64

// D converts m to a duration.
func (m Millis) D() time.Duration { return time.Duration(m) * time.Millisecond }

// Of converts d to Millis.
func Of(d time.Duration) Millis { return Millis(d / time.Millisecond) }

// Kind is what became of a request.
type Kind string

// Kinds.
const (
	Response Kind = "response" // an HTTP response arrived
	Timeout  Kind = "timeout"  // no TCP connection within the connect timeout: a dropped SYN
	Stalled  Kind = "stalled"  // connected, but no response within the request's timeout
	Reset    Kind = "reset"    // connected, then reset or closed before any response
	Refused  Kind = "refused"  // the connection was refused: nothing listens, or a reject rule
	DNS      Kind = "dns"      // the name did not resolve
	Error    Kind = "error"    // anything else, such as a TLS failure
)

// Outcome is what became of one request.
type Outcome struct {
	Kind    Kind              `json:"kind"`
	Status  int               `json:"status,omitempty"`
	Header  map[string]string `json:"header,omitempty"` // first values, lower-case names
	Body    string            `json:"body,omitempty"`   // at most MaxBody bytes
	Elapsed Millis            `json:"elapsed_ms"`
	Error   string            `json:"error,omitempty"`
}

// MaxBody bounds the body an outcome carries.
const MaxBody = 64 << 10

func (o Outcome) String() string {
	switch o.Kind {
	case Response:
		body := strings.TrimSpace(o.Body)
		if len(body) > 200 {
			body = body[:200] + "…"
		}
		return fmt.Sprintf("HTTP %d after %s: %s", o.Status, o.Elapsed.D(), body)
	default:
		return fmt.Sprintf("%s after %s: %s", o.Kind, o.Elapsed.D(), o.Error)
	}
}

// Client makes requests from the process it runs in. Proxy variables are
// never read: the platform's containers reach what they reach directly.
type Client struct {
	Roots *x509.CertPool // trusted CAs; nil means the system's
	// Dial overrides how connections are made, for tests that map
	// hostnames to local servers.
	Dial func(ctx context.Context, network, addr string) (net.Conn, error)
}

// NewClient returns a client trusting the system's roots plus the PEM
// bundle in caFile, if one is named.
func NewClient(caFile string) (*Client, error) {
	roots, err := x509.SystemCertPool()
	if err != nil || roots == nil {
		roots = x509.NewCertPool()
	}
	if caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return nil, err
		}
		if !roots.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("%s: no certificates", caFile)
		}
	}
	return &Client{Roots: roots}, nil
}

// Do makes the request and says what became of it. It never follows
// redirects.
func (cl *Client) Do(ctx context.Context, r Request) Outcome {
	timeout, connect := r.Timeout.D(), r.Connect.D()
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	if connect <= 0 {
		connect = 5 * time.Second
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	// The transport may still be dialing when Do returns, after a timeout
	// or cancellation, so the flag is atomic.
	var connected atomic.Bool
	dialer := &net.Dialer{Timeout: connect}
	dial := cl.Dial
	if dial == nil {
		dial = dialer.DialContext
	}
	tr := &http.Transport{
		Proxy: nil,
		DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
			dctx, dcancel := context.WithTimeout(ctx, connect)
			defer dcancel()
			conn, err := dial(dctx, network, addr)
			if err == nil {
				connected.Store(true)
			}
			return conn, err
		},
		TLSClientConfig:       &tls.Config{RootCAs: cl.Roots, MinVersion: tls.VersionTLS12},
		DisableKeepAlives:     true,
		ResponseHeaderTimeout: timeout,
	}
	defer tr.CloseIdleConnections()
	hc := &http.Client{Transport: tr, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	method := r.Method
	if method == "" {
		method = http.MethodGet
	}
	var body io.Reader
	if r.Body != "" {
		body = strings.NewReader(r.Body)
	}
	req, err := http.NewRequestWithContext(ctx, method, r.URL, body)
	if err != nil {
		return Outcome{Kind: Error, Error: err.Error()}
	}
	for k, v := range r.Header {
		if strings.EqualFold(k, "host") {
			req.Host = v
			continue
		}
		req.Header.Set(k, v)
	}
	start := time.Now()
	resp, err := hc.Do(req)
	elapsed := Of(time.Since(start))
	if err != nil {
		return Outcome{Kind: classify(err, connected.Load()), Elapsed: elapsed, Error: err.Error()}
	}
	defer resp.Body.Close()
	raw, rerr := io.ReadAll(io.LimitReader(resp.Body, MaxBody))
	o := Outcome{Kind: Response, Status: resp.StatusCode, Body: string(raw), Elapsed: Of(time.Since(start)), Header: map[string]string{}}
	for k, v := range resp.Header {
		if len(v) > 0 {
			o.Header[strings.ToLower(k)] = v[0]
		}
	}
	if rerr != nil && !errors.Is(rerr, io.EOF) {
		o.Error = "reading the body: " + rerr.Error()
	}
	return o
}

func classify(err error, connected bool) Kind {
	var dnsErr *net.DNSError
	switch {
	case errors.As(err, &dnsErr):
		return DNS
	case errors.Is(err, syscall.ECONNREFUSED):
		return Refused
	case errors.Is(err, syscall.ECONNRESET), errors.Is(err, io.EOF), errors.Is(err, io.ErrUnexpectedEOF), errors.Is(err, syscall.EPIPE):
		return Reset
	case isTimeout(err):
		if connected {
			return Stalled
		}
		return Timeout
	case strings.Contains(err.Error(), "connection reset"), strings.Contains(err.Error(), "EOF"):
		return Reset
	}
	return Error
}

func isTimeout(err error) bool {
	var ne net.Error
	if errors.As(err, &ne) && ne.Timeout() {
		return true
	}
	return errors.Is(err, context.DeadlineExceeded)
}

// Layer is a part of the platform that refuses traffic.
type Layer string

// The layers design/conformance.md names, and two outcomes that are not a
// refusal by any of them.
const (
	Gateway             Layer = "gateway"              // the gateway's own 401 or 403 (or another refusal it answers)
	AuthorizationPolicy Layer = "authorization-policy" // a sidecar's RBAC denial
	MTLS                Layer = "strict-mtls"          // a sidecar refusing a client without mesh TLS
	NetworkPolicy       Layer = "networkpolicy"        // a dropped connection
	MeshEgress          Layer = "mesh-egress"          // the client's own sidecar refusing at once, as REGISTRY_ONLY would
	Admission           Layer = "admission"            // an admission webhook's denial
	Realm               Layer = "realm"                // the identity provider's own refusal, such as its client-registration policy
	None                Layer = "none"                 // nothing refused: an answer arrived from past every layer
	Unknown             Layer = "unknown"
)

// Source is where a request starts, which changes how each layer looks.
type Source struct {
	Name   string
	Meshed bool // the source pod has a sidecar
	// MeshConnectTimeout is the sidecar's connect timeout toward an
	// upstream, after which it gives up on a dropped connection (Istio's
	// default is 10s); a meshed source sees a NetworkPolicy drop only as
	// its own sidecar's failure after about this long.
	MeshConnectTimeout time.Duration
}

// RBACBody is the body of an Istio sidecar's RBAC denial on an HTTP port.
const RBACBody = "RBAC: access denied"

// Refuser says which layer the outcome shows refusing, from where the
// request started (design/conformance.md: a gateway's 401 or 403, a
// sidecar's RBAC denial, a NetworkPolicy drop, a sidecar refusing plain
// text). An answer that is none of these is None: the request got through.
//
//   - A 403 whose body is the sidecar's "RBAC: access denied" is
//     AuthorizationPolicy, whatever the source.
//   - From an unmeshed source, a connection that never opens is
//     NetworkPolicy (T21: every refusal there was a connection timeout),
//     and one reset or closed before any answer is STRICT mTLS (T21: a
//     client without a sidecar got a reset from the STRICT server).
//   - From a meshed source the sidecar always accepts the connection, so a
//     drop shows as the sidecar giving up after its connect timeout: a 503
//     naming a connection timeout for plain HTTP, or a reset no sooner than
//     most of that timeout for TLS it passes through. A reset well before
//     it is the client's own sidecar refusing (MeshEgress), not a drop.
//   - Any other 401 or 403 is the gateway's: the fixtures behind it never
//     answer either, so the case's twin and the records tell the rest.
func Refuser(o Outcome, src Source) Layer {
	limit := src.MeshConnectTimeout
	if limit <= 0 {
		limit = 10 * time.Second
	}
	switch o.Kind {
	case Response:
		body := strings.TrimSpace(o.Body)
		switch {
		case o.Status == http.StatusForbidden && body == RBACBody:
			return AuthorizationPolicy
		case src.Meshed && o.Status == http.StatusServiceUnavailable && mentionsConnectTimeout(body) && o.Elapsed.D() >= limit*8/10:
			return NetworkPolicy
		case o.Status == http.StatusUnauthorized || o.Status == http.StatusForbidden:
			return Gateway
		}
		return None
	case Timeout:
		if !src.Meshed {
			return NetworkPolicy
		}
		return Unknown
	case Reset:
		if src.Meshed {
			if o.Elapsed.D() >= limit*8/10 {
				return NetworkPolicy
			}
			return MeshEgress
		}
		return MTLS
	}
	return Unknown
}

func mentionsConnectTimeout(body string) bool {
	b := strings.ToLower(body)
	return strings.Contains(b, "connection timeout") || strings.Contains(b, "connect timeout") || strings.Contains(b, "connection_timeout")
}

// Reached reports whether the request got an answer from past every
// layer: any response that no layer would give.
func Reached(o Outcome, src Source) bool {
	return o.Kind == Response && Refuser(o, src) == None
}

// Compact is a short form of a JSON body, for messages.
func Compact(body string) string {
	var buf bytes.Buffer
	if err := jsonCompact(&buf, body); err == nil {
		body = buf.String()
	}
	if len(body) > 300 {
		body = body[:300] + "…"
	}
	return body
}

func jsonCompact(buf *bytes.Buffer, s string) error { return json.Compact(buf, []byte(s)) }
