// Package s3 lists and reads objects, all the telemetry cases need of S3:
// the audit bucket's records and Langfuse's event blobs (plan/local-build.md,
// "B3 in detail", The checks). Requests are signed with Signature Version
// 4, written here on the standard library, since the runner's image holds
// no AWS CLI and the module takes no dependency for two calls. Locally the
// store is floci, path style, with its static credentials; credentials
// come from the environment's AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY and
// AWS_SESSION_TOKEN.
package s3

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/fetch"
)

// Credentials sign requests.
type Credentials struct {
	AccessKeyID, SecretAccessKey, SessionToken string
}

// EnvCredentials reads the credentials from the environment.
func EnvCredentials() (Credentials, error) {
	c := Credentials{os.Getenv("AWS_ACCESS_KEY_ID"), os.Getenv("AWS_SECRET_ACCESS_KEY"), os.Getenv("AWS_SESSION_TOKEN")}
	if c.AccessKeyID == "" || c.SecretAccessKey == "" {
		return c, fmt.Errorf("no AWS credentials: set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY (locally, floci's static credentials from the Secret aws-static-credentials)")
	}
	return c, nil
}

// Client reads one S3 endpoint.
type Client struct {
	Endpoint  string // such as http://floci:4566
	Region    string
	PathStyle bool // bucket in the path, as floci needs, rather than in the host
	HTTP      *fetch.Client
	Creds     func() (Credentials, error)
	Now       func() time.Time
}

// Object is one listed object.
type Object struct {
	Key          string    `xml:"Key"`
	LastModified time.Time `xml:"LastModified"`
	Size         int64     `xml:"Size"`
}

// List lists every object under prefix, page by page.
func (c *Client) List(ctx context.Context, bucket, prefix string) ([]Object, error) {
	var out []Object
	token := ""
	for page := 0; page < 100; page++ {
		q := map[string]string{"list-type": "2", "prefix": prefix}
		if token != "" {
			q["continuation-token"] = token
		}
		body, err := c.do(ctx, bucket, "", q)
		if err != nil {
			return nil, err
		}
		var res struct {
			Contents              []Object `xml:"Contents"`
			IsTruncated           bool     `xml:"IsTruncated"`
			NextContinuationToken string   `xml:"NextContinuationToken"`
		}
		if err := xml.Unmarshal(body, &res); err != nil {
			return nil, fmt.Errorf("listing s3://%s/%s: %v", bucket, prefix, err)
		}
		out = append(out, res.Contents...)
		if !res.IsTruncated || res.NextContinuationToken == "" {
			return out, nil
		}
		token = res.NextContinuationToken
	}
	return nil, fmt.Errorf("listing s3://%s/%s: more than 100 pages", bucket, prefix)
}

// Get reads an object whole, decompressed if it is gzip, as the
// collector's S3 exporter writes it.
func (c *Client) Get(ctx context.Context, bucket, key string) ([]byte, error) {
	body, err := c.do(ctx, bucket, key, nil)
	if err != nil {
		return nil, err
	}
	if len(body) >= 2 && body[0] == 0x1f && body[1] == 0x8b {
		zr, err := gzip.NewReader(bytes.NewReader(body))
		if err != nil {
			return nil, fmt.Errorf("s3://%s/%s: %v", bucket, key, err)
		}
		max := c.HTTP.Max
		if max <= 0 {
			max = fetch.DefaultMax
		}
		raw, err := io.ReadAll(io.LimitReader(zr, max+1))
		if err != nil {
			return nil, fmt.Errorf("s3://%s/%s: %v", bucket, key, err)
		}
		if int64(len(raw)) > max {
			return nil, fmt.Errorf("s3://%s/%s: larger than %d bytes uncompressed; refusing to judge a part of it", bucket, key, max)
		}
		return raw, nil
	}
	return body, nil
}

func (c *Client) do(ctx context.Context, bucket, key string, query map[string]string) ([]byte, error) {
	creds, err := c.Creds()
	if err != nil {
		return nil, err
	}
	u, err := url.Parse(strings.TrimRight(c.Endpoint, "/"))
	if err != nil {
		return nil, fmt.Errorf("s3.endpoint: %v", err)
	}
	host, path := u.Host, "/"+escape(key, false)
	if c.PathStyle {
		path = "/" + escape(bucket, true) + path
		if key == "" {
			path = "/" + escape(bucket, true)
		}
	} else {
		host = bucket + "." + host
	}
	rawQuery := canonicalQuery(query)
	target := u.Scheme + "://" + host + path
	if rawQuery != "" {
		target += "?" + rawQuery
	}
	now := time.Now
	if c.Now != nil {
		now = c.Now
	}
	header := Sign(http.MethodGet, host, path, rawQuery, nil, creds, c.Region, "s3", now())
	resp, err := c.HTTP.Do(ctx, http.MethodGet, target, header, nil)
	if err != nil {
		return nil, err
	}
	if resp.Status != http.StatusOK {
		return nil, fmt.Errorf("GET s3://%s/%s: HTTP %d: %s", bucket, key, resp.Status, strings.TrimSpace(string(resp.Body[:min(len(resp.Body), 300)])))
	}
	return resp.Body, nil
}

// Sign returns the headers that sign a request with Signature Version 4:
// Authorization, X-Amz-Date, X-Amz-Content-Sha256 and, with a session
// token, X-Amz-Security-Token. path is the request's path as sent, already
// escaped, and rawQuery its canonical query string.
func Sign(method, host, path, rawQuery string, payload []byte, creds Credentials, region, service string, t time.Time) map[string]string {
	t = t.UTC()
	date, stamp := t.Format("20060102"), t.Format("20060102T150405Z")
	sum := sha256.Sum256(payload)
	payloadHash := hex.EncodeToString(sum[:])
	h := map[string]string{"host": host, "x-amz-date": stamp, "x-amz-content-sha256": payloadHash}
	if creds.SessionToken != "" {
		h["x-amz-security-token"] = creds.SessionToken
	}
	return sign(method, path, rawQuery, h, payloadHash, creds, region, service, date)
}

func sign(method, path, rawQuery string, h map[string]string, payloadHash string, creds Credentials, region, service, date string) map[string]string {
	names := make([]string, 0, len(h))
	for k := range h {
		names = append(names, k)
	}
	sort.Strings(names)
	var canonHeaders strings.Builder
	for _, k := range names {
		canonHeaders.WriteString(k + ":" + strings.TrimSpace(h[k]) + "\n")
	}
	signed := strings.Join(names, ";")
	canonical := strings.Join([]string{method, path, rawQuery, canonHeaders.String(), signed, payloadHash}, "\n")
	scope := date + "/" + region + "/" + service + "/aws4_request"
	sum := sha256.Sum256([]byte(canonical))
	toSign := strings.Join([]string{"AWS4-HMAC-SHA256", h["x-amz-date"], scope, hex.EncodeToString(sum[:])}, "\n")
	key := mac([]byte("AWS4"+creds.SecretAccessKey), date)
	key = mac(key, region)
	key = mac(key, service)
	key = mac(key, "aws4_request")
	sig := hex.EncodeToString(mac(key, toSign))
	out := map[string]string{"Authorization": fmt.Sprintf("AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s", creds.AccessKeyID, scope, signed, sig)}
	for k, v := range h {
		if k != "host" {
			out[k] = v
		}
	}
	return out
}

func mac(key []byte, data string) []byte {
	m := hmac.New(sha256.New, key)
	m.Write([]byte(data))
	return m.Sum(nil)
}

// canonicalQuery is the query string sorted by name, each part escaped as
// Signature Version 4 requires; it is also what the request sends.
func canonicalQuery(q map[string]string) string {
	names := make([]string, 0, len(q))
	for k := range q {
		names = append(names, k)
	}
	sort.Strings(names)
	parts := make([]string, 0, len(names))
	for _, k := range names {
		parts = append(parts, escape(k, true)+"="+escape(q[k], true))
	}
	return strings.Join(parts, "&")
}

// escape percent-encodes all but the unreserved characters, and slashes
// too when slash is true.
func escape(s string, slash bool) string {
	var b strings.Builder
	for i := 0; i < len(s); i++ {
		ch := s[i]
		switch {
		case ch >= 'A' && ch <= 'Z', ch >= 'a' && ch <= 'z', ch >= '0' && ch <= '9', ch == '-', ch == '_', ch == '.', ch == '~':
			b.WriteByte(ch)
		case ch == '/' && !slash:
			b.WriteByte(ch)
		default:
			fmt.Fprintf(&b, "%%%02X", ch)
		}
	}
	return b.String()
}
