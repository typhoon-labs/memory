package s3

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/fetch"
)

// TestSignVanilla: AWS's published Signature Version 4 test case
// get-vanilla (aws-sig-v4-test-suite): GET / on example.amazonaws.com at
// 20150830T123600Z, with its documented example credentials.
func TestSignVanilla(t *testing.T) {
	empty := sha256.Sum256(nil)
	h := map[string]string{"host": "example.amazonaws.com", "x-amz-date": "20150830T123600Z"}
	got := sign("GET", "/", "", h, hex.EncodeToString(empty[:]),
		Credentials{AccessKeyID: "AKIDEXAMPLE", SecretAccessKey: "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY"}, "us-east-1", "service", "20150830")
	want := "AWS4-HMAC-SHA256 Credential=AKIDEXAMPLE/20150830/us-east-1/service/aws4_request, SignedHeaders=host;x-amz-date, Signature=5fa00fa31553b73ebf1942676e86291e8372ff2a2260956d9b8aae1d763fbf31"
	if got["Authorization"] != want {
		t.Errorf("Authorization:\n got %s\nwant %s", got["Authorization"], want)
	}
}

func TestEscape(t *testing.T) {
	if got := escape("records/year=2026/a b~", false); got != "records/year%3D2026/a%20b~" {
		t.Errorf("a key: %s", got)
	}
	if got := canonicalQuery(map[string]string{"prefix": "otel/x=1/", "list-type": "2"}); got != "list-type=2&prefix=otel%2Fx%3D1%2F" {
		t.Errorf("a query: %s", got)
	}
}

// TestListAndGet: pages are followed, keys are sent as signed, and a
// gzip object comes back decompressed.
func TestListAndGet(t *testing.T) {
	var zipped bytes.Buffer
	zw := gzip.NewWriter(&zipped)
	zw.Write([]byte(`{"resourceLogs":[]}`))
	zw.Close()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.Header.Get("Authorization"), "AWS4-HMAC-SHA256 Credential=test/") || r.Header.Get("X-Amz-Content-Sha256") == "" {
			http.Error(w, "unsigned", http.StatusForbidden)
			return
		}
		switch {
		case r.URL.Path == "/audit" && r.URL.Query().Get("continuation-token") == "":
			fmt.Fprint(w, `<ListBucketResult><Contents><Key>records/minute=01/a.json.gz</Key><LastModified>2026-11-17T08:00:00.000Z</LastModified><Size>3</Size></Contents><IsTruncated>true</IsTruncated><NextContinuationToken>n/2</NextContinuationToken></ListBucketResult>`)
		case r.URL.Path == "/audit" && r.URL.Query().Get("continuation-token") == "n/2":
			fmt.Fprint(w, `<ListBucketResult><Contents><Key>records/minute=01/b.json.gz</Key></Contents><IsTruncated>false</IsTruncated></ListBucketResult>`)
		case r.URL.EscapedPath() == "/audit/records/minute%3D01/a.json.gz":
			w.Write(zipped.Bytes())
		default:
			http.Error(w, "NoSuchKey "+r.URL.EscapedPath(), http.StatusNotFound)
		}
	}))
	defer srv.Close()
	c := &Client{Endpoint: srv.URL, Region: "us-east-1", PathStyle: true, HTTP: &fetch.Client{},
		Creds: func() (Credentials, error) { return Credentials{AccessKeyID: "test", SecretAccessKey: "test"}, nil },
		Now:   func() time.Time { return time.Date(2026, 11, 17, 8, 0, 0, 0, time.UTC) }}
	objs, err := c.List(context.Background(), "audit", "records/minute=01/")
	if err != nil || len(objs) != 2 || objs[0].Key != "records/minute=01/a.json.gz" || objs[0].LastModified.IsZero() {
		t.Fatalf("list: %v %+v", err, objs)
	}
	body, err := c.Get(context.Background(), "audit", objs[0].Key)
	if err != nil || string(body) != `{"resourceLogs":[]}` {
		t.Fatalf("get: %v %q", err, body)
	}
	if _, err := c.Get(context.Background(), "audit", "missing"); err == nil || !strings.Contains(err.Error(), "404") {
		t.Errorf("a missing object: %v", err)
	}
}
