package otlp

import (
	"strings"
	"testing"
	"time"
)

func TestRoundTrip(t *testing.T) {
	now := time.Unix(1794905104, 428892234)
	body := Traces(KVs("service.name", "conformance-runner"), "conformance", []Span{
		{TraceID: "25faf12bfce0fb0a8835871fbc2435b9", SpanID: "95b6909e2ab43d77", Name: "invoke_agent a", Kind: KindInternal, Start: now, End: now.Add(time.Millisecond), Error: "kept"},
		{TraceID: "25faf12bfce0fb0a8835871fbc2435b9", SpanID: "b076fdbd071b53c5", ParentSpanID: "95b6909e2ab43d77", Name: "chat m", Kind: KindClient, Start: now, End: now,
			Attributes: KVs("gen_ai.operation.name", "chat"), Events: []Event{{Name: "gen_ai.client.inference.operation.details", Time: now}}},
	})
	for _, want := range []string{`"startTimeUnixNano":"1794905104428892234"`, `"status":{"code":2,"message":"kept"}`, `"stringValue":"chat"`} {
		if !strings.Contains(string(body), want) {
			t.Errorf("want %s in %s", want, body)
		}
	}
	e, ok := Parse(body)
	if !ok {
		t.Fatal("not an export")
	}
	spans := e.Spans("25faf12bfce0fb0a8835871fbc2435b9")
	if len(spans) != 2 || spans[1].ParentSpanID != "95b6909e2ab43d77" || Attr(spans[1].Attributes, "gen_ai.operation.name") != "chat" || spans[1].Service != "conformance-runner" {
		t.Errorf("spans: %+v", spans)
	}
	logs := Logs(KVs("service.name", "w"), "conformance", []Record{{TraceID: "25faf12bfce0fb0a8835871fbc2435b9", Time: now, Body: "b",
		Attributes: KVs("record.source", "platform")}})
	e, ok = Parse(logs)
	if !ok || len(e.Logs("25faf12bfce0fb0a8835871fbc2435b9")) != 1 || Attr(e.Logs("25faf12bfce0fb0a8835871fbc2435b9")[0].Attributes, "record.source") != "platform" {
		t.Errorf("logs: %s", logs)
	}
}

// TestParse reads lines shaped as the file exporter at 0.165.0 wrote them
// in a local run: a logs export, and a line that is not one.
func TestParse(t *testing.T) {
	line := `{"resourceLogs":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"agentgateway"}}]},"scopeLogs":[{"scope":{},"logRecords":[{"timeUnixNano":"1","body":{"stringValue":"request"},"attributes":[{"key":"user.team","value":{"stringValue":"payments"}}],"traceId":"25faf12bfce0fb0a8835871fbc2435b9","spanId":"b076fdbd071b53c5"}]}]}]}`
	e, ok := Parse([]byte(line))
	if !ok || len(e.Logs("25faf12bfce0fb0a8835871fbc2435b9")) != 1 || Attr(e.Logs("25faf12bfce0fb0a8835871fbc2435b9")[0].Attributes, "user.team") != "payments" {
		t.Errorf("a logs export: %v %+v", ok, e)
	}
	if _, ok := Parse([]byte("2026-11-17T08:44:50.409Z\twarn\tbuilders/builders.go:40\t\"spanmetrics\" alias is deprecated")); ok {
		t.Error("a log line of the collector's own is no export")
	}
}
