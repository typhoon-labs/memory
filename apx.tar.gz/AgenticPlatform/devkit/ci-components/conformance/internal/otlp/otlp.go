// Package otlp writes and reads the little of OTLP's JSON encoding the
// telemetry cases need (plan/local-build.md, "B3 in detail", The checks):
// traces the runner sends to the collector's general port over HTTP, and
// the lines the Dynatrace and SIEM stand-ins print, the file exporter's
// newline-delimited OTLP JSON, read back for their trace IDs. Trace and span
// IDs are hex, as OTLP's JSON encoding writes them; times are nanoseconds
// since the epoch, as decimal strings.
package otlp

import (
	"encoding/json"
	"strconv"
	"time"
)

// Span kinds and status codes, as OTLP numbers them.
const (
	KindInternal = 1
	KindServer   = 2
	KindClient   = 3

	StatusError = 2
)

// Span is one span to send.
type Span struct {
	TraceID, SpanID, ParentSpanID string
	Name                          string
	Kind                          int
	Start, End                    time.Time
	Attributes                    []KV
	Events                        []Event
	Error                         string // a status of ERROR with this message, if set
}

// Event is a span event.
type Event struct {
	Name       string
	Time       time.Time
	Attributes []KV
}

// KV is a string attribute.
type KV struct{ Key, Value string }

// KVs makes attributes from keys and values in turn.
func KVs(pairs ...string) []KV {
	out := make([]KV, 0, len(pairs)/2)
	for i := 0; i+1 < len(pairs); i += 2 {
		out = append(out, KV{Key: pairs[i], Value: pairs[i+1]})
	}
	return out
}

type kv struct {
	Key   string `json:"key"`
	Value struct {
		StringValue string `json:"stringValue"`
	} `json:"value"`
}

func kvs(in []KV) []kv {
	out := make([]kv, len(in))
	for i, a := range in {
		out[i].Key, out[i].Value.StringValue = a.Key, a.Value
	}
	return out
}

func nanos(t time.Time) string { return strconv.FormatInt(t.UnixNano(), 10) }

// Traces is an ExportTraceServiceRequest of spans from one service, as
// JSON.
func Traces(resource []KV, scope string, spans []Span) []byte {
	type event struct {
		Time       string `json:"timeUnixNano"`
		Name       string `json:"name"`
		Attributes []kv   `json:"attributes,omitempty"`
	}
	type status struct {
		Code    int    `json:"code,omitempty"`
		Message string `json:"message,omitempty"`
	}
	type span struct {
		TraceID      string  `json:"traceId"`
		SpanID       string  `json:"spanId"`
		ParentSpanID string  `json:"parentSpanId,omitempty"`
		Name         string  `json:"name"`
		Kind         int     `json:"kind"`
		Start        string  `json:"startTimeUnixNano"`
		End          string  `json:"endTimeUnixNano"`
		Attributes   []kv    `json:"attributes,omitempty"`
		Events       []event `json:"events,omitempty"`
		Status       status  `json:"status"`
	}
	out := make([]span, len(spans))
	for i, s := range spans {
		out[i] = span{TraceID: s.TraceID, SpanID: s.SpanID, ParentSpanID: s.ParentSpanID, Name: s.Name, Kind: s.Kind,
			Start: nanos(s.Start), End: nanos(s.End), Attributes: kvs(s.Attributes)}
		for _, e := range s.Events {
			out[i].Events = append(out[i].Events, event{Time: nanos(e.Time), Name: e.Name, Attributes: kvs(e.Attributes)})
		}
		if s.Error != "" {
			out[i].Status = status{Code: StatusError, Message: s.Error}
		}
	}
	body, _ := json.Marshal(map[string]any{"resourceSpans": []any{map[string]any{
		"resource":   map[string]any{"attributes": kvs(resource)},
		"scopeSpans": []any{map[string]any{"scope": map[string]any{"name": scope}, "spans": out}},
	}}})
	return body
}

// Record is one log record to send.
type Record struct {
	TraceID, SpanID string
	Time            time.Time
	Body            string
	Attributes      []KV
}

// Logs is an OTLP JSON export of log records, as OTLP over HTTP takes it
// on /v1/logs.
func Logs(resource []KV, scope string, records []Record) []byte {
	type record struct {
		Time       string         `json:"timeUnixNano"`
		TraceID    string         `json:"traceId,omitempty"`
		SpanID     string         `json:"spanId,omitempty"`
		Body       map[string]any `json:"body,omitempty"`
		Attributes []kv           `json:"attributes,omitempty"`
	}
	out := make([]record, len(records))
	for i, r := range records {
		out[i] = record{Time: nanos(r.Time), TraceID: r.TraceID, SpanID: r.SpanID, Attributes: kvs(r.Attributes)}
		if r.Body != "" {
			out[i].Body = map[string]any{"stringValue": r.Body}
		}
	}
	body, _ := json.Marshal(map[string]any{"resourceLogs": []any{map[string]any{
		"resource":  map[string]any{"attributes": kvs(resource)},
		"scopeLogs": []any{map[string]any{"scope": map[string]any{"name": scope}, "logRecords": out}},
	}}})
	return body
}

// Export is one line of the file exporter's output, or one OTLP JSON
// object in a bucket: traces, logs or metrics.
type Export struct {
	ResourceSpans []struct {
		Resource   Resource `json:"resource"`
		ScopeSpans []struct {
			Spans []ReadSpan `json:"spans"`
		} `json:"scopeSpans"`
	} `json:"resourceSpans"`
	ResourceLogs []struct {
		Resource  Resource `json:"resource"`
		ScopeLogs []struct {
			LogRecords []LogRecord `json:"logRecords"`
		} `json:"scopeLogs"`
	} `json:"resourceLogs"`
	ResourceMetrics []json.RawMessage `json:"resourceMetrics"`
}

// Resource is a resource's attributes.
type Resource struct {
	Attributes []Attribute `json:"attributes"`
}

// Attribute is an attribute as read: its value kept as JSON.
type Attribute struct {
	Key   string          `json:"key"`
	Value json.RawMessage `json:"value"`
}

// ReadSpan is a span as read back.
type ReadSpan struct {
	TraceID      string      `json:"traceId"`
	SpanID       string      `json:"spanId"`
	ParentSpanID string      `json:"parentSpanId"`
	Name         string      `json:"name"`
	Attributes   []Attribute `json:"attributes"`
	// Service is its resource's service.name, which Spans sets.
	Service string `json:"-"`
}

// LogRecord is a log record as read back.
type LogRecord struct {
	TraceID    string      `json:"traceId"`
	SpanID     string      `json:"spanId"`
	Attributes []Attribute `json:"attributes"`
}

// Parse reads one export; ok is false for anything else, such as a line
// the collector logs about itself.
func Parse(line []byte) (e Export, ok bool) {
	if json.Unmarshal(line, &e) != nil {
		return Export{}, false
	}
	return e, len(e.ResourceSpans)+len(e.ResourceLogs)+len(e.ResourceMetrics) > 0
}

// Spans are the export's spans of one trace, each with its service.
func (e Export) Spans(traceID string) []ReadSpan {
	var out []ReadSpan
	for _, rs := range e.ResourceSpans {
		service := Attr(rs.Resource.Attributes, "service.name")
		for _, ss := range rs.ScopeSpans {
			for _, s := range ss.Spans {
				if s.TraceID == traceID {
					s.Service = service
					out = append(out, s)
				}
			}
		}
	}
	return out
}

// Logs are the export's log records of one trace.
func (e Export) Logs(traceID string) []LogRecord {
	var out []LogRecord
	for _, rl := range e.ResourceLogs {
		for _, sl := range rl.ScopeLogs {
			for _, r := range sl.LogRecords {
				if r.TraceID == traceID {
					out = append(out, r)
				}
			}
		}
	}
	return out
}

// String is an attribute's string value, or "" if it has none.
func (a Attribute) String() string {
	var v struct {
		StringValue string `json:"stringValue"`
	}
	json.Unmarshal(a.Value, &v)
	return v.StringValue
}

// Attr is the string value of the attribute named key, or "".
func Attr(attrs []Attribute, key string) string {
	for _, a := range attrs {
		if a.Key == key {
			return a.String()
		}
	}
	return ""
}
