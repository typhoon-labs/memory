// Package a2a speaks the agent-to-agent protocol's JSON-RPC binding, A2A
// 1.0 as a2a-sdk 1.x serves it (checked against a2a-sdk 1.3.1's
// jsonrpc_dispatcher and a2a.proto on 2026-11-17): methods named after the
// proto service's RPCs (SendMessage, GetTask, CancelTask), messages in the
// proto's JSON form (camelCase fields, enums as their names, such as
// TASK_STATE_COMPLETED and ROLE_USER), the version in the A2A-Version
// header, and the agent card at /.well-known/agent-card.json. A request
// without that header is A2A 0.3 to a 1.x server, which answers it only
// in compatibility mode, so every request here sends it.
package a2a

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

// Version is the protocol version every request names.
const Version = "1.0"

// CardPath is where an agent serves its card, under its A2A path.
const CardPath = "/.well-known/agent-card.json"

// Task states.
const (
	Submitted     = "TASK_STATE_SUBMITTED"
	Working       = "TASK_STATE_WORKING"
	Completed     = "TASK_STATE_COMPLETED"
	Failed        = "TASK_STATE_FAILED"
	Canceled      = "TASK_STATE_CANCELED"
	InputRequired = "TASK_STATE_INPUT_REQUIRED"
	Rejected      = "TASK_STATE_REJECTED"
	AuthRequired  = "TASK_STATE_AUTH_REQUIRED"
)

// Terminal reports whether a task in state s can change no more.
func Terminal(s string) bool {
	return s == Completed || s == Failed || s == Canceled || s == Rejected
}

// JSON-RPC error codes of A2A (a2a-sdk's JSON_RPC_ERROR_CODE_MAP).
const (
	CodeTaskNotFound      = -32001
	CodeTaskNotCancelable = -32002
	CodeVersion           = -32009
	CodeInvalidParams     = -32602
	CodeInvalidRequest    = -32600
	CodeMethodNotFound    = -32601
	CodeParse             = -32700
)

// Part is a message or artifact part: text or data.
type Part struct {
	Text string          `json:"text,omitempty"`
	Data json.RawMessage `json:"data,omitempty"`
}

// Message is a message of a conversation.
type Message struct {
	MessageID string `json:"messageId"`
	ContextID string `json:"contextId,omitempty"`
	TaskID    string `json:"taskId,omitempty"`
	Role      string `json:"role"`
	Parts     []Part `json:"parts"`
}

// Status is a task's state, with the message that came with it.
type Status struct {
	State     string   `json:"state"`
	Message   *Message `json:"message,omitempty"`
	Timestamp string   `json:"timestamp,omitempty"`
}

// Artifact is an output of a task.
type Artifact struct {
	ArtifactID string `json:"artifactId"`
	Name       string `json:"name,omitempty"`
	Parts      []Part `json:"parts"`
}

// Task is a unit of work an agent runs.
type Task struct {
	ID        string     `json:"id"`
	ContextID string     `json:"contextId,omitempty"`
	Status    Status     `json:"status"`
	Artifacts []Artifact `json:"artifacts,omitempty"`
	History   []Message  `json:"history,omitempty"`
}

// Text joins the text of the task's artifacts and final status message.
func (t Task) Text() string {
	var b strings.Builder
	for _, a := range t.Artifacts {
		for _, p := range a.Parts {
			b.WriteString(p.Text)
		}
	}
	if t.Status.Message != nil {
		for _, p := range t.Status.Message.Parts {
			b.WriteString(p.Text)
		}
	}
	return b.String()
}

// Data returns the data parts of the task's final status message.
func (t Task) Data() []json.RawMessage {
	var out []json.RawMessage
	if t.Status.Message != nil {
		for _, p := range t.Status.Message.Parts {
			if len(p.Data) > 0 {
				out = append(out, p.Data)
			}
		}
	}
	return out
}

// RPCError is a JSON-RPC error.
type RPCError struct {
	Code    int             `json:"code"`
	Message string          `json:"message"`
	Data    json.RawMessage `json:"data,omitempty"`
}

func (e *RPCError) Error() string { return fmt.Sprintf("JSON-RPC error %d: %s", e.Code, e.Message) }

// Response is a JSON-RPC response.
type Response struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Result  json.RawMessage `json:"result,omitempty"`
	Error   *RPCError       `json:"error,omitempty"`
}

// Call is one request's outcome and, if one parsed, its response.
type Call struct {
	Outcome  outcome.Outcome
	Response *Response
}

// OK reports a 200 with a JSON-RPC result.
func (c Call) OK() bool {
	return c.Outcome.Kind == outcome.Response && c.Outcome.Status == http.StatusOK && c.Response != nil && c.Response.Error == nil && c.Response.Result != nil
}

func (c Call) String() string {
	if c.Response != nil && c.Response.Error != nil {
		return fmt.Sprintf("HTTP %d with %v", c.Outcome.Status, c.Response.Error)
	}
	return c.Outcome.String()
}

// Task reads a SendMessage, GetTask or CancelTask result as a task:
// SendMessage's result holds it under "task", the others are the task.
func (c Call) Task() (Task, error) {
	if !c.OK() {
		return Task{}, fmt.Errorf("no result: %s", c)
	}
	var wrapped struct {
		Task    *Task    `json:"task"`
		Message *Message `json:"message"`
	}
	if json.Unmarshal(c.Response.Result, &wrapped) == nil {
		if wrapped.Task != nil {
			return *wrapped.Task, nil
		}
		if wrapped.Message != nil {
			return Task{}, fmt.Errorf("the agent answered with a message, not a task: %s", outcome.Compact(string(c.Response.Result)))
		}
	}
	var t Task
	if err := json.Unmarshal(c.Response.Result, &t); err != nil || t.ID == "" {
		return Task{}, fmt.Errorf("not a task: %s", outcome.Compact(string(c.Response.Result)))
	}
	return t, nil
}

// Client calls one agent.
type Client struct {
	URL    string // the agent's JSON-RPC endpoint
	Token  string
	Header map[string]string
	HTTP   interface {
		Do(ctx context.Context, r outcome.Request) outcome.Outcome
	}
	Timeout outcome.Millis

	next int
}

// Request sends one JSON-RPC request.
func (c *Client) Request(ctx context.Context, method string, params any) Call {
	c.next++
	body, _ := json.Marshal(map[string]any{"jsonrpc": "2.0", "id": c.next, "method": method, "params": params})
	h := map[string]string{"Content-Type": "application/json", "Accept": "application/json", "A2A-Version": Version}
	if c.Token != "" {
		h["Authorization"] = "Bearer " + c.Token
	}
	for k, v := range c.Header {
		h[k] = v
	}
	o := c.HTTP.Do(ctx, outcome.Request{Method: http.MethodPost, URL: c.URL, Header: h, Body: string(body), Timeout: c.Timeout})
	call := Call{Outcome: o}
	if o.Kind == outcome.Response {
		var r Response
		if json.Unmarshal([]byte(o.Body), &r) == nil && (r.Result != nil || r.Error != nil) {
			call.Response = &r
		}
	}
	return call
}

// Send sends a user message with one text part and returns the task. With
// immediately, the agent answers before the task finishes.
func (c *Client) Send(ctx context.Context, messageID, text string, immediately bool) Call {
	params := map[string]any{
		"message": Message{MessageID: messageID, Role: "ROLE_USER", Parts: []Part{{Text: text}}},
	}
	if immediately {
		params["configuration"] = map[string]any{"returnImmediately": true}
	}
	return c.Request(ctx, "SendMessage", params)
}

// Get reads a task.
func (c *Client) Get(ctx context.Context, id string) Call {
	return c.Request(ctx, "GetTask", map[string]any{"id": id})
}

// Cancel asks for a task's cancellation.
func (c *Client) Cancel(ctx context.Context, id string) Call {
	return c.Request(ctx, "CancelTask", map[string]any{"id": id})
}
