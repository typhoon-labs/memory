// Package ecr is the little of Amazon ECR's API the contract stage needs,
// on the standard library: deleting the tag it pushed to the project's
// scratch repository, so that a pipeline leaves nothing behind, pass or
// fail. Requests are signed with Signature Version 4, so the same call
// works against floci and AWS.
package ecr

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// Client calls ECR's JSON API.
type Client struct {
	Endpoint string // such as http://floci:4566, or https://api.ecr.<region>.amazonaws.com
	Region   string
	// Static credentials; SessionToken may be empty.
	AccessKeyID, SecretAccessKey, SessionToken string
	HTTP                                       *http.Client
	Now                                        func() time.Time
}

// Error is ECR's error answer.
type Error struct {
	Status  int
	Type    string `json:"__type"`
	Message string `json:"message"`
}

func (e *Error) Error() string { return fmt.Sprintf("ECR %d %s: %s", e.Status, e.Type, e.Message) }

type imageID struct {
	ImageTag    string `json:"imageTag,omitempty"`
	ImageDigest string `json:"imageDigest,omitempty"`
}

// DeleteTag removes one tag from repository, and the image it named when
// no other tag names it any more, as ECR itself does when an image's last
// tag goes: floci keeps the image, untagged, so the second step is
// explicit. A tag that is already gone is not an error.
func (c *Client) DeleteTag(ctx context.Context, repository, tag string) error {
	deleted, err := c.batchDelete(ctx, repository, imageID{ImageTag: tag})
	if err != nil || len(deleted) == 0 {
		return err
	}
	digest := deleted[0].ImageDigest
	var desc struct {
		ImageDetails []struct {
			ImageTags []string `json:"imageTags"`
		} `json:"imageDetails"`
	}
	in := map[string]any{"repositoryName": repository, "imageIds": []imageID{{ImageDigest: digest}}}
	if err := c.call(ctx, "DescribeImages", in, &desc); err != nil {
		var e *Error
		if errors.As(err, &e) && e.Type == "ImageNotFoundException" {
			return nil
		}
		return err
	}
	if len(desc.ImageDetails) == 1 && len(desc.ImageDetails[0].ImageTags) == 0 {
		_, err = c.batchDelete(ctx, repository, imageID{ImageDigest: digest})
	}
	return err
}

// batchDelete is BatchDeleteImage of one image, by tag or digest: what it
// deleted; nothing, without an error, if it was not there.
func (c *Client) batchDelete(ctx context.Context, repository string, id imageID) ([]imageID, error) {
	var out struct {
		ImageIDs []imageID `json:"imageIds"`
		Failures []struct {
			FailureCode   string `json:"failureCode"`
			FailureReason string `json:"failureReason"`
		} `json:"failures"`
	}
	in := map[string]any{"repositoryName": repository, "imageIds": []imageID{id}}
	if err := c.call(ctx, "BatchDeleteImage", in, &out); err != nil {
		return nil, err
	}
	for _, f := range out.Failures {
		if f.FailureCode != "ImageNotFound" && f.FailureCode != "ImageTagDoesNotMatchDigest" {
			return nil, fmt.Errorf("%s %v: %s %s", repository, id, f.FailureCode, f.FailureReason)
		}
	}
	return out.ImageIDs, nil
}

func (c *Client) call(ctx context.Context, op string, in, out any) error {
	body, err := json.Marshal(in)
	if err != nil {
		return err
	}
	u, err := url.Parse(c.Endpoint)
	if err != nil || u.Host == "" {
		return fmt.Errorf("ECR endpoint %q is not a URL", c.Endpoint)
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(c.Endpoint, "/")+"/", bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-amz-json-1.1")
	req.Header.Set("X-Amz-Target", "AmazonEC2ContainerRegistry_V20150921."+op)
	c.sign(req, u.Host, body)
	hc := c.HTTP
	if hc == nil {
		hc = &http.Client{Transport: &http.Transport{Proxy: nil}, Timeout: 30 * time.Second}
	}
	resp, err := hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK {
		e := &Error{Status: resp.StatusCode}
		json.Unmarshal(raw, e)
		if i := strings.LastIndex(e.Type, "#"); i >= 0 {
			e.Type = e.Type[i+1:]
		}
		return e
	}
	if out != nil {
		return json.Unmarshal(raw, out)
	}
	return nil
}

// sign adds Signature Version 4 headers for service ecr.
func (c *Client) sign(req *http.Request, host string, body []byte) {
	now := time.Now
	if c.Now != nil {
		now = c.Now
	}
	t := now().UTC()
	amzDate, day := t.Format("20060102T150405Z"), t.Format("20060102")
	payload := sha256.Sum256(body)
	req.Header.Set("X-Amz-Date", amzDate)
	req.Header.Set("Host", host)
	names := []string{"content-type", "host", "x-amz-date", "x-amz-target"}
	if c.SessionToken != "" {
		req.Header.Set("X-Amz-Security-Token", c.SessionToken)
		names = []string{"content-type", "host", "x-amz-date", "x-amz-security-token", "x-amz-target"}
	}
	var canonHeaders strings.Builder
	for _, n := range names {
		v := req.Header.Get(n)
		if n == "host" {
			v = host
		}
		canonHeaders.WriteString(n + ":" + strings.TrimSpace(v) + "\n")
	}
	signed := strings.Join(names, ";")
	canonical := strings.Join([]string{"POST", "/", "", canonHeaders.String(), signed, hex.EncodeToString(payload[:])}, "\n")
	scope := day + "/" + c.Region + "/ecr/aws4_request"
	cr := sha256.Sum256([]byte(canonical))
	toSign := "AWS4-HMAC-SHA256\n" + amzDate + "\n" + scope + "\n" + hex.EncodeToString(cr[:])
	key := mac([]byte("AWS4"+c.SecretAccessKey), day)
	key = mac(key, c.Region)
	key = mac(key, "ecr")
	key = mac(key, "aws4_request")
	sig := hex.EncodeToString(mac(key, toSign))
	req.Header.Set("Authorization", "AWS4-HMAC-SHA256 Credential="+c.AccessKeyID+"/"+scope+", SignedHeaders="+signed+", Signature="+sig)
}

func mac(key []byte, s string) []byte {
	h := hmac.New(sha256.New, key)
	h.Write([]byte(s))
	return h.Sum(nil)
}
