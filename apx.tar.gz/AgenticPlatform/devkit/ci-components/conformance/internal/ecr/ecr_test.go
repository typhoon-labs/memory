package ecr

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestDeleteTag(t *testing.T) {
	var got map[string]any
	var target, auth string
	var calls []string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		target, auth = r.Header.Get("X-Amz-Target"), r.Header.Get("Authorization")
		raw, _ := io.ReadAll(r.Body)
		calls = append(calls, strings.TrimPrefix(target, "AmazonEC2ContainerRegistry_V20150921.")+" "+string(raw))
		if strings.HasSuffix(target, ".DescribeImages") {
			// The image p1-j2 named has no tag left; shared's has another.
			if strings.Contains(string(raw), "sha256:11") {
				io.WriteString(w, `{"imageDetails":[{"imageDigest":"sha256:11","imageTags":["other"]}]}`)
				return
			}
			io.WriteString(w, `{"imageDetails":[{"imageDigest":"sha256:00","imageTags":[]}]}`)
			return
		}
		json.Unmarshal(raw, &got)
		if strings.Contains(string(raw), "shared") {
			io.WriteString(w, `{"imageIds":[{"imageTag":"shared","imageDigest":"sha256:11"}],"failures":[]}`)
			return
		}
		if strings.Contains(string(raw), "gone") {
			io.WriteString(w, `{"imageIds":[],"failures":[{"imageId":{"imageTag":"gone"},"failureCode":"ImageNotFound","failureReason":"Requested image not found"}]}`)
			return
		}
		if strings.Contains(string(raw), "denied") {
			w.WriteHeader(http.StatusBadRequest)
			io.WriteString(w, `{"__type":"com.amazonaws#AccessDeniedException","message":"no"}`)
			return
		}
		io.WriteString(w, `{"imageIds":[{"imageTag":"p1-j2","imageDigest":"sha256:00"}],"failures":[]}`)
	}))
	defer srv.Close()
	c := &Client{Endpoint: srv.URL, Region: "us-east-1", AccessKeyID: "test", SecretAccessKey: "test"}
	if err := c.DeleteTag(context.Background(), "ci-scratch/app", "p1-j2"); err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(auth, "/us-east-1/ecr/aws4_request") {
		t.Errorf("authorization %q", auth)
	}
	// The tag, then its image, which no tag names any more.
	if len(calls) != 3 || !strings.Contains(calls[0], `BatchDeleteImage {"imageIds":[{"imageTag":"p1-j2"}],"repositoryName":"ci-scratch/app"}`) ||
		!strings.HasPrefix(calls[1], "DescribeImages") || !strings.Contains(calls[2], `BatchDeleteImage {"imageIds":[{"imageDigest":"sha256:00"}],"repositoryName":"ci-scratch/app"}`) {
		t.Errorf("calls: %q", calls)
	}
	calls = nil
	if err := c.DeleteTag(context.Background(), "ci-scratch/app", "shared"); err != nil || len(calls) != 2 {
		t.Errorf("an image another tag still names is kept: %v %q", err, calls)
	}
	if err := c.DeleteTag(context.Background(), "ci-scratch/app", "gone"); err != nil {
		t.Errorf("a tag already gone: %v", err)
	}
	if err := c.DeleteTag(context.Background(), "ci-scratch/app", "denied"); err == nil || !strings.Contains(err.Error(), "AccessDeniedException") {
		t.Errorf("a refusal: %v", err)
	}
}

func toJSON(v any) string { b, _ := json.Marshal(v); return string(b) }
