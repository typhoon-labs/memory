package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"syscall"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/registry"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/kagent"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// runKagent is the kagent profile (suites/kagent), against one kagent
// agent, with the platform suites' configuration for the environment. In
// the cluster it is the kagent-profile release's Helm test. It is not
// strict unless the configuration says so: on a kernel where no actor can
// start, the actor cases skip.
func runKagent(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("conform kagent", flag.ContinueOnError)
	fs.SetOutput(stderr)
	configPath := fs.String("config", os.Getenv("CONFORMANCE_CONFIG"), "the environment's configuration, as the platform suites take it")
	profilePath := fs.String("profile", os.Getenv("CONFORMANCE_PROFILE"), "the agent under test (JSON)")
	runPat := fs.String("run", "", "run only the cases whose ID matches")
	skipPat := fs.String("skip", "", "leave out the cases whose ID matches")
	junit := fs.String("junit", "", "write a JUnit report here")
	jsonOut := fs.String("json", "", "write the results as JSON here")
	list := fs.Bool("list", false, "list the cases, then exit")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	cases, err := runner.Select(kagent.Cases(), *runPat, *skipPat)
	if err != nil {
		fmt.Fprintf(stderr, "conform kagent: %v\n", err)
		return 2
	}
	if *list {
		for _, k := range cases {
			fmt.Fprintf(stdout, "%s\t%s\n", k.ID, k.Layer)
		}
		return 0
	}
	if *profilePath == "" {
		fmt.Fprintln(stderr, "conform kagent: -profile is required")
		return 2
	}
	profile, err := kagent.LoadProfile(*profilePath)
	if err != nil {
		fmt.Fprintf(stderr, "conform kagent: %v\n", err)
		return 2
	}
	cfg, err := platform.LoadConfig(*configPath)
	if err != nil {
		fmt.Fprintf(stderr, "conform kagent: %v\n", err)
		return 2
	}
	// The personas sign in with the agent's route's scope, and the K2
	// fixture agents', too: a refresh may only narrow (T20).
	cfg.SignIn.Scopes = append(cfg.SignIn.Scopes, profile.Scope)
	for _, a := range []string{profile.Actor.K2.Admitted, profile.Actor.K2.Refused} {
		if a != "" {
			cfg.SignIn.Scopes = append(cfg.SignIn.Scopes, "a2a/"+a)
		}
	}
	penv, err := platform.NewEnv(cfg, platform.Options{})
	if err != nil {
		fmt.Fprintf(stderr, "conform kagent: %v\n", err)
		return 2
	}
	env := &kagent.Env{P: penv, Profile: profile, Registry: &registry.Client{PlainHTTP: profile.PlainHTTP}}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	fmt.Fprintf(stdout, "conform kagent: %d cases for %s, run %s\n", len(cases), profile.Agent, penv.RunID)
	var results []runner.Result
	for _, k := range cases {
		r := runner.Run(ctx, env, k)
		runner.Text(stdout, []runner.Result{r})
		results = append(results, r)
		if ctx.Err() != nil {
			break
		}
	}
	ok, summary := runner.Verdict(results, cfg.Strict)
	fmt.Fprintf(stdout, "conform kagent: %s\n", summary)
	if code := writeReports(results, *junit, *jsonOut, stderr); code != 0 {
		return code
	}
	if !ok {
		return 1
	}
	return 0
}
