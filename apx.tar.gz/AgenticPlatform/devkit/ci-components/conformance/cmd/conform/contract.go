package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kms"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/registry"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload"
)

func envOr(name, def string) string {
	if v := os.Getenv(name); v != "" {
		return v
	}
	return def
}

// readWorkload reads workload.yaml out of the image under test.
func readWorkload(ctx context.Context, image string, plain bool, helm string) (*contract.Workload, error) {
	reg := &registry.Client{PlainHTTP: plain}
	raw, err := reg.ReadFile(ctx, image, "linux/"+runtime.GOARCH, contract.WorkloadPath, 1<<20)
	if err != nil {
		return nil, fmt.Errorf("the workload's %s: %w (the build component copies workload.yaml there)", contract.WorkloadPath, err)
	}
	return contract.ParseWorkload(raw, helm)
}

// runWorkloadInfo prints what the component's first job needs of an
// image's workload.yaml, as dotenv lines.
func runWorkloadInfo(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("conform workload-info", flag.ContinueOnError)
	fs.SetOutput(stderr)
	image := fs.String("image", "", "the image, by digest")
	plain := fs.Bool("plain-http", envOr("CONFORMANCE_REGISTRY_PLAIN_HTTP", "true") == "true", "speak plain HTTP to the registry")
	helm := fs.String("helm", envOr("CONFORMANCE_HELM", "/usr/local/bin/helm"), "helm, which reads YAML")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	w, err := readWorkload(context.Background(), *image, *plain, *helm)
	if err != nil {
		fmt.Fprintf(stderr, "conform: %v\n", err)
		return 2
	}
	fmt.Fprintf(stdout, "CONFORMANCE_WORKLOAD_NAME=%s\nCONFORMANCE_WORKLOAD_KIND=%s\nCONFORMANCE_WORKLOAD_LEVEL=%s\n", w.Name, w.Kind, w.Level())
	return 0
}

// runContract is the contract stage: it starts the harness, waits for the
// workload's service, runs the workload suites against it and reports.
func runContract(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("conform contract", flag.ContinueOnError)
	fs.SetOutput(stderr)
	o := struct {
		image, url, profile, protocol, stsImage, alias, kmsEndpoint, region, listen, host, kubeListen, otlp, otlpGRPC string
		fakeModel, collector, helm, actorFile, domain, cluster, limits, audience, release, service, dir               string
		junit, json, run, skip                                                                                        string
		plain, strict                                                                                                 bool
		ttl                                                                                                           int
		ready                                                                                                         time.Duration
	}{}
	fs.StringVar(&o.image, "workload-image", os.Getenv("CONFORMANCE_WORKLOAD_IMAGE"), "the image under test, by digest, as the service runs it")
	workloadFile := fs.String("workload-file", "", "read workload.yaml from this file instead of the image, for a run outside CI")
	fs.StringVar(&o.url, "workload-url", os.Getenv("CONFORMANCE_WORKLOAD_URL"), "the workload's base URL, such as http://workload-<job>:8080")
	fs.StringVar(&o.profile, "profile", envOr("CONFORMANCE_PROFILE", "l1"), "l1 or l2: the least level to run; workload.yaml may raise it")
	fs.StringVar(&o.protocol, "protocol", envOr("CONFORMANCE_PROTOCOL", ""), "a2a or mcp: must match workload.yaml's kind")
	fs.StringVar(&o.stsImage, "sts-image", os.Getenv("CONFORMANCE_STS_IMAGE"), "delegation-sts's image, by digest")
	fs.StringVar(&o.alias, "sts-signing-alias", envOr("CONFORMANCE_STS_SIGNING_ALIAS", "alias/conformance/sts-signing"), "the KMS alias the stage's STS signs through")
	fs.StringVar(&o.kmsEndpoint, "kms-endpoint", envOr("CONFORMANCE_KMS_ENDPOINT", "http://floci:4566"), "KMS's endpoint")
	fs.StringVar(&o.region, "region", envOr("AWS_REGION", "us-east-1"), "the AWS region")
	fs.BoolVar(&o.plain, "plain-http", envOr("CONFORMANCE_REGISTRY_PLAIN_HTTP", "true") == "true", "speak plain HTTP to the registries")
	fs.StringVar(&o.listen, "listen", envOr("CONFORMANCE_LISTEN", ":18080"), "the harness's front")
	fs.StringVar(&o.host, "host", os.Getenv("CONFORMANCE_HOST"), "the job container's host name, as the workload's service reaches it")
	fs.StringVar(&o.kubeListen, "kube-listen", "127.0.0.1:18081", "the fake TokenReview API")
	fs.StringVar(&o.otlp, "otlp-listen", envOr("CONFORMANCE_OTLP_LISTEN", ":4318"), "the collector's OTLP/HTTP receiver")
	fs.StringVar(&o.otlpGRPC, "otlp-grpc-listen", envOr("CONFORMANCE_OTLP_GRPC_LISTEN", ":4317"), "the collector's OTLP/gRPC receiver")
	fs.StringVar(&o.fakeModel, "fake-model", envOr("CONFORMANCE_FAKE_MODEL", "/usr/local/bin/fake-model"), "the fake model server's binary")
	fs.StringVar(&o.collector, "collector", envOr("CONFORMANCE_COLLECTOR", "/usr/local/bin/otelcol"), "the collector's binary")
	fs.StringVar(&o.helm, "helm", envOr("CONFORMANCE_HELM", "/usr/local/bin/helm"), "helm, which reads YAML")
	fs.StringVar(&o.actorFile, "actor-token-file", os.Getenv("CONFORMANCE_ACTOR_TOKEN_FILE"), "where the workload reads its actor token (AGENTIC_ACTOR_TOKEN_FILE)")
	fs.StringVar(&o.domain, "domain", envOr("CONFORMANCE_DOMAIN", "agentic.internal"), "the platform domain routes expand with")
	fs.StringVar(&o.cluster, "cluster", envOr("CONFORMANCE_CLUSTER", "agentic-local"), "the cluster actor names carry")
	fs.StringVar(&o.limits, "limits", os.Getenv("CONFORMANCE_LIMITS"), "AGENTIC_LIMIT_* as the stage set them: model_calls=4,tool_calls=2,...")
	fs.IntVar(&o.ttl, "approval-ttl", atoi(envOr("CONFORMANCE_APPROVAL_TTL_SECONDS", "5")), "AGENTIC_APPROVAL_TTL_SECONDS as set")
	fs.StringVar(&o.audience, "approval-audience", os.Getenv("CONFORMANCE_APPROVAL_AUDIENCE"), "AGENTIC_APPROVAL_AUDIENCE as set")
	fs.StringVar(&o.release, "release-id", os.Getenv("CONFORMANCE_RELEASE_ID"), "platform.release.id as set in OTEL_RESOURCE_ATTRIBUTES")
	fs.StringVar(&o.service, "service-name", os.Getenv("CONFORMANCE_SERVICE_NAME"), "OTEL_SERVICE_NAME as set; default the workload's name")
	fs.StringVar(&o.dir, "dir", envOr("CONFORMANCE_DIR", "out/conformance"), "working files and reports")
	fs.DurationVar(&o.ready, "ready-timeout", 3*time.Minute, "how long the workload's service may take to answer /readyz")
	fs.StringVar(&o.junit, "junit", os.Getenv("CONFORMANCE_REPORT"), "write a JUnit report here")
	fs.StringVar(&o.json, "json", "", "write the results as JSON here")
	fs.StringVar(&o.run, "run", "", "run only the cases whose ID matches")
	fs.StringVar(&o.skip, "skip", "", "leave out the cases whose ID matches")
	fs.BoolVar(&o.strict, "strict", true, "a skipped case fails the run")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	fail := func(format string, a ...any) int {
		fmt.Fprintf(stderr, "conform contract: "+format+"\n", a...)
		return 2
	}
	if (o.image == "" && *workloadFile == "") || o.url == "" || o.stsImage == "" || o.host == "" {
		return fail("-workload-image (or -workload-file), -workload-url, -sts-image and -host are required")
	}
	var w *contract.Workload
	var err error
	if *workloadFile != "" {
		var raw []byte
		if raw, err = os.ReadFile(*workloadFile); err == nil {
			w, err = contract.ParseWorkload(raw, o.helm)
		}
	} else {
		w, err = readWorkload(ctx, o.image, o.plain, o.helm)
	}
	if err != nil {
		return fail("%v", err)
	}
	switch {
	case o.protocol == "a2a" && w.Kind != "agent", o.protocol == "mcp" && w.Kind != "mcp-server":
		return fail("protocol %s, but workload.yaml's %s is a %s", o.protocol, w.Name, w.Kind)
	case w.Kind == "workflow" || w.Runtime == "kagent":
		return fail("%s is a %s on %s: the contract stage runs agents and MCP servers in containers; the kagent profile is its own", w.Name, w.Kind, w.Runtime)
	}
	level := strings.ToUpper(o.profile)
	if l := w.Level(); l > level {
		level = l
	}
	if level > "L2" {
		fmt.Fprintf(stdout, "conform contract: %s is %s; the contract stage runs L1 and L2 (L3's durability suite comes later)\n", w.Name, level)
		level = "L2"
	}
	limits := map[string]int{}
	for _, kv := range strings.Split(o.limits, ",") {
		if k, v, ok := strings.Cut(kv, "="); ok {
			limits[strings.TrimSpace(k)] = atoi(v)
		}
	}
	dir, _ := filepath.Abs(o.dir)
	os.MkdirAll(dir, 0o755)
	fmt.Fprintf(stdout, "conform contract: %s (%s, %s), %s, at %s\n", w.Name, w.Kind, level, o.image, o.url)

	stsBin := filepath.Join(dir, "bin", "delegation-sts")
	reg := &registry.Client{PlainHTTP: o.plain}
	bin, err := reg.ReadFile(ctx, o.stsImage, "linux/"+runtime.GOARCH, "/delegation-sts", 256<<20)
	if err != nil {
		return fail("the STS's binary from %s: %v", o.stsImage, err)
	}
	os.MkdirAll(filepath.Dir(stsBin), 0o755)
	if err := os.WriteFile(stsBin, bin, 0o755); err != nil {
		return fail("%v", err)
	}
	port := "18080"
	if _, p, ok := strings.Cut(o.listen, ":"); ok && p != "" {
		port = p
	}
	denied := contract.NewPerson("conformance")
	log := &lineLog{w: stderr}
	h, err := contract.Start(ctx, contract.Options{
		Dir: dir, Listen: o.listen, BaseURL: "http://" + o.host + ":" + port, KubeListen: o.kubeListen,
		OTLPListen: o.otlp, OTLPGRPCListen: o.otlpGRPC, Domain: o.domain, Cluster: o.cluster, Workload: w,
		ActorTokenFile: o.actorFile, FakeModel: o.fakeModel, FakeModelPorts: [2]int{18090, 18091},
		STSBinary: stsBin, STSPorts: [3]int{18443, 18444, 18445}, SigningAlias: o.alias,
		KMS: &kms.Client{Endpoint: o.kmsEndpoint, Region: o.region, AccessKeyID: envOr("AWS_ACCESS_KEY_ID", "test"),
			SecretAccessKey: envOr("AWS_SECRET_ACCESS_KEY", "test"), SessionToken: os.Getenv("AWS_SESSION_TOKEN")},
		Collector: o.collector, Denied: []string{denied.Sub}, Log: log,
		DatabaseListen: ":15432", DatabaseTarget: databaseTarget(stdout),
	})
	if err != nil {
		return fail("the harness: %v", err)
	}
	defer h.Close()
	if err := waitReady(ctx, o.url, o.ready); err != nil {
		return fail("%v", err)
	}
	service := o.service
	if service == "" || strings.Contains(service, "$") {
		service = w.Name
	}
	// The approval route's audience is the server's developer-deployment
	// route unless the stage set another (B5's seams).
	if o.audience == "" || strings.Contains(o.audience, "$") {
		o.audience = "https://gateway." + o.domain + "/mcp/" + w.Name
	}
	env := &workload.Env{RunID: strings.ToLower(contract.UUID()[:8]), Workload: w, Level: level, URL: strings.TrimRight(o.url, "/"), H: h,
		S: workload.Settings{Domain: o.domain, Cluster: o.cluster, Limits: limits, ApprovalTTL: time.Duration(o.ttl) * time.Second,
			ApprovalAudience: o.audience, ReleaseID: o.release, ServiceName: service},
		HTTP: &outcome.Client{}, Denied: denied}
	cases, err := runner.Select(workload.Cases(env), o.run, o.skip)
	if err != nil {
		return fail("%v", err)
	}
	var results []runner.Result
	for _, k := range cases {
		r := runner.Run(ctx, env, k)
		runner.Text(stdout, []runner.Result{r})
		results = append(results, r)
		if ctx.Err() != nil {
			break
		}
	}
	ok, summary := runner.Verdict(results, o.strict)
	fmt.Fprintf(stdout, "conform contract: %s\n", summary)
	if code := writeReports(results, o.junit, o.json, stderr); code != 0 {
		return code
	}
	if !ok {
		return 1
	}
	return 0
}

// databaseTarget is the stage's PostgreSQL, when the workload has one:
// the harness's proxy forwards to it.
func databaseTarget(stdout io.Writer) string {
	url, alias := os.Getenv("CONFORMANCE_DATABASE_URL"), os.Getenv("CONFORMANCE_DATABASE_ALIAS")
	if url == "" || alias == "" {
		return ""
	}
	if strings.Contains(url, "$") {
		fmt.Fprintln(stdout, "conform contract: warning: the database URL holds an unexpanded variable; the workload may not reach its proxy")
	}
	return alias + ":5432"
}

func atoi(s string) int { n, _ := strconv.Atoi(strings.TrimSpace(s)); return n }

// waitReady waits for the workload's /readyz, which a service container
// answers once it has started.
func waitReady(ctx context.Context, base string, timeout time.Duration) error {
	cl := &outcome.Client{}
	deadline := time.Now().Add(timeout)
	var last outcome.Outcome
	for time.Now().Before(deadline) {
		last = cl.Do(ctx, outcome.Request{Method: "GET", URL: strings.TrimRight(base, "/") + "/readyz", Timeout: outcome.Of(5 * time.Second)})
		if last.Kind == outcome.Response && last.Status == 200 {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(2 * time.Second):
		}
	}
	return errors.New("the workload did not answer /readyz within " + timeout.String() + ": " + last.String())
}

// lineLog passes the harness's children's log lines on.
type lineLog struct{ w io.Writer }

func (l *lineLog) Write(b []byte) (int, error) { return l.w.Write(b) }
