// Command conform is the conformance runner (design/conformance.md): it
// runs the platform-controls suites and, from build phase B3, the telemetry
// group against an environment, and from B5 the workload suites in a
// workload's contract stage (conform contract), and reports
// each case as text on standard output, and as JUnit and JSON when asked.
// It exits 0 when every selected case passed (in strict mode, none
// skipped), 1 when one failed, and 2 when it could not run.
//
//	conform -config cluster.json [-suite gateway-path,bypass,delegation,telemetry]
//	        [-run REGEXP] [-skip REGEXP] [-junit FILE] [-json FILE] [-list]
//	conform contract [flags]      # the contract stage (contract.go); flags default from CONFORMANCE_*
//	conform integration -config cluster.json -workloads workloads.json   # the workload suites' integration stage
//	conform kagent -config cluster.json -profile profile.json            # the kagent profile, of one kagent agent
//	conform scratch-delete -endpoint URL -repository REPO -tag TAG        # the contract stage's scratch copy, deleted
//	conform workload-info -image REF
//	conform standin-workload      # the stand-in workload, configured as a workload is
//	conform version               # the suites' version, as a conformance attestation records it
//
// In the cluster it is the platform-conformance release's Helm test
// (chart/, design/repositories.md: platform/95-conformance/).
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"slices"
	"strings"
	"syscall"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

func main() { os.Exit(run(os.Args[1:], os.Stdout, os.Stderr)) }

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) > 0 {
		switch args[0] {
		case "contract":
			return runContract(args[1:], stdout, stderr)
		case "integration":
			return runIntegration(args[1:], stdout, stderr)
		case "kagent":
			return runKagent(args[1:], stdout, stderr)
		case "scratch-delete":
			return runScratchDelete(args[1:], stdout, stderr)
		case "workload-info":
			return runWorkloadInfo(args[1:], stdout, stderr)
		case "standin-workload":
			return runStandin(args[1:], stderr)
		case "version":
			fmt.Fprintln(stdout, runner.Version())
			return 0
		}
	}
	fs := flag.NewFlagSet("conform", flag.ContinueOnError)
	fs.SetOutput(stderr)
	configPath := fs.String("config", os.Getenv("CONFORMANCE_CONFIG"), "the run's configuration (JSON); default $CONFORMANCE_CONFIG")
	suites := fs.String("suite", strings.Join(platform.Suites, ","), "the suites to run, comma-separated")
	runPat := fs.String("run", "", "run only the cases whose ID matches this regular expression")
	skipPat := fs.String("skip", "", "leave out the cases whose ID matches this regular expression")
	junit := fs.String("junit", "", "write a JUnit report here")
	jsonOut := fs.String("json", "", "write the results as JSON here")
	list := fs.Bool("list", false, "list the cases, their layers and needs, and whether they need the cluster, then exit")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	want := strings.Split(*suites, ",")
	for _, s := range want {
		if !slices.Contains(platform.Suites, s) {
			fmt.Fprintf(stderr, "conform: unknown suite %q; the suites are %s\n", s, strings.Join(platform.Suites, ", "))
			return 2
		}
	}
	var cases []platform.Case
	for _, k := range platform.Cases() {
		if slices.Contains(want, k.Suite) {
			cases = append(cases, k)
		}
	}
	cases, err := runner.Select(cases, *runPat, *skipPat)
	if err != nil {
		fmt.Fprintf(stderr, "conform: %v\n", err)
		return 2
	}
	if *list {
		for _, k := range cases {
			where := "anywhere"
			if k.Cluster {
				where = "cluster"
			}
			layer := k.Layer
			if layer == "" {
				layer = "allowed path"
			}
			var needs []string
			for _, n := range k.Needs {
				needs = append(needs, string(n))
			}
			fmt.Fprintf(stdout, "%s\t%s\t%s\t%s\n", k.ID, layer, where, strings.Join(needs, ","))
		}
		return 0
	}
	if *configPath == "" {
		fmt.Fprintln(stderr, "conform: -config is required (or $CONFORMANCE_CONFIG)")
		return 2
	}
	cfg, err := platform.LoadConfig(*configPath)
	if err != nil {
		fmt.Fprintf(stderr, "conform: %v\n", err)
		return 2
	}
	env, err := platform.NewEnv(cfg, platform.Options{})
	if err != nil {
		fmt.Fprintf(stderr, "conform: %v\n", err)
		return 2
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	fmt.Fprintf(stdout, "conform: %d cases, run %s, against %s and %s\n", len(cases), env.RunID, cfg.Gateways["gateway"], cfg.Gateways["workloads-gateway"])
	var results []runner.Result
	for _, k := range cases {
		r := runner.Run(ctx, env, k)
		runner.Text(stdout, []runner.Result{r})
		results = append(results, r)
		if ctx.Err() != nil {
			break
		}
	}
	ok, summary := runner.Verdict(results, cfg.Strict)
	fmt.Fprintf(stdout, "conform: %s\n", summary)
	if code := writeReports(results, *junit, *jsonOut, stderr); code != 0 {
		return code
	}
	if !ok {
		return 1
	}
	return 0
}

// writeReports writes the JUnit and JSON reports asked for.
func writeReports(results []runner.Result, junit, jsonOut string, stderr io.Writer) int {
	for path, write := range map[string]func(io.Writer, []runner.Result) error{junit: runner.JUnit, jsonOut: runner.JSON} {
		if path == "" {
			continue
		}
		os.MkdirAll(filepath.Dir(path), 0o755)
		f, err := os.Create(path)
		if err == nil {
			err = write(f, results)
			if cerr := f.Close(); err == nil {
				err = cerr
			}
		}
		if err != nil {
			fmt.Fprintf(stderr, "conform: writing %s: %v\n", path, err)
			return 2
		}
	}
	return 0
}
