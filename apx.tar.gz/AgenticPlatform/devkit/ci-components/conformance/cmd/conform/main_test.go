package main

import (
	"bytes"
	"strings"
	"testing"
)

func TestList(t *testing.T) {
	var out, errs bytes.Buffer
	if code := run([]string{"-list", "-suite", "bypass", "-run", "admission"}, &out, &errs); code != 0 {
		t.Fatalf("exit %d: %s", code, errs.String())
	}
	lines := strings.Split(strings.TrimSpace(out.String()), "\n")
	// Eight cases, and from B6 image-verification's nine, one per fixture.
	if len(lines) != 17 || strings.Count(out.String(), "bypass/admission/image-verification/") != 9 ||
		!strings.HasPrefix(lines[0], "bypass/admission/") || !strings.Contains(lines[0], "\tadmission\tcluster\t") {
		t.Errorf("list:\n%s", out.String())
	}
}

func TestUsage(t *testing.T) {
	var out, errs bytes.Buffer
	if code := run([]string{}, &out, &errs); code != 2 || !strings.Contains(errs.String(), "-config is required") {
		t.Errorf("no config: exit %d, %s", code, errs.String())
	}
	if code := run([]string{"-suite", "nope", "-list"}, &out, &errs); code != 2 {
		t.Errorf("an unknown suite: exit %d", code)
	}
}
