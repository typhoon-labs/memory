package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"syscall"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload"
)

// runIntegration is the workload suites' integration stage: the cases
// that need the platform around a deployed workload, with the platform
// suites' configuration for the environment and a list of the workloads.
// In the cluster it is the workload-conformance release's Helm test.
func runIntegration(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("conform integration", flag.ContinueOnError)
	fs.SetOutput(stderr)
	configPath := fs.String("config", os.Getenv("CONFORMANCE_CONFIG"), "the environment's configuration, as the platform suites take it")
	workloadsPath := fs.String("workloads", os.Getenv("CONFORMANCE_WORKLOADS"), "the deployed workloads to check (JSON)")
	runPat := fs.String("run", "", "run only the cases whose ID matches")
	skipPat := fs.String("skip", "", "leave out the cases whose ID matches")
	junit := fs.String("junit", "", "write a JUnit report here")
	jsonOut := fs.String("json", "", "write the results as JSON here")
	list := fs.Bool("list", false, "list the cases, then exit")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	if *workloadsPath == "" {
		fmt.Fprintln(stderr, "conform integration: -workloads is required")
		return 2
	}
	targets, err := workload.LoadTargets(*workloadsPath)
	if err != nil {
		fmt.Fprintf(stderr, "conform integration: %v\n", err)
		return 2
	}
	cases, err := runner.Select(workload.IntegrationCases(targets), *runPat, *skipPat)
	if err != nil {
		fmt.Fprintf(stderr, "conform integration: %v\n", err)
		return 2
	}
	if *list {
		for _, k := range cases {
			fmt.Fprintf(stdout, "%s\t%s\n", k.ID, k.Layer)
		}
		return 0
	}
	cfg, err := platform.LoadConfig(*configPath)
	if err != nil {
		fmt.Fprintf(stderr, "conform integration: %v\n", err)
		return 2
	}
	// The personas sign in with the workloads' routes' scopes too: a
	// refresh may only narrow what the sign-in asked for (T20).
	for _, t := range targets {
		cfg.SignIn.Scopes = append(cfg.SignIn.Scopes, t.Scope, t.OtherScope)
	}
	penv, err := platform.NewEnv(cfg, platform.Options{})
	if err != nil {
		fmt.Fprintf(stderr, "conform integration: %v\n", err)
		return 2
	}
	env := &workload.Integration{P: penv, Targets: targets}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	fmt.Fprintf(stdout, "conform integration: %d cases for %d workloads, run %s\n", len(cases), len(targets), penv.RunID)
	var results []runner.Result
	for _, k := range cases {
		r := runner.Run(ctx, env, k)
		runner.Text(stdout, []runner.Result{r})
		results = append(results, r)
		if ctx.Err() != nil {
			break
		}
	}
	ok, summary := runner.Verdict(results, cfg.Strict)
	fmt.Fprintf(stdout, "conform integration: %s\n", summary)
	if code := writeReports(results, *junit, *jsonOut, stderr); code != 0 {
		return code
	}
	if !ok {
		return 1
	}
	return 0
}
