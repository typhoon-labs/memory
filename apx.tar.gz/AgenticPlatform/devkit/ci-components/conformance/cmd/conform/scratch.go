package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"os"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/ecr"
)

// runScratchDelete deletes the tag the contract stage pushed to the
// project's scratch repository (templates/conformance), at the end of
// its jobs, pass or fail, so that a pipeline leaves nothing behind. A tag
// already gone is no error; any other failure exits 1, which the jobs'
// after_script reports without failing the job.
func runScratchDelete(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("conform scratch-delete", flag.ContinueOnError)
	fs.SetOutput(stderr)
	endpoint := fs.String("endpoint", os.Getenv("CONFORMANCE_SCRATCH_ENDPOINT"), "ECR's API endpoint for the scratch repository")
	region := fs.String("region", envOr("AWS_REGION", "us-east-1"), "its region")
	repository := fs.String("repository", os.Getenv("CONFORMANCE_SCRATCH_REPOSITORY"), "the scratch repository")
	tag := fs.String("tag", os.Getenv("CONFORMANCE_SCRATCH_TAG"), "the tag to delete")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	if *endpoint == "" || *repository == "" || *tag == "" {
		fmt.Fprintln(stderr, "conform scratch-delete: -endpoint, -repository and -tag are required")
		return 2
	}
	// floci takes any credentials; with AWS, the job's.
	c := &ecr.Client{Endpoint: *endpoint, Region: *region, AccessKeyID: envOr("AWS_ACCESS_KEY_ID", "test"),
		SecretAccessKey: envOr("AWS_SECRET_ACCESS_KEY", "test"), SessionToken: os.Getenv("AWS_SESSION_TOKEN")}
	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()
	if err := c.DeleteTag(ctx, *repository, *tag); err != nil {
		fmt.Fprintf(stderr, "conform scratch-delete: %v\n", err)
		return 1
	}
	fmt.Fprintf(stdout, "conform scratch-delete: deleted %s:%s\n", *repository, *tag)
	return 0
}
