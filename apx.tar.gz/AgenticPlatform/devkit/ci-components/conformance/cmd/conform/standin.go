package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload/standin"
)

// runStandin serves the stand-in workload, configured by its environment
// as a workload is (AGENTIC_*, OTEL_*, /etc/agentic/workload.yaml), plus
// STANDIN_FAULTS. The conformance component's own pipeline runs it as the
// workload under test, honest and faulty.
func runStandin(args []string, stderr io.Writer) int {
	cfg, err := standin.FromEnv(os.Getenv)
	if err != nil {
		fmt.Fprintf(stderr, "standin-workload: %v\n", err)
		return 2
	}
	fmt.Fprintf(stderr, "standin-workload: %s (%s) on %s, faults [%s]\n", cfg.Workload.Name, cfg.Workload.Kind, cfg.Listen, cfg.Faults)
	srv := &http.Server{Addr: cfg.Listen, Handler: standin.New(cfg), ReadHeaderTimeout: 10 * time.Second}
	if err := srv.ListenAndServe(); err != nil {
		fmt.Fprintf(stderr, "standin-workload: %v\n", err)
		return 1
	}
	return 0
}
