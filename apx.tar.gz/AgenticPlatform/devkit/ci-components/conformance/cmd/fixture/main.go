// Command fixture runs one of the platform-controls suites' fixtures
// (plan/local-build.md, "B2 in detail", "The suites' fixtures"), all in one
// image:
//
//	fixture capture-mcp [-listen :8080] [-ops-listen :9090]
//	fixture relay-agent -name relay-agent -token-endpoint URL [-actor-token FILE] [-ca-file FILE]
//	fixture probe [-listen :8080] [-ca-file FILE]
//
// outsider-agent is relay-agent under another name and service account.
// Each logs JSON to standard error and stops gracefully on SIGTERM.
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"sync/atomic"
	"syscall"
	"time"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/probe"
	relayagent "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/relay-agent"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

func main() { os.Exit(run(os.Args[1:], os.Stderr)) }

func env(name, def string) string {
	if v := os.Getenv(name); v != "" {
		return v
	}
	return def
}

func run(args []string, stderr io.Writer) int {
	log := slog.New(slog.NewJSONHandler(stderr, nil))
	if len(args) == 0 {
		fmt.Fprintln(stderr, "usage: fixture capture-mcp|relay-agent|probe [flags]")
		return 2
	}
	fs := flag.NewFlagSet(args[0], flag.ContinueOnError)
	fs.SetOutput(stderr)
	listen := fs.String("listen", env("FIXTURE_LISTEN", ":8080"), "the fixture's port")
	opsListen := fs.String("ops-listen", env("FIXTURE_OPS_LISTEN", ":9090"), "the operations port: health, and capture-mcp's records")
	caFile := fs.String("ca-file", env("FIXTURE_CA_FILE", ""), "a PEM bundle to trust besides the system's: the platform's CA")
	name := fs.String("name", env("FIXTURE_NAME", "relay-agent"), "relay-agent: the name it reports")
	tokenEndpoint := fs.String("token-endpoint", env("FIXTURE_TOKEN_ENDPOINT", ""), "relay-agent: the STS's /token")
	actorToken := fs.String("actor-token", env("FIXTURE_ACTOR_TOKEN", "/var/run/sts/token"), "relay-agent: the projected token for the STS's audience")
	records := fs.Int("records", 10000, "capture-mcp: the records kept")
	if err := fs.Parse(args[1:]); err != nil {
		return 2
	}
	var stopping atomic.Bool
	ready := func() bool { return !stopping.Load() }
	ops := http.NewServeMux()
	ops.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusOK) })
	ops.HandleFunc("GET /readyz", func(w http.ResponseWriter, _ *http.Request) {
		if !ready() {
			w.WriteHeader(http.StatusServiceUnavailable)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	var main http.Handler
	switch args[0] {
	case "capture-mcp":
		s := capturemcp.New(*records, ready)
		main = s.MCPHandler()
		ops.Handle("/requests", s.OpsHandler())
	case "relay-agent":
		if *tokenEndpoint == "" {
			fmt.Fprintln(stderr, "relay-agent: -token-endpoint is required")
			return 2
		}
		cl, err := outcome.NewClient(*caFile)
		if err != nil {
			fmt.Fprintf(stderr, "relay-agent: %v\n", err)
			return 2
		}
		main = (&relayagent.Agent{Name: *name, TokenEndpoint: *tokenEndpoint, ActorTokenFile: *actorToken, HTTP: cl, Log: log}).Handler()
	case "probe":
		cl, err := outcome.NewClient(*caFile)
		if err != nil {
			fmt.Fprintf(stderr, "probe: %v\n", err)
			return 2
		}
		main = (&probe.Server{Client: cl, Log: log}).Handler()
	default:
		fmt.Fprintf(stderr, "fixture: unknown fixture %q: want capture-mcp, relay-agent or probe\n", args[0])
		return 2
	}
	servers := []*http.Server{
		{Addr: *listen, Handler: main, ReadHeaderTimeout: 10 * time.Second},
		{Addr: *opsListen, Handler: ops, ReadHeaderTimeout: 10 * time.Second},
	}
	errs := make(chan error, len(servers))
	for _, s := range servers {
		go func() {
			if err := s.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
				errs <- err
			}
		}()
	}
	log.Info("serving", "fixture", args[0], "listen", *listen, "ops", *opsListen)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	select {
	case err := <-errs:
		log.Error("serving", "error", err)
		return 1
	case <-ctx.Done():
	}
	stopping.Store(true)
	shutdown, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	for _, s := range servers {
		s.Shutdown(shutdown)
	}
	return 0
}
