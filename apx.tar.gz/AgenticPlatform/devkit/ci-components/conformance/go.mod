module gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance

go 1.27.4
