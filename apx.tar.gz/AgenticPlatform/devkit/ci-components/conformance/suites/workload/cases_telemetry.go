package workload

import (
	"encoding/base64"
	"fmt"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
)

const telemetryRow = "Telemetry: spans carry the required resource attributes. Inbound traceparent continues on outbound calls. Prompt text is absent unless content capture is enabled. A canary secret placed in a tool response never appears in exported telemetry"

func telemetryCases(e *Env) []Case {
	cases := []Case{
		{ID: "l1/telemetry/resource-and-task", Suite: "l1/telemetry", Layer: LayerTelemetry, Row: telemetryRow,
			Title: "the request's spans carry service.name, platform.release.id, task.id from Agentic-Task-Id and user.id from the token; none lacks them",
			Run:   resourceAndTask},
		{ID: "l1/telemetry/trace-continues", Suite: "l1/telemetry", Layer: LayerTelemetry, Row: telemetryRow,
			Title: "the inbound traceparent's trace continues in the workload's spans and on every outbound call; no call starts another",
			Run:   traceContinues},
	}
	if e.Agent() && e.CallsOn() {
		cases = append(cases, Case{ID: "l1/telemetry/canary-secret", Suite: "l1/telemetry", Layer: LayerTelemetry, Row: telemetryRow,
			Title: "a canary GitLab token and JWT in a tool's output reach no exported span, event or record, whole or in part; the run's marker beside them reaches the GenAI content",
			Run:   canarySecret})
	}
	if e.Agent() {
		cases = append(cases,
			Case{ID: "l1/telemetry/content-only-genai", Suite: "l1/telemetry", Layer: LayerTelemetry, Row: telemetryRow,
				Title: "prompt text is exported only in the GenAI content attributes, never in a framework's own (gcp.vertex.agent.*), a span name or a log record",
				Run:   contentOnlyGenAI})
	}
	return cases
}

// waitSpans polls the export for the trace's spans, at most 30 seconds:
// the workload's batch delay plus the collector's flush.
func waitSpans(c *C, traceID string, enough func([]contract.Span) bool) []contract.Span {
	var spans []contract.Span
	c.Env.await(c, func() bool {
		snap, err := c.Env.H.Telemetry.Read()
		if err != nil {
			c.Fatalf("reading the collector's export: %v", err)
		}
		spans = nil
		for _, s := range snap.Spans {
			if s.TraceID == traceID {
				spans = append(spans, s)
			}
		}
		return enough(spans)
	})
	return spans
}

// request makes one request of the workload with a task ID and a trace,
// as its protocol has it, and returns them.
func request(c *C, p contract.Person) *Task {
	if c.Env.Agent() {
		return c.Env.Send(c, p, "Say something short.", nil)
	}
	tp, trace, span := Trace()
	t := &Task{ID: "conformance-task-" + randomHex(8), TraceID: trace, SpanID: span, Person: p}
	token := c.Env.Inbound(c, p)
	cl := c.Env.MCP(token, map[string]string{contract.TaskHeader: t.ID, "Traceparent": tp})
	ro := c.Env.Workload.ReadOnlyTools()
	if len(ro) == 0 {
		c.Fatalf("an MCP server without a read-only tool: the telemetry cases call one")
	}
	args := sampleArgs(c.Env.Schemas(c, token)[ro[0]], c.Env.Marker("arg"))
	if r, err := cl.CallTool(c, ro[0], args).Result(); err != nil {
		c.Fatalf("tools/call %s: %v %+v", ro[0], err, r)
	}
	return t
}

func resourceAndTask(c *C) {
	p := contract.NewPerson("conformance")
	t := request(c, p)
	if t.Err != nil {
		c.Fatalf("the request: %v", t.Err)
	}
	// Waits for the evidence, a span of the work done for the task, not the
	// trace's first span: a server's spans arrive in more than one batch.
	spans := waitSpans(c, t.TraceID, func(s []contract.Span) bool {
		for _, x := range s {
			if x.Attributes["task.id"] == t.ID && x.Attributes["user.id"] == p.Sub {
				return true
			}
		}
		return false
	})
	if len(spans) == 0 {
		c.Fatalf("no span of trace %s reached the collector within 30 seconds", t.TraceID)
	}
	// The resource is on every span. The task and the caller are on the
	// spans of the work done for them, of which there is at least one;
	// a span begun before the token was checked, such as a server's, may
	// lack them, but none may name another task or caller.
	tagged := 0
	for _, s := range spans {
		var missing []string
		if s.Resource["service.name"] != c.Env.S.ServiceName {
			missing = append(missing, fmt.Sprintf("service.name %v, not %s", s.Resource["service.name"], c.Env.S.ServiceName))
		}
		if c.Env.S.ReleaseID != "" && s.Resource["platform.release.id"] != c.Env.S.ReleaseID {
			missing = append(missing, fmt.Sprintf("platform.release.id %v, not %s", s.Resource["platform.release.id"], c.Env.S.ReleaseID))
		}
		task, hasTask := s.Attributes["task.id"]
		user, hasUser := s.Attributes["user.id"]
		if hasTask && task != t.ID {
			missing = append(missing, fmt.Sprintf("task.id %v, not the Agentic-Task-Id sent, %s", task, t.ID))
		}
		if hasUser && user != p.Sub {
			missing = append(missing, fmt.Sprintf("user.id %v, not the token's sub", user))
		}
		if task == t.ID && user == p.Sub {
			tagged++
		}
		if len(missing) > 0 {
			c.Errorf("span %q: %s", s.Name, strings.Join(missing, "; "))
		}
	}
	if tagged == 0 {
		c.Errorf("no span of the request's trace carries both task.id %s (the Agentic-Task-Id sent) and user.id from the token", t.ID)
	}
}

func traceContinues(c *C) {
	p := contract.NewPerson("conformance")
	var t *Task
	if c.Env.Agent() && c.Env.CallsOn() {
		t = c.Env.Send(c, p, callOnce(c.Env), contract.Script(func(int, string, []byte) string { return "ok " + contract.End }))
	} else {
		t = request(c, p)
	}
	if t.Err != nil {
		c.Fatalf("the request: %v", t.Err)
	}
	// Waits for the evidence, a child of the inbound span, not the trace's
	// first span: a server's own span, that child, ends last and often
	// reaches the collector in a later batch than the work under it.
	spans := waitSpans(c, t.TraceID, func(s []contract.Span) bool {
		for _, x := range s {
			if x.ParentSpanID == t.SpanID {
				return true
			}
		}
		return false
	})
	child := false
	for _, s := range spans {
		child = child || s.ParentSpanID == t.SpanID
	}
	if !child {
		c.Errorf("no span of the workload is a child of the inbound span %s in trace %s: %d spans of the trace arrived", t.SpanID, t.TraceID, len(spans))
	}
	if !c.Env.Agent() {
		return
	}
	var outbound int
	for _, m := range c.Env.H.ModelCalls() {
		if m.TaskID == t.ID {
			outbound++
			if !strings.Contains(m.Trace, t.TraceID) {
				c.Errorf("a model call of the task carried traceparent %q, not trace %s", m.Trace, t.TraceID)
			}
		}
	}
	for _, call := range c.Env.H.Tools.Calls() {
		if call.TaskID == t.ID {
			outbound++
			if !strings.Contains(call.Trace, t.TraceID) {
				c.Errorf("an MCP call (%s) of the task carried traceparent %q, not trace %s", call.Method, call.Trace, t.TraceID)
			}
		}
	}
	if outbound == 0 {
		c.Errorf("no outbound call could be tied to the task by Agentic-Task-Id, so trace continuity could not be shown")
	}
}

// canary is a marker and two secrets in the shapes the platform's secret
// patterns name, as the platform-controls telemetry group's.
type canary struct {
	marker, text string
	secrets      []string // whole
	cores        []string // their random parts
}

func newCanary(e *Env) canary {
	gitlab := "glpat-" + randomHex(10)
	header := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"ES256","typ":"JWT","kid":"canary-` + randomHex(4) + `"}`))
	payload := base64.RawURLEncoding.EncodeToString([]byte(`{"sub":"canary-` + randomHex(8) + `","jti":"` + randomHex(16) + `"}`))
	sig := base64.RawURLEncoding.EncodeToString([]byte(randomHex(32)))
	jwt := header + "." + payload + "." + sig
	k := canary{marker: e.Marker("canary"), secrets: []string{gitlab, jwt}, cores: []string{strings.TrimPrefix(gitlab, "glpat-"), payload, sig}}
	k.text = k.marker + " returned " + gitlab + " and " + jwt + " done"
	return k
}

func canarySecret(c *C) {
	k := newCanary(c.Env)
	t := c.Env.Send(c, contract.NewPerson("conformance"), callOnce(c.Env), func(int, string, []byte) string { return k.text + " " + contract.End })
	if t.Err != nil || t.Task.Status.State != a2a.Completed {
		c.Fatalf("the task did not complete: %v %s", t.Err, t.Task.Status.State)
	}
	spans := waitSpans(c, t.TraceID, func(s []contract.Span) bool { return markerInGenAI(s, k.marker) })
	if !markerInGenAI(spans, k.marker) {
		c.Errorf("the marker %s reached no GenAI content attribute of trace %s: the export holds no tool output, so its lack of secrets proves nothing", k.marker, t.TraceID)
	}
	snap, err := c.Env.H.Telemetry.Read()
	if err != nil {
		c.Fatalf("reading the export: %v", err)
	}
	for i, s := range append(k.secrets, k.cores...) {
		if strings.Contains(snap.Raw, s) {
			what := "a canary secret, whole"
			if i >= len(k.secrets) {
				what = "the random part of a canary secret"
			}
			c.Errorf("%s reached the export: the workload's redaction missed it", what)
		}
	}
}

func markerInGenAI(spans []contract.Span, marker string) bool {
	for _, s := range spans {
		for k, v := range s.Attributes {
			if strings.HasPrefix(k, "gen_ai.") && strings.Contains(fmt.Sprint(v), marker) {
				return true
			}
		}
		for _, ev := range s.Events {
			for k, v := range ev.Attributes {
				if strings.HasPrefix(k, "gen_ai.") && strings.Contains(fmt.Sprint(v), marker) {
					return true
				}
			}
		}
	}
	return false
}

func contentOnlyGenAI(c *C) {
	marker := c.Env.Marker("prompt")
	t := c.Env.Send(c, contract.NewPerson("conformance"), "Repeat nothing of this: "+marker, nil)
	if t.Err != nil || t.Task.Status.State != a2a.Completed {
		c.Fatalf("the task did not complete: %v %s", t.Err, t.Task.Status.State)
	}
	spans := waitSpans(c, t.TraceID, func(s []contract.Span) bool { return markerInGenAI(s, marker) })
	if !markerInGenAI(spans, marker) {
		c.Errorf("the prompt's marker reached no GenAI content attribute: content capture is off, or the content goes elsewhere")
	}
	snap, _ := c.Env.H.Telemetry.Read()
	for _, s := range snap.Spans {
		if strings.Contains(s.Name, marker) {
			c.Errorf("span name %q holds the prompt", s.Name)
		}
		for k, v := range s.Attributes {
			if !strings.HasPrefix(k, "gen_ai.") && strings.Contains(fmt.Sprint(v), marker) {
				c.Errorf("span %q: attribute %s holds the prompt; only the GenAI content attributes may, which the collector strips before Dynatrace", s.Name, k)
			}
		}
	}
	for _, l := range snap.Logs {
		if strings.Contains(fmt.Sprint(l.Body), marker) || strings.Contains(fmt.Sprint(l.Attributes), marker) {
			c.Errorf("a log record (%s) holds the prompt", l.EventName)
		}
	}
}
