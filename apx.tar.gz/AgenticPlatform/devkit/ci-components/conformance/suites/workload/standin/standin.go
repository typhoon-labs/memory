// Package standin is a stand-in workload for the workload suites' own
// tests and for the conformance component's own pipeline: an A2A agent or
// an MCP server, as its workload.yaml says, built to agent-sdk's spec and
// configured by the same environment a real workload is. With no fault it
// is honest; each Fault breaks one property, so the tests can show that
// every case passes against the honest stand-in and that each fails, for
// the right reason, against some faulty one. It is not a workload: that a
// case detects wrong behaviour here does not show that a real workload
// passes it, which only the contract stage against its image shows.
package standin

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"sync/atomic"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
)

// Workload is a running stand-in.
type Workload struct {
	cfg      *Config
	verify   *verifier
	exporter *exporter
	http     *http.Client
	agent    *agent
	server   *server
	// sending counts exports still to come of work whose answer is out:
	// a task's root span, sent after its end (Config.RootSpanDelay).
	sending atomic.Int64
}

// settleBound is the backstop of Settle.
const settleBound = time.Minute

// Settle returns once everything the stand-in has sent so far has reached
// the collector, for the suites' own tests: every export but a task's
// root span is sent before the request that caused it is answered, and
// the root span counts from before the task's end is visible.
func (w *Workload) Settle(ctx context.Context) error {
	ctx, cancel := context.WithTimeout(ctx, settleBound)
	defer cancel()
	for w.sending.Load() > 0 {
		select {
		case <-ctx.Done():
			return fmt.Errorf("%d exports still to come: %w", w.sending.Load(), ctx.Err())
		case <-time.After(5 * time.Millisecond):
		}
	}
	return nil
}

// New builds the stand-in from its configuration.
func New(cfg *Config) *Workload {
	hc := &http.Client{Timeout: 20 * time.Second, Transport: &http.Transport{Proxy: nil}}
	res := map[string]any{"service.name": cfg.ServiceName}
	for k, v := range cfg.Resource {
		if k == "platform.release.id" && cfg.Faults.Has(NoReleaseID) {
			continue
		}
		res[k] = v
	}
	w := &Workload{cfg: cfg, http: hc,
		verify:   &verifier{trust: cfg.Trust, leeway: cfg.Leeway, faults: &cfg.Faults, http: hc, sets: map[string]jose.JWKS{}, got: map[string]time.Time{}},
		exporter: &exporter{endpoint: cfg.OTLPEndpoint, resource: res, faults: &cfg.Faults, http: hc},
	}
	if cfg.Workload.Kind == "agent" {
		w.agent = newAgent(w)
	} else {
		w.server = newServer(w)
	}
	return w
}

// ServeHTTP routes: health without a token, the agent card without one,
// everything else behind the inbound token check.
func (w *Workload) ServeHTTP(rw http.ResponseWriter, r *http.Request) {
	switch {
	case r.Method == http.MethodGet && (r.URL.Path == "/healthz" || r.URL.Path == "/readyz"):
		if w.cfg.Faults.Has(HealthNeedsToken) && r.Header.Get("Authorization") == "" {
			w.challenge(rw, false)
			return
		}
		rw.Write([]byte("ok"))
		return
	case w.agent != nil && r.Method == http.MethodGet && (r.URL.Path == w.a2aPath()+"/.well-known/agent-card.json" || r.URL.Path == "/.well-known/agent-card.json"):
		w.agent.card(rw, r)
		return
	case w.server != nil && strings.HasPrefix(r.URL.Path, "/approvals/"+w.cfg.Name+"/"):
		w.server.approvals(rw, r)
		return
	}
	raw := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	if raw == r.Header.Get("Authorization") {
		raw = ""
	}
	p, reason := w.verify.verify(r.Context(), raw, nil)
	if reason != "" {
		if w.server != nil && w.cfg.Faults.Has(AuditOnRefusedToken) {
			w.exporter.log(r.Context(), map[string]any{"event.name": "tool.call", "tool.call.outcome": "refused", "refusal.reason": reason,
				"task.id": r.Header.Get("Agentic-Task-Id"), "tool.parameters.hash": "sha256:" + strings.Repeat("0", 64), "trace_id": newID(16), "span_id": newID(8)})
		}
		w.challenge(rw, raw != "")
		return
	}
	ctx := context.WithValue(r.Context(), principalKey{}, p)
	r = r.WithContext(ctx)
	switch {
	case w.agent != nil && (r.URL.Path == w.a2aPath() || r.URL.Path == "/"):
		w.agent.serve(rw, r)
	case w.server != nil && r.URL.Path == "/mcp":
		w.server.serve(rw, r)
	default:
		http.NotFound(rw, r)
	}
}

// a2aPath is where the agent serves A2A, directly and through the gateway
// alike (B5's seams, "Paths through the gateway").
func (w *Workload) a2aPath() string { return "/a2a/" + w.cfg.Name }

type principalKey struct{}

func principalOf(ctx context.Context) *Principal {
	p, _ := ctx.Value(principalKey{}).(*Principal)
	return p
}

// challenge refuses an inbound token as RFC 6750 says: 401 with
// WWW-Authenticate: Bearer, and error="invalid_token" when one was sent.
func (w *Workload) challenge(rw http.ResponseWriter, sent bool) {
	status := http.StatusUnauthorized
	if w.cfg.Faults.Has(Refuse403) {
		status = http.StatusForbidden
	}
	if !w.cfg.Faults.Has(NoChallenge) {
		v := "Bearer"
		if sent {
			v += ` error="invalid_token"`
		}
		rw.Header().Set("WWW-Authenticate", v)
	}
	http.Error(rw, "unauthorized", status)
}
