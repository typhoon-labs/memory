package standin

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"net/url"
	"os"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
)

// server plays an MCP server built on agent-sdk: notes in memory, its
// workload.yaml's tools, and for a destructive tool the checks of
// agent-sdk's spec/audit/tool/ in order (idempotency, then approval, then
// apply), the approval route, and one audit record per call that passes
// the token check.
type server struct {
	w   *Workload
	mcp *mcp.Server

	mu        sync.Mutex
	notes     map[string]*note
	proposals map[string]*proposal
	keys      map[string]*idemEntry
	nextNote  int

	dbMu   sync.Mutex // one round trip at a time on the pooled connection
	dbConn net.Conn   // the pooled connection, with DatabasePooled
}

type note struct {
	ID, Text string
	Version  int
}

type proposal struct {
	ID, Tool, Hash, TaskID     string
	Arguments                  map[string]any
	TargetID, TargetVersion    string
	ProposerUser, ProposerActr string
	ProposedAt                 int64
	Approver                   string
	ApprovedAt, ExpiresAt      int64
	UsedAt                     int64
}

type idemEntry struct {
	done   bool
	result map[string]any
}

func newServer(w *Workload) *server {
	s := &server{w: w, notes: map[string]*note{}, proposals: map[string]*proposal{}, keys: map[string]*idemEntry{}}
	var tools []mcp.Tool
	for _, t := range w.cfg.Workload.Tools {
		schema := map[string]any{"type": "object", "properties": map[string]any{}}
		props := schema["properties"].(map[string]any)
		switch {
		case contract.Destructive(t.Annotations):
			props["note_id"] = map[string]any{"type": "string"}
			props["text"] = map[string]any{"type": "string"}
			props["approval_id"] = map[string]any{"type": "string"}
			schema["required"] = []string{"text"}
		case strings.HasPrefix(t.Name, "get_"):
			props["note_id"] = map[string]any{"type": "string"}
			schema["required"] = []string{"note_id"}
		}
		ann := map[string]any{}
		for k, v := range t.Annotations {
			ann[k] = v
		}
		if w.cfg.Faults.Has(NoAnnotations) {
			ann = nil
		}
		tools = append(tools, mcp.Tool{Name: t.Name, Description: "The stand-in's " + t.Name, InputSchema: schema, Annotations: ann})
	}
	s.mcp = &mcp.Server{Name: w.cfg.Workload.Name, Version: "0.1.0", Tools: tools, Call: s.call}
	return s
}

func (s *server) serve(rw http.ResponseWriter, r *http.Request) {
	if s.w.cfg.Faults.Has(MalformedCrash) || s.w.cfg.Faults.Has(UnknownToolCrash) {
		body, _ := io.ReadAll(io.LimitReader(r.Body, 4<<20))
		r.Body = io.NopCloser(bytes.NewReader(body))
		var req struct {
			JSONRPC string `json:"jsonrpc"`
			Method  string `json:"method"`
			Params  struct {
				Name string `json:"name"`
			} `json:"params"`
		}
		bad := json.Unmarshal(body, &req) != nil || req.JSONRPC != "2.0"
		unknown := req.Method == "tools/call" && !slices.ContainsFunc(s.mcp.Tools, func(t mcp.Tool) bool { return t.Name == req.Params.Name })
		if (bad && s.w.cfg.Faults.Has(MalformedCrash)) || (unknown && s.w.cfg.Faults.Has(UnknownToolCrash)) {
			http.Error(rw, "internal error", http.StatusInternalServerError)
			return
		}
	}
	s.mcp.ServeHTTP(rw, r)
}

// ParametersHash is agent-sdk's spec/audit/tool/parameters-hash.json for
// arguments of strings, objects and integers: sorted keys, no HTML
// escaping, approval_id left out.
func ParametersHash(args map[string]any) string {
	clean := map[string]any{}
	for k, v := range args {
		if k != "approval_id" {
			clean[k] = v
		}
	}
	var b bytes.Buffer
	enc := json.NewEncoder(&b)
	enc.SetEscapeHTML(false)
	enc.Encode(clean)
	sum := sha256.Sum256(bytes.TrimSuffix(b.Bytes(), []byte("\n")))
	return "sha256:" + hex.EncodeToString(sum[:])
}

func toolResult(text string, structured any, isErr bool) map[string]any {
	m := map[string]any{"content": []any{map[string]any{"type": "text", "text": text}}}
	if structured != nil {
		m["structuredContent"] = structured
	}
	if isErr {
		m["isError"] = true
	}
	return m
}

func (s *server) call(ctx context.Context, r *http.Request, name string, raw json.RawMessage) (any, *mcp.RPCError) {
	f := &s.w.cfg.Faults
	p := principalOf(ctx)
	tid := ""
	if v := r.Header.Values("Agentic-Task-Id"); len(v) == 1 && taskIDPattern.MatchString(v[0]) {
		tid = v[0]
	}
	tc := inbound(r, f)
	spanID := newID(8)
	var args map[string]any
	json.Unmarshal(raw, &args)
	if args == nil {
		args = map[string]any{}
	}
	hash := ParametersHash(args)
	var tool contract.WorkloadTool
	for _, t := range s.w.cfg.Workload.Tools {
		if t.Name == name {
			tool = t
		}
	}
	destructive := contract.Destructive(tool.Annotations)
	// The task's wall time: the call ends past it with the spec's error on
	// the MCP surface, whatever it was waiting for.
	start := time.Now()
	if wall, ok := s.w.cfg.Limits["wall_time_seconds"]; ok && !f.Has(IgnoreWallTime) {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, time.Duration(wall)*time.Second)
		defer cancel()
	}
	rec := map[string]any{"event.name": "tool.call", "tool.name": name, "tool.parameters.hash": hash, "tool.destructive": destructive,
		"trace_id": tc.trace, "span_id": spanID}
	if p.Profile != "substrate-actor" {
		rec["user.id"], rec["user.team"], rec["session.id"], rec["client.id"] = p.UserID, p.Team, p.SessionID, p.ClientID
	}
	if p.ActorSub != "" {
		rec["actor.sub"], rec["actor.chain"] = p.ActorSub, p.Chain
	}
	rec["token.jti"] = p.JTI
	if tid != "" {
		rec["task.id"] = tid
	}
	if f.Has(AuditRecordsArguments) {
		b, _ := json.Marshal(args)
		rec["tool.arguments"] = string(b)
	}
	emit := func(outcome string, extra map[string]any) {
		rec["tool.call.outcome"] = outcome
		for k, v := range extra {
			rec[k] = v
		}
		if !f.Has(NoAuditRecord) {
			s.w.exporter.log(context.Background(), rec)
		}
		attrs := taskAttrs(tid, p, f)
		attrs["gen_ai.operation.name"], attrs["gen_ai.tool.name"] = "execute_tool", name
		s.w.exporter.spans(context.Background(), []span{{TraceID: tc.trace, SpanID: spanID, Parent: tc.span, Name: "execute_tool " + name,
			Kind: 2, Start: time.Now(), End: time.Now(), Attrs: attrs}})
	}
	refuse := func(code, approvalID string) (any, *mcp.RPCError) {
		body := map[string]any{"error": code}
		if approvalID != "" {
			body["approval_id"] = approvalID
		}
		extra := map[string]any{"refusal.reason": code}
		if approvalID != "" {
			extra["approval.id"] = approvalID
		}
		emit("refused", extra)
		return toolResult(name+" was refused: "+code, body, true), nil
	}
	if err := s.database(ctx); err != nil {
		if ctx.Err() != nil || errors.Is(err, context.DeadlineExceeded) {
			cap := s.w.cfg.Limits["wall_time_seconds"]
			used := int(math.Ceil(time.Since(start).Seconds()))
			emit("failed", map[string]any{"error.type": "limit_exceeded"})
			e := map[string]any{"error": "limit_exceeded", "limit": "wall_time_seconds", "cap": cap, "used": used}
			if tid != "" {
				e["task_id"] = tid
			}
			if f.Has(LimitAsText) {
				e = nil
			}
			return toolResult(fmt.Sprintf("%s stopped at its wall-time cap of %d seconds", name, cap), e, true), nil
		}
		emit("failed", map[string]any{"error.type": "database"})
		return toolResult(name+" failed: its database: "+err.Error(), nil, true), nil
	}
	if !destructive {
		emit("completed", nil)
		return toolResult(s.read(name, args), nil, false), nil
	}
	// 1. Idempotency, by the verified caller, the task and the call.
	key := ""
	if tid != "" && !f.Has(NoIdempotency) {
		key = strings.Join([]string{p.UserID, p.ActorSub, tid, name, hash}, "|")
		s.mu.Lock()
		e := s.keys[key]
		s.mu.Unlock()
		if e != nil && e.done {
			emit("replayed", nil)
			return e.result, nil
		}
		if e != nil {
			return refuse("idempotency_in_progress", "")
		}
	}
	// 2. Approval, and 3. apply, under one lock: the change, the key and
	// used_at together.
	code, proposalID, result := s.decide(p, tid, name, hash, args, key, rec)
	if code != "" {
		return refuse(code, proposalID)
	}
	emit("completed", nil)
	return result, nil
}

func (s *server) decide(p *Principal, tid, name, hash string, args map[string]any, key string, rec map[string]any) (string, string, map[string]any) {
	f := &s.w.cfg.Faults
	approvalID, _ := args["approval_id"].(string)
	targetID, _ := args["note_id"].(string)
	s.mu.Lock()
	defer s.mu.Unlock()
	var target *note
	if targetID != "" {
		target = s.notes[targetID]
	}
	if target != nil {
		rec["target.id"], rec["target.version"] = target.ID, strconv.Itoa(target.Version)
	}
	now := time.Now().Unix()
	if !f.Has(NoApprovalCheck) {
		if approvalID == "" {
			pr := &proposal{ID: newApprovalID(), Tool: name, Hash: hash, TaskID: tid, Arguments: args,
				ProposerUser: p.UserID, ProposerActr: p.ActorSub, ProposedAt: now}
			if target != nil {
				pr.TargetID, pr.TargetVersion = target.ID, strconv.Itoa(target.Version)
			}
			s.proposals[pr.ID] = pr
			return "approval_missing", pr.ID, nil
		}
		pr := s.proposals[approvalID]
		rec["approval.id"] = approvalID
		switch {
		case pr == nil || pr.Tool != name:
			return "approval_unknown", "", nil
		case !f.Has(ApprovalAnyCaller) && (pr.ProposerUser != p.UserID || pr.ProposerActr != p.ActorSub):
			return "approval_caller", "", nil
		case pr.Approver == "":
			return "approval_pending", "", nil
		case pr.Approver == pr.ProposerUser && !f.Has(SelfApproval):
			return "approval_self", "", nil
		case pr.UsedAt != 0 && !f.Has(ApprovalReusable):
			return "approval_used", "", nil
		case now >= pr.ExpiresAt && !f.Has(ApprovalNeverExpires):
			return "approval_expired", "", nil
		case pr.Hash != hash && !f.Has(ApprovalIgnoresParams):
			return "approval_parameters", "", nil
		case pr.TargetID != "" && !f.Has(ApprovalIgnoresVersion) && (s.notes[pr.TargetID] == nil || strconv.Itoa(s.notes[pr.TargetID].Version) != pr.TargetVersion):
			return "approval_version", "", nil
		}
		pr.UsedAt = now
	}
	text, _ := args["text"].(string)
	if target != nil {
		target.Text += "\n" + text
		target.Version++
	} else {
		s.nextNote++
		target = &note{ID: fmt.Sprintf("note-%d", s.nextNote), Text: text, Version: 1}
		if targetID != "" {
			target.ID = targetID
		}
		s.notes[target.ID] = target
	}
	rec["target.id"], rec["target.version"] = target.ID, strconv.Itoa(target.Version)
	// The result's shape is the server's own, as reference-mcp's {id,
	// version} is: no case reads an object's ID or version from it.
	result := toolResult(fmt.Sprintf("%s is now version %d", target.ID, target.Version), map[string]any{"id": target.ID, "version": strconv.Itoa(target.Version)}, false)
	if key != "" {
		s.keys[key] = &idemEntry{done: true, result: result}
	}
	return "", "", result
}

// database makes one round trip to the workload's database, when it has
// one, as a real server's query would: PostgreSQL's SSLRequest, answered
// with one byte. The stand-in keeps its data in memory; the trip is what
// the stage's database proxy can slow down. With DatabasePooled the
// connection stays open for the next call, as a real server's pool keeps
// its connections.
func (s *server) database(ctx context.Context) (err error) {
	if s.w.cfg.DatabaseURL == "" {
		return nil
	}
	u, err := url.Parse(s.w.cfg.DatabaseURL)
	if err != nil {
		return err
	}
	host := u.Host
	if u.Port() == "" {
		host = net.JoinHostPort(u.Hostname(), "5432")
	}
	var conn net.Conn
	if s.w.cfg.DatabasePooled {
		s.dbMu.Lock()
		defer s.dbMu.Unlock()
		if s.dbConn == nil {
			var d net.Dialer
			if s.dbConn, err = d.DialContext(ctx, "tcp", host); err != nil {
				return err
			}
		}
		conn = s.dbConn
		defer func() {
			// A connection a call failed or gave up on may hold an answer
			// still to come: the next call opens another.
			if err != nil || ctx.Err() != nil {
				conn.Close()
				s.dbConn = nil
			}
		}()
		defer conn.SetDeadline(time.Time{})
	} else {
		var d net.Dialer
		if conn, err = d.DialContext(ctx, "tcp", host); err != nil {
			return err
		}
		defer conn.Close()
	}
	if dl, ok := ctx.Deadline(); ok {
		conn.SetDeadline(dl)
	}
	stop := context.AfterFunc(ctx, func() { conn.SetDeadline(time.Now()) })
	defer stop()
	if _, err := conn.Write([]byte{0, 0, 0, 8, 4, 210, 22, 47}); err != nil {
		return err
	}
	b := make([]byte, 1)
	if _, err := io.ReadFull(conn, b); err != nil {
		// The connection's deadline is the context's, and may pass a
		// moment before the context's own timer fires.
		if ctx.Err() != nil || errors.Is(err, os.ErrDeadlineExceeded) {
			return context.DeadlineExceeded
		}
		return err
	}
	return nil
}

func (s *server) read(name string, args map[string]any) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if id, ok := args["note_id"].(string); ok && strings.HasPrefix(name, "get_") {
		if n := s.notes[id]; n != nil {
			return fmt.Sprintf("%s (version %d): %s", n.ID, n.Version, n.Text)
		}
		return "no note " + id
	}
	ids := make([]string, 0, len(s.notes))
	for id := range s.notes {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	var b strings.Builder
	for _, id := range ids {
		fmt.Fprintf(&b, "%s (version %d): %s\n", id, s.notes[id].Version, s.notes[id].Text)
	}
	if b.Len() == 0 {
		return "no notes"
	}
	return b.String()
}

func newApprovalID() string {
	return strings.TrimRight(strings.NewReplacer("+", "-", "/", "_").Replace(newID(16)), "=")
}

// approvals is the approval route: GET reads a proposal, POST approves it
// with the approver's own token, a person's from the realm, for the
// approval audience.
func (s *server) approvals(rw http.ResponseWriter, r *http.Request) {
	f := &s.w.cfg.Faults
	id := strings.TrimPrefix(r.URL.Path, "/approvals/"+s.w.cfg.Name+"/")
	raw := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	override := map[string]string{"keycloak": s.w.cfg.ApprovalAudience}
	p, reason := s.w.verify.verify(r.Context(), raw, override)
	if reason == "" && p.Profile != "keycloak" && !f.Has(AgentApproves) {
		reason = "an agent never approves"
	}
	if reason != "" && f.Has(AgentApproves) && p == nil {
		// An agent's chain token for the server's own route is taken too.
		p, reason = s.w.verify.verify(r.Context(), raw, nil)
	}
	if reason != "" {
		writeJSON(rw, http.StatusUnauthorized, map[string]string{"error": "invalid_token"})
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	pr := s.proposals[id]
	if pr == nil {
		writeJSON(rw, http.StatusNotFound, map[string]string{"error": "approval_unknown"})
		return
	}
	record := func() map[string]any {
		m := map[string]any{"id": pr.ID, "tool": pr.Tool, "parameters_hash": pr.Hash, "arguments": pr.Arguments, "proposed_at": pr.ProposedAt,
			"proposer": map[string]any{"user.id": pr.ProposerUser}}
		if pr.ProposerActr != "" {
			m["proposer"].(map[string]any)["actor.sub"] = pr.ProposerActr
		}
		if pr.TaskID != "" {
			m["task_id"] = pr.TaskID
		}
		if pr.TargetID != "" {
			m["target"] = map[string]any{"id": pr.TargetID, "version": pr.TargetVersion}
		}
		if pr.Approver != "" {
			m["approver"] = map[string]any{"user.id": pr.Approver}
			m["approved_at"], m["expires_at"] = pr.ApprovedAt, pr.ExpiresAt
		}
		if pr.UsedAt != 0 {
			m["used_at"] = pr.UsedAt
		}
		return m
	}
	if r.Method == http.MethodGet {
		writeJSON(rw, http.StatusOK, record())
		return
	}
	if r.Method != http.MethodPost {
		http.Error(rw, "GET or POST", http.StatusMethodNotAllowed)
		return
	}
	var body struct {
		ParametersHash string `json:"parameters_hash"`
		TargetVersion  string `json:"target_version"`
	}
	json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(&body)
	switch {
	case p.UserID == pr.ProposerUser && !f.Has(SelfApproval):
		writeJSON(rw, http.StatusForbidden, map[string]string{"error": "approval_self"})
		return
	case body.ParametersHash != pr.Hash:
		writeJSON(rw, http.StatusConflict, map[string]string{"error": "approval_parameters"})
		return
	case pr.Approver != "":
		writeJSON(rw, http.StatusConflict, map[string]string{"error": "approval_used"})
		return
	}
	now := time.Now().Unix()
	pr.Approver, pr.ApprovedAt = p.UserID, now
	pr.ExpiresAt = now + int64(s.w.cfg.ApprovalTTL/time.Second)
	if f.Has(ApprovalNeverExpires) {
		pr.ExpiresAt = now + 86400
	}
	writeJSON(rw, http.StatusOK, record())
}
