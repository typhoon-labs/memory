package standin

import (
	"fmt"
	"slices"
	"sort"
	"strings"
)

// Fault breaks one property of the stand-in workload.
type Fault string

// The faults. Each names what the stand-in does wrong; standin_test.go
// lists the cases each must fail.
const (
	// The inbound token check (Identity).
	AcceptAlgNone         Fault = "accept-alg-none"
	AcceptHS256           Fault = "accept-hs256"
	NoSignatureCheck      Fault = "no-signature-check"
	IgnoreTyp             Fault = "ignore-typ"
	IgnoreExpiry          Fault = "ignore-expiry"
	IgnoreNotBefore       Fault = "ignore-nbf"
	IgnoreAudience        Fault = "ignore-audience"
	AcceptManyAudiences   Fault = "accept-many-audiences"
	AcceptForeignAct      Fault = "accept-foreign-act"
	AcceptChainWithoutAct Fault = "accept-chain-without-act"
	Refuse403             Fault = "refuse-403"
	NoChallenge           Fault = "no-www-authenticate"
	// Delegation and token cache isolation.
	ForwardInbound     Fault = "forward-inbound-token"
	InboundToModel     Fault = "inbound-token-to-model"
	ForwardWhenRefused Fault = "forward-when-exchange-refused"
	CacheByTargetOnly  Fault = "cache-by-target-only"
	// Telemetry.
	NoTaskHeader     Fault = "no-task-header"
	NewTrace         Fault = "new-trace"
	NoRedaction      Fault = "no-redaction"
	LegacyContent    Fault = "content-in-legacy-attributes"
	NoReleaseID      Fault = "no-release-id"
	NoTaskAttributes Fault = "no-task-attributes"
	// Protocol and lifecycle.
	CardWithoutSecurity Fault = "card-without-security"
	CancelIgnored       Fault = "cancel-ignored"
	UnknownTaskOK       Fault = "unknown-task-ok"
	HealthNeedsToken    Fault = "health-needs-token"
	NoAnnotations       Fault = "no-tool-annotations"
	UnknownToolCrash    Fault = "unknown-tool-500"
	MalformedCrash      Fault = "malformed-500"
	// Retries.
	NoRetry        Fault = "no-retry"
	UnboundedRetry Fault = "unbounded-retry"
	RetryNoBackoff Fault = "retry-without-backoff"
	// Limits.
	IgnoreToolLimit  Fault = "ignore-tool-limit"
	IgnoreModelLimit Fault = "ignore-model-limit"
	IgnoreTokenLimit Fault = "ignore-token-limit"
	IgnoreWallTime   Fault = "ignore-wall-time"
	LimitAsText      Fault = "limit-error-as-text"
	// Injection: the agent calls whatever tool the model asks for.
	CallOutsideAllowlist Fault = "call-outside-allowlist"
	// Approvals, idempotency and the tool's audit record (L2).
	NoApprovalCheck        Fault = "no-approval-check"
	ApprovalIgnoresParams  Fault = "approval-ignores-parameters"
	ApprovalIgnoresVersion Fault = "approval-ignores-version"
	ApprovalNeverExpires   Fault = "approval-never-expires"
	ApprovalReusable       Fault = "approval-reusable"
	SelfApproval           Fault = "self-approval"
	AgentApproves          Fault = "agent-approves"
	ApprovalAnyCaller      Fault = "approval-any-caller"
	NoIdempotency          Fault = "no-idempotency"
	AuditRecordsArguments  Fault = "audit-records-arguments"
	NoAuditRecord          Fault = "no-audit-record"
	AuditOnRefusedToken    Fault = "audit-on-refused-token"
)

// All lists every fault.
var All = []Fault{
	AcceptAlgNone, AcceptHS256, NoSignatureCheck, IgnoreTyp, IgnoreExpiry, IgnoreNotBefore, IgnoreAudience, AcceptManyAudiences,
	AcceptForeignAct, AcceptChainWithoutAct, Refuse403, NoChallenge,
	ForwardInbound, InboundToModel, ForwardWhenRefused, CacheByTargetOnly,
	NoTaskHeader, NewTrace, NoRedaction, LegacyContent, NoReleaseID, NoTaskAttributes,
	CardWithoutSecurity, CancelIgnored, UnknownTaskOK, HealthNeedsToken, NoAnnotations, UnknownToolCrash, MalformedCrash,
	NoRetry, UnboundedRetry, RetryNoBackoff,
	IgnoreToolLimit, IgnoreModelLimit, IgnoreTokenLimit, IgnoreWallTime, LimitAsText,
	CallOutsideAllowlist,
	NoApprovalCheck, ApprovalIgnoresParams, ApprovalIgnoresVersion, ApprovalNeverExpires, ApprovalReusable, SelfApproval,
	AgentApproves, ApprovalAnyCaller, NoIdempotency, AuditRecordsArguments, NoAuditRecord, AuditOnRefusedToken,
}

// Faults is a set of faults; the zero value is the honest stand-in.
type Faults []Fault

// Has reports whether f is in the set.
func (fs *Faults) Has(f Fault) bool { return fs != nil && slices.Contains(*fs, f) }

// String lists the set.
func (fs Faults) String() string {
	s := make([]string, len(fs))
	for i, f := range fs {
		s[i] = string(f)
	}
	sort.Strings(s)
	return strings.Join(s, ",")
}

// ParseFaults reads a comma-separated list.
func ParseFaults(s string) (Faults, error) {
	var out Faults
	for _, name := range strings.Split(s, ",") {
		name = strings.TrimSpace(name)
		if name == "" {
			continue
		}
		if !slices.Contains(All, Fault(name)) {
			return nil, fmt.Errorf("unknown stand-in fault %q", name)
		}
		out = append(out, Fault(name))
	}
	return out, nil
}
