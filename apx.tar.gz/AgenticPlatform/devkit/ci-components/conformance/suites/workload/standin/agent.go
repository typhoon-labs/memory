package standin

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/url"
	"os"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

// agent plays an A2A agent built on agent-sdk: it answers a message by a
// model loop through the gateway's model route, calling the MCP tools its
// workload.yaml allows, each with a token exchanged at the STS for that
// tool's route, within its limits.
type agent struct {
	w *Workload

	mu    sync.Mutex
	tasks map[string]*task
	cache map[string]cached // exchanged tokens
}

type task struct {
	mu     sync.Mutex
	t      a2a.Task
	cancel context.CancelFunc
	done   chan struct{}
}

type cached struct {
	token string
	exp   time.Time
}

func newAgent(w *Workload) *agent {
	return &agent{w: w, tasks: map[string]*task{}, cache: map[string]cached{}}
}

func (a *agent) card(rw http.ResponseWriter, r *http.Request) {
	name := a.w.cfg.Workload.Name
	card := map[string]any{
		"name": name, "description": "The conformance stand-in agent", "version": "0.1.0",
		"supportedInterfaces": []any{map[string]any{"url": "http://" + r.Host + a.w.a2aPath(), "protocolBinding": "JSONRPC", "protocolVersion": a2a.Version}},
		"capabilities":        map[string]any{"streaming": false},
		"defaultInputModes":   []string{"text/plain"}, "defaultOutputModes": []string{"text/plain"},
		"skills": []any{map[string]any{"id": "answer", "name": "Answer", "description": "Answers a question", "tags": []string{"conformance"}}},
	}
	if !a.w.cfg.Faults.Has(CardWithoutSecurity) {
		card["securitySchemes"] = map[string]any{"bearer": map[string]any{"httpAuthSecurityScheme": map[string]any{"scheme": "Bearer", "bearerFormat": "JWT"}}}
		card["securityRequirements"] = []any{map[string]any{"schemes": map[string]any{"bearer": map[string]any{"list": []string{}}}}}
	}
	writeJSON(rw, http.StatusOK, card)
}

type rpcRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Method  string          `json:"method"`
	Params  json.RawMessage `json:"params"`
}

func rpcReply(rw http.ResponseWriter, id json.RawMessage, result any, rerr *a2a.RPCError) {
	msg := map[string]any{"jsonrpc": "2.0", "id": id}
	if rerr != nil {
		msg["error"] = rerr
	} else {
		msg["result"] = result
	}
	writeJSON(rw, http.StatusOK, msg)
}

func writeJSON(rw http.ResponseWriter, status int, v any) {
	rw.Header().Set("Content-Type", "application/json")
	rw.WriteHeader(status)
	json.NewEncoder(rw).Encode(v)
}

func (a *agent) serve(rw http.ResponseWriter, r *http.Request) {
	f := &a.w.cfg.Faults
	raw, _ := io.ReadAll(io.LimitReader(r.Body, 4<<20))
	var req rpcRequest
	if err := json.Unmarshal(raw, &req); err != nil || req.JSONRPC != "2.0" || req.Method == "" {
		if f.Has(MalformedCrash) {
			http.Error(rw, "internal error", http.StatusInternalServerError)
			return
		}
		rpcReply(rw, nil, nil, &a2a.RPCError{Code: a2a.CodeParse, Message: "Parse error"})
		return
	}
	if r.Header.Get("A2A-Version") != a2a.Version {
		rpcReply(rw, req.ID, nil, &a2a.RPCError{Code: a2a.CodeVersion, Message: "Version not supported"})
		return
	}
	switch req.Method {
	case "SendMessage":
		var p struct {
			Message       a2a.Message `json:"message"`
			Configuration struct {
				ReturnImmediately bool `json:"returnImmediately"`
			} `json:"configuration"`
		}
		if json.Unmarshal(req.Params, &p) != nil || len(p.Message.Parts) == 0 {
			rpcReply(rw, req.ID, nil, &a2a.RPCError{Code: a2a.CodeInvalidParams, Message: "Invalid params"})
			return
		}
		t := a.start(r, p.Message)
		if !p.Configuration.ReturnImmediately {
			<-t.done
		}
		t.mu.Lock()
		snapshot := t.t
		t.mu.Unlock()
		rpcReply(rw, req.ID, map[string]any{"task": snapshot}, nil)
	case "GetTask":
		var p struct {
			ID string `json:"id"`
		}
		json.Unmarshal(req.Params, &p)
		a.mu.Lock()
		t := a.tasks[p.ID]
		a.mu.Unlock()
		if t == nil {
			if f.Has(UnknownTaskOK) {
				rpcReply(rw, req.ID, a2a.Task{ID: p.ID, Status: a2a.Status{State: a2a.Completed}}, nil)
				return
			}
			rpcReply(rw, req.ID, nil, &a2a.RPCError{Code: a2a.CodeTaskNotFound, Message: "Task not found"})
			return
		}
		t.mu.Lock()
		snapshot := t.t
		t.mu.Unlock()
		rpcReply(rw, req.ID, snapshot, nil)
	case "CancelTask":
		var p struct {
			ID string `json:"id"`
		}
		json.Unmarshal(req.Params, &p)
		a.mu.Lock()
		t := a.tasks[p.ID]
		a.mu.Unlock()
		if t == nil {
			rpcReply(rw, req.ID, nil, &a2a.RPCError{Code: a2a.CodeTaskNotFound, Message: "Task not found"})
			return
		}
		t.mu.Lock()
		state := t.t.Status.State
		t.mu.Unlock()
		if a2a.Terminal(state) {
			rpcReply(rw, req.ID, nil, &a2a.RPCError{Code: a2a.CodeTaskNotCancelable, Message: "Task cannot be canceled"})
			return
		}
		if !f.Has(CancelIgnored) {
			t.cancel()
			select {
			case <-t.done:
			case <-time.After(5 * time.Second):
			}
		}
		t.mu.Lock()
		snapshot := t.t
		t.mu.Unlock()
		rpcReply(rw, req.ID, snapshot, nil)
	default:
		rpcReply(rw, req.ID, nil, &a2a.RPCError{Code: a2a.CodeMethodNotFound, Message: "Method not found"})
	}
}

// limitError is the spec's limit error (spec/limits/).
type limitError struct {
	Error  string      `json:"error"`
	Limit  string      `json:"limit"`
	Cap    valueNumber `json:"cap"`
	Used   valueNumber `json:"used"`
	TaskID string      `json:"task_id,omitempty"`
}

// valueNumber is a count as A2A 1.0 puts it in a data part: the part is a
// google.protobuf.Value, whose numbers are doubles, and a2a-sdk (Python's
// MessageToDict) writes 2 as 2.0. JSON Schema's "integer" accepts it, so
// the stand-in sends counts that way, as the reference agent does.
type valueNumber int

func (n valueNumber) MarshalJSON() ([]byte, error) { return []byte(fmt.Sprintf("%d.0", int(n))), nil }

func (a *agent) start(r *http.Request, msg a2a.Message) *task {
	p := principalOf(r.Context())
	tid := taskID(r)
	tc := inbound(r, &a.w.cfg.Faults)
	ctx, cancel := context.WithCancel(context.Background())
	t := &task{cancel: cancel, done: make(chan struct{}),
		t: a2a.Task{ID: newUUID(), ContextID: newUUID(), Status: a2a.Status{State: a2a.Working}}}
	a.mu.Lock()
	a.tasks[t.t.ID] = t
	a.mu.Unlock()
	var text strings.Builder
	for _, part := range msg.Parts {
		text.WriteString(part.Text)
	}
	go func() {
		defer close(t.done)
		a.run(ctx, t, p, tid, tc, text.String())
	}()
	return t
}

// run is the model loop of one task.
func (a *agent) run(ctx context.Context, t *task, p *Principal, tid string, tc traceContext, prompt string) {
	cfg := a.w.cfg
	f := &cfg.Faults
	root := span{TraceID: tc.trace, SpanID: newID(8), Parent: tc.span, Name: "invoke_agent " + cfg.Workload.Name, Kind: 2,
		Start: time.Now(), Attrs: taskAttrs(tid, p, f)}
	root.Attrs["gen_ai.operation.name"] = "invoke_agent"
	var spans []span
	finish := func(state string, msg *a2a.Message, artifact string) {
		// The root span is still to come once the task's end is visible.
		a.w.sending.Add(1)
		t.mu.Lock()
		if t.t.Status.State == a2a.Canceled {
			state, msg, artifact = a2a.Canceled, nil, ""
		}
		t.t.Status = a2a.Status{State: state, Message: msg, Timestamp: time.Now().UTC().Format(time.RFC3339)}
		if artifact != "" {
			t.t.Artifacts = []a2a.Artifact{{ArtifactID: newUUID(), Parts: []a2a.Part{{Text: artifact}}}}
		}
		t.mu.Unlock()
		root.End = time.Now()
		// A server's own span ends last, after its answer, and reaches the
		// collector in a later batch than the work under it (reference-agent's
		// a2a-sdk server span did): the stand-in sends it a moment after the
		// others, so a case waits for the evidence it checks, not the trace's
		// first span.
		if len(spans) > 0 {
			a.w.exporter.spans(context.Background(), spans)
		}
		go func(root span) {
			defer a.w.sending.Add(-1)
			time.Sleep(a.w.cfg.RootSpanDelay)
			a.w.exporter.spans(context.Background(), []span{root})
		}(root)
	}
	limits := cfg.Limits
	start := time.Now()
	runCtx := ctx
	if wall, ok := limits["wall_time_seconds"]; ok && !f.Has(IgnoreWallTime) {
		var cancel context.CancelFunc
		runCtx, cancel = context.WithTimeout(ctx, time.Duration(wall)*time.Second)
		defer cancel()
	}
	stop := func(limit string, used int) {
		e := limitError{Error: "limit_exceeded", Limit: limit, Cap: valueNumber(limits[limit]), Used: valueNumber(used), TaskID: tid}
		data, _ := json.Marshal(e)
		parts := []a2a.Part{{Text: fmt.Sprintf("The task stopped at its %s cap of %d.", limit, e.Cap)}}
		if !f.Has(LimitAsText) {
			parts = append(parts, a2a.Part{Data: data})
		}
		root.Error, root.Attrs["error.type"] = "limit_exceeded", "limit_exceeded"
		finish(a2a.Failed, &a2a.Message{MessageID: newUUID(), Role: "ROLE_AGENT", Parts: parts}, "")
	}
	fail := func(why string) {
		if ctx.Err() != nil {
			finish(a2a.Canceled, nil, "")
			return
		}
		root.Error = why
		finish(a2a.Failed, &a2a.Message{MessageID: newUUID(), Role: "ROLE_AGENT", Parts: []a2a.Part{{Text: why}}}, "")
	}
	tools, servers, err := a.listTools(runCtx, p, tid, tc)
	if err != nil {
		fail("the tools: " + err.Error())
		return
	}
	messages := []map[string]any{{"role": "user", "content": prompt}}
	modelCalls, toolCalls, tokens := 0, 0, 0
	for {
		if ctx.Err() != nil {
			finish(a2a.Canceled, nil, "")
			return
		}
		if c, ok := limits["model_calls"]; ok && modelCalls >= c && !f.Has(IgnoreModelLimit) {
			stop("model_calls", modelCalls)
			return
		}
		if c, ok := limits["tokens"]; ok && tokens >= c && !f.Has(IgnoreTokenLimit) {
			stop("tokens", tokens)
			return
		}
		modelCalls++
		chat := span{TraceID: tc.trace, SpanID: newID(8), Parent: root.SpanID, Name: "chat fast-default", Kind: 3, Start: time.Now(), Attrs: taskAttrs(tid, p, f)}
		in, _ := json.Marshal(messages)
		chat.Attrs["gen_ai.operation.name"], chat.Attrs["gen_ai.input.messages"] = "chat", string(in)
		if f.Has(LegacyContent) {
			chat.Attrs["gcp.vertex.agent.llm_request"] = string(in)
		}
		reply, err := a.model(runCtx, p, tid, tc.header(chat.SpanID), messages, tools)
		chat.End = time.Now()
		if err != nil {
			chat.Error = err.Error()
			spans = append(spans, chat)
			switch {
			case ctx.Err() != nil:
				finish(a2a.Canceled, nil, "")
			case runCtx.Err() != nil:
				stop("wall_time_seconds", int(math.Ceil(time.Since(start).Seconds())))
			default:
				fail("the model: " + err.Error())
			}
			return
		}
		out, _ := json.Marshal(reply.message)
		chat.Attrs["gen_ai.output.messages"] = string(out)
		spans = append(spans, chat)
		tokens += reply.tokens
		if c, ok := limits["tokens"]; ok && tokens > c && !f.Has(IgnoreTokenLimit) {
			stop("tokens", tokens)
			return
		}
		if len(reply.calls) == 0 {
			finish(a2a.Completed, nil, reply.text)
			return
		}
		messages = append(messages, reply.message)
		// Each call of the response, parallel ones too, is counted before
		// it starts: the one that would pass the cap never does.
		for _, call := range reply.calls {
			server, allowed := servers[call.name]
			if !allowed && f.Has(CallOutsideAllowlist) {
				for _, s := range servers {
					server, allowed = s, true
					break
				}
			}
			if !allowed {
				messages = append(messages, map[string]any{"role": "tool", "tool_call_id": call.id,
					"content": "refused: " + call.name + " is not among this task's tools"})
				continue
			}
			if c, ok := limits["tool_calls"]; ok && toolCalls >= c && !f.Has(IgnoreToolLimit) {
				stop("tool_calls", toolCalls)
				return
			}
			toolCalls++
			exec := span{TraceID: tc.trace, SpanID: newID(8), Parent: root.SpanID, Name: "execute_tool " + call.name, Kind: 1, Start: time.Now(), Attrs: taskAttrs(tid, p, f)}
			exec.Attrs["gen_ai.operation.name"], exec.Attrs["gen_ai.tool.name"], exec.Attrs["gen_ai.tool.call.arguments"] = "execute_tool", call.name, call.args
			result, err := a.callTool(runCtx, p, tid, tc.header(exec.SpanID), server, call.name, call.args)
			exec.End = time.Now()
			if err != nil {
				exec.Error = err.Error()
				spans = append(spans, exec)
				if runCtx.Err() != nil && ctx.Err() == nil {
					stop("wall_time_seconds", int(math.Ceil(time.Since(start).Seconds())))
					return
				}
				fail("the tool " + call.name + ": " + err.Error())
				return
			}
			exec.Attrs["gen_ai.tool.call.result"] = result
			spans = append(spans, exec)
			messages = append(messages, map[string]any{"role": "tool", "tool_call_id": call.id, "content": result})
		}
	}
}

type toolCall struct{ name, args, id string }

type modelReply struct {
	text    string
	calls   []toolCall
	tokens  int
	message map[string]any
}

// token returns the bearer token for a target route: one exchanged at the
// STS for this subject, target and actor, cached until shortly before it
// expires.
func (a *agent) token(ctx context.Context, p *Principal, tid, traceparent, resource string) (string, error) {
	f := &a.w.cfg.Faults
	actor, err := os.ReadFile(a.w.cfg.ActorTokenFile)
	if err != nil {
		return "", fmt.Errorf("the actor token: %v", err)
	}
	key := p.Raw + "|" + resource + "|" + string(actor)
	if f.Has(CacheByTargetOnly) {
		key = resource
	}
	a.mu.Lock()
	c, ok := a.cache[key]
	a.mu.Unlock()
	if ok && time.Until(c.exp) > 30*time.Second {
		return c.token, nil
	}
	form := url.Values{
		"grant_type":         {"urn:ietf:params:oauth:grant-type:token-exchange"},
		"subject_token":      {p.Raw},
		"subject_token_type": {"urn:ietf:params:oauth:token-type:access_token"},
		"actor_token":        {strings.TrimSpace(string(actor))},
		"actor_token_type":   {"urn:ietf:params:oauth:token-type:jwt"},
		"resource":           {resource},
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, a.w.cfg.STSTokenEndpoint, strings.NewReader(form.Encode()))
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	a.headers(req, tid, traceparent)
	resp, err := a.w.http.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK {
		if f.Has(ForwardWhenRefused) {
			return p.Raw, nil
		}
		return "", fmt.Errorf("the STS refused the exchange: HTTP %d %s", resp.StatusCode, outcome.Compact(string(raw)))
	}
	var out struct {
		AccessToken string `json:"access_token"`
	}
	json.Unmarshal(raw, &out)
	exp := time.Now().Add(5 * time.Minute)
	if t, err := jose.Parse(out.AccessToken); err == nil {
		if e, ok := num(t.Claims["exp"]); ok {
			exp = time.Unix(e, 0)
		}
	}
	a.mu.Lock()
	a.cache[key] = cached{token: out.AccessToken, exp: exp}
	a.mu.Unlock()
	return out.AccessToken, nil
}

func (a *agent) headers(req *http.Request, tid, traceparent string) {
	if !a.w.cfg.Faults.Has(NoTaskHeader) {
		req.Header.Set("Agentic-Task-Id", tid)
	}
	req.Header.Set("Traceparent", traceparent)
}

// listTools lists each required server's tools and keeps those the
// workload is allowed: the model sees only those.
func (a *agent) listTools(ctx context.Context, p *Principal, tid string, tc traceContext) ([]any, map[string]string, error) {
	var tools []any
	servers := map[string]string{}
	for _, req := range a.w.cfg.Workload.Requires.Tools {
		token, err := a.serverToken(ctx, p, tid, tc.header(newID(8)), req.Server)
		if err != nil {
			return nil, nil, err
		}
		c := &mcp.Client{URL: a.w.cfg.GatewayURL + "/mcp/" + req.Server, Token: token, HTTP: &outcome.Client{},
			Header: a.mcpHeaders(tid, tc.header(newID(8)))}
		listed, call := c.ListTools(ctx)
		if !call.OK() {
			return nil, nil, fmt.Errorf("tools/list at %s: %s", req.Server, call)
		}
		var full struct {
			Tools []mcp.Tool `json:"tools"`
		}
		json.Unmarshal(call.Response.Result, &full)
		for _, t := range full.Tools {
			if !slices.Contains(req.Tools, t.Name) || !slices.Contains(listed, t.Name) {
				continue
			}
			servers[t.Name] = req.Server
			tools = append(tools, map[string]any{"type": "function", "function": map[string]any{"name": t.Name, "description": t.Description, "parameters": t.InputSchema}})
		}
	}
	return tools, servers, nil
}

func (a *agent) mcpHeaders(tid, traceparent string) map[string]string {
	h := map[string]string{"Traceparent": traceparent}
	if !a.w.cfg.Faults.Has(NoTaskHeader) {
		h["Agentic-Task-Id"] = tid
	}
	return h
}

func (a *agent) serverToken(ctx context.Context, p *Principal, tid, traceparent, server string) (string, error) {
	if a.w.cfg.Faults.Has(ForwardInbound) {
		return p.Raw, nil
	}
	return a.token(ctx, p, tid, traceparent, a.w.cfg.ResourceBase+"/mcp/"+server)
}

func (a *agent) callTool(ctx context.Context, p *Principal, tid, traceparent, server, tool, args string) (string, error) {
	token, err := a.serverToken(ctx, p, tid, traceparent, server)
	if err != nil {
		return "", err
	}
	c := &mcp.Client{URL: a.w.cfg.GatewayURL + "/mcp/" + server, Token: token, HTTP: &outcome.Client{}, Header: a.mcpHeaders(tid, traceparent)}
	var in map[string]any
	json.Unmarshal([]byte(args), &in)
	call := c.CallTool(ctx, tool, in)
	res, err := call.Result()
	if err != nil {
		if ctx.Err() != nil {
			return "", ctx.Err()
		}
		return "", err
	}
	var text strings.Builder
	for _, c := range res.Content {
		text.WriteString(c.Text)
	}
	return text.String(), nil
}

// model makes one model call, retried on 429 and 5xx with backoff, as the
// SDK's resilience does: at most three retries, honouring Retry-After.
func (a *agent) model(ctx context.Context, p *Principal, tid, traceparent string, messages []map[string]any, tools []any) (*modelReply, error) {
	f := &a.w.cfg.Faults
	token := p.Raw
	if !f.Has(InboundToModel) {
		var err error
		if token, err = a.token(ctx, p, tid, traceparent, a.w.cfg.ResourceBase+"/v1"); err != nil {
			return nil, err
		}
	}
	body := map[string]any{"model": "fast-default", "messages": messages, "max_tokens": 1024}
	if len(tools) > 0 {
		body["tools"] = tools
	}
	b, _ := json.Marshal(body)
	retries := 3
	switch {
	case f.Has(NoRetry):
		retries = 0
	case f.Has(UnboundedRetry):
		retries = 40
	}
	for attempt := 0; ; attempt++ {
		req, _ := http.NewRequestWithContext(ctx, http.MethodPost, a.w.cfg.GatewayURL+"/v1/chat/completions", strings.NewReader(string(b)))
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("Authorization", "Bearer "+token)
		a.headers(req, tid, traceparent)
		resp, err := a.w.http.Do(req)
		if err != nil {
			return nil, err
		}
		raw, _ := io.ReadAll(io.LimitReader(resp.Body, 16<<20))
		resp.Body.Close()
		if resp.StatusCode == http.StatusTooManyRequests || resp.StatusCode >= 500 {
			if attempt >= retries {
				return nil, fmt.Errorf("HTTP %d after %d attempts", resp.StatusCode, attempt+1)
			}
			wait := time.Duration(500*(1<<attempt)) * time.Millisecond
			if s, err := strconv.Atoi(resp.Header.Get("Retry-After")); err == nil {
				wait = min(time.Duration(s)*time.Second, 10*time.Second)
			}
			if f.Has(RetryNoBackoff) || f.Has(UnboundedRetry) {
				wait = 20 * time.Millisecond
			}
			select {
			case <-time.After(wait):
			case <-ctx.Done():
				return nil, ctx.Err()
			}
			continue
		}
		if resp.StatusCode != http.StatusOK {
			return nil, fmt.Errorf("HTTP %d: %s", resp.StatusCode, outcome.Compact(string(raw)))
		}
		var cc struct {
			Choices []struct {
				Message struct {
					Content   *string `json:"content"`
					ToolCalls []struct {
						ID       string `json:"id"`
						Function struct {
							Name      string `json:"name"`
							Arguments string `json:"arguments"`
						} `json:"function"`
					} `json:"tool_calls"`
				} `json:"message"`
			} `json:"choices"`
			Usage struct {
				TotalTokens int `json:"total_tokens"`
			} `json:"usage"`
		}
		if err := json.Unmarshal(raw, &cc); err != nil || len(cc.Choices) == 0 {
			return nil, errors.New("not a chat completion")
		}
		m := cc.Choices[0].Message
		r := &modelReply{tokens: cc.Usage.TotalTokens}
		if len(m.ToolCalls) > 0 {
			var calls []any
			for _, tc := range m.ToolCalls {
				r.calls = append(r.calls, toolCall{name: tc.Function.Name, args: tc.Function.Arguments, id: tc.ID})
				calls = append(calls, map[string]any{"id": tc.ID, "type": "function",
					"function": map[string]any{"name": tc.Function.Name, "arguments": tc.Function.Arguments}})
			}
			r.message = map[string]any{"role": "assistant", "content": nil, "tool_calls": calls}
		} else if m.Content != nil {
			r.text = *m.Content
			r.message = map[string]any{"role": "assistant", "content": r.text}
		}
		return r, nil
	}
}
