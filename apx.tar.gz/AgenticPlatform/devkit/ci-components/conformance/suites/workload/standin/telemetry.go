package standin

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"regexp"
	"sort"
	"strconv"
	"sync"
	"time"
)

// secretPatterns are the platform's (environments' 50-telemetry
// redaction), which agent-sdk's telemetry module applies before export.
var secretPatterns = []*regexp.Regexp{
	regexp.MustCompile(`\b(AKIA|ASIA)[0-9A-Z]{16}\b`),
	regexp.MustCompile(`\bgl(pat|rt)-[0-9A-Za-z_.-]{20,}`),
	regexp.MustCompile(`\beyJ[0-9A-Za-z_-]+\.eyJ[0-9A-Za-z_-]+\.[0-9A-Za-z_-]*`),
	regexp.MustCompile(`-----BEGIN[A-Z ]* PRIVATE KEY-----[\s\S]*?-----END[A-Z ]* PRIVATE KEY-----`),
	regexp.MustCompile(`(?i)\b(bearer|basic|api-token)\s+[0-9A-Za-z._~+/=-]{8,}`),
}

// Mask replaces each secret.
const Mask = "****"

func redact(s string) string {
	for _, p := range secretPatterns {
		s = p.ReplaceAllString(s, Mask)
	}
	return s
}

// traceContext is a W3C traceparent's IDs.
type traceContext struct{ trace, span string }

func newID(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

var traceparentPattern = regexp.MustCompile(`^00-([0-9a-f]{32})-([0-9a-f]{16})-[0-9a-f]{2}$`)

// inbound reads a request's traceparent, or starts a trace.
func inbound(r *http.Request, f *Faults) traceContext {
	if m := traceparentPattern.FindStringSubmatch(r.Header.Get("Traceparent")); m != nil && !f.Has(NewTrace) {
		return traceContext{trace: m[1], span: m[2]}
	}
	return traceContext{trace: newID(16)}
}

func (t traceContext) header(span string) string { return "00-" + t.trace + "-" + span + "-01" }

// span is one span the stand-in exports.
type span struct {
	TraceID, SpanID, Parent, Name string
	Kind                          int
	Start, End                    time.Time
	Attrs                         map[string]any
	Events                        []spanEvent
	Error                         string
}

type spanEvent struct {
	Name  string
	Attrs map[string]any
}

// exporter sends spans and log records as OTLP JSON, each value redacted
// first unless the fault says otherwise.
type exporter struct {
	endpoint string
	resource map[string]any
	faults   *Faults
	http     *http.Client
	mu       sync.Mutex
}

func value(v any, redactOn bool) map[string]any {
	switch x := v.(type) {
	case string:
		if redactOn {
			x = redact(x)
		}
		return map[string]any{"stringValue": x}
	case bool:
		return map[string]any{"boolValue": x}
	case int:
		return map[string]any{"intValue": strconv.Itoa(x)}
	case int64:
		return map[string]any{"intValue": strconv.FormatInt(x, 10)}
	case []string:
		var vals []any
		for _, s := range x {
			vals = append(vals, value(s, redactOn))
		}
		return map[string]any{"arrayValue": map[string]any{"values": vals}}
	}
	b, _ := json.Marshal(v)
	return value(string(b), redactOn)
}

func kvs(m map[string]any, redactOn bool) []any {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := []any{}
	for _, k := range keys {
		out = append(out, map[string]any{"key": k, "value": value(m[k], redactOn)})
	}
	return out
}

func (e *exporter) post(ctx context.Context, path string, body any) {
	if e.endpoint == "" {
		return
	}
	b, _ := json.Marshal(body)
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, e.endpoint+path, bytes.NewReader(b))
	req.Header.Set("Content-Type", "application/json")
	if resp, err := e.http.Do(req); err == nil {
		resp.Body.Close()
	}
}

func (e *exporter) spans(ctx context.Context, spans []span) {
	redactOn := !e.faults.Has(NoRedaction)
	var out []any
	for _, s := range spans {
		m := map[string]any{"traceId": s.TraceID, "spanId": s.SpanID, "name": redactName(s.Name, redactOn), "kind": s.Kind,
			"startTimeUnixNano": strconv.FormatInt(s.Start.UnixNano(), 10), "endTimeUnixNano": strconv.FormatInt(s.End.UnixNano(), 10),
			"attributes": kvs(s.Attrs, redactOn)}
		if s.Parent != "" {
			m["parentSpanId"] = s.Parent
		}
		if s.Error != "" {
			m["status"] = map[string]any{"code": 2, "message": s.Error}
		}
		var evs []any
		for _, ev := range s.Events {
			evs = append(evs, map[string]any{"name": ev.Name, "timeUnixNano": strconv.FormatInt(s.End.UnixNano(), 10), "attributes": kvs(ev.Attrs, redactOn)})
		}
		if evs != nil {
			m["events"] = evs
		}
		out = append(out, m)
	}
	e.post(ctx, "/v1/traces", map[string]any{"resourceSpans": []any{map[string]any{
		"resource":   map[string]any{"attributes": kvs(e.resource, false)},
		"scopeSpans": []any{map[string]any{"scope": map[string]any{"name": "standin"}, "spans": out}},
	}}})
}

func redactName(n string, on bool) string {
	if on {
		return redact(n)
	}
	return n
}

// log exports one audit record as an OTel log record: its attributes one
// to one, no body, severity INFO, scope audit (agent-sdk's
// spec/audit/encoding.json).
func (e *exporter) log(ctx context.Context, record map[string]any) {
	attrs := map[string]any{}
	for k, v := range record {
		attrs[k] = v
	}
	lr := map[string]any{"timeUnixNano": strconv.FormatInt(time.Now().UnixNano(), 10), "severityNumber": 9, "severityText": "INFO",
		"attributes": kvs(attrs, !e.faults.Has(NoRedaction))}
	if t, ok := record["trace_id"].(string); ok {
		lr["traceId"] = t
	}
	if s, ok := record["span_id"].(string); ok {
		lr["spanId"] = s
	}
	if n, ok := record["event.name"].(string); ok {
		lr["eventName"] = n
	}
	e.post(ctx, "/v1/logs", map[string]any{"resourceLogs": []any{map[string]any{
		"resource":  map[string]any{"attributes": kvs(e.resource, false)},
		"scopeLogs": []any{map[string]any{"scope": map[string]any{"name": "audit"}, "logRecords": []any{lr}}},
	}}})
}

// taskAttrs are the attributes every span of an invocation carries: the
// task and the verified caller.
func taskAttrs(taskID string, p *Principal, f *Faults) map[string]any {
	if f.Has(NoTaskAttributes) {
		return map[string]any{}
	}
	a := map[string]any{"task.id": taskID}
	if p != nil {
		if p.Profile != "substrate-actor" {
			a["user.id"], a["user.team"], a["session.id"] = p.UserID, p.Team, p.SessionID
		}
		if p.ActorSub != "" {
			a["actor.sub"] = p.ActorSub
		}
	}
	return a
}

var taskIDPattern = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$`)

// taskID takes a valid Agentic-Task-Id, sent once, or starts a task.
func taskID(r *http.Request) string {
	if v := r.Header.Values("Agentic-Task-Id"); len(v) == 1 && taskIDPattern.MatchString(v[0]) {
		return v[0]
	}
	return newUUID()
}

func newUUID() string {
	h := newID(16)
	b := []byte(h)
	b[12] = '4'
	return string(b[:8]) + "-" + string(b[8:12]) + "-" + string(b[12:16]) + "-" + string(b[16:20]) + "-" + string(b[20:])
}
