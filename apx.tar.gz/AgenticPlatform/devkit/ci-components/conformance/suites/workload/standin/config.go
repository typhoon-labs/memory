package standin

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
)

// Trust is one issuer the inbound check trusts (AGENTIC_TRUST).
type Trust struct {
	Issuer   string `json:"issuer"`
	Profile  string `json:"profile"` // keycloak, chain or substrate-actor
	JWKSURI  string `json:"jwks_uri"`
	Audience string `json:"audience"`
}

// Config is the stand-in's configuration: the env-only surface agent-sdk's
// Python core reads (B5's seams), so the stand-in runs as a workload
// service exactly as a real workload does.
type Config struct {
	Listen           string
	Name             string // AGENTIC_WORKLOAD_NAME: the path segment of /a2a/<name> and /approvals/<name>
	GatewayURL       string
	ResourceBase     string
	STSTokenEndpoint string
	ActorTokenFile   string
	Trust            []Trust
	ApprovalAudience string
	ApprovalTTL      time.Duration
	Leeway           time.Duration
	Limits           map[string]int
	OTLPEndpoint     string
	ServiceName      string
	Resource         map[string]string
	Workload         *contract.Workload
	DatabaseURL      string // AGENTIC_DATABASE_URL; empty means none
	DatabasePooled   bool   // STANDIN_DATABASE_POOLED=true: one connection kept open, as a real server's pool does
	// RootSpanDelay is how much later than a task's other spans its root
	// span is sent: STANDIN_ROOT_SPAN_DELAY, a duration; default a second.
	RootSpanDelay time.Duration
	Faults        Faults
}

// FromEnv reads the configuration as the SDK would, plus STANDIN_FAULTS, a
// comma-separated list of the faults to play, STANDIN_ROOT_SPAN_DELAY,
// and STANDIN_DATABASE_POOLED,
// "true" to keep one database connection open across calls (its round trip
// must then be one the database answers again on the same connection, as
// the suites' own tests' fake database does; PostgreSQL does not).
func FromEnv(getenv func(string) string) (*Config, error) {
	c := &Config{
		Listen: getenv("AGENTIC_LISTEN"), GatewayURL: strings.TrimRight(getenv("AGENTIC_GATEWAY_URL"), "/"),
		ResourceBase: strings.TrimRight(getenv("AGENTIC_RESOURCE_BASE"), "/"), STSTokenEndpoint: getenv("AGENTIC_STS_TOKEN_ENDPOINT"),
		ActorTokenFile: getenv("AGENTIC_ACTOR_TOKEN_FILE"), ApprovalAudience: getenv("AGENTIC_APPROVAL_AUDIENCE"),
		OTLPEndpoint: strings.TrimRight(getenv("OTEL_EXPORTER_OTLP_ENDPOINT"), "/"), ServiceName: getenv("OTEL_SERVICE_NAME"),
		Resource: map[string]string{}, Limits: map[string]int{}, ApprovalTTL: 300 * time.Second, Leeway: 60 * time.Second,
	}
	if c.Listen == "" {
		c.Listen = "0.0.0.0:8080"
	}
	c.DatabaseURL = getenv("AGENTIC_DATABASE_URL")
	c.DatabasePooled = getenv("STANDIN_DATABASE_POOLED") == "true"
	if c.ResourceBase == "" {
		c.ResourceBase = c.GatewayURL
	}
	if t := getenv("AGENTIC_TRUST"); t != "" {
		if err := json.Unmarshal([]byte(t), &c.Trust); err != nil {
			return nil, fmt.Errorf("AGENTIC_TRUST: %v", err)
		}
	}
	if v := getenv("AGENTIC_APPROVAL_TTL_SECONDS"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 || n > 900 {
			return nil, fmt.Errorf("AGENTIC_APPROVAL_TTL_SECONDS %q: 1 to 900", v)
		}
		c.ApprovalTTL = time.Duration(n) * time.Second
	}
	for _, kv := range strings.Split(getenv("OTEL_RESOURCE_ATTRIBUTES"), ",") {
		if k, v, ok := strings.Cut(kv, "="); ok {
			c.Resource[strings.TrimSpace(k)] = strings.TrimSpace(v)
		}
	}
	path := getenv("STANDIN_WORKLOAD")
	if path == "" {
		path = contract.WorkloadPath
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if c.Workload, err = contract.ParseWorkload(raw, ""); err != nil {
		return nil, err
	}
	if c.ServiceName == "" {
		c.ServiceName = c.Workload.Name
	}
	if c.Name = getenv("AGENTIC_WORKLOAD_NAME"); c.Name == "" {
		c.Name = c.Workload.Name
	}
	for k, v := range c.Workload.Limits {
		c.Limits[k] = v
	}
	for _, name := range []string{"model_calls", "tool_calls", "tokens", "wall_time_seconds"} {
		v := getenv("AGENTIC_LIMIT_" + strings.ToUpper(name))
		if v == "" {
			continue
		}
		n, err := strconv.Atoi(v)
		if err != nil || n < 0 {
			return nil, fmt.Errorf("AGENTIC_LIMIT_%s %q", strings.ToUpper(name), v)
		}
		// Env lowers a cap, never raises it.
		if cur, ok := c.Limits[name]; !ok || n < cur {
			c.Limits[name] = n
		}
	}
	if c.Faults, err = ParseFaults(getenv("STANDIN_FAULTS")); err != nil {
		return nil, err
	}
	c.RootSpanDelay = time.Second
	if v := getenv("STANDIN_ROOT_SPAN_DELAY"); v != "" {
		if c.RootSpanDelay, err = time.ParseDuration(v); err != nil || c.RootSpanDelay < 0 {
			return nil, fmt.Errorf("STANDIN_ROOT_SPAN_DELAY must be a duration such as 1s: %q", v)
		}
	}
	return c, nil
}

// Principal is who a verified token names, under the audit records' names.
type Principal struct {
	UserID, Team, SessionID, ClientID, JTI, ActorSub string
	Chain                                            []string
	Profile                                          string
	Raw                                              string
	Claims                                           map[string]any
}

// verifier checks inbound tokens as agent-sdk's spec/vectors say, in
// their order: the first failed check names the reason.
type verifier struct {
	trust  []Trust
	leeway time.Duration
	faults *Faults
	http   *http.Client

	mu   sync.Mutex
	sets map[string]jose.JWKS
	got  map[string]time.Time
}

func (v *verifier) jwks(ctx context.Context, uri string, refresh bool) jose.JWKS {
	v.mu.Lock()
	set, ok := v.sets[uri]
	at := v.got[uri]
	v.mu.Unlock()
	if ok && (!refresh || time.Since(at) < 2*time.Second) && time.Since(at) < 5*time.Minute {
		return set
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, uri, nil)
	resp, err := v.http.Do(req)
	if err != nil {
		return set
	}
	defer resp.Body.Close()
	var fresh jose.JWKS
	if resp.StatusCode == http.StatusOK && json.NewDecoder(resp.Body).Decode(&fresh) == nil {
		v.mu.Lock()
		v.sets[uri], v.got[uri] = fresh, time.Now()
		v.mu.Unlock()
		return fresh
	}
	return set
}

// verify returns the principal, or the refusal reason.
func (v *verifier) verify(ctx context.Context, raw string, audienceOverride map[string]string) (*Principal, string) {
	f := v.faults
	if raw == "" {
		return nil, "request_malformed"
	}
	t, err := jose.Parse(raw)
	if err != nil {
		return nil, "subject_signature"
	}
	iss, _ := t.Claims["iss"].(string)
	var tr *Trust
	for i := range v.trust {
		if v.trust[i].Issuer == iss {
			tr = &v.trust[i]
		}
	}
	if tr == nil {
		if !f.Has(NoSignatureCheck) || len(v.trust) == 0 {
			return nil, "subject_issuer"
		}
		tr = &v.trust[0]
	}
	alg := t.HeaderString("alg")
	switch {
	case alg == "none" && f.Has(AcceptAlgNone):
	case alg == "HS256" && f.Has(AcceptHS256):
	case f.Has(NoSignatureCheck):
	default:
		if !slices.Contains([]string{"ES256", "RS256"}, alg) || t.Header["crit"] != nil {
			return nil, "subject_signature"
		}
		kid := t.HeaderString("kid")
		k, ok := v.jwks(ctx, tr.JWKSURI, false).Key(kid)
		if !ok {
			k, ok = v.jwks(ctx, tr.JWKSURI, true).Key(kid)
		}
		if !ok {
			return nil, "subject_signature"
		}
		pub, err := k.Public()
		if err != nil || t.Verify(pub) != nil {
			return nil, "subject_signature"
		}
	}
	typ := strings.ToLower(t.HeaderString("typ"))
	if !f.Has(IgnoreTyp) && typ != "at+jwt" && typ != "application/at+jwt" {
		return nil, "subject_type"
	}
	sub, _ := t.Claims["sub"].(string)
	exp, hasExp := num(t.Claims["exp"])
	act, hasAct := t.Claims["act"].(map[string]any)
	if sub == "" || !hasExp || (tr.Profile == "chain" && (!hasAct || act["sub"] == nil) && !f.Has(AcceptChainWithoutAct)) {
		return nil, "subject_type"
	}
	now := time.Now()
	if !f.Has(IgnoreExpiry) && now.Unix() >= exp+int64(v.leeway/time.Second) {
		return nil, "subject_expired"
	}
	if nbf, ok := num(t.Claims["nbf"]); ok && !f.Has(IgnoreNotBefore) && nbf > now.Unix()+int64(v.leeway/time.Second) {
		return nil, "subject_not_yet_valid"
	}
	if tr.Profile == "keycloak" && hasAct && !f.Has(AcceptForeignAct) {
		return nil, "subject_foreign_act"
	}
	want := tr.Audience
	if o, ok := audienceOverride[tr.Profile]; ok {
		want = o
	}
	var auds []string
	switch a := t.Claims["aud"].(type) {
	case string:
		auds = []string{a}
	case []any:
		for _, x := range a {
			s, _ := x.(string)
			auds = append(auds, s)
		}
	}
	switch {
	case f.Has(IgnoreAudience):
	case f.Has(AcceptManyAudiences) && slices.Contains(auds, want):
	case len(auds) != 1 || auds[0] != want:
		return nil, "subject_audience"
	}
	p := &Principal{Profile: tr.Profile, Raw: raw, Claims: t.Claims, UserID: sub}
	p.Team, _ = t.Claims["team"].(string)
	p.SessionID, _ = t.Claims["sid"].(string)
	p.ClientID, _ = t.Claims["client_id"].(string)
	p.JTI, _ = t.Claims["jti"].(string)
	for a := act; a != nil; {
		s, _ := a["sub"].(string)
		p.Chain = append(p.Chain, s)
		a, _ = a["act"].(map[string]any)
	}
	if len(p.Chain) > 0 {
		p.ActorSub = p.Chain[0]
	}
	return p, ""
}

func num(v any) (int64, bool) {
	switch n := v.(type) {
	case json.Number:
		i, err := n.Int64()
		return i, err == nil
	case float64:
		return int64(n), true
	}
	return 0, false
}
