package workload_test

import (
	"strings"
	"sync"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload/standin"
)

// Every task-running agent case: an agent that forwards its inbound token
// to the MCP server, which refuses it, ends every such task failed.
var agentTaskCases = []string{
	"l1/cache-isolation/concurrent-users", "l1/delegation/model-token", "l1/delegation/refused-exchange", "l1/delegation/tool-token",
	"l1/limits/model-calls", "l1/limits/tokens", "l1/limits/tool-calls", "l1/limits/wall-time", "l1/protocol/a2a/cancel", "l1/protocol/a2a/task-states",
	"l1/retries/model-429", "l1/retries/model-5xx-bounded", "l1/telemetry/canary-secret", "l1/telemetry/content-only-genai",
	"l2/injection/tool-outside-allowlist",
}

func tokenCases(kind string, extra ...string) []string {
	ids := []string{"alg-none", "expired", "hs256-public-key", "missing", "nbf-120s-ahead", "other-audience", "other-issuer",
		"tampered", "two-audiences", "typ-jwt", "unknown-kid"}
	if kind == "agent" {
		ids = append(ids, "carries-act")
	} else {
		ids = append(ids, "no-act", "person-token")
	}
	var out []string
	for _, id := range ids {
		out = append(out, "l1/identity/"+id)
	}
	out = append(out, "l1/lifecycle/health")
	return append(out, extra...)
}

var approvalCases = []string{
	"l2/approvals/agent-approves", "l2/approvals/changed-parameters", "l2/approvals/expired", "l2/approvals/newer-version",
	"l2/approvals/other-caller", "l2/approvals/pending", "l2/approvals/proposer-approves", "l2/approvals/reused",
	"l2/approvals/unknown", "l2/approvals/without-record", "l2/idempotency/same-task", "l2/injection/planted-instruction",
}

// faults lists, for each fault and the kind of stand-in it breaks, the
// cases it must fail; every other case must still pass. One word of each
// failing case's message is checked where the case names the property.
var faults = []struct {
	fault  standin.Fault
	kind   string // agent or mcp
	expect []string
	words  string // in every expected failure's message
}{
	{standin.AcceptAlgNone, "agent", []string{"l1/identity/alg-none"}, "got through"},
	{standin.AcceptAlgNone, "mcp", []string{"l1/identity/alg-none"}, "got through"},
	{standin.AcceptHS256, "agent", []string{"l1/identity/hs256-public-key"}, "got through"},
	{standin.AcceptHS256, "mcp", []string{"l1/identity/hs256-public-key"}, "got through"},
	{standin.NoSignatureCheck, "agent", []string{"l1/identity/alg-none", "l1/identity/hs256-public-key", "l1/identity/other-issuer", "l1/identity/tampered", "l1/identity/unknown-kid"}, "got through"},
	{standin.NoSignatureCheck, "mcp", []string{"l1/identity/alg-none", "l1/identity/hs256-public-key", "l1/identity/tampered", "l1/identity/unknown-kid"}, "got through"},
	{standin.IgnoreTyp, "agent", []string{"l1/identity/typ-jwt"}, "got through"},
	{standin.IgnoreTyp, "mcp", []string{"l1/identity/typ-jwt"}, "got through"},
	{standin.IgnoreExpiry, "agent", []string{"l1/identity/expired"}, "got through"},
	{standin.IgnoreExpiry, "mcp", []string{"l1/identity/expired"}, "got through"},
	{standin.IgnoreNotBefore, "agent", []string{"l1/identity/nbf-120s-ahead"}, "got through"},
	{standin.IgnoreNotBefore, "mcp", []string{"l1/identity/nbf-120s-ahead"}, "got through"},
	{standin.IgnoreAudience, "agent", []string{"l1/identity/other-audience", "l1/identity/two-audiences"}, "got through"},
	{standin.IgnoreAudience, "mcp", []string{"l1/identity/other-audience", "l1/identity/two-audiences", "l1/identity/person-token", "l2/audit/tool-record"}, "got through"},
	{standin.AcceptManyAudiences, "agent", []string{"l1/identity/two-audiences"}, "got through"},
	{standin.AcceptManyAudiences, "mcp", []string{"l1/identity/two-audiences"}, "got through"},
	{standin.AcceptForeignAct, "agent", []string{"l1/identity/carries-act"}, "got through"},
	{standin.AcceptChainWithoutAct, "mcp", []string{"l1/identity/no-act"}, "got through"},
	{standin.Refuse403, "agent", tokenCases("agent", "l1/protocol/a2a/agent-card"), "403"},
	{standin.Refuse403, "mcp", tokenCases("mcp", "l2/audit/tool-record"), "403"},
	{standin.NoChallenge, "agent", tokenCases("agent", "l1/protocol/a2a/agent-card"), "WWW-Authenticate"},
	{standin.NoChallenge, "mcp", tokenCases("mcp", "l2/audit/tool-record"), "WWW-Authenticate"},
	{standin.ForwardInbound, "agent", agentTaskCases, ""},
	{standin.InboundToModel, "agent", []string{"l1/delegation/model-token"}, "not the STS"},
	{standin.ForwardWhenRefused, "agent", []string{"l1/delegation/refused-exchange"}, "reached the MCP server"},
	{standin.CacheByTargetOnly, "agent", []string{"l1/cache-isolation/concurrent-users"}, "another user's token"},
	{standin.NoTaskHeader, "agent", []string{"l1/cache-isolation/concurrent-users", "l1/limits/model-calls", "l1/limits/tool-calls", "l1/telemetry/canary-secret", "l1/telemetry/trace-continues", "l2/injection/tool-outside-allowlist"}, ""},
	{standin.NewTrace, "agent", []string{"l1/limits/model-calls", "l1/limits/tokens", "l1/limits/tool-calls", "l1/limits/wall-time", "l1/telemetry/canary-secret", "l1/telemetry/content-only-genai", "l1/telemetry/resource-and-task", "l1/telemetry/trace-continues"}, ""},
	{standin.NewTrace, "mcp", []string{"l1/telemetry/resource-and-task", "l1/telemetry/trace-continues"}, "trace"},
	{standin.NoRedaction, "agent", []string{"l1/telemetry/canary-secret"}, "redaction"},
	{standin.LegacyContent, "agent", []string{"l1/telemetry/content-only-genai"}, "gcp.vertex.agent.llm_request"},
	{standin.NoReleaseID, "agent", []string{"l1/telemetry/resource-and-task"}, "platform.release.id"},
	{standin.NoReleaseID, "mcp", []string{"l1/telemetry/resource-and-task"}, "platform.release.id"},
	{standin.NoTaskAttributes, "agent", []string{"l1/telemetry/resource-and-task"}, "task.id"},
	{standin.NoTaskAttributes, "mcp", []string{"l1/telemetry/resource-and-task"}, "task.id"},
	{standin.CardWithoutSecurity, "agent", []string{"l1/protocol/a2a/agent-card"}, "bearer"},
	{standin.CancelIgnored, "agent", []string{"l1/protocol/a2a/cancel"}, "TASK_STATE_CANCELED"},
	{standin.UnknownTaskOK, "agent", []string{"l1/protocol/a2a/task-states"}, "-32001"},
	{standin.HealthNeedsToken, "agent", []string{"l1/lifecycle/health"}, "/healthz"},
	{standin.HealthNeedsToken, "mcp", []string{"l1/lifecycle/health"}, "/healthz"},
	{standin.NoAnnotations, "mcp", []string{"l1/protocol/mcp/tools"}, "readOnlyHint"},
	{standin.UnknownToolCrash, "mcp", []string{"l1/protocol/mcp/tools"}, "unknown tool"},
	{standin.MalformedCrash, "agent", []string{"l1/protocol/a2a/errors"}, "not JSON"},
	{standin.MalformedCrash, "mcp", []string{"l1/protocol/mcp/errors"}, "not JSON"},
	{standin.NoRetry, "agent", []string{"l1/retries/model-429", "l1/retries/model-5xx-bounded"}, ""},
	{standin.UnboundedRetry, "agent", []string{"l1/retries/model-429", "l1/retries/model-5xx-bounded"}, ""},
	{standin.RetryNoBackoff, "agent", []string{"l1/retries/model-429", "l1/retries/model-5xx-bounded"}, "after"},
	{standin.IgnoreToolLimit, "agent", []string{"l1/limits/tool-calls"}, "tool_calls"},
	{standin.IgnoreModelLimit, "agent", []string{"l1/limits/model-calls"}, "model_calls"},
	{standin.IgnoreTokenLimit, "agent", []string{"l1/limits/tokens"}, "tokens"},
	{standin.IgnoreWallTime, "agent", []string{"l1/limits/wall-time"}, "limit_exceeded"},
	{standin.IgnoreWallTime, "mcp", []string{"l1/limits/wall-time"}, "late"},
	{standin.LimitAsText, "agent", []string{"l1/limits/model-calls", "l1/limits/tokens", "l1/limits/tool-calls", "l1/limits/wall-time"}, "data part"},
	{standin.LimitAsText, "mcp", []string{"l1/limits/wall-time"}, "structured content"},
	{standin.CallOutsideAllowlist, "agent", []string{"l2/injection/tool-outside-allowlist"}, "outside its allowlist"},
	{standin.NoApprovalCheck, "mcp", approvalCases, ""},
	{standin.ApprovalIgnoresParams, "mcp", []string{"l2/approvals/changed-parameters"}, "applied"},
	{standin.ApprovalIgnoresVersion, "mcp", []string{"l2/approvals/newer-version"}, "applied"},
	{standin.ApprovalNeverExpires, "mcp", []string{"l2/approvals/expired"}, "applied"},
	{standin.ApprovalReusable, "mcp", []string{"l2/approvals/reused"}, "applied"},
	{standin.SelfApproval, "mcp", []string{"l2/approvals/proposer-approves"}, "applied"},
	{standin.AgentApproves, "mcp", []string{"l2/approvals/agent-approves"}, "applied"},
	{standin.ApprovalAnyCaller, "mcp", []string{"l2/approvals/other-caller"}, "applied"},
	{standin.NoIdempotency, "mcp", []string{"l2/idempotency/same-task"}, "replay"},
	{standin.AuditRecordsArguments, "mcp", []string{"l2/audit/tool-record"}, "arguments"},
	{standin.NoAuditRecord, "mcp", []string{"l2/approvals/without-record", "l2/audit/tool-record", "l2/idempotency/same-task"}, ""},
	{standin.AuditOnRefusedToken, "mcp", []string{"l2/audit/tool-record"}, "token check"},
}

// maybeFails are cases whose verdict under a fault depends on what ran
// before them, such as whose token a shared cache holds when they start;
// the case built to detect the fault fails whatever ran before.
var maybeFails = map[standin.Fault][]string{
	standin.CacheByTargetOnly: {"l1/delegation/model-token", "l1/delegation/refused-exchange", "l1/delegation/tool-token"},
}

func TestFaults(t *testing.T) {
	if testing.Short() {
		t.Skip("every fault against every case: about two minutes")
	}
	seen := map[standin.Fault]bool{}
	sem := make(chan struct{}, 6)
	var wg sync.WaitGroup
	for _, f := range faults {
		seen[f.fault] = true
		yaml := agentYAML
		if f.kind == "mcp" {
			yaml = serverYAML
		}
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			res := runAll(t, yaml, standin.Faults{f.fault})
			want, maybe := map[string]bool{}, map[string]bool{}
			for _, id := range maybeFails[f.fault] {
				maybe[id] = true
			}
			for _, id := range f.expect {
				want[id] = true
				if _, ok := res[id]; !ok {
					t.Errorf("%s (%s): no case %s", f.fault, f.kind, id)
				}
			}
			for _, id := range ids(res) {
				r := res[id]
				switch {
				case want[id] && r.Status != runner.Fail:
					t.Errorf("%s (%s): %s should fail, got %s", f.fault, f.kind, id, r.Status)
				case want[id] && f.words != "" && !strings.Contains(r.Message, f.words):
					t.Errorf("%s (%s): %s failed without naming %q:\n%s", f.fault, f.kind, id, f.words, r.Message)
				case !want[id] && !maybe[id] && r.Status != runner.Pass:
					t.Errorf("%s (%s): %s should pass, got %s:\n%s", f.fault, f.kind, id, r.Status, r.Message)
				}
			}
		}()
	}
	wg.Wait()
	for _, f := range standin.All {
		if !seen[f] {
			t.Errorf("fault %s has no expectation", f)
		}
	}
}

// TestEveryCaseFails: every case fails against at least one faulty
// stand-in, so none can pass on any answer.
func TestEveryCaseFails(t *testing.T) {
	detected := map[string]bool{}
	for _, f := range faults {
		for _, id := range f.expect {
			detected[id] = true
		}
	}
	for name, yaml := range map[string]string{"agent": agentYAML, "mcp": serverYAML} {
		w := newWorld(t, yaml, nil)
		for _, k := range casesOf(w) {
			if !detected[k] {
				t.Errorf("%s: case %s fails against no faulty stand-in", name, k)
			}
		}
		w.cleanup()
	}
}
