package workload

import (
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

func jsonDecode(r io.Reader, v any) error { return json.NewDecoder(io.LimitReader(r, 4<<20)).Decode(v) }

// refusedByWorkload checks an outcome is the workload's own refusal of an
// inbound token: 401 and WWW-Authenticate: Bearer, with
// error="invalid_token" when a token was sent (RFC 6750; agent-sdk's
// spec/vectors/README.md).
func refusedByWorkload(c *C, what string, o outcome.Outcome, sent bool) {
	if o.Kind != outcome.Response {
		c.Errorf("%s: no answer from the workload: %s", what, o)
		return
	}
	if o.Status != http.StatusUnauthorized {
		if o.Status < 400 {
			c.Errorf("%s got through: %s", what, o)
		} else {
			c.Errorf("%s: refused with %d, not the 401 RFC 6750 asks for: %s", what, o.Status, o)
		}
		return
	}
	ch := strings.ToLower(o.Header["www-authenticate"])
	if !strings.HasPrefix(ch, "bearer") {
		c.Errorf("%s: 401 without WWW-Authenticate: Bearer (got %q)", what, o.Header["www-authenticate"])
		return
	}
	if sent && !strings.Contains(ch, `error="invalid_token"`) {
		c.Errorf("%s: a token was sent, so the challenge names error=\"invalid_token\" (got %q)", what, o.Header["www-authenticate"])
	}
}

// answeredByWorkload checks the allowed twin: the protocol answered.
func answeredByWorkload(c *C, what string, o outcome.Outcome) bool {
	if o.Kind != outcome.Response || o.Status == http.StatusUnauthorized || o.Status == http.StatusForbidden || o.Status >= 500 {
		c.Errorf("the allowed twin, %s, was not answered: %s", what, o)
		return false
	}
	return true
}

type identityCase struct {
	id, title string
	sent      bool
	// token makes the token the case sends; valid is its twin.
	token func(c *C, valid string) string
}

func identityCases(e *Env) []Case {
	var cases []identityCase
	if e.Agent() {
		cases = personIdentityCases(e)
	} else {
		cases = chainIdentityCases(e)
	}
	var out []Case
	for _, k := range cases {
		k := k
		out = append(out, Case{
			ID: "l1/identity/" + k.id, Suite: "l1/identity", Layer: LayerIdentity,
			Row:   "Identity: refuses tokens that are missing, expired, for another audience or issuer, alg none, HMAC-signed with the public key, or signed by an unknown kid; accepts only its own audience",
			Title: k.title,
			Run: func(c *C) {
				person := contract.NewPerson("conformance")
				valid := c.Env.Inbound(c, person)
				if !answeredByWorkload(c, "the route's own token", c.Env.Probe(c, valid)) {
					return
				}
				refusedByWorkload(c, k.title, c.Env.Probe(c, k.token(c, valid)), k.sent)
			},
		})
	}
	return out
}

// personIdentityCases are an agent's: people's tokens from the realm.
func personIdentityCases(e *Env) []identityCase {
	other := "https://gateway." + e.S.Domain + "/a2a/" + contract.ElsewhereServer
	p := func(c *C, o contract.TokenOpts) string {
		return c.Env.Person(contract.NewPerson("conformance"), o)
	}
	ago := func(d time.Duration) time.Time { return time.Now().Add(-d) }
	ahead := time.Now().Add(120 * time.Second)
	return []identityCase{
		{id: "missing", title: "a request without a token", token: func(*C, string) string { return "" }},
		{id: "expired", title: "a token expired 120 seconds ago", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{IssuedAt: ago(420 * time.Second), Lifetime: 300 * time.Second})
		}},
		{id: "other-audience", title: "a token for another route", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Audience: other})
		}},
		{id: "two-audiences", title: "a token for the route and another", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Audience: []string{c.Env.OwnRoute(), other}})
		}},
		{id: "other-issuer", title: "a token naming another issuer, signed with the trusted key", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Issuer: "https://other-issuer.conformance.invalid/realms/agentic"})
		}},
		{id: "alg-none", title: "an unsigned token, alg none", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Alg: "none"})
		}},
		{id: "hs256-public-key", title: "a token signed HS256 with the issuer's public key", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Alg: "HS256"})
		}},
		{id: "unknown-kid", title: "a token signed by a key the issuer does not publish", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Kid: "conformance-unknown", Key: contract.UnknownSigner("RS256")})
		}},
		{id: "tampered", title: "a token whose claims changed under its signature", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Tamper: true})
		}},
		{id: "typ-jwt", title: "a token typed JWT, not at+jwt", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Typ: "JWT"})
		}},
		{id: "nbf-120s-ahead", title: "a token not valid for another 120 seconds", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{NotBefore: &ahead})
		}},
		{id: "carries-act", title: "a realm token that carries an act", sent: true, token: func(c *C, _ string) string {
			return p(c, contract.TokenOpts{Act: map[string]any{"sub": "agentic-local/elsewhere/impostor"}})
		}},
	}
}

// chainIdentityCases are an MCP server's: chain tokens from the STS. The
// forgeries are signed with the STS's own key, so each breaks one property.
func chainIdentityCases(e *Env) []identityCase {
	claims := func(c *C, valid string) map[string]any {
		t, err := jose.Parse(valid)
		if err != nil {
			c.Fatalf("the STS's chain token does not parse: %v", err)
		}
		out := map[string]any{}
		for k, v := range t.Claims {
			out[k] = v
		}
		return out
	}
	forge := func(change func(map[string]any), header map[string]any) func(c *C, valid string) string {
		return func(c *C, valid string) string {
			cl := claims(c, valid)
			cl["jti"] = contract.UUID()
			change(cl)
			return c.Env.Forge(c, header, cl)
		}
	}
	now := time.Now().Unix()
	return []identityCase{
		{id: "missing", title: "a request without a token", token: func(*C, string) string { return "" }},
		{id: "expired", title: "a chain token expired 120 seconds ago", sent: true, token: forge(func(m map[string]any) {
			m["iat"], m["nbf"], m["exp"] = now-420, now-420, now-120
		}, nil)},
		{id: "other-audience", title: "a chain token for another route", sent: true, token: func(c *C, _ string) string {
			return c.Env.CallerToken(c, contract.CallerName, contract.NewPerson("conformance"), "https://workloads-gateway."+c.Env.S.Domain+"/mcp/"+contract.ElsewhereServer)
		}},
		{id: "two-audiences", title: "a chain token for the route and another", sent: true, token: forge(func(m map[string]any) {
			m["aud"] = []string{m["aud"].(string), "https://workloads-gateway." + e.S.Domain + "/mcp/" + contract.ElsewhereServer}
		}, nil)},
		{id: "other-issuer", title: "a chain token naming another issuer, signed with the STS's key", sent: true, token: forge(func(m map[string]any) {
			m["iss"] = "https://other-sts.conformance.invalid"
		}, nil)},
		{id: "alg-none", title: "an unsigned chain token, alg none", sent: true, token: func(c *C, valid string) string {
			t, _ := jose.Parse(valid)
			tok, _ := jose.Sign(map[string]any{"alg": "none", "typ": "at+jwt", "kid": t.HeaderString("kid")}, claims(c, valid), nil)
			return tok
		}},
		{id: "hs256-public-key", title: "a chain token signed HS256 with the STS's public key", sent: true, token: func(c *C, valid string) string {
			t, _ := jose.Parse(valid)
			pub, err := c.Env.stsKey(c, t.HeaderString("kid"))
			if err != nil {
				c.Fatalf("the STS's public key: %v", err)
			}
			pem, _ := jose.PublicPEM(pub)
			tok, _ := jose.Sign(map[string]any{"alg": "HS256", "typ": "at+jwt", "kid": t.HeaderString("kid")}, claims(c, valid), pem)
			return tok
		}},
		{id: "unknown-kid", title: "a chain token signed by a key the STS does not publish", sent: true, token: func(c *C, valid string) string {
			tok, _ := jose.Sign(map[string]any{"alg": "ES256", "typ": "at+jwt", "kid": "conformance-unknown"}, claims(c, valid), contract.UnknownSigner("ES256"))
			return tok
		}},
		{id: "tampered", title: "a chain token whose claims changed under its signature", sent: true, token: func(c *C, valid string) string {
			cl := claims(c, valid)
			cl["sub"] = contract.UUID()
			tok, _ := jose.ReplaceClaims(valid, cl)
			return tok
		}},
		{id: "typ-jwt", title: "a chain token typed JWT, not at+jwt", sent: true, token: forge(func(map[string]any) {}, map[string]any{"typ": "JWT"})},
		{id: "nbf-120s-ahead", title: "a chain token not valid for another 120 seconds", sent: true, token: forge(func(m map[string]any) {
			m["nbf"] = time.Now().Unix() + 120
		}, nil)},
		{id: "no-act", title: "an STS token without act, which the STS never issues", sent: true, token: forge(func(m map[string]any) {
			delete(m, "act")
		}, nil)},
		{id: "person-token", title: "a person's realm token for the hosted-workloads route, which only chain tokens reach", sent: true, token: func(c *C, _ string) string {
			return c.Env.Person(contract.NewPerson("conformance"), contract.TokenOpts{Audience: c.Env.OwnRoute()})
		}},
	}
}
