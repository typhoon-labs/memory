package workload_test

import (
	"context"
	"sort"
	"strings"
	"sync"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload/standin"
)

// The suites' own tests: every case against the stand-in workload, honest
// and then with one fault at a time, as the platform-controls suites'
// tests do. The cases of one world run at once: each keeps to its own
// task IDs, markers and directive ids, as in the stage, where they run one
// after another.

func runAll(t *testing.T, yaml string, faults standin.Faults) map[string]runner.Result {
	t.Helper()
	w := newWorld(t, yaml, faults)
	defer w.cleanup()
	cases := workload.Cases(w.env)
	out := map[string]runner.Result{}
	var mu sync.Mutex
	var wg sync.WaitGroup
	var alone []workload.Case
	for _, k := range cases {
		if exclusive[k.ID] && w.env.Workload.Kind == "mcp-server" {
			alone = append(alone, k)
			continue
		}
		if env, ok := ownWorld[k.ID]; ok {
			wg.Add(1)
			go func(id string) {
				defer wg.Done()
				r := runAlone(t, yaml, faults, id, env)
				mu.Lock()
				out[id] = r
				mu.Unlock()
			}(k.ID)
			continue
		}
		wg.Add(1)
		go func(k workload.Case) {
			defer wg.Done()
			r := runner.Run(context.Background(), w.env, k)
			mu.Lock()
			out[k.ID] = r
			mu.Unlock()
		}(k)
	}
	wg.Wait()
	for _, k := range alone {
		out[k.ID] = runner.Run(context.Background(), w.env, k)
	}
	return out
}

// ownWorld are cases whose own timing the shared world's caps do not fit,
// each run in a world of its own with this more of the stand-in's
// environment. Two 429s with Retry-After: 1, and the backoff after each,
// take two seconds and more, which on a loaded runner under the race
// detector, with every other case of the world at once, went past the
// shared wall-time cap of 3 seconds now and then: the task stopped before
// its third attempt. 15 seconds leaves clear margin; the case's assertions
// are unchanged.
var ownWorld = map[string]map[string]string{
	"l1/retries/model-429": {"AGENTIC_LIMIT_WALL_TIME_SECONDS": "15"},
}

// runAlone runs one case in a world of its own, with env over the
// stand-in's environment.
func runAlone(t *testing.T, yaml string, faults standin.Faults, id string, env map[string]string) runner.Result {
	t.Helper()
	w := newWorld(t, yaml, faults, env)
	defer w.cleanup()
	for _, k := range workload.Cases(w.env) {
		if k.ID == id {
			return runner.Run(context.Background(), w.env, k)
		}
	}
	return runner.Result{ID: id, Status: runner.Fail, Message: "no such case in its own world"}
}

// exclusive are cases that change what every other call meets: an MCP
// server's wall-time case slows its database for a while. They run after
// the others, as in the stage, where cases run one at a time.
var exclusive = map[string]bool{"l1/limits/wall-time": true}

func ids(m map[string]runner.Result) []string {
	var out []string
	for id := range m {
		out = append(out, id)
	}
	sort.Strings(out)
	return out
}

func TestHonest(t *testing.T) {
	for name, yaml := range map[string]string{"agent": agentYAML, "mcp-server": serverYAML} {
		t.Run(name, func(t *testing.T) {
			t.Parallel()
			res := runAll(t, yaml, nil)
			if len(res) == 0 {
				t.Fatal("no cases")
			}
			for _, id := range ids(res) {
				r := res[id]
				if r.Status != runner.Pass {
					t.Errorf("%s: want pass against the honest stand-in, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
				}
			}
		})
	}
}

// TestLateRootSpan: with a task's root span sent later than the wait the
// world gives (Env.Wait), as a loaded runner can delay it, every case of
// an agent still passes: the cases wait on the stand-in's delivery signal,
// not on wall time.
func TestLateRootSpan(t *testing.T) {
	w := newWorld(t, agentYAML, nil, map[string]string{"STANDIN_ROOT_SPAN_DELAY": "5s"})
	defer w.cleanup()
	var mu sync.Mutex
	var wg sync.WaitGroup
	res := map[string]runner.Result{}
	for _, k := range workload.Cases(w.env) {
		if _, own := ownWorld[k.ID]; own {
			continue
		}
		wg.Add(1)
		go func(k workload.Case) {
			defer wg.Done()
			r := runner.Run(context.Background(), w.env, k)
			mu.Lock()
			res[k.ID] = r
			mu.Unlock()
		}(k)
	}
	wg.Wait()
	for _, id := range ids(res) {
		if r := res[id]; r.Status != runner.Pass {
			t.Errorf("%s: want pass with the root span 5 s late, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
}

// TestWallTimeWithPooledDatabase: an MCP server that keeps its database
// connections open across calls, as a real server's pool does (asyncpg's,
// in reference-mcp), is still seen reaching its database through the
// stage's proxy. A read-only call first (the resource-and-task case's)
// opens the connection, which the wall-time case's calls then reuse.
func TestWallTimeWithPooledDatabase(t *testing.T) {
	w := newWorld(t, serverYAML, nil, map[string]string{"STANDIN_DATABASE_POOLED": "true"})
	defer w.cleanup()
	byID := map[string]workload.Case{}
	for _, k := range workload.Cases(w.env) {
		byID[k.ID] = k
	}
	for _, id := range []string{"l1/telemetry/resource-and-task", "l1/limits/wall-time"} {
		k, ok := byID[id]
		if !ok {
			t.Fatalf("no %s case for an MCP server with a database", id)
		}
		if r := runner.Run(context.Background(), w.env, k); r.Status != runner.Pass {
			t.Errorf("%s: want pass against a stand-in with a pooled database, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
}
