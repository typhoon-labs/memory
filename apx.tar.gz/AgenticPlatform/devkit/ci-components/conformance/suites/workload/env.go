// Package workload holds the workload suites of design/conformance.md: L1
// (identity, delegation, token cache isolation, telemetry, protocol,
// lifecycle, retries, limits) and L2 (approvals, idempotency, injection
// canaries), run in a workload's merge request by the conformance
// component's contract stage against the workload alone, beside the
// harness of package contract. Each case proves a refusal and its allowed
// twin and names the layer that refuses: the workload's own token check,
// its delegation, its limits, its tools' approvals.
//
// Which cases run follows the workload's workload.yaml: an agent's or an
// MCP server's, delegation and cache isolation for an agent that calls on,
// L2 for a server with a destructive tool. The suites' own tests run every
// case against package standin, honest and with each fault.
package workload

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// Case and C are the runner's, over this package's Env.
type (
	Case = runner.Case[*Env]
	C    = runner.C[*Env]
)

// Layers the cases assert.
const (
	LayerIdentity   = "workload-identity"   // the workload's inbound token check: 401 with WWW-Authenticate: Bearer
	LayerProtocol   = "workload-protocol"   // the protocol's own error shapes
	LayerDelegation = "workload-delegation" // what the workload sends downstream
	LayerSTS        = "sts"                 // the STS refused the exchange
	LayerTelemetry  = "workload-telemetry"  // what the workload exports
	LayerResilience = "workload-resilience" // its retries
	LayerLimits     = "workload-limits"     // its limits module
	LayerApproval   = "tool-approval"       // the executing tool's approval check
	LayerIdempotent = "tool-idempotency"    // the executing tool's idempotency
	LayerAllowlist  = "workload-allowlist"  // the agent's own tool allowlist
)

// Settings are what the stage gave the workload through its environment,
// which the cases must know.
type Settings struct {
	Domain, Cluster string
	// Limits are AGENTIC_LIMIT_*, by the limits' names.
	Limits map[string]int
	// ApprovalTTL is AGENTIC_APPROVAL_TTL_SECONDS.
	ApprovalTTL time.Duration
	// ApprovalAudience is AGENTIC_APPROVAL_AUDIENCE.
	ApprovalAudience string
	// ReleaseID is platform.release.id in OTEL_RESOURCE_ATTRIBUTES;
	// ServiceName is OTEL_SERVICE_NAME, or the workload's name.
	ReleaseID, ServiceName string
}

// Env is what the cases run against.
type Env struct {
	RunID    string
	Workload *contract.Workload
	Level    string
	URL      string // the workload's base URL
	H        *contract.Harness
	S        Settings
	HTTP     *outcome.Client
	// Denied is a person on the STS's deny list.
	Denied contract.Person
	// Wait bounds a wait for telemetry or records to arrive; default 30s.
	Wait time.Duration
	// Settle, set by a stand-in only, returns once everything the workload
	// has sent so far has reached the harness: a wait then judges at once
	// instead of waiting out Wait. The contract stage leaves it nil.
	Settle func(ctx context.Context) error

	mu     sync.Mutex
	serial int
}

// Unmet: the contract stage's cases need nothing beyond the harness.
func (e *Env) Unmet(n runner.Need) string { return "" }

// Marker is unique to the run and the call.
func (e *Env) Marker(what string) string {
	e.mu.Lock()
	e.serial++
	n := e.serial
	e.mu.Unlock()
	return fmt.Sprintf("conformance-%s-%s-%d", what, e.RunID, n)
}

// await calls f, once a second, until it holds or the wait passes, and
// reports whether it held. Against a stand-in that signals delivery, f's
// answer once everything sent is delivered is final; the stand-in bounds
// its own signal, as a backstop.
func (e *Env) await(c *C, f func() bool) bool {
	deadline := time.Now().Add(e.wait())
	for {
		if f() {
			return true
		}
		if e.Settle != nil {
			if err := e.Settle(c); err != nil {
				c.Logf("the stand-in did not settle: %v", err)
			}
			return f()
		}
		if time.Now().After(deadline) {
			return false
		}
		c.Sleep(time.Second)
	}
}

func (e *Env) wait() time.Duration {
	if e.Wait > 0 {
		return e.Wait
	}
	return 30 * time.Second
}

// Agent reports whether the workload is an agent.
func (e *Env) Agent() bool { return e.Workload.Kind == "agent" }

func (e *Env) proto() string {
	if e.Agent() {
		return "a2a"
	}
	return "mcp"
}

// OwnRoute is the workload's route on the deployment its callers use: a
// person calls an agent through the developer deployment; an agent calls
// an MCP server through the hosted-workloads deployment.
func (e *Env) OwnRoute() string {
	if e.Agent() {
		return "https://gateway." + e.S.Domain + "/a2a/" + e.Workload.Name
	}
	return "https://workloads-gateway." + e.S.Domain + "/mcp/" + e.Workload.Name
}

// ActorSub is the workload's canonical actor name, as act.sub carries it.
func (e *Env) ActorSub() string {
	return e.S.Cluster + "/" + e.Workload.Name + "/" + e.Workload.Name
}

// CallerSub is the runner's caller's canonical actor name.
func (e *Env) CallerSub(caller string) string {
	return e.S.Cluster + "/" + contract.CallerNamespace + "/" + caller
}

// Person mints a person's token for the agent's route, or opts' audience.
func (e *Env) Person(p contract.Person, o contract.TokenOpts) string {
	if o.Audience == nil {
		o.Audience = "https://gateway." + e.S.Domain + "/a2a/" + e.Workload.Name
	}
	tok, _ := e.H.Keycloak.Mint(p, o)
	return tok
}

// CallerToken is a chain token for the workload's own route, for p, from
// the STS: the runner plays caller, an agent the policy lets call it.
func (e *Env) CallerToken(c *C, caller string, p contract.Person, resource string) string {
	subject := e.Person(p, contract.TokenOpts{Audience: "https://gateway." + e.S.Domain + "/a2a/" + caller})
	if resource == "" {
		resource = e.OwnRoute()
	}
	tok, status, body := e.H.Exchange(c, caller, subject, resource)
	if status != http.StatusOK || tok == "" {
		c.Fatalf("the harness's STS refused the runner's own exchange for %s: HTTP %d %s", resource, status, outcome.Compact(body))
	}
	return tok
}

// Forge signs claims with the STS's own key, so only the property the
// claims change is wrong.
func (e *Env) Forge(c *C, header, claims map[string]any) string {
	h := map[string]any{"alg": "ES256", "typ": "at+jwt"}
	for k, v := range header {
		if v == nil {
			delete(h, k)
		} else {
			h[k] = v
		}
	}
	tok, err := e.H.STS.Sign(c, h, claims)
	if err != nil {
		c.Fatalf("signing a test chain token with the STS's key: %v", err)
	}
	return tok
}

// stsKey is the STS's public key for kid, for HS256 forgeries.
func (e *Env) stsKey(c *C, kid string) (any, error) {
	req, _ := http.NewRequestWithContext(c, http.MethodGet, e.H.STS.JWKSURL(), nil)
	resp, err := e.H.STS.HTTP().Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var set jose.JWKS
	if err := jsonDecode(resp.Body, &set); err != nil {
		return nil, err
	}
	k, ok := set.Key(kid)
	if !ok && len(set.Keys) > 0 {
		k = set.Keys[0]
	}
	return k.Public()
}

// Inbound is a valid token for the workload's own route: a person's for an
// agent, a chain token from the runner's caller for an MCP server.
func (e *Env) Inbound(c *C, p contract.Person) string {
	if e.Agent() {
		return e.Person(p, contract.TokenOpts{})
	}
	return e.CallerToken(c, contract.CallerName, p, "")
}

// Probe makes the cheapest authenticated request of the workload's
// protocol: GetTask of an unknown task for an agent, tools/list for an MCP
// server.
func (e *Env) Probe(c *C, token string) outcome.Outcome {
	if e.Agent() {
		cl := e.A2A(token, nil)
		return cl.Get(c, "conformance-"+randomHex(8)).Outcome
	}
	cl := e.MCP(token, nil)
	return cl.Request(c, "tools/list", map[string]any{}).Outcome
}

// A2A is a client of the agent under test.
func (e *Env) A2A(token string, header map[string]string) *a2a.Client {
	return &a2a.Client{URL: e.A2AURL(), Token: token, Header: header, HTTP: e.HTTP, Timeout: outcome.Of(90 * time.Second)}
}

// A2AURL is where the agent serves A2A: /a2a/<name>, directly and through
// the gateway alike (B5's seams, "Paths through the gateway").
func (e *Env) A2AURL() string { return e.URL + "/a2a/" + e.Workload.Name }

// ApprovalURL is the approval route of a proposal: /approvals/<name>/<id>.
func (e *Env) ApprovalURL(id string) string {
	return e.URL + "/approvals/" + e.Workload.Name + "/" + id
}

// MCP is a client of the MCP server under test.
func (e *Env) MCP(token string, header map[string]string) *mcp.Client {
	return &mcp.Client{URL: e.URL + "/mcp", Token: token, Header: header, HTTP: e.HTTP}
}

// Schemas lists the MCP server's tools and returns each one's input
// schema, by name, so the cases fill arguments from what the server
// declares, never from names they assume.
func (e *Env) Schemas(c *C, token string) map[string]map[string]any {
	_, call := e.MCP(token, nil).ListTools(c)
	if !call.OK() {
		c.Fatalf("tools/list: %s", call)
	}
	var res struct {
		Tools []mcp.Tool `json:"tools"`
	}
	json.Unmarshal(call.Response.Result, &res)
	out := map[string]map[string]any{}
	for _, t := range res.Tools {
		out[t.Name] = t.InputSchema
	}
	return out
}

// IDProperty is the property of a tool's input schema that names an
// existing object, <thing>_id, such as note_id; "" when it has none.
func IDProperty(schema map[string]any) string {
	props, _ := schema["properties"].(map[string]any)
	for name := range props {
		if strings.HasSuffix(name, "_id") && name != "approval_id" {
			return name
		}
	}
	return ""
}

// TextProperty is the first string property a tool requires, else any
// string property but an ID: where a planted instruction goes.
func TextProperty(schema map[string]any) string {
	props, _ := schema["properties"].(map[string]any)
	req, _ := schema["required"].([]any)
	for _, r := range req {
		name, _ := r.(string)
		if p, _ := props[name].(map[string]any); p["type"] == "string" && !strings.HasSuffix(name, "_id") {
			return name
		}
	}
	for name, p := range props {
		if pm, _ := p.(map[string]any); pm["type"] == "string" && !strings.HasSuffix(name, "_id") {
			return name
		}
	}
	return ""
}

// Trace starts a W3C trace context for one request.
func Trace() (traceparent, traceID, spanID string) {
	traceID, spanID = randomHex(16), randomHex(8)
	return "00-" + traceID + "-" + spanID + "-01", traceID, spanID
}

func randomHex(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// Task runs one A2A task as p, with a task ID and a trace, and waits for it.
type Task struct {
	ID      string // the task ID the runner sent, Agentic-Task-Id
	TraceID string
	SpanID  string
	Person  contract.Person
	Call    a2a.Call
	Task    a2a.Task
	Err     error
	Took    time.Duration
}

// Send sends text to the agent as p and waits for the task's end.
func (e *Env) Send(c *C, p contract.Person, text string, script contract.Script) *Task {
	tp, trace, span := Trace()
	t := &Task{ID: "conformance-task-" + randomHex(8), TraceID: trace, SpanID: span, Person: p}
	if script != nil {
		e.H.Tools.Script(t.ID, script)
	}
	cl := e.A2A(e.Person(p, contract.TokenOpts{}), map[string]string{contract.TaskHeader: t.ID, "Traceparent": tp})
	start := time.Now()
	t.Call = cl.Send(c, e.Marker("message"), text, false)
	t.Took = time.Since(start)
	t.Task, t.Err = t.Call.Task()
	return t
}

// Loop answers every tool call with text that keeps the model's loop
// going, until call last, which ends it; last 0 never ends it.
func Loop(last int) contract.Script {
	return func(n int, tool string, _ []byte) string {
		if last > 0 && n >= last {
			return "done with " + tool + " " + contract.End
		}
		return fmt.Sprintf("result %d of %s", n, tool)
	}
}

// AllowedTool is a tool the agent may call, and its server.
func (e *Env) AllowedTool() (tool, server string) {
	for _, r := range e.Workload.Requires.Tools {
		for _, t := range r.Tools {
			return t, r.Server
		}
	}
	return "", ""
}

// CallsOn reports whether the agent calls MCP tools.
func (e *Env) CallsOn() bool { t, _ := e.AllowedTool(); return t != "" }

// Cap is the effective cap on a limit: the lower of the declared one and
// the one the stage set; ok is false when neither exists.
func (e *Env) Cap(limit string) (int, bool) {
	d, hasD := e.Workload.Limits[limit]
	s, hasS := e.S.Limits[limit]
	switch {
	case hasD && hasS:
		return min(d, s), true
	case hasD:
		return d, true
	case hasS:
		return s, true
	}
	return 0, false
}

func shorten(s string) string {
	s = strings.TrimSpace(s)
	if len(s) > 300 {
		return s[:300] + "…"
	}
	return s
}
