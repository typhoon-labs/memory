package workload

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// The integration stage (design/conformance.md, "How conformance runs in
// CI"): the cases that need the platform around a deployed workload, run
// as the Helm test of a workload-conformance release beside the
// platform-controls suites, against each deployed workload through the
// real gateways and STS. They reuse the platform suites' environment: its
// personas, probes, logs and stores.

// Target is a deployed workload the integration stage checks.
type Target struct {
	Name string `json:"name"`
	Kind string `json:"kind"` // agent or mcp-server
	// Route is its route on the developer deployment, where people reach
	// it: gateway/a2a/<name> for an agent, gateway/mcp/<name> for a server.
	Route string `json:"route"`
	// Scope is the client scope that gives Route's audience.
	Scope string `json:"scope"`
	// OtherScope is a scope of another route the developer persona has,
	// for the wrong-audience case; default models.
	OtherScope string `json:"other_scope"`
	// Direct is its Service's URL, bypassing the gateway:
	// http://<name>.<namespace>.svc.cluster.local:<port>.
	Direct string `json:"direct"`
	// Namespace and Selector find its pods, for the drain case.
	Namespace string `json:"namespace"`
	Selector  string `json:"selector"`
	// CallsModel: its tasks call the model route, for attribution and
	// trace continuity.
	CallsModel bool `json:"calls_model"`
	// Drain enables the SIGTERM case, which deletes one of its pods.
	Drain bool `json:"drain"`
	// Telemetry has an agent play the platform suites' telemetry group's
	// turn (B5, the plan's check 7): a tool it may call, whose result
	// names an argument's value, and its spans' service.name (default its
	// name). Unset, the group does not run with it.
	Telemetry *TelemetryTarget `json:"telemetry,omitempty"`
}

// TelemetryTarget is what the telemetry group needs of an agent that plays
// its turn (platform.TelemetryAgent).
type TelemetryTarget struct {
	Tool    string `json:"tool"`    // such as reference-mcp's get_note
	Arg     string `json:"arg"`     // such as note_id
	Service string `json:"service"` // its spans' service.name; default the agent's name
}

// Integration is the integration stage's environment.
type Integration struct {
	P       *platform.Env
	Targets []Target

	mu     sync.Mutex
	agents map[string]*platform.Env // by agent: the telemetry group's environment, its turn played by the agent
}

// telemetryEnv is the platform suites' environment whose telemetry group's
// turn t plays, made once, so its cases read one canary.
func (i *Integration) telemetryEnv(t Target) *platform.Env {
	i.mu.Lock()
	defer i.mu.Unlock()
	if i.agents == nil {
		i.agents = map[string]*platform.Env{}
	}
	if e, ok := i.agents[t.Name]; ok {
		return e
	}
	e := i.P.WithTelemetryAgent(platform.TelemetryAgent{Name: t.Name, Route: t.Route, Scope: t.Scope, Service: t.Telemetry.Service,
		Tool: t.Telemetry.Tool, Arg: t.Telemetry.Arg})
	i.agents[t.Name] = e
	return e
}

// telemetry runs one of the telemetry group's cases with t playing the
// turn, and reports its verdict as this case's.
func telemetry(c *IC, t Target, k platform.Case) {
	r := runner.Run(c, c.Env.telemetryEnv(t), k)
	for _, l := range r.Logs {
		c.Logf("%s", l)
	}
	switch r.Status {
	case runner.Fail:
		c.Errorf("%s", r.Message)
	case runner.Skip:
		c.Skipf("%s", r.Message)
	}
}

// Unmet defers to the platform suites' environment, but for pod deletion.
func (i *Integration) Unmet(n runner.Need) string {
	if n == NeedPodDeletion {
		if i.P.Kube == nil {
			return "the drain case deletes a pod through the API server: run in the cluster, with the right to delete the workload's pods (the environment's setup)"
		}
		return ""
	}
	return i.P.Unmet(n)
}

// ICase and IC are the runner's, over Integration.
type (
	ICase = runner.Case[*Integration]
	IC    = runner.C[*Integration]
)

// LoadTargets reads the workloads to check, a JSON list of Target.
func LoadTargets(path string) ([]Target, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var ts []Target
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&ts); err != nil {
		return nil, fmt.Errorf("%s: %v", path, err)
	}
	for i := range ts {
		t := &ts[i]
		if t.Name == "" || (t.Kind != "agent" && t.Kind != "mcp-server") || t.Route == "" || t.Scope == "" {
			return nil, fmt.Errorf("%s: workload %d needs name, kind (agent or mcp-server), route and scope", path, i)
		}
		if t.OtherScope == "" {
			t.OtherScope = "models"
		}
		if tt := t.Telemetry; tt != nil && (t.Kind != "agent" || tt.Tool == "" || tt.Arg == "") {
			return nil, fmt.Errorf("%s: workload %s: telemetry is an agent's, with tool and arg", path, t.Name)
		}
	}
	return ts, nil
}

// Integration needs, beyond the platform suites'.
const (
	NeedProbeMeshed = platform.NeedProbeMeshed
	NeedProbeNomesh = platform.NeedProbeNomesh
	NeedUsage       = platform.NeedUsageRecords
	NeedLangfuse    = platform.NeedLangfuse
	NeedDeveloper   = runner.Need("persona:" + platform.RoleDeveloper)
	NeedPodDeletion = runner.Need("pod-deletion")
)

// IntegrationCases are the integration stage's cases for every target.
func IntegrationCases(targets []Target) []ICase {
	var out []ICase
	for _, t := range targets {
		t := t
		id := func(suite, c string) string { return "integration/" + suite + "/" + t.Name + "/" + c }
		out = append(out,
			ICase{ID: id("gateway-path", "route-token"), Suite: "integration/gateway-path", Layer: "gateway", Cluster: true,
				Needs: []runner.Need{NeedDeveloper},
				Row:   "Gateway path: direct egress and ingress fail; attribution comes from the token",
				Title: "the workload's route refuses a person's token for another route with 401; its own token reaches the workload",
				Run:   func(c *IC) { routeToken(c, t) }},
			ICase{ID: id("bypass", "authorization-policy"), Suite: "integration/bypass", Layer: string(outcome.AuthorizationPolicy), Cluster: true,
				Needs: []runner.Need{NeedDeveloper, NeedProbeMeshed},
				Row:   "Gateway path: direct ingress to the pod, bypassing the gateway, fails",
				Title: "a direct request to the workload's Service from a meshed namespace without grants is denied by its sidecar; the same request through the gateway is answered",
				Run:   func(c *IC) { bypass(c, t, "meshed", outcome.AuthorizationPolicy) }},
			ICase{ID: id("bypass", "strict-mtls"), Suite: "integration/bypass", Layer: string(outcome.MTLS), Cluster: true,
				Needs: []runner.Need{NeedDeveloper, NeedProbeNomesh},
				Row:   "Gateway path: direct ingress to the pod, bypassing the gateway, fails",
				Title: "a plaintext request to the workload's Service from outside the mesh is refused by STRICT mTLS; the same request through the gateway is answered",
				Run:   func(c *IC) { bypass(c, t, "nomesh", outcome.MTLS) }},
		)
		if t.Kind == "agent" && t.CallsModel {
			out = append(out,
				ICase{ID: id("attribution", "from-token"), Suite: "integration/attribution", Layer: "gateway-record", Cluster: true,
					Needs: []runner.Need{NeedDeveloper, NeedUsage},
					Row:   "Attribution from verified claims",
					Title: "a task sent with a forged x-team, x-user-id and baggage is billed, for every model call the agent makes for it, to the token's user and team",
					Run:   func(c *IC) { attribution(c, t) }},
				ICase{ID: id("trace-continuity", "gateway-to-workload"), Suite: "integration/trace-continuity", Layer: "workload-telemetry", Cluster: true,
					Needs: []runner.Need{NeedDeveloper, NeedLangfuse},
					Row:   "Trace continuity",
					Title: "a task's traceparent continues through the gateway into the agent's spans and on to its model call's gateway span, all in one trace",
					Run:   func(c *IC) { traceContinuity(c, t) }},
			)
		}
		if t.Kind == "agent" && t.Telemetry != nil {
			for _, k := range platform.TelemetryAgentCases() {
				out = append(out, ICase{ID: id("telemetry", strings.TrimPrefix(k.ID, "telemetry/")), Suite: "integration/telemetry", Layer: k.Layer, Cluster: true,
					Needs: k.Needs, Row: "Telemetry, with the agent as the emitter: " + k.Row, Title: "with " + t.Name + " playing the turn: " + k.Title,
					Run: func(c *IC) { telemetry(c, t, k) }})
			}
		}
		if t.Kind == "agent" && t.Drain {
			out = append(out, ICase{ID: id("lifecycle", "sigterm-drain"), Suite: "integration/lifecycle", Layer: "workload-lifecycle", Cluster: true,
				Needs: []runner.Need{NeedDeveloper, NeedPodDeletion, NeedLangfuse},
				Row:   "Lifecycle: SIGTERM drains in-flight work within the grace period, and the drained turn's spans reach its trace (T31)",
				Title: "a task in flight when its pod is deleted still completes: SIGTERM drains it, and the agent's spans of that turn, its invoke_agent span and its model call's, which end after SIGTERM, reach Langfuse in the task's trace, whether a flush at shutdown or a scheduled export sent them; a task after the new pod is ready completes too",
				Run:   func(c *IC) { drain(c, t) }})
		}
	}
	return out
}

func (i *Integration) token(c *IC, scope string) string {
	tok, err := i.P.Tokens.Token(c, platform.RoleDeveloper, scope)
	if err != nil {
		c.Fatalf("the developer's token for %s: %v", scope, err)
	}
	return tok
}

func (i *Integration) gatewayURL(t Target) string {
	gw, rest, _ := strings.Cut(t.Route, "/")
	return strings.TrimRight(i.P.Cfg.Gateways[gw], "/") + "/" + rest
}

// probe asks the workload the cheapest authenticated question, through
// url, from src.
func probe(c *IC, src platform.Source, t Target, base, token string, header map[string]string) outcome.Outcome {
	if t.Kind == "agent" {
		cl := &a2a.Client{URL: base, Token: token, Header: header, HTTP: src}
		return cl.Get(c, "conformance-"+randomHex(6)).Outcome
	}
	cl := &mcp.Client{URL: base, Token: token, Header: header, HTTP: src}
	return cl.Request(c, "tools/list", map[string]any{}).Outcome
}

func routeToken(c *IC, t Target) {
	e := c.Env
	own := probe(c, e.P.Runner, t, e.gatewayURL(t), e.token(c, t.Scope), nil)
	if own.Kind != outcome.Response || own.Status == http.StatusUnauthorized || own.Status == http.StatusForbidden || own.Status >= 500 {
		c.Fatalf("the allowed twin, the route's own token, was not answered: %s", own)
	}
	other := probe(c, e.P.Runner, t, e.gatewayURL(t), e.token(c, t.OtherScope), nil)
	if other.Kind != outcome.Response || other.Status != http.StatusUnauthorized {
		c.Errorf("a token for %s on %s: want the gateway's 401, got %s", t.OtherScope, t.Route, other)
	}
}

func bypass(c *IC, t Target, probeName string, want outcome.Layer) {
	e := c.Env
	if t.Direct == "" {
		c.Fatalf("workload %s has no direct URL to bypass the gateway with", t.Name)
	}
	src, ok := e.P.Probes[probeName]
	if !ok {
		c.Fatalf("no %s probe", probeName)
	}
	tok := e.token(c, t.Scope)
	if twin := probe(c, e.P.Runner, t, e.gatewayURL(t), tok, nil); twin.Kind != outcome.Response || twin.Status >= 400 && twin.Status != http.StatusNotFound {
		c.Fatalf("the allowed twin, the same request through the gateway, was not answered: %s", twin)
	}
	direct := strings.TrimRight(t.Direct, "/")
	if t.Kind == "agent" {
		direct += "/a2a/" + t.Name
	} else {
		direct += "/mcp"
	}
	o := probe(c, src, t, direct, tok, nil)
	if got := outcome.Refuser(o, src.Source); got != want {
		c.Errorf("a direct request to %s from %s: want %s to refuse it, got %s (%s)", direct, probeName, want, got, o)
	}
}

// task sends one A2A task through the developer deployment and waits.
func (i *Integration) task(c *IC, t Target, text string, header map[string]string) a2a.Call {
	cl := &a2a.Client{URL: i.gatewayURL(t), Token: i.token(c, t.Scope), Header: header, HTTP: i.P.Runner, Timeout: outcome.Of(3 * time.Minute)}
	return cl.Send(c, "conformance-"+randomHex(6), text, false)
}

func attribution(c *IC, t Target) {
	e := c.Env
	tok := e.token(c, t.Scope)
	jt, err := jose.Parse(tok)
	if err != nil {
		c.Fatalf("the developer's token: %v", err)
	}
	sub, _ := jt.Claims["sub"].(string)
	team, _ := jt.Claims["team"].(string)
	const forgedTeam, forgedUser = "conformance-forged-team", "conformance-forged-user"
	tp, trace, _ := Trace()
	call := e.task(c, t, "Say something short.", map[string]string{"Traceparent": tp, "x-team": forgedTeam, "x-user-id": forgedUser,
		"baggage": "user.team=" + forgedTeam + ",user.id=" + forgedUser})
	if task, err := call.Task(); err != nil || task.Status.State != a2a.Completed {
		c.Fatalf("the task did not complete: %v %s", err, call)
	}
	var rows []map[string]any
	deadline := time.Now().Add(max(e.P.Cfg.UsageTable.Wait.Duration, time.Minute))
	for len(rows) == 0 && time.Now().Before(deadline) {
		if rows, err = e.usageRows(c, trace); err != nil {
			c.Fatalf("%v", err)
		}
		if len(rows) == 0 {
			c.Sleep(3 * time.Second)
		}
	}
	if len(rows) == 0 {
		c.Fatalf("no usage row has the task's trace ID %s: the agent's model calls were not billed, or not in the task's trace", trace)
	}
	for _, r := range rows {
		if fmt.Sprint(r["user_id"]) != sub || fmt.Sprint(r["user_team"]) != team {
			c.Errorf("a usage row of the task names user %v and team %v, not the token's %s and %s", r["user_id"], r["user_team"], sub, team)
		}
	}
}

// usageRows reads the usage table's rows of one trace, as the platform
// suites' attribution case does.
func (i *Integration) usageRows(c *IC, trace string) ([]map[string]any, error) {
	u := i.P.Cfg.UsageTable
	pw, err := os.ReadFile(i.P.Cfg.Path(u.PasswordFile))
	if err != nil {
		return nil, fmt.Errorf("usage_table.password_file: %v", err)
	}
	ident := func(s string) string { return "`" + strings.ReplaceAll(s, "`", "``") + "`" }
	query := fmt.Sprintf("SELECT user_id, user_team FROM %s.%s WHERE trace_id = {trace:String} FORMAT JSONEachRow", ident(u.Database), ident(u.Table))
	resp, err := i.P.Read.Do(c, http.MethodPost, u.URL+"/?"+url.Values{"param_trace": {trace}}.Encode(),
		map[string]string{"X-ClickHouse-User": u.User, "X-ClickHouse-Key": strings.TrimSpace(string(pw)), "Content-Type": "text/plain"}, []byte(query))
	if err != nil {
		return nil, fmt.Errorf("querying the usage table: %v", err)
	}
	if resp.Status != http.StatusOK {
		return nil, fmt.Errorf("querying the usage table: HTTP %d", resp.Status)
	}
	var rows []map[string]any
	sc := bufio.NewScanner(bytes.NewReader(resp.Body))
	for sc.Scan() {
		var r map[string]any
		if json.Unmarshal(sc.Bytes(), &r) == nil {
			rows = append(rows, r)
		}
	}
	return rows, nil
}

// traceContinuity reads the task's trace from Langfuse, which keeps whole
// every trace with a GenAI span, as an agent that calls a model makes: the
// Dynatrace branch keeps only errors, slow traces and a share of the rest,
// so a short task's trace is mostly not there (B5).
func traceContinuity(c *IC, t Target) {
	e := c.Env
	tp, trace, _ := Trace()
	call := e.task(c, t, "Say something short.", map[string]string{"Traceparent": tp})
	if task, err := call.Task(); err != nil || task.Status.State != a2a.Completed {
		c.Fatalf("the task did not complete: %v %s", err, call)
	}
	w := e.P.Cfg.Telemetry.Waits
	wait := w.Decision.Duration + w.Delivery.Duration + w.Langfuse.Duration
	var services map[string]int
	var err error
	for deadline := time.Now().Add(wait); ; c.Sleep(5 * time.Second) {
		var obs map[string]map[string]any
		if obs, err = e.P.LangfuseObservations(c, trace); err == nil {
			services = map[string]int{}
			for _, o := range obs {
				services[platform.ObservationService(o)]++
			}
			if services[t.Name] > 0 && len(services) > 1 {
				break
			}
		}
		if !time.Now().Before(deadline) {
			break
		}
	}
	if err != nil {
		c.Fatalf("Langfuse's observations of the task's trace %s: %v", trace, err)
	}
	if services[t.Name] == 0 {
		c.Errorf("Langfuse holds no span of %s in the task's trace %s after %s (services seen: %v): the agent did not continue the gateway's trace", t.Name, trace, wait, services)
	}
	if len(services) < 2 {
		c.Errorf("the task's trace holds spans of %v only: the gateway's spans are not in the agent's trace", services)
	}
}

// drain deletes a pod of the agent while a task is in flight there, its
// model call held by the fake model's delay, so that SIGTERM arrives
// mid-turn. The task must complete (the drain), and the agent's spans of
// that turn must reach Langfuse in the task's trace (T31): its
// invoke_agent span and a model call's, as agent-sdk's own process test
// counts them (python/adk/tests/test_serve_process.py, 431b935c), each
// ending after SIGTERM. Then a task after the pod's replacement
// completes: the allowed twin.
//
// The case does not tell a flush at shutdown from the batch processor's
// scheduled export: that export is periodic from the process's start,
// every 5 seconds by default, and at this timing it sends the spans
// before a process without the flush dies (reference-agent on SDK
// 0.1.0.dev12 passes too). What proves the flush is agent-sdk's process
// test, which delays the schedule past the process's life, and the
// integration tests' fault "no flush at shutdown".
func drain(c *IC, t Target) {
	e := c.Env
	if e.P.Kube == nil || t.Namespace == "" || t.Selector == "" {
		c.Fatalf("the drain case needs the API server and the workload's namespace and selector")
	}
	pods, err := e.P.Kube.Pods(c, t.Namespace, t.Selector)
	if err != nil {
		c.Fatalf("listing %s's pods: %v", t.Name, err)
	}
	var victim string
	for _, p := range pods {
		if p.Ready && !p.Deleting {
			victim = p.Name
		}
	}
	if victim == "" {
		c.Fatalf("no ready pod of %s to delete", t.Name)
	}
	tp, trace, _ := Trace()
	var wg sync.WaitGroup
	var inflight a2a.Call
	wg.Add(1)
	go func() {
		defer wg.Done()
		inflight = e.task(c, t, fmt.Sprintf("Take your time. [[fake-model id=%s delay=8s]]", "conformance-drain-"+randomHex(6)), map[string]string{"Traceparent": tp})
	}()
	c.Sleep(2 * time.Second)
	sigterm := time.Now()
	if err := e.P.Kube.DeletePod(context.WithoutCancel(c), t.Namespace, victim); err != nil {
		c.Fatalf("deleting %s: %v", victim, err)
	}
	wg.Wait()
	if task, err := inflight.Task(); err != nil || task.Status.State != a2a.Completed {
		c.Errorf("the task in flight when %s got SIGTERM did not complete: %v %s", victim, err, inflight)
	}
	twin := false
	for deadline := time.Now().Add(3 * time.Minute); !twin && time.Now().Before(deadline); {
		if after := e.task(c, t, "Say something short.", nil); after.OK() {
			if task, err := after.Task(); err == nil && task.Status.State == a2a.Completed {
				twin = true
				continue
			}
		}
		c.Sleep(5 * time.Second)
	}
	if !twin {
		c.Errorf("the allowed twin, a task after the pod's replacement, did not complete within three minutes")
	}
	drainSpans(c, t, trace, sigterm, victim)
}

// drainSpans looks in Langfuse, which keeps whole every trace with a
// GenAI span, for the agent's spans of the in-flight task's turn that
// ended after SIGTERM: its root, invoke_agent, and a model call's. A
// second of slack covers the clocks of the runner's node and the pod's.
func drainSpans(c *IC, t Target, trace string, sigterm time.Time, victim string) {
	e := c.Env
	w := e.P.Cfg.Telemetry.Waits
	wait := w.Decision.Duration + w.Delivery.Duration + w.Langfuse.Duration
	after := sigterm.Add(-time.Second)
	var root, model, agentSpans int
	var err error
	for deadline := time.Now().Add(wait); ; c.Sleep(5 * time.Second) {
		var obs map[string]map[string]any
		if obs, err = e.P.LangfuseObservations(c, trace); err == nil {
			root, model, agentSpans = 0, 0, 0
			for _, o := range obs {
				if platform.ObservationService(o) != t.Name {
					continue
				}
				agentSpans++
				end, ok := observationEnd(o)
				if !ok || end.Before(after) {
					continue
				}
				switch op := platform.ObservationOp(o); {
				case op == "invoke_agent":
					root++
				case platform.IsModelOp(op):
					model++
				}
			}
			if root > 0 && model > 0 {
				break
			}
		}
		if !time.Now().Before(deadline) {
			break
		}
	}
	if err != nil {
		c.Fatalf("Langfuse's observations of the in-flight task's trace %s: %v", trace, err)
	}
	c.Logf("the in-flight task's trace %s: %d spans of %s, %d invoke_agent and %d model-call spans ending after SIGTERM", trace, agentSpans, t.Name, root, model)
	if root == 0 {
		c.Errorf("Langfuse holds no invoke_agent span of %s ending after %s got SIGTERM, in the in-flight task's trace %s, after %s: the spans of a task still running at SIGTERM were lost at shutdown; the workload must drain, then flush its tracer (T31)", t.Name, victim, trace, wait)
	}
	if model == 0 {
		c.Errorf("Langfuse holds no model-call span of %s (%s) ending after %s got SIGTERM, in the in-flight task's trace %s, after %s: the spans of a task still running at SIGTERM were lost at shutdown (T31)", t.Name, strings.Join(platform.ModelOps(), ", "), victim, trace, wait)
	}
}

// observationEnd is an observation's end time, which Langfuse gives as
// endTime in RFC 3339; an observation without one has not ended.
func observationEnd(o map[string]any) (time.Time, bool) {
	s, _ := o["endTime"].(string)
	if s == "" {
		return time.Time{}, false
	}
	end, err := time.Parse(time.RFC3339Nano, s)
	return end, err == nil
}
