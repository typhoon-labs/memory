package workload_test

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/fetch"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
	pstandin "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform/standin"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload"
)

// The integration cases' own tests: a scripted platform around one agent
// and one MCP server, right and then wrong in one property at a time. It
// is not the platform: only the cluster shows the platform passes them.

type iFaults struct {
	gatewayAnyToken bool // the route admits any of the person's tokens
	noAuthzPolicy   bool // a meshed namespace without grants reaches the pod
	permissiveMTLS  bool // a client outside the mesh reaches the pod
	teamFromHeader  bool // the usage record takes the team from x-team
	noWorkloadSpans bool // the agent starts its own trace
	noDrain         bool // SIGTERM kills the task in flight
	noFlush         bool // the drain completes the task, but the spans that end after SIGTERM are lost: no flush at shutdown (T31)
}

// iSpan is a span the world recorded, as Langfuse would hold it: its
// resource's service, its GenAI operation and its end.
type iSpan struct {
	service, op string
	end         time.Time
}

type iWorld struct {
	f        iFaults
	mu       sync.Mutex
	usage    map[string][]map[string]any // by trace
	spans    map[string][]iSpan          // by trace
	draining bool
}

func b64j(v any) string { b, _ := json.Marshal(v); return base64.RawURLEncoding.EncodeToString(b) }

type iTokens struct{}

func (iTokens) Token(_ context.Context, role, scope string) (string, error) {
	claims := map[string]any{"sub": "sub-" + role, "team": "team-" + role, "jti": "jti-" + scope, "aud": "https://gateway.agentic.internal/" + scope}
	return b64j(map[string]any{"alg": "RS256"}) + "." + b64j(claims) + ".sig", nil
}
func (iTokens) Wide(ctx context.Context, role string) (string, error) {
	return iTokens{}.Token(ctx, role, "models")
}
func (iTokens) Has(string) bool { return true }

// iProbe answers as a probe pod's sidecar and the network would.
type iProbe struct {
	meshed bool
	w      *iWorld
	direct *outcome.Client
}

func (p iProbe) Do(ctx context.Context, r outcome.Request) outcome.Outcome {
	switch {
	case p.meshed && !p.w.f.noAuthzPolicy:
		return outcome.Outcome{Kind: outcome.Response, Status: http.StatusForbidden, Body: outcome.RBACBody}
	case !p.meshed && !p.w.f.permissiveMTLS:
		return outcome.Outcome{Kind: outcome.Reset, Error: "connection reset by peer"}
	}
	return p.direct.Do(ctx, r)
}

// langfuse plays Langfuse's observations API for the spans the world
// recorded, each with its service in the metadata, as Langfuse 4 keeps it.
func (w *iWorld) langfuse() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if u, p, ok := r.BasicAuth(); !ok || u != "pk" || p != "sk" || r.URL.Path != "/api/public/v2/observations" {
			http.Error(rw, `{"message":"Invalid credentials"}`, http.StatusUnauthorized)
			return
		}
		w.mu.Lock()
		defer w.mu.Unlock()
		trace := r.URL.Query().Get("traceId")
		data := []map[string]any{}
		for i, s := range w.spans[trace] {
			meta := map[string]any{"resourceAttributes.service.name": s.service}
			if s.op != "" {
				meta["attributes.gen_ai.operation.name"] = s.op
			}
			data = append(data, map[string]any{"id": fmt.Sprintf("%016x", i+1), "traceId": trace, "name": "x", "type": "SPAN",
				"endTime": s.end.UTC().Format(time.RFC3339Nano), "metadata": meta})
		}
		json.NewEncoder(rw).Encode(map[string]any{"data": data, "meta": map[string]any{}})
	})
}

func claimsOf(r *http.Request) map[string]any {
	claims := map[string]any{}
	if parts := strings.Split(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "), "."); len(parts) == 3 {
		raw, _ := base64.RawURLEncoding.DecodeString(parts[1])
		json.Unmarshal(raw, &claims)
	}
	return claims
}

// workload answers as the deployed workload, and records what the
// platform would of an agent's task: its usage rows and spans.
func (w *iWorld) workload(name, kind string) http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		var req struct {
			ID     json.RawMessage `json:"id"`
			Method string          `json:"method"`
			Params struct {
				Message a2a.Message `json:"message"`
			} `json:"params"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		reply := func(result any, rerr map[string]any) {
			m := map[string]any{"jsonrpc": "2.0", "id": req.ID}
			if rerr != nil {
				m["error"] = rerr
			} else {
				m["result"] = result
			}
			json.NewEncoder(rw).Encode(m)
		}
		if kind != "agent" {
			reply(map[string]any{"tools": []any{}}, nil)
			return
		}
		switch req.Method {
		case "GetTask":
			reply(nil, map[string]any{"code": -32001, "message": "Task not found"})
		case "SendMessage":
			text := ""
			for _, p := range req.Params.Message.Parts {
				text += p.Text
			}
			claims := claimsOf(r)
			lost := false
			if strings.Contains(text, "delay=") {
				time.Sleep(3 * time.Second)
				w.mu.Lock()
				killed := w.draining && w.f.noDrain
				lost = w.draining && w.f.noFlush
				w.mu.Unlock()
				if killed {
					http.Error(rw, "upstream connect error or disconnect/reset before headers", http.StatusServiceUnavailable)
					return
				}
			}
			trace := ""
			if tp := strings.Split(r.Header.Get("Traceparent"), "-"); len(tp) == 4 {
				trace = tp[1]
			}
			w.mu.Lock()
			team := claims["team"]
			if w.f.teamFromHeader && r.Header.Get("x-team") != "" {
				team = r.Header.Get("x-team")
			}
			w.usage[trace] = append(w.usage[trace], map[string]any{"user_id": claims["sub"], "user_team": team})
			now := time.Now()
			w.spans[trace] = append(w.spans[trace], iSpan{service: "agentgateway", end: now})
			// The agent's turn: its root and its model call, ending now. A
			// task drained at SIGTERM ends after it, and without a flush at
			// shutdown those spans never leave the process.
			if !w.f.noWorkloadSpans && !lost {
				w.spans[trace] = append(w.spans[trace], iSpan{service: name, op: "invoke_agent", end: now},
					iSpan{service: name, op: "generate_content", end: now})
			}
			w.mu.Unlock()
			reply(map[string]any{"task": a2a.Task{ID: "t1", Status: a2a.Status{State: a2a.Completed}, Artifacts: []a2a.Artifact{{Parts: []a2a.Part{{Text: "ok"}}}}}}, nil)
		default:
			reply(nil, map[string]any{"code": -32601, "message": "Method not found"})
		}
	})
}

func newIntegration(t *testing.T, f iFaults) (*workload.Integration, []workload.Target) {
	w := &iWorld{f: f, usage: map[string][]map[string]any{}, spans: map[string][]iSpan{}}
	agent, server := w.workload("ref-agent", "agent"), w.workload("ref-mcp", "mcp-server")
	route := func(rw http.ResponseWriter, r *http.Request) {
		if strings.HasPrefix(r.URL.Path, "/a2a/") {
			agent.ServeHTTP(rw, r)
		} else {
			server.ServeHTTP(rw, r)
		}
	}
	direct := httptest.NewServer(http.HandlerFunc(route))
	t.Cleanup(direct.Close)
	gateway := httptest.NewServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if claimsOf(r)["aud"] != "https://gateway.agentic.internal"+r.URL.Path && !f.gatewayAnyToken {
			http.Error(rw, "authentication failure: audience", http.StatusUnauthorized)
			return
		}
		route(rw, r)
	}))
	t.Cleanup(gateway.Close)
	clickhouse := httptest.NewServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		w.mu.Lock()
		defer w.mu.Unlock()
		for _, row := range w.usage[r.URL.Query().Get("param_trace")] {
			json.NewEncoder(rw).Encode(row)
		}
	}))
	t.Cleanup(clickhouse.Close)
	langfuse := httptest.NewServer(w.langfuse())
	t.Cleanup(langfuse.Close)
	api := httptest.NewServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodDelete {
			w.mu.Lock()
			w.draining = true
			w.mu.Unlock()
			rw.Write([]byte(`{}`))
			return
		}
		rw.Write([]byte(`{"items": [{"metadata": {"name": "ref-agent-0"}, "status": {"conditions": [{"type": "Ready", "status": "True"}]}}]}`))
	}))
	t.Cleanup(api.Close)
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "pw"), []byte("pw"), 0o600)
	os.WriteFile(filepath.Join(dir, "pk"), []byte("pk"), 0o600)
	os.WriteFile(filepath.Join(dir, "sk"), []byte("sk"), 0o600)
	cfg := &platform.Config{}
	cfg.Gateways = map[string]string{"gateway": gateway.URL}
	cfg.UsageTable.URL, cfg.UsageTable.Database, cfg.UsageTable.Table = clickhouse.URL, "platform_usage", "llm_requests"
	cfg.UsageTable.User, cfg.UsageTable.PasswordFile = "r", filepath.Join(dir, "pw")
	cfg.Langfuse.URL, cfg.Langfuse.PublicKeyFile, cfg.Langfuse.SecretKeyFile = langfuse.URL, filepath.Join(dir, "pk"), filepath.Join(dir, "sk")
	cl := &outcome.Client{}
	p := &platform.Env{Cfg: cfg, RunID: "test", Runner: platform.Source{Source: outcome.Source{Name: "runner"}, Doer: cl},
		Probes: map[string]platform.Source{
			"meshed": {Source: outcome.Source{Name: "meshed", Meshed: true, MeshConnectTimeout: 10 * time.Second}, Doer: iProbe{meshed: true, w: w, direct: cl}},
			"nomesh": {Source: outcome.Source{Name: "nomesh"}, Doer: iProbe{w: w, direct: cl}},
		},
		Tokens: iTokens{}, Read: &fetch.Client{}, Kube: &kube.Client{Server: api.URL, HTTP: api.Client()}}
	targets := []workload.Target{
		{Name: "ref-agent", Kind: "agent", Route: "gateway/a2a/ref-agent", Scope: "a2a/ref-agent", OtherScope: "models", Direct: direct.URL,
			Namespace: "ref-agent", Selector: "app=ref-agent", CallsModel: true, Drain: true},
		{Name: "ref-mcp", Kind: "mcp-server", Route: "gateway/mcp/ref-mcp", Scope: "mcp/ref-mcp", OtherScope: "models", Direct: direct.URL},
	}
	return &workload.Integration{P: p, Targets: targets}, targets
}

func runIntegrationCases(t *testing.T, f iFaults) map[string]runner.Result {
	env, targets := newIntegration(t, f)
	out := map[string]runner.Result{}
	for _, k := range workload.IntegrationCases(targets) {
		// The needs are the platform environment's, which this scripted
		// one meets by construction; the cases run without them.
		k.Needs = nil
		out[k.ID] = runner.Run(context.Background(), env, k)
	}
	return out
}

func TestIntegration(t *testing.T) {
	for id, r := range runIntegrationCases(t, iFaults{}) {
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass on the right answers, got %s: %s", id, r.Status, r.Message)
		}
	}
	for _, tc := range []struct {
		name   string
		f      iFaults
		expect []string
	}{
		{"the route admits any token", iFaults{gatewayAnyToken: true}, []string{"integration/gateway-path/ref-agent/route-token", "integration/gateway-path/ref-mcp/route-token"}},
		{"no AuthorizationPolicy", iFaults{noAuthzPolicy: true}, []string{"integration/bypass/ref-agent/authorization-policy", "integration/bypass/ref-mcp/authorization-policy"}},
		{"PERMISSIVE mTLS", iFaults{permissiveMTLS: true}, []string{"integration/bypass/ref-agent/strict-mtls", "integration/bypass/ref-mcp/strict-mtls"}},
		{"the team from x-team", iFaults{teamFromHeader: true}, []string{"integration/attribution/ref-agent/from-token"}},
		// The drain case reads the in-flight task's trace too.
		{"the agent starts its own trace", iFaults{noWorkloadSpans: true}, []string{"integration/trace-continuity/ref-agent/gateway-to-workload", "integration/lifecycle/ref-agent/sigterm-drain"}},
		{"no drain", iFaults{noDrain: true}, []string{"integration/lifecycle/ref-agent/sigterm-drain"}},
		{"no flush at shutdown (T31)", iFaults{noFlush: true}, []string{"integration/lifecycle/ref-agent/sigterm-drain"}},
	} {
		res := runIntegrationCases(t, tc.f)
		want := map[string]bool{}
		for _, id := range tc.expect {
			want[id] = true
		}
		for id, r := range res {
			if want[id] != (r.Status == runner.Fail) {
				t.Errorf("%s: %s: got %s: %s", tc.name, id, r.Status, r.Message)
			}
		}
	}
}

// TestIntegrationTelemetry: an agent target with telemetry gets the
// platform suites' telemetry group with the agent playing the turn, run
// against the platform stand-in, whose telemetry agent plays it as
// reference-agent does; the cases pass, and fail when the agent starts a
// trace of its own.
func TestIntegrationTelemetry(t *testing.T) {
	target := workload.Target{Name: pstandin.TelemetryAgent, Kind: "agent", Route: "gateway/a2a/" + pstandin.TelemetryAgent,
		Scope: "a2a/" + pstandin.TelemetryAgent, Telemetry: &workload.TelemetryTarget{Tool: "get_note", Arg: "note_id"}}
	run := func(f pstandin.Faults) map[string]runner.Result {
		w, err := pstandin.New(f)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(w.Close)
		penv, err := w.Env()
		if err != nil {
			t.Fatal(err)
		}
		env := &workload.Integration{P: penv, Targets: []workload.Target{target}}
		out := map[string]runner.Result{}
		for _, k := range workload.IntegrationCases(env.Targets) {
			if strings.HasPrefix(k.ID, "integration/telemetry/") {
				out[k.ID] = runner.Run(context.Background(), env, k)
			}
		}
		return out
	}
	res := run(pstandin.Faults{})
	if len(res) != len(platform.TelemetryAgentCases()) {
		t.Fatalf("want the telemetry group's %d cases, got %d", len(platform.TelemetryAgentCases()), len(res))
	}
	for id, r := range res {
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass, got %s:\n%s", id, r.Status, r.Message)
		}
	}
	for id, r := range run(pstandin.Faults{AgentOwnTrace: true}) {
		if r.Status != runner.Fail {
			t.Errorf("%s with an agent that starts its own trace: want fail, got %s", id, r.Status)
		}
	}
}
