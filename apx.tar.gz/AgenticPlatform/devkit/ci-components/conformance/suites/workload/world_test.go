package workload_test

import (
	"context"
	"fmt"
	"io"
	"net"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/workload/standin"
)

// The stand-ins' workload.yaml files, as JSON: an agent like
// reference-agent, raised to L2 so the injection canary runs, and an MCP
// server like reference-mcp (agent-sdk's spec/schemas/examples). The
// component's own pipeline bakes the same files into its stand-in images.
var agentYAML, serverYAML = mustRead("standin/testdata/agent.workload.json"), mustRead("standin/testdata/mcp.workload.json")

func mustRead(p string) string {
	b, err := os.ReadFile(p)
	if err != nil {
		panic(err)
	}
	return string(b)
}

var fakeModel string

func TestMain(m *testing.M) {
	dir, err := os.MkdirTemp("", "fake-model-")
	if err != nil {
		panic(err)
	}
	fakeModel = filepath.Join(dir, "fake-model")
	build := exec.Command("go", "build", "-o", fakeModel, ".")
	build.Dir = "../../fixtures/fake-model"
	build.Stderr = os.Stderr
	if err := build.Run(); err != nil {
		fmt.Fprintln(os.Stderr, "building the fake model server:", err)
		os.Exit(2)
	}
	code := m.Run()
	os.RemoveAll(dir)
	os.Exit(code)
}

// The stage's settings in the tests: low caps, so the limit cases are
// quick, and a five-second approval life.
var settings = workload.Settings{
	Domain: "agentic.internal", Cluster: "agentic-local",
	Limits:      map[string]int{"model_calls": 2, "tool_calls": 2, "tokens": 20000, "wall_time_seconds": 3},
	ApprovalTTL: 5 * time.Second, ReleaseID: "conformance-test-release",
}

// world is a harness and a stand-in workload with faults.
type world struct {
	env     *workload.Env
	h       *contract.Harness
	srv     *httptest.Server
	cleanup func()
}

// extra is more of the stand-in's environment, such as
// STANDIN_DATABASE_POOLED.
func newWorld(t *testing.T, yaml string, faults standin.Faults, extra ...map[string]string) *world {
	t.Helper()
	dir := t.TempDir()
	w, err := contract.ParseWorkload([]byte(yaml), "")
	if err != nil {
		t.Fatal(err)
	}
	denied := contract.NewPerson("conformance")
	// The MCP server's database: a TCP server that answers each of
	// PostgreSQL's SSLRequests on a connection with N, behind the harness's
	// proxy, as the stage's PostgreSQL service is. Answering more than one
	// lets a stand-in keep its connection open, as a real server's pool does.
	var dbTarget string
	if w.Kind == "mcp-server" {
		ln, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { ln.Close() })
		go func() {
			for {
				c, err := ln.Accept()
				if err != nil {
					return
				}
				go func() {
					defer c.Close()
					b := make([]byte, 8)
					for {
						if _, err := io.ReadFull(c, b); err != nil {
							return
						}
						if _, err := c.Write([]byte("N")); err != nil {
							return
						}
					}
				}()
			}
		}()
		dbTarget = ln.Addr().String()
	}
	actorFile := filepath.Join(dir, "actor", "token")
	var h *contract.Harness
	// The fake model's ports are picked free, then bound by its process: a
	// parallel test can take one in between, so a start is tried thrice.
	for try := 0; ; try++ {
		h, err = contract.Start(context.Background(), contract.Options{
			Dir: filepath.Join(dir, fmt.Sprint(try)), Listen: "127.0.0.1:0", KubeListen: "127.0.0.1:0", OTLPListen: "127.0.0.1:0",
			Domain: settings.Domain, Cluster: settings.Cluster, Workload: w, ActorTokenFile: actorFile,
			FakeModel: fakeModel, Denied: []string{denied.Sub}, Log: io.Discard,
			DatabaseListen: "127.0.0.1:0", DatabaseTarget: dbTarget,
		})
		if err == nil {
			break
		}
		if try == 2 {
			t.Fatal(err)
		}
	}
	yamlPath := filepath.Join(dir, "workload.json")
	os.WriteFile(yamlPath, []byte(yaml), 0o600)
	s := settings
	s.ServiceName = w.Name
	s.ApprovalAudience = "https://gateway." + s.Domain + "/mcp/" + w.Name
	proto := "mcp"
	if w.Kind == "agent" {
		proto = "a2a"
	}
	env := map[string]string{
		"AGENTIC_GATEWAY_URL":        h.O.BaseURL,
		"AGENTIC_RESOURCE_BASE":      "https://workloads-gateway." + s.Domain,
		"AGENTIC_STS_TOKEN_ENDPOINT": h.O.BaseURL + "/sts/token",
		"AGENTIC_ACTOR_TOKEN_FILE":   actorFile,
		"AGENTIC_TRUST": fmt.Sprintf(`[{"issuer":%q,"profile":"keycloak","jwks_uri":%q,"audience":%q},{"issuer":%q,"profile":"chain","jwks_uri":%q,"audience":%q}]`,
			contract.KeycloakIssuer, h.O.BaseURL+"/issuer/keycloak/jwks", "https://gateway."+s.Domain+"/"+proto+"/"+w.Name,
			contract.STSIssuer, h.O.BaseURL+"/sts/jwks", "https://workloads-gateway."+s.Domain+"/"+proto+"/"+w.Name),
		"AGENTIC_APPROVAL_AUDIENCE":       s.ApprovalAudience,
		"AGENTIC_APPROVAL_TTL_SECONDS":    fmt.Sprint(int(s.ApprovalTTL / time.Second)),
		"AGENTIC_LIMIT_MODEL_CALLS":       fmt.Sprint(s.Limits["model_calls"]),
		"AGENTIC_LIMIT_TOOL_CALLS":        fmt.Sprint(s.Limits["tool_calls"]),
		"AGENTIC_LIMIT_TOKENS":            fmt.Sprint(s.Limits["tokens"]),
		"AGENTIC_LIMIT_WALL_TIME_SECONDS": fmt.Sprint(s.Limits["wall_time_seconds"]),
		"OTEL_EXPORTER_OTLP_ENDPOINT":     h.OTLPURL,
		"OTEL_RESOURCE_ATTRIBUTES":        "platform.release.id=" + s.ReleaseID,
		"STANDIN_WORKLOAD":                yamlPath,
		"AGENTIC_DATABASE_URL":            databaseURL(h),
		"STANDIN_FAULTS":                  faults.String(),
	}
	for _, m := range extra {
		for k, v := range m {
			env[k] = v
		}
	}
	cfg, err := standin.FromEnv(func(k string) string { return env[k] })
	if err != nil {
		h.Close()
		t.Fatal(err)
	}
	wl := standin.New(cfg)
	srv := httptest.NewServer(wl)
	// The cases wait on the stand-in's delivery signal (Settle), not on
	// Wait, which bounds only a run without one: in wall time, a task's
	// root span, sent a second after its end, could miss 3 seconds on a
	// loaded runner.
	e := &workload.Env{RunID: strings.ToLower(contract.UUID()[:8]), Workload: w, Level: w.Level(), URL: srv.URL, H: h, S: s,
		HTTP: &outcome.Client{}, Denied: denied, Wait: 3 * time.Second, Settle: wl.Settle}
	return &world{env: e, h: h, srv: srv, cleanup: func() { srv.Close(); h.Close() }}
}

func databaseURL(h *contract.Harness) string {
	if h.Database == nil {
		return ""
	}
	return "postgresql://agentic:test@" + h.Database.Addr() + "/postgres"
}

func casesOf(w *world) []string {
	var out []string
	for _, k := range workload.Cases(w.env) {
		out = append(out, k.ID)
	}
	return out
}
