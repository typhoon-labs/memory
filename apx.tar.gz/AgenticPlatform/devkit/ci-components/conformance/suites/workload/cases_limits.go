package workload

import (
	"encoding/json"
	"fmt"
	"math"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
)

const (
	retriesRow = "Retries: on 429 and 5xx from the model, retries are bounded with backoff. A non-idempotent tool is never retried without an idempotency key"
	limitsRow  = "Limits: a task that exceeds its declared caps on steps, tool calls, tokens or wall time stops with the defined error and leaves no partial side effect"
)

// MaxModelAttempts bounds the attempts of one model call: the SDK's
// resilience retries at most three times; the case allows one more.
const MaxModelAttempts = 5

func retryCases(e *Env) []Case {
	if !e.Agent() {
		return nil
	}
	return []Case{
		{ID: "l1/retries/model-429", Suite: "l1/retries", Layer: LayerResilience, Row: retriesRow,
			Title: "two 429s with Retry-After: 1 are retried after waiting, and the task completes on the third attempt", Run: retry429},
		{ID: "l1/retries/model-5xx-bounded", Suite: "l1/retries", Layer: LayerResilience, Row: retriesRow,
			Title: fmt.Sprintf("a model that always answers 503 is tried at most %d times, with backoff, and the task fails", MaxModelAttempts), Run: retry5xx},
	}
}

func retry429(c *C) {
	id := c.Env.Marker("retry")
	t := c.Env.Send(c, contract.NewPerson("conformance"), fmt.Sprintf("Answer. [[fake-model id=%s status=429 retry-after=1 times=2]]", id), nil)
	if t.Err != nil || t.Task.Status.State != a2a.Completed {
		c.Errorf("the task did not complete after two 429s: %v %s %s", t.Err, t.Task.Status.State, shorten(t.Task.Text()))
	}
	recs, err := c.Env.H.ModelRecords(c, id)
	if err != nil {
		c.Fatalf("the fake model's records: %v", err)
	}
	if len(recs) < 3 {
		c.Fatalf("the fake model saw %d attempts, not the three a retry after two 429s takes", len(recs))
	}
	for i := 1; i < 3; i++ {
		if gap := recs[i].Time.Sub(recs[i-1].Time); gap < 900*time.Millisecond {
			c.Errorf("attempt %d came %s after a 429 with Retry-After: 1", i+1, gap)
		}
	}
}

func retry5xx(c *C) {
	id := c.Env.Marker("retry")
	t := c.Env.Send(c, contract.NewPerson("conformance"), fmt.Sprintf("Answer. [[fake-model id=%s status=503]]", id), nil)
	if t.Err == nil && t.Task.Status.State == a2a.Completed {
		c.Errorf("the task completed though every model call answered 503")
	}
	recs, err := c.Env.H.ModelRecords(c, id)
	if err != nil {
		c.Fatalf("the fake model's records: %v", err)
	}
	switch {
	case len(recs) > MaxModelAttempts:
		c.Errorf("the model was tried %d times: retries are not bounded (at most %d)", len(recs), MaxModelAttempts)
	case len(recs) < 2:
		c.Errorf("the model was tried %d time: a 503 is retried at least once", len(recs))
	default:
		for i := 1; i < len(recs); i++ {
			if gap := recs[i].Time.Sub(recs[i-1].Time); gap < 100*time.Millisecond {
				c.Errorf("attempt %d came %s after the one before: no backoff", i+1, gap)
			}
		}
	}
}

func limitCases(e *Env) []Case {
	var cases []Case
	if !e.Agent() {
		if _, ok := e.Cap("wall_time_seconds"); ok && e.H.Database != nil {
			cases = append(cases, Case{ID: "l1/limits/wall-time", Suite: "l1/limits", Layer: LayerLimits, Row: limitsRow,
				Title: "a tool call whose database answers past the wall-time cap ends with limit_exceeded on the MCP surface; at full speed it answers", Run: serverWallTime})
		}
		return cases
	}
	_, hasTool := e.Cap("tool_calls")
	_, hasModel := e.Cap("model_calls")
	if hasTool && e.CallsOn() {
		cases = append(cases, Case{ID: "l1/limits/tool-calls", Suite: "l1/limits", Layer: LayerLimits, Row: limitsRow,
			Title: "one model response asking for one tool call more than the cap starts as many as the cap and stops with limit_exceeded tool_calls; as many as the cap complete", Run: limitToolCalls})
	}
	if hasModel && e.CallsOn() {
		cases = append(cases, Case{ID: "l1/limits/model-calls", Suite: "l1/limits", Layer: LayerLimits, Row: limitsRow,
			Title: "a model that keeps asking for a tool, one call a turn, is stopped before the model call past the cap with limit_exceeded model_calls; a task within it completes", Run: limitModelCalls})
	}
	if _, ok := e.Cap("tokens"); ok {
		cases = append(cases, Case{ID: "l1/limits/tokens", Suite: "l1/limits", Layer: LayerLimits, Row: limitsRow,
			Title: "a response past the token cap is not acted on: the task stops with limit_exceeded and the tool it asks for never starts; a task within the cap completes", Run: limitTokens})
	}
	if _, ok := e.Cap("wall_time_seconds"); ok {
		cases = append(cases, Case{ID: "l1/limits/wall-time", Suite: "l1/limits", Layer: LayerLimits, Row: limitsRow,
			Title: "a model that never answers is cancelled at the wall-time cap with limit_exceeded; a quick task completes", Run: limitWallTime})
	}
	return cases
}

// limitStop checks the A2A surface of spec/limits/: a failed task whose
// final status message holds the error object as a data part, and the
// span surface: the task's span ends with status ERROR, error.type
// limit_exceeded.
// limitError is the spec's error object (spec/limits/error.schema.json).
// cap and used are decoded as JSON numbers and then required to be
// integers, as the schema's "integer" is: A2A 1.0 carries a data part as a
// google.protobuf.Value, whose numbers are doubles, so a2a-sdk (Python's
// MessageToDict) sends a count of 2 as 2.0, which Go's int refuses.
type limitError struct {
	Error string  `json:"error"`
	Limit string  `json:"limit"`
	Cap   float64 `json:"cap"`
	Used  float64 `json:"used"`
}

func (e limitError) integral() bool {
	return e.Cap == math.Trunc(e.Cap) && e.Used == math.Trunc(e.Used)
}

func limitStop(c *C, t *Task, limit string, cap int) {
	if t.Err != nil {
		c.Fatalf("the task: %v", t.Err)
	}
	if t.Task.Status.State != a2a.Failed {
		c.Errorf("the task ended %s, not TASK_STATE_FAILED, past its %s cap", t.Task.Status.State, limit)
		return
	}
	var found bool
	for _, d := range t.Task.Data() {
		var e limitError
		if json.Unmarshal(d, &e) == nil && e.Error == "limit_exceeded" {
			found = true
			if !e.integral() {
				c.Errorf("cap %v and used %v are not both integers", e.Cap, e.Used)
			}
			if e.Limit != limit || int(e.Cap) != cap {
				c.Errorf("the error names %s with cap %v, not %s with cap %d", e.Limit, e.Cap, limit, cap)
			}
			if (limit == "tool_calls" || limit == "model_calls") && int(e.Used) != cap {
				c.Errorf("used is %v, not the cap %d, for a count", e.Used, cap)
			}
			if (limit == "tokens" || limit == "wall_time_seconds") && int(e.Used) < cap {
				c.Errorf("used is %v, below the cap %d", e.Used, cap)
			}
		}
	}
	if !found {
		c.Errorf("the failed task's status message holds no data part with the spec's limit_exceeded error: %q", shorten(t.Task.Text()))
	}
	spans := waitSpans(c, t.TraceID, func(s []contract.Span) bool {
		for _, x := range s {
			if x.Attributes["error.type"] == "limit_exceeded" {
				return true
			}
		}
		return false
	})
	// The task's span: whichever of the trace's spans ends with status
	// ERROR and error.type limit_exceeded, the invoke_agent span in ADK,
	// which a server span may sit above.
	ok := false
	for _, s := range spans {
		ok = ok || (s.StatusCode == 2 && s.Attributes["error.type"] == "limit_exceeded")
	}
	if !ok {
		c.Errorf("no span of the task's trace ended with status ERROR and error.type limit_exceeded")
	}
}

func toolCallsOf(e *Env, task string) int {
	n := 0
	for _, call := range e.H.Tools.Calls() {
		if call.TaskID == task && call.Method == "tools/call" {
			n++
		}
	}
	return n
}

func limitToolCalls(c *C) {
	toolCap, _ := c.Env.Cap("tool_calls")
	modelCap, hasModel := c.Env.Cap("model_calls")
	if toolCap+1 > 16 {
		c.Fatalf("the tool-call cap is %d; the stage lowers it with AGENTIC_LIMIT_TOOL_CALLS so one response can pass it", toolCap)
	}
	if hasModel && modelCap < 2 {
		c.Fatalf("the model-call cap is %d: a task that calls a tool needs two model calls", modelCap)
	}
	tool, _ := c.Env.AllowedTool()
	if toolCap > 0 {
		twin := c.Env.Send(c, contract.NewPerson("conformance"), fmt.Sprintf("Use %s. [[fake-model tool=%s parallel=%d]]", tool, tool, max(2, toolCap)), Loop(1))
		if toolCap == 1 {
			twin = c.Env.Send(c, contract.NewPerson("conformance"), callOnce(c.Env), Loop(1))
		}
		if twin.Err != nil || twin.Task.Status.State != a2a.Completed {
			c.Errorf("the allowed twin, a task of exactly %d tool calls, did not complete: %v %s %s", toolCap, twin.Err, twin.Task.Status.State, shorten(twin.Task.Text()))
		}
	}
	t := c.Env.Send(c, contract.NewPerson("conformance"), fmt.Sprintf("Use %s. [[fake-model tool=%s parallel=%d]]", tool, tool, toolCap+1), Loop(0))
	limitStop(c, t, "tool_calls", toolCap)
	if n := toolCallsOf(c.Env, t.ID); n != toolCap {
		c.Errorf("the MCP server saw %d calls of the task, not the cap of %d: the call past the cap started", n, toolCap)
	}
}

func limitModelCalls(c *C) {
	modelCap, _ := c.Env.Cap("model_calls")
	toolCap, hasTool := c.Env.Cap("tool_calls")
	if hasTool && toolCap < modelCap {
		c.Fatalf("the tool-call cap (%d) is below the model-call cap (%d): one tool call a turn meets it first; the stage sets both to 2", toolCap, modelCap)
	}
	tool, _ := c.Env.AllowedTool()
	directive := fmt.Sprintf("Keep using %s. [[fake-model tool=%s]]", tool, tool)
	if modelCap > 1 {
		twin := c.Env.Send(c, contract.NewPerson("conformance"), directive, Loop(modelCap-1))
		if twin.Err != nil || twin.Task.Status.State != a2a.Completed {
			c.Errorf("the allowed twin, a task of exactly %d model calls, did not complete: %v %s %s", modelCap, twin.Err, twin.Task.Status.State, shorten(twin.Task.Text()))
		}
	}
	t := c.Env.Send(c, contract.NewPerson("conformance"), directive, Loop(0))
	limitStop(c, t, "model_calls", modelCap)
}

// serverWallTime holds the database's answers past the server's wall-time
// cap: its tool call ends with the spec's error on the MCP surface, a
// result whose isError is true and whose structured content is the error.
func serverWallTime(c *C) {
	cap, _ := c.Env.Cap("wall_time_seconds")
	if cap > 30 {
		c.Fatalf("the wall-time cap is %d seconds; the stage lowers it with AGENTIC_LIMIT_WALL_TIME_SECONDS", cap)
	}
	token := c.Env.Inbound(c, contract.NewPerson("conformance"))
	ro := c.Env.Workload.ReadOnlyTools()
	if len(ro) == 0 {
		c.Fatalf("no read-only tool to call")
	}
	args := sampleArgs(c.Env.Schemas(c, token)[ro[0]], c.Env.Marker("arg"))
	db := c.Env.H.Database
	// What the server sent its database, not the connections it opened: a
	// server with a pool reuses connections it opened before.
	before := db.Traffic()
	if r, err := c.Env.MCP(token, nil).CallTool(c, ro[0], args).Result(); err != nil || r.IsError {
		c.Errorf("the allowed twin, %s at the database's full speed, did not answer: %v %+v", ro[0], err, r)
	}
	if db.Traffic() == before {
		c.Fatalf("%s reached no database through the stage's proxy (AGENTIC_DATABASE_URL), so no wait can be put in its way", ro[0])
	}
	db.SetDelay(time.Duration(cap+3) * time.Second)
	defer db.SetDelay(0)
	task := "conformance-task-" + randomHex(8)
	start := time.Now()
	call := c.Env.MCP(token, map[string]string{contract.TaskHeader: task}).CallTool(c, ro[0], args)
	took := time.Since(start)
	r, err := call.Result()
	if err != nil {
		c.Fatalf("tools/call past the cap: no MCP result, a protocol error instead: %s", call)
	}
	var e limitError
	json.Unmarshal(r.StructuredContent, &e)
	switch {
	case !r.IsError:
		c.Errorf("the call whose database answered %s late succeeded after %s", time.Duration(cap+3)*time.Second, took.Round(time.Second))
	case e.Error != "limit_exceeded" || e.Limit != "wall_time_seconds":
		c.Errorf("the call past the cap answered isError without the spec's error as structured content: %s", shorten(string(r.StructuredContent)))
	case !e.integral():
		c.Errorf("the error's cap %v and used %v are not both integers", e.Cap, e.Used)
	case int(e.Cap) != cap || int(e.Used) < cap:
		c.Errorf("the error says cap %v, used %v; the cap is %d", e.Cap, e.Used, cap)
	}
	if took > time.Duration(cap+2)*time.Second {
		c.Errorf("the call took %s to stop at a %d-second cap", took.Round(100*time.Millisecond), cap)
	}
}

func limitTokens(c *C) {
	cap, _ := c.Env.Cap("tokens")
	tool, _ := c.Env.AllowedTool()
	twin := c.Env.Send(c, contract.NewPerson("conformance"), "Answer briefly.", nil)
	if twin.Err != nil || twin.Task.Status.State != a2a.Completed {
		c.Errorf("the allowed twin, a short task, did not complete: %v %s", twin.Err, twin.Task.Status.State)
	}
	directive := fmt.Sprintf("Answer. [[fake-model usage=%d]]", cap+1000)
	if tool != "" {
		directive = fmt.Sprintf("Use %s. [[fake-model tool=%s usage=%d]]", tool, tool, cap+1000)
	}
	t := c.Env.Send(c, contract.NewPerson("conformance"), directive, Loop(1))
	limitStop(c, t, "tokens", cap)
	if n := toolCallsOf(c.Env, t.ID); n > 0 {
		c.Errorf("the response past the cap was acted on: %d tool calls started", n)
	}
}

func limitWallTime(c *C) {
	cap, _ := c.Env.Cap("wall_time_seconds")
	if cap > 120 {
		c.Fatalf("the wall-time cap is %d seconds; the stage lowers it to at most 120 with AGENTIC_LIMIT_WALL_TIME_SECONDS", cap)
	}
	t := c.Env.Send(c, contract.NewPerson("conformance"), fmt.Sprintf("Answer. [[fake-model id=%s stall]]", c.Env.Marker("stall")), nil)
	limitStop(c, t, "wall_time_seconds", cap)
	if lim := time.Duration(cap+15) * time.Second; t.Took > lim {
		c.Errorf("the task took %s to stop at a %d-second cap", t.Took.Round(time.Second), cap)
	}
}
