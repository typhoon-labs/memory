package workload

import (
	"encoding/json"
	"fmt"
	"net/http"
	"slices"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

const protocolRow = "Protocol: MCP initialize, tools/list and tools/call validate; tools declare read-only or destructive hints; errors use protocol error shapes. A2A agent card validates; task states and cancellation behave"

func protocolCases(e *Env) []Case {
	if e.Agent() {
		return []Case{
			{ID: "l1/protocol/a2a/agent-card", Suite: "l1/protocol", Layer: LayerIdentity, Row: protocolRow,
				Title: "the A2A 1.0 agent card validates and is served without a token; a call without one is refused", Run: agentCard},
			{ID: "l1/protocol/a2a/task-states", Suite: "l1/protocol", Layer: LayerProtocol, Row: protocolRow,
				Title: "a message runs to TASK_STATE_COMPLETED and GetTask reads it back; an unknown task is TaskNotFoundError", Run: taskStates},
			{ID: "l1/protocol/a2a/cancel", Suite: "l1/protocol", Layer: LayerProtocol, Row: protocolRow,
				Title: "a working task cancels to TASK_STATE_CANCELED; a finished one is TaskNotCancelableError", Run: cancelTask},
			{ID: "l1/protocol/a2a/errors", Suite: "l1/protocol", Layer: LayerProtocol, Row: protocolRow,
				Title: "a malformed request and an unknown method get JSON-RPC errors, a valid one a result", Run: a2aErrors},
		}
	}
	return []Case{
		{ID: "l1/protocol/mcp/tools", Suite: "l1/protocol", Layer: LayerProtocol, Row: protocolRow,
			Title: "tools/list lists every tool of workload.yaml with an object input schema and its hints stated; an unknown tool is a protocol error, a read-only one answers", Run: mcpTools},
		{ID: "l1/protocol/mcp/errors", Suite: "l1/protocol", Layer: LayerProtocol, Row: protocolRow,
			Title: "a request that is not JSON-RPC gets a JSON-RPC error, a valid one a result", Run: mcpErrors},
	}
}

func lifecycleCases(e *Env) []Case {
	return []Case{{ID: "l1/lifecycle/health", Suite: "l1/lifecycle", Layer: LayerIdentity,
		Row:   "Lifecycle: health endpoints; SIGTERM drains in-flight work within the grace period; deadlines are honored",
		Title: "/healthz and /readyz answer 200 without a token, and open no data path: the protocol endpoint without one is refused",
		Run: func(c *C) {
			for _, p := range []string{"/healthz", "/readyz"} {
				o := c.Env.HTTP.Do(c, outcome.Request{Method: http.MethodGet, URL: c.Env.URL + p})
				if o.Kind != outcome.Response || o.Status != http.StatusOK {
					c.Errorf("GET %s without a token: %s", p, o)
				}
			}
			refusedByWorkload(c, "the protocol endpoint without a token", c.Env.Probe(c, ""), false)
		}}}
}

func agentCard(c *C) {
	card := c.Env.A2AURL() + a2a.CardPath
	o := c.Env.HTTP.Do(c, outcome.Request{Method: http.MethodGet, URL: card, Header: map[string]string{"A2A-Version": a2a.Version}})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		c.Fatalf("GET %s without a token: %s", card, o)
	}
	var cardBody struct {
		Name                string `json:"name"`
		Version             string `json:"version"`
		SupportedInterfaces []struct {
			URL             string `json:"url"`
			ProtocolBinding string `json:"protocolBinding"`
			ProtocolVersion string `json:"protocolVersion"`
		} `json:"supportedInterfaces"`
		Capabilities       map[string]any `json:"capabilities"`
		DefaultInputModes  []string       `json:"defaultInputModes"`
		DefaultOutputModes []string       `json:"defaultOutputModes"`
		Skills             []struct {
			ID, Name, Description string
			Tags                  []string
		} `json:"skills"`
		SecuritySchemes map[string]struct {
			HTTPAuth *struct {
				Scheme string `json:"scheme"`
			} `json:"httpAuthSecurityScheme"`
		} `json:"securitySchemes"`
		SecurityRequirements []json.RawMessage `json:"securityRequirements"`
	}
	if err := json.Unmarshal([]byte(o.Body), &cardBody); err != nil {
		c.Fatalf("the agent card is not JSON: %v", err)
	}
	var problems []string
	if cardBody.Name == "" || cardBody.Version == "" {
		problems = append(problems, "no name or version")
	}
	jsonrpc := false
	for _, i := range cardBody.SupportedInterfaces {
		if strings.EqualFold(i.ProtocolBinding, "JSONRPC") && i.ProtocolVersion == a2a.Version && (strings.HasPrefix(i.URL, "http://") || strings.HasPrefix(i.URL, "https://")) {
			jsonrpc = true
		}
	}
	if !jsonrpc {
		problems = append(problems, "no supportedInterfaces entry with protocolBinding JSONRPC, protocolVersion 1.0 and an absolute URL")
	}
	if cardBody.Capabilities == nil || len(cardBody.DefaultInputModes) == 0 || len(cardBody.DefaultOutputModes) == 0 {
		problems = append(problems, "no capabilities or default input and output modes")
	}
	if len(cardBody.Skills) == 0 || slices.ContainsFunc(cardBody.Skills, func(s struct {
		ID, Name, Description string
		Tags                  []string
	}) bool {
		return s.ID == "" || s.Name == "" || s.Description == "" || len(s.Tags) == 0
	}) {
		problems = append(problems, "no skills, or one without id, name, description and tags")
	}
	bearer := false
	for _, s := range cardBody.SecuritySchemes {
		bearer = bearer || (s.HTTPAuth != nil && strings.EqualFold(s.HTTPAuth.Scheme, "bearer"))
	}
	if !bearer || len(cardBody.SecurityRequirements) == 0 {
		problems = append(problems, "no HTTP bearer security scheme required: every path but the card needs a token")
	}
	if len(problems) > 0 {
		c.Errorf("the agent card does not validate: %s; card: %s", strings.Join(problems, "; "), shorten(o.Body))
	}
	refusedByWorkload(c, "SendMessage without a token", c.Env.A2A("", nil).Send(c, c.Env.Marker("m"), "hello", false).Outcome, false)
}

func taskStates(c *C) {
	t := c.Env.Send(c, contract.NewPerson("conformance"), "Say something short.", nil)
	if t.Err != nil {
		c.Fatalf("SendMessage: %v", t.Err)
	}
	if t.Task.Status.State != a2a.Completed || strings.TrimSpace(t.Task.Text()) == "" {
		c.Errorf("the task ended %s with %q, not TASK_STATE_COMPLETED with an answer", t.Task.Status.State, shorten(t.Task.Text()))
	}
	cl := c.Env.A2A(c.Env.Person(t.Person, contract.TokenOpts{}), nil)
	got, err := cl.Get(c, t.Task.ID).Task()
	if err != nil || got.ID != t.Task.ID || got.Status.State != t.Task.Status.State {
		c.Errorf("GetTask %s: %+v, %v", t.Task.ID, got.Status, err)
	}
	unknown := cl.Get(c, "conformance-unknown-"+randomHex(6))
	if unknown.Response == nil || unknown.Response.Error == nil || unknown.Response.Error.Code != a2a.CodeTaskNotFound {
		c.Errorf("GetTask of an unknown task: want JSON-RPC error %d, got %s", a2a.CodeTaskNotFound, unknown)
	}
}

func cancelTask(c *C) {
	id := c.Env.Marker("cancel")
	p := contract.NewPerson("conformance")
	cl := c.Env.A2A(c.Env.Person(p, contract.TokenOpts{}), map[string]string{contract.TaskHeader: "conformance-task-" + randomHex(8)})
	started, err := cl.Send(c, c.Env.Marker("m"), fmt.Sprintf("Wait for this. [[fake-model id=%s delay=60s]]", id), true).Task()
	if err != nil {
		c.Fatalf("SendMessage with returnImmediately: %v", err)
	}
	if a2a.Terminal(started.Status.State) {
		c.Fatalf("the task had already ended (%s) while its model call was held for a minute", started.Status.State)
	}
	canceled, err := cl.Cancel(c, started.ID).Task()
	if err != nil {
		c.Fatalf("CancelTask of a working task: %v", err)
	}
	deadline := time.Now().Add(15 * time.Second)
	for canceled.Status.State != a2a.Canceled && time.Now().Before(deadline) {
		c.Sleep(500 * time.Millisecond)
		canceled, _ = cl.Get(c, started.ID).Task()
	}
	if canceled.Status.State != a2a.Canceled {
		c.Errorf("the canceled task is %s, not TASK_STATE_CANCELED, 15 seconds on", canceled.Status.State)
	}
	done := c.Env.Send(c, p, "Say something short.", nil)
	if done.Err != nil || done.Task.Status.State != a2a.Completed {
		c.Fatalf("a task to finish first: %v %s", done.Err, done.Task.Status.State)
	}
	again := c.Env.A2A(c.Env.Person(p, contract.TokenOpts{}), nil).Cancel(c, done.Task.ID)
	if again.Response == nil || again.Response.Error == nil || again.Response.Error.Code != a2a.CodeTaskNotCancelable {
		c.Errorf("CancelTask of a completed task: want JSON-RPC error %d, got %s", a2a.CodeTaskNotCancelable, again)
	}
}

func rpcErrorCode(o outcome.Outcome) (int, bool) {
	var r struct {
		Error *struct {
			Code int `json:"code"`
		} `json:"error"`
	}
	if o.Kind != outcome.Response || json.Unmarshal([]byte(o.Body), &r) != nil || r.Error == nil {
		return 0, false
	}
	return r.Error.Code, true
}

func a2aErrors(c *C) {
	tok := c.Env.Person(contract.NewPerson("conformance"), contract.TokenOpts{})
	h := map[string]string{"Authorization": "Bearer " + tok, "Content-Type": "application/json", "A2A-Version": a2a.Version}
	bad := c.Env.HTTP.Do(c, outcome.Request{Method: http.MethodPost, URL: c.Env.A2AURL(), Header: h, Body: `{"jsonrpc": "2.0", "id": 1, "method":`})
	if code, ok := rpcErrorCode(bad); !ok || bad.Status >= 500 || (code != a2a.CodeParse && code != a2a.CodeInvalidRequest) {
		c.Errorf("a request that is not JSON: want a JSON-RPC parse or invalid-request error, got %s", bad)
	}
	unknown := c.Env.A2A(tok, nil).Request(c, "conformance/NoSuchMethod", map[string]any{})
	if unknown.Response == nil || unknown.Response.Error == nil || unknown.Response.Error.Code != a2a.CodeMethodNotFound || unknown.Outcome.Status >= 500 {
		c.Errorf("an unknown method: want JSON-RPC error %d, got %s", a2a.CodeMethodNotFound, unknown)
	}
	twin := c.Env.A2A(tok, nil).Get(c, "conformance-unknown-"+randomHex(6))
	if twin.Response == nil || twin.Outcome.Status >= 500 {
		c.Errorf("the allowed twin, a valid request, got no JSON-RPC answer: %s", twin)
	}
}

func mcpTools(c *C) {
	tok := c.Env.Inbound(c, contract.NewPerson("conformance"))
	cl := c.Env.MCP(tok, nil)
	_, call := cl.ListTools(c)
	if !call.OK() {
		c.Fatalf("tools/list: %s", call)
	}
	var res struct {
		Tools []mcp.Tool `json:"tools"`
	}
	json.Unmarshal(call.Response.Result, &res)
	listed := map[string]mcp.Tool{}
	for _, t := range res.Tools {
		listed[t.Name] = t
	}
	for _, want := range c.Env.Workload.Tools {
		t, ok := listed[want.Name]
		if !ok {
			c.Errorf("tools/list does not list %s, which workload.yaml declares", want.Name)
			continue
		}
		if typ, _ := t.InputSchema["type"].(string); typ != "object" {
			c.Errorf("%s: inputSchema is not an object schema: %v", want.Name, t.InputSchema)
		}
		for _, hint := range []string{"readOnlyHint", "destructiveHint"} {
			w, declared := want.Annotations[hint]
			if !declared {
				continue
			}
			got, stated := t.Annotations[hint].(bool)
			if !stated || got != w {
				c.Errorf("%s: %s is %v in tools/list, %v in workload.yaml; hints are stated, never left to MCP's defaults", want.Name, hint, t.Annotations[hint], w)
			}
		}
	}
	unknown := cl.CallTool(c, "conformance_no_such_tool", map[string]any{})
	switch {
	case unknown.Outcome.Kind != outcome.Response || unknown.Outcome.Status >= 500:
		c.Errorf("tools/call of an unknown tool: no protocol answer: %s", unknown.Outcome)
	case unknown.Response == nil:
		c.Errorf("tools/call of an unknown tool: not a JSON-RPC response: %s", unknown.Outcome)
	case unknown.Response.Error == nil:
		if r, err := unknown.Result(); err != nil || !r.IsError {
			c.Errorf("tools/call of an unknown tool succeeded: %s", shorten(string(unknown.Response.Result)))
		}
	}
	ro := c.Env.Workload.ReadOnlyTools()
	if len(ro) == 0 {
		c.Logf("no read-only tool to call as the allowed twin; tools/list was the twin")
		return
	}
	twin := cl.CallTool(c, ro[0], sampleArgs(listed[ro[0]].InputSchema, c.Env.Marker("arg")))
	if r, err := twin.Result(); err != nil || r.IsError {
		c.Errorf("the allowed twin, tools/call of %s, did not answer a result: %s", ro[0], twin)
	}
}

// sampleArgs fills an input schema's required string properties.
func sampleArgs(schema map[string]any, value string) map[string]any {
	out := map[string]any{}
	req, _ := schema["required"].([]any)
	props, _ := schema["properties"].(map[string]any)
	for _, r := range req {
		name, _ := r.(string)
		p, _ := props[name].(map[string]any)
		switch p["type"] {
		case "integer", "number":
			out[name] = 1
		case "boolean":
			out[name] = false
		default:
			out[name] = value
		}
	}
	return out
}

func mcpErrors(c *C) {
	tok := c.Env.Inbound(c, contract.NewPerson("conformance"))
	h := map[string]string{"Authorization": "Bearer " + tok, "Content-Type": "application/json", "Accept": "application/json, text/event-stream"}
	bad := c.Env.HTTP.Do(c, outcome.Request{Method: http.MethodPost, URL: c.Env.URL + "/mcp", Header: h, Body: `{"jsonrpc": "2.0", "id": 1, "method":`})
	if code, ok := rpcErrorCode(bad); !ok || bad.Status >= 500 || (code != -32700 && code != -32600) {
		c.Errorf("a request that is not JSON: want a JSON-RPC parse or invalid-request error, got %s", bad)
	}
	if _, call := c.Env.MCP(tok, nil).ListTools(c); !call.OK() {
		c.Errorf("the allowed twin, tools/list: %s", call)
	}
}
