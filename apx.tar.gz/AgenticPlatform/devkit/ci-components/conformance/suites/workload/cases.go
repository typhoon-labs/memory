package workload

// Cases returns the contract stage's cases for the workload, in the order
// they run: L1 always, L2 when the level is L2 or above. Which cases of a
// category apply follows workload.yaml: an agent's or an MCP server's,
// delegation and cache isolation for an agent that calls on.
func Cases(e *Env) []Case {
	var all []Case
	all = append(all, identityCases(e)...)
	all = append(all, protocolCases(e)...)
	all = append(all, lifecycleCases(e)...)
	all = append(all, delegationCases(e)...)
	all = append(all, telemetryCases(e)...)
	all = append(all, retryCases(e)...)
	all = append(all, limitCases(e)...)
	if e.Level >= "L2" {
		all = append(all, l2Cases(e)...)
	}
	return all
}
