package workload

import (
	"fmt"
	"strings"
	"sync"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
)

const (
	delegationRow = "Delegation: never forwards its inbound token. Downstream sees a token for the downstream's audience, the same sub, and the workload as current actor"
	cacheRow      = "Token cache isolation: two users in parallel: each downstream call carries its own user's sub"
)

// callOnce is a task that calls the allowed tool once and then answers.
func callOnce(e *Env) string {
	tool, _ := e.AllowedTool()
	return fmt.Sprintf("Use %s once. [[fake-model tool=%s]]", tool, tool)
}

func delegationCases(e *Env) []Case {
	if !e.Agent() || !e.CallsOn() {
		return nil
	}
	return []Case{
		{ID: "l1/delegation/tool-token", Suite: "l1/delegation", Layer: LayerDelegation, Row: delegationRow,
			Title: "the MCP server gets a chain token for its own route, the person's sub and the workload as act; never the inbound token",
			Run:   toolToken},
		{ID: "l1/delegation/model-token", Suite: "l1/delegation", Layer: LayerDelegation, Row: delegationRow,
			Title: "the model route gets a chain token for its own route, the person's sub and the workload as act; never the inbound token",
			Run:   modelToken},
		{ID: "l1/delegation/refused-exchange", Suite: "l1/delegation", Layer: LayerSTS, Row: delegationRow,
			Title: "when the STS refuses a person's exchange, nothing goes downstream for the task, the inbound token least of all; an allowed person's task goes on",
			Run:   refusedExchange},
		{ID: "l1/cache-isolation/concurrent-users", Suite: "l1/cache-isolation", Layer: LayerDelegation, Row: cacheRow,
			Title: "tasks of two people in parallel: every downstream call carries its own person's sub, none the other's",
			Run:   cacheIsolation},
	}
}

// checkChain judges a downstream token: issued by the STS for audience,
// for the person, with the workload as the outermost actor, and never the
// inbound token.
func checkChain(c *C, where, raw, inbound, audience, sub string) {
	if raw == inbound {
		c.Errorf("%s received the workload's inbound token: the workload forwarded its caller's token instead of exchanging it", where)
		return
	}
	t, err := jose.Parse(raw)
	if err != nil {
		c.Errorf("%s received no chain token: %q", where, shorten(raw))
		return
	}
	iss, _ := t.Claims["iss"].(string)
	aud, _ := t.Claims["aud"].(string)
	s, _ := t.Claims["sub"].(string)
	act, _ := t.Claims["act"].(map[string]any)
	actor, _ := act["sub"].(string)
	switch {
	case iss != contract.STSIssuer:
		c.Errorf("%s: the token's issuer is %q, not the STS", where, iss)
	case aud != audience:
		c.Errorf("%s: the token's audience is %v, not %s", where, t.Claims["aud"], audience)
	case s != sub:
		c.Errorf("%s: the token's sub is %q, not the person's %q", where, s, sub)
	case actor != c.Env.ActorSub():
		c.Errorf("%s: the token's act.sub is %q, not the workload, %s", where, actor, c.Env.ActorSub())
	}
}

func toolToken(c *C) {
	p := contract.NewPerson("conformance")
	t := c.Env.Send(c, p, callOnce(c.Env), contract.Script(func(int, string, []byte) string { return "ok " + contract.End }))
	if t.Err != nil || t.Task.Status.State != a2a.Completed {
		c.Fatalf("the task did not complete: %v %s %s", t.Err, t.Task.Status.State, shorten(t.Task.Text()))
	}
	inbound := c.Env.Person(p, contract.TokenOpts{})
	_, server := c.Env.AllowedTool()
	var seen int
	for _, call := range c.Env.H.Tools.Calls() {
		if call.TaskID != t.ID && !(call.Claims != nil && call.Claims["sub"] == p.Sub) {
			continue
		}
		seen++
		if call.Refused != "" {
			c.Errorf("the MCP server refused the token of the task's %s: %s", call.Method, call.Refused)
		}
		checkChain(c, "the MCP server ("+call.Method+")", call.Token, inbound, c.Env.H.Tools.Audience(server), p.Sub)
	}
	if seen == 0 {
		c.Errorf("no request of the task reached the MCP server: the allowed path never ran")
	}
}

func modelToken(c *C) {
	p := contract.NewPerson("conformance")
	t := c.Env.Send(c, p, "Say something short.", nil)
	if t.Err != nil || t.Task.Status.State != a2a.Completed {
		c.Fatalf("the task did not complete: %v %s", t.Err, t.Task.Status.State)
	}
	inbound := c.Env.Person(p, contract.TokenOpts{})
	var seen int
	for _, m := range c.Env.H.ModelCalls() {
		mt, err := jose.Parse(m.Token)
		if m.TaskID != t.ID && (err != nil || mt.Claims["sub"] != p.Sub) {
			continue
		}
		seen++
		checkChain(c, "the model route", m.Token, inbound, "https://workloads-gateway."+c.Env.S.Domain+"/v1", p.Sub)
	}
	if seen == 0 {
		c.Errorf("no model request of the task reached the model route")
	}
}

func refusedExchange(c *C) {
	denied := c.Env.Denied
	t := c.Env.Send(c, denied, callOnce(c.Env), nil)
	if t.Err == nil && t.Task.Status.State == a2a.Completed {
		c.Errorf("the task of a person on the STS's deny list completed: %q", shorten(t.Task.Text()))
	}
	inbound := c.Env.Person(denied, contract.TokenOpts{})
	for _, call := range c.Env.H.Tools.Calls() {
		if call.TaskID == t.ID || call.Token == inbound || (call.Claims != nil && call.Claims["sub"] == denied.Sub) {
			c.Errorf("a request of the refused task reached the MCP server (%s, refused there: %q)", call.Method, call.Refused)
		}
	}
	for _, m := range c.Env.H.ModelCalls() {
		mt, _ := jose.Parse(m.Token)
		if m.TaskID == t.ID || m.Token == inbound || (mt != nil && mt.Claims["sub"] == denied.Sub) {
			c.Errorf("a model request of the refused task reached the model route")
		}
	}
	refused := false
	for _, line := range c.Env.H.STS.Audit() {
		refused = refused || (strings.Contains(line, "subject_denied") && strings.Contains(line, denied.Sub))
	}
	if !refused {
		c.Errorf("the STS recorded no subject_denied refusal for the person: the case did not reach the STS")
	}
	allowed := c.Env.Send(c, contract.NewPerson("conformance"), callOnce(c.Env), contract.Script(func(int, string, []byte) string { return "ok " + contract.End }))
	if allowed.Err != nil || allowed.Task.Status.State != a2a.Completed {
		c.Errorf("the allowed twin, another person's same task, did not complete: %v %s", allowed.Err, allowed.Task.Status.State)
	}
}

func cacheIsolation(c *C) {
	people := []contract.Person{contract.NewPerson("conformance"), contract.NewPerson("conformance-other")}
	const each = 3
	ok := contract.Script(func(int, string, []byte) string { return "ok " + contract.End })
	// The first person's first task alone, so that any token a cache keeps
	// for the target is theirs when the others start; then the rest at once.
	tasks := make([]*Task, 2*each)
	tasks[0] = c.Env.Send(c, people[0], callOnce(c.Env), ok)
	var wg sync.WaitGroup
	for i := 1; i < len(tasks); i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			tasks[i] = c.Env.Send(c, people[i%2], callOnce(c.Env), ok)
		}(i)
	}
	wg.Wait()
	byTask := map[string]contract.Person{}
	for _, t := range tasks {
		if t.Err != nil || t.Task.Status.State != a2a.Completed {
			c.Errorf("task %s of %s did not complete: %v %s", t.ID, t.Person.Sub, t.Err, t.Task.Status.State)
		}
		byTask[t.ID] = t.Person
	}
	var checked int
	for _, call := range c.Env.H.Tools.Calls() {
		p, ok := byTask[call.TaskID]
		if !ok {
			continue
		}
		checked++
		if s, _ := call.Claims["sub"].(string); s != p.Sub {
			c.Errorf("a tool call of %s's task carried sub %q: another user's token from the cache", p.Sub, s)
		}
	}
	for _, m := range c.Env.H.ModelCalls() {
		p, ok := byTask[m.TaskID]
		if !ok {
			continue
		}
		checked++
		if t, err := jose.Parse(m.Token); err != nil || t.Claims["sub"] != p.Sub {
			c.Errorf("a model call of %s's task carried another user's token", p.Sub)
		}
	}
	if checked < 2*each {
		c.Errorf("only %d downstream calls of the %d tasks could be tied to their task by Agentic-Task-Id: the workload does not propagate the task header", checked, 2*each)
	}
}
