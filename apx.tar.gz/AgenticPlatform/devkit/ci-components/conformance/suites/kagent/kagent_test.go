package kagent_test

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/registry"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/kagent"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform/standin"
)

// The profile's own tests: every case against the platform stand-in,
// whose kagent fixture agent stands for the agent under test, and a
// registry holding its packaged definition, right and then wrong in one
// property at a time. On the stand-in no actor runs, as on this
// workstation's kernel: the actor cases must skip, naming why.

// fakeRegistry serves one repository: manifests by digest and tag, blobs
// by digest.
type fakeRegistry struct {
	manifests, blobs map[string][]byte
}

func digestOf(b []byte) string { s := sha256.Sum256(b); return "sha256:" + hex.EncodeToString(s[:]) }

func (f *fakeRegistry) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	rest, ok := strings.CutPrefix(r.URL.Path, "/v2/workloads/reference/notes/")
	if !ok {
		http.NotFound(w, r)
		return
	}
	kind, ref, _ := strings.Cut(rest, "/")
	m := map[string]map[string][]byte{"manifests": f.manifests, "blobs": f.blobs}[kind]
	b, ok := m[ref]
	if !ok {
		http.NotFound(w, r)
		return
	}
	if kind == "manifests" {
		w.Header().Set("Content-Type", registry.OCIManifest)
	}
	w.Write(b)
}

// image adds a manifest of one layer and returns its digest; signed adds
// cosign's referrers tag for it.
func (f *fakeRegistry) image(layer []byte, signed bool) string {
	ld := digestOf(layer)
	f.blobs[ld] = layer
	m, _ := json.Marshal(registry.Manifest{MediaType: registry.OCIManifest, Layers: []registry.Descriptor{{MediaType: "application/json", Digest: ld, Size: int64(len(layer))}}})
	d := digestOf(m)
	f.manifests[d] = m
	if signed {
		f.manifests[strings.Replace(d, ":", "-", 1)] = m
	}
	return d
}

type world struct {
	skillUnsigned, skillByTag bool
}

func run(t *testing.T, f standin.Faults, wf world) map[string]runner.Result {
	t.Helper()
	w, err := standin.New(f)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(w.Close)
	penv, err := w.Env()
	if err != nil {
		t.Fatal(err)
	}
	reg := &fakeRegistry{manifests: map[string][]byte{}, blobs: map[string][]byte{}}
	srv := httptest.NewServer(reg)
	t.Cleanup(srv.Close)
	repo := strings.TrimPrefix(srv.URL, "http://") + "/workloads/reference/notes"
	skill := repo + "@" + reg.image([]byte("SKILL.md"), !wf.skillUnsigned)
	if wf.skillByTag {
		skill = repo + ":v1-skill-notes"
	}
	def, _ := json.Marshal(map[string]any{"apiVersion": "api.kagent.dev/v1alpha3", "kind": "AgentTemplate",
		"spec": map[string]any{"skills": []any{map[string]any{"name": "notes", "source": map[string]any{"oci": skill}}}}})
	p := &kagent.Profile{Agent: "kagent-reader", Namespace: "kagent-reader", HostedActor: "relay-agent", RouteLimit: standin.KagentRouteLimit,
		Definition: repo + "@" + reg.image(def, true), PlainHTTP: true, NoActor: "no actor can start: kernel lacks CONFIG_NFT_REDIR (T27)"}
	p.Actor.Tool, p.Actor.Arg, p.Actor.ApprovalTool, p.Actor.ApprovalArg = "get_note", "note_id", "add_note", "note_id"
	p.Actor.Snapshots, p.Actor.K2.Admitted, p.Actor.K2.Refused = "s3://agentic-kagent-snapshots-local/kagent-reader/", "kagent-reader", "kagent-outsider"
	if err := p.Complete(); err != nil {
		t.Fatal(err)
	}
	env := &kagent.Env{P: penv, Profile: p, Registry: &registry.Client{PlainHTTP: true}}
	out := map[string]runner.Result{}
	for _, k := range kagent.Cases() {
		out[k.ID] = runner.Run(context.Background(), env, k)
	}
	return out
}

// actorCases are those that need a running actor.
func actorCase(k kagent.Case) bool {
	for _, n := range k.Needs {
		if n == kagent.NeedActor {
			return true
		}
	}
	return false
}

func TestRightAnswers(t *testing.T) {
	res := run(t, standin.Faults{}, world{})
	for _, k := range kagent.Cases() {
		r := res[k.ID]
		switch {
		case actorCase(k):
			if r.Status != runner.Skip || !strings.Contains(r.Message, "no actor can start: kernel lacks CONFIG_NFT_REDIR (T27)") || !strings.Contains(r.Message, "GoldenActorCrashed") {
				t.Errorf("%s: want skipped, naming T27 and the Agent's state, got %s: %s", k.ID, r.Status, r.Message)
			}
		case r.Status != runner.Pass:
			t.Errorf("%s: want pass on the right answers, got %s:\n%s\n%s", k.ID, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
}

func TestFaults(t *testing.T) {
	for _, tc := range []struct {
		name   string
		f      standin.Faults
		w      world
		expect map[string]string // case ID -> words of its message
	}{
		{"typ not checked", standin.Faults{IgnoreTyp: true}, world{}, map[string]string{kagent.Suite + "/identity/route-tokens": "want the gateway's 403, got its 401"}},
		{"no signature check", standin.Faults{NoSignatureCheck: true}, world{}, map[string]string{kagent.Suite + "/identity/route-tokens": "unknown key"}},
		{"roles not checked", standin.Faults{SkipRoleCheck: true}, world{}, map[string]string{kagent.Suite + "/gateway-path/role": "want the gateway's 403"}},
		{"no NetworkPolicy", standin.Faults{NoNetworkPolicy: true}, world{}, map[string]string{kagent.Suite + "/gateway-path/direct-ingress": "want networkpolicy to refuse"}},
		{"the hosted route names no actor", standin.Faults{KagentRouteNoActors: true}, world{}, map[string]string{kagent.Suite + "/gateway-path/hosted-route": "allowed twin"}},
		{"no card", standin.Faults{NoCard: true}, world{}, map[string]string{kagent.Suite + "/protocol/agent-card": "allowed twin"}},
		{"no route limit", standin.Faults{NoRouteLimit: true}, world{}, map[string]string{kagent.Suite + "/limits/route-rate": "got no 429"}},
		{"an unsigned skill", standin.Faults{}, world{skillUnsigned: true}, map[string]string{kagent.Suite + "/supply-chain/definition": "has no signature"}},
		{"a skill by tag", standin.Faults{}, world{skillByTag: true}, map[string]string{kagent.Suite + "/supply-chain/definition": "by tag, not by digest"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			res := run(t, tc.f, tc.w)
			for _, k := range kagent.Cases() {
				r := res[k.ID]
				words, want := tc.expect[k.ID]
				switch {
				case actorCase(k):
				case want && (r.Status != runner.Fail || !strings.Contains(r.Message, words)):
					t.Errorf("%s: want a fail naming %q, got %s: %s", k.ID, words, r.Status, r.Message)
				case !want && r.Status != runner.Pass:
					t.Errorf("%s: want pass (the fault is not this case's), got %s: %s", k.ID, r.Status, r.Message)
				}
			}
		})
	}
}

// TestT30: where the gateway cannot read kagent's card, as B4 saw, the
// card case skips naming T30.
func TestT30(t *testing.T) {
	r := run(t, standin.Faults{CardT30: true}, world{})[kagent.Suite+"/protocol/agent-card"]
	if r.Status != runner.Skip || !strings.Contains(r.Message, "T30") {
		t.Errorf("want skipped naming T30, got %s: %s", r.Status, r.Message)
	}
}

// TestActorRuns: where the Agent is Ready, the actor cases run, not skip.
func TestActorRuns(t *testing.T) {
	res := run(t, standin.Faults{ActorReady: true}, world{})
	for _, k := range kagent.Cases() {
		if r := res[k.ID]; actorCase(k) && r.Status == runner.Skip && strings.Contains(r.Message, "needs actor") {
			t.Errorf("%s: skipped for want of an actor, which runs: %s", k.ID, r.Message)
		}
	}
}
