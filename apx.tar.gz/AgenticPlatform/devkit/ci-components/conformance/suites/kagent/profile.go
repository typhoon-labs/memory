// Package kagent is the kagent profile (design/conformance.md, "The kagent
// profile"; plan/local-build.md, "B5 in detail", check 9): what a
// declarative kagent agent passes in place of the L1 suites, since kagent
// decodes inbound tokens without verifying them and runs no pod per agent.
// Identity and Gateway path are asserted at the agent's gateway routes,
// Delegation is replaced by K2, Lifecycle by suspend and resume, Telemetry
// carries K10's tolerance, and Protocol, Retries at the model route,
// Limits at the route and Supply chain apply.
//
// It runs as the Helm test of a kagent-profile release of the conformance
// chart (runner.mode kagent), beside the platform-controls release, whose
// personas, probes and stores it reuses, against an agent environments'
// kagent-agents renders into its own namespace from its packaged
// definition. The cases that need a running actor skip, naming why, when
// none runs: on a kernel without CONFIG_NFT_REDIR no Substrate actor can
// start (T27); they run unchanged where one can.
package kagent

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"sync"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/registry"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// Profile is the agent under test and what the profile needs to know of
// it. Its routes are a2a/<agent> on both deployments (D18).
type Profile struct {
	Agent     string `json:"agent"`
	Namespace string `json:"namespace"` // where its Agent is; default kagent-profile
	// Scope is its developer route's client scope; default a2a/<agent>.
	Scope string `json:"scope"`
	// RefusedRole is a role its developer route does not admit; default
	// incident-manager.
	RefusedRole string `json:"refused_role"`
	// HostedActor is the actor its hosted-workloads route names, whose
	// chain token the STS issues for it, such as relay-agent; empty when
	// its access file names none.
	HostedActor string `json:"hosted_actor"`
	// Controller is kagent's controller's A2A endpoint for the agent,
	// reached past the gateway; default
	// http://kagent-controller.kagent.svc.cluster.local:8083/agents/<namespace>/<agent>.
	Controller string `json:"controller"`
	// RouteLimit is the requests a minute its developer route admits per
	// person (its local rate limit); 0 leaves the limits case out.
	RouteLimit int `json:"route_limit"`
	// Definition is its packaged definition, by digest, as kagent-package
	// published it: <registry>/<repository>@sha256:<hex>. PlainHTTP when
	// the registry speaks plain HTTP (floci).
	Definition string `json:"definition"`
	PlainHTTP  bool   `json:"plain_http"`
	// NoActor says why no actor can start in this environment, when that
	// is known, for the actor cases' skips; whether one runs is read from
	// the Agent's Ready condition.
	NoActor string `json:"no_actor"`
	// Actor are what the actor cases need.
	Actor struct {
		// Tool is a read-only tool its model may call, and Arg one of its
		// arguments, whose value the tool's result names (reference-mcp's
		// get_note and note_id).
		Tool string `json:"tool"`
		Arg  string `json:"arg"`
		// ApprovalTool is a tool bound with requireApproval (K3), such as
		// add_note, with an argument.
		ApprovalTool string `json:"approval_tool"`
		ApprovalArg  string `json:"approval_arg"`
		// Snapshots is where its sessions' snapshots land:
		// s3://<bucket>/<prefix>/.
		Snapshots string `json:"snapshots"`
		// Service is its spans' service.name; default the agent's name.
		Service string `json:"service"`
		// K2 names two fixture agents bound to capture-mcp through
		// Substrate's listener: one whose atespace its route admits, one
		// whose it does not (kagent-reader and kagent-outsider).
		K2 struct {
			Admitted string `json:"admitted"`
			Refused  string `json:"refused"`
		} `json:"k2"`
	} `json:"actor"`
}

// LoadProfile reads a profile.
func LoadProfile(path string) (*Profile, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var p Profile
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&p); err != nil {
		return nil, fmt.Errorf("%s: %v", path, err)
	}
	if err := p.Complete(); err != nil {
		return nil, fmt.Errorf("%s: %v", path, err)
	}
	return &p, nil
}

// Complete fills defaults and checks the required fields.
func (p *Profile) Complete() error {
	if p.Agent == "" {
		return fmt.Errorf("agent is required")
	}
	def(&p.Namespace, "kagent-profile")
	def(&p.Scope, "a2a/"+p.Agent)
	def(&p.RefusedRole, platform.RoleIncidentManager)
	def(&p.Controller, "http://kagent-controller.kagent.svc.cluster.local:8083/agents/"+p.Namespace+"/"+p.Agent)
	def(&p.Actor.Service, p.Agent)
	if p.Definition != "" && !strings.Contains(p.Definition, "@sha256:") {
		return fmt.Errorf("definition %q: name the packaged definition by digest", p.Definition)
	}
	return nil
}

func def(s *string, v string) {
	if *s == "" {
		*s = v
	}
}

// Env is the profile's environment: the platform suites', and the agent.
type Env struct {
	P        *platform.Env
	Profile  *Profile
	Registry *registry.Client

	once  sync.Once
	actor string // why no actor runs, "" if one does
}

// Needs of the profile, beyond the platform suites'.
const (
	NeedActor      runner.Need = "actor"            // a Substrate actor of the agent's
	NeedHosted     runner.Need = "hosted-actor"     // an actor its hosted-workloads route names
	NeedDefinition runner.Need = "definition"       // its packaged definition
	NeedRouteLimit runner.Need = "route-limit"      // its developer route's rate limit
	NeedApproval   runner.Need = "approval-tool"    // a tool bound with requireApproval
	NeedSnapshots  runner.Need = "snapshots-bucket" // where its snapshots land
	NeedK2Agents   runner.Need = "k2-agents"        // the fixture agents K2 asks
)

// Unmet implements runner.Env.
func (e *Env) Unmet(n runner.Need) string {
	p := e.Profile
	switch n {
	case NeedActor:
		e.once.Do(func() { e.actor = e.actorState() })
		return e.actor
	case NeedHosted:
		if p.HostedActor == "" {
			return "the agent's access file names no actor on the hosted-workloads deployment (hosted_actor)"
		}
	case NeedDefinition:
		if p.Definition == "" {
			return "set definition: the packaged definition, by digest"
		}
	case NeedRouteLimit:
		if p.RouteLimit == 0 {
			return "set route_limit: the requests a minute the agent's developer route admits per person"
		}
	case NeedApproval:
		if p.Actor.ApprovalTool == "" {
			return "set actor.approval_tool: a tool bound with requireApproval"
		}
	case NeedSnapshots:
		if p.Actor.Snapshots == "" || e.P.S3 == nil {
			return "set actor.snapshots and s3: where the agent's snapshots land"
		}
	case NeedK2Agents:
		if p.Actor.K2.Admitted == "" || p.Actor.K2.Refused == "" || e.P.Cfg.CaptureMCP.Ops == "" {
			return "set actor.k2: two fixture agents bound to capture-mcp, and capture_mcp.ops"
		}
	default:
		return e.P.Unmet(n)
	}
	return ""
}

// actorState is why no actor of the agent runs, read from its Agent's
// Ready condition, which kagent sets once its golden actor has started;
// "" when it is Ready.
func (e *Env) actorState() string {
	p := e.Profile
	if e.P.Kube == nil {
		return "the runner cannot read the Agent " + p.Namespace + "/" + p.Agent + " to tell whether an actor runs"
	}
	var a struct {
		Status struct {
			Conditions []struct {
				Type    string `json:"type"`
				Status  string `json:"status"`
				Reason  string `json:"reason"`
				Message string `json:"message"`
			} `json:"conditions"`
		} `json:"status"`
	}
	path := "/apis/api.kagent.dev/v1alpha3/namespaces/" + p.Namespace + "/agents/" + p.Agent
	if err := e.P.Kube.Get(context.Background(), path, &a); err != nil {
		return "cannot tell whether an actor runs: reading the Agent: " + err.Error()
	}
	ready := "no Ready condition"
	for _, c := range a.Status.Conditions {
		if c.Type == "Ready" {
			if c.Status == "True" {
				return ""
			}
			ready = c.Reason + ": " + c.Message
		}
	}
	why := "no actor runs"
	if p.NoActor != "" {
		why = p.NoActor
	}
	return fmt.Sprintf("%s; the Agent %s/%s is not Ready (%s)", why, p.Namespace, p.Agent, ready)
}

// C and Case are the runner's, over Env.
type (
	C    = runner.C[*Env]
	Case = runner.Case[*Env]
)
