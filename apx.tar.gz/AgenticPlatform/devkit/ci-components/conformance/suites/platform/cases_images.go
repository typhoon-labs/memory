package platform

import (
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// imageStates are admission.images' fixtures, by JSON name, as the need's
// message describes each.
var imageStates = map[string]string{
	"admitted":               "signed and attested with the release key and conformance-attested at its level with the conformance key",
	"unsigned":               "under registry.host by digest, with no signature",
	"other_key":              "signed and attested with a key that is not the release key",
	"signed_only":            "with the release key's signature and no attestation",
	"no_conformance":         "signed and attested with the release key and never conformance-attested",
	"conformance_by_release": "whose conformance attestation the release key signed (TM13)",
	"below_level":            "conformance-attested below the level it requires",
	"old_suite":              "conformance-attested by suites older than the environment's minimum",
	"by_tag":                 "under registry.host by tag",
	"outside":                "outside registry.host, which the environment does not pin",
}

func (i AdmissionImages) ref(name string) string {
	return map[string]string{
		"admitted": i.Admitted, "unsigned": i.Unsigned, "other_key": i.OtherKey, "signed_only": i.SignedOnly,
		"no_conformance": i.NoConformance, "conformance_by_release": i.ConformanceByRelease,
		"below_level": i.BelowLevel, "old_suite": i.OldSuite, "by_tag": i.ByTag, "outside": i.Outside,
	}[name]
}

// imageRefusals are image-verification's refusals (environments'
// charts/kyverno-rules, D36): each fixture, and the clause that refuses
// it, cut before any value the environment renders into it. The release
// key's clauses name the key as the workload policy renders it.
var imageRefusals = []struct{ state, what, clause string }{
	{"unsigned", "an unsigned image", "no signature by the release key"},
	{"other_key", "an image another key signed and attested", "no signature by the release key"},
	{"signed_only", "an image signed with the release key, with no attestation", "no SBOM attestation by the release key"},
	{"no_conformance", "a release never conformance-attested", "no conformance attestation by the conformance key"},
	{"conformance_by_release", "a release whose conformance attestation the release key signed", "no conformance attestation by the conformance key"},
	{"below_level", "a release conformance-attested below its level", "conformance level tested below the level required"},
	{"old_suite", "a release conformance-attested by suites older than the minimum", "conformance suite older than the minimum"},
	{"by_tag", "an image under registry.host by tag", "an image under registry.host not by digest"},
	{"outside", "an image outside registry.host the environment does not pin", "an image outside registry.host that the environment does not pin"},
}

// imagePod is a plain non-root Pod in the image namespace, its one
// container's image one of admission.images. The image namespace is the
// platform's admission-probe locally (admission.image_namespace), a
// workload namespace image-verification governs as any other; the other
// cases' Pods run admission.images.admitted (podImage), so they meet
// image-verification there without a refusal.
func imagePod(name, state string) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		m := meta(e, name, nil)
		m["namespace"] = e.Cfg.Admission.ImageNamespace
		ctr := map[string]any{"name": "app", "image": e.Cfg.Admission.Images.ref(state), "securityContext": map[string]any{
			"runAsNonRoot": true, "runAsUser": 65532, "allowPrivilegeEscalation": false, "capabilities": map[string]any{"drop": []any{"ALL"}}}}
		return map[string]any{"apiVersion": "v1", "kind": "Pod", "metadata": m, "spec": map[string]any{"containers": []any{ctr}}}
	}
}

// imageVerificationRules are image-verification's cases, one per fixture,
// each beside the admitted twin, so that a fixture the environment has
// not made skips by name instead of failing the others.
func imageVerificationRules() []admissionRule {
	var out []admissionRule
	for _, r := range imageRefusals {
		out = append(out, admissionRule{
			name: "image-verification/" + r.state, rule: "image-verification", row: "image-verification (D36)",
			title: r.what + " is refused by image-verification in a workload namespace; a release signed, attested and conformance-attested is admitted",
			needs: []runner.Need{NeedAdmissionImage(r.state), NeedAdmissionImage("admitted")},
			refused: []admissionObject{
				// A fixture's JSON name holds underscores, which no object
				// name may: the API server refuses one before admission runs.
				{r.what, "pods", r.clause, imagePod("iv-"+strings.ReplaceAll(r.state, "_", "-"), r.state)},
			},
			allowed: []admissionObject{
				{"a release signed, attested and conformance-attested", "pods", "", imagePod("iv-admitted", "admitted")},
			},
		})
	}
	return out
}
