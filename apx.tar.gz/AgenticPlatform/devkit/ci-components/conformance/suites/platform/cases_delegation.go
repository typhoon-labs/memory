package platform

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	relayagent "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/relay-agent"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// The delegation suite (design/conformance.md, "The platform-controls
// suites"), across the two gateway deployments (design/gateway.md, "Routes
// and issuers"): a chain token works on its own route and gets 401 on any
// other; a chain token gets 401 on the developer deployment and a person's
// token on the hosted-workloads deployment, so an agent that forwards its
// caller's token fails; a route admits only the outermost actors its access
// file names (403). End to end, a person calls an agent through the
// developer deployment, the agent exchanges and calls an MCP server through
// the hosted-workloads deployment, and the server receives a token for its
// own route with the person's sub and the agent as outermost act.
const SuiteDelegation = "delegation"

const (
	relayRoute    = "gateway/a2a/relay-agent"
	outsiderRoute = "gateway/a2a/outsider-agent"
	chainMCPRoute = "workloads-gateway/mcp/capture-mcp"
	chainModel    = "workloads-gateway/v1"
)

// agentCall is what an agent reported, with the outcome of calling it.
type agentCall struct {
	Outcome outcome.Outcome
	Report  *relayagent.Report
}

// ask sends an instruction to a fixture agent through its route on the
// developer deployment, as role.
func (e *Env) ask(ctx context.Context, c *C, role, agentRoute string, in relayagent.Instruction) agentCall {
	data, _ := json.Marshal(in)
	body, _ := json.Marshal(map[string]any{"jsonrpc": "2.0", "id": 1, "method": "message/send", "params": map[string]any{
		"message": map[string]any{"kind": "message", "role": "user", "messageId": e.Marker("msg"),
			"parts": []any{map[string]any{"kind": "data", "data": json.RawMessage(data)}}},
	}})
	o := e.Do(ctx, e.Runner, outcome.Request{Method: http.MethodPost, URL: e.Cfg.CallURL(agentRoute), Body: string(body),
		Header: map[string]string{"Authorization": "Bearer " + token(c, role, agentRoute), "Content-Type": "application/json"}})
	ac := agentCall{Outcome: o}
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		return ac
	}
	var resp struct {
		Result struct {
			Parts []struct {
				Data json.RawMessage `json:"data"`
			} `json:"parts"`
		} `json:"result"`
	}
	if json.Unmarshal([]byte(o.Body), &resp) == nil && len(resp.Result.Parts) > 0 {
		var r relayagent.Report
		if json.Unmarshal(resp.Result.Parts[0].Data, &r) == nil {
			ac.Report = &r
		}
	}
	return ac
}

// relayed asks an agent to act and ends the case unless it acted and the
// STS answered as want says: true for issued.
func relayed(c *C, agentRoute string, in relayagent.Instruction, wantIssued bool) *relayagent.Report {
	ac := c.Env.ask(c, c, RoleDeveloper, agentRoute, in)
	if ac.Report == nil {
		c.Fatalf("calling the agent on %s: %s", agentRoute, ac.Outcome)
	}
	r := ac.Report
	if r.Error != "" {
		c.Fatalf("the agent on %s: %s", agentRoute, r.Error)
	}
	if !r.Inbound.Present {
		c.Fatalf("no token reached the agent on %s: the gateway must pass its caller's token on", agentRoute)
	}
	if in.Mode == relayagent.Exchange || in.Mode == "" {
		ex := r.Exchange
		switch {
		case ex == nil:
			c.Fatalf("the agent made no exchange")
		case ex.Failure != "":
			c.Fatalf("the agent's exchange for %s: %s", ex.Resource, ex.Failure)
		case wantIssued && ex.Status != http.StatusOK:
			c.Fatalf("the STS refused the agent's exchange for %s: HTTP %d %s/%s; the case needs it issued, so its refusal is the gateway's", ex.Resource, ex.Status, ex.Error, ex.Reason)
		}
	}
	if r.Call == nil {
		c.Fatalf("the agent made no call")
	}
	return r
}

func mcpInstruction(e *Env, mode, resource, route, marker string) relayagent.Instruction {
	return relayagent.Instruction{Mode: mode, Resource: resource, Marker: marker,
		Call: relayagent.Target{Kind: "mcp-tool", URL: e.Cfg.RouteURL(route), Tool: capturemcp.ToolEveryone}}
}

func modelInstruction(e *Env, resource, marker string) relayagent.Instruction {
	return relayagent.Instruction{Mode: relayagent.Exchange, Resource: resource, Marker: marker,
		Call: relayagent.Target{Kind: "http", Method: http.MethodPost, URL: e.Cfg.RouteURL(chainModel) + "/messages",
			Header: map[string]string{"Content-Type": "application/json", "anthropic-version": e.Cfg.Models.AnthropicVersion},
			Body:   messages(e.alias(), marker, "")}}
}

// agentSource is how the fixture agents' calls look: from a meshed pod.
func (e *Env) agentSource() Source {
	return Source{Source: outcome.Source{Name: "relay-agent", Meshed: true, MeshConnectTimeout: e.Cfg.Timing.MeshConnectTimeout.Duration}}
}

// chainCallOK checks that an agent's MCP call with a chain token went
// through, and that what capture-mcp received is a token for its own route
// with the person's sub and the agent as outermost actor.
func chainCallOK(c *C, r *relayagent.Report, agentSA string) {
	e := c.Env
	call := r.Call
	if call.Outcome.Kind != outcome.Response || call.Outcome.Status != http.StatusOK || call.RPC != nil {
		c.Errorf("the agent's call of %s through the hosted-workloads deployment: %s %v", chainMCPRoute, call.Outcome, call.RPC)
		return
	}
	var res struct {
		Structured capturemcp.Record `json:"structuredContent"`
	}
	if err := json.Unmarshal(call.Result, &res); err != nil || res.Structured.Method == "" {
		c.Errorf("capture-mcp's result carries no record: %v", err)
		return
	}
	got := res.Structured.Token
	if got == nil {
		c.Errorf("capture-mcp received no bearer token")
		return
	}
	want := map[string]string{
		"iss": e.Cfg.Issuers.STS,
		"sub": fmt.Sprint(r.Inbound.Claims["sub"]),
	}
	for k, v := range want {
		if fmt.Sprint(got.Claims[k]) != v {
			c.Errorf("the token capture-mcp received has %s %v, want %s", k, got.Claims[k], v)
		}
	}
	if aud := audiences(got.Claims); len(aud) != 1 || aud[0] != e.Cfg.RouteURL(chainMCPRoute) {
		c.Errorf("the token capture-mcp received has aud %v, want exactly [%s]", aud, e.Cfg.RouteURL(chainMCPRoute))
	}
	actor := e.Cfg.Actor("conformance", agentSA)
	if chain := actChain(got.Claims); len(chain) == 0 || chain[0] != actor {
		c.Errorf("the token capture-mcp received has act chain %v, want %s outermost", chain, actor)
	}
	if typ, _ := got.Header["typ"].(string); typ != "at+jwt" {
		c.Errorf("the token capture-mcp received is typed %q, want at+jwt", typ)
	}
	if aud := audiences(r.Inbound.Claims); len(aud) != 1 || aud[0] != e.Cfg.RouteURL(relayRoute) {
		c.Errorf("the token the agent received has aud %v, want the person's token for its own route, %s", aud, e.Cfg.RouteURL(relayRoute))
	}
}

// expectAgentRefused checks that the gateway refused the agent's call with
// status, and that capture-mcp never saw it.
func expectAgentRefused(c *C, what string, r *relayagent.Report, status int, marker string) {
	e := c.Env
	if expectGateway(c, what, r.Call.Outcome, e.agentSource(), status) {
		noCaptureRecord(c, marker)
	}
}

func delegationCases() []Case {
	base := []runner.Need{NeedPersona(RoleDeveloper), NeedRoute(relayRoute), NeedRoute(chainMCPRoute)}
	return []Case{
		{
			ID: "delegation/end-to-end", Suite: SuiteDelegation, Cluster: true, Needs: base,
			Row:   "End to end, a person calls an agent through the developer deployment, the agent exchanges and calls an MCP server through the hosted-workloads deployment, and the server receives a token for its own route with the person's sub and the agent as outermost act",
			Title: "a developer calls relay-agent, which exchanges at the STS and calls capture-mcp through the hosted-workloads deployment; capture-mcp receives a chain token for its own route with the developer's sub and relay-agent as outermost act",
			Run: func(c *C) {
				e := c.Env
				r := relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), chainMCPRoute, e.Marker("e2e")), true)
				chainCallOK(c, r, "relay-agent")
			},
		},
		{
			ID: "delegation/forwarded-token", Suite: SuiteDelegation, Layer: string(outcome.Gateway), Cluster: true, Needs: base,
			Row:   "A person's token gets 401 on the hosted-workloads deployment, so an agent that forwards its caller's token fails",
			Title: "relay-agent forwarding its caller's token unchanged to capture-mcp through the hosted-workloads deployment gets 401; exchanging it first passes",
			Run: func(c *C) {
				e := c.Env
				marker := e.Marker("forward")
				r := relayed(c, relayRoute, mcpInstruction(e, relayagent.Forward, "", chainMCPRoute, marker), false)
				expectAgentRefused(c, "the forwarded person's token", r, http.StatusUnauthorized, marker)
				r = relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), chainMCPRoute, e.Marker("twin")), true)
				chainCallOK(c, r, "relay-agent")
			},
		},
		{
			ID: "delegation/chain-token-on-developer-deployment", Suite: SuiteDelegation, Layer: string(outcome.Gateway), Cluster: true,
			Needs: append(append([]runner.Need{}, base...), NeedRoute("gateway/mcp/capture-mcp")),
			Row:   "A chain token gets 401 on the developer deployment",
			Title: "a chain token presented on the developer deployment's capture-mcp route gets 401; on its own route it passes",
			Run: func(c *C) {
				e := c.Env
				marker := e.Marker("chaindev")
				r := relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), "gateway/mcp/capture-mcp", marker), true)
				expectAgentRefused(c, "a chain token on the developer deployment", r, http.StatusUnauthorized, marker)
				r = relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), chainMCPRoute, e.Marker("twin")), true)
				chainCallOK(c, r, "relay-agent")
			},
		},
		{
			ID: "delegation/replay-elsewhere", Suite: SuiteDelegation, Layer: string(outcome.Gateway), Cluster: true,
			Needs: append(append([]runner.Need{}, base...), NeedRoute(chainModel)),
			Row:   "A chain token works on its own route and gets 401 on any other: the STS suite's replay case (design/identity.md, \"Tests a replacement STS must pass\")",
			Title: "a chain token for capture-mcp's route replayed on the model route gets 401, and one for the model route replayed on capture-mcp's; each passes on its own route",
			Run: func(c *C) {
				e := c.Env
				m1 := e.Marker("replay")
				in := modelInstruction(e, e.Cfg.RouteURL(chainMCPRoute), m1)
				r := relayed(c, relayRoute, in, true)
				if expectGateway(c, "capture-mcp's chain token on the model route", r.Call.Outcome, e.agentSource(), http.StatusUnauthorized) && e.Cfg.FakeModel.Ops != "" {
					if recs, err := e.fakeModelRecords(c, m1); err == nil && len(recs) > 0 {
						c.Errorf("the replayed token's request reached the fake model server")
					}
				}
				r = relayed(c, relayRoute, modelInstruction(e, e.Cfg.RouteURL(chainModel), e.Marker("twin")), true)
				if o := r.Call.Outcome; o.Kind != outcome.Response || o.Status != http.StatusOK {
					c.Errorf("allowed twin: the model route's own chain token: %s", o)
				}
				m2 := e.Marker("replay")
				r = relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainModel), chainMCPRoute, m2), true)
				expectAgentRefused(c, "the model route's chain token on capture-mcp's route", r, http.StatusUnauthorized, m2)
				r = relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), chainMCPRoute, e.Marker("twin")), true)
				chainCallOK(c, r, "relay-agent")
			},
		},
		{
			ID: "delegation/person-token-on-workloads-deployment", Suite: SuiteDelegation, Layer: string(outcome.Gateway), Cluster: true,
			Needs: []runner.Need{NeedHostedDeployment, NeedPersona(RoleDeveloper), NeedRoute("gateway/mcp/capture-mcp"), NeedRoute(chainMCPRoute)},
			Row:   "A person's token gets 401 on the hosted-workloads deployment",
			Title: "a person's own token for capture-mcp, presented on the hosted-workloads deployment, gets 401; on the developer deployment it passes",
			Run: func(c *C) {
				e := c.Env
				tok := token(c, RoleDeveloper, "gateway/mcp/capture-mcp")
				marker := e.Marker("person")
				_, call := e.mcpClient(e.Runner, chainMCPRoute, tok, marker).ListTools(c)
				if expectGateway(c, "a person's token on the hosted-workloads deployment", call.Outcome, e.Runner, http.StatusUnauthorized) {
					noCaptureRecord(c, marker)
				}
				_, call = e.mcpClient(e.Runner, "gateway/mcp/capture-mcp", tok, e.Marker("twin")).ListTools(c)
				expectThrough(c, "the same token on the developer deployment", call.Outcome, call.OK())
			},
		},
		{
			ID: "delegation/outermost-actor", Suite: SuiteDelegation, Layer: string(outcome.Gateway), Cluster: true,
			Needs: append(append([]runner.Need{}, base...), NeedRoute(outsiderRoute)),
			Row:   "A route admits only the outermost actors its access file names, whatever the inner chain holds (403)",
			Title: "outsider-agent's chain token, which the STS issues, gets 403 on capture-mcp's route, whose access file names relay-agent alone; relay-agent's passes",
			Run: func(c *C) {
				e := c.Env
				marker := e.Marker("outsider")
				r := relayed(c, outsiderRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), chainMCPRoute, marker), true)
				if chain := actChain(r.Exchange.Claims); len(chain) == 0 || chain[0] != e.Cfg.Actor("conformance", "outsider-agent") {
					c.Fatalf("outsider-agent's chain token has act chain %v: the case needs outsider-agent outermost", chain)
				}
				expectAgentRefused(c, "outsider-agent on capture-mcp's route", r, http.StatusForbidden, marker)
				r = relayed(c, relayRoute, mcpInstruction(e, relayagent.Exchange, e.Cfg.RouteURL(chainMCPRoute), chainMCPRoute, e.Marker("twin")), true)
				chainCallOK(c, r, "relay-agent")
			},
		},
	}
}
