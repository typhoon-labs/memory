package platform

import (
	"strings"
	"testing"
)

// TestCoverage: every claim of the design's table has a case, every case
// names the claim it proves, and IDs are unique.
func TestCoverage(t *testing.T) {
	seen := map[string]bool{}
	for _, k := range Cases() {
		if seen[k.ID] {
			t.Errorf("duplicate case ID %s", k.ID)
		}
		seen[k.ID] = true
		if k.Row == "" || k.Title == "" || k.Run == nil {
			t.Errorf("%s: a case needs a row, a title and a run", k.ID)
		}
		if !strings.HasPrefix(k.ID, k.Suite+"/") {
			t.Errorf("%s: its ID must start with its suite, %s", k.ID, k.Suite)
		}
	}
	for suite, rows := range Rows {
		for _, row := range rows {
			found := false
			for _, k := range Cases() {
				found = found || (k.Suite == suite && strings.Contains(k.Row, row))
			}
			if !found {
				t.Errorf("%s: no case proves %q", suite, row)
			}
		}
	}
}
