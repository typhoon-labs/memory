package platform

import (
	"context"
	"os"
	"path/filepath"
	"regexp"
	"slices"
	"sort"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// TestShippedConfig: the chart's configuration loads, with the values the
// chart adds, and names every route the cases need.
func TestShippedConfig(t *testing.T) {
	raw, err := os.ReadFile("../../chart/files/config.json")
	if err != nil {
		t.Fatal(err)
	}
	text := strings.Replace(string(raw), `"okta": ""`, `"okta": "https://example.okta.com"`, 1)
	path := filepath.Join(t.TempDir(), "config.json")
	os.WriteFile(path, []byte(text), 0o600)
	cfg, err := LoadConfig(path)
	if err != nil {
		t.Fatal(err)
	}
	for _, k := range Cases() {
		for _, n := range k.Needs {
			if route, ok := strings.CutPrefix(string(n), needRoutePrefix); ok {
				if _, ok := cfg.Routes[route]; !ok {
					t.Errorf("%s needs route %s, which the shipped configuration lacks", k.ID, route)
				}
			}
		}
	}
	if cfg.Gateways["gateway"] != "https://gateway.agentic.internal" || cfg.STSToken != "https://delegation-sts.agentic.internal:8443/token" {
		t.Errorf("defaults: %v %s", cfg.Gateways, cfg.STSToken)
	}
	if p := os.Getenv("RENDERED_CONFIG"); p != "" {
		if _, err := LoadConfig(p); err != nil {
			t.Errorf("the chart's rendered configuration: %v", err)
		}
	}
}

type allPersonas struct{}

func (allPersonas) Token(context.Context, string, string) (string, error) { return "", nil }
func (allPersonas) Wide(context.Context, string) (string, error)          { return "", nil }
func (allPersonas) Has(string) bool                                       { return true }

// TestShippedNeeds: with the chart's configuration and its default -skip,
// exactly the cases that await a decision, or the environment's own
// fixtures, cannot run in the cluster, so a strict run there is red for
// those reasons alone.
func TestShippedNeeds(t *testing.T) {
	raw, err := os.ReadFile("../../chart/files/config.json")
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "config.json")
	text := strings.Replace(string(raw), `"okta": ""`, `"okta": "https://example.okta.com"`, 1)
	text = strings.Replace(text, `"ca_file": "/etc/platform-ca/ca.crt"`, `"ca_file": ""`, 1) // the pod's mount
	os.WriteFile(path, []byte(text), 0o600)
	cfg, err := LoadConfig(path)
	if err != nil {
		t.Fatal(err)
	}
	env, err := NewEnv(cfg, Options{Tokens: allPersonas{}, Kube: &kube.Client{}})
	if err != nil {
		t.Fatal(err)
	}
	values, err := os.ReadFile("../../chart/values.yaml")
	if err != nil {
		t.Fatal(err)
	}
	m := regexp.MustCompile(`(?m)^  skip: (.+)$`).FindSubmatch(values)
	if m == nil {
		t.Fatal("chart/values.yaml has no runner.skip")
	}
	skip := regexp.MustCompile(string(m[1]))
	var unmet []string
	for _, k := range Cases() {
		if skip.MatchString(k.ID) {
			continue
		}
		for _, n := range k.Needs {
			if env.Unmet(n) != "" {
				unmet = append(unmet, k.ID)
				break
			}
		}
	}
	sort.Strings(unmet)
	var want []string
	for _, r := range []string{"gateway/mcp/capture-mcp", "gateway/v1"} {
		for _, p := range []string{"expired", "nbf-120s-ahead", "typ-jwt"} {
			want = append(want, "gateway-path/token/"+r+"/"+p)
		}
	}
	// image-verification's cases need the environment's own releases as
	// fixtures (admission.images), which environments renders into
	// runner.config, not the chart.
	for _, r := range imageRefusals {
		want = append(want, "bypass/admission/image-verification/"+r.state)
	}
	sort.Strings(want)
	if !slices.Equal(unmet, want) {
		t.Errorf("cases the shipped configuration cannot run:\n got %v\nwant %v", unmet, want)
	}
}

// TestNanoCost: the attribution case's cost is exact, in the usage
// table's nano-dollars, with prices taken as the decimals written.
func TestNanoCost(t *testing.T) {
	for _, tc := range []struct {
		in, out           int
		priceIn, priceOut float64
		want              int64
	}{
		{9, 12, 3, 15, 207000},    // 27 + 180 dollars a million tokens
		{1000, 0, 0.8, 4, 800000}, // 0.8 is not a binary fraction
		{1, 1, 0.0003, 0, 0},      // 0.3 nano-dollars rounds down
		{1, 1, 0.0005, 0.0002, 1}, // 0.7 rounds up
	} {
		got, err := nanoCost(tc.in, tc.out, tc.priceIn, tc.priceOut)
		if err != nil || got.Int64() != tc.want {
			t.Errorf("nanoCost(%d, %d, %v, %v) = %v, %v; want %d", tc.in, tc.out, tc.priceIn, tc.priceOut, got, err, tc.want)
		}
	}
}

// TestHostedDeploymentNeed (T32): the three cases that call the
// hosted-workloads deployment from the runner itself skip, by name and
// need, where the runner is not meshed, as on a workstation, and only
// they; in the cluster's configuration, meshed, they run.
func TestHostedDeploymentNeed(t *testing.T) {
	want := []string{
		"delegation/person-token-on-workloads-deployment",
		"kagent/k2/actor-token-elsewhere",
		"kagent/k2/hosted-agent-route",
	}
	var declared []string
	for _, k := range Cases() {
		if slices.Contains(k.Needs, NeedHostedDeployment) {
			declared = append(declared, k.ID)
			if !k.Cluster {
				t.Errorf("%s needs the hosted-workloads deployment but is not a cluster case", k.ID)
			}
		}
	}
	sort.Strings(declared)
	if !slices.Equal(declared, want) {
		t.Errorf("cases that need the hosted-workloads deployment:\n got %v\nwant %v", declared, want)
	}

	raw, err := os.ReadFile("../../chart/files/config.json")
	if err != nil {
		t.Fatal(err)
	}
	unmet := func(meshed bool) map[string]string {
		text := strings.Replace(string(raw), `"okta": ""`, `"okta": "https://example.okta.com"`, 1)
		text = strings.Replace(text, `"ca_file": "/etc/platform-ca/ca.crt"`, `"ca_file": ""`, 1)
		if !meshed {
			if !strings.Contains(text, `"runner_meshed": true`) {
				t.Fatal(`the chart's configuration no longer says "runner_meshed": true`)
			}
			text = strings.Replace(text, `"runner_meshed": true`, `"runner_meshed": false`, 1)
		}
		path := filepath.Join(t.TempDir(), "config.json")
		os.WriteFile(path, []byte(text), 0o600)
		cfg, err := LoadConfig(path)
		if err != nil {
			t.Fatal(err)
		}
		env, err := NewEnv(cfg, Options{Tokens: allPersonas{}, Kube: &kube.Client{}})
		if err != nil {
			t.Fatal(err)
		}
		out := map[string]string{}
		for _, k := range Cases() {
			// Skipped on an unmet need before the case runs, so nothing is
			// called.
			if res := runner.Run(context.Background(), env, Case{ID: k.ID, Suite: k.Suite, Needs: k.Needs, Run: func(*C) {}}); res.Status == runner.Skip {
				out[k.ID] = res.Message
			}
		}
		return out
	}
	meshed, workstation := unmet(true), unmet(false)
	for _, id := range want {
		if why, ok := meshed[id]; ok {
			t.Errorf("meshed, %s skips: %s", id, why)
		}
		if why := workstation[id]; !strings.HasPrefix(why, "needs hosted-deployment: runner_meshed is false") {
			t.Errorf("not meshed, %s: %q, want a skip naming the hosted-deployment need", id, why)
		}
	}
	for id, why := range workstation {
		if _, ok := meshed[id]; !ok && !slices.Contains(want, id) {
			t.Errorf("not meshed, %s skips too: %s", id, why)
		}
	}
}

// TestAdmissionFixtureNames: every object the admission cases dry-run has
// a name the API server takes, a lowercase RFC 1123 subdomain, so a
// refusal is admission's, never the name's (image-verification's fixtures
// once named their Pods with underscores, which the API server refused
// with 422 before admission ran).
func TestAdmissionFixtureNames(t *testing.T) {
	name := regexp.MustCompile(`^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$`)
	raw, err := os.ReadFile("../../chart/files/config.json")
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "config.json")
	text := strings.Replace(string(raw), `"okta": ""`, `"okta": "https://example.okta.com"`, 1)
	os.WriteFile(path, []byte(strings.Replace(text, `"ca_file": "/etc/platform-ca/ca.crt"`, `"ca_file": ""`, 1)), 0o600)
	c, err := LoadConfig(path)
	if err != nil {
		t.Fatal(err)
	}
	c.Admission.Images = AdmissionImages{Admitted: "r@sha256:" + strings.Repeat("a", 64)}
	n := 0
	for _, f := range AdmissionFixtures(&Env{Cfg: c}) {
		m, _ := f.Object["metadata"].(map[string]any)
		got, _ := m["name"].(string)
		if len(got) > 253 || !name.MatchString(got) {
			t.Errorf("%s: name %q is not a lowercase RFC 1123 subdomain", f.What, got)
		}
		n++
	}
	if n < 50 {
		t.Errorf("only %d admission fixtures", n)
	}
}
