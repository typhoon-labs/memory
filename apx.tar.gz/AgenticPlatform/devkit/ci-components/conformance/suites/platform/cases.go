// Package platform holds the platform-controls suites of
// design/conformance.md: gateway path, bypass and delegation, run against a
// whole environment rather than one workload, and from build phase B3 the
// telemetry group beside them. Each case proves a refusal and
// its allowed twin, and asserts which layer refused (outcome.Refuser), so a
// case cannot pass because another layer refused first and a NetworkPolicy
// case cannot pass on mTLS alone (T21).
//
// The cases are written against the routes, issuers and fixtures of build
// phase B2 (plan/local-build.md, "B2 in detail"). Cases are values, so the
// suites' own tests run them against stand-ins (package standin) that are
// wrong in known ways, and assert that each case detects it.
package platform

// Suites names the suites, in the order they run.
var Suites = []string{SuiteGatewayPath, SuiteBypass, SuiteDelegation, SuiteTelemetry, SuiteKagent}

// Cases returns every case of the three suites, the telemetry group and,
// from B4, the kagent group, in the order they run.
func Cases() []Case {
	var all []Case
	all = append(all, gatewayPathCases()...)
	all = append(all, bypassCases()...)
	all = append(all, delegationCases()...)
	all = append(all, telemetryCases()...)
	all = append(all, kagentCases()...)
	return all
}

// Rows are the claims of design/conformance.md's platform-controls table,
// by suite: every one has a case whose Row names it (suite_test.go).
var Rows = map[string][]string{
	SuiteGatewayPath: {
		"Each route admits only its own tokens",
		"CEL admits only the route's roles",
		"A provider's model name gets model_not_found",
		"A hidden tool is missing from tools/list",
		"A hidden tool is refused on tools/call",
		"The realm admits no anonymous client registration",
		"On the model route, a path that is not an LLM API path is refused",
		"Attribution comes from the token",
		"the usage record's cost matches the price catalog",
		"The upstream never receives the caller's token",
		"A limit answers 429 with Retry-After past its threshold while another team carries on",
	},
	SuiteBypass: {
		"Direct ingress to a backend from another meshed namespace (AuthorizationPolicy)",
		"Direct ingress to a backend from outside the mesh (STRICT mTLS)",
		"Direct ingress to a backend from where only NetworkPolicy stops it",
		"Direct egress from a workload to a model provider (NetworkPolicy)",
		"Direct egress from a workload to a tool's upstream (NetworkPolicy)",
		"route-claims", "backend-targets", "gateway-policy-floor", "mesh-floor", "platform-crds",
		"A workload release that writes a platform namespace into Helm's ownership annotation, installed through Helm",
		"In AWS, Bedrock for any role but the gateway's (IAM and the SCP)",
	},
	SuiteDelegation: {
		"A chain token works on its own route and gets 401 on any other",
		"A chain token gets 401 on the developer deployment",
		"A person's token gets 401 on the hosted-workloads deployment",
		"an agent that forwards its caller's token fails",
		"A route admits only the outermost actors its access file names",
		"End to end, a person calls an agent through the developer deployment",
	},
	// The telemetry group's claims, as design/conformance.md's telemetry
	// group states them.
	SuiteTelemetry: {
		"The Dynatrace stand-in holds every span of the trace, the gateway's among them, and span metrics, and neither the marker nor either secret",
		"The SIEM stand-in, the audit bucket and the usage table hold the gateway's record of the request, found by the trace ID, and neither the marker nor either secret",
		"Langfuse holds the marker in the tool span's output and the chat span's input, each secret replaced by the mask, and neither secret",
		"A trace without a GenAI span reaches the Dynatrace stand-in but not Langfuse",
		"A plaintext export to the collector's general ports, PERMISSIVE from build phase B4, from a governed namespace outside the mesh is refused by NetworkPolicy",
		"Calls to the collector's platform port from the suites' probe pods are refused by NetworkPolicy",
		"where a probe is let through it, by the collector's sidecar",
		"A record a workload sends to a general port, forged as the gateway's, lands stamped workload and never in the usage table",
		"A model call's error that quotes the prompt reaches Dynatrace with its type and status code, and neither the marker nor either secret",
		"A model call's error that quotes a secret reaches Langfuse with the secret masked and the rest of its text kept",
	},
	// From B4 (plan/local-build.md, "B4 in detail", The checks): the
	// checks of kagent's controls that need no running actor.
	SuiteKagent: {
		"K2: a Substrate actor token, typed JWT, is refused on every listener but Substrate's",
		"K2: on the hosted-workloads deployment, a kagent agent's route admits only chain tokens for itself",
		"K6: sandbox-privileges",
		"K7: Substrate's listener on the hosted-workloads deployment is refused by NetworkPolicy",
		"kagent-floor",
	},
}
