package platform

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// Config parameterises a run: where the gateways, fixtures and probes
// answer, which issuers and routes the environment has, who signs in, and
// what the optional cases need. It is JSON, so the conformance release can
// render it from its values; config/ holds the local cluster's.
type Config struct {
	PlatformDomain string `json:"platform_domain"` // audiences are https://<gateway>.<platform_domain>/<route>
	Cluster        string `json:"cluster"`         // the <cluster> of canonical actor names
	CAFile         string `json:"ca_file"`         // the platform's CA bundle, for its hostnames
	Strict         bool   `json:"strict"`          // a skipped case fails the run
	Slow           bool   `json:"slow"`            // run cases that wait for minutes

	// Gateways maps each deployment to the base URL the runner reaches it
	// at; default https://<name>.<platform_domain>.
	Gateways map[string]string `json:"gateways"`
	Issuers  struct {
		Keycloak string `json:"keycloak"` // default https://keycloak.<domain>/realms/agentic
		STS      string `json:"sts"`      // default https://delegation-sts.<domain>
	} `json:"issuers"`
	// KeycloakJWKS is the realm's key set; the HS256 case signs with its
	// public key. Default <keycloak issuer>/protocol/openid-connect/certs.
	KeycloakJWKS string `json:"keycloak_jwks"`

	// Routes are the routes of B2 (plan/local-build.md, "B2's routes"), as
	// <gateway>/<route>, with what each admits.
	Routes map[string]Route `json:"routes"`
	// TokenRoutes are the routes the token cases run on.
	TokenRoutes []string `json:"token_routes"`

	Models struct {
		// Aliases maps each approved alias to the model the fake model
		// server must receive (access/models.yaml, the fake column).
		Aliases map[string]string `json:"aliases"`
		// Refused are model names a client may not ask for: providers'
		// names, which only the aliases may reach.
		Refused []string `json:"refused"`
		// NotLLM are paths under the model route that are no LLM API path.
		NotLLM []string `json:"not_llm_paths"`
		// AnthropicVersion is sent on Messages requests, as clients do.
		AnthropicVersion string `json:"anthropic_version"`
	} `json:"models"`

	SignIn struct {
		Okta     string `json:"okta"`      // the Okta org's URL
		ClientID string `json:"client_id"` // default agentctl
		// PersonasFile is the personas' logins, passwords and TOTP
		// secrets: a JSON object keyed by login, as stacks/okta-local's
		// personas file, mounted from platform/conformance/personas.
		PersonasFile string `json:"personas_file"`
		// Scopes are more client scopes the personas sign in with, beside
		// every route's and kagent.scope, since a refresh may only narrow
		// (T20): the integration stage adds its workloads' routes' here.
		Scopes []string `json:"scopes"`
	} `json:"sign_in"`
	// Personas maps each role the cases play to a persona's name (its login
	// is agentic.<name>@…) or login.
	Personas map[string]string `json:"personas"`

	FakeModel struct {
		Ops string `json:"ops"` // the operations port: records
		// Direct is the model port, for the bypass suite's egress case.
		Direct string `json:"direct"`
	} `json:"fake_model"`
	CaptureMCP struct {
		Ops    string `json:"ops"`    // the operations port: records
		Direct string `json:"direct"` // the MCP endpoint itself, bypassing the gateway
		// SidecarPort is a URL on capture-mcp's pod at a port its sidecar
		// does not intercept (15021), reached through a headless Service, so
		// only NetworkPolicy can stop it.
		SidecarPort string `json:"sidecar_port"`
	} `json:"capture_mcp"`
	// MCPClient is the realm's pre-registered MCP client (design/identity.md,
	// "The realm": claude-code) and its loopback redirect: the
	// anonymous-registration case's twin signs in as it.
	MCPClient struct {
		ClientID    string `json:"client_id"`    // default claude-code
		RedirectURI string `json:"redirect_uri"` // default http://localhost:33418/callback
	} `json:"mcp_client"`
	// STSToken is the STS's token endpoint, which the fixture agents call.
	STSToken string `json:"sts_token_endpoint"`

	// Probes are where the bypass suite's requests start besides the
	// runner: meshed (conformance-probe) and nomesh (conformance-nomesh).
	Probes map[string]Probe `json:"probes"`
	// RunnerMeshed says whether the runner's own pod has a sidecar.
	RunnerMeshed bool `json:"runner_meshed"`

	Bypass struct {
		// Providers and ToolUpstreams are outside addresses a workload must
		// not reach directly (NetworkPolicy), which the runner itself may.
		Providers     []string `json:"providers"`
		ToolUpstreams []string `json:"tool_upstreams"`
	} `json:"bypass"`

	Admission struct {
		Enabled   bool   `json:"enabled"`   // the runner may dry-run objects
		Namespace string `json:"namespace"` // a team-owned namespace; default conformance
		Workload  string `json:"workload"`  // the workload whose objects the cases write; default capture-mcp
		// WorkloadLabel is the label naming a route's workload.
		WorkloadLabel string `json:"workload_label"`
		// SecondWorkload is another workload Namespace hosts (the
		// namespace's workloads.agentic-platform/<workload> label);
		// default relay-agent.
		SecondWorkload string `json:"second_workload"`
		// ForeignWorkload is a workload Namespace does not host, which
		// ForeignNamespace does; defaults kagent-reader and its name.
		ForeignWorkload  string `json:"foreign_workload"`
		ForeignNamespace string `json:"foreign_namespace"`
		// PlatformSecretsRole is the role the platform's SecretStores
		// assume, which a workload's own store must not; default the
		// local build's.
		PlatformSecretsRole string `json:"platform_secrets_role"`
		// Impersonate is the user the dry runs act as, such as the deploy
		// job; "" for the runner's own account.
		Impersonate string `json:"impersonate"`
		Server      string `json:"server"` // default: the pod's API server
		TokenFile   string `json:"token_file"`
		CAFile      string `json:"ca_file"`
		// Helm is a helm binary, for the case that installs a chart; empty
		// skips it.
		Helm []string `json:"helm"`
		// EgressGatewayNamespace is where MCP servers' egress goes.
		EgressGatewayNamespace string `json:"egress_gateway_namespace"`
		// ImageNamespace is the workload namespace image-verification's
		// cases dry-run their Pods in; default Namespace.
		ImageNamespace string `json:"image_namespace"`
		// Images are the references image-verification's cases dry-run
		// Pods with (B6, D36), one per state of an image, from the
		// environment's own releases: a case whose image is not set
		// skips. Admitted is the allowed twin of every case: signed and
		// attested with the release key and conformance-attested with
		// the conformance key at the required level.
		Images AdmissionImages `json:"images"`
	} `json:"admission"`

	// Kagent is the kagent group's (B4): a fixture kagent agent and
	// Substrate. The agent's routes are a2a/<agent> on both deployments,
	// and its namespace and atespace are its name (D18).
	Kagent struct {
		Agent string `json:"agent"` // default kagent-reader
		// Scope is the client scope of the agent's developer route;
		// default a2a/<agent>.
		Scope string `json:"scope"`
		// Issuer is Substrate's, which signs actor tokens; default
		// https://idp.ate-system.svc.
		Issuer string `json:"issuer"`
		// Listener is the hosted-workloads deployment's listener for
		// Substrate's egress: its name, the last part of its one audience
		// (default substrate), and its port (default 8443).
		Listener     string `json:"listener"`
		ListenerPort int    `json:"listener_port"`
		// Namespace is Substrate's, where atelet runs (default ate-system),
		// and AteletSelector picks atelet's pods (default app=atelet).
		Namespace      string `json:"namespace"`
		AteletSelector string `json:"atelet_selector"`
		// WorkerLabel names a worker's pool on its pods (default
		// ate.dev/worker-pool), and SandboxNode is the sandbox pool's node
		// label, key=value (default agentic-platform/pool=sandbox).
		WorkerLabel string `json:"worker_label"`
		SandboxNode string `json:"sandbox_node"`
	} `json:"kagent"`

	// TestIssuer is a signer the gateway trusts on TestIssuer.Routes, whose
	// key the suite holds, for the token cases neither Keycloak nor the STS
	// can produce (a wrong typ, nbf ahead). No such issuer exists in the
	// design yet; without one those cases are skipped.
	TestIssuer struct {
		Issuer  string   `json:"issuer"`
		KeyFile string   `json:"key_file"` // PEM private key, ES256 or RS256
		Kid     string   `json:"kid"`
		Routes  []string `json:"routes"`
		// Team is the team its tokens claim: a team of its own, whose
		// budget no case drains, never the limited persona's (default
		// conformance-issuer).
		Team string `json:"team"`
	} `json:"test_issuer"`

	// UsageTable is where the usage records land: the usage table's
	// ClickHouse, read over its HTTP interface as a user that may select
	// from the table and nothing else (design/observability.md, "Audit and
	// usage records"). Unset skips the cases that read it.
	UsageTable struct {
		URL          string `json:"url"`           // ClickHouse's HTTP interface
		Database     string `json:"database"`      // default platform_usage
		Table        string `json:"table"`         // default llm_requests
		User         string `json:"user"`          // default usage_reader
		PasswordFile string `json:"password_file"` // the user's password, mounted from a Secret
		// Wait bounds how long a record may take to reach the table after
		// its request: the gateway's export, the collector's batch and
		// queue, and the insert; default 60s, the plan's minute.
		Wait Duration `json:"wait"`
	} `json:"usage_table"`
	// Telemetry is where the telemetry cases send their synthetic traces
	// and where they read what reached the collector's destinations
	// (plan/local-build.md, "B3 in detail", The checks).
	Telemetry struct {
		// OTLP is a general port of the collector for OTLP over HTTP, where
		// the runner sends its traces, as any workload would.
		OTLP string `json:"otlp"`
		// PlatformPort is the collector's platform port, OTLP over gRPC,
		// which only the platform's emitters may reach (threat TM15).
		PlatformPort string `json:"platform_port"`
		ServiceName  string `json:"service_name"` // the traces' service.name; default conformance-runner
		// Mask is what the collector's redaction processor writes in place
		// of a secret; default ****.
		Mask string `json:"mask"`
		// Sinks are the Dynatrace and SIEM stand-ins: each one's container,
		// also its sink's name in the store. From B5 they are read from the
		// store they keep their records in, at RecordsURL; without one,
		// through their pod's log, by namespace and selector (where the
		// destinations are real, as in dev, the cases that read them are
		// left out).
		Sinks struct {
			Namespace string `json:"namespace"`
			Selector  string `json:"selector"`
			Dynatrace string `json:"dynatrace"`
			SIEM      string `json:"siem"`
			// RecordsURL is the stand-ins' records store (environments'
			// charts/telemetry-sink, records.py): GET <url>/<sink>?since=
			// <Unix seconds> streams what reached the sink, its rotated
			// files included, one OTLP export request a line.
			RecordsURL string `json:"records_url"`
		} `json:"sinks"`
		// Waits are the collector's own and what follows them, from which
		// each case bounds how long it polls for telemetry to arrive.
		Waits struct {
			// Decision is the sampling tier's tail-sampling decision_wait
			// (TAIL_SAMPLING_DECISION_WAIT); default 10s, the local value.
			Decision Duration `json:"decision"`
			// MetricsFlush is the span-metrics connector's flush interval;
			// default 60s, its default.
			MetricsFlush Duration `json:"metrics_flush"`
			// Delivery is everything else between a sender and a store: the
			// senders' and the tiers' batches, queues and exports; default
			// 30s.
			Delivery Duration `json:"delivery"`
			// Langfuse is Langfuse's own time from receipt to its API: its
			// ingestion queue and worker; default 60s.
			Langfuse Duration `json:"langfuse"`
		} `json:"waits"`
	} `json:"telemetry"`
	// Langfuse is read through its public API with a project's keys, and
	// its event blobs in their bucket.
	Langfuse struct {
		URL           string `json:"url"` // its web's base URL
		PublicKeyFile string `json:"public_key_file"`
		SecretKeyFile string `json:"secret_key_file"`
		// Project is the project's ID, the path of its blobs; default
		// conformance.
		Project      string `json:"project"`
		EventsBucket string `json:"events_bucket"`
		EventsPrefix string `json:"events_prefix"` // LANGFUSE_S3_EVENT_UPLOAD_PREFIX
	} `json:"langfuse"`
	// Audit is the audit bucket as the collector's S3 exporter writes it:
	// its s3_prefix and s3_partition_format.
	Audit struct {
		Bucket    string `json:"bucket"`
		Prefix    string `json:"prefix"`    // default records
		Partition string `json:"partition"` // default year=%Y/month=%m/day=%d/hour=%H/minute=%M
	} `json:"audit"`
	// S3 is where both buckets are, read with the credentials in the
	// runner's AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY.
	S3 struct {
		Endpoint  string `json:"endpoint"`
		Region    string `json:"region"`     // default us-east-1
		PathStyle bool   `json:"path_style"` // the bucket in the path, as floci needs
	} `json:"s3"`
	// Prices are dollars per million tokens of the price overlay.
	Prices struct {
		Input  float64 `json:"input"`
		Output float64 `json:"output"`
	} `json:"prices"`

	Limits struct {
		// Tokens is the limited persona's team's token budget for one
		// window of the rate-limit service (access/teams.yaml, and the
		// environment's own window): small enough to cross in a few
		// requests.
		Tokens int `json:"tokens"`
		// MaxRequests bounds the requests the limit case sends.
		MaxRequests int `json:"max_requests"`
		// MaxWait is the longest the limit case waits for the team's
		// window to reset when it finds it already crossed, as by an
		// earlier run; an environment that runs the suites back to back
		// gives the team a window shorter than this. Default 90s.
		MaxWait Duration `json:"max_wait"`
	} `json:"limits"`

	// AWS runs the bypass suite's Bedrock case with commands, one per
	// principal, that call Bedrock and exit 0 when it answers.
	AWS struct {
		Allowed []string            `json:"allowed"` // as the gateway's role
		Refused map[string][]string `json:"refused"` // principal -> command
	} `json:"aws"`

	Timing struct {
		Connect            Duration `json:"connect"`              // a TCP connection; default 5s
		Request            Duration `json:"request"`              // a whole request; default 30s
		MeshConnectTimeout Duration `json:"mesh_connect_timeout"` // a sidecar's upstream connect timeout; default 10s
		TokenLeeway        Duration `json:"token_leeway"`         // the verifier profile's clock leeway; default 60s
	} `json:"timing"`

	dir string
}

// AdmissionImages are image-verification's fixtures, each an image
// reference under registry.host by digest unless said otherwise.
type AdmissionImages struct {
	Admitted string `json:"admitted"`  // signed, attested and conformance-attested: every case's twin
	Unsigned string `json:"unsigned"`  // no signature at all
	OtherKey string `json:"other_key"` // signed and attested with a key that is not the release key
	// SignedOnly carries the release key's signature and nothing else:
	// no SBOM, provenance or conformance attestation.
	SignedOnly string `json:"signed_only"`
	// NoConformance is a release signed and attested with the release
	// key, never conformance-attested.
	NoConformance string `json:"no_conformance"`
	// ConformanceByRelease is a release whose conformance attestation
	// the release key signed, as a workload's own pipeline could (TM13).
	ConformanceByRelease string `json:"conformance_by_release"`
	// BelowLevel is conformance-attested at a level below the one it
	// requires.
	BelowLevel string `json:"below_level"`
	// OldSuite is conformance-attested by suites older than the
	// environment's minimum.
	OldSuite string `json:"old_suite"`
	// ByTag is under registry.host by tag; default Admitted's
	// repository with the tag latest.
	ByTag string `json:"by_tag"`
	// Outside is outside registry.host and not one the environment pins;
	// default busybox 1.37.0 by digest.
	Outside string `json:"outside"`
}

// Route is what a route admits.
type Route struct {
	Kind   string   `json:"kind"`             // model, mcp or a2a
	Scope  string   `json:"scope,omitempty"`  // the client scope that gives its audience, on the developer deployment
	Roles  []string `json:"roles,omitempty"`  // the roles its CEL admits, on the developer deployment
	Actors []string `json:"actors,omitempty"` // the outermost actors its access file names, on the hosted-workloads deployment
}

// Probe is a pod that makes requests for the runner.
type Probe struct {
	URL    string `json:"url"`
	Meshed bool   `json:"meshed"`
}

// Duration reads Go duration strings such as 10s.
type Duration struct{ time.Duration }

// UnmarshalJSON implements json.Unmarshaler.
func (d *Duration) UnmarshalJSON(b []byte) error {
	var s string
	if err := json.Unmarshal(b, &s); err != nil {
		return fmt.Errorf("a duration is a string such as \"10s\": %v", err)
	}
	v, err := time.ParseDuration(s)
	d.Duration = v
	return err
}

// MarshalJSON implements json.Marshaler.
func (d Duration) MarshalJSON() ([]byte, error) { return json.Marshal(d.String()) }

// LoadConfig reads a configuration file. Unknown fields are errors, so a
// typo never silently drops a setting.
func LoadConfig(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c Config
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&c); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	c.dir = filepath.Dir(path)
	if err := c.Complete(); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	return &c, nil
}

// Complete fills defaults and checks the required fields.
func (c *Config) Complete() error {
	if c.PlatformDomain == "" || c.Cluster == "" {
		return fmt.Errorf("platform_domain and cluster are required")
	}
	if c.Gateways == nil {
		c.Gateways = map[string]string{}
	}
	for _, g := range []string{"gateway", "workloads-gateway"} {
		if c.Gateways[g] == "" {
			c.Gateways[g] = "https://" + g + "." + c.PlatformDomain
		}
		c.Gateways[g] = strings.TrimRight(c.Gateways[g], "/")
	}
	def(&c.Issuers.Keycloak, "https://keycloak."+c.PlatformDomain+"/realms/agentic")
	def(&c.Issuers.STS, "https://delegation-sts."+c.PlatformDomain)
	def(&c.KeycloakJWKS, strings.TrimRight(c.Issuers.Keycloak, "/")+"/protocol/openid-connect/certs")
	def(&c.STSToken, c.Issuers.STS+":8443/token")
	def(&c.SignIn.ClientID, "agentctl")
	def(&c.MCPClient.ClientID, "claude-code")
	def(&c.MCPClient.RedirectURI, "http://localhost:33418/callback")
	def(&c.Models.AnthropicVersion, "2023-06-01")
	if len(c.TokenRoutes) == 0 {
		c.TokenRoutes = []string{"gateway/v1", "gateway/mcp/capture-mcp"}
	}
	for _, r := range c.TokenRoutes {
		if _, ok := c.Routes[r]; !ok {
			return fmt.Errorf("token_routes names %s, which routes does not", r)
		}
	}
	for name, r := range c.Routes {
		if gw, _, ok := strings.Cut(name, "/"); !ok || c.Gateways[gw] == "" {
			return fmt.Errorf("route %s: want <gateway>/<route> on gateway or workloads-gateway", name)
		}
		switch r.Kind {
		case "model", "mcp", "a2a":
		default:
			return fmt.Errorf("route %s: kind %q: want model, mcp or a2a", name, r.Kind)
		}
	}
	if c.Personas == nil {
		c.Personas = map[string]string{}
	}
	for role, name := range map[string]string{
		RoleDeveloper: "developer", RoleIncidentManager: "incident-manager", RolePlatformEngineer: "platform-engineer",
		RoleOtherTeam: "developer-other-team", RoleLimited: "spare-1", RoleNoTeam: "spare-2",
	} {
		def2(c.Personas, role, name)
	}
	def(&c.Admission.Namespace, "conformance")
	def(&c.Admission.Workload, "capture-mcp")
	def(&c.Admission.WorkloadLabel, "platform.example.com/workload")
	def(&c.Admission.SecondWorkload, "relay-agent")
	def(&c.Admission.ForeignWorkload, "kagent-reader")
	def(&c.Admission.ForeignNamespace, c.Admission.ForeignWorkload)
	def(&c.Admission.PlatformSecretsRole, "arn:aws:iam::000000000000:role/platform-external-secrets")
	def(&c.Admission.EgressGatewayNamespace, "istio-egress")
	def(&c.Admission.ImageNamespace, c.Admission.Namespace)
	if img := c.Admission.Images.Admitted; c.Admission.Images.ByTag == "" && strings.Contains(img, "@sha256:") {
		c.Admission.Images.ByTag = img[:strings.Index(img, "@")] + ":latest"
	}
	def(&c.Admission.Images.Outside, "docker.io/library/busybox@sha256:a7dbc319b1438115a207e11930dc4bb3e643dcb3ec0bdd694bb36cd8fad289ec")
	if c.Prices.Input == 0 && c.Prices.Output == 0 {
		c.Prices.Input, c.Prices.Output = 3, 15
	}
	if c.Limits.Tokens == 0 {
		c.Limits.Tokens = 6000
	}
	defDur(&c.Limits.MaxWait, 90*time.Second)
	def(&c.Kagent.Agent, "kagent-reader")
	def(&c.Kagent.Scope, "a2a/"+c.Kagent.Agent)
	def(&c.Kagent.Issuer, "https://idp.ate-system.svc")
	def(&c.Kagent.Listener, "substrate")
	if c.Kagent.ListenerPort == 0 {
		c.Kagent.ListenerPort = 8443
	}
	def(&c.Kagent.Namespace, "ate-system")
	def(&c.Kagent.AteletSelector, "app=atelet")
	def(&c.Kagent.WorkerLabel, "ate.dev/worker-pool")
	def(&c.Kagent.SandboxNode, "agentic-platform/pool=sandbox")
	if !strings.Contains(c.Kagent.SandboxNode, "=") {
		return fmt.Errorf("kagent.sandbox_node: want key=value, got %q", c.Kagent.SandboxNode)
	}
	def(&c.TestIssuer.Team, "conformance-issuer")
	def(&c.UsageTable.Database, "platform_usage")
	def(&c.UsageTable.Table, "llm_requests")
	def(&c.UsageTable.User, "usage_reader")
	defDur(&c.UsageTable.Wait, 60*time.Second)
	c.UsageTable.URL = strings.TrimRight(c.UsageTable.URL, "/")
	def(&c.Telemetry.ServiceName, "conformance-runner")
	def(&c.Telemetry.Mask, "****")
	defDur(&c.Telemetry.Waits.Decision, 10*time.Second)
	defDur(&c.Telemetry.Waits.MetricsFlush, 60*time.Second)
	defDur(&c.Telemetry.Waits.Delivery, 30*time.Second)
	defDur(&c.Telemetry.Waits.Langfuse, 60*time.Second)
	c.Telemetry.OTLP = strings.TrimRight(c.Telemetry.OTLP, "/")
	c.Telemetry.PlatformPort = strings.TrimRight(c.Telemetry.PlatformPort, "/")
	c.Telemetry.Sinks.RecordsURL = strings.TrimRight(c.Telemetry.Sinks.RecordsURL, "/")
	c.Langfuse.URL = strings.TrimRight(c.Langfuse.URL, "/")
	def(&c.Langfuse.Project, "conformance")
	def(&c.Audit.Prefix, "records")
	def(&c.Audit.Partition, "year=%Y/month=%m/day=%d/hour=%H/minute=%M")
	def(&c.S3.Region, "us-east-1")
	if c.Limits.MaxRequests == 0 {
		c.Limits.MaxRequests = 12
	}
	defDur(&c.Timing.Connect, 5*time.Second)
	defDur(&c.Timing.Request, 30*time.Second)
	defDur(&c.Timing.MeshConnectTimeout, 10*time.Second)
	defDur(&c.Timing.TokenLeeway, 60*time.Second)
	return nil
}

// Path resolves a path from the configuration file's directory.
func (c *Config) Path(p string) string {
	if p == "" || filepath.IsAbs(p) || c.dir == "" {
		return p
	}
	return filepath.Join(c.dir, p)
}

// RouteURL is a route's audience and URL: https://<gateway>.<domain>/<route>.
func (c *Config) RouteURL(route string) string {
	gw, path, _ := strings.Cut(route, "/")
	return "https://" + gw + "." + c.PlatformDomain + "/" + path
}

// CallURL is where the runner calls a route: the gateway's base URL, which
// is the audience's host locally, plus the route's path.
func (c *Config) CallURL(route string) string {
	gw, path, _ := strings.Cut(route, "/")
	return c.Gateways[gw] + "/" + path
}

// Actor is an agent's canonical name: <cluster>/<namespace>/<service account>.
func (c *Config) Actor(namespace, sa string) string { return c.Cluster + "/" + namespace + "/" + sa }

func def(s *string, v string) {
	if *s == "" {
		*s = v
	}
}

func def2(m map[string]string, k, v string) {
	if m[k] == "" {
		m[k] = v
	}
}

func defDur(d *Duration, v time.Duration) {
	if d.Duration == 0 {
		d.Duration = v
	}
}
