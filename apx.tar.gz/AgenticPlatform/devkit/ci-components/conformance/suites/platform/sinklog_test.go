package platform

import (
	"context"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// scriptedLogs answers each read with the next of reads, then the last.
type scriptedLogs struct {
	reads [][]kube.LogLine
	n     int
}

func (s *scriptedLogs) Lines(context.Context, string, string, string, time.Time) ([]kube.LogLine, error) {
	r := s.reads[min(s.n, len(s.reads)-1)]
	s.n++
	return r, nil
}

// TestSinkLinesAcrossRotation: a line read once is kept after the
// kubelet rotates it away, a line is kept once however often it is read,
// identical texts printed at different times are both kept, and a
// rotation between reads is named with the span it hid.
func TestSinkLinesAcrossRotation(t *testing.T) {
	t0 := time.Date(2026, 11, 17, 20, 6, 32, 0, time.UTC)
	line := func(s int, text string) kube.LogLine {
		return kube.LogLine{Pod: "telemetry-sink-0", Time: t0.Add(time.Duration(s) * time.Second), Text: text}
	}
	a, b, b2, c, d := line(0, "a"), line(1, "b"), line(2, "b"), line(30, "c"), line(31, "d")
	logs := &scriptedLogs{reads: [][]kube.LogLine{{a, b}, {a, b, b2}, {c, d}, {c, d}}}
	e := &Env{Cfg: &Config{}, Logs: logs}
	cc := &runner.C[*Env]{Context: context.Background(), Env: e}
	since := t0.Add(-time.Second)
	want := [][]string{{"a", "b"}, {"a", "b", "b"}, {"a", "b", "b", "c", "d"}, {"a", "b", "b", "c", "d"}}
	for i, w := range want {
		got, err := e.sinkLines(cc, "dynatrace", since)
		if err != nil || strings.Join(got, ",") != strings.Join(w, ",") {
			t.Fatalf("read %d: got %v %v, want %v", i+1, got, err, w)
		}
		gaps := e.sinkGaps("dynatrace", since)
		switch {
		case i < 2 && gaps != "":
			t.Errorf("read %d: no rotation yet, but %q", i+1, gaps)
		case i >= 2 && (strings.Count(gaps, "rotated between reads") != 1 || !strings.Contains(gaps, "to 20:07:02.000")):
			t.Errorf("read %d: want one rotation named, up to the new file's first line, got %q", i+1, gaps)
		}
	}
	if g := e.sinkGaps("siem", since); g != "" {
		t.Errorf("another container's reads: %q", g)
	}
}
