package platform

import (
	"crypto"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// The gateway-path suite (design/conformance.md, "The platform-controls
// suites"): each route admits only its own tokens; CEL admits only the
// route's roles, the approved aliases and the visible tools; the model route
// refuses paths that are not LLM API paths; attribution comes from the
// token; the upstream never receives the caller's token; a limit answers
// 429 past its threshold while another team carries on.
const SuiteGatewayPath = "gateway-path"

// tokenCase is one way a token can be wrong. Each breaks exactly one
// property of a token the route would otherwise accept, sorted by who can
// sign it: forgeable without any trusted key, obtainable from the real
// issuers, or needing a signer the gateway trusts (the test issuer).
type tokenCase struct {
	name  string
	title string
	// status is the refusal due: 401 from the route's JWT policy, unless
	// set; 403 for what the token-profile rules hold, a typ other than
	// at+jwt, an alg other than RS256 or ES256 and more than one audience,
	// since those rules run first and CEL authorization answers 403
	// (design/gateway.md, "Routes and issuers"; spike T22).
	status int
	needs  []runner.Need
	// make returns the token to present on route; "" sends none.
	make func(c *C, route string) string
	// twin returns the allowed twin's token; default the route's own.
	twin func(c *C, route string) string
}

func tokenCases() []tokenCase {
	own := func(c *C, route string) string { return token(c, RoleDeveloper, route) }
	return []tokenCase{
		{name: "missing", title: "no token gets 401", make: func(*C, string) string { return "" }},
		{name: "other-audience", title: "a Keycloak token for another route gets 401", make: func(c *C, route string) string {
			other := c.Env.otherRoute(route)
			if other == "" {
				c.Fatalf("routes describe no other developer-deployment route with a scope, so no token for another audience")
			}
			return token(c, RoleDeveloper, other)
		}},
		{name: "two-audiences", title: "a Keycloak token for two routes, this one among them, gets 403 from the route's one-audience rule", status: http.StatusForbidden, make: func(c *C, route string) string {
			t, err := c.Env.Tokens.Wide(c, RoleDeveloper)
			if err != nil {
				c.Fatalf("the sign-in's token: %v", err)
			}
			aud := audiences(claims(c, t))
			if len(aud) < 2 || !contains(aud, c.Env.Cfg.RouteURL(route)) {
				c.Fatalf("the sign-in's own token should carry every route scope asked for, this route's among them; its aud is %v", aud)
			}
			return t
		}},
		{name: "other-issuer", title: "a token from an issuer the route does not trust, with the route's claims, gets 401", make: func(c *C, route string) string {
			cl := claims(c, own(c, route))
			cl["iss"] = "https://untrusted.conformance.invalid"
			t, err := jose.Sign(map[string]any{"alg": "ES256", "typ": "at+jwt", "kid": "conformance-untrusted"}, cl, c.Env.Untrusted)
			if err != nil {
				c.Fatalf("%v", err)
			}
			return t
		}},
		{name: "bad-signature", title: "the route's own token with a claim changed under its signature gets 401", make: func(c *C, route string) string {
			raw := own(c, route)
			cl := claims(c, raw)
			cl["roles"] = []string{"platform-engineer", "developer", "incident-manager"}
			t, err := jose.ReplaceClaims(raw, cl)
			if err != nil {
				c.Fatalf("%v", err)
			}
			return t
		}},
		{name: "alg-none", title: "the route's own claims under alg none, unsigned, get 403 from the token-profile rule", status: http.StatusForbidden, make: func(c *C, route string) string {
			t, err := jose.Parse(own(c, route))
			if err != nil {
				c.Fatalf("%v", err)
			}
			h := map[string]any{}
			for k, v := range t.Header {
				h[k] = v
			}
			h["alg"] = "none"
			out, err := jose.Sign(h, t.Claims, nil)
			if err != nil {
				c.Fatalf("%v", err)
			}
			return out
		}},
		{name: "hs256-public-key", title: "the route's own claims signed HS256 with the issuer's public key get 403 from the token-profile rule", status: http.StatusForbidden, make: func(c *C, route string) string {
			t, err := jose.Parse(own(c, route))
			if err != nil {
				c.Fatalf("%v", err)
			}
			pub := c.Env.issuerKey(c, t.HeaderString("kid"))
			secret, err := jose.PublicPEM(pub)
			if err != nil {
				c.Fatalf("%v", err)
			}
			h := map[string]any{}
			for k, v := range t.Header {
				h[k] = v
			}
			h["alg"] = "HS256"
			out, err := jose.Sign(h, t.Claims, secret)
			if err != nil {
				c.Fatalf("%v", err)
			}
			return out
		}},
		{name: "unknown-kid", title: "the route's own claims signed by a key the issuer never published get 401", make: func(c *C, route string) string {
			t, err := jose.Parse(own(c, route))
			if err != nil {
				c.Fatalf("%v", err)
			}
			h := map[string]any{"alg": "ES256", "typ": t.HeaderString("typ"), "kid": "conformance-" + jose.RandomID(6)}
			out, err := jose.Sign(h, t.Claims, c.Env.Untrusted)
			if err != nil {
				c.Fatalf("%v", err)
			}
			return out
		}},
		{name: "expired-held", title: "the route's own token, held until past its exp and the 60-second leeway, gets 401", needs: []runner.Need{NeedSlow}, make: func(c *C, route string) string {
			raw := own(c, route)
			exp, ok := claimInt(claims(c, raw), "exp")
			if !ok {
				c.Fatalf("the token has no exp")
			}
			wait := time.Until(time.Unix(exp, 0)) + c.Env.Cfg.Timing.TokenLeeway.Duration + 15*time.Second
			c.Logf("holding the token for %s, until past its exp and the leeway", wait.Round(time.Second))
			c.Sleep(wait)
			return raw
		}},
		{name: "expired", title: "a trusted token whose exp passed 120 seconds ago gets 401 (T22's clock leeway)", needs: []runner.Need{NeedTestIssuer},
			make: testToken(func(h, cl map[string]any, now time.Time) { cl["exp"] = now.Add(-120 * time.Second).Unix() }), twin: testToken(nil)},
		{name: "typ-jwt", title: "a trusted token typed JWT rather than at+jwt gets 403 from the token-profile rule (T22)", status: http.StatusForbidden, needs: []runner.Need{NeedTestIssuer},
			make: testToken(func(h, cl map[string]any, _ time.Time) { h["typ"] = "JWT" }), twin: testToken(nil)},
		{name: "nbf-120s-ahead", title: "a trusted token with nbf 120 seconds ahead gets 401; its twin has nbf 30 seconds ahead (T22's clock leeway)", needs: []runner.Need{NeedTestIssuer},
			make: testToken(func(h, cl map[string]any, now time.Time) { cl["nbf"] = now.Add(120 * time.Second).Unix() }),
			twin: testToken(func(h, cl map[string]any, now time.Time) { cl["nbf"] = now.Add(30 * time.Second).Unix() })},
	}
}

// testToken mints a token from the trusted test issuer that the route
// accepts in every way, then lets mutate break one property.
func testToken(mutate func(header, claims map[string]any, now time.Time)) func(c *C, route string) string {
	return func(c *C, route string) string {
		e := c.Env
		if !contains(e.Cfg.TestIssuer.Routes, route) {
			c.Fatalf("test_issuer.routes does not name %s: the gateway trusts the test issuer on those routes only", route)
		}
		now := e.Now()
		alg := "ES256"
		if _, ok := e.TestKey.(*rsa.PrivateKey); ok {
			alg = "RS256"
		}
		h := map[string]any{"alg": alg, "typ": "at+jwt", "kid": e.Cfg.TestIssuer.Kid}
		cl := map[string]any{
			"iss": e.Cfg.TestIssuer.Issuer, "sub": "conformance-test-subject", "aud": e.Cfg.RouteURL(route),
			"client_id": e.Cfg.SignIn.ClientID, "roles": []string{"developer"}, "team": e.Cfg.TestIssuer.Team,
			"iat": now.Unix(), "nbf": now.Unix(), "exp": now.Add(5 * time.Minute).Unix(), "jti": jose.RandomID(16),
		}
		if mutate != nil {
			mutate(h, cl, now)
		}
		t, err := jose.Sign(h, cl, e.TestKey)
		if err != nil {
			c.Fatalf("signing as the test issuer: %v", err)
		}
		return t
	}
}

// issuerKey fetches the Keycloak realm's public key named kid.
func (e *Env) issuerKey(c *C, kid string) crypto.PublicKey {
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: e.Cfg.KeycloakJWKS})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		c.Fatalf("fetching the realm's JWKS at %s: %s", e.Cfg.KeycloakJWKS, o)
	}
	var set jose.JWKS
	if err := json.Unmarshal([]byte(o.Body), &set); err != nil {
		c.Fatalf("the realm's JWKS: %v", err)
	}
	k, ok := set.Key(kid)
	if !ok {
		c.Fatalf("the realm's JWKS has no key %q (it has %v)", kid, set.Kids())
	}
	pub, err := k.Public()
	if err != nil {
		c.Fatalf("%v", err)
	}
	return pub
}

func gatewayPathCases() []Case {
	var out []Case
	for _, route := range defaultTokenRoutes {
		for _, tc := range tokenCases() {
			out = append(out, tokenCaseFor(route, tc))
		}
	}
	out = append(out, authzCases()...)
	out = append(out, modelCases()...)
	out = append(out, mcpCases()...)
	out = append(out, upstreamCases()...)
	out = append(out, Case{
		ID: "gateway-path/attribution/from-token", Suite: SuiteGatewayPath, Row: "Attribution comes from the token, never from a header the caller sets, and the usage record's cost matches the price catalog",
		Title: "a caller's forged x-team, baggage and x-user-id change nothing: the usage table holds one row for the request, with the token's sub and team, the alias and the model it maps to, the fake model server's token counts, and their cost at the price overlay's rates",
		Layer: "", Needs: []runner.Need{NeedSignIn, NeedUsageRecords, NeedFakeModel, NeedRoute("gateway/v1")}, Cluster: true, Run: attributionCase,
	}, Case{
		ID: "gateway-path/limits/team-tokens", Suite: SuiteGatewayPath, Row: "A limit answers 429 with Retry-After past its threshold while another team carries on",
		Title: "the conformance team past its hourly token limit gets 429 with Retry-After; the crossing request succeeded; another team carries on (T4)",
		Layer: string(outcome.Gateway), Needs: []runner.Need{NeedPersona(RoleLimited), NeedPersona(RoleOtherTeam), NeedRoute("gateway/v1")}, Cluster: false, Run: limitCase,
	})
	return out
}

// defaultTokenRoutes are the routes the token cases are generated for;
// a run's token_routes may name fewer, and the others skip.
var defaultTokenRoutes = []string{"gateway/v1", "gateway/mcp/capture-mcp"}

func tokenCaseFor(route string, tc tokenCase) Case {
	needs := append([]runner.Need{NeedRoute(route), NeedSignIn}, tc.needs...)
	return Case{
		ID: "gateway-path/token/" + route + "/" + tc.name, Suite: SuiteGatewayPath, Layer: string(outcome.Gateway),
		Row:   "Each route admits only its own tokens: missing, expired, another audience or issuer, a bad signature, an unknown kid and nbf 120 seconds ahead get 401 from the JWT policy; typed other than at+jwt, signed with an alg other than RS256 or ES256 (alg none and HS256 among them) or for two audiences get 403 from the token-profile rules",
		Title: "on " + route + ", " + tc.title + "; the route's own token passes",
		Needs: needs, Cluster: false,
		Run: func(c *C) {
			e := c.Env
			if !contains(e.Cfg.TokenRoutes, route) {
				c.Skipf("token_routes leaves out %s", route)
			}
			bad := tc.make(c, route)
			marker := e.Marker("token")
			o, _ := e.callRoute(c, e.Runner, route, bad, marker)
			status := tc.status
			if status == 0 {
				status = http.StatusUnauthorized
			}
			if expectGateway(c, "refusal", o, e.Runner, status) {
				noUpstreamRecord(c, route, marker)
			}
			twin := tc.twin
			if twin == nil {
				twin = func(c *C, route string) string { return token(c, RoleDeveloper, route) }
			}
			o, ok := e.callRoute(c, e.Runner, route, twin(c, route), e.Marker("twin"))
			expectThrough(c, "the same request with nothing broken", o, ok)
		},
	}
}

func authzCases() []Case {
	return []Case{
		{
			ID: "gateway-path/authz/role-not-admitted", Suite: SuiteGatewayPath, Layer: string(outcome.Gateway), Cluster: false,
			Row:   "CEL admits only the route's roles: another role gets 403",
			Title: "a role the route's CEL does not admit gets 403; a developer passes",
			Needs: []runner.Need{NeedPersona(RoleIncidentManager), NeedPersona(RoleDeveloper)},
			Run: func(c *C) {
				e := c.Env
				var route string
				for _, kind := range []string{"mcp", "model", "a2a"} {
					for _, r := range e.developerRoutes(kind) {
						roles := e.Cfg.Routes[r].Roles
						if contains(roles, RoleDeveloper) && !contains(roles, "incident-manager") && kind != "a2a" {
							route = r
							break
						}
					}
					if route != "" {
						break
					}
				}
				if route == "" {
					c.Fatalf("routes describe no model or MCP route on the developer deployment that admits developer but not incident-manager")
				}
				marker := e.Marker("role")
				o, _ := e.callRoute(c, e.Runner, route, token(c, RoleIncidentManager, route), marker)
				if expectGateway(c, "incident-manager on "+route, o, e.Runner, http.StatusForbidden) {
					noUpstreamRecord(c, route, marker)
				}
				o, ok := e.callRoute(c, e.Runner, route, token(c, RoleDeveloper, route), e.Marker("twin"))
				expectThrough(c, "developer on "+route, o, ok)
			},
		},
		{
			ID: "gateway-path/authz/no-team", Suite: SuiteGatewayPath, Layer: string(outcome.Gateway), Cluster: false,
			Row:   "CEL admits only the route's roles (and a team, which the limits key on)",
			Title: "a token with a role but no team gets 403 on the model route, before any limit's descriptor runs; a developer with a team passes (T4)",
			Needs: []runner.Need{NeedPersona(RoleNoTeam), NeedPersona(RoleDeveloper), NeedRoute("gateway/v1")},
			Run: func(c *C) {
				e := c.Env
				route := "gateway/v1"
				tok := token(c, RoleNoTeam, route)
				cl := claims(c, tok)
				if t, _ := cl["team"].(string); t != "" {
					c.Fatalf("the %s persona's token carries team %q: it must be in no team", e.Cfg.Personas[RoleNoTeam], t)
				}
				if r, _ := cl["roles"].([]any); len(r) == 0 {
					c.Fatalf("the %s persona's token carries no role: give it one, or the case refuses on the role, not the team", e.Cfg.Personas[RoleNoTeam])
				}
				marker := e.Marker("noteam")
				o, _ := e.callRoute(c, e.Runner, route, tok, marker)
				if expectGateway(c, "a token without team", o, e.Runner, http.StatusForbidden) {
					noUpstreamRecord(c, route, marker)
				}
				o, ok := e.callRoute(c, e.Runner, route, token(c, RoleDeveloper, route), e.Marker("twin"))
				expectThrough(c, "a developer with a team", o, ok)
			},
		},
	}
}

func modelCases() []Case {
	route := "gateway/v1"
	needs := []runner.Need{NeedSignIn, NeedRoute(route), NeedFakeModel}
	return []Case{
		{
			ID: "gateway-path/model/aliases", Suite: SuiteGatewayPath, Cluster: true, Needs: needs,
			Row:   "CEL admits only the approved aliases",
			Title: "each approved alias reaches the fake model server as its mapped model, with no credential header",
			Run: func(c *C) {
				e := c.Env
				if len(e.Cfg.Models.Aliases) == 0 {
					c.Fatalf("models.aliases is empty")
				}
				tok := token(c, RoleDeveloper, route)
				for alias, want := range e.Cfg.Models.Aliases {
					marker := e.Marker("alias")
					o := e.callModel(c, e.Runner, route, tok, alias, marker, nil)
					if !expectThrough(c, "alias "+alias, o, o.Kind == outcome.Response && o.Status == http.StatusOK) {
						continue
					}
					recs, err := e.fakeModelRecords(c, marker)
					switch {
					case err != nil:
						c.Errorf("%v", err)
					case len(recs) != 1:
						c.Errorf("alias %s: want one record for %s, got %d", alias, marker, len(recs))
					case recs[0].Model != want:
						c.Errorf("alias %s reached the fake model server as %q, want %q", alias, recs[0].Model, want)
					case len(recs[0].Credentials) != 0:
						c.Errorf("alias %s: the fake model server received credential headers %v: a caller's token reached the model", alias, recs[0].Credentials)
					}
				}
			},
		},
		{
			ID: "gateway-path/model/provider-name", Suite: SuiteGatewayPath, Layer: string(outcome.Gateway), Cluster: true, Needs: needs,
			Row:   "A provider's model name gets model_not_found",
			Title: "a provider's model name, named directly, gets model_not_found and never reaches the provider; an alias passes",
			Run: func(c *C) {
				e := c.Env
				if len(e.Cfg.Models.Refused) == 0 {
					c.Fatalf("models.refused names no provider model")
				}
				tok := token(c, RoleDeveloper, route)
				for _, name := range e.Cfg.Models.Refused {
					marker := e.Marker("provider")
					o := e.callModel(c, e.Runner, route, tok, name, marker, nil)
					switch {
					case o.Kind != outcome.Response:
						c.Errorf("model %q: %s", name, o)
					case o.Status == http.StatusOK:
						c.Errorf("model %q was served: want model_not_found", name)
					case !strings.Contains(o.Body, "model_not_found"):
						c.Errorf("model %q: want model_not_found, got %s", name, o)
					case outcome.Refuser(o, e.Runner.Source) == outcome.AuthorizationPolicy:
						c.Errorf("model %q: a sidecar refused, not the gateway: %s", name, o)
					default:
						c.Logf("model %q refused: %s", name, o)
					}
					noUpstreamRecord(c, route, marker)
				}
				o := e.callModel(c, e.Runner, route, tok, e.alias(), e.Marker("twin"), nil)
				expectThrough(c, "the alias "+e.alias(), o, o.Kind == outcome.Response && o.Status == http.StatusOK)
			},
		},
		{
			ID: "gateway-path/model/non-llm-path", Suite: SuiteGatewayPath, Layer: string(outcome.Gateway), Cluster: true, Needs: needs,
			Row:   "On the model route, a path that is not an LLM API path is refused, never passed through to the provider",
			Title: "a path under the model route that is no LLM API path is refused by the gateway and never reaches the fake model server; /v1/messages passes",
			Run: func(c *C) {
				e := c.Env
				paths := e.Cfg.Models.NotLLM
				if len(paths) == 0 {
					paths = []string{"/v1/embeddings", "/v1/files", "/v1/messages/batches", "/v1/../admin"}
				}
				before, err := e.fakeModelRecords(c, "")
				if err != nil {
					c.Fatalf("%v", err)
				}
				tok := token(c, RoleDeveloper, route)
				for _, p := range paths {
					o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: e.Cfg.Gateways["gateway"] + p,
						Header: map[string]string{"Authorization": "Bearer " + tok, "Content-Type": "application/json", "anthropic-version": e.Cfg.Models.AnthropicVersion},
						Body:   messages(e.alias(), e.Marker("path"), "")})
					if o.Kind == outcome.Response && o.Status < 400 {
						c.Errorf("POST %s was answered %d: want a refusal", p, o.Status)
					} else if outcome.Refuser(o, e.Runner.Source) == outcome.AuthorizationPolicy {
						c.Errorf("POST %s: a sidecar refused, not the gateway: %s", p, o)
					} else {
						c.Logf("POST %s: %s", p, o)
					}
				}
				after, err := e.fakeModelRecords(c, "")
				if err != nil {
					c.Fatalf("%v", err)
				}
				for _, r := range after[min(len(before), len(after)):] {
					if r.API == "none" {
						c.Errorf("the fake model server received %s %s: the gateway passed a non-LLM path through", r.Method, r.Path)
					}
				}
				o := e.callModel(c, e.Runner, route, tok, e.alias(), e.Marker("twin"), nil)
				expectThrough(c, "POST /v1/messages", o, o.Kind == outcome.Response && o.Status == http.StatusOK)
			},
		},
		{
			ID: "gateway-path/model/models-list", Suite: SuiteGatewayPath, Cluster: false, Needs: []runner.Need{NeedSignIn, NeedRoute(route)},
			Row:   "CEL admits only the approved aliases",
			Title: "/v1/models lists the approved aliases and nothing else",
			Run: func(c *C) {
				e := c.Env
				o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: e.Cfg.CallURL(route) + "/models",
					Header: map[string]string{"Authorization": "Bearer " + token(c, RoleDeveloper, route), "anthropic-version": e.Cfg.Models.AnthropicVersion}})
				if o.Kind != outcome.Response || o.Status != http.StatusOK {
					c.Fatalf("GET /v1/models: %s", o)
				}
				var doc struct {
					Data []struct {
						ID string `json:"id"`
					} `json:"data"`
				}
				json.Unmarshal([]byte(o.Body), &doc)
				var got []string
				for _, m := range doc.Data {
					got = append(got, m.ID)
				}
				for alias := range e.Cfg.Models.Aliases {
					if !contains(got, alias) {
						c.Errorf("/v1/models lacks the alias %s: it lists %v", alias, got)
					}
				}
				for _, id := range got {
					if _, ok := e.Cfg.Models.Aliases[id]; !ok {
						c.Errorf("/v1/models lists %q, which is no approved alias", id)
					}
				}
			},
		},
	}
}

func mcpCases() []Case {
	route := "gateway/mcp/capture-mcp"
	return []Case{
		{
			ID: "gateway-path/mcp/anonymous-registration", Suite: SuiteGatewayPath, Layer: string(outcome.Realm), Cluster: false,
			Needs: []runner.Need{NeedRoute(route)},
			Row:   "The realm admits no anonymous client registration, at its own registration endpoint or at the one an MCP route's metadata advertises: MCP clients come pre-registered",
			Title: "an anonymous client registration is refused by the realm's registration policy, directly and through the registration endpoint capture-mcp's route advertises; the pre-registered MCP client's authorization request goes on to sign-in",
			Run:   func(c *C) { anonymousRegistrationCase(c, route) },
		},
		{
			ID: "gateway-path/mcp/hidden-tool-listed", Suite: SuiteGatewayPath, Layer: string(outcome.Gateway), Cluster: false,
			Needs: []runner.Need{NeedRoute(route), NeedPersona(RoleDeveloper), NeedPersona(RolePlatformEngineer)},
			Row:   "A hidden tool is missing from tools/list",
			Title: "a developer's tools/list lacks the platform-engineer tool and has the everyone tool; a platform engineer's has both",
			Run: func(c *C) {
				e := c.Env
				names, call := e.mcpClient(e.Runner, route, token(c, RoleDeveloper, route), e.Marker("list")).ListTools(c)
				if !call.OK() {
					c.Fatalf("a developer's tools/list: %s", call)
				}
				if contains(names, capturemcp.ToolPlatform) {
					c.Errorf("a developer sees %s: the gateway did not filter tools/list (%v)", capturemcp.ToolPlatform, names)
				}
				if !contains(names, capturemcp.ToolEveryone) {
					c.Errorf("a developer does not see %s (%v): the twin of the hidden tool", capturemcp.ToolEveryone, names)
				}
				names, call = e.mcpClient(e.Runner, route, token(c, RolePlatformEngineer, route), e.Marker("list")).ListTools(c)
				if !call.OK() {
					c.Fatalf("a platform engineer's tools/list: %s", call)
				}
				if !contains(names, capturemcp.ToolPlatform) {
					c.Errorf("a platform engineer does not see %s (%v): the tool must exist for the hidden case to mean anything", capturemcp.ToolPlatform, names)
				}
			},
		},
		{
			ID: "gateway-path/mcp/hidden-tool-called", Suite: SuiteGatewayPath, Layer: string(outcome.Gateway), Cluster: true,
			Needs: []runner.Need{NeedRoute(route), NeedPersona(RoleDeveloper), NeedCaptureMCP},
			Row:   "A hidden tool is refused on tools/call",
			Title: "a developer's tools/call of the platform-engineer tool is refused and never reaches capture-mcp; the everyone tool is called",
			Run: func(c *C) {
				e := c.Env
				tok := token(c, RoleDeveloper, route)
				marker := e.Marker("hidden")
				call := e.mcpClient(e.Runner, route, tok, marker).CallTool(c, capturemcp.ToolPlatform, nil)
				if call.OK() {
					if r, err := call.Result(); err == nil && !r.IsError {
						c.Errorf("a developer called %s: the gateway did not refuse it", capturemcp.ToolPlatform)
					}
				} else if outcome.Refuser(call.Outcome, e.Runner.Source) == outcome.AuthorizationPolicy {
					c.Errorf("a sidecar refused the call, not the gateway: %s", call)
				} else {
					c.Logf("refused: %s", call)
				}
				recs, err := e.captureRecords(c, marker)
				if err != nil {
					c.Errorf("%v", err)
				}
				for _, r := range recs {
					if r.Method == "tools/call" {
						c.Errorf("capture-mcp received the call of %s: the gateway passed a hidden tool's call on", r.Tool)
					}
				}
				twin := e.Marker("visible")
				call = e.mcpClient(e.Runner, route, tok, twin).CallTool(c, capturemcp.ToolEveryone, nil)
				if !call.OK() {
					c.Errorf("allowed twin: a developer's call of %s: %s", capturemcp.ToolEveryone, call)
				} else if recs, err := e.captureRecords(c, twin); err == nil && !hasMethod(recs, "tools/call") {
					c.Errorf("allowed twin: capture-mcp has no record of the call of %s", capturemcp.ToolEveryone)
				}
			},
		},
	}
}

func hasMethod(recs []capturemcp.Record, m string) bool {
	for _, r := range recs {
		if r.Method == m {
			return true
		}
	}
	return false
}

func upstreamCases() []Case {
	return []Case{
		{
			ID: "gateway-path/upstream/model-headers", Suite: SuiteGatewayPath, Cluster: true,
			Needs: []runner.Need{NeedSignIn, NeedRoute("gateway/v1"), NeedFakeModel},
			Row:   "The upstream never receives the caller's token",
			Title: "the fake model server receives no credential header, and anthropic-version, anthropic-beta and traceparent as the client sent them (T11)",
			Run: func(c *C) {
				e := c.Env
				marker := e.Marker("headers")
				trace := fmt.Sprintf("00-%032x-%016x-01", time.Now().UnixNano(), time.Now().UnixNano()&0xffffffff)
				beta := "conformance-beta-2026-11-16"
				o := e.callModel(c, e.Runner, "gateway/v1", token(c, RoleDeveloper, "gateway/v1"), e.alias(), marker,
					map[string]string{"anthropic-beta": beta, "traceparent": trace, "x-api-key": "conformance-not-a-key"})
				if !expectThrough(c, "a model call", o, o.Kind == outcome.Response && o.Status == http.StatusOK) {
					return
				}
				recs, err := e.fakeModelRecords(c, marker)
				if err != nil || len(recs) != 1 {
					c.Fatalf("want one record for %s: %v %d", marker, err, len(recs))
				}
				r := recs[0]
				if len(r.Credentials) != 0 {
					c.Errorf("the fake model server received credential headers %v: a caller's credential reached the model", r.Credentials)
				}
				if r.AnthropicVersion != e.Cfg.Models.AnthropicVersion {
					c.Errorf("anthropic-version arrived as %q, sent %q", r.AnthropicVersion, e.Cfg.Models.AnthropicVersion)
				}
				if r.AnthropicBeta != beta {
					c.Errorf("anthropic-beta arrived as %q, sent %q", r.AnthropicBeta, beta)
				}
				if !strings.Contains(r.Traceparent, trace[3:35]) {
					c.Errorf("traceparent arrived as %q: the trace %s did not continue", r.Traceparent, trace[3:35])
				}
			},
		},
		{
			ID: "gateway-path/upstream/mcp-token", Suite: SuiteGatewayPath, Cluster: true,
			Needs: []runner.Need{NeedRoute("gateway/mcp/capture-mcp"), NeedPersona(RoleDeveloper), NeedCaptureMCP},
			Row:   "Each route admits only its own tokens",
			Title: "capture-mcp, which re-verifies, receives the caller's token for its own route: one audience, the route's URL, typed at+jwt",
			Run: func(c *C) {
				e := c.Env
				route := "gateway/mcp/capture-mcp"
				marker := e.Marker("mcptoken")
				call := e.mcpClient(e.Runner, route, token(c, RoleDeveloper, route), marker).CallTool(c, capturemcp.ToolEveryone, nil)
				if !call.OK() {
					c.Fatalf("calling %s: %s", capturemcp.ToolEveryone, call)
				}
				recs, err := e.captureRecords(c, marker)
				if err != nil || !hasMethod(recs, "tools/call") {
					c.Fatalf("capture-mcp's record of the call: %v", err)
				}
				for _, r := range recs {
					if r.Method != "tools/call" {
						continue
					}
					if r.Token == nil {
						c.Fatalf("capture-mcp received no bearer token: the gateway must pass the route's token on, since tools re-verify")
					}
					if aud := audiences(r.Token.Claims); len(aud) != 1 || aud[0] != e.Cfg.RouteURL(route) {
						c.Errorf("the token capture-mcp received has aud %v, want exactly [%s]", aud, e.Cfg.RouteURL(route))
					}
					if typ, _ := r.Token.Header["typ"].(string); typ != "at+jwt" {
						c.Errorf("the token capture-mcp received is typed %q, want at+jwt", typ)
					}
				}
			},
		},
	}
}

func limitCase(c *C) {
	e := c.Env
	route := "gateway/v1"
	tok := token(c, RoleLimited, route)
	team, _ := claims(c, tok)["team"].(string)
	if team == "" {
		c.Fatalf("the %s persona's token has no team: it must be in the team whose budget is %d tokens a window", e.Cfg.Personas[RoleLimited], e.Cfg.Limits.Tokens)
	}
	if e.Cfg.TestIssuer.Issuer != "" && e.Cfg.TestIssuer.Team == team {
		c.Fatalf("the test issuer's tokens claim team %s, whose budget this case drains: the test issuer's cases would then depend on when this case last ran (test_issuer.team)", team)
	}
	per := e.Cfg.Limits.Tokens / 3
	body := func(marker string) string {
		b, _ := json.Marshal(map[string]any{"model": e.alias(), "max_tokens": per + 100,
			"messages": []map[string]any{{"role": "user", "content": fmt.Sprintf("[[fake-model id=%s tokens=%d]] Talk.", marker, per)}}})
		return string(b)
	}
	waited := false
	for {
		h := map[string]string{"Authorization": "Bearer " + tok, "Content-Type": "application/json", "anthropic-version": e.Cfg.Models.AnthropicVersion}
		spent, prev := 0, 0
		for i := 1; i <= e.Cfg.Limits.MaxRequests; i++ {
			o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: e.Cfg.CallURL(route) + "/messages", Header: h, Body: body(e.Marker("limit"))})
			if o.Kind == outcome.Response && o.Status == http.StatusTooManyRequests {
				if outcome.Refuser(o, e.Runner.Source) == outcome.AuthorizationPolicy {
					c.Fatalf("request %d: a sidecar answered: %s", i, o)
				}
				ra, err := strconv.Atoi(o.Header["retry-after"])
				if err != nil || ra <= 0 {
					c.Errorf("request %d got 429 without a positive Retry-After (%q)", i, o.Header["retry-after"])
					return
				}
				if i == 1 {
					// Crossed before this run began, as by an earlier run: wait
					// for the window to reset, once, so the crossing itself is
					// seen; a window too long to wait for proves nothing here.
					wait := time.Duration(ra)*time.Second + 2*time.Second
					if waited || wait > e.Cfg.Limits.MaxWait.Duration {
						c.Errorf("team %s's window was crossed before the case began and resets in %ds, longer than limits.max_wait %s: the crossing cannot be observed; give the team a window shorter than that where the suites run back to back", team, ra, e.Cfg.Limits.MaxWait.Duration)
						return
					}
					c.Logf("team %s's window was crossed before the case began, as by an earlier run: waiting %s for it to reset", team, wait.Round(time.Second))
					c.Sleep(wait)
					waited = true
					tok = token(c, RoleLimited, route)
					break
				}
				if prev != http.StatusOK {
					c.Errorf("the request before the first 429 got %d: the crossing request must succeed", prev)
				} else {
					c.Logf("crossed after %d requests, %d tokens; request %d got 429, Retry-After %s", i-1, spent, i, o.Header["retry-after"])
				}
				o = e.callModel(c, e.Runner, route, token(c, RoleOtherTeam, route), e.alias(), e.Marker("otherteam"), nil)
				expectThrough(c, "another team's request right after", o, o.Kind == outcome.Response && o.Status == http.StatusOK)
				return
			}
			if o.Kind != outcome.Response || o.Status != http.StatusOK {
				c.Fatalf("request %d: %s", i, o)
			}
			var resp struct {
				Usage struct {
					In  int `json:"input_tokens"`
					Out int `json:"output_tokens"`
				} `json:"usage"`
			}
			json.Unmarshal([]byte(o.Body), &resp)
			spent += resp.Usage.In + resp.Usage.Out
			prev = o.Status
			if i == e.Cfg.Limits.MaxRequests {
				c.Errorf("no 429 after %d requests and %d tokens, past a budget of %d a window", e.Cfg.Limits.MaxRequests, spent, e.Cfg.Limits.Tokens)
				return
			}
		}
	}
}

// anonymousRegistrationCase: the realm admits no anonymous client
// registration (design/gateway.md, "MCP and A2A"), neither at its own
// registration endpoint nor at the one route's discovery leads an MCP
// client to, which the gateway proxies to the realm since its MCP settings
// name no client ID to answer with. A refusal is the realm's when its body
// names the client-registration service, as Keycloak's policies do. The
// twin: the pre-registered MCP client's authorization request for the
// route's scope goes on to sign-in instead of back to the client with an
// error.
func anonymousRegistrationCase(c *C, route string) {
	e := c.Env
	register := func(what string, metadata []string) {
		md, from := e.authServerMetadata(c, metadata)
		if md == nil {
			c.Errorf("%s: no authorization-server metadata at %v", what, metadata)
			return
		}
		reg, _ := md["registration_endpoint"].(string)
		if reg == "" {
			c.Logf("%s: %s advertises no registration endpoint, so there is nothing to register at", what, from)
			return
		}
		body, _ := json.Marshal(map[string]any{"client_name": "conformance-" + e.Marker("register"),
			"redirect_uris": []string{e.Cfg.MCPClient.RedirectURI}, "grant_types": []string{"authorization_code"},
			"response_types": []string{"code"}, "token_endpoint_auth_method": "none"})
		o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: reg, Body: string(body),
			Header: map[string]string{"Content-Type": "application/json"}})
		switch {
		case o.Kind != outcome.Response:
			c.Errorf("%s: the registration at %s got no answer: %s", what, reg, o)
		case o.Status/100 == 2:
			c.Errorf("%s: %s registered an anonymous client (%s): the realm must refuse it, and the gateway must not answer for it", what, reg, o)
			e.unregister(c, o.Body)
		case (o.Status == http.StatusUnauthorized || o.Status == http.StatusForbidden) && strings.Contains(o.Body, "client-registration"):
			c.Logf("%s: refused by realm, as due: %s", what, o)
		default:
			c.Errorf("%s: want realm to refuse, but the answer is not its registration policy's: %s", what, o)
		}
	}
	issuer := strings.TrimRight(e.Cfg.Issuers.Keycloak, "/")
	register("the realm's own registration endpoint", []string{issuer + "/.well-known/openid-configuration"})
	// As an MCP client finds it: the route's protected-resource metadata
	// names the authorization server, whose metadata names the endpoint.
	gw, path, _ := strings.Cut(route, "/")
	prm := e.Cfg.Gateways[gw] + "/.well-known/oauth-protected-resource/" + path
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: prm})
	var res struct {
		AuthorizationServers []string `json:"authorization_servers"`
	}
	if o.Kind != outcome.Response || o.Status != http.StatusOK || json.Unmarshal([]byte(o.Body), &res) != nil || len(res.AuthorizationServers) == 0 {
		c.Errorf("the route's protected-resource metadata at %s: %s", prm, o)
	} else {
		as := strings.TrimRight(res.AuthorizationServers[0], "/")
		register("the registration endpoint the route's discovery advertises", []string{wellKnown(as, "oauth-authorization-server"), as + "/.well-known/openid-configuration"})
	}

	// The allowed twin.
	md, _ := e.authServerMetadata(c, []string{issuer + "/.well-known/openid-configuration"})
	authz, _ := md["authorization_endpoint"].(string)
	if authz == "" {
		c.Fatalf("allowed twin: the realm's metadata names no authorization endpoint")
	}
	sum := sha256.Sum256([]byte(e.Marker("verifier") + "-0123456789abcdefghijklmnopqrstuvwxyz"))
	q := url.Values{"client_id": {e.Cfg.MCPClient.ClientID}, "response_type": {"code"}, "redirect_uri": {e.Cfg.MCPClient.RedirectURI},
		"scope": {e.Cfg.Routes[route].Scope}, "state": {e.Marker("state")}, "code_challenge_method": {"S256"},
		"code_challenge": {base64.RawURLEncoding.EncodeToString(sum[:])}}
	o = e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: authz + "?" + q.Encode()})
	loc := o.Header["location"]
	if o.Kind == outcome.Response && o.Status/100 == 3 && loc != "" && !strings.HasPrefix(loc, e.Cfg.MCPClient.RedirectURI) {
		c.Logf("allowed twin: %s's authorization request went on to sign-in (%d to %s)", e.Cfg.MCPClient.ClientID, o.Status, strings.SplitN(loc, "?", 2)[0])
	} else {
		c.Errorf("allowed twin: the pre-registered client %s's authorization request did not go on to sign-in: %s, location %q", e.Cfg.MCPClient.ClientID, o, loc)
	}
}

// authServerMetadata fetches the first of urls that answers with JSON.
func (e *Env) authServerMetadata(c *C, urls []string) (map[string]any, string) {
	for _, u := range urls {
		o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: u})
		var md map[string]any
		if o.Kind == outcome.Response && o.Status == http.StatusOK && json.Unmarshal([]byte(o.Body), &md) == nil {
			return md, u
		}
	}
	return nil, ""
}

// unregister deletes a client a registration created, with the access
// token RFC 7592 hands back, so a failed case leaves nothing behind.
func (e *Env) unregister(c *C, body string) {
	var r struct {
		URI   string `json:"registration_client_uri"`
		Token string `json:"registration_access_token"`
	}
	if json.Unmarshal([]byte(body), &r) != nil || r.URI == "" || r.Token == "" {
		c.Logf("the registration returned no registration_client_uri and token: delete the client by hand")
		return
	}
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodDelete, URL: r.URI, Header: map[string]string{"Authorization": "Bearer " + r.Token}})
	c.Logf("deleting the registered client: %s", o)
}

// wellKnown is RFC 8414's metadata URL for an issuer: the well-known
// suffix inserted before the issuer's path.
func wellKnown(issuer, suffix string) string {
	u, err := url.Parse(issuer)
	if err != nil {
		return issuer + "/.well-known/" + suffix
	}
	u.Path = "/.well-known/" + suffix + strings.TrimRight(u.Path, "/")
	return u.String()
}
