package platform

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/json"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// The bypass suite (design/conformance.md, "The platform-controls
// suites"): every way around the gateways fails, each refused by the layer
// meant to refuse it, whose source every other layer admits, so that a case
// cannot pass because another layer refused first. The allowed twin is the
// same call through the gateway, or the workload's own objects.
const SuiteBypass = "bypass"

func bypassCases() []Case {
	mcpRoute := "gateway/mcp/capture-mcp"
	var out []Case
	out = append(out,
		Case{
			ID: "bypass/ingress/authorization-policy/capture-mcp", Suite: SuiteBypass, Layer: string(outcome.AuthorizationPolicy), Cluster: true,
			Row:   "Direct ingress to a backend from another meshed namespace (AuthorizationPolicy)",
			Title: "a meshed pod with no grants, which NetworkPolicy lets through, calling capture-mcp directly is denied by its sidecar's AuthorizationPolicy; the same call through the gateway passes",
			Needs: []runner.Need{NeedProbeMeshed, NeedPersona(RoleDeveloper), NeedRoute(mcpRoute)},
			Run: func(c *C) {
				e := c.Env
				direct := need(c, e.Cfg.CaptureMCP.Direct, "capture_mcp.direct")
				src := e.Probes["meshed"]
				marker := e.Marker("direct")
				cl := &mcp.Client{URL: direct, HTTP: &doer{e: e, src: src}, Header: map[string]string{capturemcp.MarkerHeader: marker}}
				_, call := cl.ListTools(c)
				expectLayer(c, "conformance-probe to capture-mcp", call.Outcome, src, outcome.AuthorizationPolicy)
				noCaptureRecord(c, marker)
				_, call = e.mcpClient(e.Runner, mcpRoute, token(c, RoleDeveloper, mcpRoute), e.Marker("twin")).ListTools(c)
				expectThrough(c, "through the gateway", call.Outcome, call.OK())
			},
		},
		Case{
			ID: "bypass/ingress/authorization-policy/fake-model-ops", Suite: SuiteBypass, Layer: string(outcome.AuthorizationPolicy), Cluster: true,
			Row:   "Direct ingress to a backend from another meshed namespace (AuthorizationPolicy); named platform callers (design/gateway.md, \"Bypass prevention\")",
			Title: "a meshed pod with no grants reading the fake model server's operations port is denied by its sidecar; the runner, its one named platform caller, reads it",
			Needs: []runner.Need{NeedProbeMeshed, NeedFakeModel},
			Run: func(c *C) {
				e := c.Env
				u := strings.TrimRight(e.Cfg.FakeModel.Ops, "/") + "/requests?id=" + e.Marker("ops")
				src := e.Probes["meshed"]
				expectLayer(c, "conformance-probe to the operations port", e.Do(c, src, outcome.Request{Method: http.MethodGet, URL: u}), src, outcome.AuthorizationPolicy)
				o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: u})
				expectThrough(c, "the runner, the named platform caller", o, o.Kind == outcome.Response && o.Status == http.StatusOK)
			},
		},
		Case{
			ID: "bypass/ingress/strict-mtls/capture-mcp", Suite: SuiteBypass, Layer: string(outcome.MTLS), Cluster: true,
			Row:   "Direct ingress to a backend from outside the mesh (STRICT mTLS)",
			Title: "a pod outside the mesh, which NetworkPolicy lets through, calling capture-mcp in plain text is refused by its sidecar's STRICT mTLS; the same pod's call through the gateway passes",
			Needs: []runner.Need{NeedProbeNomesh, NeedPersona(RoleDeveloper), NeedRoute(mcpRoute)},
			Run: func(c *C) {
				e := c.Env
				direct := need(c, e.Cfg.CaptureMCP.Direct, "capture_mcp.direct")
				src := e.Probes["nomesh"]
				marker := e.Marker("plain")
				cl := &mcp.Client{URL: direct, HTTP: &doer{e: e, src: src}, Header: map[string]string{capturemcp.MarkerHeader: marker}}
				_, call := cl.ListTools(c)
				expectLayer(c, "conformance-nomesh to capture-mcp", call.Outcome, src, outcome.MTLS)
				noCaptureRecord(c, marker)
				_, call = e.mcpClient(src, mcpRoute, token(c, RoleDeveloper, mcpRoute), e.Marker("twin")).ListTools(c)
				expectThrough(c, "conformance-nomesh through the gateway", call.Outcome, call.OK())
			},
		},
		Case{
			ID: "bypass/ingress/networkpolicy/sidecar-port", Suite: SuiteBypass, Layer: string(outcome.NetworkPolicy), Cluster: true,
			Row:   "Direct ingress to a backend from where only NetworkPolicy stops it",
			Title: "a pod outside the mesh calling a port of capture-mcp's pod that its sidecar does not intercept, where neither mTLS nor AuthorizationPolicy applies, is dropped by NetworkPolicy; the same pod reaches the pod's own port, where mTLS answers",
			Needs: []runner.Need{NeedProbeNomesh},
			Run: func(c *C) {
				e := c.Env
				port := need(c, e.Cfg.CaptureMCP.SidecarPort, "capture_mcp.sidecar_port")
				direct := need(c, e.Cfg.CaptureMCP.Direct, "capture_mcp.direct")
				src := e.Probes["nomesh"]
				expectLayer(c, "conformance-nomesh to the un-intercepted port", e.Do(c, src, outcome.Request{Method: http.MethodGet, URL: port}), src, outcome.NetworkPolicy)
				o := e.Do(c, src, outcome.Request{Method: http.MethodPost, URL: direct, Header: map[string]string{"Content-Type": "application/json"}, Body: `{}`})
				if got := outcome.Refuser(o, src.Source); got != outcome.MTLS {
					c.Errorf("allowed twin: want the pod reachable on its own port, where its sidecar refuses plain text, got %s: %s", got, o)
				}
			},
		},
		Case{
			ID: "bypass/egress/networkpolicy/fake-model", Suite: SuiteBypass, Layer: string(outcome.NetworkPolicy), Cluster: true,
			Row:   "Direct egress from a workload to a model provider (NetworkPolicy)",
			Title: "a workload's direct call to the model provider, the fake model server's model port, is dropped by NetworkPolicy; the same workload's call through the gateway passes",
			Needs: []runner.Need{NeedProbeMeshed, NeedPersona(RoleDeveloper), NeedRoute("gateway/v1")},
			Run: func(c *C) {
				e := c.Env
				direct := need(c, e.Cfg.FakeModel.Direct, "fake_model.direct")
				src := e.Probes["meshed"]
				o := e.Do(c, src, outcome.Request{Method: http.MethodPost, URL: strings.TrimRight(direct, "/") + "/v1/messages",
					Header: map[string]string{"Content-Type": "application/json", "anthropic-version": e.Cfg.Models.AnthropicVersion},
					Body:   messages("fake-reasoning", e.Marker("egress"), ""), Timeout: outcome.Of(e.Cfg.Timing.MeshConnectTimeout.Duration + e.Cfg.Timing.Request.Duration)})
				expectLayer(c, "conformance-probe to the fake model server", o, src, outcome.NetworkPolicy)
				o = e.callModel(c, src, "gateway/v1", token(c, RoleDeveloper, "gateway/v1"), e.alias(), e.Marker("twin"), nil)
				expectThrough(c, "conformance-probe through the gateway", o, o.Kind == outcome.Response && o.Status == http.StatusOK)
			},
		},
		egressCase("model-providers", "Direct egress from a workload to a model provider (NetworkPolicy)",
			"a workload's direct call to an outside model provider is dropped by NetworkPolicy; the runner, whose namespace may reach the internet, reaches the same address",
			func(cfg *Config) []string { return cfg.Bypass.Providers }, "bypass.providers"),
		egressCase("tool-upstreams", "Direct egress from a workload to a tool's upstream (NetworkPolicy)",
			"a workload's direct call to a tool's outside upstream is dropped by NetworkPolicy; the runner reaches the same address",
			func(cfg *Config) []string { return cfg.Bypass.ToolUpstreams }, "bypass.tool_upstreams"),
	)
	for _, r := range admissionRules() {
		out = append(out, admissionCase(r))
	}
	out = append(out,
		Case{
			ID: "bypass/admission/helm-ownership", Suite: SuiteBypass, Layer: string(outcome.Admission), Cluster: true,
			Row:   "A workload release that writes a platform namespace into Helm's ownership annotation, installed through Helm",
			Title: "a workload chart whose AuthorizationPolicy claims a platform release's namespace is refused by mesh-floor when Helm installs it, because Helm writes the annotation itself; the same chart without it installs",
			Needs: []runner.Need{NeedHelm, NeedAdmission}, Run: helmOwnershipCase,
		},
		Case{
			ID: "bypass/aws/bedrock", Suite: SuiteBypass, Layer: "iam", Cluster: true,
			Row:   "In AWS, Bedrock for any role but the gateway's (IAM and the SCP)",
			Title: "Bedrock invocation as any principal but the gateway's gets AccessDenied, the SCP's included; the gateway's role is allowed",
			Needs: []runner.Need{NeedAWS}, Run: awsCase,
		},
	)
	return out
}

// need returns a configured URL or ends the case naming the setting.
func need(c *C, v, setting string) string {
	if v == "" {
		c.Fatalf("set %s", setting)
	}
	return v
}

func noCaptureRecord(c *C, marker string) {
	if c.Env.Cfg.CaptureMCP.Ops == "" {
		return
	}
	recs, err := c.Env.captureRecords(c, marker)
	if err != nil {
		c.Errorf("%v", err)
	} else if len(recs) > 0 {
		c.Errorf("capture-mcp received the direct request (%d records): nothing stopped it", len(recs))
	}
}

func egressCase(name, row, title string, urls func(*Config) []string, setting string) Case {
	return Case{
		ID: "bypass/egress/networkpolicy/" + name, Suite: SuiteBypass, Layer: string(outcome.NetworkPolicy), Cluster: true,
		Row: row, Title: title, Needs: []runner.Need{NeedProbeMeshed},
		Run: func(c *C) {
			e := c.Env
			list := urls(e.Cfg)
			if len(list) == 0 {
				c.Fatalf("set %s", setting)
			}
			src := e.Probes["meshed"]
			for _, u := range list {
				o := e.Do(c, src, outcome.Request{Method: http.MethodGet, URL: u, Timeout: outcome.Of(e.Cfg.Timing.MeshConnectTimeout.Duration + e.Cfg.Timing.Request.Duration)})
				if got := outcome.Refuser(o, src.Source); o.Kind == outcome.Response && got != outcome.AuthorizationPolicy && got != outcome.NetworkPolicy {
					// No gateway stands between a pod and the outside: any
					// answer, a 403 included, came from there.
					c.Errorf("conformance-probe to %s: want networkpolicy to refuse, but it got through to the outside: %s", u, o)
				} else {
					expectLayer(c, "conformance-probe to "+u, o, src, outcome.NetworkPolicy)
				}
				if o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: u}); o.Kind != outcome.Response {
					c.Errorf("allowed twin: the runner could not reach %s either (%s), so the probe's refusal proves nothing", u, o)
				}
			}
		},
	}
}

// admissionRule is one of design/gateway.md's admission rules, with
// objects a workload release could write that it refuses, one per clause,
// and objects it admits.
type admissionRule struct {
	suite string // the case's suite; "" for the bypass suite
	name  string // the case's name
	// rule is the rule that refuses; "" for name. One rule may have
	// several cases, such as backend-targets and its key sets.
	rule    string
	row     string
	title   string
	refused []admissionObject
	allowed []admissionObject
	// needs are the case's needs beside admission's.
	needs []runner.Need
	// twin, if set, checks more of what the rule must admit, such as the
	// live objects only its exceptions let in.
	twin func(c *C)
}

func (r admissionRule) refuser() string {
	if r.rule != "" {
		return r.rule
	}
	return r.name
}

type admissionObject struct {
	what   string
	plural string
	// clause is the refusing clause's message after "<rule>: ", cut
	// before the first value the environment renders into it, so that a
	// refusal by another clause of the same rule does not pass for this
	// one; "" for an allowed twin.
	clause string
	obj    func(e *Env) map[string]any
}

func admissionCase(r admissionRule) Case {
	suite := r.suite
	if suite == "" {
		suite = SuiteBypass
	}
	return Case{
		ID: suite + "/admission/" + r.name, Suite: suite, Layer: string(outcome.Admission), Cluster: true,
		Row: "Each admission rule (design/gateway.md), by a server-side dry run: " + r.row, Title: r.title,
		Needs: append([]runner.Need{NeedAdmission}, r.needs...),
		Run: func(c *C) {
			e := c.Env
			for _, o := range r.refused {
				admissionRefused(c, o, r.refuser())
			}
			for _, o := range r.allowed {
				st, err := e.Kube.DryRunCreate(c, o.plural, o.obj(e))
				if err != nil {
					c.Errorf("allowed twin, %s: %v", o.what, err)
				} else if !st.Admitted() {
					c.Errorf("allowed twin, %s: want it admitted, got %s", o.what, st)
				}
			}
			if r.twin != nil {
				r.twin(c)
			}
		},
	}
}

// admissionRefused checks that a dry run of o is refused by rule, not by
// RBAC or another rule, and by the clause o names. Each rule's messages
// start with its name and a colon (charts/kyverno-rules in environments),
// then the clause's text, which is what this asserts, whatever Kyverno or
// the API server words around it.
func admissionRefused(c *C, o admissionObject, rule string) bool {
	st, err := c.Env.Kube.DryRunCreate(c, o.plural, o.obj(c.Env))
	switch {
	case err != nil:
		c.Errorf("%s: %v", o.what, err)
	case st.Admitted():
		c.Errorf("%s: admitted, want %s to refuse it", o.what, rule)
	case st.Reason == "Forbidden" && !strings.Contains(st.Message, rule+":"):
		c.Errorf("%s: RBAC refused the runner (%s), not admission: give the runner the right to create this kind there, or the case proves nothing", o.what, st)
	case !strings.Contains(st.Message, rule+":"):
		c.Errorf("%s: refused, but not by %s: %s", o.what, rule, st)
	case !strings.Contains(st.Message, rule+": "+o.clause):
		c.Errorf("%s: refused by %s, but not by its clause %q: %s", o.what, rule, o.clause, st)
	default:
		c.Logf("%s: refused by %s, %q", o.what, rule, o.clause)
		return true
	}
	return false
}

func meta(e *Env, name string, extra map[string]any) map[string]any {
	m := map[string]any{"name": "conformance-" + name, "namespace": e.Cfg.Admission.Namespace,
		"labels": map[string]any{e.Cfg.Admission.WorkloadLabel: e.Cfg.Admission.Workload}}
	for k, v := range extra {
		m[k] = v
	}
	return m
}

// route is the workload's own HTTPRoute, which route-claims admits;
// mutate breaks one clause.
func route(name string, mutate func(spec map[string]any, e *Env)) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		wl := e.Cfg.Admission.Workload
		spec := map[string]any{
			"parentRefs": []any{map[string]any{"group": "gateway.networking.k8s.io", "kind": "Gateway", "name": "gateway", "namespace": "gateway"}},
			"rules": []any{map[string]any{
				"matches":     []any{map[string]any{"path": map[string]any{"type": "PathPrefix", "value": "/mcp/" + wl}}},
				"backendRefs": []any{map[string]any{"name": wl, "port": 8080}},
			}},
		}
		if mutate != nil {
			mutate(spec, e)
		}
		return map[string]any{"apiVersion": "gateway.networking.k8s.io/v1", "kind": "HTTPRoute", "metadata": meta(e, name, nil), "spec": spec}
	}
}

func firstRule(spec map[string]any) map[string]any { return spec["rules"].([]any)[0].(map[string]any) }

func backend(name string, spec func(e *Env) map[string]any) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		return map[string]any{"apiVersion": "agentgateway.dev/v1alpha1", "kind": "AgentgatewayBackend", "metadata": meta(e, name, nil), "spec": spec(e)}
	}
}

// policy is the policy agent-integration renders for the workload's MCP
// route, which gateway-policy-floor and backend-targets admit: Keycloak's
// keys from the platform's key-set backend; mutate breaks one clause.
func policy(name string, mutate func(spec, provider map[string]any, e *Env)) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		wl := e.Cfg.Admission.Workload
		provider := map[string]any{
			"issuer":    e.Cfg.Issuers.Keycloak,
			"audiences": []any{e.Cfg.RouteURL("gateway/mcp/" + wl)},
			"jwks":      map[string]any{"remote": keySet(e, "gateway")},
		}
		spec := map[string]any{
			"targetRefs": []any{map[string]any{"group": "gateway.networking.k8s.io", "kind": "HTTPRoute", "name": wl}},
			"traffic":    map[string]any{"jwtAuthentication": map[string]any{"mode": "Strict", "providers": []any{provider}}},
		}
		if mutate != nil {
			mutate(spec, provider, e)
		}
		return map[string]any{"apiVersion": "agentgateway.dev/v1alpha1", "kind": "AgentgatewayPolicy", "metadata": meta(e, name, nil), "spec": spec}
	}
}

func istio(kind, name string, spec map[string]any, platform bool) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		var extra map[string]any
		if platform {
			extra = map[string]any{"annotations": map[string]any{"meta.helm.sh/release-name": "network-boundaries", "meta.helm.sh/release-namespace": "policy-releases"}}
		}
		return map[string]any{"apiVersion": "security.istio.io/v1", "kind": kind, "metadata": meta(e, name, extra), "spec": spec}
	}
}

func netpol(name string, spec func(e *Env) map[string]any) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		return map[string]any{"apiVersion": "networking.k8s.io/v1", "kind": "NetworkPolicy", "metadata": meta(e, name, nil), "spec": spec(e)}
	}
}

func nsPeer(ns string) map[string]any {
	return map[string]any{"namespaceSelector": map[string]any{"matchLabels": map[string]any{"kubernetes.io/metadata.name": ns}}}
}

// withPods narrows a namespace peer to the pods with one label: DNS is
// kube-dns, not all of kube-system.
func withPods(peer map[string]any, k, v string) map[string]any {
	peer["podSelector"] = map[string]any{"matchLabels": map[string]any{k: v}}
	return peer
}

func crd(releaseNS string) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		return map[string]any{
			"apiVersion": "apiextensions.k8s.io/v1", "kind": "CustomResourceDefinition",
			"metadata": map[string]any{"name": "widgets.conformance.agentic.internal",
				"annotations": map[string]any{"meta.helm.sh/release-name": "conformance-widgets", "meta.helm.sh/release-namespace": releaseNS}},
			"spec": map[string]any{
				"group": "conformance.agentic.internal", "scope": "Namespaced",
				"names": map[string]any{"kind": "Widget", "plural": "widgets", "singular": "widget", "listKind": "WidgetList"},
				"versions": []any{map[string]any{"name": "v1", "served": true, "storage": true,
					"schema": map[string]any{"openAPIV3Schema": map[string]any{"type": "object", "x-kubernetes-preserve-unknown-fields": true}}}},
			},
		}
	}
}

func admissionRules() []admissionRule {
	return append(baseAdmissionRules(), imageVerificationRules()...)
}

func baseAdmissionRules() []admissionRule {
	return []admissionRule{
		{
			name: "route-claims", row: "route-claims",
			title: "an HTTPRoute that attaches elsewhere or to no listener of the hosted-workloads deployment, sets a hostname, matches another workload's path or a header, rewrites, claims an approval path off its MCP route or the developer deployment, or carries a workload label its namespace does not host, is refused by route-claims; the workload's own routes, on either deployment, with its approval path, and a second workload's its namespace hosts, are admitted",
			refused: []admissionObject{
				{"a hostname", "httproutes", "an HTTPRoute sets no hostname", route("route-hostname", func(s map[string]any, e *Env) { s["hostnames"] = []any{"evil." + e.Cfg.PlatformDomain} })},
				{"another parent", "httproutes", "an HTTPRoute attaches only to the gateway deployments", route("route-parent", func(s map[string]any, e *Env) {
					s["parentRefs"] = []any{parentRef("platform-ingress", "istio-ingress", "")}
				})},
				{"another workload's path", "httproutes", "an HTTPRoute matches only the path prefix", route("route-path", func(s map[string]any, e *Env) {
					firstRule(s)["matches"] = []any{map[string]any{"path": map[string]any{"type": "PathPrefix", "value": "/mcp/another-workload"}}}
				})},
				{"a header match", "httproutes", "an HTTPRoute matches on its path alone", route("route-header", func(s map[string]any, e *Env) {
					m := firstRule(s)["matches"].([]any)[0].(map[string]any)
					m["headers"] = []any{map[string]any{"name": "x-route", "value": "shadow"}}
				})},
				{"a rewrite", "httproutes", "an HTTPRoute neither rewrites nor redirects", route("route-rewrite", func(s map[string]any, e *Env) {
					firstRule(s)["filters"] = []any{map[string]any{"type": "URLRewrite", "urlRewrite": map[string]any{"path": map[string]any{"type": "ReplacePrefixMatch", "replacePrefixMatch": "/"}}}}
				})},
				// B5 (F1): without a listener, a route attaches to every
				// listener of the hosted-workloads deployment, Substrate's
				// among them.
				{"a route on the hosted-workloads deployment without a listener", "httproutes", "an HTTPRoute on the hosted-workloads deployment names its listener", route("route-no-listener", func(s map[string]any, e *Env) {
					s["parentRefs"] = []any{parentRef("workloads-gateway", "workloads-gateway", "")}
				})},
				{"a route on Substrate's listener", "httproutes", "an HTTPRoute on the hosted-workloads deployment names its listener", route("route-substrate", func(s map[string]any, e *Env) {
					s["parentRefs"] = []any{parentRef("workloads-gateway", "workloads-gateway", "substrate")}
				})},
				// B5 (P2): the approval path is people's, on the workload's
				// MCP route on the developer deployment alone.
				{"the approval path on the hosted-workloads deployment", "httproutes", "an approval path is claimed on the developer deployment", route("route-approvals-workloads", func(s map[string]any, e *Env) {
					wl := e.Cfg.Admission.Workload
					s["parentRefs"] = []any{parentRef("workloads-gateway", "workloads-gateway", "https")}
					s["rules"] = routeRules(wl, "/mcp/"+wl, "/approvals/"+wl)
				})},
				{"an approval path without the MCP prefix", "httproutes", "an HTTPRoute matches only the path prefix", route("route-approvals-alone", func(s map[string]any, e *Env) {
					s["rules"] = routeRules(e.Cfg.Admission.Workload, "/approvals/"+e.Cfg.Admission.Workload)
				})},
				{"another workload's approval path", "httproutes", "an HTTPRoute matches only the path prefix", route("route-approvals-other", func(s map[string]any, e *Env) {
					s["rules"] = routeRules(e.Cfg.Admission.Workload, "/mcp/"+e.Cfg.Admission.Workload, "/approvals/another-workload")
				})},
				// B5 (finding 3): a release cannot label itself as a workload
				// its namespace does not host, to claim that workload's
				// prefix.
				{"another workload's label, with that workload's own prefix", "httproutes", "a workload's HTTPRoute is labelled with a workload its namespace hosts", labelled(route("route-foreign-label", func(s map[string]any, e *Env) {
					s["rules"] = routeRules(e.Cfg.Admission.Workload, "/a2a/"+e.Cfg.Admission.ForeignWorkload)
				}), func(c *Config) string { return c.Admission.ForeignWorkload })},
			},
			allowed: []admissionObject{
				{"the workload's own route", "httproutes", "", route("route-own", nil)},
				{"the workload's route on the hosted-workloads deployment's listener", "httproutes", "", route("route-workloads-own", func(s map[string]any, e *Env) {
					s["parentRefs"] = []any{parentRef("workloads-gateway", "workloads-gateway", "https")}
				})},
				{"the MCP route with its approval path", "httproutes", "", route("route-approvals-own", func(s map[string]any, e *Env) {
					s["rules"] = routeRules(e.Cfg.Admission.Workload, "/mcp/"+e.Cfg.Admission.Workload, "/approvals/"+e.Cfg.Admission.Workload)
				})},
				{"a second workload the namespace hosts", "httproutes", "", labelled(route("route-second-own", func(s map[string]any, e *Env) {
					s["rules"] = routeRules(e.Cfg.Admission.SecondWorkload, "/a2a/"+e.Cfg.Admission.SecondWorkload)
				}), func(c *Config) string { return c.Admission.SecondWorkload })},
			},
		},
		{
			name: "backend-targets", row: "backend-targets",
			title: "a backend at a static host, an AI provider backend, an AgentgatewayModel, or a route backend in another namespace is refused by backend-targets; a backend naming the workload's own Service is admitted",
			refused: []admissionObject{
				{"a static host", "agentgatewaybackends", "a workload's backend is its own Service, never a static host", backend("backend-static", func(*Env) map[string]any {
					return map[string]any{"static": map[string]any{"host": "api.anthropic.com", "port": 443}}
				})},
				{"an MCP target at a host", "agentgatewaybackends", "an MCP target names its Service by backendRef, never a host", backend("backend-mcp-host", func(*Env) map[string]any {
					return map[string]any{"mcp": map[string]any{"targets": []any{map[string]any{"name": "outside", "static": map[string]any{"host": "mcp.example.com", "port": 443}}}}}
				})},
				{"an AI provider backend", "agentgatewaybackends", "a workload release adds no AI provider backend", backend("backend-ai", func(*Env) map[string]any {
					return map[string]any{"ai": map[string]any{"provider": map[string]any{"anthropic": map[string]any{"model": "claude-opus-5-5"}}}}
				})},
				{"an AgentgatewayModel", "agentgatewaymodels", "a workload release adds no AgentgatewayModel", func(e *Env) map[string]any {
					return map[string]any{"apiVersion": "agentgateway.dev/v1alpha1", "kind": "AgentgatewayModel", "metadata": meta(e, "model", nil),
						"spec": map[string]any{"parentRefs": []any{map[string]any{"name": "gateway", "namespace": "gateway"}}, "provider": "Anthropic"}}
				}},
				{"a route backend in another namespace", "httproutes", "a route's backends are in its own namespace", route("route-backend-ns", func(s map[string]any, e *Env) {
					firstRule(s)["backendRefs"] = []any{map[string]any{"name": "fake-model", "namespace": "fake-model", "port": 8080}}
				})},
			},
			allowed: []admissionObject{{"an MCP backend naming the workload's own Service", "agentgatewaybackends", "", backend("backend-own", func(e *Env) map[string]any {
				return map[string]any{"mcp": ownMCPTargets(e)}
			})}},
		},
		{
			// B5 (D14, the platform stream's (b)): a workload's route
			// verifies with its issuer's own key set, never keys it chose,
			// which would let it accept tokens it signed itself under a
			// platform issuer's name.
			name: "backend-targets-keys", rule: "backend-targets", row: "backend-targets, a workload's key sets",
			title: "a workload policy whose JWT provider holds inline keys under Keycloak's issuer, fetches a key set from a URL the workload controls, or names another namespace's key-set backend or one for another issuer, is refused by backend-targets; the platform's key-set backend for the provider's issuer is admitted",
			refused: []admissionObject{
				{"inline keys under Keycloak's issuer", "agentgatewaypolicies", "a workload's JWT provider fetches its issuer's key set; it holds no inline keys", policy("keys-inline", func(s, p map[string]any, e *Env) {
					p["jwks"] = map[string]any{"inline": inlineKeySet()}
				})},
				{"a key-set URL the workload controls", "agentgatewaypolicies", "a workload's key-set URL is its provider's issuer's own JWKS URL", policy("keys-url", func(s, p map[string]any, e *Env) {
					p["jwks"] = map[string]any{"remote": map[string]any{"url": "http://" + e.Cfg.Admission.Workload + "." + e.Cfg.Admission.Namespace + ".svc.cluster.local:8080/jwks.json"}}
				})},
				{"another namespace's key-set backend", "agentgatewaypolicies", "a workload's key-set backend is the platform's for its provider's issuer", policy("keys-other-namespace", func(s, p map[string]any, e *Env) {
					p["jwks"] = map[string]any{"remote": keySet(e, e.Cfg.Admission.Namespace)}
				})},
				{"the STS's issuer with Keycloak's key-set backend", "agentgatewaypolicies", "a workload's key-set backend is the platform's for its provider's issuer", policy("keys-other-issuer", func(s, p map[string]any, e *Env) {
					p["issuer"] = e.Cfg.Issuers.STS
					p["audiences"] = []any{e.Cfg.RouteURL("workloads-gateway/mcp/" + e.Cfg.Admission.Workload)}
				})},
			},
			allowed: []admissionObject{{"the platform's key-set backend", "agentgatewaypolicies", "", policy("keys-own", nil)}},
		},
		{
			name: "gateway-policy-floor", row: "gateway-policy-floor",
			title: "a policy that weakens JWT authentication, names an issuer or audience its route may not have, targets a Gateway, or carries a workload label its namespace does not host, and a backend whose own MCP authentication names another route's audience or is Permissive, are refused by gateway-policy-floor; the policy agent-integration renders for the route, and a backend authenticating for its own route, are admitted",
			refused: []admissionObject{
				{"JWT authentication Permissive", "agentgatewaypolicies", "JWT authentication stays Strict", policy("policy-permissive", func(s, p map[string]any, e *Env) {
					s["traffic"].(map[string]any)["jwtAuthentication"].(map[string]any)["mode"] = "Permissive"
				})},
				{"an issuer the deployment does not accept", "agentgatewaypolicies", "a provider names an issuer its gateway deployment accepts from workloads", policy("policy-issuer", func(s, p map[string]any, e *Env) { p["issuer"] = "https://untrusted.conformance.invalid" })},
				{"another route's audience", "agentgatewaypolicies", "a provider names exactly one audience, the URL of one of the workload's own routes", policy("policy-audience", func(s, p map[string]any, e *Env) {
					p["audiences"] = []any{e.Cfg.RouteURL("gateway/mcp/another-workload")}
				})},
				{"a Gateway as its target", "agentgatewaypolicies", "a workload's policy targets its own HTTPRoutes alone", policy("policy-target", func(s, p map[string]any, e *Env) {
					s["targetRefs"] = []any{map[string]any{"group": "gateway.networking.k8s.io", "kind": "Gateway", "name": "gateway"}}
				})},
				// B5 (finding 3): a release cannot label itself as a workload
				// its namespace does not host, to take that workload's
				// audience on its own route.
				{"another workload's label and audience on the workload's route", "agentgatewaypolicies", "a workload's AgentgatewayPolicy, or backend with MCP authentication, is labelled with a workload its namespace hosts", labelled(policy("policy-foreign-label", func(s, p map[string]any, e *Env) {
					p["audiences"] = []any{e.Cfg.RouteURL("gateway/a2a/" + e.Cfg.Admission.ForeignWorkload)}
				}), func(c *Config) string { return c.Admission.ForeignWorkload })},
				// B5: a backend's own MCP authentication is held to the same
				// floor as a policy's.
				{"a backend's own MCP authentication with another workload's audience", "agentgatewaybackends", "a provider names exactly one audience, the URL of one of the workload's own routes", mcpAuthBackend("policy-backend-audience", func(a map[string]any, e *Env) {
					a["audiences"] = []any{e.Cfg.RouteURL("gateway/a2a/" + e.Cfg.Admission.ForeignWorkload)}
				})},
				{"a backend's own MCP authentication made Permissive", "agentgatewaybackends", "JWT authentication stays Strict", mcpAuthBackend("policy-backend-permissive", func(a map[string]any, e *Env) {
					a["mode"] = "Permissive"
				})},
			},
			allowed: []admissionObject{
				{"agent-integration's policy for the route", "agentgatewaypolicies", "", policy("policy-own", nil)},
				{"a backend's own MCP authentication on its own route", "agentgatewaybackends", "", mcpAuthBackend("policy-backend-own", nil)},
			},
		},
		{
			name: "mesh-floor", row: "mesh-floor",
			title: "an AuthorizationPolicy, a PeerAuthentication, or a NetworkPolicy admitting ingress from anywhere or egress to the internet, from a workload release, is refused by mesh-floor; the platform's own AuthorizationPolicy and a NetworkPolicy within the floor are admitted",
			refused: []admissionObject{
				{"an AuthorizationPolicy", "authorizationpolicies", "a workload release adds no PeerAuthentication, AuthorizationPolicy", istio("AuthorizationPolicy", "mesh-authz", map[string]any{"action": "ALLOW",
					"rules": []any{map[string]any{"from": []any{map[string]any{"source": map[string]any{"namespaces": []any{"conformance-probe"}}}}}}}, false)},
				{"a PeerAuthentication", "peerauthentications", "a workload release adds no PeerAuthentication, AuthorizationPolicy", istio("PeerAuthentication", "mesh-peer", map[string]any{"mtls": map[string]any{"mode": "PERMISSIVE"}}, false)},
				{"a NetworkPolicy admitting ingress from anywhere", "networkpolicies", "a workload's NetworkPolicy admits ingress only from the namespaces of the gateway deployments", netpol("mesh-np-ingress", func(*Env) map[string]any {
					return map[string]any{"podSelector": map[string]any{}, "policyTypes": []any{"Ingress"}, "ingress": []any{map[string]any{}}}
				})},
				{"a NetworkPolicy admitting egress to the internet", "networkpolicies", "a workload's NetworkPolicy allows egress only to the gateways, the STS, DNS", netpol("mesh-np-egress", func(*Env) map[string]any {
					return map[string]any{"podSelector": map[string]any{}, "policyTypes": []any{"Egress"},
						"egress": []any{map[string]any{"to": []any{map[string]any{"ipBlock": map[string]any{"cidr": "0.0.0.0/0"}}}}}}
				})},
			},
			allowed: []admissionObject{
				{"the platform's own AuthorizationPolicy, from a platform namespace's release", "authorizationpolicies", "", istio("AuthorizationPolicy", "mesh-platform", map[string]any{"action": "ALLOW",
					"rules": []any{map[string]any{"from": []any{map[string]any{"source": map[string]any{"principals": []any{"cluster.local/ns/gateway/sa/gateway"}}}}}}}, true)},
				{"a NetworkPolicy within the floor", "networkpolicies", "", netpol("mesh-np-own", func(*Env) map[string]any {
					return map[string]any{"podSelector": map[string]any{}, "policyTypes": []any{"Ingress", "Egress"},
						"ingress": []any{map[string]any{"from": []any{nsPeer("gateway"), nsPeer("workloads-gateway")}}},
						"egress": []any{map[string]any{"to": []any{nsPeer("workloads-gateway")}},
							map[string]any{"to": []any{withPods(nsPeer("kube-system"), "k8s-app", "kube-dns")}, "ports": []any{map[string]any{"port": 53, "protocol": "UDP"}}}}}
				})},
			},
		},
		{
			name: "platform-crds", row: "platform-crds",
			title:   "a CustomResourceDefinition from a release whose Helm state is in a team namespace is refused by platform-crds; the same from a platform namespace's release is admitted",
			refused: []admissionObject{{"a CRD from a workload release", "customresourcedefinitions", "a CustomResourceDefinition comes only from a release whose Helm state is in a platform namespace", func(e *Env) map[string]any { return crd(e.Cfg.Admission.Namespace)(e) }}},
			allowed: []admissionObject{{"the same CRD from platform/00-crds", "customresourcedefinitions", "", crd("platform-crds")}},
		},
		{
			// B5 (F3): External Secrets Operator reads with whatever
			// credentials a store names, and the platform's store reads
			// every platform secret.
			name: "secret-stores", row: "secret-stores",
			title: "a workload's own SecretStore, and an ExternalSecret through another store or a generator, for a platform key or another namespace's, or by a search, are refused by secret-stores; an ExternalSecret reading the workload's own key through the platform's store is admitted",
			refused: []admissionObject{
				{"a workload's own SecretStore assuming the platform's role", "secretstores", "only a platform release adds a secret store", func(e *Env) map[string]any {
					return map[string]any{"apiVersion": "external-secrets.io/v1", "kind": "SecretStore", "metadata": meta(e, "secret-store", nil),
						"spec": map[string]any{"provider": map[string]any{"aws": map[string]any{"service": "SecretsManager", "region": e.Cfg.S3.Region, "role": e.Cfg.Admission.PlatformSecretsRole}}}}
				}},
				{"an ExternalSecret through another store", "externalsecrets", "a workload's ExternalSecret reads through the platform's store", externalSecret("secret-other-store", func(s map[string]any, e *Env) {
					s["secretStoreRef"] = map[string]any{"name": "conformance-secret-store"}
				})},
				{"an ExternalSecret through a generator", "externalsecrets", "a workload's ExternalSecret names no other store and no generator in its data", externalSecret("secret-generator", func(s map[string]any, e *Env) {
					delete(s, "data")
					s["dataFrom"] = []any{map[string]any{"sourceRef": map[string]any{"generatorRef": map[string]any{
						"apiVersion": "generators.external-secrets.io/v1alpha1", "kind": "STSSessionToken", "name": "conformance-generator"}}}}
				})},
				{"a platform key through the platform's store", "externalsecrets", "a workload's ExternalSecret reads only keys under", externalSecret("secret-platform-key", func(s map[string]any, e *Env) {
					s["data"] = []any{map[string]any{"secretKey": "k", "remoteRef": map[string]any{"key": "platform/keycloak/okta-broker"}}}
				})},
				{"another namespace's key", "externalsecrets", "a workload's ExternalSecret reads only keys under", externalSecret("secret-other-namespace", func(s map[string]any, e *Env) {
					s["data"] = []any{map[string]any{"secretKey": "k", "remoteRef": map[string]any{"key": "workloads/" + e.Cfg.Admission.ForeignNamespace + "/x"}}}
				})},
				{"a search", "externalsecrets", "a workload's ExternalSecret names its keys; it never searches for them", externalSecret("secret-find", func(s map[string]any, e *Env) {
					delete(s, "data")
					s["dataFrom"] = []any{map[string]any{"find": map[string]any{"name": map[string]any{"regexp": ".*"}}}}
				})},
			},
			allowed: []admissionObject{{"the workload's own key through the platform's store", "externalsecrets", "", externalSecret("secret-own", nil)}},
		},
	}
}

func parentRef(name, ns, section string) map[string]any {
	p := map[string]any{"group": "gateway.networking.k8s.io", "kind": "Gateway", "name": name, "namespace": ns}
	if section != "" {
		p["sectionName"] = section
	}
	return p
}

// routeRules is one rule per path prefix, each to the Service svc.
func routeRules(svc string, prefixes ...string) []any {
	out := make([]any, 0, len(prefixes))
	for _, p := range prefixes {
		out = append(out, map[string]any{
			"matches":     []any{map[string]any{"path": map[string]any{"type": "PathPrefix", "value": p}}},
			"backendRefs": []any{map[string]any{"name": svc, "port": 8080}},
		})
	}
	return out
}

// labelled is obj with its workload label naming another workload.
func labelled(obj func(e *Env) map[string]any, workload func(c *Config) string) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		o := obj(e)
		o["metadata"].(map[string]any)["labels"] = map[string]any{e.Cfg.Admission.WorkloadLabel: workload(e.Cfg)}
		return o
	}
}

func ownMCPTargets(e *Env) map[string]any {
	wl := e.Cfg.Admission.Workload
	return map[string]any{"targets": []any{map[string]any{"name": wl, "static": map[string]any{"backendRef": map[string]any{"name": wl}, "port": 8080, "path": "/mcp"}}}}
}

// keySet is a RemoteJWKS naming Keycloak's key-set backend in ns: the
// platform's own is in the developer deployment's namespace, gateway
// (charts/platform-gateway), named for the issuer's host.
func keySet(e *Env, ns string) map[string]any {
	host, path := e.Cfg.Issuers.Keycloak, e.Cfg.KeycloakJWKS
	if u, err := url.Parse(host); err == nil {
		host, _, _ = strings.Cut(u.Hostname(), ".")
	}
	if u, err := url.Parse(path); err == nil {
		path = u.Path
	}
	return map[string]any{"backendRef": map[string]any{"group": "agentgateway.dev", "kind": "AgentgatewayBackend", "namespace": ns, "name": host + "-jwks"}, "jwksPath": path}
}

// inlineKeySet is a key set of one P-256 key, made for the run: the keys a
// workload would choose.
func inlineKeySet() string {
	k, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		panic(err)
	}
	jwk, err := jose.PublicJWK(&k.PublicKey, "conformance-inline", "ES256")
	if err != nil {
		panic(err)
	}
	b, _ := json.Marshal(jose.JWKS{Keys: []jose.JWK{jwk}})
	return string(b)
}

// mcpAuthBackend is the workload's MCP backend with MCP authentication of
// its own, for its own route, which gateway-policy-floor admits; mutate
// breaks one clause.
func mcpAuthBackend(name string, mutate func(auth map[string]any, e *Env)) func(e *Env) map[string]any {
	return backend(name, func(e *Env) map[string]any {
		auth := map[string]any{"mode": "Strict", "issuer": e.Cfg.Issuers.Keycloak,
			"audiences": []any{e.Cfg.RouteURL("gateway/mcp/" + e.Cfg.Admission.Workload)}, "jwks": keySet(e, "gateway")}
		if mutate != nil {
			mutate(auth, e)
		}
		return map[string]any{"mcp": ownMCPTargets(e), "policies": map[string]any{"mcp": map[string]any{"authentication": auth}}}
	})
}

// externalSecret reads the workload's own key through the platform's
// store, which secret-stores admits; mutate breaks one clause.
func externalSecret(name string, mutate func(spec map[string]any, e *Env)) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		spec := map[string]any{
			"secretStoreRef": map[string]any{"name": "secrets-manager", "kind": "SecretStore"},
			"target":         map[string]any{"name": "conformance-" + name},
			"data": []any{map[string]any{"secretKey": "k",
				"remoteRef": map[string]any{"key": "workloads/" + e.Cfg.Admission.Namespace + "/conformance", "property": "p"}}},
		}
		if mutate != nil {
			mutate(spec, e)
		}
		return map[string]any{"apiVersion": "external-secrets.io/v1", "kind": "ExternalSecret", "metadata": meta(e, name, nil), "spec": spec}
	}
}

func helmOwnershipCase(c *C) {
	e := c.Env
	dir, err := os.MkdirTemp("", "conformance-helm-")
	if err != nil {
		c.Fatalf("%v", err)
	}
	defer os.RemoveAll(dir)
	write := func(rel, text string) {
		p := filepath.Join(dir, rel)
		os.MkdirAll(filepath.Dir(p), 0o755)
		if err := os.WriteFile(p, []byte(text), 0o644); err != nil {
			c.Fatalf("%v", err)
		}
	}
	write("Chart.yaml", "apiVersion: v2\nname: conformance-helm-ownership\nversion: 0.1.0\n")
	write("templates/configmap.yaml", "apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: {{ .Release.Name }}\ndata: {a: b}\n")
	write("templates/authz.yaml", `{{- if .Values.claimPlatform }}
apiVersion: security.istio.io/v1
kind: AuthorizationPolicy
metadata:
  name: {{ .Release.Name }}
  annotations:
    meta.helm.sh/release-name: network-boundaries
    meta.helm.sh/release-namespace: policy-releases
spec:
  action: ALLOW
  rules:
    - from:
        - source: {namespaces: [conformance-probe]}
{{- end }}
`)
	ns := e.Cfg.Admission.Namespace
	// First, that mesh-floor refuses the same AuthorizationPolicy without
	// the claim, or an install that succeeds says nothing about Helm.
	plain := admissionObject{"the chart's AuthorizationPolicy, without the claim", "authorizationpolicies", "a workload release adds no PeerAuthentication, AuthorizationPolicy", istio("AuthorizationPolicy", "helm-plain", map[string]any{"action": "ALLOW",
		"rules": []any{map[string]any{"from": []any{map[string]any{"source": map[string]any{"namespaces": []any{"conformance-probe"}}}}}}}, false)}
	if !admissionRefused(c, plain, "mesh-floor") {
		c.Fatalf("mesh-floor must refuse a plain AuthorizationPolicy before this case can tell what Helm does")
	}
	helm := func(args ...string) (string, int) {
		out, code, err := e.Run(c, append(append([]string{}, e.Cfg.Admission.Helm...), args...), dir)
		if err != nil {
			c.Fatalf("running helm: %v", err)
		}
		return out, code
	}
	name := "conformance-helm-" + e.RunID
	out, code := helm("install", name, dir, "-n", ns, "--set", "claimPlatform=true", "--wait", "--timeout", "60s")
	if code == 0 {
		helm("uninstall", name, "-n", ns)
		c.Errorf("Helm installed an AuthorizationPolicy that claims policy-releases: Helm kept the chart's annotation, so the rules cannot tell a platform release by it, and the platform's releases must move to a deploy account of their own (design/gateway.md, \"Bypass prevention\")")
	} else if !strings.Contains(out, "mesh-floor") {
		c.Errorf("the install failed, but not by mesh-floor: %s", strings.TrimSpace(out))
		helm("uninstall", name, "-n", ns)
	} else {
		c.Logf("refused by mesh-floor: Helm wrote the release's own namespace over the chart's")
		helm("uninstall", name, "-n", ns)
	}
	out, code = helm("install", name+"-twin", dir, "-n", ns, "--wait", "--timeout", "60s")
	if code != 0 {
		c.Errorf("allowed twin: the same chart without the AuthorizationPolicy did not install: %s", strings.TrimSpace(out))
	}
	helm("uninstall", name+"-twin", "-n", ns)
}

func awsCase(c *C) {
	e := c.Env
	out, code, err := e.Run(c, e.Cfg.AWS.Allowed, "")
	if err != nil || code != 0 {
		c.Errorf("allowed twin: Bedrock as the gateway's role failed (exit %d, %v): %s", code, err, strings.TrimSpace(out))
	}
	for who, cmd := range e.Cfg.AWS.Refused {
		out, code, err := e.Run(c, cmd, "")
		switch {
		case err != nil:
			c.Errorf("%s: %v", who, err)
		case code == 0:
			c.Errorf("%s invoked Bedrock: want AccessDenied", who)
		case !strings.Contains(out, "AccessDenied"):
			c.Errorf("%s failed, but not with AccessDenied: %s", who, strings.TrimSpace(out))
		default:
			c.Logf("%s: AccessDenied", who)
		}
	}
}

// AdmissionFixture is one object the admission cases dry-run, with the
// rule that must refuse it, or "" for an allowed twin. Exported so the
// objects can be checked against the rendered rules without a cluster
// (kyverno apply, in environments' charts/kyverno-rules).
type AdmissionFixture struct {
	Rule   string
	Clause string // the refusing clause's text after "<Rule>: "
	What   string
	Plural string
	Object map[string]any
}

// AdmissionFixtures lists the admission cases' objects for e's
// configuration.
func AdmissionFixtures(e *Env) []AdmissionFixture {
	var out []AdmissionFixture
	for _, r := range append(admissionRules(), kagentAdmissionRules()...) {
		for _, o := range r.refused {
			out = append(out, AdmissionFixture{Rule: r.refuser(), Clause: o.clause, What: o.what, Plural: o.plural, Object: o.obj(e)})
		}
		for _, o := range r.allowed {
			out = append(out, AdmissionFixture{What: o.what, Plural: o.plural, Object: o.obj(e)})
		}
	}
	return out
}
