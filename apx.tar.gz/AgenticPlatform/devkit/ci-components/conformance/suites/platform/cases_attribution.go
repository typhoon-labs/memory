package platform

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"math/big"
	"net/http"
	"strconv"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
)

// attributionCase: attribution comes from the token, never from what the
// caller sets, and the usage record's cost is the price catalog's
// (plan/local-build.md, "B3 in detail", The checks; design/observability.md,
// "Audit and usage records"). The runner sends one model request as the
// developer, with a fresh traceparent and forged attribution: x-team and
// x-user-id headers and a baggage entry naming another team and user.
// Within usage_table.wait, the usage table must hold exactly one row with
// the request's trace ID, and that row the token's jti, sub and team, the
// alias asked for and the provider model it maps to, the fake model
// server's own count of the request's tokens, and a cost that is exactly
// those counts at the price overlay's rates.
func attributionCase(c *C) {
	e := c.Env
	route := "gateway/v1"
	tok := token(c, RoleDeveloper, route)
	cl := claims(c, tok)
	sub, team, jti := str(cl["sub"]), str(cl["team"]), str(cl["jti"])
	if sub == "" || team == "" || jti == "" {
		c.Fatalf("the developer's token lacks sub, team or jti (%q, %q, %q): nothing to attribute to", sub, team, jti)
	}
	alias := e.alias()
	mapped := e.Cfg.Models.Aliases[alias]
	traceID, parent := randomHex(16), randomHex(8)
	const forgedTeam, forgedUser = "conformance-forged-team", "conformance-forged-user"
	marker := e.Marker("attribution")
	o := e.callModel(c, e.Runner, route, tok, alias, marker, map[string]string{
		"traceparent": "00-" + traceID + "-" + parent + "-01",
		"x-team":      forgedTeam, "x-agentic-team": forgedTeam,
		"x-user-id": forgedUser, "x-forwarded-user": forgedUser,
		"baggage": "user.team=" + forgedTeam + ",user.id=" + forgedUser,
	})
	if !expectThrough(c, "a model call with forged attribution", o, o.Kind == outcome.Response && o.Status == http.StatusOK) {
		return
	}
	recs, err := e.fakeModelRecords(c, marker)
	if err != nil {
		c.Fatalf("%v", err)
	}
	if len(recs) != 1 {
		c.Fatalf("want the fake model server's one record of %s, got %d", marker, len(recs))
	}
	fake := recs[0]
	c.Logf("trace %s, jti %s; the fake model server counted %d input and %d output tokens for %s", traceID, jti, fake.InputTokens, fake.OutputTokens, fake.Model)

	var rows []map[string]any
	var readErr error
	poll(c, e.Cfg.UsageTable.Wait.Duration, func() bool {
		rows, readErr = e.usageRows(c, traceID)
		return readErr == nil && len(rows) > 0
	})
	if readErr != nil {
		c.Fatalf("%v", readErr)
	}
	if len(rows) == 0 {
		c.Fatalf("no row in the usage table has trace_id %s after %s: the request's usage record never arrived", traceID, e.Cfg.UsageTable.Wait.Duration)
	}
	if len(rows) != 1 {
		c.Errorf("the usage table holds %d rows with trace_id %s, want exactly one: one request must be billed once", len(rows), traceID)
	}
	row := rows[0]
	check := func(column, want, what string) {
		if got := str(row[column]); got != want {
			c.Errorf("the usage record's %s is %q, want %q (%s)", column, got, want, what)
		}
	}
	check("token_jti", jti, "the token's jti")
	check("user_id", sub, "the token's sub, not the forged x-user-id or baggage: attribution did not come from the token")
	check("user_team", team, "the token's team, not the forged x-team or baggage: attribution did not come from the token")
	check("record_source", "platform", "stamped by the collector's platform port")
	check("original_model", alias, "the alias asked for")
	check("request_model", mapped, "the provider model the alias maps to")
	if fake.Model != mapped {
		c.Errorf("the fake model server received model %q for alias %s, want %q", fake.Model, alias, mapped)
	}
	check("input_tokens", strconv.Itoa(fake.InputTokens), "the fake model server's count")
	check("output_tokens", strconv.Itoa(fake.OutputTokens), "the fake model server's count")

	want, err := nanoCost(fake.InputTokens, fake.OutputTokens, e.Cfg.Prices.Input, e.Cfg.Prices.Output)
	if err != nil {
		c.Fatalf("%v", err)
	}
	gotText := str(row["cost_total"])
	got, ok := new(big.Rat).SetString(gotText)
	switch {
	case gotText == "" || !ok:
		c.Errorf("the usage record has no cost (cost_total %q): the price catalog did not price %s", gotText, mapped)
	case new(big.Rat).Mul(got, big.NewRat(1e9, 1)).Cmp(new(big.Rat).SetInt(want)) != 0:
		c.Errorf("the usage record's cost is %s, want exactly %s: %d input and %d output tokens at %v and %v dollars a million",
			gotText, new(big.Rat).SetFrac(want, big.NewInt(1e9)).FloatString(9), fake.InputTokens, fake.OutputTokens, e.Cfg.Prices.Input, e.Cfg.Prices.Output)
	}
	if strings.Contains(strings.ToLower(fmt.Sprint(row)), "conformance-forged") {
		c.Errorf("the usage record holds the forged attribution: %v", row)
	}
}

// nanoCost is the cost in nano-dollars, the usage table's resolution, of
// tokens at prices in dollars per million, rounded to the nearest; the
// prices are taken as the decimals they were written as.
func nanoCost(in, out int, priceIn, priceOut float64) (*big.Int, error) {
	rat := func(p float64) (*big.Rat, error) {
		r, ok := new(big.Rat).SetString(strconv.FormatFloat(p, 'f', -1, 64))
		if !ok {
			return nil, fmt.Errorf("prices: %v is not a decimal", p)
		}
		return r, nil
	}
	pi, err := rat(priceIn)
	if err != nil {
		return nil, err
	}
	po, err := rat(priceOut)
	if err != nil {
		return nil, err
	}
	total := new(big.Rat).Add(new(big.Rat).Mul(big.NewRat(int64(in), 1), pi), new(big.Rat).Mul(big.NewRat(int64(out), 1), po))
	total.Mul(total, big.NewRat(1000, 1)) // dollars a million tokens to nano-dollars a token
	q, r := new(big.Int).QuoRem(total.Num(), total.Denom(), new(big.Int))
	if new(big.Int).Mul(r, big.NewInt(2)).CmpAbs(total.Denom()) >= 0 {
		q.Add(q, big.NewInt(1))
	}
	return q, nil
}

// randomHex is n random bytes in hex: a trace or span ID.
func randomHex(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}
