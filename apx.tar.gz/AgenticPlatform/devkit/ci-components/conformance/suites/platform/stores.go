package platform

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

// The platform's stores, as the cases read them: whole, with Env.Read, and
// with credentials only in headers, never in a URL or a message.

// secretFile reads a credential mounted from a Secret.
func (e *Env) secretFile(setting, path string) (string, error) {
	raw, err := os.ReadFile(e.Cfg.Path(path))
	if err != nil {
		return "", fmt.Errorf("%s: %v", setting, err)
	}
	s := strings.TrimSpace(string(raw))
	if s == "" {
		return "", fmt.Errorf("%s: %s is empty", setting, path)
	}
	return s, nil
}

// usageRows are the usage table's rows with one trace ID, as JSON objects,
// numbers kept as written: ClickHouse quotes 64-bit integers by default
// and writes decimals bare.
func (e *Env) usageRows(c *C, traceID string) ([]map[string]any, error) {
	u := e.Cfg.UsageTable
	password, err := e.secretFile("usage_table.password_file", u.PasswordFile)
	if err != nil {
		return nil, err
	}
	// The table's name comes from the configuration; the trace ID goes as
	// a query parameter, never into the SQL.
	query := fmt.Sprintf("SELECT * FROM %s.%s WHERE trace_id = {trace:String} FORMAT JSONEachRow", ident(u.Database), ident(u.Table))
	q := url.Values{"param_trace": {traceID}}
	resp, err := e.Read.Do(c, http.MethodPost, u.URL+"/?"+q.Encode(),
		map[string]string{"X-ClickHouse-User": u.User, "X-ClickHouse-Key": password, "Content-Type": "text/plain"}, []byte(query))
	if err != nil {
		return nil, fmt.Errorf("querying the usage table: %v", err)
	}
	if resp.Status != http.StatusOK {
		return nil, fmt.Errorf("querying the usage table: HTTP %d: %s", resp.Status, short(resp.Body))
	}
	var rows []map[string]any
	sc := bufio.NewScanner(bytes.NewReader(resp.Body))
	sc.Buffer(make([]byte, 1<<20), 16<<20)
	for sc.Scan() {
		line := bytes.TrimSpace(sc.Bytes())
		if len(line) == 0 {
			continue
		}
		dec := json.NewDecoder(bytes.NewReader(line))
		dec.UseNumber()
		var row map[string]any
		if err := dec.Decode(&row); err != nil {
			return nil, fmt.Errorf("the usage table's answer is not JSON lines: %v", err)
		}
		rows = append(rows, row)
	}
	return rows, sc.Err()
}

// ident quotes a ClickHouse identifier.
func ident(s string) string { return "`" + strings.ReplaceAll(s, "`", "``") + "`" }

// short is the start of a body, for messages.
func short(b []byte) string {
	s := strings.TrimSpace(string(b))
	if len(s) > 300 {
		s = s[:300] + "…"
	}
	return s
}

// poll calls f until it reports done or timeout passes, at most every
// interval, a twentieth of the timeout between 10 milliseconds and 2
// seconds. It reports whether f was done.
func poll(c *C, timeout time.Duration, f func() bool) bool {
	if c.Env.Settle != nil {
		// A stand-in that signals delivery: once everything sent to it is
		// delivered, f's answer is final, whatever the timeout, which
		// bounds a wait on a cluster only. The stand-in bounds its own
		// signal, as a backstop.
		if f() {
			return true
		}
		if err := c.Env.Settle(c); err != nil {
			c.Logf("the stand-in did not settle: %v", err)
		}
		return f()
	}
	every := min(max(timeout/20, 10*time.Millisecond), 2*time.Second)
	deadline := time.Now().Add(timeout)
	for {
		if f() {
			return true
		}
		if !time.Now().Before(deadline) {
			return false
		}
		c.Sleep(min(every, time.Until(deadline)+time.Millisecond))
	}
}

// str is a JSON value as text: a string as itself, a number as written.
func str(v any) string {
	switch x := v.(type) {
	case nil:
		return ""
	case string:
		return x
	case json.Number:
		return x.String()
	}
	return fmt.Sprint(v)
}
