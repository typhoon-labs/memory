package standin

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"regexp"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// destination is a host and port in the stand-in network, with the
// layers in front of it, as network-boundaries renders them.
type destination struct {
	meshed bool // a sidecar in front, STRICT unless permissive
	// permissive is a meshed port that takes plaintext too: PERMISSIVE at
	// port level, as the collector's general ports are from B4.
	permissive bool
	np         func(from string) bool // NetworkPolicy admits the source, on both sides
	authz      func(principal string) bool
	external   bool // outside the cluster
}

func only(names ...string) func(string) bool {
	return func(s string) bool {
		for _, n := range names {
			if s == n {
				return true
			}
		}
		return false
	}
}

func anyone(string) bool { return true }

// emitters are the principals the collector's platform port admits.
var emitters = only("gateway/gateway", "workloads-gateway/workloads-gateway", "delegation-sts/delegation-sts", "keycloak/okta-reconciler")

// The matrix the bypass suite relies on: each case's source is admitted by
// every layer but the one under test.
var destinations = map[string]destination{
	"gateway." + Domain + ":443":           {np: anyone},
	"workloads-gateway." + Domain + ":443": {np: only("runner")},
	// Substrate's listener: Substrate's egress alone, none of the suites'
	// sources (K7).
	"workloads-gateway." + Domain + ":8443": {np: only()},
	// kagent's controller: the gateways, Substrate's egress and its UI
	// alone, none of the suites' sources (K1).
	"kagent-controller.kagent.svc.cluster.local:8083": {np: only()},
	"keycloak." + Domain + ":443":                     {np: anyone},
	// capture-mcp's MCP port admits the gateways in the mesh; NetworkPolicy
	// lets both probes through, so the mesh is what refuses them.
	"capture-mcp.conformance.svc.cluster.local:8080": {meshed: true, np: only("probe-meshed", "probe-nomesh"), authz: only()},
	"capture-mcp.conformance.svc.cluster.local:9090": {meshed: true, np: only("runner"), authz: only("conformance/conformance-runner")},
	// The sidecar does not intercept 15021: only NetworkPolicy stands there.
	"capture-mcp-pods.conformance.svc.cluster.local:15021": {np: only()},
	"fake-model.fake-model.svc.cluster.local:8080":         {meshed: true, np: only(), authz: only()},
	"fake-model.fake-model.svc.cluster.local:9090":         {meshed: true, np: only("runner", "probe-meshed"), authz: only("conformance/conformance-runner")},
	// The collector's general port, PERMISSIVE from B4 for kagent and
	// Substrate: NetworkPolicy admits the meshed governed namespaces (and
	// Substrate's and the agent namespaces, which play no part here), and
	// any principal or none.
	"collector.telemetry.svc.cluster.local:4318": {meshed: true, permissive: true, np: only("runner", "probe-meshed"), authz: anyone},
	// Its platform port: the platform's emitters alone, and the meshed
	// probe through NetworkPolicy, so that the sidecar refuses it.
	"collector.telemetry.svc.cluster.local:4319":  {meshed: true, np: only("probe-meshed"), authz: emitters},
	"bedrock-runtime.us-east-1.amazonaws.com:443": {np: only("runner"), external: true},
	"gitlab.com:443": {np: only("runner"), external: true},
}

// network is a source in the stand-in network.
type network struct {
	w         *World
	from      string
	principal string
	meshed    bool
}

func hostPort(u *url.URL) string {
	if u.Port() != "" {
		return u.Host
	}
	if u.Scheme == "https" {
		return u.Host + ":443"
	}
	return u.Host + ":80"
}

func (n *network) Do(ctx context.Context, r outcome.Request) outcome.Outcome {
	u, err := url.Parse(r.URL)
	if err != nil {
		return outcome.Outcome{Kind: outcome.Error, Error: err.Error()}
	}
	addr := hostPort(u)
	d, ok := destinations[addr]
	if !ok {
		return outcome.Outcome{Kind: outcome.DNS, Error: "no such host " + addr}
	}
	f := n.w.F
	mesh := outcome.Of(n.w.Cfg.Timing.MeshConnectTimeout.Duration)
	if d.external && n.meshed && f.MeshBlocksEgress {
		return outcome.Outcome{Kind: outcome.Reset, Elapsed: 3, Error: "connection reset by peer"}
	}
	if d.external && f.NoInternet {
		if n.meshed {
			return outcome.Outcome{Kind: outcome.Reset, Elapsed: mesh, Error: "EOF"}
		}
		return outcome.Outcome{Kind: outcome.Timeout, Elapsed: r.Connect, Error: "dial tcp: i/o timeout"}
	}
	np := d.np
	switch {
	case f.GeneralPortsAnyGoverned && addr == "collector.telemetry.svc.cluster.local:4318":
		np = anyone // B3's rule: every governed namespace, meshed or not
	case f.PlatformPortClosedToProbe && addr == "collector.telemetry.svc.cluster.local:4319":
		np = only()
	case f.ListenerOpen && addr == "workloads-gateway."+Domain+":8443":
		np = anyone
	}
	if !np(n.from) && !f.NoNetworkPolicy {
		if n.meshed {
			if u.Scheme == "http" {
				return outcome.Outcome{Kind: outcome.Response, Status: http.StatusServiceUnavailable, Elapsed: mesh,
					Body: "upstream connect error or disconnect/reset before headers. reset reason: connection timeout"}
			}
			return outcome.Outcome{Kind: outcome.Reset, Elapsed: mesh, Error: "EOF"}
		}
		return outcome.Outcome{Kind: outcome.Timeout, Elapsed: r.Connect, Error: "dial tcp: i/o timeout"}
	}
	if d.meshed {
		principal := n.principal
		if !n.meshed {
			if !f.PermissiveMTLS && !d.permissive {
				return outcome.Outcome{Kind: outcome.Reset, Elapsed: 2, Error: "read: connection reset by peer"}
			}
			principal = ""
		}
		admitted := d.authz == nil || d.authz(principal) || (f.PlatformPortOpen && addr == "collector.telemetry.svc.cluster.local:4319")
		if !admitted && !f.NoAuthorizationPolicy {
			return outcome.Outcome{Kind: outcome.Response, Status: http.StatusForbidden, Body: outcome.RBACBody, Elapsed: 2,
				Header: map[string]string{"content-type": "text/plain"}}
		}
	}
	return n.w.direct().Do(ctx, r)
}

// rfc1123Subdomain is the form the API server requires of most objects'
// names (k8s.io/apimachinery's IsDNS1123Subdomain), length apart.
var rfc1123Subdomain = regexp.MustCompile(`^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$`)

// apiServer plays the admission answers for the bypass suite's dry runs:
// a script of design/gateway.md's rules by object name, not Kyverno. Each
// object the suites dry-run is refused by the rule and clause they expect
// of it (platform.AdmissionFixtures), and any other by its name's prefix.
func (w *World) apiServer() http.Handler {
	// By name and Helm's release namespace: platform-crds' twin is its
	// refused CRD from a platform release.
	key := func(name, release string) string { return name + " " + release }
	expected := map[string]platform.AdmissionFixture{}
	for _, f := range platform.AdmissionFixtures(&platform.Env{Cfg: w.Cfg}) {
		m := f.Object["metadata"].(map[string]any)
		name, _ := m["name"].(string)
		ann, _ := m["annotations"].(map[string]any)
		release, _ := ann["meta.helm.sh/release-namespace"].(string)
		expected[key(name, release)] = f
	}
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		var obj struct {
			Kind     string `json:"kind"`
			Metadata struct {
				Name        string            `json:"name"`
				Labels      map[string]string `json:"labels"`
				Annotations map[string]string `json:"annotations"`
			} `json:"metadata"`
			Spec struct {
				ParentRefs []struct {
					Name string `json:"name"`
				} `json:"parentRefs"`
				Policies struct {
					MCP struct {
						Authentication json.RawMessage `json:"authentication"`
					} `json:"mcp"`
				} `json:"policies"`
			} `json:"spec"`
		}
		json.Unmarshal(raw, &obj)
		status := func(code int, reason, msg string) {
			rw.Header().Set("Content-Type", "application/json")
			rw.WriteHeader(code)
			json.NewEncoder(rw).Encode(map[string]any{"kind": "Status", "apiVersion": "v1", "status": "Failure", "reason": reason, "message": msg, "code": code})
		}
		if r.Method == http.MethodGet && strings.HasPrefix(r.URL.Path, "/apis/api.kagent.dev/") {
			w.agent(rw, r)
			return
		}
		if r.Method == http.MethodGet {
			w.pods(rw, r)
			return
		}
		if r.URL.Query().Get("dryRun") != "All" {
			status(http.StatusBadRequest, "BadRequest", "the stand-in takes dry runs only")
			return
		}
		// As the API server, before any admission: an object's name is a
		// lowercase RFC 1123 subdomain.
		if n := obj.Metadata.Name; len(n) > 253 || !rfc1123Subdomain.MatchString(n) {
			status(http.StatusUnprocessableEntity, "Invalid", fmt.Sprintf(`%s %q is invalid: metadata.name: Invalid value: %q: a lowercase RFC 1123 subdomain must consist of lower case alphanumeric characters, '-' or '.', and must start and end with an alphanumeric character`, obj.Kind, n, n))
			return
		}
		if w.F.RBACForbidden {
			status(http.StatusForbidden, "Forbidden", fmt.Sprintf(`%s %q is forbidden: User "system:serviceaccount:conformance:conformance-runner" cannot create resource`, strings.ToLower(obj.Kind), obj.Metadata.Name))
			return
		}
		name := strings.TrimPrefix(obj.Metadata.Name, "conformance-")
		rule, clause := "", "refused by the stand-in"
		if f, ok := expected[key(obj.Metadata.Name, obj.Metadata.Annotations["meta.helm.sh/release-namespace"])]; ok {
			rule = f.Rule
			if f.Clause != "" {
				clause = f.Clause
			}
		} else {
			switch {
			case obj.Kind == "CustomResourceDefinition":
				if obj.Metadata.Annotations["meta.helm.sh/release-namespace"] != "platform-crds" {
					rule = "platform-crds"
				}
			case strings.HasSuffix(name, "-own"), name == "mesh-platform":
			case name == "route-backend-ns", strings.HasPrefix(name, "backend-"), name == "model":
				rule = "backend-targets"
			case strings.HasPrefix(name, "route-"):
				rule = "route-claims"
			case strings.HasPrefix(name, "policy-"):
				rule = "gateway-policy-floor"
			case strings.HasPrefix(name, "mesh-"), strings.HasPrefix(name, "helm-"):
				rule, clause = "mesh-floor", "a workload release adds no PeerAuthentication, AuthorizationPolicy, DestinationRule, ServiceEntry, VirtualService, Sidecar or EnvoyFilter"
			}
		}
		// Faults that refuse a kind of object the rules admit, each an
		// allowed twin's.
		workload := obj.Metadata.Labels[w.Cfg.Admission.WorkloadLabel]
		switch {
		case rule != "":
		case w.F.RefusePolicies && obj.Kind == "AgentgatewayPolicy":
			rule = "backend-targets"
		case w.F.RefuseApprovalsPath && obj.Kind == "HTTPRoute" && strings.Contains(string(raw), `"/approvals/`):
			rule = "route-claims"
		case w.F.RefuseOtherLabels && workload != "" && workload != w.Cfg.Admission.Workload:
			rule = "route-claims"
			if obj.Kind != "HTTPRoute" {
				rule = "gateway-policy-floor"
			}
		case w.F.RefuseBackendMCPAuth && obj.Kind == "AgentgatewayBackend" && len(obj.Spec.Policies.MCP.Authentication) > 0:
			rule = "gateway-policy-floor"
		case w.F.RefuseWorkloadsGatewayRoutes && obj.Kind == "HTTPRoute" && len(obj.Spec.ParentRefs) > 0 && obj.Spec.ParentRefs[0].Name == "workloads-gateway":
			rule = "route-claims"
		case w.F.RefuseExternalSecrets && obj.Kind == "ExternalSecret":
			rule = "secret-stores"
		case w.F.RefusePods && obj.Kind == "Pod":
			rule = "sandbox-privileges"
		case w.F.RefuseKagentConfigs && (obj.Kind == "ModelConfig" || obj.Kind == "RemoteMCPServer"):
			rule = "kagent-floor"
		}
		if rule == "" || w.F.NoKyverno {
			rw.Header().Set("Content-Type", "application/json")
			rw.WriteHeader(http.StatusCreated)
			rw.Write(raw)
			return
		}
		if w.F.WrongRule {
			rule = "some-other-rule"
		}
		if w.F.WrongClause {
			clause = "a clause the case does not test"
		}
		status(http.StatusBadRequest, "BadRequest", fmt.Sprintf(`admission webhook "vpol.validate.kyverno.svc-fail" denied the request: Policy %s failed: %s: %s`, rule, rule, clause))
	})
}

// pods lists the pods the kagent group reads: the fixture agent's worker,
// in its namespace, and atelet, in Substrate's, each on the sandbox node.
func (w *World) pods(rw http.ResponseWriter, r *http.Request) {
	k := w.Cfg.Kagent
	type pod struct{ ns, selector, name string }
	var items []any
	for _, p := range []pod{{k.Agent, k.WorkerLabel + "=" + k.Agent, k.Agent + "-worker-0"}, {k.Namespace, k.AteletSelector, "atelet-0"}} {
		if r.URL.Path != "/api/v1/namespaces/"+p.ns+"/pods" || r.URL.Query().Get("labelSelector") != p.selector {
			continue
		}
		spec := map[string]any{"nodeSelector": map[string]any{"agentic-platform/pool": "sandbox"}}
		if w.F.WorkerOffSandbox && p.ns == k.Agent {
			spec = map[string]any{}
		}
		items = append(items, map[string]any{"metadata": map[string]any{"name": p.name, "namespace": p.ns}, "spec": spec, "status": map[string]any{"phase": "Running"}})
	}
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(map[string]any{"kind": "PodList", "items": items})
}

// agent answers the kagent agent's Agent, as the profile reads it: not
// Ready, its golden actor crashing, as on a kernel without
// CONFIG_NFT_REDIR; Ready with ActorReady.
func (w *World) agent(rw http.ResponseWriter, r *http.Request) {
	k := w.Cfg.Kagent
	if r.URL.Path != "/apis/api.kagent.dev/v1alpha3/namespaces/"+k.Agent+"/agents/"+k.Agent {
		http.Error(rw, `{"kind":"Status","reason":"NotFound","code":404}`, http.StatusNotFound)
		return
	}
	ready := map[string]any{"type": "Ready", "status": "False", "reason": "ActorTemplateRetrying", "message": "golden build failed (GoldenActorCrashed), retry 83"}
	if w.F.ActorReady {
		ready = map[string]any{"type": "Ready", "status": "True", "reason": "Ready", "message": "the golden actor is ready"}
	}
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(map[string]any{"kind": "Agent", "metadata": map[string]any{"name": k.Agent, "namespace": k.Agent},
		"status": map[string]any{"conditions": []any{ready}}})
}
