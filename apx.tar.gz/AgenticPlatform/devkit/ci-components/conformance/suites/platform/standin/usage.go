package standin

import (
	"encoding/json"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"strconv"
	"strings"
	"sync"
)

// usageTable plays the usage table's ClickHouse over HTTP: the rows the
// materialized view would write into llm_requests from the gateway's
// records, served to its reader only, as JSONEachRow with 64-bit integers
// quoted and decimals bare, as ClickHouse writes them by default. It
// answers only the query shape the cases send: rows by trace ID, given as
// the query parameter trace.
type usageTable struct {
	mu       sync.Mutex
	rows     []map[string]any
	password string
}

func (u *usageTable) add(row map[string]any) {
	u.mu.Lock()
	u.rows = append(u.rows, row)
	u.mu.Unlock()
}

func (u *usageTable) handler() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if r.Header.Get("X-ClickHouse-User") != "usage_reader" || r.Header.Get("X-ClickHouse-Key") != u.password {
			http.Error(rw, "Code: 516. DB::Exception: usage_reader: Authentication failed. (AUTHENTICATION_FAILED)", http.StatusUnauthorized)
			return
		}
		sql, _ := io.ReadAll(r.Body)
		trace := r.URL.Query().Get("param_trace")
		if !strings.Contains(string(sql), "FROM `platform_usage`.`llm_requests` WHERE trace_id = {trace:String}") || trace == "" {
			http.Error(rw, "Code: 497. DB::Exception: the stand-in answers only rows by trace ID. (ACCESS_DENIED)", http.StatusForbidden)
			return
		}
		u.mu.Lock()
		defer u.mu.Unlock()
		for _, row := range u.rows {
			if row["trace_id"] != trace {
				continue
			}
			out := map[string]any{}
			for k, v := range row {
				switch x := v.(type) {
				case int:
					out[k] = strconv.Itoa(x) // UInt64, quoted
				case *big.Rat:
					out[k] = json.Number(strings.TrimRight(strings.TrimRight(x.FloatString(9), "0"), "."))
				default:
					out[k] = v
				}
			}
			b, _ := json.Marshal(out)
			fmt.Fprintf(rw, "%s\n", b)
		}
	})
}

// usageRow is the materialized view's row for a gateway's record of a
// model request, with the record's fields as agentgateway and the
// gateway's CEL write them.
func (w *World) usageRow(r *http.Request, claims map[string]any, traceID, alias, mapped string, in, out int) map[string]any {
	f := w.F
	team, _ := claims["team"].(string)
	user, _ := claims["sub"].(string)
	if f.AttributionFromHeader && r.Header.Get("x-team") != "" {
		team = r.Header.Get("x-team")
	}
	if f.TeamFromBaggage {
		for _, kv := range strings.Split(r.Header.Get("baggage"), ",") {
			if k, v, ok := strings.Cut(strings.TrimSpace(kv), "="); ok && k == "user.team" {
				team = v
			}
		}
	}
	if f.UserFromHeader && r.Header.Get("x-user-id") != "" {
		user = r.Header.Get("x-user-id")
	}
	if f.UsageUnmappedModel {
		mapped = alias
	}
	if f.UsageWrongTokens {
		out++
	}
	price := func(p float64) *big.Rat {
		r, _ := new(big.Rat).SetString(strconv.FormatFloat(p, 'f', -1, 64))
		return r
	}
	cost := new(big.Rat).Add(new(big.Rat).Mul(big.NewRat(int64(in), 1), price(w.Cfg.Prices.Input)), new(big.Rat).Mul(big.NewRat(int64(out), 1), price(w.Cfg.Prices.Output)))
	cost.Quo(cost, big.NewRat(1e6, 1))
	if f.WrongCost {
		cost.Mul(cost, big.NewRat(2, 1))
	}
	return map[string]any{
		"trace_id": traceID, "event_name": "gateway.request", "record_source": "platform", "gateway": "gateway", "route": "v1",
		"user_id": user, "user_team": team, "session_id": claims["sid"], "client_id": claims["client_id"], "token_jti": claims["jti"],
		"original_model": alias, "request_model": mapped, "response_model": mapped, "provider": "anthropic", "operation": "chat",
		"input_tokens": in, "output_tokens": out, "cache_read_input_tokens": 0, "cache_creation_input_tokens": 0,
		"cost_total": cost, "status_code": 200,
	}
}
