package standin

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// telemetry plays B3's telemetry (plan/local-build.md, "B3 in detail"):
// the collector's two tiers as one, with the Dynatrace branch's span
// metrics, tail sampling, content deletion and redaction, and the Langfuse
// branch's sampling and redaction; the gateway's records on the platform
// port; and what they reach: the Dynatrace and SIEM stand-ins' output, the
// audit bucket and Langfuse's event bucket on floci, and Langfuse's API.
// The usage table is usage.go's.
type telemetry struct {
	w  *World
	mu sync.Mutex
	// sinks are the stand-ins' output lines, by container, and rotated how
	// many of them the kubelet has rotated away.
	sinks   map[string][]kube.LogLine
	rotated map[string]int
	// traces are tail sampling's buffers, by trace ID; pending counts
	// those not yet decided.
	traces  map[string]*sampled
	pending int
	// buckets are floci's objects, by bucket and key.
	buckets map[string]map[string][]byte
	// observations are Langfuse's, by trace ID.
	observations map[string][]map[string]any
	keys         [2]string // Langfuse's public and secret keys
}

type sampled struct {
	spans     []rspan
	decided   bool
	dynatrace bool // kept by the Dynatrace branch
	langfuse  bool // kept by the Langfuse branch
}

// rspan is a span as received, with its resource's attributes.
type rspan struct {
	resource []any
	span     map[string]any
}

func newTelemetry(w *World) *telemetry {
	return &telemetry{w: w, sinks: map[string][]kube.LogLine{}, rotated: map[string]int{}, traces: map[string]*sampled{},
		buckets:      map[string]map[string][]byte{"agentic-audit-local": {}, "agentic-langfuse-events-local": {}},
		observations: map[string][]map[string]any{}, keys: [2]string{"pk-lf-" + jose.RandomID(8), "sk-lf-" + jose.RandomID(8)}}
}

// Lines implements platform.Logs: what a stand-in printed and the kubelet
// has not rotated away, whatever since says: each world is fresh. With
// SinkLogRotates the log rotates after every read, as a kubelet's does
// when its stand-in prints faster than the suites read.
func (t *telemetry) Lines(_ context.Context, namespace, selector, container string, _ time.Time) ([]kube.LogLine, error) {
	if namespace != "telemetry-sink" || selector != "app.kubernetes.io/name=telemetry-sink" {
		return nil, fmt.Errorf("GET pods: no pods match %s in %s", selector, namespace)
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	out := append([]kube.LogLine(nil), t.sinks[container][t.rotated[container]:]...)
	if t.w.F.SinkLogRotates {
		t.rotated[container] = len(t.sinks[container])
	}
	return out, nil
}

// records plays the stand-ins' records store (environments'
// charts/telemetry-sink, records.py): every line a stand-in received,
// whatever the kubelet rotated, since the store serves its rotated files
// too, and then a line the collector is still writing, cut short.
func (t *telemetry) records() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		sink := strings.TrimPrefix(r.URL.Path, "/")
		if r.Method != http.MethodGet || (sink != "siem" && sink != "dynatrace") {
			http.NotFound(rw, r)
			return
		}
		if s := r.URL.Query().Get("since"); s != "" {
			if _, err := strconv.ParseFloat(s, 64); err != nil {
				http.Error(rw, "since is not a number", http.StatusBadRequest)
				return
			}
		}
		if t.w.F.RecordsStoreDown {
			http.Error(rw, "upstream connect error or disconnect/reset before headers", http.StatusServiceUnavailable)
			return
		}
		t.mu.Lock()
		lines := append([]kube.LogLine(nil), t.sinks[sink]...)
		t.mu.Unlock()
		if t.w.F.RecordsDropNewest && sink == "siem" && len(lines) > 0 {
			lines = lines[:len(lines)-1]
		}
		rw.Header().Set("Content-Type", "application/x-ndjson")
		for _, l := range lines {
			io.WriteString(rw, l.Text+"\n")
		}
		io.WriteString(rw, `{"resourceLogs":[{"resource":{"attributes":[`)
	})
}

func (t *telemetry) print(container string, v any) {
	b, _ := json.Marshal(v)
	t.sinks[container] = append(t.sinks[container], kube.LogLine{Pod: "telemetry-sink-0", Time: time.Now(), Text: string(b)})
}

// The platform's secret patterns, as pipelines.yaml names them.
var secretPatterns = []*regexp.Regexp{
	regexp.MustCompile(`\b(AKIA|ASIA)[0-9A-Z]{16}\b`),
	regexp.MustCompile(`\bgl(pat|rt)-[0-9A-Za-z_.-]{20,}`),
	regexp.MustCompile(`\beyJ[0-9A-Za-z_-]+\.eyJ[0-9A-Za-z_-]+\.[0-9A-Za-z_-]*`),
	regexp.MustCompile(`-----BEGIN[A-Z ]* PRIVATE KEY-----[\s\S]*?-----END[A-Z ]* PRIVATE KEY-----`),
	regexp.MustCompile(`(?i)\b(bearer|basic|api-token)\s+[0-9A-Za-z._~+/=-]{8,}`),
}

// narrowPatterns are patterns too narrow: a token's prefix and a JWT's
// header alone.
var narrowPatterns = []*regexp.Regexp{regexp.MustCompile(`\bgl(pat|rt)-`), regexp.MustCompile(`\beyJ[0-9A-Za-z_-]+`)}

var contentKeys = map[string]bool{"gen_ai.input.messages": true, "gen_ai.output.messages": true, "gen_ai.system_instructions": true,
	"gen_ai.tool.call.arguments": true, "gen_ai.tool.call.result": true, "gen_ai.prompt": true, "gen_ai.completion": true}

// workloadLogs plays a general port's log records (B5): each stamped
// record.source workload, over the sender's value, on to the SIEM and the
// audit bucket, never the usage table.
func (t *telemetry) workloadLogs(raw []byte) error {
	var doc struct {
		ResourceLogs []struct {
			Resource  map[string]any `json:"resource"`
			ScopeLogs []struct {
				Scope      map[string]any   `json:"scope"`
				LogRecords []map[string]any `json:"logRecords"`
			} `json:"scopeLogs"`
		} `json:"resourceLogs"`
	}
	if err := json.Unmarshal(raw, &doc); err != nil {
		return err
	}
	f := t.w.F
	t.mu.Lock()
	defer t.mu.Unlock()
	for _, rl := range doc.ResourceLogs {
		for _, sl := range rl.ScopeLogs {
			for _, rec := range sl.LogRecords {
				if !f.WorkloadKeepsSource {
					var attrs []any
					for _, a := range list(rec["attributes"]) {
						if kv, _ := a.(map[string]any); kv["key"] != "record.source" {
							attrs = append(attrs, a)
						}
					}
					rec["attributes"] = append(attrs, kvJSON("record.source", "workload"))
				}
				t.print("siem", map[string]any{"resourceLogs": []any{map[string]any{"resource": rl.Resource,
					"scopeLogs": []any{map[string]any{"scope": sl.Scope, "logRecords": []any{rec}}}}}})
				if f.WorkloadRecordsToUsage {
					t.w.usage.add(map[string]any{"trace_id": fmt.Sprint(rec["traceId"]), "user_id": attrJSON(rec["attributes"], "user.id"),
						"team": attrJSON(rec["attributes"], "user.team"), "record_source": "workload"})
				}
			}
		}
	}
	return nil
}

// collector is the general port's OTLP over HTTP: traces only, as JSON.
func (t *telemetry) collector() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && r.URL.Path == "/v1/logs" {
			raw, _ := io.ReadAll(r.Body)
			if err := t.workloadLogs(raw); err != nil {
				http.Error(rw, err.Error(), http.StatusBadRequest)
				return
			}
			rw.Header().Set("Content-Type", "application/json")
			io.WriteString(rw, `{"partialSuccess":{}}`)
			return
		}
		if r.Method != http.MethodPost || r.URL.Path != "/v1/traces" {
			http.Error(rw, "404 page not found", http.StatusNotFound)
			return
		}
		raw, _ := io.ReadAll(r.Body)
		if err := t.receive(raw); err != nil {
			http.Error(rw, err.Error(), http.StatusBadRequest)
			return
		}
		rw.Header().Set("Content-Type", "application/json")
		io.WriteString(rw, `{"partialSuccess":{}}`)
	})
}

// receive takes an export: span metrics at once, then each trace into its
// buffer until its decision.
func (t *telemetry) receive(raw []byte) error {
	var doc struct {
		ResourceSpans []struct {
			Resource struct {
				Attributes []any `json:"attributes"`
			} `json:"resource"`
			ScopeSpans []struct {
				Spans []map[string]any `json:"spans"`
			} `json:"scopeSpans"`
		} `json:"resourceSpans"`
	}
	if err := json.Unmarshal(raw, &doc); err != nil {
		return err
	}
	f := t.w.F
	t.mu.Lock()
	defer t.mu.Unlock()
	for _, rs := range doc.ResourceSpans {
		for _, ss := range rs.ScopeSpans {
			for _, s := range ss.Spans {
				if !f.NoSpanMetrics {
					t.print("dynatrace", map[string]any{"resourceMetrics": []any{map[string]any{"resource": map[string]any{"attributes": rs.Resource.Attributes},
						"scopeMetrics": []any{map[string]any{"scope": map[string]any{"name": "spanmetricsconnector"}, "metrics": []any{map[string]any{
							"name": "traces.span.metrics.calls", "sum": map[string]any{"dataPoints": []any{map[string]any{"asInt": "1",
								"attributes": []any{kvJSON("service.name", attr(rs.Resource.Attributes, "service.name")), kvJSON("span.name", s["name"])}}}}}}}}}}})
				}
				id, _ := s["traceId"].(string)
				tr := t.traces[id]
				if tr == nil {
					tr = &sampled{}
					t.traces[id] = tr
					t.pending++ // until its decision, which Settle waits for
					after := t.w.Cfg.Telemetry.Waits.Decision.Duration / 2
					if f.LateDecisions {
						after += 5 * time.Second
					}
					time.AfterFunc(after, func() { t.decide(id) })
				}
				sp := rspan{resource: rs.Resource.Attributes, span: s}
				if tr.decided {
					t.export(tr, []rspan{sp}) // a late span takes the cached decision
				} else {
					tr.spans = append(tr.spans, sp)
				}
			}
		}
	}
	return nil
}

// decide is tail sampling's decision on a trace: the Dynatrace branch keeps
// errors (and, here, nothing of the rest), the Langfuse branch every trace
// with a span that carries gen_ai.operation.name.
func (t *telemetry) decide(id string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	tr := t.traces[id]
	f := t.w.F
	for _, sp := range tr.spans {
		if st, _ := sp.span["status"].(map[string]any); fmt.Sprint(st["code"]) == "2" && !f.NoErrorPolicy {
			tr.dynatrace = true
		}
		if attrJSON(sp.span["attributes"], "gen_ai.operation.name") != "" {
			tr.langfuse = true
		}
	}
	tr.langfuse = (tr.langfuse || f.LangfuseKeepsAll) && !f.NoLangfuseExport
	tr.decided = true
	t.export(tr, tr.spans)
	tr.spans = nil
	t.pending--
}

// settleBound is the backstop of Settle: a decision is due after half the
// decision wait, so only a stand-in that has stopped deciding takes it.
const settleBound = time.Minute

// Settle returns once every trace the collector has received is decided
// and exported, with the sinks, Langfuse, the buckets and the usage
// table written: everything else the stand-in does, it does before it
// answers the request that caused it. A case that has had its answers
// therefore finds everything it caused delivered, however late a loaded
// runner fires the decisions' timers.
func (t *telemetry) Settle(ctx context.Context) error {
	ctx, cancel := context.WithTimeout(ctx, settleBound)
	defer cancel()
	for {
		t.mu.Lock()
		n := t.pending
		t.mu.Unlock()
		if n == 0 {
			return nil
		}
		select {
		case <-ctx.Done():
			return fmt.Errorf("%d traces still undecided: %w", n, ctx.Err())
		case <-time.After(5 * time.Millisecond):
		}
	}
}

func (t *telemetry) export(tr *sampled, spans []rspan) {
	f := t.w.F
	if tr.dynatrace {
		var out []rspan
		for _, sp := range spans {
			s := clone(sp.span)
			if !f.DynatraceKeepsContent {
				s["attributes"] = dropKeys(s["attributes"])
				var events []any
				for _, ev := range list(s["events"]) {
					e, _ := ev.(map[string]any)
					if strings.HasPrefix(fmt.Sprint(e["name"]), "gen_ai.") {
						continue
					}
					e["attributes"] = dropKeys(e["attributes"])
					events = append(events, e)
				}
				s["events"] = events
			}
			if !f.NoErrorScrub {
				scrubErrors(s, f.ErrorScrubDropsType)
			}
			out = append(out, rspan{sp.resource, redact(s, secretPatterns, false)})
		}
		t.print("dynatrace", traces(out))
	}
	if tr.langfuse {
		patterns := secretPatterns
		if f.NarrowSecretPatterns {
			patterns = narrowPatterns
		}
		var out []rspan
		for _, sp := range spans {
			s := clone(sp.span)
			if f.LangfuseDropsContent {
				s["attributes"] = dropKeys(s["attributes"])
				s["events"] = nil
			}
			if !f.LangfuseNoRedaction {
				s = redact(s, patterns, f.LangfuseStatusUnmasked)
			}
			out = append(out, rspan{sp.resource, s})
		}
		body, _ := json.Marshal(traces(out)["resourceSpans"])
		now := time.Now().UTC()
		t.buckets["agentic-langfuse-events-local"]["otel/conformance/"+now.Format("2006/01/02/15/04")+"/"+jose.RandomID(8)+".json"] = body
		for _, sp := range out {
			t.observe(sp.resource, sp.span)
		}
	}
}

// scrubErrors plays the Dynatrace branch's error scrub (B5): an error's
// message may quote a prompt, as a provider's error does, so the
// exception events' exception.message and exception.stacktrace and the
// span status's description go; exception.type, error.type and the status
// code stay. dropType, a fault, deletes those too.
func scrubErrors(s map[string]any, dropType bool) {
	if st, ok := s["status"].(map[string]any); ok {
		delete(st, "message")
	}
	drop := map[string]bool{"exception.message": true, "exception.stacktrace": true}
	if dropType {
		drop["exception.type"], drop["error.type"], drop["http.response.status_code"] = true, true, true
	}
	keep := func(attrs any) []any {
		var out []any
		for _, a := range list(attrs) {
			if kv, _ := a.(map[string]any); !drop[fmt.Sprint(kv["key"])] {
				out = append(out, a)
			}
		}
		return out
	}
	s["attributes"] = keep(s["attributes"])
	for _, ev := range list(s["events"]) {
		if e, ok := ev.(map[string]any); ok {
			e["attributes"] = keep(e["attributes"])
		}
	}
}

// observe is Langfuse's mapping of a span to an observation, as Langfuse
// 4 shows it (checked against the platform's on 2026-11-18): its input
// and output from, in order, the GenAI conventions' operation-details
// event, the messages attributes, a tool call's arguments and result; a
// span with gen_ai.tool.name is a TOOL observation named by the tool, not
// by the span, and a model call's a GENERATION; the metadata holds the
// span's attributes as attributes.<key>, its resource's as
// resourceAttributes.<key> and its scope as scope.name.
func (t *telemetry) observe(resource []any, s map[string]any) {
	var input, output string
	for _, ev := range list(s["events"]) {
		e, _ := ev.(map[string]any)
		if e["name"] == "gen_ai.client.inference.operation.details" {
			input = attrJSON(e["attributes"], "gen_ai.input.messages")
		}
	}
	if input == "" {
		input, output = attrJSON(s["attributes"], "gen_ai.input.messages"), attrJSON(s["attributes"], "gen_ai.output.messages")
	}
	if input == "" && output == "" {
		input, output = attrJSON(s["attributes"], "gen_ai.tool.call.arguments"), attrJSON(s["attributes"], "gen_ai.tool.call.result")
	}
	meta := map[string]string{"scope.name": "conformance"}
	for _, a := range list(s["attributes"]) {
		kv, _ := a.(map[string]any)
		if k := fmt.Sprint(kv["key"]); !contentKeys[k] {
			meta["attributes."+k] = attrJSON([]any{kv}, k)
		}
	}
	for _, a := range resource {
		kv, _ := a.(map[string]any)
		k := fmt.Sprint(kv["key"])
		meta["resourceAttributes."+k] = attrJSON([]any{kv}, k)
	}
	name, typ := s["name"], "SPAN"
	switch op := attrJSON(s["attributes"], "gen_ai.operation.name"); {
	case attrJSON(s["attributes"], "gen_ai.tool.name") != "":
		name, typ = attrJSON(s["attributes"], "gen_ai.tool.name"), "TOOL"
	case op == "chat" || op == "generate_content" || op == "text_completion":
		typ = "GENERATION"
	}
	trace := fmt.Sprint(s["traceId"])
	level, status := "DEFAULT", ""
	if st, _ := s["status"].(map[string]any); fmt.Sprint(st["code"]) == "2" {
		level = "ERROR"
		status, _ = st["message"].(string)
	}
	t.observations[trace] = append(t.observations[trace], map[string]any{
		"id": s["spanId"], "traceId": trace, "parentObservationId": s["parentSpanId"], "projectId": "conformance",
		"type": typ, "name": name, "input": nullable(input), "output": nullable(output), "metadata": meta,
		"level": level, "statusMessage": nullable(status),
		"modelId": nil, "inputPrice": nil, "outputPrice": nil, "totalPrice": nil})
}

// langfuse plays Langfuse 4's public API, its observations by trace, with
// input and output only when the io field group is asked for, as 4.81.0
// defaults to the core and basic groups.
func (t *telemetry) langfuse() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		want := "Basic " + base64.StdEncoding.EncodeToString([]byte(t.keys[0]+":"+t.keys[1]))
		if r.Header.Get("Authorization") != want {
			rw.WriteHeader(http.StatusUnauthorized)
			io.WriteString(rw, `{"message":"Invalid credentials"}`)
			return
		}
		if r.URL.Path != "/api/public/v2/observations" {
			rw.WriteHeader(http.StatusNotFound)
			io.WriteString(rw, `{"message":"not found"}`)
			return
		}
		io := strings.Contains(","+r.URL.Query().Get("fields")+",", ",io,")
		t.mu.Lock()
		data := []map[string]any{}
		for _, o := range t.observations[r.URL.Query().Get("traceId")] {
			c := map[string]any{}
			for k, v := range o {
				if io || (k != "input" && k != "output") {
					c[k] = v
				}
			}
			data = append(data, c)
		}
		t.mu.Unlock()
		rw.Header().Set("Content-Type", "application/json")
		json.NewEncoder(rw).Encode(map[string]any{"data": data, "meta": map[string]any{}})
	})
}

// floci plays S3's ListObjectsV2 and GetObject, path style, for signed
// requests.
func (t *telemetry) floci() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if !strings.HasPrefix(r.Header.Get("Authorization"), "AWS4-HMAC-SHA256 Credential=test/") || r.Header.Get("X-Amz-Date") == "" {
			http.Error(rw, "<Error><Code>AccessDenied</Code></Error>", http.StatusForbidden)
			return
		}
		bucket, key, _ := strings.Cut(strings.TrimPrefix(r.URL.Path, "/"), "/")
		t.mu.Lock()
		defer t.mu.Unlock()
		objs, ok := t.buckets[bucket]
		if !ok {
			http.Error(rw, "<Error><Code>NoSuchBucket</Code></Error>", http.StatusNotFound)
			return
		}
		if key != "" {
			body, ok := objs[key]
			if !ok {
				http.Error(rw, "<Error><Code>NoSuchKey</Code></Error>", http.StatusNotFound)
				return
			}
			rw.Write(body)
			return
		}
		type content struct {
			Key          string `xml:"Key"`
			LastModified string `xml:"LastModified"`
			Size         int    `xml:"Size"`
		}
		var res struct {
			XMLName     xml.Name  `xml:"ListBucketResult"`
			Contents    []content `xml:"Contents"`
			IsTruncated bool      `xml:"IsTruncated"`
		}
		var keys []string
		for k := range objs {
			if strings.HasPrefix(k, r.URL.Query().Get("prefix")) {
				keys = append(keys, k)
			}
		}
		sort.Strings(keys)
		for _, k := range keys {
			res.Contents = append(res.Contents, content{k, time.Now().UTC().Format(time.RFC3339), len(objs[k])})
		}
		xml.NewEncoder(rw).Encode(res)
	})
}

// gatewayTelemetry is what the developer deployment sends of a model
// request under a caller's traceparent: its span, to a general port, and
// its record, on the platform port, to the SIEM, the audit bucket and, a
// model request's, the usage table.
func (w *World) gatewayTelemetry(r *http.Request, prompt []byte, claims map[string]any, alias, mapped string, in, out int) {
	parts := strings.Split(r.Header.Get("traceparent"), "-")
	if len(parts) != 4 {
		return
	}
	trace, parent := parts[1], parts[2]
	f := w.F
	if !f.GatewayNoTracing && parts[3] == "01" {
		id := make([]byte, 8)
		rand.Read(id)
		span := map[string]any{"traceId": trace, "spanId": hex.EncodeToString(id), "parentSpanId": parent, "name": "POST /v1/messages", "kind": 2,
			"startTimeUnixNano": fmt.Sprint(time.Now().UnixNano()), "endTimeUnixNano": fmt.Sprint(time.Now().UnixNano()),
			"attributes": []any{kvJSON("gen_ai.operation.name", "chat"), kvJSON("gen_ai.request.model", mapped), kvJSON("user.team", claims["team"])}}
		body, _ := json.Marshal(traces([]rspan{{resource: []any{kvJSON("service.name", "agentgateway")}, span: span}}))
		w.tel.receive(body)
	}
	attrs := []any{kvJSON("event.name", "gateway.request"), kvJSON("user.id", claims["sub"]), kvJSON("user.team", claims["team"]),
		kvJSON("token.jti", claims["jti"]), kvJSON("agw.ai.original_model", alias), kvJSON("gen_ai.request.model", mapped), kvJSON("record.source", "platform")}
	if f.PlatformStampedWorkload {
		attrs[len(attrs)-1] = kvJSON("record.source", "workload")
	}
	if f.RecordCarriesPrompt {
		attrs = append(attrs, kvJSON("gen_ai.prompt", string(prompt)))
	}
	record := map[string]any{"resourceLogs": []any{map[string]any{"resource": map[string]any{"attributes": []any{kvJSON("service.name", "agentgateway")}},
		"scopeLogs": []any{map[string]any{"scope": map[string]any{}, "logRecords": []any{map[string]any{
			"timeUnixNano": fmt.Sprint(time.Now().UnixNano()), "traceId": trace, "spanId": parent, "attributes": attrs}}}}}}}
	t := w.tel
	t.mu.Lock()
	t.print("siem", record)
	if !f.NoAuditExport {
		// One gzip object a batch under a prefix per minute, with no
		// Content-Encoding of its own.
		var z bytes.Buffer
		zw := gzip.NewWriter(&z)
		json.NewEncoder(zw).Encode(record)
		zw.Close()
		now := time.Now().UTC()
		t.buckets["agentic-audit-local"]["records/"+now.Format("year=2006/month=01/day=02/hour=15/minute=04")+"/logs_"+jose.RandomID(6)+".json.gz"] = z.Bytes()
	}
	t.mu.Unlock()
	if !f.NoUsageRecord {
		row := w.usageRow(r, claims, trace, alias, mapped, in, out)
		w.usage.add(row)
		if f.UsageTwice {
			w.usage.add(row)
		}
	}
}

// --- OTLP JSON as generic values --------------------------------------

func traces(spans []rspan) map[string]any {
	var rs []any
	for _, sp := range spans {
		rs = append(rs, map[string]any{"resource": map[string]any{"attributes": sp.resource},
			"scopeSpans": []any{map[string]any{"scope": map[string]any{}, "spans": []any{sp.span}}}})
	}
	return map[string]any{"resourceSpans": rs}
}

func kvJSON(key string, v any) map[string]any {
	return map[string]any{"key": key, "value": map[string]any{"stringValue": fmt.Sprint(v)}}
}

func list(v any) []any { l, _ := v.([]any); return l }

// attrJSON is the string value of the attribute key in a JSON attribute
// list.
func attrJSON(attrs any, key string) string {
	for _, a := range list(attrs) {
		kv, _ := a.(map[string]any)
		if kv["key"] == key {
			v, _ := kv["value"].(map[string]any)
			s, _ := v["stringValue"].(string)
			return s
		}
	}
	return ""
}

func attr(attrs []any, key string) string { return attrJSON(attrs, key) }

func dropKeys(attrs any) []any {
	var out []any
	for _, a := range list(attrs) {
		kv, _ := a.(map[string]any)
		if !contentKeys[fmt.Sprint(kv["key"])] {
			out = append(out, a)
		}
	}
	return out
}

// redact masks every match of patterns in the string values of a span's
// attributes and its events' attributes, as the redaction processor does.
func redact(s map[string]any, patterns []*regexp.Regexp, statusUnmasked bool) map[string]any {
	mask := func(attrs any) {
		for _, a := range list(attrs) {
			kv, _ := a.(map[string]any)
			v, _ := kv["value"].(map[string]any)
			if str, ok := v["stringValue"].(string); ok {
				for _, p := range patterns {
					str = p.ReplaceAllString(str, "****")
				}
				v["stringValue"] = str
			}
		}
	}
	mask(s["attributes"])
	for _, ev := range list(s["events"]) {
		e, _ := ev.(map[string]any)
		mask(e["attributes"])
	}
	// The status's description too, where a provider's error may quote a
	// secret (the platform's Langfuse branch from B5), unless a fault.
	if st, ok := s["status"].(map[string]any); ok && !statusUnmasked {
		if str, ok := st["message"].(string); ok {
			for _, p := range patterns {
				str = p.ReplaceAllString(str, "****")
			}
			st["message"] = str
		}
	}
	return s
}

func clone(m map[string]any) map[string]any {
	b, _ := json.Marshal(m)
	var out map[string]any
	json.Unmarshal(b, &out)
	return out
}

func nullable(s string) any {
	if s == "" {
		return nil
	}
	return s
}

// TelemetryAgent is the stand-in's agent that plays the telemetry group's
// turn (platform.TelemetryAgent), at gateway/a2a/<TelemetryAgent>, as
// reference-agent does: its spans under the caller's traceparent, a model
// request through the gateway, and a tool call whose result names the
// argument the fake model's directive gives it.
const TelemetryAgent = "telemetry-agent"

var directiveArg = regexp.MustCompile(`arg\.[A-Za-z0-9_-]+=([^\s\]]+)`)

func (w *World) telemetryAgent(rw http.ResponseWriter, r *http.Request, raw []byte) {
	var req struct {
		ID     json.RawMessage `json:"id"`
		Params struct {
			Message struct {
				Parts []struct {
					Text string `json:"text"`
				} `json:"parts"`
			} `json:"message"`
		} `json:"params"`
	}
	json.Unmarshal(raw, &req)
	var text string
	for _, p := range req.Params.Message.Parts {
		text += p.Text
	}
	trace := randomHexS(16)
	if parts := strings.Split(r.Header.Get("traceparent"), "-"); len(parts) == 4 && !w.F.AgentOwnTrace {
		trace = parts[1]
	}
	arg := ""
	if m := directiveArg.FindStringSubmatch(text); m != nil {
		arg = m[1]
	}
	root, tool, model := randomHexS(8), randomHexS(8), randomHexS(8)
	t0 := time.Now()
	body, _ := json.Marshal(map[string]any{"model": "reasoning-default", "max_tokens": 64, "messages": []map[string]any{{"role": "user", "content": text}}})
	w.direct().Do(r.Context(), outcome.Request{Method: http.MethodPost, URL: "https://gateway." + Domain + "/v1/messages", Body: string(body), Header: map[string]string{
		"Authorization": "Bearer " + w.personaToken(platform.RoleDeveloper, w.Cfg.RouteURL("gateway/v1")), "Content-Type": "application/json",
		"anthropic-version": "2023-06-01", "traceparent": "00-" + trace + "-" + model + "-01"}})
	t1 := time.Now()
	msgs, _ := json.Marshal([]any{map[string]any{"role": "user", "parts": []any{map[string]any{"type": "text", "content": text}}}})
	ms := time.Millisecond
	spans := []otlp.Span{
		{TraceID: trace, SpanID: root, Name: "invoke_agent telemetry_agent", Kind: otlp.KindInternal, Start: t0, End: t1.Add(30 * ms),
			Attributes: otlp.KVs("gen_ai.operation.name", "invoke_agent", "gen_ai.agent.name", "telemetry_agent"), Error: "limit_exceeded: model_calls"},
		{TraceID: trace, SpanID: model, ParentSpanID: root, Name: "generate_content reasoning-default", Kind: otlp.KindClient, Start: t0, End: t1,
			Attributes: otlp.KVs("gen_ai.operation.name", "generate_content", "gen_ai.request.model", "reasoning-default", "gen_ai.input.messages", string(msgs))},
		{TraceID: trace, SpanID: tool, ParentSpanID: root, Name: "execute_tool get_note", Kind: otlp.KindInternal, Start: t1, End: t1.Add(10 * ms),
			Attributes: otlp.KVs("gen_ai.operation.name", "execute_tool", "gen_ai.tool.name", "get_note",
				"gen_ai.tool.call.arguments", `{"note_id":"`+arg+`"}`, "gen_ai.tool.call.result", "No note "+arg+".")},
	}
	w.tel.receive(otlp.Traces(otlp.KVs("service.name", TelemetryAgent), "stand-in", spans))
	// Its tool's audit record, in the same trace, on a general port, as
	// reference-mcp's: stamped workload there, never the gateway's.
	w.tel.workloadLogs(otlp.Logs(otlp.KVs("service.name", "notes-mcp"), "stand-in", []otlp.Record{{TraceID: trace, SpanID: tool, Time: t1,
		Body: "tool.call", Attributes: otlp.KVs("event.name", "tool.call", "gen_ai.tool.name", "get_note")}}))
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(map[string]any{"jsonrpc": "2.0", "id": req.ID, "result": map[string]any{"task": map[string]any{
		"id": randomHexS(8), "contextId": randomHexS(8), "status": map[string]any{"state": "TASK_STATE_FAILED"}}}})
}

func randomHexS(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return hex.EncodeToString(b)
}
