// Package standin is a stand-in platform for the platform-controls suites'
// own tests: two gateway deployments, an issuer for persona tokens, an STS,
// the fixtures (the real capture-mcp and relay-agent, in process), a
// network that plays NetworkPolicy, STRICT mTLS and AuthorizationPolicy
// from the matrix network-boundaries renders, and an API server that plays
// the admission rules' answers.
//
// None of it is the platform: it is a script of the right answers, with
// Faults that each break one property, so the tests can show that every
// case passes on the right answers and fails, for the right reason, on a
// wrong one. That a case detects wrong behaviour here does not show that
// the platform passes it; only a run against the cluster shows that.
package standin

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	relayagent "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/relay-agent"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/s3"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// Faults break one property of the stand-in each.
type Faults struct {
	// The gateway's token checks.
	AcceptAlgNone     bool // accepts an unsigned token
	AcceptHS256       bool // accepts HS256 keyed with the issuer's public key
	NoSignatureCheck  bool // accepts any signature, any key
	IgnoreTyp         bool
	AcceptMultiAud    bool // accepts a token whose aud list holds the route among others
	NoProfileRules    bool // has neither T22 rule: typ and alg, one audience
	IgnoreAud         bool
	IgnoreExp         bool
	IgnoreNbf         bool
	Status403For401   bool // refuses bad tokens with 403
	ChainOnDeveloper  bool // the developer deployment accepts STS chain tokens
	PersonOnWorkloads bool // the hosted-workloads deployment accepts Keycloak tokens
	// The gateway's CEL.
	SkipRoleCheck        bool
	SkipTeamCheck        bool
	IgnoreOutermostActor bool
	PassUnknownModel     bool // forwards a model name that is no alias
	PassNonLLMPath       bool // forwards any path under the model route
	ListProviderModels   bool // /v1/models lists the providers' names too
	NoToolFilter         bool // shows and forwards the platform-only tool
	// The gateway's upstream calls.
	ForwardModelToken bool // the model route keeps the caller's Authorization
	DropModelHeaders  bool // the model route drops anthropic-beta and traceparent
	DropMCPToken      bool // the MCP route strips the token tools re-verify
	// Limits and records.
	LimitWindowCrossed    bool // not a fault: the limited team's window starts crossed and resets in a second
	LimitWindowLong       bool // the limited team's window starts crossed and resets in an hour
	TestIssuerInLimitTeam bool // the test issuer's tokens claim the limited persona's team
	NoLimit               bool
	NoRetryAfter          bool
	LimitAllTeams         bool // one counter for every team
	AttributionFromHeader bool // the usage record takes the team from x-team
	TeamFromBaggage       bool // the usage record takes the team from the baggage header
	UserFromHeader        bool // the usage record takes the user from x-user-id
	UsageUnmappedModel    bool // the usage record names the alias as the provider model
	UsageWrongTokens      bool // the usage record's output count is not the model's
	UsageTwice            bool // a request is recorded twice
	NoUsageRecord         bool // no record reaches the usage table
	WrongCost             bool
	EarlierModelRecords   bool // not a fault: the fake model server holds more earlier runs' records than outcome.MaxBody
	// Telemetry.
	DynatraceKeepsContent bool // the Dynatrace branch deletes no GenAI content
	NoErrorPolicy         bool // the Dynatrace branch's sampling keeps no error trace
	NoSpanMetrics         bool
	GatewayNoTracing      bool // the gateway sends no spans
	LangfuseNoRedaction   bool // the Langfuse branch masks no secret
	NarrowSecretPatterns  bool // the Langfuse branch's patterns catch a token's prefix and a JWT's header only
	LangfuseDropsContent  bool // the Langfuse branch deletes the content too
	LangfuseKeepsAll      bool // the Langfuse branch keeps traces without a GenAI span
	NoLangfuseExport      bool // nothing reaches Langfuse
	RecordCarriesPrompt   bool // the gateway's record holds the request's prompt
	NoAuditExport         bool // no record reaches the audit bucket
	PlatformPortOpen      bool // the collector's platform port admits any principal
	// The collector's general ports' NetworkPolicy admits every governed
	// namespace, meshed or not, as before B4 made the ports PERMISSIVE.
	GeneralPortsAnyGoverned   bool
	PlatformPortClosedToProbe bool // NetworkPolicy drops the meshed probe at the platform port too
	// Not a fault: the stand-ins' logs rotate after every read, so that a
	// read returns only what they printed since the one before, as the
	// kubelet rotates a busy container's log.
	SinkLogRotates bool
	// Not a fault: no records store, so the stand-ins are read through
	// their pod's log, as before B5.
	NoRecordsStore    bool
	RecordsDropNewest bool // the SIEM stand-in's store serves all but its newest line
	RecordsStoreDown  bool // the records store answers 503
	// The realm and MCP sign-in.
	AnonymousRegistration      bool // the realm registers any client that asks
	GatewayAnswersRegistration bool // the gateway's MCP settings name a client ID it answers registration with
	NoPreRegisteredClient      bool // the realm does not know the MCP client
	// The STS.
	STSWrongActor bool // act.sub names another agent
	// The network.
	NoNetworkPolicy       bool // kindnet on this workstation (T21)
	NoAuthorizationPolicy bool
	PermissiveMTLS        bool
	MeshBlocksEgress      bool // REGISTRY_ONLY: the client's sidecar refuses outside hosts at once
	NoInternet            bool // the runner cannot reach outside either
	// Admission.
	NoKyverno     bool
	RBACForbidden bool // the runner may not create the kinds
	WrongRule     bool // refusals name another rule
	WrongClause   bool // refusals name the rule, but another of its clauses
	// Rules that refuse what they must admit, each an allowed twin's kind.
	RefusePolicies               bool // every AgentgatewayPolicy, by backend-targets
	RefuseApprovalsPath          bool // every HTTPRoute with an approval path
	RefuseOtherLabels            bool // every workload label but admission.workload's
	RefuseBackendMCPAuth         bool // every backend with MCP authentication of its own
	RefuseWorkloadsGatewayRoutes bool // every route on the hosted-workloads deployment
	RefuseExternalSecrets        bool // every ExternalSecret
	HelmKeepsAnnotation          bool
	BedrockOpen                  bool
	// The telemetry group (B5).
	WorkloadKeepsSource    bool // the general port keeps a record's own record.source
	WorkloadRecordsToUsage bool // the general port's records reach the usage table
	AgentOwnTrace          bool // the telemetry agent starts a trace of its own
	// The platform port's records stamped workload, as if they came in
	// on a general port.
	PlatformStampedWorkload bool
	// The Dynatrace branch without the error scrub: exception messages,
	// stack traces and status descriptions kept, a quoted prompt in them.
	NoErrorScrub bool
	// The error scrub deleting the error's type and status code too.
	ErrorScrubDropsType bool
	// The Langfuse branch masking attributes only, as the redaction
	// processor does, not a span status's description.
	LangfuseStatusUnmasked bool
	// Not a fault: tail sampling's decisions five seconds late, past every
	// wait the stand-in's configuration gives, as a loaded runner's timers
	// can fire.
	LateDecisions bool
	// The kagent profile (B5).
	NoRouteLimit bool // the kagent agent's route has no rate limit
	CardT30      bool // the gateway cannot read kagent's card (T30)
	NoCard       bool // kagent serves no card
	ActorReady   bool // the kagent agent's Agent is Ready: an actor runs
	// kagent (B4).
	KagentRouteNoActors bool // the kagent agent's hosted-workloads route names no actor
	ListenerOpen        bool // NetworkPolicy admits the probes to Substrate's listener
	WorkerOffSandbox    bool // the fixture agent's worker runs without the sandbox node's selector
	RefusePods          bool // sandbox-privileges refuses every pod
	RefuseKagentConfigs bool // kagent-floor refuses every ModelConfig and RemoteMCPServer
}

// Domain is the stand-in's platform domain.
const Domain = "agentic.internal"

// World is a running stand-in platform.
type World struct {
	F   Faults
	Cfg *platform.Config

	kcKey, stsKey *rsa.PrivateKey
	stsEC         *ecdsa.PrivateKey
	k8sKey        *ecdsa.PrivateKey
	testKey       *ecdsa.PrivateKey
	ca            *x509.CertPool

	servers map[string]string // host:port -> 127.0.0.1:port
	capture *capturemcp.Server
	fake    *fakeModel
	usage   *usageTable
	tel     *telemetry
	limits  *limits
	// kagentRate is the kagent route's per-person rate limit (the profile).
	kagentRate kagentRate
	dir        string
	closers    []func()
}

// New starts a stand-in world with faults.
func New(f Faults) (*World, error) {
	w := &World{F: f, servers: map[string]string{}, fake: &fakeModel{}, usage: &usageTable{password: jose.RandomID(12)}, limits: &limits{used: map[string]int{}}}
	var err error
	if w.dir, err = os.MkdirTemp("", "standin-"); err != nil {
		return nil, err
	}
	w.kcKey, _ = rsa.GenerateKey(rand.Reader, 2048)
	w.stsEC, _ = ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	w.k8sKey, _ = ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	w.testKey, _ = ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	der, _ := x509.MarshalPKCS8PrivateKey(w.testKey)
	keyFile := filepath.Join(w.dir, "test-issuer.pem")
	os.WriteFile(keyFile, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: der}), 0o600)

	tlsCert, err := w.certificate()
	if err != nil {
		return nil, err
	}
	w.capture = capturemcp.New(0, nil)
	w.Cfg = config(keyFile)
	if !f.NoRecordsStore {
		w.Cfg.Telemetry.Sinks.RecordsURL = "http://telemetry-sink.telemetry-sink.svc.cluster.local:8080"
	}
	w.tel = newTelemetry(w)
	w.Cfg.Langfuse.PublicKeyFile = filepath.Join(w.dir, "langfuse-public-key")
	w.Cfg.Langfuse.SecretKeyFile = filepath.Join(w.dir, "langfuse-secret-key")
	os.WriteFile(w.Cfg.Langfuse.PublicKeyFile, []byte(w.tel.keys[0]), 0o600)
	os.WriteFile(w.Cfg.Langfuse.SecretKeyFile, []byte(w.tel.keys[1]), 0o600)
	w.Cfg.UsageTable.PasswordFile = filepath.Join(w.dir, "usage-reader-password")
	os.WriteFile(w.Cfg.UsageTable.PasswordFile, []byte(w.usage.password+"\n"), 0o600)
	switch {
	case f.LimitWindowCrossed:
		// Crossed already, as by an earlier run, with a second of its
		// window left from the limit case's first request, not from the
		// world's start, which the cases before it may take longer than.
		w.limits.used["conformance"], w.limits.left = w.Cfg.Limits.Tokens, time.Second
	case f.LimitWindowLong:
		w.limits.used["conformance"], w.limits.reset = w.Cfg.Limits.Tokens, time.Now().Add(time.Hour)
	}
	if f.TestIssuerInLimitTeam {
		w.Cfg.TestIssuer.Team = "conformance"
	}
	if f.EarlierModelRecords {
		w.fake.earlierRuns(outcome.MaxBody)
	}

	// TLS: the entry point and the hosts pods reach by their platform names.
	w.serveTLS(tlsCert, "gateway."+Domain+":443", w.gateway("gateway"))
	w.serveTLS(tlsCert, "workloads-gateway."+Domain+":443", w.gateway("workloads-gateway"))
	// Substrate's listener, on its own port: only NetworkPolicy keeps the
	// suites' sources from it (K7).
	w.serveTLS(tlsCert, "workloads-gateway."+Domain+":8443", w.gateway("workloads-gateway"))
	// kagent's controller, which only the gateways and Substrate's egress
	// reach (K1).
	w.serve("kagent-controller.kagent.svc.cluster.local:8083", http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		w.kagent(rw, raw)
	}))
	w.serveTLS(tlsCert, "keycloak."+Domain+":443", w.keycloak())
	sts := w.sts()
	w.serveTLS(tlsCert, "delegation-sts."+Domain+":8443", sts)
	w.serveTLS(tlsCert, "delegation-sts."+Domain+":443", sts)
	// Plain HTTP: the fixtures' ports inside the mesh.
	w.serve("capture-mcp.conformance.svc.cluster.local:8080", w.capture.MCPHandler())
	w.serve("capture-mcp.conformance.svc.cluster.local:9090", w.capture.OpsHandler())
	w.serve("capture-mcp-pods.conformance.svc.cluster.local:15021", http.HandlerFunc(func(rw http.ResponseWriter, _ *http.Request) { rw.WriteHeader(http.StatusOK) }))
	w.serve("fake-model.fake-model.svc.cluster.local:8080", w.fake.model())
	w.serve("fake-model.fake-model.svc.cluster.local:9090", w.fake.ops())
	w.serve("usage-clickhouse-headless.usage.svc.cluster.local:8123", w.usage.handler())
	w.serve("collector.telemetry.svc.cluster.local:4318", w.tel.collector())
	// The platform port is gRPC: a plain HTTP request that reaches it is
	// refused by the collector itself.
	w.serve("collector.telemetry.svc.cluster.local:4319", http.HandlerFunc(func(rw http.ResponseWriter, _ *http.Request) {
		http.Error(rw, "invalid gRPC request content-type", http.StatusUnsupportedMediaType)
	}))
	w.serve("langfuse-web.langfuse.svc.cluster.local:3000", w.tel.langfuse())
	w.serve("telemetry-sink.telemetry-sink.svc.cluster.local:8080", w.tel.records())
	w.serve("floci:4566", w.tel.floci())
	for _, a := range []string{"relay-agent", "outsider-agent"} {
		tokFile := filepath.Join(w.dir, a+".token")
		os.WriteFile(tokFile, []byte(w.actorToken(a)), 0o600)
		agent := &relayagent.Agent{Name: a, TokenEndpoint: "https://delegation-sts." + Domain + ":8443/token", ActorTokenFile: tokFile,
			HTTP: &outcome.Client{Roots: w.ca, Dial: w.dial}}
		w.serve(a+".conformance.svc.cluster.local:8080", agent.Handler())
	}
	outside := http.HandlerFunc(func(rw http.ResponseWriter, _ *http.Request) { rw.WriteHeader(http.StatusForbidden) })
	for _, h := range []string{"bedrock-runtime.us-east-1.amazonaws.com:443", "gitlab.com:443"} {
		w.serveTLS(tlsCert, h, outside)
	}
	return w, nil
}

// Close stops the world.
func (w *World) Close() {
	for _, c := range w.closers {
		c()
	}
	os.RemoveAll(w.dir)
}

func (w *World) serve(host string, h http.Handler) {
	s := httptest.NewServer(h)
	w.servers[host] = strings.TrimPrefix(s.URL, "http://")
	w.closers = append(w.closers, s.Close)
}

func (w *World) serveTLS(cert tls.Certificate, host string, h http.Handler) {
	s := httptest.NewUnstartedServer(h)
	s.TLS = &tls.Config{Certificates: []tls.Certificate{cert}}
	s.StartTLS()
	w.servers[host] = strings.TrimPrefix(s.URL, "https://")
	w.closers = append(w.closers, s.Close)
}

// dial maps a platform host and port to its local server.
func (w *World) dial(ctx context.Context, network, addr string) (net.Conn, error) {
	local, ok := w.servers[addr]
	if !ok {
		return nil, &net.DNSError{Err: "no such host", Name: addr, IsNotFound: true}
	}
	var d net.Dialer
	return d.DialContext(ctx, network, local)
}

// direct makes a request with no layer in the way.
func (w *World) direct() *outcome.Client { return &outcome.Client{Roots: w.ca, Dial: w.dial} }

func (w *World) certificate() (tls.Certificate, error) {
	caKey, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	ca := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "stand-in CA"}, NotBefore: time.Now().Add(-time.Hour),
		NotAfter: time.Now().Add(24 * time.Hour), IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign}
	caDER, err := x509.CreateCertificate(rand.Reader, ca, ca, &caKey.PublicKey, caKey)
	if err != nil {
		return tls.Certificate{}, err
	}
	caCert, _ := x509.ParseCertificate(caDER)
	w.ca = x509.NewCertPool()
	w.ca.AddCert(caCert)
	leafKey, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	leaf := &x509.Certificate{SerialNumber: big.NewInt(2), Subject: pkix.Name{CommonName: "stand-in"}, NotBefore: time.Now().Add(-time.Hour),
		NotAfter: time.Now().Add(24 * time.Hour), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		DNSNames: []string{"gateway." + Domain, "workloads-gateway." + Domain, "keycloak." + Domain, "delegation-sts." + Domain, "bedrock-runtime.us-east-1.amazonaws.com", "gitlab.com"}}
	leafDER, err := x509.CreateCertificate(rand.Reader, leaf, caCert, &leafKey.PublicKey, caKey)
	if err != nil {
		return tls.Certificate{}, err
	}
	return tls.Certificate{Certificate: [][]byte{leafDER}, PrivateKey: leafKey}, nil
}

func config(testKeyFile string) *platform.Config {
	c := &platform.Config{PlatformDomain: Domain, Cluster: "agentic-local", RunnerMeshed: true}
	c.Routes = map[string]platform.Route{
		"gateway/v1":                        {Kind: "model", Scope: "models", Roles: []string{"developer", "incident-manager", "platform-engineer"}},
		"gateway/mcp/capture-mcp":           {Kind: "mcp", Scope: "mcp/capture-mcp", Roles: []string{"developer", "platform-engineer"}},
		"gateway/a2a/relay-agent":           {Kind: "a2a", Scope: "a2a/relay-agent", Roles: []string{"developer", "platform-engineer"}},
		"gateway/a2a/outsider-agent":        {Kind: "a2a", Scope: "a2a/outsider-agent", Roles: []string{"developer", "platform-engineer"}},
		"workloads-gateway/v1":              {Kind: "model", Actors: []string{"relay-agent"}},
		"workloads-gateway/mcp/capture-mcp": {Kind: "mcp", Actors: []string{"relay-agent"}},
	}
	c.Models.Aliases = map[string]string{"reasoning-default": "fake-reasoning", "fast-default": "fake-fast"}
	c.Models.Refused = []string{"fake-reasoning", "claude-opus-5-5"}
	c.FakeModel.Ops = "http://fake-model.fake-model.svc.cluster.local:9090"
	c.FakeModel.Direct = "http://fake-model.fake-model.svc.cluster.local:8080"
	c.CaptureMCP.Ops = "http://capture-mcp.conformance.svc.cluster.local:9090"
	c.CaptureMCP.Direct = "http://capture-mcp.conformance.svc.cluster.local:8080/mcp"
	c.CaptureMCP.SidecarPort = "http://capture-mcp-pods.conformance.svc.cluster.local:15021/healthz/ready"
	c.Probes = map[string]platform.Probe{"meshed": {URL: "stand-in", Meshed: true}, "nomesh": {URL: "stand-in"}}
	c.Bypass.Providers = []string{"https://bedrock-runtime.us-east-1.amazonaws.com/"}
	c.Bypass.ToolUpstreams = []string{"https://gitlab.com/"}
	c.Admission.Enabled = true
	c.Admission.Helm = []string{"helm"}
	// image-verification's fixtures: the stand-in's API server judges a
	// Pod by its name, as every other dry run, so these only need to be
	// references.
	reg := "floci:4566/000000000000/us-east-1/workloads/conformance/"
	digest := func(n byte) string { return "@sha256:" + strings.Repeat(string("0123456789abcdef"[n]), 64) }
	c.Admission.Images = platform.AdmissionImages{
		Admitted: reg + "admitted" + digest(1), Unsigned: reg + "unsigned" + digest(2), OtherKey: reg + "other-key" + digest(3),
		SignedOnly: reg + "signed-only" + digest(4), NoConformance: reg + "no-conformance" + digest(5),
		ConformanceByRelease: reg + "conformance-by-release" + digest(6), BelowLevel: reg + "below-level" + digest(7),
		OldSuite: reg + "old-suite" + digest(8),
	}
	c.TestIssuer.Issuer = "https://conformance-issuer." + Domain
	c.TestIssuer.KeyFile = testKeyFile
	c.TestIssuer.Kid = "test-1"
	c.TestIssuer.Routes = []string{"gateway/v1", "gateway/mcp/capture-mcp"}
	c.UsageTable.URL = "http://usage-clickhouse-headless.usage.svc.cluster.local:8123"
	c.UsageTable.Wait = platform.Duration{Duration: 600 * time.Millisecond}
	c.Telemetry.OTLP = "http://collector.telemetry.svc.cluster.local:4318"
	c.Telemetry.PlatformPort = "http://collector.telemetry.svc.cluster.local:4319"
	c.Telemetry.Sinks.Namespace, c.Telemetry.Sinks.Selector = "telemetry-sink", "app.kubernetes.io/name=telemetry-sink"
	c.Telemetry.Sinks.Dynatrace, c.Telemetry.Sinks.SIEM = "dynatrace", "siem"
	// The collector's waits, scaled down: the stand-in decides at half the
	// decision wait and delivers at once. The cases do not wait these out
	// here: they wait on the stand-in's signal that everything sent to it
	// is delivered (Settle), bounded only by its backstop, so a loaded CI
	// runner whose timers fire seconds late passes or fails as an idle one
	// does. These bounds were wall time until two CI runs under the race
	// detector found no span of the canary at the Dynatrace stand-in
	// within them: 800 ms (main 3083011572), and then 3.2 s (!37's MR
	// pipeline 3083538929). They remain in the cases' messages, and in the
	// decision timer.
	ms := func(n int) platform.Duration { return platform.Duration{Duration: time.Duration(n) * time.Millisecond} }
	c.Telemetry.Waits.Decision, c.Telemetry.Waits.MetricsFlush, c.Telemetry.Waits.Delivery, c.Telemetry.Waits.Langfuse = ms(200), ms(100), ms(3000), ms(2000)
	c.Langfuse.URL, c.Langfuse.EventsBucket = "http://langfuse-web.langfuse.svc.cluster.local:3000", "agentic-langfuse-events-local"
	c.Audit.Bucket = "agentic-audit-local"
	c.S3.Endpoint, c.S3.PathStyle = "http://floci:4566", true
	c.AWS.Allowed = []string{"aws", "as", "platform-gateway"}
	c.AWS.Refused = map[string][]string{"platform-delegation-sts": {"aws", "as", "platform-delegation-sts"}, "bedrock-probe": {"aws", "as", "bedrock-probe"}}
	if err := c.Complete(); err != nil {
		panic(err)
	}
	return c
}

// Env is an environment wired to the stand-in.
func (w *World) Env() (*platform.Env, error) {
	mesh := w.Cfg.Timing.MeshConnectTimeout.Duration
	src := func(name, principal string, meshed bool) platform.Source {
		s := outcome.Source{Name: name, Meshed: meshed, MeshConnectTimeout: mesh}
		return platform.Source{Source: s, Doer: &network{w: w, from: name, principal: principal, meshed: meshed}}
	}
	runner := src("runner", "conformance/conformance-runner", true)
	srv := httptest.NewServer(w.apiServer())
	w.closers = append(w.closers, srv.Close)
	return platform.NewEnv(w.Cfg, platform.Options{
		Runner: &runner,
		Probes: map[string]platform.Source{"meshed": src("probe-meshed", "conformance-probe/probe", true), "nomesh": src("probe-nomesh", "", false)},
		Tokens: &tokens{w: w},
		Kube:   &kube.Client{Server: srv.URL, HTTP: srv.Client()},
		Run:    w.commands,
		Dial:   w.dial,
		Logs:   w.tel,
		Settle: w.tel.Settle,
		S3Credentials: func() (s3.Credentials, error) {
			return s3.Credentials{AccessKeyID: "test", SecretAccessKey: "test"}, nil
		},
	})
}

// --- Issuers ------------------------------------------------------------

func (w *World) keycloak() http.Handler {
	mux := http.NewServeMux()
	issuer := "https://keycloak." + Domain + "/realms/agentic"
	mux.HandleFunc("GET /realms/agentic/protocol/openid-connect/certs", func(rw http.ResponseWriter, _ *http.Request) {
		k, _ := jose.PublicJWK(&w.kcKey.PublicKey, "kc-1", "RS256")
		json.NewEncoder(rw).Encode(jose.JWKS{Keys: []jose.JWK{k}})
	})
	mux.HandleFunc("GET /realms/agentic/.well-known/openid-configuration", func(rw http.ResponseWriter, _ *http.Request) {
		json.NewEncoder(rw).Encode(map[string]any{"issuer": issuer,
			"authorization_endpoint": issuer + "/protocol/openid-connect/auth",
			"token_endpoint":         issuer + "/protocol/openid-connect/token",
			"registration_endpoint":  issuer + "/clients-registrations/openid-connect"})
	})
	// Keycloak's anonymous registration, which its Trusted Hosts policy
	// refuses from anywhere but a trusted host.
	mux.HandleFunc("POST /realms/agentic/clients-registrations/openid-connect", func(rw http.ResponseWriter, _ *http.Request) {
		rw.Header().Set("Content-Type", "application/json")
		if w.F.AnonymousRegistration {
			rw.WriteHeader(http.StatusCreated)
			json.NewEncoder(rw).Encode(map[string]any{"client_id": "anonymous-1"})
			return
		}
		rw.WriteHeader(http.StatusForbidden)
		json.NewEncoder(rw).Encode(map[string]any{"error": "insufficient_scope",
			"error_description": "Policy 'Trusted Hosts' rejected request to client-registration service. Details: Host not trusted."})
	})
	// The browser flow: a known client goes on to the Okta broker; any
	// other is sent back with an error.
	mux.HandleFunc("GET /realms/agentic/protocol/openid-connect/auth", func(rw http.ResponseWriter, r *http.Request) {
		q := r.URL.Query()
		if q.Get("client_id") == "claude-code" && !w.F.NoPreRegisteredClient {
			rw.Header().Set("Location", issuer+"/broker/okta/login?client_id=claude-code")
			rw.WriteHeader(http.StatusSeeOther)
			return
		}
		rw.Header().Set("Location", q.Get("redirect_uri")+"?error=unauthorized_client&state="+q.Get("state"))
		rw.WriteHeader(http.StatusFound)
	})
	return mux
}

// persona is what a persona's token claims.
type persona struct {
	sub, team string
	roles     []string
}

var personas = map[string]persona{
	platform.RoleDeveloper:        {"0b1c-developer", "payments", []string{"developer"}},
	platform.RoleIncidentManager:  {"0b1c-incident", "payments", []string{"incident-manager"}},
	platform.RolePlatformEngineer: {"0b1c-platform", "platform", []string{"platform-engineer"}},
	platform.RoleOtherTeam:        {"0b1c-other", "platform", []string{"developer"}},
	platform.RoleLimited:          {"0b1c-limited", "conformance", []string{"developer"}},
	platform.RoleNoTeam:           {"0b1c-noteam", "", []string{"developer"}},
}

func (w *World) personaToken(role string, aud any) string {
	p := personas[role]
	now := time.Now()
	cl := map[string]any{"iss": "https://keycloak." + Domain + "/realms/agentic", "sub": p.sub, "aud": aud, "client_id": "agentctl", "azp": "agentctl",
		"roles": p.roles, "iat": now.Unix(), "exp": now.Add(5 * time.Minute).Unix(), "jti": jose.RandomID(12), "sid": "s-" + p.sub}
	if p.team != "" {
		cl["team"] = p.team
	}
	t, _ := jose.Sign(map[string]any{"alg": "RS256", "typ": "at+jwt", "kid": "kc-1"}, cl, w.kcKey)
	return t
}

type tokens struct{ w *World }

func (t *tokens) Has(role string) bool { _, ok := personas[role]; return ok }

func (t *tokens) Token(_ context.Context, role, scope string) (string, error) {
	if scope == t.w.Cfg.Kagent.Scope {
		return t.w.personaToken(role, t.w.Cfg.RouteURL("gateway/a2a/"+t.w.Cfg.Kagent.Agent)), nil
	}
	if scope == "a2a/"+TelemetryAgent {
		return t.w.personaToken(role, t.w.Cfg.RouteURL("gateway/a2a/"+TelemetryAgent)), nil
	}
	for name, r := range t.w.Cfg.Routes {
		if r.Scope == scope {
			return t.w.personaToken(role, t.w.Cfg.RouteURL(name)), nil
		}
	}
	return "", fmt.Errorf("no route has scope %s", scope)
}

func (t *tokens) Wide(_ context.Context, role string) (string, error) {
	var aud []string
	for name, r := range t.w.Cfg.Routes {
		if r.Scope != "" {
			aud = append(aud, t.w.Cfg.RouteURL(name))
		}
	}
	return t.w.personaToken(role, aud), nil
}

func (w *World) actorToken(sa string) string {
	now := time.Now()
	t, _ := jose.Sign(map[string]any{"alg": "ES256", "kid": "k8s-1"}, map[string]any{
		"iss": "https://kubernetes.default.svc.cluster.local", "sub": "system:serviceaccount:conformance:" + sa,
		"aud": "https://delegation-sts." + Domain, "iat": now.Unix(), "exp": now.Add(10 * time.Minute).Unix(),
	}, w.k8sKey)
	return t
}

// agents is the stand-in STS's policy: as plan/local-build.md's fixture
// agents' entries.
var agents = map[string]struct{ routes, targets []string }{
	"relay-agent":    {[]string{"gateway/a2a/relay-agent"}, []string{"workloads-gateway/v1", "workloads-gateway/mcp/capture-mcp", "workloads-gateway/a2a/kagent-reader"}},
	"outsider-agent": {[]string{"gateway/a2a/outsider-agent"}, []string{"workloads-gateway/mcp/capture-mcp"}},
}

func (w *World) sts() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /jwks", func(rw http.ResponseWriter, _ *http.Request) {
		k, _ := jose.PublicJWK(&w.stsEC.PublicKey, "sts-1", "ES256")
		json.NewEncoder(rw).Encode(jose.JWKS{Keys: []jose.JWK{k}})
	})
	refuse := func(rw http.ResponseWriter, e, reason string) {
		rw.Header().Set("Content-Type", "application/json")
		rw.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(rw).Encode(map[string]string{"error": e, "reason": reason})
	}
	mux.HandleFunc("POST /token", func(rw http.ResponseWriter, r *http.Request) {
		r.ParseForm()
		actor, err := jose.Parse(r.PostForm.Get("actor_token"))
		if err != nil || actor.Verify(&w.k8sKey.PublicKey) != nil {
			refuse(rw, "invalid_request", "actor_rejected")
			return
		}
		sa := strings.TrimPrefix(fmt.Sprint(actor.Claims["sub"]), "system:serviceaccount:conformance:")
		pol, ok := agents[sa]
		if !ok {
			refuse(rw, "invalid_request", "actor_unknown")
			return
		}
		subj, err := jose.Parse(r.PostForm.Get("subject_token"))
		if err != nil || subj.Verify(&w.kcKey.PublicKey) != nil {
			refuse(rw, "invalid_request", "subject_signature")
			return
		}
		aud := fmt.Sprint(subj.Claims["aud"])
		allowed := false
		for _, route := range pol.routes {
			allowed = allowed || w.Cfg.RouteURL(route) == aud
		}
		if !allowed {
			refuse(rw, "invalid_request", "subject_audience")
			return
		}
		res := r.PostForm["resource"]
		if len(res) != 1 {
			refuse(rw, "invalid_target", "resource_missing")
			return
		}
		ok = false
		for _, t := range pol.targets {
			ok = ok || w.Cfg.RouteURL(t) == res[0]
		}
		if !ok {
			refuse(rw, "invalid_target", "resource_not_allowed")
			return
		}
		name := w.Cfg.Actor("conformance", sa)
		if w.F.STSWrongActor {
			name = w.Cfg.Actor("conformance", "someone-else")
		}
		now := time.Now()
		cl := map[string]any{"iss": "https://delegation-sts." + Domain, "sub": subj.Claims["sub"], "aud": res[0], "client_id": name,
			"act": map[string]any{"sub": name}, "iat": now.Unix(), "nbf": now.Unix(), "exp": now.Add(5 * time.Minute).Unix(), "jti": jose.RandomID(16)}
		for _, k := range []string{"roles", "team", "sid", "idp_sub", "preferred_username"} {
			if v, ok := subj.Claims[k]; ok {
				cl[k] = v
			}
		}
		tok, _ := jose.Sign(map[string]any{"alg": "ES256", "typ": "at+jwt", "kid": "sts-1"}, cl, w.stsEC)
		rw.Header().Set("Content-Type", "application/json")
		json.NewEncoder(rw).Encode(map[string]any{"access_token": tok, "issued_token_type": "urn:ietf:params:oauth:token-type:access_token", "token_type": "Bearer", "expires_in": 300})
	})
	return mux
}

// --- Limits and commands ---------------------------------

// kagentRate counts the kagent route's requests per person in a minute.
type kagentRate struct {
	sync.Mutex
	start time.Time
	used  map[string]int
}

type limits struct {
	mu    sync.Mutex
	used  map[string]int
	reset time.Time // when the window resets; zero: not within a test
	// left, if set, starts the window's last stretch at the first limited
	// request: reset is then that request's time plus left.
	left time.Duration
}

func (w *World) commands(_ context.Context, argv []string, _ string) (string, int, error) {
	args := strings.Join(argv, " ")
	switch {
	case strings.HasPrefix(args, "helm install") && strings.Contains(args, "claimPlatform=true"):
		if w.F.HelmKeepsAnnotation || w.F.NoKyverno {
			return "STATUS: deployed", 0, nil
		}
		return `Error: INSTALLATION FAILED: admission webhook "vpol.validate.kyverno.svc-fail" denied the request: mesh-floor: a workload release may not create an AuthorizationPolicy`, 1, nil
	case strings.HasPrefix(args, "helm"):
		return "ok", 0, nil
	case args == "aws as platform-gateway":
		return `{"body": "stub"}`, 0, nil
	case strings.HasPrefix(args, "aws as "):
		if w.F.BedrockOpen {
			return `{"body": "stub"}`, 0, nil
		}
		return "An error occurred (AccessDeniedException) when calling the InvokeModel operation: AccessDenied", 254, nil
	}
	return "unknown command " + args, 127, nil
}
