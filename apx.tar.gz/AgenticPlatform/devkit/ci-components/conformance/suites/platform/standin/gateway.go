package standin

import (
	"bytes"
	"crypto"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
)

// gateway plays one agentgateway deployment: its routes, the issuers it
// accepts, the verifier profile's checks, CEL and the model route.
func (w *World) gateway(deployment string) http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if deployment == "gateway" && strings.HasPrefix(r.URL.Path, "/.well-known/oauth-") {
			w.mcpDiscovery(rw, r)
			return
		}
		route, kind := w.routeOf(deployment, r.URL.Path)
		if route == "" {
			http.Error(rw, "no route", http.StatusNotFound)
			return
		}
		raw, _ := io.ReadAll(r.Body)
		if why := w.profile(r.Header.Get("Authorization")); why != "" {
			http.Error(rw, "authorization failed: "+why, http.StatusForbidden)
			return
		}
		claims, why := w.verify(deployment, route, r.Header.Get("Authorization"))
		if why != "" {
			status := http.StatusUnauthorized
			if w.F.Status403For401 {
				status = http.StatusForbidden
			}
			rw.Header().Set("WWW-Authenticate", `Bearer error="invalid_token"`)
			http.Error(rw, "authentication failure: "+why, status)
			return
		}
		if a, many := claims["aud"].([]any); many && len(a) != 1 && !w.F.AcceptMultiAud && !w.F.NoProfileRules {
			http.Error(rw, "authorization failed: more than one audience", http.StatusForbidden)
			return
		}
		if why := w.authorize(deployment, route, claims); why != "" {
			http.Error(rw, "authorization failed: "+why, http.StatusForbidden)
			return
		}
		switch kind {
		case "model":
			w.model(rw, r, raw, claims)
		case "mcp":
			w.mcp(rw, r, raw, claims)
		case "a2a":
			agent := strings.TrimPrefix(route, "gateway/a2a/")
			w.forward(rw, r, raw, "http://"+agent+".conformance.svc.cluster.local:8080/", r.Header.Get("Authorization"))
		case "kagent":
			if deployment == "gateway" && !w.kagentAdmit(claims) {
				rw.Header().Set("Retry-After", "60")
				http.Error(rw, "rate limit exceeded", http.StatusTooManyRequests)
				return
			}
			if strings.HasSuffix(r.URL.Path, "/.well-known/agent-card.json") {
				w.kagentCard(rw)
				return
			}
			w.kagent(rw, raw)
		case "telemetry-agent":
			w.telemetryAgent(rw, r, raw)
		}
	})
}

func (w *World) routeOf(deployment, path string) (string, string) {
	// The kagent fixture agent's A2A route, on both deployments (B4).
	if p := "/a2a/" + w.Cfg.Kagent.Agent; path == p || strings.HasPrefix(path, p+"/") {
		return deployment + p, "kagent"
	}
	// An agent that plays the telemetry group's turn (B5).
	if p := "/a2a/" + TelemetryAgent; deployment == "gateway" && (path == p || strings.HasPrefix(path, p+"/")) {
		return deployment + p, "telemetry-agent"
	}
	for name, rt := range w.Cfg.Routes {
		gw, p, _ := strings.Cut(name, "/")
		if gw != deployment || rt.Kind == "model" {
			continue
		}
		if path == "/"+p || strings.HasPrefix(path, "/"+p+"/") {
			return name, rt.Kind
		}
	}
	if _, ok := w.Cfg.Routes[deployment+"/v1"]; ok {
		return deployment + "/v1", "model"
	}
	return "", ""
}

func (w *World) issuers(deployment, route string) map[string]crypto.PublicKey {
	kc := map[string]crypto.PublicKey{"https://keycloak." + Domain + "/realms/agentic": &w.kcKey.PublicKey}
	sts := map[string]crypto.PublicKey{"https://delegation-sts." + Domain: &w.stsEC.PublicKey}
	out := map[string]crypto.PublicKey{}
	add := func(m map[string]crypto.PublicKey) {
		for k, v := range m {
			out[k] = v
		}
	}
	if deployment == "gateway" {
		add(kc)
		if w.F.ChainOnDeveloper {
			add(sts)
		}
		if slices.Contains(w.Cfg.TestIssuer.Routes, route) {
			out[w.Cfg.TestIssuer.Issuer] = &w.testKey.PublicKey
		}
	} else {
		add(sts)
		if w.F.PersonOnWorkloads {
			add(kc)
		}
	}
	return out
}

// profile plays T22's token-profile rule, a PreRouting authorization on
// each Gateway: a bearer token's header must name typ at+jwt and alg RS256
// or ES256, else 403; a request without one goes on to its route.
func (w *World) profile(header string) string {
	raw, ok := strings.CutPrefix(header, "Bearer ")
	if !ok || raw == "" || w.F.NoProfileRules {
		return ""
	}
	t, err := jose.Parse(raw)
	if err != nil {
		return "malformed"
	}
	if t.HeaderString("typ") != "at+jwt" && !w.F.IgnoreTyp {
		return "typ"
	}
	switch alg := t.HeaderString("alg"); {
	case alg == "RS256" || alg == "ES256":
	case alg == "none" && w.F.AcceptAlgNone:
	case alg == "HS256" && w.F.AcceptHS256:
	default:
		return "alg"
	}
	return ""
}

// verify plays the route's JWT policy, which accepts any typ and an aud
// list that holds the route: "" when the token is good, else why not.
func (w *World) verify(deployment, route, header string) (map[string]any, string) {
	raw, ok := strings.CutPrefix(header, "Bearer ")
	if !ok || raw == "" {
		return nil, "no token"
	}
	t, err := jose.Parse(raw)
	if err != nil {
		return nil, "malformed"
	}
	iss, _ := t.Claims["iss"].(string)
	keys := w.issuers(deployment, route)
	key, trusted := keys[iss]
	alg := t.HeaderString("alg")
	switch {
	case w.F.NoSignatureCheck:
	case alg == "none" && w.F.AcceptAlgNone:
	case alg == "HS256" && w.F.AcceptHS256:
		if !trusted {
			return nil, "issuer"
		}
		secret, _ := jose.PublicPEM(key)
		m := hmac.New(sha256.New, secret)
		m.Write([]byte(t.SigningInput))
		if !hmac.Equal(m.Sum(nil), t.Signature) {
			return nil, "signature"
		}
	default:
		if !trusted {
			return nil, "issuer"
		}
		if kid := t.HeaderString("kid"); kid != "kc-1" && kid != "sts-1" && kid != w.Cfg.TestIssuer.Kid {
			return nil, "unknown kid"
		}
		if err := t.Verify(key); err != nil {
			return nil, "signature"
		}
	}
	if !trusted && !w.F.NoSignatureCheck {
		return nil, "issuer"
	}
	want := w.Cfg.RouteURL(route)
	if !w.F.IgnoreAud {
		switch a := t.Claims["aud"].(type) {
		case string:
			if a != want {
				return nil, "audience"
			}
		case []any:
			if !slices.Contains(a, any(want)) {
				return nil, "audience"
			}
		default:
			return nil, "audience"
		}
	}
	now := time.Now().Unix()
	if exp, ok := num(t.Claims["exp"]); !w.F.IgnoreExp && (!ok || now > exp+60) {
		return nil, "expired"
	}
	if nbf, ok := num(t.Claims["nbf"]); ok && !w.F.IgnoreNbf && nbf > now+60 {
		return nil, "not yet valid"
	}
	return t.Claims, ""
}

func num(v any) (int64, bool) {
	switch n := v.(type) {
	case json.Number:
		i, err := n.Int64()
		return i, err == nil
	case float64:
		return int64(n), true
	}
	return 0, false
}

func roles(claims map[string]any) []string {
	var out []string
	if rs, ok := claims["roles"].([]any); ok {
		for _, r := range rs {
			out = append(out, fmt.Sprint(r))
		}
	}
	return out
}

func (w *World) authorize(deployment, route string, claims map[string]any) string {
	rt, ok := w.Cfg.Routes[route]
	if !ok && route == "gateway/a2a/"+TelemetryAgent {
		rt = platform.Route{Kind: "a2a", Roles: []string{"developer", "platform-engineer"}}
	}
	if !ok && strings.HasSuffix(route, "/a2a/"+w.Cfg.Kagent.Agent) {
		// The kagent agent's access file: the developer's roles, and
		// relay-agent on the hosted-workloads deployment.
		rt = platform.Route{Kind: "a2a", Roles: []string{"developer", "platform-engineer"}, Actors: []string{"relay-agent"}}
		if w.F.KagentRouteNoActors {
			rt.Actors = nil
		}
	}
	if deployment == "gateway" {
		if !w.F.SkipRoleCheck && !slices.ContainsFunc(roles(claims), func(r string) bool { return slices.Contains(rt.Roles, r) }) {
			return "role"
		}
		if team, _ := claims["team"].(string); team == "" && !w.F.SkipTeamCheck {
			return "team"
		}
		return ""
	}
	act, _ := claims["act"].(map[string]any)
	sub, _ := act["sub"].(string)
	if w.F.IgnoreOutermostActor && sub != "" {
		return ""
	}
	for _, a := range rt.Actors {
		if sub == w.Cfg.Actor("conformance", a) {
			return ""
		}
	}
	return "outermost actor"
}

var llmPaths = []string{"/v1/messages", "/v1/messages/count_tokens", "/v1/chat/completions", "/v1/responses", "/v1/models"}

func (w *World) model(rw http.ResponseWriter, r *http.Request, raw []byte, claims map[string]any) {
	if !slices.Contains(llmPaths, r.URL.Path) && !w.F.PassNonLLMPath {
		http.Error(rw, "not found", http.StatusNotFound)
		return
	}
	if r.URL.Path == "/v1/models" {
		var data []map[string]any
		for a := range w.Cfg.Models.Aliases {
			data = append(data, map[string]any{"id": a, "object": "model"})
		}
		if w.F.ListProviderModels {
			data = append(data, map[string]any{"id": "fake-reasoning", "object": "model"})
		}
		json.NewEncoder(rw).Encode(map[string]any{"object": "list", "data": data})
		return
	}
	var body map[string]any
	json.Unmarshal(raw, &body)
	name, _ := body["model"].(string)
	mapped, known := w.Cfg.Models.Aliases[name]
	if known {
		body["model"] = mapped
	} else if slices.Contains(llmPaths, r.URL.Path) && !w.F.PassUnknownModel {
		rw.Header().Set("Content-Type", "application/json")
		rw.WriteHeader(http.StatusNotFound)
		json.NewEncoder(rw).Encode(map[string]any{"error": map[string]any{"type": "model_not_found", "message": "model " + name + " not found"}})
		return
	}
	team, _ := claims["team"].(string)
	key := team
	if w.F.LimitAllTeams && (team == "conformance" || team == "platform") {
		key = "shared" // one counter for the limited team and the other team
	}
	if team == "conformance" || key == "shared" {
		w.limits.mu.Lock()
		if w.limits.left > 0 {
			w.limits.reset, w.limits.left = time.Now().Add(w.limits.left), 0
		}
		if !w.limits.reset.IsZero() && time.Now().After(w.limits.reset) {
			w.limits.used, w.limits.reset = map[string]int{}, time.Time{}
		}
		used := w.limits.used[key]
		retry := "3600"
		if !w.limits.reset.IsZero() {
			retry = strconv.Itoa(int(time.Until(w.limits.reset).Seconds()) + 1)
		}
		w.limits.mu.Unlock()
		if used >= w.Cfg.Limits.Tokens && !w.F.NoLimit {
			if !w.F.NoRetryAfter {
				rw.Header().Set("Retry-After", retry)
			}
			http.Error(rw, "rate limited", http.StatusTooManyRequests)
			return
		}
	}
	upstream, _ := json.Marshal(body)
	h := http.Header{}
	for _, k := range []string{"Content-Type", "anthropic-version", "anthropic-beta", "traceparent", "x-api-key"} {
		if v := r.Header.Get(k); v != "" && !(w.F.DropModelHeaders && (k == "anthropic-beta" || k == "traceparent")) && k != "x-api-key" {
			h.Set(k, v)
		}
	}
	if w.F.ForwardModelToken {
		h.Set("Authorization", r.Header.Get("Authorization"))
	}
	req, _ := http.NewRequestWithContext(r.Context(), r.Method, "http://fake-model.fake-model.svc.cluster.local:8080"+r.URL.Path, bytes.NewReader(upstream))
	req.Header = h
	resp, err := (&http.Client{Transport: &http.Transport{DialContext: w.dial}}).Do(req)
	if err != nil {
		http.Error(rw, err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	out, _ := io.ReadAll(resp.Body)
	var answer struct {
		ID    string `json:"id"`
		Usage struct {
			In  int `json:"input_tokens"`
			Out int `json:"output_tokens"`
		} `json:"usage"`
	}
	json.Unmarshal(out, &answer)
	w.limits.mu.Lock()
	w.limits.used[key] += answer.Usage.In + answer.Usage.Out
	w.limits.mu.Unlock()
	// The gateway's span and record of the request, under the caller's
	// trace ID.
	if resp.StatusCode == http.StatusOK {
		w.gatewayTelemetry(r, raw, claims, name, mapped, answer.Usage.In, answer.Usage.Out)
	}
	for k, v := range resp.Header {
		rw.Header()[k] = v
	}
	rw.WriteHeader(resp.StatusCode)
	rw.Write(out)
}

func (w *World) mcp(rw http.ResponseWriter, r *http.Request, raw []byte, claims map[string]any) {
	var msg struct {
		Method string `json:"method"`
		Params struct {
			Name string `json:"name"`
		} `json:"params"`
	}
	json.Unmarshal(raw, &msg)
	platform := slices.Contains(roles(claims), "platform-engineer") || w.F.NoToolFilter
	if msg.Method == "tools/call" && msg.Params.Name == capturemcp.ToolPlatform && !platform {
		http.Error(rw, "authorization failed: tool not visible", http.StatusForbidden)
		return
	}
	tok := r.Header.Get("Authorization")
	if w.F.DropMCPToken {
		tok = ""
	}
	if msg.Method != "tools/list" || platform {
		w.forward(rw, r, raw, "http://capture-mcp.conformance.svc.cluster.local:8080/mcp", tok)
		return
	}
	rec := &recorder{header: http.Header{}}
	w.forward(rec, r, raw, "http://capture-mcp.conformance.svc.cluster.local:8080/mcp", tok)
	var resp map[string]any
	if json.Unmarshal(rec.body.Bytes(), &resp) == nil {
		if res, ok := resp["result"].(map[string]any); ok {
			if tools, ok := res["tools"].([]any); ok {
				var kept []any
				for _, t := range tools {
					if m, _ := t.(map[string]any); m["name"] != capturemcp.ToolPlatform {
						kept = append(kept, t)
					}
				}
				res["tools"] = kept
			}
		}
		out, _ := json.Marshal(resp)
		for k, v := range rec.header {
			rw.Header()[k] = v
		}
		rw.Header().Del("Content-Length")
		rw.WriteHeader(rec.status)
		rw.Write(out)
		return
	}
	rw.WriteHeader(rec.status)
	rw.Write(rec.body.Bytes())
}

type recorder struct {
	header http.Header
	status int
	body   bytes.Buffer
}

func (r *recorder) Header() http.Header         { return r.header }
func (r *recorder) WriteHeader(s int)           { r.status = s }
func (r *recorder) Write(b []byte) (int, error) { return r.body.Write(b) }

// kagent plays kagent's controller behind an agent's A2A route: a JSON-RPC
// answer, which with no actor is an error, never a task.
func (w *World) kagent(rw http.ResponseWriter, raw []byte) {
	var req struct {
		ID json.RawMessage `json:"id"`
	}
	json.Unmarshal(raw, &req)
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(map[string]any{"jsonrpc": "2.0", "id": req.ID, "error": map[string]any{"code": -32001, "message": "task not found"}})
}

// KagentRouteLimit is the requests a minute the kagent agent's developer
// route admits per person, as its access file's local rate limit does.
const KagentRouteLimit = 20

// kagentAdmit plays that limit: false past it, within the minute.
func (w *World) kagentAdmit(claims map[string]any) bool {
	if w.F.NoRouteLimit {
		return true
	}
	sub := fmt.Sprint(claims["sub"])
	w.kagentRate.Lock()
	defer w.kagentRate.Unlock()
	if w.kagentRate.start.IsZero() || time.Since(w.kagentRate.start) > time.Minute {
		w.kagentRate.start, w.kagentRate.used = time.Now(), map[string]int{}
	}
	w.kagentRate.used[sub]++
	return w.kagentRate.used[sub] <= KagentRouteLimit
}

// kagentCard plays kagent's agent card through the gateway: an A2A 1.0
// card, or with CardT30 what B4 saw, the gateway's 503.
func (w *World) kagentCard(rw http.ResponseWriter) {
	switch {
	case w.F.CardT30:
		// What B4 saw: the body says "internal error", the gateway's log
		// "processing failed: agent card invalid JSON".
		http.Error(rw, "internal error", http.StatusServiceUnavailable)
	case w.F.NoCard:
		http.Error(rw, "not found", http.StatusNotFound)
	default:
		rw.Header().Set("Content-Type", "application/json")
		json.NewEncoder(rw).Encode(map[string]any{"name": w.Cfg.Kagent.Agent, "description": "the kagent fixture agent", "version": "1",
			"supportedInterfaces": []any{map[string]any{"url": w.Cfg.RouteURL("gateway/a2a/" + w.Cfg.Kagent.Agent), "protocolBinding": "JSONRPC", "protocolVersion": "1.0"}}})
	}
}

func (w *World) forward(rw http.ResponseWriter, r *http.Request, raw []byte, to, auth string) {
	req, _ := http.NewRequestWithContext(r.Context(), r.Method, to, bytes.NewReader(raw))
	for k, v := range r.Header {
		if !strings.EqualFold(k, "Authorization") {
			req.Header[k] = v
		}
	}
	if auth != "" {
		req.Header.Set("Authorization", auth)
	}
	resp, err := (&http.Client{Transport: &http.Transport{DialContext: w.dial}}).Do(req)
	if err != nil {
		http.Error(rw, err.Error(), http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	for k, v := range resp.Header {
		rw.Header()[k] = v
	}
	rw.WriteHeader(resp.StatusCode)
	io.Copy(rw, resp.Body)
}

// fakeModel answers Messages requests and keeps records shaped like the
// fake model server's (its README's "Request records").
type fakeModel struct {
	mu      sync.Mutex
	records []map[string]any
}

func (f *fakeModel) model() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		raw, _ := io.ReadAll(r.Body)
		var body struct {
			Model    string `json:"model"`
			Messages []struct {
				Content string `json:"content"`
			} `json:"messages"`
		}
		json.Unmarshal(raw, &body)
		id, tokens := "", 12
		if len(body.Messages) > 0 {
			text := body.Messages[0].Content
			if i := strings.Index(text, "id="); i >= 0 {
				id = strings.Fields(text[i+3:])[0]
				id = strings.TrimSuffix(id, "]]")
			}
			if i := strings.Index(text, "tokens="); i >= 0 {
				fmt.Sscanf(text[i+7:], "%d", &tokens)
			}
		}
		api := "none"
		if r.URL.Path == "/v1/messages" {
			api = "messages"
		}
		var creds []string
		for _, h := range []string{"Authorization", "X-Api-Key", "Proxy-Authorization"} {
			if r.Header.Get(h) != "" {
				creds = append(creds, h)
			}
		}
		f.mu.Lock()
		f.records = append(f.records, map[string]any{"api": api, "method": r.Method, "path": r.URL.Path, "model": body.Model, "directive_id": id,
			"credentials": creds, "traceparent": r.Header.Get("traceparent"), "anthropic_version": r.Header.Get("anthropic-version"),
			"anthropic_beta": r.Header.Get("anthropic-beta"), "input_tokens": 9, "output_tokens": tokens})
		f.mu.Unlock()
		if api == "none" {
			http.Error(rw, "Invalid URL", http.StatusNotFound)
			return
		}
		rw.Header().Set("Content-Type", "application/json")
		// status=400 echo: a provider's error quoting the prompt.
		if len(body.Messages) > 0 && strings.Contains(body.Messages[0].Content, "status=400 echo]]") {
			rw.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(rw).Encode(map[string]any{"type": "error", "error": map[string]any{"type": "invalid_request_error",
				"message": "Bad Request (injected by a fake-model directive): " + body.Messages[0].Content}})
			return
		}
		json.NewEncoder(rw).Encode(map[string]any{"id": "msg_fake_" + id, "type": "message", "model": body.Model,
			"usage": map[string]any{"input_tokens": 9, "output_tokens": tokens}})
	})
}

// earlierRuns fills the records with earlier runs' model requests until
// they take more than size bytes as the ops port answers them, as the
// fake model server holds them after a few runs of the suites.
func (f *fakeModel) earlierRuns(size int) {
	f.mu.Lock()
	defer f.mu.Unlock()
	n := 0
	for i := 0; n <= size; i++ {
		rec := map[string]any{"api": "messages", "method": "POST", "path": "/v1/messages", "model": "fake-fast",
			"directive_id": fmt.Sprintf("conf-earlier-%d-twin", i), "credentials": []string{}, "anthropic_version": "2023-06-01",
			"input_tokens": 9, "output_tokens": 12}
		b, _ := json.Marshal(rec)
		n += len(b) + 1
		f.records = append(f.records, rec)
	}
}

func (f *fakeModel) ops() http.Handler {
	return http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		id := r.URL.Query().Get("id")
		f.mu.Lock()
		out := []map[string]any{}
		for _, rec := range f.records {
			if id == "" || rec["directive_id"] == id {
				out = append(out, rec)
			}
		}
		f.mu.Unlock()
		json.NewEncoder(rw).Encode(map[string]any{"requests": out})
	})
}

// mcpDiscovery plays MCP sign-in on capture-mcp's developer route, as
// agentgateway's Keycloak adapter does: the protected-resource metadata
// names the route as its authorization server, whose metadata is the
// realm's with the gateway as issuer and a registration endpoint of the
// gateway's, which proxies to the realm's unless a client ID is set to
// answer with.
func (w *World) mcpDiscovery(rw http.ResponseWriter, r *http.Request) {
	gw := "https://gateway." + Domain
	route := gw + "/mcp/capture-mcp"
	realm := "https://keycloak." + Domain + "/realms/agentic"
	rw.Header().Set("Content-Type", "application/json")
	switch p := r.URL.Path; {
	case p == "/.well-known/oauth-protected-resource/mcp/capture-mcp":
		json.NewEncoder(rw).Encode(map[string]any{"resource": route, "authorization_servers": []string{route}, "scopes_supported": []string{"mcp/capture-mcp"}})
	case p == "/.well-known/oauth-authorization-server/mcp/capture-mcp":
		json.NewEncoder(rw).Encode(map[string]any{"issuer": route, "authorization_endpoint": realm + "/protocol/openid-connect/auth",
			"registration_endpoint": gw + p + "/client-registration"})
	case p == "/.well-known/oauth-authorization-server/mcp/capture-mcp/client-registration" && r.Method == http.MethodPost:
		if w.F.GatewayAnswersRegistration {
			rw.WriteHeader(http.StatusCreated)
			json.NewEncoder(rw).Encode(map[string]any{"client_id": "claude-code"})
			return
		}
		raw, _ := io.ReadAll(r.Body)
		o := w.direct().Do(r.Context(), outcome.Request{Method: http.MethodPost, URL: realm + "/clients-registrations/openid-connect",
			Body: string(raw), Header: map[string]string{"Content-Type": "application/json"}})
		rw.WriteHeader(o.Status)
		io.WriteString(rw, o.Body)
	default:
		http.Error(rw, "authentication failed", http.StatusUnauthorized)
	}
}
