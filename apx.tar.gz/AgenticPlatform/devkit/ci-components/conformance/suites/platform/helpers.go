package platform

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"slices"
	"sort"
	"strings"

	capturemcp "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/capture-mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// C is a running case of these suites.
type C = runner.C[*Env]

// Case is a case of these suites.
type Case = runner.Case[*Env]

// req fills a request's timeouts from the configuration.
func (e *Env) req(r outcome.Request) outcome.Request {
	if r.Timeout == 0 {
		r.Timeout = outcome.Of(e.Cfg.Timing.Request.Duration)
	}
	if r.Connect == 0 {
		r.Connect = outcome.Of(e.Cfg.Timing.Connect.Duration)
	}
	return r
}

// Do makes r from src.
func (e *Env) Do(ctx context.Context, src Source, r outcome.Request) outcome.Outcome {
	return src.Do(ctx, e.req(r))
}

// alias is the first approved alias, by name.
func (e *Env) alias() string {
	var names []string
	for a := range e.Cfg.Models.Aliases {
		names = append(names, a)
	}
	sort.Strings(names)
	if len(names) == 0 {
		return "reasoning-default"
	}
	return names[0]
}

// messages is a Messages request body for model that carries the fake
// model server's directive with id marker, plus more directive keys.
func messages(model, marker, more string) string {
	body, _ := json.Marshal(map[string]any{
		"model":      model,
		"max_tokens": 64,
		"messages":   []map[string]any{{"role": "user", "content": fmt.Sprintf("[[fake-model id=%s%s]] Say something.", marker, more)}},
	})
	return string(body)
}

// callModel posts a Messages request to a model route from src.
func (e *Env) callModel(ctx context.Context, src Source, route, token, model, marker string, header map[string]string) outcome.Outcome {
	h := map[string]string{"Content-Type": "application/json", "anthropic-version": e.Cfg.Models.AnthropicVersion}
	if token != "" {
		h["Authorization"] = "Bearer " + token
	}
	for k, v := range header {
		h[k] = v
	}
	return e.Do(ctx, src, outcome.Request{Method: http.MethodPost, URL: e.Cfg.CallURL(route) + "/messages", Header: h, Body: messages(model, marker, "")})
}

// mcpClient is an MCP client for a route, from src.
func (e *Env) mcpClient(src Source, route, token, marker string) *mcp.Client {
	return &mcp.Client{URL: e.Cfg.CallURL(route), Token: token, HTTP: &doer{e: e, src: src},
		Header: map[string]string{capturemcp.MarkerHeader: marker}}
}

type doer struct {
	e   *Env
	src Source
}

func (d *doer) Do(ctx context.Context, r outcome.Request) outcome.Outcome {
	return d.e.Do(ctx, d.src, r)
}

// callRoute makes the route's ordinary request with token: a Messages call
// on a model route, tools/list on an MCP route. It returns the outcome and
// whether the request got through.
func (e *Env) callRoute(ctx context.Context, src Source, route, token, marker string) (outcome.Outcome, bool) {
	switch e.Cfg.Routes[route].Kind {
	case "mcp":
		_, call := e.mcpClient(src, route, token, marker).ListTools(ctx)
		return call.Outcome, call.OK()
	default:
		o := e.callModel(ctx, src, route, token, e.alias(), marker, nil)
		return o, o.Kind == outcome.Response && o.Status == http.StatusOK
	}
}

// FakeModelRecord is one of the fake model server's request records
// (conformance/fixtures/fake-model/README.md, "Request records").
type FakeModelRecord struct {
	API              string   `json:"api"`
	Method           string   `json:"method"`
	Path             string   `json:"path"`
	Model            string   `json:"model"`
	DirectiveID      string   `json:"directive_id"`
	Status           int      `json:"status"`
	InputTokens      int      `json:"input_tokens"`
	OutputTokens     int      `json:"output_tokens"`
	Credentials      []string `json:"credentials"`
	Traceparent      string   `json:"traceparent"`
	AnthropicVersion string   `json:"anthropic_version"`
	AnthropicBeta    string   `json:"anthropic_beta"`
}

// fakeModelRecords are the fake model server's records: all, or one
// directive id's. They are read whole, through Read: the server keeps the
// latest 10,000 of every run since it started, so all of them soon pass
// outcome.MaxBody, where a Runner request's body is cut short.
func (e *Env) fakeModelRecords(ctx context.Context, id string) ([]FakeModelRecord, error) {
	u := strings.TrimRight(e.Cfg.FakeModel.Ops, "/") + "/requests"
	if id != "" {
		u += "?id=" + url.QueryEscape(id)
	}
	resp, err := e.Read.Do(ctx, http.MethodGet, u, nil, nil)
	if err != nil {
		return nil, fmt.Errorf("reading the fake model server's records: %v", err)
	}
	if resp.Status != http.StatusOK {
		return nil, fmt.Errorf("reading the fake model server's records: HTTP %d: %s", resp.Status, short(resp.Body))
	}
	var doc struct {
		Requests []FakeModelRecord `json:"requests"`
	}
	if err := json.Unmarshal(resp.Body, &doc); err != nil {
		return nil, fmt.Errorf("reading the fake model server's records: %v", err)
	}
	return doc.Requests, nil
}

// captureRecords are capture-mcp's records of one marker.
func (e *Env) captureRecords(ctx context.Context, marker string) ([]capturemcp.Record, error) {
	o := e.Do(ctx, e.Runner, outcome.Request{Method: http.MethodGet, URL: strings.TrimRight(e.Cfg.CaptureMCP.Ops, "/") + "/requests?id=" + url.QueryEscape(marker)})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		return nil, fmt.Errorf("reading capture-mcp's records: %s", o)
	}
	var doc struct {
		Requests []capturemcp.Record `json:"requests"`
	}
	if err := json.Unmarshal([]byte(o.Body), &doc); err != nil {
		return nil, fmt.Errorf("reading capture-mcp's records: %v", err)
	}
	return doc.Requests, nil
}

// noUpstreamRecord checks that a refused request never reached the
// backend behind route, when that backend's records can be read: the proof
// that the gateway refused, rather than the backend.
func noUpstreamRecord(c *C, route, marker string) {
	e := c.Env
	switch e.Cfg.Routes[route].Kind {
	case "model":
		if e.Cfg.FakeModel.Ops == "" {
			c.Logf("the fake model server's records were not read (fake_model.ops unset)")
			return
		}
		recs, err := e.fakeModelRecords(c, marker)
		if err != nil {
			c.Errorf("%v", err)
		} else if len(recs) > 0 {
			c.Errorf("the request reached the fake model server (%d records for %s): the gateway passed it on", len(recs), marker)
		}
	case "mcp":
		if e.Cfg.CaptureMCP.Ops == "" {
			c.Logf("capture-mcp's records were not read (capture_mcp.ops unset)")
			return
		}
		recs, err := e.captureRecords(c, marker)
		if err != nil {
			c.Errorf("%v", err)
		} else if len(recs) > 0 {
			c.Errorf("the request reached capture-mcp (%d records for %s): the gateway passed it on", len(recs), marker)
		}
	}
}

// expectLayer checks that the layer want refused o.
func expectLayer(c *C, what string, o outcome.Outcome, src Source, want outcome.Layer) bool {
	got := outcome.Refuser(o, src.Source)
	if got == want {
		c.Logf("%s: refused by %s, as due: %s", what, want, o)
		return true
	}
	switch {
	case o.Kind == outcome.Error:
		c.Errorf("%s: could not tell: %s", what, o)
	case got == outcome.None:
		c.Errorf("%s: want %s to refuse, but it got through: %s", what, want, o)
	default:
		c.Errorf("%s: want %s to refuse, but %s did: %s. The case cannot pass because another layer refused first", what, want, got, o)
	}
	return false
}

// expectGateway checks that the gateway itself refused o with status.
func expectGateway(c *C, what string, o outcome.Outcome, src Source, status int) bool {
	if !expectLayer(c, what, o, src, outcome.Gateway) {
		return false
	}
	if o.Status != status {
		c.Errorf("%s: want the gateway's %d, got its %d: a different check refused (%s)", what, status, o.Status, o)
		return false
	}
	return true
}

// expectThrough checks that o got through every layer with status 200.
func expectThrough(c *C, what string, o outcome.Outcome, ok bool) bool {
	if ok {
		return true
	}
	c.Errorf("allowed twin (%s): want it to get through, got %s", what, o)
	return false
}

// token gets role's token for route's scope, or ends the case.
func token(c *C, role, route string) string {
	r := c.Env.Cfg.Routes[route]
	if r.Scope == "" {
		c.Fatalf("route %s has no scope: persona tokens exist only for the developer deployment's routes", route)
	}
	t, err := c.Env.Tokens.Token(c, role, r.Scope)
	if err != nil {
		c.Fatalf("%s's token for %s: %v", role, route, err)
	}
	return t
}

// claims decodes a token's claims or ends the case.
func claims(c *C, raw string) map[string]any {
	t, err := jose.Parse(raw)
	if err != nil {
		c.Fatalf("not a JWS: %v", err)
	}
	return t.Claims
}

// audiences lists a token's aud values.
func audiences(cl map[string]any) []string {
	switch a := cl["aud"].(type) {
	case string:
		return []string{a}
	case []any:
		var out []string
		for _, v := range a {
			if s, ok := v.(string); ok {
				out = append(out, s)
			}
		}
		return out
	}
	return nil
}

// actChain lists the act.sub values of claims, outermost first.
func actChain(cl map[string]any) []string {
	var out []string
	cur, _ := cl["act"].(map[string]any)
	for cur != nil {
		s, _ := cur["sub"].(string)
		out = append(out, s)
		cur, _ = cur["act"].(map[string]any)
	}
	return out
}

// developerRoutes lists the developer deployment's routes of a kind, by
// name.
func (e *Env) developerRoutes(kind string) []string {
	var out []string
	for name, r := range e.Cfg.Routes {
		if strings.HasPrefix(name, "gateway/") && r.Kind == kind && r.Scope != "" {
			out = append(out, name)
		}
	}
	sort.Strings(out)
	return out
}

// otherRoute is a developer-deployment route other than route, with a
// scope, for a token with another audience.
func (e *Env) otherRoute(route string) string {
	var names []string
	for name, r := range e.Cfg.Routes {
		if name != route && strings.HasPrefix(name, "gateway/") && r.Scope != "" {
			names = append(names, name)
		}
	}
	sort.Strings(names)
	if len(names) == 0 {
		return ""
	}
	return names[0]
}

func contains(xs []string, x string) bool { return slices.Contains(xs, x) }
