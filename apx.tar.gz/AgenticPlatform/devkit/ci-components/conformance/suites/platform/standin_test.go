package platform_test

import (
	"context"
	"os"
	"sort"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/suites/platform/standin"
)

// The suites' own tests: run every case against the stand-in platform,
// right and then wrong in one property at a time, and check each case's
// verdict. The stand-in is a script of the right answers, not the
// platform, so these tests show that the cases detect wrong behaviour,
// with a message that names it; only a run against the cluster shows the
// platform passes them.

// skippedEverywhere are the cases no stand-in run meets the needs of.
var skippedEverywhere = map[string]string{
	"gateway-path/token/gateway/v1/expired-held":              "slow",
	"gateway-path/token/gateway/mcp/capture-mcp/expired-held": "slow",
}

func run(t *testing.T, f standin.Faults) map[string]runner.Result {
	t.Helper()
	w, err := standin.New(f)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(w.Close)
	env, err := w.Env()
	if err != nil {
		t.Fatal(err)
	}
	out := map[string]runner.Result{}
	for _, k := range platform.Cases() {
		out[k.ID] = runner.Run(context.Background(), env, k)
	}
	return out
}

// TestRightAnswers: on the right answers, every case passes but those
// that need what no stand-in has.
func TestRightAnswers(t *testing.T) {
	for id, r := range run(t, standin.Faults{}) {
		if need, ok := skippedEverywhere[id]; ok {
			if r.Status != runner.Skip || !strings.Contains(r.Message, need) {
				t.Errorf("%s: want skipped for %s, got %s: %s", id, need, r.Status, r.Message)
			}
			continue
		}
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass on the right answers, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
}

// faults lists, for each fault, the cases it must fail and words their
// message must contain. Every other case must still pass, so a fault shows
// exactly which cases detect it.
var faults = []struct {
	name   string
	f      standin.Faults
	expect map[string]string // case ID or prefix (ending in /) -> words
}{
	{"alg none accepted", standin.Faults{AcceptAlgNone: true}, map[string]string{
		"gateway-path/token/gateway/v1/alg-none": "got through", "gateway-path/token/gateway/mcp/capture-mcp/alg-none": "got through"}},
	{"HS256 with the public key accepted", standin.Faults{AcceptHS256: true}, map[string]string{
		"gateway-path/token/gateway/v1/hs256-public-key": "got through", "gateway-path/token/gateway/mcp/capture-mcp/hs256-public-key": "got through"}},
	{"no signature check", standin.Faults{NoSignatureCheck: true}, map[string]string{
		"gateway-path/token/gateway/v1/other-issuer": "got through", "gateway-path/token/gateway/mcp/capture-mcp/other-issuer": "got through",
		"gateway-path/token/gateway/v1/bad-signature": "got through", "gateway-path/token/gateway/mcp/capture-mcp/bad-signature": "got through",
		"gateway-path/token/gateway/v1/unknown-kid": "got through", "gateway-path/token/gateway/mcp/capture-mcp/unknown-kid": "got through"}},
	// alg none and HS256 are still refused by the token-profile rule, which
	// runs first: this fault breaks only the JWT policy.
	{"no token-profile rules (T22)", standin.Faults{NoProfileRules: true}, map[string]string{
		"gateway-path/token/gateway/v1/alg-none": "want the gateway's 403, got its 401", "gateway-path/token/gateway/mcp/capture-mcp/alg-none": "want the gateway's 403, got its 401",
		"gateway-path/token/gateway/v1/hs256-public-key": "want the gateway's 403, got its 401", "gateway-path/token/gateway/mcp/capture-mcp/hs256-public-key": "want the gateway's 403, got its 401",
		"gateway-path/token/gateway/v1/typ-jwt": "got through", "gateway-path/token/gateway/mcp/capture-mcp/typ-jwt": "got through",
		"gateway-path/token/gateway/v1/two-audiences": "got through", "gateway-path/token/gateway/mcp/capture-mcp/two-audiences": "got through",
		"kagent/k2/actor-token-elsewhere": "want the gateway's 403, got its 401"}},
	{"typ not checked (T22)", standin.Faults{IgnoreTyp: true}, map[string]string{
		"gateway-path/token/gateway/v1/typ-jwt": "got through", "gateway-path/token/gateway/mcp/capture-mcp/typ-jwt": "got through",
		"kagent/k2/actor-token-elsewhere": "want the gateway's 403, got its 401"}},
	{"two audiences accepted", standin.Faults{AcceptMultiAud: true}, map[string]string{
		"gateway-path/token/gateway/v1/two-audiences": "got through", "gateway-path/token/gateway/mcp/capture-mcp/two-audiences": "got through"}},
	{"audience not checked", standin.Faults{IgnoreAud: true}, map[string]string{
		"gateway-path/token/gateway/v1/other-audience": "got through", "gateway-path/token/gateway/mcp/capture-mcp/other-audience": "got through",
		"delegation/replay-elsewhere": "got through", "kagent/k2/hosted-agent-route": "got through"}},
	{"exp not checked", standin.Faults{IgnoreExp: true}, map[string]string{
		"gateway-path/token/gateway/v1/expired": "got through", "gateway-path/token/gateway/mcp/capture-mcp/expired": "got through"}},
	{"nbf not checked", standin.Faults{IgnoreNbf: true}, map[string]string{
		"gateway-path/token/gateway/v1/nbf-120s-ahead": "got through", "gateway-path/token/gateway/mcp/capture-mcp/nbf-120s-ahead": "got through"}},
	{"403 where 401 is due", standin.Faults{Status403For401: true}, map[string]string{
		"gateway-path/token/": "want the gateway's 401, got its 403", "delegation/forwarded-token": "want the gateway's 401",
		// The token-profile rules' cases, whose 403 is due.
		"gateway-path/token/gateway/v1/two-audiences": "-", "gateway-path/token/gateway/mcp/capture-mcp/two-audiences": "-",
		"gateway-path/token/gateway/v1/alg-none": "-", "gateway-path/token/gateway/mcp/capture-mcp/alg-none": "-",
		"gateway-path/token/gateway/v1/hs256-public-key": "-", "gateway-path/token/gateway/mcp/capture-mcp/hs256-public-key": "-",
		"gateway-path/token/gateway/v1/typ-jwt": "-", "gateway-path/token/gateway/mcp/capture-mcp/typ-jwt": "-",
		"delegation/chain-token-on-developer-deployment": "want the gateway's 401", "delegation/replay-elsewhere": "want the gateway's 401",
		"delegation/person-token-on-workloads-deployment": "want the gateway's 401", "kagent/k2/": "want the gateway's 401, got its 403"}},
	// The STS issues only hosted-workloads audiences and Keycloak only the
	// developer deployment's, so a token on the wrong deployment always
	// breaks two properties, its issuer and its audience: these cases
	// detect a deployment that checks neither, not one that checks one.
	{"chain tokens on the developer deployment, audience not checked", standin.Faults{ChainOnDeveloper: true, IgnoreAud: true}, map[string]string{
		"delegation/chain-token-on-developer-deployment": "got through", "delegation/replay-elsewhere": "got through",
		"gateway-path/token/gateway/v1/other-audience": "got through", "gateway-path/token/gateway/mcp/capture-mcp/other-audience": "got through",
		"kagent/k2/hosted-agent-route": "got through"}},
	{"person tokens on the hosted-workloads deployment, audience not checked", standin.Faults{PersonOnWorkloads: true, IgnoreAud: true}, map[string]string{
		"delegation/forwarded-token": "want the gateway's 401", "delegation/person-token-on-workloads-deployment": "want the gateway's 401", "delegation/replay-elsewhere": "got through",
		"gateway-path/token/gateway/v1/other-audience": "got through", "gateway-path/token/gateway/mcp/capture-mcp/other-audience": "got through",
		"kagent/k2/hosted-agent-route": "want the gateway's 401"}},
	{"anonymous registration admitted", standin.Faults{AnonymousRegistration: true}, map[string]string{
		"gateway-path/mcp/anonymous-registration": "registered an anonymous client"}},
	{"the gateway answers registration", standin.Faults{GatewayAnswersRegistration: true}, map[string]string{
		"gateway-path/mcp/anonymous-registration": "must not answer for it"}},
	{"the MCP client is not pre-registered", standin.Faults{NoPreRegisteredClient: true}, map[string]string{
		"gateway-path/mcp/anonymous-registration": "did not go on to sign-in"}},
	{"roles not checked", standin.Faults{SkipRoleCheck: true}, map[string]string{"gateway-path/authz/role-not-admitted": "got through"}},
	{"team not required", standin.Faults{SkipTeamCheck: true}, map[string]string{"gateway-path/authz/no-team": "got through"}},
	{"outermost actor not checked", standin.Faults{IgnoreOutermostActor: true}, map[string]string{"delegation/outermost-actor": "got through"}},
	{"a provider's model name served", standin.Faults{PassUnknownModel: true}, map[string]string{"gateway-path/model/provider-name": "was served"}},
	{"non-LLM paths passed through", standin.Faults{PassNonLLMPath: true}, map[string]string{"gateway-path/model/non-llm-path": "passed a non-LLM path through"}},
	{"providers' names listed", standin.Faults{ListProviderModels: true}, map[string]string{"gateway-path/model/models-list": "no approved alias"}},
	{"no tool filter", standin.Faults{NoToolFilter: true}, map[string]string{
		"gateway-path/mcp/hidden-tool-listed": "did not filter", "gateway-path/mcp/hidden-tool-called": "did not refuse"}},
	{"the caller's token sent to the model", standin.Faults{ForwardModelToken: true}, map[string]string{
		"gateway-path/model/aliases": "credential headers", "gateway-path/upstream/model-headers": "credential headers"}},
	{"model headers dropped", standin.Faults{DropModelHeaders: true}, map[string]string{"gateway-path/upstream/model-headers": "arrived as"}},
	{"the MCP route strips the token", standin.Faults{DropMCPToken: true}, map[string]string{
		"gateway-path/upstream/mcp-token": "no bearer token", "delegation/": "no bearer token", "delegation/person-token-on-workloads-deployment": "-"}},
	{"the limited team's window crossed for an hour already", standin.Faults{LimitWindowLong: true}, map[string]string{
		"gateway-path/limits/team-tokens": "the crossing cannot be observed"}},
	{"the test issuer in the limited team", standin.Faults{TestIssuerInLimitTeam: true}, map[string]string{
		"gateway-path/limits/team-tokens": "whose budget this case drains"}},
	{"no limit", standin.Faults{NoLimit: true}, map[string]string{"gateway-path/limits/team-tokens": "no 429"}},
	{"no Retry-After", standin.Faults{NoRetryAfter: true}, map[string]string{"gateway-path/limits/team-tokens": "Retry-After"}},
	{"one limit for every team", standin.Faults{LimitAllTeams: true}, map[string]string{"gateway-path/limits/team-tokens": "another team's request"}},
	{"attribution from a header", standin.Faults{AttributionFromHeader: true}, map[string]string{"gateway-path/attribution/from-token": "did not come from the token"}},
	{"wrong cost", standin.Faults{WrongCost: true}, map[string]string{"gateway-path/attribution/from-token": "cost"}},
	{"attribution from baggage", standin.Faults{TeamFromBaggage: true}, map[string]string{"gateway-path/attribution/from-token": "did not come from the token"}},
	{"the user from a header", standin.Faults{UserFromHeader: true}, map[string]string{"gateway-path/attribution/from-token": "did not come from the token"}},
	{"the alias recorded as the provider model", standin.Faults{UsageUnmappedModel: true}, map[string]string{"gateway-path/attribution/from-token": "request_model"}},
	{"token counts not the model's", standin.Faults{UsageWrongTokens: true}, map[string]string{"gateway-path/attribution/from-token": "output_tokens"}},
	{"a request recorded twice", standin.Faults{UsageTwice: true}, map[string]string{"gateway-path/attribution/from-token": "exactly one"}},
	{"no usage record", standin.Faults{NoUsageRecord: true}, map[string]string{"gateway-path/attribution/from-token": "never arrived", "telemetry/canary/records": "no row in the usage table",
		"telemetry/records/workload-port": "no row of the usage table"}},
	{"GenAI content kept for Dynatrace", standin.Faults{DynatraceKeepsContent: true}, map[string]string{"telemetry/canary/dynatrace": "holds the marker"}},
	{"error traces sampled away", standin.Faults{NoErrorPolicy: true}, map[string]string{
		"telemetry/canary/dynatrace": "lacks the runner's", "telemetry/sampling/no-genai": "never reached the Dynatrace stand-in",
		"telemetry/error/provider-echo": "never reached the Dynatrace stand-in"}},
	{"an error's message kept for Dynatrace", standin.Faults{NoErrorScrub: true}, map[string]string{"telemetry/error/provider-echo": "holds the marker"}},
	{"the error scrub drops the error's type", standin.Faults{ErrorScrubDropsType: true}, map[string]string{"telemetry/error/provider-echo": "error.type"}},
	{"no span metrics", standin.Faults{NoSpanMetrics: true}, map[string]string{"telemetry/canary/dynatrace": "no span metrics"}},
	{"the gateway traces nothing", standin.Faults{GatewayNoTracing: true}, map[string]string{"telemetry/canary/dynatrace": "no span of the gateway's"}},
	{"no redaction for Langfuse", standin.Faults{LangfuseNoRedaction: true}, map[string]string{"telemetry/canary/langfuse": "holds a canary secret",
		"telemetry/error/provider-echo-langfuse": "not with each secret replaced"}},
	{"a status's description unmasked for Langfuse", standin.Faults{LangfuseStatusUnmasked: true}, map[string]string{
		"telemetry/error/provider-echo-langfuse": "not with each secret replaced"}},
	{"secret patterns too narrow", standin.Faults{NarrowSecretPatterns: true}, map[string]string{"telemetry/canary/langfuse": "random part",
		"telemetry/error/provider-echo-langfuse": "random part"}},
	{"content deleted for Langfuse too", standin.Faults{LangfuseDropsContent: true}, map[string]string{"telemetry/canary/langfuse": "lacks the marker"}},
	{"every trace kept for Langfuse", standin.Faults{LangfuseKeepsAll: true}, map[string]string{"telemetry/sampling/no-genai": "reached Langfuse"}},
	{"nothing reaches Langfuse", standin.Faults{NoLangfuseExport: true}, map[string]string{
		"telemetry/canary/langfuse": "no observation", "telemetry/sampling/no-genai": "never reached Langfuse",
		"telemetry/error/provider-echo": "allowed twin", "telemetry/error/provider-echo-langfuse": "no observation of the failed call"}},
	{"the gateway's record holds the prompt", standin.Faults{RecordCarriesPrompt: true}, map[string]string{"telemetry/canary/records": "holds the marker"}},
	{"no audit export", standin.Faults{NoAuditExport: true}, map[string]string{"telemetry/canary/records": "no object in s3://"}},
	{"a general port keeps a record's own source (TM15)", standin.Faults{WorkloadKeepsSource: true}, map[string]string{"telemetry/records/workload-port": `record.source "platform"`}},
	{"a general port's records reach the usage table (TM15)", standin.Faults{WorkloadRecordsToUsage: true}, map[string]string{"telemetry/records/workload-port": "reached the usage table"}},
	{"the platform port's records stamped workload", standin.Faults{PlatformStampedWorkload: true}, map[string]string{
		"telemetry/canary/records": "no record with trace ID", "telemetry/records/workload-port": `record.source "workload", not platform`}},
	// The records store (B5): the cases read it, and a failed read is an
	// error, never "no record".
	{"the SIEM's store drops its newest line", standin.Faults{RecordsDropNewest: true}, map[string]string{"telemetry/canary/records": "no record with trace ID",
		"telemetry/records/workload-port": "never reached the SIEM"}},
	{"the records store down", standin.Faults{RecordsStoreDown: true}, map[string]string{
		"telemetry/canary/dynatrace": "records store", "telemetry/canary/records": "records store", "telemetry/sampling/no-genai": "records store",
		"telemetry/records/workload-port": "records store", "telemetry/error/provider-echo": "records store"}},
	{"the platform port open to any principal (TM15)", standin.Faults{PlatformPortOpen: true}, map[string]string{"telemetry/platform-port/authorization-policy": "got through"}},
	{"plaintext to the general ports from every governed namespace", standin.Faults{GeneralPortsAnyGoverned: true}, map[string]string{
		"telemetry/general-ports/networkpolicy": "got through"}},
	{"the platform port closed to the meshed probe", standin.Faults{PlatformPortClosedToProbe: true}, map[string]string{
		"telemetry/platform-port/networkpolicy": "allowed twin", "telemetry/platform-port/authorization-policy": "but networkpolicy did"}},
	{"the STS names another actor", standin.Faults{STSWrongActor: true}, map[string]string{
		"delegation/end-to-end": "outermost actor", "delegation/forwarded-token": "outermost actor", "delegation/outermost-actor": "act chain",
		"delegation/chain-token-on-developer-deployment": "outermost actor", "delegation/replay-elsewhere": "outermost actor",
		"kagent/k2/": "outermost actor"}},
	{"no NetworkPolicy (kindnet, T21)", standin.Faults{NoNetworkPolicy: true}, map[string]string{
		"bypass/ingress/networkpolicy/sidecar-port":   "got through",
		"bypass/egress/networkpolicy/fake-model":      "but authorization-policy did",
		"bypass/egress/networkpolicy/model-providers": "got through to the outside",
		"bypass/egress/networkpolicy/tool-upstreams":  "got through to the outside",
		"telemetry/platform-port/networkpolicy":       "but strict-mtls did",
		"telemetry/general-ports/networkpolicy":       "got through",
		"kagent/k7/networkpolicy":                     "but gateway did",
	}},
	{"no AuthorizationPolicy", standin.Faults{NoAuthorizationPolicy: true}, map[string]string{
		"bypass/ingress/authorization-policy/capture-mcp": "got through", "bypass/ingress/authorization-policy/fake-model-ops": "got through",
		"telemetry/platform-port/authorization-policy": "got through"}},
	{"PERMISSIVE mTLS", standin.Faults{PermissiveMTLS: true}, map[string]string{
		"bypass/ingress/strict-mtls/capture-mcp": "but authorization-policy did", "bypass/ingress/networkpolicy/sidecar-port": "allowed twin"}},
	{"the mesh refuses outside hosts (REGISTRY_ONLY)", standin.Faults{MeshBlocksEgress: true}, map[string]string{
		"bypass/egress/networkpolicy/model-providers": "but mesh-egress did", "bypass/egress/networkpolicy/tool-upstreams": "but mesh-egress did"}},
	{"no internet anywhere", standin.Faults{NoInternet: true}, map[string]string{
		"bypass/egress/networkpolicy/model-providers": "proves nothing", "bypass/egress/networkpolicy/tool-upstreams": "proves nothing"}},
	{"no admission rules", standin.Faults{NoKyverno: true}, map[string]string{"bypass/admission/": "admitted, want", "kagent/admission/": "admitted, want"}},
	{"RBAC refuses the runner", standin.Faults{RBACForbidden: true}, map[string]string{"bypass/admission/": "RBAC refused the runner", "kagent/admission/": "RBAC refused the runner"}},
	{"another rule refuses", standin.Faults{WrongRule: true}, map[string]string{"bypass/admission/": "not by", "kagent/admission/": "not by"}},
	{"another clause refuses", standin.Faults{WrongClause: true}, map[string]string{"bypass/admission/": "not by its clause", "kagent/admission/": "not by its clause"}},
	// Rules that refuse what they must admit: each fails the allowed twin
	// of its kind.
	{"every AgentgatewayPolicy refused", standin.Faults{RefusePolicies: true}, map[string]string{
		"bypass/admission/backend-targets-keys": "allowed twin, the platform's key-set backend", "bypass/admission/gateway-policy-floor": "allowed twin, agent-integration's policy"}},
	{"every approval path refused", standin.Faults{RefuseApprovalsPath: true}, map[string]string{"bypass/admission/route-claims": "allowed twin, the MCP route with its approval path"}},
	{"every workload label but the workload's refused", standin.Faults{RefuseOtherLabels: true}, map[string]string{"bypass/admission/route-claims": "allowed twin, a second workload the namespace hosts"}},
	{"every backend's own MCP authentication refused", standin.Faults{RefuseBackendMCPAuth: true}, map[string]string{"bypass/admission/gateway-policy-floor": "allowed twin, a backend's own MCP authentication"}},
	{"every route on the hosted-workloads deployment refused", standin.Faults{RefuseWorkloadsGatewayRoutes: true}, map[string]string{"bypass/admission/route-claims": "allowed twin, the workload's route on the hosted-workloads deployment's listener"}},
	{"every ExternalSecret refused", standin.Faults{RefuseExternalSecrets: true}, map[string]string{"bypass/admission/secret-stores": "allowed twin, the workload's own key"}},
	{"Helm keeps a chart's ownership annotation", standin.Faults{HelmKeepsAnnotation: true}, map[string]string{"bypass/admission/helm-ownership": "Helm kept the chart's annotation"}},
	{"Bedrock open to every role", standin.Faults{BedrockOpen: true}, map[string]string{"bypass/aws/bedrock": "want AccessDenied"}},
	// The kagent group (B4).
	{"the kagent agent's hosted route names no actor", standin.Faults{KagentRouteNoActors: true}, map[string]string{"kagent/k2/": "allowed twin"}},
	{"Substrate's listener open to the probes", standin.Faults{ListenerOpen: true}, map[string]string{"kagent/k7/networkpolicy": "but gateway did"}},
	{"the fixture agent's worker off the sandbox node", standin.Faults{WorkerOffSandbox: true}, map[string]string{"kagent/admission/sandbox-privileges": "without the sandbox node's selector"}},
	{"every pod refused", standin.Faults{RefusePods: true}, map[string]string{"kagent/admission/sandbox-privileges": "allowed twin, a plain non-root pod",
		"bypass/admission/image-verification/": "allowed twin, a release signed, attested and conformance-attested"}},
	{"every ModelConfig and RemoteMCPServer refused", standin.Faults{RefuseKagentConfigs: true}, map[string]string{"kagent/admission/kagent-floor": "allowed twin, the ModelConfig"}},
}

// expected gives a case's expected failure words under a fault: by exact
// ID, then by prefix (a key ending in /). "-" exempts a case a prefix names.
func expected(expect map[string]string, id string) (string, bool) {
	if w, ok := expect[id]; ok {
		return w, w != "-"
	}
	for k, w := range expect {
		if strings.HasSuffix(k, "/") && strings.HasPrefix(id, k) {
			if _, exact := expect[id]; !exact {
				return w, true
			}
		}
	}
	return "", false
}

func TestFaults(t *testing.T) {
	for _, fc := range faults {
		t.Run(fc.name, func(t *testing.T) {
			for id, r := range run(t, fc.f) {
				if _, ok := skippedEverywhere[id]; ok {
					continue
				}
				words, want := expected(fc.expect, id)
				switch {
				case want && r.Status != runner.Fail:
					t.Errorf("%s: want fail, got %s", id, r.Status)
				case want && !strings.Contains(r.Message, words):
					t.Errorf("%s: want a message with %q, got:\n%s", id, words, r.Message)
				case !want && r.Status != runner.Pass:
					t.Errorf("%s: want pass (the fault is not this case's), got %s:\n%s", id, r.Status, r.Message)
				}
			}
		})
	}
}

// TestLimitWindowCrossed: a run that finds the limited team's window
// crossed already, as by an earlier run, waits for it to reset and then
// sees the crossing itself.
func TestLimitWindowCrossed(t *testing.T) {
	r := run(t, standin.Faults{LimitWindowCrossed: true})["gateway-path/limits/team-tokens"]
	logs := strings.Join(r.Logs, "\n")
	if r.Status != runner.Pass || !strings.Contains(logs, "waiting") || !strings.Contains(logs, "crossed after") {
		t.Errorf("want a pass that waited and then crossed, got %s: %s\n%s", r.Status, r.Message, logs)
	}
}

// TestLateDecisions: with tail sampling's decisions later than every
// wait the configuration gives, as a loaded runner's timers fire, every
// case still passes: the cases wait on the stand-in's delivery signal,
// not on wall time. Before they did, the canary's spans missed the
// Dynatrace stand-in's 3-second bound on CI (!37's MR pipeline 3083538929).
func TestLateDecisions(t *testing.T) {
	for id, r := range run(t, standin.Faults{LateDecisions: true}) {
		if _, ok := skippedEverywhere[id]; ok {
			continue
		}
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass with late decisions, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
}

// TestEarlierModelRecords: the fake model server keeps the records of
// every run since it started, so a run may find more of them than a
// Runner request's body holds (outcome.MaxBody). Every case still passes,
// and non-llm-path, which reads them all, still sees a non-LLM path the
// gateway passes through.
func TestEarlierModelRecords(t *testing.T) {
	for id, r := range run(t, standin.Faults{EarlierModelRecords: true}) {
		if _, ok := skippedEverywhere[id]; ok {
			continue
		}
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass after earlier runs' records, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
	r := run(t, standin.Faults{EarlierModelRecords: true, PassNonLLMPath: true})["gateway-path/model/non-llm-path"]
	if r.Status != runner.Fail || !strings.Contains(r.Message, "passed a non-LLM path through") {
		t.Errorf("non-llm-path after earlier runs' records, with non-LLM paths passed through: want a fail naming it, got %s: %s", r.Status, r.Message)
	}
}

// TestSinkLogRotation: without a records store, the stand-ins are read
// through their pod's log, which rotates after every read, so each line
// is served once; the telemetry cases keep what they read and still
// pass, and say that the log rotated.
func TestSinkLogRotation(t *testing.T) {
	results := run(t, standin.Faults{SinkLogRotates: true, NoRecordsStore: true})
	var named bool
	for id, r := range results {
		if !strings.HasPrefix(id, "telemetry/") {
			continue
		}
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass with the logs rotating, got %s:\n%s", id, r.Status, r.Message)
		}
		named = named || strings.Contains(strings.Join(r.Logs, "\n"), "rotated")
	}
	if !named {
		t.Error("no telemetry case said that a stand-in's log rotated")
	}
}

// TestRecordsStore: from the records store, which serves the rotated
// files too, a rotating log changes nothing, and no case reads the log.
func TestRecordsStore(t *testing.T) {
	for id, r := range run(t, standin.Faults{SinkLogRotates: true}) {
		if !strings.HasPrefix(id, "telemetry/") {
			continue
		}
		if r.Status != runner.Pass {
			t.Errorf("%s: want pass from the records store, got %s:\n%s", id, r.Status, r.Message)
		}
		if logs := strings.Join(r.Logs, "\n"); strings.Contains(logs, "rotated") {
			t.Errorf("%s: read the pod's log, not the records store:\n%s", id, logs)
		}
	}
}

// TestTelemetryAgent: an agent plays the telemetry group's turn, as
// reference-agent does in the integration stage (B5); its cases pass, and
// fail when the agent starts a trace of its own.
func TestTelemetryAgent(t *testing.T) {
	agent := platform.TelemetryAgent{Name: standin.TelemetryAgent, Route: "gateway/a2a/" + standin.TelemetryAgent,
		Scope: "a2a/" + standin.TelemetryAgent, Tool: "get_note", Arg: "note_id"}
	runAgent := func(f standin.Faults) map[string]runner.Result {
		w, err := standin.New(f)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(w.Close)
		env, err := w.Env()
		if err != nil {
			t.Fatal(err)
		}
		ae := env.WithTelemetryAgent(agent)
		out := map[string]runner.Result{}
		for _, k := range platform.TelemetryAgentCases() {
			out[k.ID] = runner.Run(context.Background(), ae, k)
		}
		return out
	}
	for id, r := range runAgent(standin.Faults{}) {
		if r.Status != runner.Pass {
			t.Errorf("%s with the agent's turn: want pass, got %s:\n%s\n%s", id, r.Status, r.Message, strings.Join(r.Logs, "\n"))
		}
	}
	want := map[string]string{
		"telemetry/canary/dynatrace": "lacks", "telemetry/canary/records": "no record with trace ID",
		"telemetry/canary/langfuse": "no observation", "telemetry/sampling/no-genai": "never reached Langfuse",
		"telemetry/records/workload-port": "the gateway's own record",
	}
	for id, r := range runAgent(standin.Faults{AgentOwnTrace: true}) {
		if words := want[id]; r.Status != runner.Fail || !strings.Contains(r.Message, words) {
			t.Errorf("%s with an agent that starts its own trace: want a fail naming %q, got %s:\n%s", id, words, r.Status, r.Message)
		}
	}
}

// TestEveryCaseDetectsSomething: every case fails against at least one
// fault, so none passes because nothing answers.
func TestEveryCaseDetectsSomething(t *testing.T) {
	detected := map[string]bool{}
	for _, fc := range faults {
		for _, k := range platform.Cases() {
			if _, ok := expected(fc.expect, k.ID); ok {
				detected[k.ID] = true
			}
		}
	}
	var missing []string
	for _, k := range platform.Cases() {
		if _, ok := skippedEverywhere[k.ID]; !ok && !detected[k.ID] {
			missing = append(missing, k.ID)
		}
	}
	sort.Strings(missing)
	if len(missing) > 0 {
		t.Errorf("no fault makes these cases fail: %s", strings.Join(missing, ", "))
	}
}

func TestMain(m *testing.M) { os.Exit(m.Run()) }
