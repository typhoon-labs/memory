package platform

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	relayagent "gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/relay-agent"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// The kagent group (plan/local-build.md, "B4 in detail", The checks): the
// bypass and token checks of kagent's controls (design/runtime.md, K2, K6
// and K7, and kagent-floor) that need no running actor, beside the three
// suites. K2 at Substrate's listener with an actor's own token, and every
// check through an actor, are the kagent profile's (suites/kagent): the
// runner holds no Substrate signing key, and only Substrate's egress
// reaches that listener.
const SuiteKagent = "kagent"

func kagentCases() []Case {
	out := []Case{
		{
			ID: "kagent/k2/actor-token-elsewhere", Suite: SuiteKagent, Layer: string(outcome.Gateway), Cluster: true,
			Needs: []runner.Need{NeedHostedDeployment, NeedPersona(RoleDeveloper), NeedRoute("gateway/v1"), NeedRoute(relayRoute), NeedRoute(chainModel)},
			Row:   "K2: a Substrate actor token, typed JWT, is refused on every listener but Substrate's (403, the token profile)",
			Title: "a token in Substrate's actor-token shape, typed JWT, gets 403 from the token profile on the model routes and the kagent agent's A2A routes of both deployments' other listeners, and typed at+jwt the JWT policy's 401, since none trusts Substrate's issuer; each route's own token passes",
			Run:   actorTokenElsewhereCase,
		},
		{
			ID: "kagent/k2/hosted-agent-route", Suite: SuiteKagent, Layer: string(outcome.Gateway), Cluster: true,
			Needs: []runner.Need{NeedHostedDeployment, NeedPersona(RoleDeveloper), NeedRoute(relayRoute), NeedRoute(chainMCPRoute)},
			Row:   "K2: on the hosted-workloads deployment, a kagent agent's route admits only chain tokens for itself",
			Title: "on the kagent agent's route of the hosted-workloads deployment, a person's token for its developer route and relay-agent's chain token for capture-mcp's route get 401; relay-agent's chain token for the agent's route reaches kagent",
			Run:   hostedAgentRouteCase,
		},
		{
			ID: "kagent/k7/networkpolicy", Suite: SuiteKagent, Layer: string(outcome.NetworkPolicy), Cluster: true,
			Needs: []runner.Need{NeedProbeMeshed, NeedProbeNomesh},
			Row:   "K7: Substrate's listener on the hosted-workloads deployment is refused by NetworkPolicy to every source but Substrate's egress",
			Title: "both probes calling Substrate's listener are dropped by NetworkPolicy; the runner, whose namespace NetworkPolicy admits to the same deployment's https listener, gets its answer there",
			Run:   listenerNetworkPolicyCase,
		},
	}
	for _, r := range kagentAdmissionRules() {
		out = append(out, admissionCase(r))
	}
	return out
}

// kagentRoute is the kagent agent's A2A route on a deployment.
func (e *Env) kagentRoute(gateway string) string { return gateway + "/a2a/" + e.Cfg.Kagent.Agent }

// listenerAudience is Substrate's listener's one audience (D18).
func (e *Env) listenerAudience() string {
	return "https://workloads-gateway." + e.Cfg.PlatformDomain + "/" + e.Cfg.Kagent.Listener
}

// actorToken is a token in the shape Substrate's actor tokens have (its
// docs/guides/actor-jwts.md at v1.0.0, as B4 minted them): typ, ES256,
// Substrate's issuer, sub actor/<atespace>/<name>, the listener's audience
// as an array, nbf five minutes back, at most 300 seconds, a jti and
// actor.ate.dev. It is signed with a key no one trusts: the runner holds
// no Substrate key, and the token profile judges a token's type before
// any signature.
func (e *Env) actorToken(c *C, typ string) string {
	now := time.Now()
	name := "conformance-" + e.RunID
	t, err := jose.Sign(map[string]any{"alg": "ES256", "typ": typ, "kid": "conformance-untrusted"}, map[string]any{
		"iss": e.Cfg.Kagent.Issuer, "sub": "actor/" + e.Cfg.Kagent.Agent + "/" + name, "aud": []any{e.listenerAudience()},
		"iat": now.Unix(), "nbf": now.Add(-5 * time.Minute).Unix(), "exp": now.Add(5 * time.Minute).Unix(), "jti": jose.RandomID(13),
		"actor.ate.dev": map[string]any{"atespace": e.Cfg.Kagent.Agent, "actorName": name, "actorUID": jose.RandomID(16)},
	}, e.Untrusted)
	if err != nil {
		c.Fatalf("minting the actor-shaped token: %v", err)
	}
	return t
}

// kagentToken is the developer's token for the kagent agent's developer
// route.
func (e *Env) kagentToken(c *C) string {
	t, err := e.Tokens.Token(c, RoleDeveloper, e.Cfg.Kagent.Scope)
	if err != nil {
		c.Fatalf("the developer's token for %s: %v", e.Cfg.Kagent.Scope, err)
	}
	return t
}

// a2aProbe is the request the cases make of a kagent agent: GetTask for a
// task that does not exist, in A2A 1.0, which kagent answers with a
// JSON-RPC error and no side effect, actor or not.
func (e *Env) a2aProbe() string {
	b, _ := json.Marshal(map[string]any{"jsonrpc": "2.0", "id": 1, "method": "GetTask", "params": map[string]any{"id": "conformance-" + e.RunID}})
	return string(b)
}

func a2aHeader(token string) map[string]string {
	h := map[string]string{"Content-Type": "application/json", "Accept": "application/json", "A2A-Version": a2a.Version}
	if token != "" {
		h["Authorization"] = "Bearer " + token
	}
	return h
}

// callKagent makes the route's request: GetTask on an A2A route, a
// Messages call on a model route.
func (e *Env) callKagent(c *C, src Source, route, token string) outcome.Outcome {
	if strings.Contains(route, "/a2a/") {
		return e.Do(c, src, outcome.Request{Method: http.MethodPost, URL: e.Cfg.CallURL(route), Header: a2aHeader(token), Body: e.a2aProbe()})
	}
	return e.callModel(c, src, route, token, e.alias(), e.Marker("kagent"), nil)
}

// kagentAnswered checks that kagent itself answered: a JSON-RPC response,
// which no gateway gives.
func kagentAnswered(c *C, what string, o outcome.Outcome) bool {
	var r a2a.Response
	if o.Kind == outcome.Response && o.Status == http.StatusOK && json.Unmarshal([]byte(o.Body), &r) == nil && r.JSONRPC == "2.0" {
		c.Logf("%s: kagent answered: %s", what, outcome.Compact(o.Body))
		return true
	}
	c.Errorf("allowed twin (%s): want kagent's JSON-RPC answer through the gateway, got %s", what, o)
	return false
}

// kagentInstruction has relay-agent exchange for resource and send the
// probe request to the kagent agent's route on the hosted-workloads
// deployment.
func kagentInstruction(e *Env, resource string) relayagent.Instruction {
	return relayagent.Instruction{Mode: relayagent.Exchange, Resource: resource, Marker: e.Marker("kagent"),
		Call: relayagent.Target{Kind: "http", Method: http.MethodPost, URL: e.Cfg.RouteURL(e.kagentRoute("workloads-gateway")),
			Header: a2aHeader(""), Body: e.a2aProbe()}}
}

func actorTokenElsewhereCase(c *C) {
	e := c.Env
	for _, route := range []string{"gateway/v1", e.kagentRoute("gateway"), chainModel, e.kagentRoute("workloads-gateway")} {
		expectGateway(c, "an actor token typed JWT on "+route, e.callKagent(c, e.Runner, route, e.actorToken(c, "JWT")), e.Runner, http.StatusForbidden)
		// The same token typed for a route: the profile passes it, and the
		// JWT policy refuses Substrate's issuer, which no listener but
		// Substrate's trusts.
		expectGateway(c, "the same token typed at+jwt on "+route, e.callKagent(c, e.Runner, route, e.actorToken(c, "at+jwt")), e.Runner, http.StatusUnauthorized)
	}
	o := e.callModel(c, e.Runner, "gateway/v1", token(c, RoleDeveloper, "gateway/v1"), e.alias(), e.Marker("twin"), nil)
	expectThrough(c, "the developer's own token on gateway/v1", o, o.Kind == outcome.Response && o.Status == http.StatusOK)
	kagentAnswered(c, "the developer's own token on "+e.kagentRoute("gateway"), e.callKagent(c, e.Runner, e.kagentRoute("gateway"), e.kagentToken(c)))
	r := relayed(c, relayRoute, modelInstruction(e, e.Cfg.RouteURL(chainModel), e.Marker("twin")), true)
	expectThrough(c, "relay-agent's chain token on "+chainModel, r.Call.Outcome, r.Call.Outcome.Kind == outcome.Response && r.Call.Outcome.Status == http.StatusOK)
	r = relayed(c, relayRoute, kagentInstruction(e, e.Cfg.RouteURL(e.kagentRoute("workloads-gateway"))), true)
	kagentAnswered(c, "relay-agent's chain token on "+e.kagentRoute("workloads-gateway"), r.Call.Outcome)
}

func hostedAgentRouteCase(c *C) {
	e := c.Env
	hosted := e.kagentRoute("workloads-gateway")
	o := e.callKagent(c, e.Runner, hosted, e.kagentToken(c))
	expectGateway(c, "the developer's token for "+e.kagentRoute("gateway")+" on "+hosted, o, e.Runner, http.StatusUnauthorized)
	r := relayed(c, relayRoute, kagentInstruction(e, e.Cfg.RouteURL(chainMCPRoute)), true)
	expectGateway(c, "relay-agent's chain token for "+chainMCPRoute+" on "+hosted, r.Call.Outcome, e.agentSource(), http.StatusUnauthorized)
	r = relayed(c, relayRoute, kagentInstruction(e, e.Cfg.RouteURL(hosted)), true)
	kagentAnswered(c, "relay-agent's chain token for "+hosted, r.Call.Outcome)
}

func listenerNetworkPolicyCase(c *C) {
	e := c.Env
	listener := "https://workloads-gateway." + e.Cfg.PlatformDomain + ":" + strconv.Itoa(e.Cfg.Kagent.ListenerPort) + "/v1/models"
	for _, name := range []string{"nomesh", "meshed"} {
		src := e.Probes[name]
		o := e.Do(c, src, outcome.Request{Method: http.MethodGet, URL: listener, Timeout: outcome.Of(e.Cfg.Timing.MeshConnectTimeout.Duration + e.Cfg.Timing.Request.Duration)})
		expectLayer(c, src.Name+" to Substrate's listener", o, src, outcome.NetworkPolicy)
	}
	// The twin: the deployment answers where NetworkPolicy admits, here
	// the runner on its https listener, so the probes' drops are not a
	// deployment that is down. Substrate's egress itself, the listener's
	// one source, is an actor's path: the kagent profile's.
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodGet, URL: e.Cfg.CallURL(chainModel) + "/models"})
	if o.Kind != outcome.Response || outcome.Refuser(o, e.Runner.Source) != outcome.Gateway && outcome.Refuser(o, e.Runner.Source) != outcome.None {
		c.Errorf("allowed twin: the runner could not reach the hosted-workloads deployment's https listener either (%s), so the probes' drops prove nothing", o)
	} else {
		c.Logf("the runner reached the deployment's https listener: %s", o)
	}
}

// kagentAdmissionRules are the admission rules B4 added (plan/local-build.md,
// "B4 in detail", Kyverno), by server-side dry runs in the team namespace,
// as for the bypass suite's rules.
func kagentAdmissionRules() []admissionRule {
	return []admissionRule{
		{
			suite: SuiteKagent, name: "sandbox-privileges", row: "K6: sandbox-privileges",
			title: "a pod adding SYS_ADMIN, a privileged one, one mounting a host path, a worker's exact shape outside an agent namespace, and a WorkerPool, from a workload release, are refused by sandbox-privileges; a plain non-root pod is admitted, and the fixture agent's workers and atelet run on the sandbox node",
			refused: []admissionObject{
				{"a pod adding SYS_ADMIN", "pods", "no container adds a capability", pod("k6-sys-admin", func(p, ctr map[string]any) {
					ctr["securityContext"] = map[string]any{"capabilities": map[string]any{"add": []any{"SYS_ADMIN"}}}
				})},
				{"a privileged pod", "pods", "no container runs privileged", pod("k6-privileged", func(p, ctr map[string]any) {
					ctr["securityContext"] = map[string]any{"privileged": true}
				})},
				{"a pod mounting a host path", "pods", "no pod mounts a host path", pod("k6-host-path", func(p, ctr map[string]any) {
					p["volumes"] = []any{map[string]any{"name": "host", "hostPath": map[string]any{"path": "/etc"}}}
				})},
				{"a worker's exact shape outside an agent namespace", "pods", "no pod mounts a host path", workerPod},
				{"a WorkerPool from a workload release", "workerpools", "WorkerPools, SandboxConfigs, CSIDriverConfigs and Harnesses come only from platform releases", func(e *Env) map[string]any {
					return map[string]any{"apiVersion": "ate.dev/v1", "kind": "WorkerPool", "metadata": meta(e, "k6-pool", nil), "spec": map[string]any{
						"replicas": 1, "workerImage": workerImage,
						"sandboxClasses": []any{map[string]any{"name": "gvisor", "configRef": map[string]any{"name": "gvisor-platform"}}},
						"template":       sandboxPlacement(e)}}
				}},
			},
			allowed: []admissionObject{{"a plain non-root pod", "pods", "", pod("k6-own", nil)}},
			twin:    sandboxPodsCheck,
		},
		{
			suite: SuiteKagent, name: "kagent-floor", row: "kagent-floor",
			title: "a ModelConfig that forwards the caller's token, names an API key Secret, another provider, a URL off Substrate's listener, a route's own audience or a longer lifetime, a RemoteMCPServer taking a header from a Secret or off the listener, and an EgressPolicy from a workload release, are refused by kagent-floor; the ModelConfig and RemoteMCPServer kagent-agents renders are admitted",
			refused: []admissionObject{
				{"a ModelConfig forwarding the caller's token", "modelconfigs", "a ModelConfig or RemoteMCPServer forwards no caller's token", modelConfig("kf-passthrough", func(s map[string]any, e *Env) {
					delete(s, "actorJwt")
					s["tokenPassthrough"] = true
				})},
				{"a ModelConfig naming an API key Secret", "modelconfigs", "a ModelConfig names no API key Secret", modelConfig("kf-api-key", func(s map[string]any, e *Env) {
					delete(s, "actorJwt")
					s["apiKeySecret"], s["apiKeySecretKey"] = "provider-key", "key"
				})},
				{"a ModelConfig with another provider", "modelconfigs", "a ModelConfig uses the OpenAI provider", modelConfig("kf-provider", func(s map[string]any, e *Env) {
					s["provider"], s["anthropic"] = "Anthropic", map[string]any{"baseUrl": listenerURL(e) + "v1"}
					delete(s, "openAI")
				})},
				{"a ModelConfig off Substrate's listener", "modelconfigs", "a ModelConfig's or RemoteMCPServer's URL is on the hosted-workloads deployment's listener", modelConfig("kf-url", func(s map[string]any, e *Env) {
					s["openAI"].(map[string]any)["baseUrl"] = "https://api.openai.com/v1"
				})},
				{"a ModelConfig with its route's own audience", "modelconfigs", "a ModelConfig or RemoteMCPServer has an actorJwt with one audience", modelConfig("kf-route-audience", func(s map[string]any, e *Env) {
					s["actorJwt"].(map[string]any)["audiences"] = []any{e.Cfg.RouteURL("workloads-gateway/v1")}
				})},
				{"a ModelConfig whose actor tokens live longer", "modelconfigs", "a ModelConfig or RemoteMCPServer has an actorJwt with one audience", modelConfig("kf-lifetime", func(s map[string]any, e *Env) {
					s["actorJwt"].(map[string]any)["expirationSeconds"] = 900
				})},
				{"a RemoteMCPServer taking a header from a Secret", "remotemcpservers", "a RemoteMCPServer takes no header from a Secret", remoteMCPServer("kf-header-secret", func(s map[string]any, e *Env) {
					s["headersFrom"] = []any{map[string]any{"name": "X-Api-Key", "valueFrom": map[string]any{"type": "Secret", "name": "tool-key", "key": "token"}}}
				})},
				{"a RemoteMCPServer off Substrate's listener", "remotemcpservers", "a ModelConfig's or RemoteMCPServer's URL is on the hosted-workloads deployment's listener", remoteMCPServer("kf-mcp-url", func(s map[string]any, e *Env) {
					s["url"] = e.Cfg.RouteURL(chainMCPRoute)
				})},
				{"an EgressPolicy from a workload release", "egresspolicies", "an EgressPolicy comes only from a platform release", func(e *Env) map[string]any {
					return map[string]any{"apiVersion": "api.kagent.dev/v1alpha3", "kind": "EgressPolicy", "metadata": meta(e, "kf-egress", nil),
						"spec": map[string]any{"destinations": []any{map[string]any{"origin": "https://api.openai.com"}}}}
				}},
			},
			allowed: []admissionObject{
				{"the ModelConfig kagent-agents renders", "modelconfigs", "", modelConfig("kf-own", nil)},
				{"the RemoteMCPServer kagent-agents renders", "remotemcpservers", "", remoteMCPServer("kf-own", nil)},
			},
		},
	}
}

// workerImage names Substrate's gVisor worker in the dry runs' objects;
// no rule judges it, so it carries no digest.
const workerImage = "ghcr.io/kagent-dev/substrate/ateworker-gvisor:v1.0.0"

// podImage is the image a dry run's Pod runs: admission.images.admitted
// when the environment gives it, so that image-verification (B6, D36),
// which judges every Pod in a workload namespace and is never exempted
// from one, admits it, and each case still isolates the rule it tests;
// otherwise fallback, which no rule judged before B6. No conflict
// meanwhile: until infra/conformance attests a digest there is no
// admitted image, and image-verification only audits.
func podImage(e *Env, fallback string) string {
	if img := e.Cfg.Admission.Images.Admitted; img != "" {
		return img
	}
	return fallback
}

// pod is a plain non-root pod, which sandbox-privileges admits; mutate
// breaks one clause.
func pod(name string, mutate func(spec, container map[string]any)) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		ctr := map[string]any{"name": "app", "image": podImage(e, "registry.k8s.io/pause:3.10"), "securityContext": map[string]any{
			"runAsNonRoot": true, "runAsUser": 65532, "allowPrivilegeEscalation": false, "capabilities": map[string]any{"drop": []any{"ALL"}}}}
		spec := map[string]any{"containers": []any{ctr}}
		if mutate != nil {
			mutate(spec, ctr)
		}
		return map[string]any{"apiVersion": "v1", "kind": "Pod", "metadata": meta(e, name, nil), "spec": spec}
	}
}

// sandboxPlacement is the sandbox node's selector and toleration.
func sandboxPlacement(e *Env) map[string]any {
	k, v, _ := strings.Cut(e.Cfg.Kagent.SandboxNode, "=")
	return map[string]any{"nodeSelector": map[string]any{k: v},
		"tolerations": []any{map[string]any{"key": k, "operator": "Equal", "value": v, "effect": "NoSchedule"}}}
}

// workerPod is a Substrate worker's exact shape (Substrate v1.0.0's
// workerpool_apply.go, gVisor class), which only an agent namespace
// admits.
func workerPod(e *Env) map[string]any {
	spec := sandboxPlacement(e)
	spec["securityContext"] = map[string]any{"runAsUser": 0, "runAsGroup": 0}
	spec["containers"] = []any{map[string]any{"name": "worker", "image": podImage(e, workerImage), "securityContext": map[string]any{
		"runAsUser": 0, "runAsGroup": 0, "privileged": false, "allowPrivilegeEscalation": false,
		"capabilities":    map[string]any{"drop": []any{"ALL"}, "add": []any{"CHOWN", "DAC_OVERRIDE", "FOWNER", "NET_ADMIN", "NET_RAW", "SETFCAP", "SETGID", "SETUID", "SYS_ADMIN"}},
		"seccompProfile":  map[string]any{"type": "Unconfined"},
		"appArmorProfile": map[string]any{"type": "Unconfined"}},
		"volumeMounts": []any{map[string]any{"name": "ate-base", "mountPath": "/var/lib/ate", "mountPropagation": "HostToContainer"}}}}
	spec["volumes"] = []any{map[string]any{"name": "ate-base", "hostPath": map[string]any{"path": "/var/lib/ate", "type": "DirectoryOrCreate"}}}
	m := meta(e, "k6-worker", nil)
	m["labels"].(map[string]any)[e.Cfg.Kagent.WorkerLabel] = e.Cfg.Admission.Namespace
	return map[string]any{"apiVersion": "v1", "kind": "Pod", "metadata": m, "spec": spec}
}

// sandboxPodsCheck is K6's live twin: the fixture agent's workers, in its
// agent namespace, and atelet, in Substrate's, run with the sandbox node's
// selector, so the rule admits what it must, where it must.
func sandboxPodsCheck(c *C) {
	e := c.Env
	k, v, _ := strings.Cut(e.Cfg.Kagent.SandboxNode, "=")
	for _, set := range []struct{ what, ns, selector string }{
		{"the fixture agent's workers", e.Cfg.Kagent.Agent, e.Cfg.Kagent.WorkerLabel + "=" + e.Cfg.Kagent.Agent},
		{"atelet", e.Cfg.Kagent.Namespace, e.Cfg.Kagent.AteletSelector},
	} {
		var list struct {
			Items []struct {
				Metadata struct {
					Name string `json:"name"`
				} `json:"metadata"`
				Spec struct {
					NodeSelector map[string]string `json:"nodeSelector"`
				} `json:"spec"`
				Status struct {
					Phase string `json:"phase"`
				} `json:"status"`
			} `json:"items"`
		}
		if err := e.Kube.Get(c, "/api/v1/namespaces/"+set.ns+"/pods?labelSelector="+url.QueryEscape(set.selector), &list); err != nil {
			c.Errorf("allowed twin, %s: reading their pods: %v", set.what, err)
			continue
		}
		if len(list.Items) == 0 {
			c.Errorf("allowed twin, %s: no pod matches %s in %s", set.what, set.selector, set.ns)
		}
		for _, p := range list.Items {
			switch {
			case p.Spec.NodeSelector[k] != v:
				c.Errorf("allowed twin, %s: %s/%s runs without the sandbox node's selector %s", set.what, set.ns, p.Metadata.Name, e.Cfg.Kagent.SandboxNode)
			case p.Status.Phase != "Running":
				c.Errorf("allowed twin, %s: %s/%s is %s, not Running", set.what, set.ns, p.Metadata.Name, p.Status.Phase)
			default:
				c.Logf("%s: %s/%s runs on the sandbox node", set.what, set.ns, p.Metadata.Name)
			}
		}
	}
}

// listenerURL is Substrate's listener's base URL.
func listenerURL(e *Env) string {
	return fmt.Sprintf("https://workloads-gateway.%s:%d/", e.Cfg.PlatformDomain, e.Cfg.Kagent.ListenerPort)
}

func actorJWT(e *Env) map[string]any {
	return map[string]any{"audiences": []any{e.listenerAudience()}, "expirationSeconds": 300}
}

// modelConfig is the ModelConfig kagent-agents renders for an agent,
// which kagent-floor admits; mutate breaks one clause.
func modelConfig(name string, mutate func(spec map[string]any, e *Env)) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		spec := map[string]any{"provider": "OpenAI", "model": e.alias(), "stream": true, "actorJwt": actorJWT(e),
			"openAI": map[string]any{"apiFormat": "chatCompletions", "baseUrl": listenerURL(e) + "v1"}}
		if mutate != nil {
			mutate(spec, e)
		}
		return map[string]any{"apiVersion": "api.kagent.dev/v1alpha3", "kind": "ModelConfig", "metadata": meta(e, name, nil), "spec": spec}
	}
}

// remoteMCPServer is the RemoteMCPServer kagent-agents renders for a tool
// server, which kagent-floor admits; mutate breaks one clause.
func remoteMCPServer(name string, mutate func(spec map[string]any, e *Env)) func(e *Env) map[string]any {
	return func(e *Env) map[string]any {
		spec := map[string]any{"description": "capture-mcp, through Substrate's listener", "protocol": "STREAMABLE_HTTP",
			"url": listenerURL(e) + "mcp/capture-mcp", "actorJwt": actorJWT(e)}
		if mutate != nil {
			mutate(spec, e)
		}
		return map[string]any{"apiVersion": "api.kagent.dev/v1alpha3", "kind": "RemoteMCPServer", "metadata": meta(e, name, nil), "spec": spec}
	}
}
