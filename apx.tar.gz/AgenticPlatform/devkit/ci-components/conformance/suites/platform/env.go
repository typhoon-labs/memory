package platform

import (
	"context"
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"os/exec"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/fixtures/probe"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/fetch"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/mcp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/s3"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/signin"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// Roles the cases play, each a persona (plan/local-build.md, "How the
// suites run locally").
const (
	RoleDeveloper        = "developer"         // the allowed twins
	RoleIncidentManager  = "incident-manager"  // a role a route does not admit
	RolePlatformEngineer = "platform-engineer" // sees the platform-only tool
	RoleOtherTeam        = "other-team"        // developer-other-team: another team
	RoleLimited          = "limited"           // the spare in team conformance, with a low token limit
	RoleNoTeam           = "no-team"           // the spare in no team
)

// Needs, beyond the gateways' URLs, which every run has.
const (
	NeedSignIn        runner.Need = "sign-in"             // personas who can sign in
	NeedFakeModel     runner.Need = "fake-model-records"  // the fake model server's operations port
	NeedCaptureMCP    runner.Need = "capture-mcp-records" // capture-mcp's operations port
	NeedProbeMeshed   runner.Need = "probe-meshed"        // the probe in conformance-probe
	NeedProbeNomesh   runner.Need = "probe-nomesh"        // the probe in conformance-nomesh
	NeedAdmission     runner.Need = "admission"           // dry runs against the API server
	NeedHelm          runner.Need = "helm"                // a helm binary that may install into the team namespace
	NeedTestIssuer    runner.Need = "test-issuer"         // a signer the gateway trusts, whose key the suite holds
	NeedUsageRecords  runner.Need = "usage-records"       // the usage table, where the gateways' usage records land
	NeedAWS           runner.Need = "aws-iam"             // commands that call Bedrock as each principal
	NeedSlow          runner.Need = "slow"                // permission to wait for minutes
	NeedCollector     runner.Need = "collector"           // a general port of the collector
	NeedPlatformPort  runner.Need = "collector-platform"  // the collector's platform port
	NeedSinks         runner.Need = "telemetry-sinks"     // the Dynatrace and SIEM stand-ins' output
	NeedLangfuse      runner.Need = "langfuse"            // Langfuse's public API and a project's keys
	NeedAuditBucket   runner.Need = "audit-bucket"        // the audit bucket
	NeedLangfuseBlobs runner.Need = "langfuse-blobs"      // Langfuse's event bucket
	// NeedHostedDeployment is the hosted-workloads deployment called from
	// the runner itself: its port admits meshed callers alone (STRICT
	// mTLS), so only a runner in the cluster's mesh reaches it (T32).
	NeedHostedDeployment runner.Need = "hosted-deployment"
	needPersonaPrefix                = "persona:"         // a persona for a role
	needRoutePrefix                  = "route:"           // a route in the configuration
	needImagePrefix                  = "admission-image:" // one of admission.images
)

// NeedPersona is the need for a persona playing role.
func NeedPersona(role string) runner.Need { return runner.Need(needPersonaPrefix + role) }

// NeedRoute is the need for a configured route.
func NeedRoute(route string) runner.Need { return runner.Need(needRoutePrefix + route) }

// NeedAdmissionImage is the need for one of admission.images, by its JSON
// name.
func NeedAdmissionImage(name string) runner.Need { return runner.Need(needImagePrefix + name) }

// Source is where requests start.
type Source struct {
	outcome.Source
	mcp.Doer
}

// Tokens hands out persona tokens.
type Tokens interface {
	// Token is role's token narrowed to scope: exactly one audience.
	Token(ctx context.Context, role, scope string) (string, error)
	// Wide is the sign-in's own token, which carries every route scope
	// signed in with: several audiences.
	Wide(ctx context.Context, role string) (string, error)
	// Has reports whether role has a persona that can sign in.
	Has(role string) bool
}

// Logs reads log lines of one container of the pods a selector picks,
// since a time, each with its pod and the kubelet's timestamp.
type Logs interface {
	Lines(ctx context.Context, namespace, selector, container string, since time.Time) ([]kube.LogLine, error)
}

// Commands runs a command and returns its output and exit code.
type Commands func(ctx context.Context, argv []string, dir string) (out string, code int, err error)

// Env is what the suites run against.
type Env struct {
	Cfg    *Config
	RunID  string
	Runner Source
	Probes map[string]Source // meshed and nomesh
	Tokens Tokens
	Kube   *kube.Client
	Logs   Logs
	Run    Commands
	// Read reads the platform's stores whole: the usage table, Langfuse
	// and the buckets, and the fake model server's records. Unlike
	// Runner's requests, whose bodies are cut short for messages, a body
	// too large to read is an error.
	Read *fetch.Client
	S3   *s3.Client // the buckets, when s3.endpoint is set

	logsErr string // why Logs could not be built

	canaryMu  sync.Mutex
	canaryRun *canary // the telemetry cases' one emission
	// agent, if set, plays the telemetry group's turn (WithTelemetryAgent).
	agent *TelemetryAgent

	sinkMu   sync.Mutex
	sinkLogs map[string]*sinkLog // what the run has read of each stand-in's log

	TestKey   crypto.Signer // the trusted test issuer's key, when configured
	Untrusted *ecdsa.PrivateKey
	Now       func() time.Time
	// Settle, set by a stand-in only, returns once everything sent to it
	// so far has been delivered: decided, exported and in its stores. A
	// wait for delivery then judges at once instead of waiting out its
	// bound; on a cluster it is nil and the configured waits apply.
	Settle func(ctx context.Context) error

	seq atomic.Int64
}

// Options replace parts of the environment, for the suites' own tests.
type Options struct {
	Runner *Source
	Probes map[string]Source
	Tokens Tokens
	Kube   *kube.Client
	Logs   Logs
	Run    Commands
	Now    func() time.Time
	// Dial replaces how Read connects, for tests that map hostnames to
	// local servers.
	Dial func(ctx context.Context, network, addr string) (net.Conn, error)
	// S3Credentials replaces the environment's AWS credentials.
	S3Credentials func() (s3.Credentials, error)
	// Settle is a stand-in's delivery signal (Env.Settle).
	Settle func(ctx context.Context) error
}

// NewEnv builds the environment a configuration describes.
func NewEnv(cfg *Config, o Options) (*Env, error) {
	e := &Env{Cfg: cfg, Probes: map[string]Source{}, Tokens: o.Tokens, Kube: o.Kube, Logs: o.Logs, Run: o.Run, Now: o.Now, Settle: o.Settle}
	if e.Now == nil {
		e.Now = time.Now
	}
	if e.Run == nil {
		e.Run = runCommand
	}
	id := make([]byte, 4)
	rand.Read(id)
	e.RunID = fmt.Sprintf("%x", id)
	mesh := outcome.Source{MeshConnectTimeout: cfg.Timing.MeshConnectTimeout.Duration}
	if o.Runner != nil {
		e.Runner = *o.Runner
	} else {
		cl, err := outcome.NewClient(cfg.Path(cfg.CAFile))
		if err != nil {
			return nil, fmt.Errorf("ca_file: %v", err)
		}
		src := mesh
		src.Name, src.Meshed = "runner", cfg.RunnerMeshed
		e.Runner = Source{Source: src, Doer: cl}
	}
	if o.Probes != nil {
		e.Probes = o.Probes
	} else {
		for name, p := range cfg.Probes {
			cl, _ := outcome.NewClient("")
			src := mesh
			src.Name, src.Meshed = "probe-"+name, p.Meshed
			e.Probes[name] = Source{Source: src, Doer: &probe.Remote{URL: strings.TrimRight(p.URL, "/"), HTTP: cl}}
		}
	}
	if e.Tokens == nil && cfg.SignIn.PersonasFile != "" && cfg.SignIn.Okta != "" {
		t, err := newSignInTokens(cfg)
		if err != nil {
			return nil, err
		}
		e.Tokens = t
	}
	if e.Kube == nil && cfg.Admission.Enabled {
		k, err := kube.New(cfg.Admission.Server, cfg.Path(cfg.Admission.TokenFile), cfg.Path(cfg.Admission.CAFile))
		if err != nil {
			return nil, fmt.Errorf("admission: %v", err)
		}
		k.Impersonate = cfg.Admission.Impersonate
		e.Kube = k
	}
	roots, err := outcome.NewClient(cfg.Path(cfg.CAFile))
	if err != nil {
		return nil, fmt.Errorf("ca_file: %v", err)
	}
	e.Read = &fetch.Client{Roots: roots.Roots, Dial: o.Dial}
	if cfg.S3.Endpoint != "" {
		creds := o.S3Credentials
		if creds == nil {
			creds = s3.EnvCredentials
		}
		e.S3 = &s3.Client{Endpoint: cfg.S3.Endpoint, Region: cfg.S3.Region, PathStyle: cfg.S3.PathStyle, HTTP: e.Read, Creds: creds}
	}
	if e.Logs == nil && cfg.Telemetry.Sinks.Namespace != "" {
		k := o.Kube
		if k == nil {
			// Its own client: the logs are read as the runner, never as
			// whom admission.impersonate names.
			if k, err = kube.New(cfg.Admission.Server, cfg.Path(cfg.Admission.TokenFile), cfg.Path(cfg.Admission.CAFile)); err != nil {
				e.logsErr = err.Error()
			}
		}
		if k != nil {
			e.Logs = &kubeLogs{k: k}
		}
	}
	if cfg.TestIssuer.KeyFile != "" {
		raw, err := os.ReadFile(cfg.Path(cfg.TestIssuer.KeyFile))
		if err != nil {
			return nil, fmt.Errorf("test_issuer.key_file: %v", err)
		}
		if e.TestKey, err = jose.LoadPrivateKey(raw); err != nil {
			return nil, fmt.Errorf("test_issuer.key_file: %v", err)
		}
	}
	k, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return nil, err
	}
	e.Untrusted = k
	return e, nil
}

// Unmet implements runner.Env.
func (e *Env) Unmet(n runner.Need) string {
	c := e.Cfg
	if role, ok := strings.CutPrefix(string(n), needPersonaPrefix); ok {
		if e.Tokens == nil || !e.Tokens.Has(role) {
			return fmt.Sprintf("personas.%s must name a persona in the personas file who can sign in", role)
		}
		return ""
	}
	if name, ok := strings.CutPrefix(string(n), needImagePrefix); ok {
		if c.Admission.Images.ref(name) == "" {
			return fmt.Sprintf("set admission.images.%s: an image %s, from the environment's own releases", name, imageStates[name])
		}
		return ""
	}
	if route, ok := strings.CutPrefix(string(n), needRoutePrefix); ok {
		if _, ok := c.Routes[route]; !ok {
			return fmt.Sprintf("routes must describe %s", route)
		}
		return ""
	}
	switch n {
	case NeedSignIn:
		if e.Tokens == nil {
			return "set sign_in.okta and sign_in.personas_file (platform/conformance/personas)"
		}
	case NeedFakeModel:
		if c.FakeModel.Ops == "" {
			return "set fake_model.ops, the fake model server's operations port, which admits the runner alone"
		}
	case NeedCaptureMCP:
		if c.CaptureMCP.Ops == "" {
			return "set capture_mcp.ops, capture-mcp's operations port"
		}
	case NeedProbeMeshed, NeedProbeNomesh:
		name := map[runner.Need]string{NeedProbeMeshed: "meshed", NeedProbeNomesh: "nomesh"}[n]
		if _, ok := e.Probes[name]; !ok {
			return fmt.Sprintf("set probes.%s: the probe pod in conformance-%s", name, map[string]string{"meshed": "probe", "nomesh": "nomesh"}[name])
		}
	case NeedAdmission:
		if e.Kube == nil {
			return "set admission.enabled: the runner needs rights to dry-run the kinds the admission rules govern in its team namespace"
		}
	case NeedHelm:
		if len(c.Admission.Helm) == 0 || e.Kube == nil {
			return "set admission.helm to a helm command that may install into the team namespace; the runner's image has none, so run this case from a workstation"
		}
	case NeedTestIssuer:
		if e.TestKey == nil || c.TestIssuer.Issuer == "" || len(c.TestIssuer.Routes) == 0 {
			return "set test_issuer: a signer the gateway trusts on the routes it names, whose key the suite holds. Neither Keycloak nor the STS signs a token typed other than at+jwt or with nbf ahead, and the design names no test issuer yet"
		}
	case NeedUsageRecords:
		if c.UsageTable.URL == "" || c.UsageTable.PasswordFile == "" {
			return "set usage_table: the usage table's ClickHouse HTTP URL and the password file of a user that may select from it (platform/usage/clickhouse's reader_password)"
		}
	case NeedAWS:
		if len(c.AWS.Allowed) == 0 || len(c.AWS.Refused) == 0 {
			return "set aws.allowed and aws.refused: commands that call Bedrock as each principal (the floci-iam rehearsal locally, dev's roles in dev)"
		}
	case NeedCollector:
		if c.Telemetry.OTLP == "" {
			return "set telemetry.otlp: a general port of the collector for OTLP over HTTP"
		}
	case NeedPlatformPort:
		if c.Telemetry.PlatformPort == "" {
			return "set telemetry.platform_port: the collector's platform port, which only the platform's emitters may reach"
		}
	case NeedSinks:
		k := c.Telemetry.Sinks
		if k.Dynatrace == "" || k.SIEM == "" {
			return "set telemetry.sinks: the Dynatrace and SIEM stand-ins' containers, and their records store or their pods' namespace and selector"
		}
		if k.RecordsURL != "" {
			return ""
		}
		if k.Namespace == "" || k.Selector == "" {
			return "set telemetry.sinks: the stand-ins' records_url, or their pods' namespace and selector, whose log the runner may read"
		}
		if e.Logs == nil {
			return "the runner cannot read pods' logs: " + e.logsErr
		}
	case NeedLangfuse:
		l := c.Langfuse
		if l.URL == "" || l.PublicKeyFile == "" || l.SecretKeyFile == "" {
			return "set langfuse.url and the files of a project's public and secret keys (platform/langfuse/projects)"
		}
	case NeedAuditBucket:
		if e.S3 == nil || c.Audit.Bucket == "" {
			return "set s3.endpoint and audit.bucket, and give the runner AWS credentials that may read the bucket"
		}
	case NeedLangfuseBlobs:
		if e.S3 == nil || c.Langfuse.EventsBucket == "" {
			return "set s3.endpoint and langfuse.events_bucket, and give the runner AWS credentials that may read the bucket"
		}
	case NeedHostedDeployment:
		if !c.RunnerMeshed {
			return "runner_meshed is false: the hosted-workloads deployment admits meshed callers alone (STRICT mTLS), so this case runs from the runner's pod in the cluster, never from a workstation"
		}
	case NeedSlow:
		if !c.Slow {
			return "set slow: true; this case waits for minutes"
		}
	}
	return ""
}

// Marker returns a run-unique ID for one request, usable as a fake-model
// directive id and as capture-mcp's marker.
func (e *Env) Marker(what string) string {
	return fmt.Sprintf("conf-%s-%d-%s", e.RunID, e.seq.Add(1), what)
}

func runCommand(ctx context.Context, argv []string, dir string) (string, int, error) {
	if len(argv) == 0 {
		return "", -1, fmt.Errorf("no command")
	}
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	cmd.Dir = dir
	out, err := cmd.CombinedOutput()
	if ee, ok := err.(*exec.ExitError); ok {
		return string(out), ee.ExitCode(), nil
	}
	return string(out), 0, err
}

// signInTokens signs personas in through Okta and Keycloak and narrows
// their tokens by refreshing, keeping only the latest refresh token.
type signInTokens struct {
	cfg     *Config
	client  *signin.Client
	entries map[string]signin.Entry // by login
	mu      sync.Mutex
	state   map[string]*personaState
}

type personaState struct {
	refresh string
	wide    string
	byScope map[string]string
}

func newSignInTokens(cfg *Config) (*signInTokens, error) {
	raw, err := os.ReadFile(cfg.Path(cfg.SignIn.PersonasFile))
	if err != nil {
		return nil, fmt.Errorf("sign_in.personas_file: %v", err)
	}
	entries := map[string]signin.Entry{}
	if err := json.Unmarshal(raw, &entries); err != nil {
		return nil, fmt.Errorf("sign_in.personas_file: want a JSON object of login -> {password, totp}: %v", err)
	}
	cl, err := outcome.NewClient(cfg.Path(cfg.CAFile))
	if err != nil {
		return nil, err
	}
	return &signInTokens{cfg: cfg, entries: entries, state: map[string]*personaState{},
		client: &signin.Client{Okta: cfg.SignIn.Okta, Realm: cfg.Issuers.Keycloak, ClientID: cfg.SignIn.ClientID, Roots: cl.Roots}}, nil
}

func (t *signInTokens) login(role string) (string, signin.Entry, bool) {
	name := t.cfg.Personas[role]
	if name == "" {
		return "", signin.Entry{}, false
	}
	if strings.Contains(name, "@") {
		e, ok := t.entries[name]
		return name, e, ok && e.Password != "" && e.TOTP != ""
	}
	for login, e := range t.entries {
		if local, _, _ := strings.Cut(login, "@"); local == "agentic."+name {
			return login, e, e.Password != "" && e.TOTP != ""
		}
	}
	return "", signin.Entry{}, false
}

func (t *signInTokens) Has(role string) bool {
	_, _, ok := t.login(role)
	return ok
}

// scopes are every developer-deployment route's scope, asked for at sign-in
// since a refresh may only narrow (T20).
func (t *signInTokens) scopes() string {
	s := []string{"openid"}
	for _, r := range t.cfg.Routes {
		if r.Scope != "" {
			s = append(s, r.Scope)
		}
	}
	if t.cfg.Kagent.Scope != "" {
		s = append(s, t.cfg.Kagent.Scope)
	}
	s = append(s, t.cfg.SignIn.Scopes...)
	return strings.Join(uniq(s), " ")
}

func (t *signInTokens) signIn(ctx context.Context, role string) (*personaState, error) {
	login, entry, ok := t.login(role)
	if !ok {
		return nil, fmt.Errorf("no persona for %s in the personas file", role)
	}
	tok, err := t.client.SignIn(ctx, login, entry, t.scopes())
	if err != nil {
		return nil, fmt.Errorf("signing %s in: %w", login, err)
	}
	st := &personaState{refresh: tok.Refresh, wide: tok.Access, byScope: map[string]string{}}
	t.state[role] = st
	return st, nil
}

func fresh(token string, now time.Time) bool {
	exp, ok := claimInt(jose.Claims(token), "exp")
	return ok && now.Add(30*time.Second).Unix() < exp
}

func (t *signInTokens) Wide(ctx context.Context, role string) (string, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	st := t.state[role]
	if st == nil || !fresh(st.wide, time.Now()) {
		var err error
		if st, err = t.signIn(ctx, role); err != nil {
			return "", err
		}
	}
	return st.wide, nil
}

func (t *signInTokens) Token(ctx context.Context, role, scope string) (string, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	st := t.state[role]
	var err error
	if st == nil {
		if st, err = t.signIn(ctx, role); err != nil {
			return "", err
		}
	}
	if tok := st.byScope[scope]; fresh(tok, time.Now()) {
		return tok, nil
	}
	got, err := t.client.Refresh(ctx, st.refresh, "openid "+scope)
	if err != nil {
		// The session may have ended (idle, or reused refresh token): sign
		// in again once.
		if st, err = t.signIn(ctx, role); err != nil {
			return "", err
		}
		if got, err = t.client.Refresh(ctx, st.refresh, "openid "+scope); err != nil {
			return "", err
		}
	}
	if got.Refresh != "" {
		st.refresh = got.Refresh
	}
	st.byScope[scope] = got.Access
	return got.Access, nil
}

func uniq(xs []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, x := range xs {
		if !seen[x] {
			seen[x] = true
			out = append(out, x)
		}
	}
	return out
}

func claimInt(claims map[string]any, name string) (int64, bool) {
	switch v := claims[name].(type) {
	case json.Number:
		i, err := v.Int64()
		if err != nil {
			f, ferr := v.Float64()
			return int64(f), ferr == nil
		}
		return i, true
	case float64:
		return int64(v), true
	case int64:
		return v, true
	case int:
		return int64(v), true
	}
	return 0, false
}

type kubeLogs struct{ k *kube.Client }

func (l *kubeLogs) Lines(ctx context.Context, namespace, selector, container string, since time.Time) ([]kube.LogLine, error) {
	return l.k.Logs(ctx, namespace, selector, container, since)
}
