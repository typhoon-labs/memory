package platform

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"slices"
	"sort"
	"strconv"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/a2a"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/internal/outcome"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/ci-components/conformance/runner"
)

// The telemetry group (plan/local-build.md, "B3 in detail", The checks):
// the platform's telemetry carries no GenAI content where it must not, and
// no secret anywhere, run beside the three suites against a whole
// environment. It is not the workload Telemetry suite of
// design/conformance.md's L1, which B5 brings.
//
// No agent exists before B5, so the runner emits one turn of an agent
// itself, once per run: a synthetic trace on a general port of the
// collector, and a model request through the developer deployment under
// the same trace ID, both carrying a text that is a run-unique marker and
// two canary secrets, generated fresh in the shapes the platform's secret
// patterns name, so that the platform's real patterns must catch them. A
// second trace, without a GenAI span, goes with it. Each case then reads
// one destination, first for what must be there, which shows the
// destination received the telemetry, then for what must not.
const SuiteTelemetry = "telemetry"

// The layers whose refusal the telemetry group asserts: what keeps content
// or a trace from a destination that received the rest.
const (
	// LayerDynatraceBranch is the sampling tier's Dynatrace branch, which
	// deletes the GenAI content attributes and gen_ai.* span events and
	// masks the secret patterns in what is left.
	LayerDynatraceBranch = "collector-dynatrace"
	// LayerLangfuseBranch is the sampling tier's Langfuse branch, which
	// keeps only traces with a GenAI span and masks the secret patterns.
	LayerLangfuseBranch = "collector-langfuse"
	// LayerRecord is the gateway's record of a request, whose fields hold
	// no content, carried by the collector's platform port.
	LayerRecord = "gateway-record"
	// LayerRecordSource is the collector's stamp of the port a record came
	// in on, record.source, over any value its sender set: only the
	// platform port's records reach the usage table (threat TM15).
	LayerRecordSource = "collector-record-source"
)

func telemetryCases() []Case {
	canary := []runner.Need{NeedCollector, NeedSignIn, NeedPersona(RoleDeveloper), NeedRoute("gateway/v1")}
	with := func(more ...runner.Need) []runner.Need { return append(append([]runner.Need(nil), canary...), more...) }
	return []Case{
		{
			ID: "telemetry/canary/dynatrace", Suite: SuiteTelemetry, Layer: LayerDynatraceBranch, Cluster: true, Needs: with(NeedSinks),
			Row:   "The Dynatrace stand-in holds every span of the trace, the gateway's among them, and span metrics, and neither the marker nor either secret",
			Title: "the canary turn's spans reach the Dynatrace stand-in, the gateway's among them, with span metrics, but its content and secrets do not",
			Run:   dynatraceCase,
		},
		{
			ID: "telemetry/canary/records", Suite: SuiteTelemetry, Layer: LayerRecord, Cluster: true, Needs: with(NeedSinks, NeedAuditBucket, NeedUsageRecords),
			Row:   "The SIEM stand-in, the audit bucket and the usage table hold the gateway's record of the request, found by the trace ID, and neither the marker nor either secret",
			Title: "the gateway's record of the canary's model request reaches the SIEM stand-in, the audit bucket and the usage table by its trace ID, and the prompt's marker and secrets reach none of them",
			Run:   recordsCase,
		},
		{
			ID: "telemetry/canary/langfuse", Suite: SuiteTelemetry, Layer: LayerLangfuseBranch, Cluster: true, Needs: with(NeedLangfuse, NeedLangfuseBlobs),
			Row:   "Langfuse holds the marker in the tool span's output and the chat span's input, each secret replaced by the mask, and neither secret, in its API or its event blobs",
			Title: "Langfuse's API shows the marker in the tool span's output and the chat span's input with each secret masked, and neither its API nor its event blobs hold a secret",
			Run:   langfuseCase,
		},
		{
			ID: "telemetry/error/provider-echo", Suite: SuiteTelemetry, Layer: LayerDynatraceBranch, Cluster: true, Needs: with(NeedSinks, NeedLangfuse),
			Row:   "A model call's error that quotes the prompt reaches Dynatrace with its type and status code, and neither the marker nor either secret",
			Title: "a provider's error quoting the canary's prompt, recorded as a failed model call's status and exception event, reaches the Dynatrace stand-in with its error type and status code but none of the text; Langfuse holds the failed call with the text",
			Run:   providerEchoCase,
		},
		{
			ID: "telemetry/error/provider-echo-langfuse", Suite: SuiteTelemetry, Layer: LayerLangfuseBranch, Cluster: true, Needs: with(NeedLangfuse),
			Row:   "A model call's error that quotes a secret reaches Langfuse with the secret masked and the rest of its text kept",
			Title: "a provider's error quoting the canary's prompt, recorded as a failed model call's status, reaches Langfuse as the observation's statusMessage holding the marker with each secret masked, and no secret in Langfuse's answer",
			Run:   providerEchoLangfuseCase,
		},
		{
			ID: "telemetry/records/workload-port", Suite: SuiteTelemetry, Layer: LayerRecordSource, Cluster: true, Needs: with(NeedSinks, NeedUsageRecords),
			Row:   "A record a workload sends to a general port, forged as the gateway's, lands stamped workload and never in the usage table (TM15)",
			Title: "a gateway-shaped model request record sent to a general port, claiming record.source platform, reaches the SIEM stand-in stamped workload and no row of the usage table; the gateway's own record of the canary's request reaches both, stamped platform",
			Run:   workloadPortCase,
		},
		{
			ID: "telemetry/general-ports/networkpolicy", Suite: SuiteTelemetry, Layer: string(outcome.NetworkPolicy), Cluster: true,
			Needs: []runner.Need{NeedProbeNomesh, NeedProbeMeshed, NeedCollector},
			Row:   "A plaintext export to the collector's general ports, PERMISSIVE from build phase B4, from a governed namespace outside the mesh is refused by NetworkPolicy",
			Title: "a pod outside the mesh, in a namespace that is neither Substrate's nor an agent's, exporting plaintext to a general port is dropped by NetworkPolicy; the meshed probe's export is answered by the collector",
			Run:   generalPortsNetworkPolicyCase,
		},
		{
			ID: "telemetry/platform-port/networkpolicy", Suite: SuiteTelemetry, Layer: string(outcome.NetworkPolicy), Cluster: true,
			Needs: []runner.Need{NeedProbeNomesh, NeedProbeMeshed, NeedPlatformPort},
			Row:   "Calls to the collector's platform port from the suites' probe pods are refused by NetworkPolicy (TM15)",
			Title: "a pod outside the mesh calling the collector's platform port is dropped by NetworkPolicy; the platform port answers the meshed probe, which NetworkPolicy lets through",
			Run:   platformPortNetworkPolicyCase,
		},
		{
			ID: "telemetry/platform-port/authorization-policy", Suite: SuiteTelemetry, Layer: string(outcome.AuthorizationPolicy), Cluster: true,
			Needs: []runner.Need{NeedProbeMeshed, NeedCollector, NeedPlatformPort},
			Row:   "where a probe is let through it, by the collector's sidecar (TM15)",
			Title: "a meshed pod with no grants, which NetworkPolicy lets through to the collector's platform port, is denied by the collector's sidecar; the same pod's export to a general port gets the collector's answer",
			Run:   platformPortAuthorizationCase,
		},
		{
			ID: "telemetry/sampling/no-genai", Suite: SuiteTelemetry, Layer: LayerLangfuseBranch, Cluster: true, Needs: with(NeedSinks, NeedLangfuse),
			Row:   "A trace without a GenAI span reaches the Dynatrace stand-in but not Langfuse",
			Title: "a trace without a GenAI span reaches the Dynatrace stand-in and not Langfuse, which the canary's GenAI trace, sent with it, reaches",
			Run:   noGenAICase,
		},
	}
}

// TelemetryAgentCases are the telemetry group's cases that read the
// canary's turn, which a TelemetryAgent may play (WithTelemetryAgent):
// the integration stage runs them with each agent that can.
func TelemetryAgentCases() []Case {
	var out []Case
	for _, k := range telemetryCases() {
		if strings.HasPrefix(k.ID, "telemetry/canary/") || strings.HasPrefix(k.ID, "telemetry/sampling/") || strings.HasPrefix(k.ID, "telemetry/records/") {
			out = append(out, k)
		}
	}
	return out
}

// echoCall is a failed model call whose provider's error quotes the
// prompt, recorded as an SDK records it.
type echoCall struct {
	k                *canary
	trace, chat, typ string
	sent             time.Time
}

// providerEcho: a provider's error may quote its input, and an SDK records
// the error's message as a failed model call's span status and exception
// event, fields the GenAI content rules do not name. The runner sends a
// prompt holding a fresh canary through the developer deployment's model
// route with a directive that makes the fake model answer 400 quoting it,
// and exports the failed call's spans as an SDK would: the error's message
// in the status and in the exception event's message and stack trace, its
// type in error.type and exception.type, its status in
// http.response.status_code.
func providerEcho(c *C) *echoCall {
	e := c.Env
	cfg := e.Cfg
	k := &canary{start: time.Now().Add(-2 * time.Second).Truncate(time.Second), marker: e.Marker("echo")}
	k.secretText(cfg.Telemetry.Mask)
	tok := token(c, RoleDeveloper, "gateway/v1")
	trace, root, chat := randomHex(16), randomHex(8), randomHex(8)
	alias := e.alias()
	body, _ := json.Marshal(map[string]any{"model": alias, "max_tokens": 64,
		"messages": []map[string]any{{"role": "user", "content": k.text + " [[fake-model status=400 echo]]"}}})
	t0 := time.Now()
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: cfg.CallURL("gateway/v1") + "/messages", Body: string(body), Header: map[string]string{
		"Authorization": "Bearer " + tok, "Content-Type": "application/json", "anthropic-version": cfg.Models.AnthropicVersion,
		"traceparent": "00-" + trace + "-" + chat + "-01"}})
	var apiErr struct {
		Error struct {
			Type    string `json:"type"`
			Message string `json:"message"`
		} `json:"error"`
	}
	if o.Kind != outcome.Response || o.Status != http.StatusBadRequest || json.Unmarshal([]byte(o.Body), &apiErr) != nil ||
		apiErr.Error.Type == "" || !strings.Contains(apiErr.Error.Message, k.marker) {
		c.Fatalf("the model route did not pass the fake model's 400 through, with its error's type and the message quoting the prompt (the fake model's echo key, from 3dc2b8f): %s", k.scrub(o.String()))
	}
	t1 := time.Now()
	msg, typ := apiErr.Error.Message, apiErr.Error.Type
	ms := time.Millisecond
	spans := []otlp.Span{
		{TraceID: trace, SpanID: root, Name: "invoke_agent conformance-echo-" + e.RunID, Kind: otlp.KindInternal, Start: t0.Add(-10 * ms), End: t1.Add(10 * ms),
			Attributes: otlp.KVs("gen_ai.operation.name", "invoke_agent"), Error: "the model call failed"},
		{TraceID: trace, SpanID: chat, ParentSpanID: root, Name: "chat " + alias, Kind: otlp.KindClient, Start: t0, End: t1,
			Attributes: otlp.KVs("gen_ai.operation.name", "chat", "gen_ai.request.model", alias, "error.type", typ, "http.response.status_code", "400"),
			Events: []otlp.Event{{Name: "exception", Time: t1, Attributes: otlp.KVs("exception.type", typ, "exception.message", msg,
				"exception.stacktrace", "Traceback (most recent call last):\n  File \"agent.py\", line 1, in call\nAPIStatusError: "+msg)}},
			Error: msg},
	}
	if err := e.exportTraces(c, spans); err != nil {
		c.Fatalf("%v", err)
	}
	c.Logf("the failed call: trace %s, chat span %s, marker %s", trace, chat, k.marker)
	return &echoCall{k: k, trace: trace, chat: chat, typ: typ, sent: time.Now()}
}

// providerEchoCase: the Dynatrace stand-in must hold the failed call's
// span with error.type and http.response.status_code, and nothing it
// received since may hold the marker or either secret; the exception event
// may stay without its message and stack trace, or go. Langfuse, the twin,
// holds the failed call with the text.
func providerEchoCase(c *C) {
	e := c.Env
	cfg := e.Cfg
	x := providerEcho(c)
	k, trace, chat, typ, sent := x.k, x.trace, x.chat, x.typ, x.sent
	w := cfg.Telemetry.Waits
	wait := w.Decision.Duration + w.Delivery.Duration
	var lines []string
	var span *otlp.ReadSpan
	var err error
	poll(c, time.Until(sent.Add(wait)), func() bool {
		if lines, err = e.sinkLines(c, cfg.Telemetry.Sinks.Dynatrace, k.start); err != nil {
			return false
		}
		for _, l := range lines {
			if x, ok := otlp.Parse([]byte(l)); ok {
				for _, s := range x.Spans(trace) {
					if s.SpanID == chat {
						s := s
						span = &s
					}
				}
			}
		}
		return span != nil
	})
	if err != nil {
		c.Fatalf("reading the Dynatrace stand-in: %v", err)
	}
	if span == nil {
		c.Fatalf("the failed model call's span never reached the Dynatrace stand-in within %s: the Dynatrace branch keeps every span of an error trace%s", wait, noteGaps(c, cfg.Telemetry.Sinks.Dynatrace, k.start))
	}
	for _, kv := range [][2]string{{"error.type", typ}, {"http.response.status_code", "400"}} {
		if got := otlp.Attr(span.Attributes, kv[0]); got != kv[1] {
			c.Errorf("the failed call's span at the Dynatrace stand-in has %s %q, want %q: the scrub keeps an error's type and status code", kv[0], got, kv[1])
		}
	}
	judgeAbsent(c, k, "the Dynatrace stand-in", lines, true,
		"an error's message, stack trace and status description, which may quote a prompt, must not reach Dynatrace")
	// The twin: Langfuse keeps the failed call with the error's text, so
	// the export carried it and the Dynatrace branch removed it.
	lw := w.Decision.Duration + w.Delivery.Duration + w.Langfuse.Duration
	var obs map[string]map[string]any
	poll(c, time.Until(sent.Add(lw)), func() bool {
		if _, obs, err = e.langfuseObservations(c, trace); err != nil {
			return false
		}
		return strings.Contains(text(obs[chat]), k.marker)
	})
	switch {
	case err != nil:
		c.Errorf("%v", err)
	case !strings.Contains(text(obs[chat]), k.marker):
		c.Errorf("allowed twin: Langfuse holds no observation of the failed call with the error's text within %s, so its absence from Dynatrace proves no scrub", lw)
	}
	if !c.Failed() {
		c.Logf("refused by %s, as due: the error's type and status code at Dynatrace without its text; Langfuse holds the failed call with the text", LayerDynatraceBranch)
	}
}

// providerEchoLangfuseCase: Langfuse keeps the failed call's error with its
// text, as it keeps content, and the Langfuse branch masks the secret
// patterns in it: the redaction processor reads attributes only, and the
// error's message is also the span status's description, which Langfuse
// shows as the observation's statusMessage. Langfuse's observation of the
// call must hold the marker with each secret replaced by the mask, and its
// API's answer for the trace no secret, whole or in part.
func providerEchoLangfuseCase(c *C) {
	e := c.Env
	w := e.Cfg.Telemetry.Waits
	x := providerEcho(c)
	k := x.k
	wait := w.Decision.Duration + w.Delivery.Duration + w.Langfuse.Duration
	var obs map[string]map[string]any
	var body []byte
	var err error
	poll(c, time.Until(x.sent.Add(wait)), func() bool {
		if body, obs, err = e.langfuseObservations(c, x.trace); err != nil {
			return false
		}
		return strings.Contains(text(obs[x.chat]["statusMessage"]), k.marker)
	})
	got := text(obs[x.chat]["statusMessage"])
	switch {
	case err != nil:
		c.Fatalf("%v", err)
	case obs[x.chat] == nil:
		c.Fatalf("Langfuse holds no observation of the failed call (span %s) after %s: the Langfuse branch keeps every trace with a GenAI span, whole", x.chat, wait)
	case !strings.Contains(got, k.marker):
		c.Errorf("allowed twin: the failed call's statusMessage in Langfuse lacks the marker: the Langfuse branch keeps an error's text, masking only secrets (%s)", k.scrub(got))
	case !strings.Contains(got, k.masked):
		c.Errorf("the failed call's statusMessage in Langfuse holds the marker, but not with each secret replaced by the mask %q: %s", e.Cfg.Telemetry.Mask, k.scrub(got))
	}
	judgeAbsent(c, k, "Langfuse's API", []string{string(body)}, false,
		"the Langfuse branch must mask the secret patterns in a span status's description too, which the redaction processor does not read")
	if !c.Failed() {
		c.Logf("refused by %s, as due: the error's text in Langfuse with each secret masked", LayerLangfuseBranch)
	}
}

// workloadPortCase: a workload, here the runner, sends the general port a
// log record shaped as the gateway's record of a model request, which
// would be a usage record, claiming record.source platform. The collector
// stamps every record with the port it came in on, over the sender's
// value, so it reaches the SIEM stand-in stamped workload, and the usage
// table, which takes only the platform port's records, never; the twin
// is the gateway's own record of the canary's request, stamped platform,
// in both.
func workloadPortCase(c *C) {
	e := c.Env
	k := e.canary(c)
	cfg := e.Cfg
	forged := randomHex(16)
	now := time.Now()
	export := otlp.Logs(otlp.KVs("service.name", "agentgateway"), "conformance", []otlp.Record{{TraceID: forged, SpanID: randomHex(8), Time: now,
		Body: "gateway.request", Attributes: otlp.KVs("event.name", "gateway.request", "record.source", "platform", "gen_ai.operation.name", "chat",
			"gen_ai.request.model", e.alias(), "user.id", "conformance-forged-"+e.RunID, "user.team", "conformance-forged", "token.jti", randomHex(16),
			"gen_ai.usage.input_tokens", "1000000", "gen_ai.usage.output_tokens", "1000000")}})
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: cfg.Telemetry.OTLP + "/v1/logs", Body: string(export),
		Header: map[string]string{"Content-Type": "application/json"}})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		c.Fatalf("sending the forged record to %s: %s", cfg.Telemetry.OTLP, o)
	}
	sent := time.Now()
	// The stamp of the trace's records: "platform" if any carries it, as
	// the gateway's own must, beside a workload's audit records in the
	// same trace (an agent's tools'); else the first's.
	stamp := func(lines []string, trace string) (string, bool) {
		got, found := "", false
		for _, l := range lines {
			if x, ok := otlp.Parse([]byte(l)); ok {
				for _, r := range x.Logs(trace) {
					src := otlp.Attr(r.Attributes, "record.source")
					if src == "platform" {
						return src, true
					}
					if !found {
						got, found = src, true
					}
				}
			}
		}
		return got, found
	}
	var lines []string
	var err error
	var forgedStamp, ownStamp string
	var forgedIn, ownIn bool
	wait := cfg.Telemetry.Waits.Delivery.Duration
	poll(c, time.Until(sent.Add(wait)), func() bool {
		if lines, err = e.sinkLines(c, cfg.Telemetry.Sinks.SIEM, k.start); err != nil {
			return false
		}
		forgedStamp, forgedIn = stamp(lines, forged)
		ownStamp, ownIn = stamp(lines, k.trace)
		return forgedIn && ownIn
	})
	if err != nil {
		c.Fatalf("reading the SIEM stand-in: %v", err)
	}
	switch {
	case !forgedIn:
		c.Errorf("the forged record never reached the SIEM stand-in within %s: the general port takes workloads' log records to the SIEM, stamped workload", wait)
	case forgedStamp != "workload":
		c.Errorf("the forged record reached the SIEM stand-in with record.source %q: the collector must stamp a general port's records workload, over any value the sender set (TM15)", forgedStamp)
	default:
		c.Logf("the forged record reached the SIEM stand-in stamped workload")
	}
	switch {
	case !ownIn:
		c.Errorf("allowed twin: the gateway's own record of trace %s never reached the SIEM stand-in within %s", k.trace, wait)
	case ownStamp != "platform":
		c.Errorf("allowed twin: the gateway's own record reached the SIEM stand-in with record.source %q, not platform", ownStamp)
	}
	// The forged record is past the collector, having reached the SIEM.
	// The usage table must not take it: once it holds the gateway's own
	// record, it is watched for one more decision wait, as sampling's
	// absence is (the usage pipeline flushes in a fraction of that).
	past := time.Now()
	extra := cfg.Telemetry.Waits.Decision.Duration
	var forgedRows, ownRows []map[string]any
	var uErr error
	poll(c, cfg.UsageTable.Wait.Duration+extra, func() bool {
		if forgedRows, uErr = e.usageRows(c, forged); uErr != nil || len(forgedRows) > 0 {
			return true
		}
		if len(ownRows) == 0 {
			ownRows, uErr = e.usageRows(c, k.trace)
		}
		return len(ownRows) > 0 && time.Since(past) >= extra
	})
	switch {
	case uErr != nil:
		c.Errorf("%v", uErr)
	case len(forgedRows) > 0:
		c.Errorf("the forged record reached the usage table (%d rows for trace %s): only the platform port's records may, so a workload cannot bill or attribute usage (TM15)", len(forgedRows), forged)
	case len(ownRows) == 0:
		c.Errorf("allowed twin: no row of the usage table has the canary's trace %s within %s, so the forged record's absence proves nothing", k.trace, cfg.UsageTable.Wait.Duration+extra)
	default:
		c.Logf("refused by %s, as due: the forged record stamped workload and in no usage row, the gateway's own stamped platform and in %d", LayerRecordSource, len(ownRows))
	}
}

// platformExport is what a probe sends the platform port: a plain HTTP
// request, not gRPC, so that each layer's refusal shows as it does on any
// port (a gRPC-framed one would come back as a 200 carrying a
// grpc-status), and that a collector reached answers it with an error of
// its own.
func (e *Env) platformExport(c *C, src Source) outcome.Outcome {
	return e.Do(c, src, outcome.Request{Method: http.MethodPost, URL: e.Cfg.Telemetry.PlatformPort + "/opentelemetry.proto.collector.logs.v1.LogsService/Export",
		Header: map[string]string{"Content-Type": "application/json"}, Body: `{"resourceLogs":[]}`,
		Timeout: outcome.Of(e.Cfg.Timing.MeshConnectTimeout.Duration + e.Cfg.Timing.Request.Duration)})
}

// generalExport is an empty export of traces to a general port, which any
// meshed workload may send.
func (e *Env) generalExport(c *C, src Source) outcome.Outcome {
	return e.Do(c, src, outcome.Request{Method: http.MethodPost, URL: e.Cfg.Telemetry.OTLP + "/v1/traces",
		Header: map[string]string{"Content-Type": "application/json"}, Body: `{"resourceSpans":[]}`})
}

// generalPortsNetworkPolicyCase: from build phase B4 the collector's
// general ports are PERMISSIVE, so that kagent's and Substrate's pods,
// outside the mesh (control K7), can send plaintext; mutual TLS no longer
// stops any other pod outside the mesh, and NetworkPolicy, which admits
// plaintext only from Substrate's namespace and the agent namespaces,
// besides the meshed governed namespaces, is what refuses it. The probe
// outside the mesh is in a governed namespace that is neither, so its
// plaintext export is dropped; the meshed probe's export, through its
// sidecar, gets the collector's answer.
func generalPortsNetworkPolicyCase(c *C) {
	e := c.Env
	src := e.Probes["nomesh"]
	expectLayer(c, "conformance-nomesh's plaintext export to a general port", e.generalExport(c, src), src, outcome.NetworkPolicy)
	twin := e.Probes["meshed"]
	o := e.generalExport(c, twin)
	expectThrough(c, "conformance-probe's export to a general port", o, outcome.Reached(o, twin.Source) && o.Status/100 == 2)
}

// platformPortNetworkPolicyCase: only the platform's emitters may send the
// platform's records (design/observability.md, "Audit and usage records";
// threat TM15). The probe outside the mesh is let through to no port of
// the collector, so NetworkPolicy alone stops its call to the platform
// port, which stays STRICT; the twin shows the port there for a source
// NetworkPolicy admits: the meshed probe's call opens and gets an answer,
// its sidecar's refusal or the collector's own, never a drop.
func platformPortNetworkPolicyCase(c *C) {
	e := c.Env
	src := e.Probes["nomesh"]
	expectLayer(c, "conformance-nomesh to the collector's platform port", e.platformExport(c, src), src, outcome.NetworkPolicy)
	twin := e.Probes["meshed"]
	if o := e.platformExport(c, twin); o.Kind != outcome.Response || outcome.Refuser(o, twin.Source) == outcome.NetworkPolicy {
		c.Errorf("allowed twin: want the collector's platform port to answer conformance-probe, which NetworkPolicy lets through to it, got %s: %s", outcome.Refuser(o, twin.Source), o)
	}
}

// platformPortAuthorizationCase: the meshed probe is let through
// NetworkPolicy to the collector's platform port, for this case, so the
// collector's sidecar, whose AuthorizationPolicy admits the gateways, the
// STS and the reconciliation job alone on that port, is what refuses it;
// the same probe's export to a general port, which admits any principal,
// gets the collector's own answer.
func platformPortAuthorizationCase(c *C) {
	e := c.Env
	src := e.Probes["meshed"]
	expectLayer(c, "conformance-probe to the collector's platform port", e.platformExport(c, src), src, outcome.AuthorizationPolicy)
	o := e.generalExport(c, src)
	expectThrough(c, "conformance-probe to a general port", o, outcome.Reached(o, src.Source) && o.Status/100 == 2)
}

// canary is the run's one emission, which every case of the group reads.
type canary struct {
	start time.Time // before anything was sent, to whole seconds: where reading starts
	sent  time.Time // when the traces were sent: where waiting starts

	marker  string   // run-unique, in the text
	text    string   // the marker and the secrets, as the tool returned them
	masked  string   // the text with each secret replaced by the mask
	secrets []string // a GitLab token and a JWT, whole
	cores   []string // their random parts, which a partial mask would leave

	trace, root, tool, chat string // the agent's turn: its trace and, when the runner played it, its spans
	agent                   string // the agent's name, in the root span's name
	plain, plainRoot        string // the trace without a GenAI span
	// service is the turn's spans' service.name: the runner's, or the
	// agent's that played it (B5); by names who played it, for messages.
	service, by string
	// toolHolds is what the tool span's output must hold: the text, when
	// the runner played the turn; the marker, which the agent's tool
	// echoes, when an agent did.
	toolHolds string
}

func (k *canary) rootName() string { return "invoke_agent " + k.agent }

// secretText makes the canary's text: its marker and two secrets, a
// GitLab token and a JWT, generated for it in the shapes the platform's
// secret patterns name, and the text with each secret masked.
func (k *canary) secretText(mask string) {
	gitlab := "glpat-" + randomAlnum(20)
	header := b64url(`{"alg":"ES256","typ":"JWT","kid":"canary-` + randomHex(4) + `"}`)
	payload := b64url(`{"sub":"canary-` + randomHex(8) + `","jti":"` + randomHex(16) + `"}`)
	sig := base64.RawURLEncoding.EncodeToString([]byte(randomHex(32)))
	jwt := header + "." + payload + "." + sig
	k.secrets = []string{gitlab, jwt}
	k.cores = []string{strings.TrimPrefix(gitlab, "glpat-"), payload, sig}
	// Spaces around each secret: the patterns are bounded by \b, and the
	// GitLab token's runs on over dots and dashes.
	k.text = k.marker + " returned " + gitlab + " and " + jwt + " done"
	k.masked = strings.NewReplacer(gitlab, mask, jwt, mask).Replace(k.text)
}

// modelOps are the GenAI operations of a model call: the conventions'
// chat and text_completion, and generate_content, Google ADK's.
var modelOps = []string{"chat", "generate_content", "text_completion"}

// turn sorts the trace's spans of the agent's turn, those of the service
// that played it, by their gen_ai.operation.name: its root, a tool call
// and a model call, the first of each by span ID. Spans of any other
// service are the gateway's.
func (k *canary) turn(spans map[string]otlp.ReadSpan) (root, tool, model *otlp.ReadSpan) {
	ids := make([]string, 0, len(spans))
	for id := range spans {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	for _, id := range ids {
		s := spans[id]
		if s.Service != k.service {
			continue
		}
		switch op := otlp.Attr(s.Attributes, "gen_ai.operation.name"); {
		case op == "invoke_agent" && root == nil:
			root = &s
		case op == "execute_tool" && tool == nil:
			tool = &s
		case contains(modelOps, op) && model == nil:
			model = &s
		}
	}
	return root, tool, model
}

// leaks names what of the canary text holds: the marker, if it counts, and
// any secret, whole or in part.
func (k *canary) leaks(text string, marker bool) []string {
	var out []string
	if marker && strings.Contains(text, k.marker) {
		out = append(out, "the marker")
	}
	for _, s := range k.secrets {
		if strings.Contains(text, s) {
			return append(out, "a canary secret")
		}
	}
	for _, s := range k.cores {
		if strings.Contains(text, s) {
			return append(out, "a canary secret's random part, around a partial mask")
		}
	}
	return out
}

// scrub replaces the secrets in a text, for messages.
func (k *canary) scrub(text string) string {
	for _, s := range append(append([]string(nil), k.secrets...), k.cores...) {
		text = strings.ReplaceAll(text, s, "<canary secret>")
	}
	if len(text) > 300 {
		text = text[:300] + "…"
	}
	return text
}

// canary returns the run's emission, sending it first if no case has.
func (e *Env) canary(c *C) *canary {
	e.canaryMu.Lock()
	defer e.canaryMu.Unlock()
	if e.canaryRun == nil {
		k, err := e.emitCanary(c)
		if err != nil {
			c.Fatalf("sending the canary: %v", err)
		}
		e.canaryRun = k
	}
	k := e.canaryRun
	c.Logf("the canary: trace %s (no GenAI span: %s), marker %s, sent %s", k.trace, k.plain, k.marker, k.sent.UTC().Format(time.RFC3339))
	return k
}

func (e *Env) emitCanary(c *C) (*canary, error) {
	cfg := e.Cfg
	route := "gateway/v1"
	tok, err := e.Tokens.Token(c, RoleDeveloper, cfg.Routes[route].Scope)
	if err != nil {
		return nil, fmt.Errorf("the developer's token: %v", err)
	}
	k := &canary{start: time.Now().Add(-2 * time.Second).Truncate(time.Second), marker: e.Marker("canary"), agent: "conformance-canary-" + e.RunID,
		service: cfg.Telemetry.ServiceName, by: "the runner's"}
	k.secretText(cfg.Telemetry.Mask)
	k.toolHolds = k.masked
	k.plain, k.plainRoot = randomHex(16), randomHex(8)
	if e.agent != nil {
		return k, e.agentTurn(c, k)
	}
	k.trace, k.root, k.tool, k.chat = randomHex(16), randomHex(8), randomHex(8), randomHex(8)
	alias := e.alias()

	// The model request, under the chat span, with the text in its prompt.
	t0 := time.Now()
	body, _ := json.Marshal(map[string]any{"model": alias, "max_tokens": 64,
		"messages": []map[string]any{{"role": "user", "content": "The conformance canary tool returned: " + k.text}}})
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: cfg.CallURL(route) + "/messages", Body: string(body), Header: map[string]string{
		"Authorization": "Bearer " + tok, "Content-Type": "application/json", "anthropic-version": cfg.Models.AnthropicVersion,
		"traceparent": "00-" + k.trace + "-" + k.chat + "-01"}})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		return nil, fmt.Errorf("the model request through the developer deployment: %s", o)
	}
	t1 := time.Now()

	msgs, _ := json.Marshal([]any{
		map[string]any{"role": "user", "parts": []any{map[string]any{"type": "text", "content": "Run the conformance canary tool."}}},
		map[string]any{"role": "assistant", "parts": []any{map[string]any{"type": "tool_call", "id": "call_canary", "name": "conformance_canary", "arguments": map[string]any{"query": "canary"}}}},
		map[string]any{"role": "tool", "parts": []any{map[string]any{"type": "tool_call_response", "id": "call_canary", "response": k.text}}},
	})
	ms := time.Millisecond
	spans := []otlp.Span{
		// The root: an error, so that the Dynatrace branch keeps the trace
		// every time, whatever its share of the rest.
		{TraceID: k.trace, SpanID: k.root, Name: k.rootName(), Kind: otlp.KindInternal, Start: t0.Add(-20 * ms), End: t1.Add(20 * ms),
			Attributes: otlp.KVs("gen_ai.operation.name", "invoke_agent", "gen_ai.agent.name", k.agent),
			Error:      "the conformance canary's turn ends in an error, which the Dynatrace branch keeps"},
		// The tool call, whose result is the text.
		{TraceID: k.trace, SpanID: k.tool, ParentSpanID: k.root, Name: "execute_tool conformance_canary", Kind: otlp.KindInternal, Start: t0.Add(-15 * ms), End: t0.Add(-10 * ms),
			Attributes: otlp.KVs("gen_ai.operation.name", "execute_tool", "gen_ai.tool.name", "conformance_canary", "gen_ai.tool.call.id", "call_canary",
				"gen_ai.tool.call.arguments", `{"query":"canary"}`, "gen_ai.tool.call.result", k.text)},
		// The model call, whose input holds the tool's result, as an
		// attribute and as the GenAI conventions' span event; the model
		// request above is its child.
		{TraceID: k.trace, SpanID: k.chat, ParentSpanID: k.root, Name: "chat " + alias, Kind: otlp.KindClient, Start: t0.Add(-5 * ms), End: t1.Add(10 * ms),
			Attributes: otlp.KVs("gen_ai.operation.name", "chat", "gen_ai.request.model", alias, "gen_ai.input.messages", string(msgs)),
			Events: []otlp.Event{{Name: "gen_ai.client.inference.operation.details", Time: t0.Add(-4 * ms),
				Attributes: otlp.KVs("gen_ai.input.messages", string(msgs))}}},
	}
	if err := e.exportTraces(c, append(spans, plainTrace(k, t0)...)); err != nil {
		return nil, err
	}
	k.sent = time.Now()
	return k, nil
}

// plainTrace is a trace without a GenAI span, an error too, so that the
// Dynatrace branch keeps it.
func plainTrace(k *canary, t0 time.Time) []otlp.Span {
	ms := time.Millisecond
	return []otlp.Span{
		{TraceID: k.plain, SpanID: k.plainRoot, Name: "GET /conformance/plain", Kind: otlp.KindServer, Start: t0, End: t0.Add(5 * ms),
			Attributes: otlp.KVs("http.request.method", "GET", "url.path", "/conformance/plain"),
			Error:      "the conformance plain trace ends in an error, which the Dynatrace branch keeps"},
		{TraceID: k.plain, SpanID: randomHex(8), ParentSpanID: k.plainRoot, Name: "lookup", Kind: otlp.KindInternal, Start: t0.Add(ms), End: t0.Add(4 * ms)},
	}
}

// exportTraces sends spans to a general port as the runner's.
func (e *Env) exportTraces(c *C, spans []otlp.Span) error {
	export := otlp.Traces(otlp.KVs("service.name", e.Cfg.Telemetry.ServiceName, "conformance.run.id", e.RunID), "conformance", spans)
	o := e.Do(c, e.Runner, outcome.Request{Method: http.MethodPost, URL: e.Cfg.Telemetry.OTLP + "/v1/traces", Body: string(export),
		Header: map[string]string{"Content-Type": "application/json"}})
	if o.Kind != outcome.Response || o.Status != http.StatusOK {
		return fmt.Errorf("sending the traces to %s: %s", e.Cfg.Telemetry.OTLP, o)
	}
	return nil
}

// TelemetryAgent is a deployed agent that plays the telemetry group's turn
// itself (B5, the plan's check 7), instead of the runner: asked over A2A
// through the developer deployment, with the canary's text and a
// directive to the fake model server, its model calls Tool with Arg set to
// the marker, which the tool's result echoes, until its model-call cap
// stops the task. Its spans, its model requests' gateway spans and
// records, and its tool call carry the run's trace, from the traceparent
// the runner sends. The trace without a GenAI span is still the runner's.
type TelemetryAgent struct {
	Name    string // its name
	Route   string // its route on the developer deployment, gateway/a2a/<name>
	Scope   string // that route's client scope
	Service string // its spans' service.name; default Name
	Tool    string // a tool it may call whose result names an argument's value, such as reference-mcp's get_note
	Arg     string // that argument, such as note_id
	// Wait bounds its turn, the A2A call; default 3 minutes.
	Wait time.Duration
}

// WithTelemetryAgent is a copy of e, sharing its clients and personas,
// whose telemetry group's turn agent plays: a canary of its own, read
// afresh.
func (e *Env) WithTelemetryAgent(agent TelemetryAgent) *Env {
	if agent.Service == "" {
		agent.Service = agent.Name
	}
	if agent.Wait == 0 {
		agent.Wait = 3 * time.Minute
	}
	return &Env{Cfg: e.Cfg, RunID: e.RunID + "-" + agent.Name, Runner: e.Runner, Probes: e.Probes, Tokens: e.Tokens, Kube: e.Kube,
		Logs: e.Logs, Run: e.Run, Read: e.Read, S3: e.S3, logsErr: e.logsErr, TestKey: e.TestKey, Untrusted: e.Untrusted, Now: e.Now, Settle: e.Settle, agent: &agent}
}

// agentTurn has the agent play the canary's turn: one A2A message, as the
// developer, under a traceparent of the runner's.
func (e *Env) agentTurn(c *C, k *canary) error {
	a := e.agent
	k.service, k.by, k.agent, k.toolHolds = a.Service, a.Name+"'s", a.Name, k.marker
	tok, err := e.Tokens.Token(c, RoleDeveloper, a.Scope)
	if err != nil {
		return fmt.Errorf("the developer's token for %s: %v", a.Scope, err)
	}
	k.trace = randomHex(16)
	t0 := time.Now()
	// The directive stays in the conversation, so every turn calls the
	// tool again until the agent's model-call cap ends the task, failed:
	// its root span is then an error, which the Dynatrace branch keeps.
	text := k.text + " [[fake-model id=" + k.marker + " tool=" + a.Tool + " arg." + a.Arg + "=" + k.marker + "]]"
	cl := &a2a.Client{URL: e.Cfg.CallURL(a.Route), Token: tok, HTTP: &doer{e: e, src: e.Runner}, Timeout: outcome.Of(a.Wait),
		Header: map[string]string{"traceparent": "00-" + k.trace + "-" + randomHex(8) + "-01"}}
	// Its message ID is not the marker, which the cases look for in
	// everything the destinations received.
	call := cl.Send(c, e.Marker("message"), text, false)
	if call.Outcome.Kind != outcome.Response || call.Outcome.Status != http.StatusOK || call.Response == nil {
		return fmt.Errorf("%s's turn through %s: %s", a.Name, a.Route, call)
	}
	if t, err := call.Task(); err == nil {
		c.Logf("%s's turn ended %s", a.Name, t.Status.State)
	} else {
		c.Logf("%s's turn: %v", a.Name, err)
	}
	if err := e.exportTraces(c, plainTrace(k, t0)); err != nil {
		return err
	}
	k.sent = time.Now()
	return nil
}

// dynatraceCase: every span of the canary's trace reaches the Dynatrace
// stand-in, the gateway's among them, and span metrics of its root; so the
// trace's content was there to remove, and none of it, nor either secret,
// is in anything the stand-in received since the canary was sent.
func dynatraceCase(c *C) {
	e := c.Env
	k := e.canary(c)
	w := e.Cfg.Telemetry.Waits
	wait := max(w.Decision.Duration, w.MetricsFlush.Duration) + w.Delivery.Duration
	var lines []string
	var spans map[string]otlp.ReadSpan
	var metrics bool
	var err error
	poll(c, time.Until(k.sent.Add(wait)), func() bool {
		if lines, err = e.sinkLines(c, e.Cfg.Telemetry.Sinks.Dynatrace, k.start); err != nil {
			return false
		}
		spans, metrics = map[string]otlp.ReadSpan{}, false
		for _, l := range lines {
			x, ok := otlp.Parse([]byte(l))
			if !ok {
				continue
			}
			for _, s := range x.Spans(k.trace) {
				spans[s.SpanID] = s
			}
		}
		// Span metrics of the turn's root, by its name: the runner's holds
		// the run's ID, so an earlier run's series cannot pass for this
		// one's; an agent's is its own, and only its series read since
		// the canary count.
		if root, _, _ := k.turn(spans); root != nil {
			for _, l := range lines {
				metrics = metrics || (strings.Contains(l, `"resourceMetrics"`) && strings.Contains(l, `"`+root.Name+`"`))
			}
		}
		return len(k.missing(spans)) == 0 && gatewaySpan(k, spans) != nil && metrics
	})
	if err != nil {
		c.Fatalf("reading the Dynatrace stand-in: %v", err)
	}
	gaps := noteGaps(c, e.Cfg.Telemetry.Sinks.Dynatrace, k.start)
	if missing := k.missing(spans); len(missing) > 0 {
		c.Errorf("the Dynatrace stand-in lacks %s %s span after %s: the Dynatrace branch keeps every span of an error trace%s", k.by, strings.Join(missing, ", "), wait, gaps)
	}
	if g := gatewaySpan(k, spans); g == nil {
		c.Errorf("no span of the gateway's joined trace %s in the Dynatrace stand-in: the gateway must trace a request under the caller's sampled traceparent, and its span reach the same sampling decision%s", k.trace, gaps)
	} else {
		c.Logf("the gateway's span %q, %s, child of %s", g.Name, g.SpanID, g.ParentSpanID)
	}
	root, _, model := k.turn(spans)
	if !metrics {
		name := k.rootName()
		if root != nil {
			name = root.Name
		}
		c.Errorf("no span metrics of %q reached the Dynatrace stand-in within %s: the Dynatrace branch computes them, before sampling%s", name, wait, gaps)
	}
	if model != nil {
		var keys []string
		for _, a := range model.Attributes {
			keys = append(keys, a.Key)
		}
		c.Logf("the model span %q arrived with the attributes %v", model.Name, keys)
	}
	judgeAbsent(c, k, "the Dynatrace stand-in", lines, true,
		"GenAI content reached Dynatrace: the Dynatrace branch must delete the content attributes and gen_ai.* span events, and mask the secret patterns in what is left")
	if !c.Failed() {
		c.Logf("refused by %s, as due: %d spans of the trace arrived, without the marker or a secret", LayerDynatraceBranch, len(spans))
	}
}

// missing names the spans of the agent's turn that spans lacks, by their
// GenAI operation: the root, a tool call and a model call.
func (k *canary) missing(spans map[string]otlp.ReadSpan) []string {
	root, tool, model := k.turn(spans)
	var out []string
	if root == nil {
		out = append(out, "invoke_agent")
	}
	if tool == nil {
		out = append(out, "execute_tool")
	}
	if model == nil {
		out = append(out, "model call ("+strings.Join(modelOps, ", ")+")")
	}
	return out
}

// gatewaySpan is a span of the trace that the turn's service did not
// send.
func gatewaySpan(k *canary, spans map[string]otlp.ReadSpan) *otlp.ReadSpan {
	ids := make([]string, 0, len(spans))
	for id := range spans {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	for _, id := range ids {
		if s := spans[id]; s.Service != k.service {
			return &s
		}
	}
	return nil
}

// judgeAbsent fails the case for each of texts that holds the marker, if
// it counts, or a secret.
func judgeAbsent(c *C, k *canary, where string, texts []string, marker bool, why string) {
	var what []string
	for _, t := range texts {
		for _, l := range k.leaks(t, marker) {
			if !contains(what, l) {
				what = append(what, l)
			}
		}
	}
	if len(what) > 0 {
		c.Errorf("%s holds %s: %s", where, strings.Join(what, " and "), why)
	}
}

// recordsCase: the gateway's record of the canary's model request reaches
// the SIEM stand-in, the audit bucket and the usage table, each found by
// the trace ID, and none of them holds the prompt's marker or secrets.
func recordsCase(c *C) {
	e := c.Env
	k := e.canary(c)
	cfg := e.Cfg
	wait := max(cfg.Telemetry.Waits.Delivery.Duration, cfg.UsageTable.Wait.Duration)
	var siem []string
	objects := map[string][]byte{}
	var rows []map[string]any
	var siemErr, auditErr, usageErr error
	var inSIEM bool
	var inAudit string
	poll(c, time.Until(k.sent.Add(wait)), func() bool {
		if !inSIEM {
			if siem, siemErr = e.sinkLines(c, cfg.Telemetry.Sinks.SIEM, k.start); siemErr == nil {
				inSIEM = recordIn(siem, k.trace)
			}
		}
		if inAudit == "" {
			if auditErr = e.readObjects(c, cfg.Audit.Bucket, e.auditPrefixes(k.start), objects); auditErr == nil {
				inAudit = objectWithRecord(objects, k.trace)
			}
		}
		if len(rows) == 0 {
			rows, usageErr = e.usageRows(c, k.trace)
		}
		return inSIEM && inAudit != "" && len(rows) > 0
	})
	// Read everything again for the absence checks: what arrived since.
	if s, err := e.sinkLines(c, cfg.Telemetry.Sinks.SIEM, k.start); err == nil {
		siem = s
	}
	e.readObjects(c, cfg.Audit.Bucket, e.auditPrefixes(k.start), objects)
	siemGaps := noteGaps(c, cfg.Telemetry.Sinks.SIEM, k.start)
	switch {
	case siemErr != nil:
		c.Errorf("reading the SIEM stand-in: %v", siemErr)
	case !inSIEM:
		c.Errorf("no record with trace ID %s reached the SIEM stand-in within %s: the gateway's record goes to the SIEM, unsampled%s", k.trace, wait, siemGaps)
	}
	switch {
	case auditErr != nil:
		c.Errorf("reading s3://%s: %v", cfg.Audit.Bucket, auditErr)
	case inAudit == "":
		c.Errorf("no object in s3://%s/%s/ holds a record with trace ID %s within %s (%d objects read): the gateway's record goes to the audit bucket", cfg.Audit.Bucket, cfg.Audit.Prefix, k.trace, wait, len(objects))
	default:
		c.Logf("the audit bucket's record: s3://%s/%s", cfg.Audit.Bucket, inAudit)
	}
	switch {
	case usageErr != nil:
		c.Errorf("%v", usageErr)
	case len(rows) == 0:
		c.Errorf("no row in the usage table has trace_id %s within %s: a model request's record is a usage record too", k.trace, wait)
	}
	why := "the gateway's record must hold no content of the request"
	judgeAbsent(c, k, "the SIEM stand-in", siem, true, why)
	var bodies []string
	for _, b := range objects {
		bodies = append(bodies, string(b))
	}
	judgeAbsent(c, k, fmt.Sprintf("the audit bucket (%d objects)", len(objects)), bodies, true, why)
	raw, _ := json.Marshal(rows)
	judgeAbsent(c, k, "the usage table", []string{string(raw)}, true, why)
	if !c.Failed() {
		c.Logf("refused by %s, as due: the record arrived in all three, without the marker or a secret", LayerRecord)
	}
}

// recordIn reports whether one of lines holds a log record of the trace
// that the collector stamped as the platform port's: the gateway's, not a
// workload's audit record in the same trace (B5), which a general port
// stamps workload.
func recordIn(lines []string, traceID string) bool {
	for _, l := range lines {
		if x, ok := otlp.Parse([]byte(l)); ok && platformRecord(x, traceID) {
			return true
		}
	}
	return false
}

func platformRecord(x otlp.Export, traceID string) bool {
	for _, r := range x.Logs(traceID) {
		if otlp.Attr(r.Attributes, "record.source") == "platform" {
			return true
		}
	}
	return false
}

// objectWithRecord is the key of an object holding the platform port's
// log record of the trace: an object is one OTLP JSON document, or one
// per line.
func objectWithRecord(objects map[string][]byte, traceID string) string {
	var keys []string
	for key := range objects {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		if x, ok := otlp.Parse(objects[key]); ok && platformRecord(x, traceID) {
			return key
		}
		if recordIn(strings.Split(string(objects[key]), "\n"), traceID) {
			return key
		}
	}
	return ""
}

// langfuseCase: Langfuse shows the canary's text in the tool span's
// output and in the chat span's input, each secret replaced by the mask,
// so the content arrived and only the secrets were masked; neither its
// API's answer nor any event blob written since the canary holds a
// secret, whole or in part.
func langfuseCase(c *C) {
	e := c.Env
	k := e.canary(c)
	cfg := e.Cfg
	w := cfg.Telemetry.Waits
	wait := w.Decision.Duration + w.Delivery.Duration + w.Langfuse.Duration
	var body []byte
	var obs map[string]map[string]any
	blobs := map[string][]byte{}
	var apiErr, blobErr error
	tool := func() map[string]any {
		return k.langfuseSpan(obs, k.tool, []string{"execute_tool"}, "output", k.toolHolds)
	}
	chat := func() map[string]any { return k.langfuseSpan(obs, k.chat, modelOps, "input", k.masked) }
	poll(c, time.Until(k.sent.Add(wait)), func() bool {
		body, obs, apiErr = e.langfuseObservations(c, k.trace)
		blobErr = e.readObjects(c, cfg.Langfuse.EventsBucket, e.blobPrefixes(k.start), blobs)
		return apiErr == nil && blobErr == nil && strings.Contains(text(tool()["output"]), k.toolHolds) &&
			strings.Contains(text(chat()["input"]), k.masked) && blobWith(blobs, k.masked) != ""
	})
	if apiErr != nil {
		c.Fatalf("%v", apiErr)
	}
	if len(obs) == 0 {
		c.Errorf("Langfuse holds no observation of trace %s after %s: the Langfuse branch keeps every trace with a GenAI span, whole", k.trace, wait)
	}
	for _, f := range []struct {
		span, field, holds string
		o                  map[string]any
	}{{"tool span's", "output", k.toolHolds, tool()}, {"model span's", "input", k.masked, chat()}} {
		got := text(f.o[f.field])
		switch {
		case f.o == nil:
			if len(obs) > 0 {
				c.Errorf("Langfuse has no observation of %s %s, by its GenAI operation and service %s", k.by, strings.TrimSuffix(f.span, "'s"), k.service)
			}
		case strings.Contains(got, f.holds):
		case strings.Contains(got, k.marker):
			c.Errorf("the %s %s in Langfuse holds the marker, but not with each secret replaced by the mask %q: %s", f.span, f.field, cfg.Telemetry.Mask, k.scrub(got))
		default:
			c.Errorf("the %s %s in Langfuse lacks the marker: the Langfuse branch keeps the content, masking only secrets (%s)", f.span, f.field, k.scrub(got))
		}
	}
	judgeAbsent(c, k, "Langfuse's API", []string{string(body)}, false, "the Langfuse branch must mask the secret patterns")
	switch {
	case blobErr != nil:
		c.Errorf("reading s3://%s: %v", cfg.Langfuse.EventsBucket, blobErr)
	case blobWith(blobs, k.marker) == "":
		c.Errorf("no event blob in s3://%s under %sotel/%s/ written since the canary holds the marker (%d read)", cfg.Langfuse.EventsBucket, cfg.Langfuse.EventsPrefix, cfg.Langfuse.Project, len(blobs))
	case blobWith(blobs, k.masked) == "":
		c.Errorf("the event blob %s holds the marker, but not with each secret replaced by the mask", blobWith(blobs, k.marker))
	default:
		c.Logf("the trace's event blob: s3://%s/%s", cfg.Langfuse.EventsBucket, blobWith(blobs, k.masked))
	}
	var bodies []string
	for _, b := range blobs {
		bodies = append(bodies, string(b))
	}
	judgeAbsent(c, k, fmt.Sprintf("Langfuse's event blobs (%d read)", len(blobs)), bodies, false, "the Langfuse branch must mask the secret patterns")
	if !c.Failed() {
		c.Logf("refused by %s, as due: the content arrived with each secret masked", LayerLangfuseBranch)
	}
}

// langfuseSpan is the turn's observation of a kind: by its span's ID
// when the runner played the turn (pick); otherwise, the agent's spans
// being unknown before they arrive, the first of the agent's service
// whose span's GenAI operation is one of ops and whose field holds want,
// else the first such. The operation is read from the metadata, not the
// name: Langfuse names a tool span's observation by the tool.
func (k *canary) langfuseSpan(obs map[string]map[string]any, id string, ops []string, field, want string) map[string]any {
	if id != "" {
		return pick(obs, id, ops[0]+" ", k.root)
	}
	var ids []string
	for i := range obs {
		ids = append(ids, i)
	}
	sort.Strings(ids)
	var first map[string]any
	for _, i := range ids {
		if !slices.Contains(ops, observationOp(obs[i])) || ObservationService(obs[i]) != k.service {
			continue
		}
		if strings.Contains(text(obs[i][field]), want) {
			return obs[i]
		}
		if first == nil {
			first = obs[i]
		}
	}
	return first
}

// pick is the observation with id, Langfuse's for the span with that hex
// ID, or else the first child of parent whose name starts with prefix: not
// the gateway's span, a child of the chat span, whatever it is named.
func pick(obs map[string]map[string]any, id, prefix, parent string) map[string]any {
	if o, ok := obs[id]; ok {
		return o
	}
	var ids []string
	for i := range obs {
		ids = append(ids, i)
	}
	sort.Strings(ids)
	for _, i := range ids {
		if strings.HasPrefix(str(obs[i]["name"]), prefix) && str(obs[i]["parentObservationId"]) == parent {
			return obs[i]
		}
	}
	return nil
}

// text is a value as text: a string as itself, anything else as JSON.
func text(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	if v == nil {
		return ""
	}
	b, _ := json.Marshal(v)
	return string(b)
}

// blobWith is the first key, in order, whose body holds s.
func blobWith(blobs map[string][]byte, s string) string {
	var keys []string
	for key, b := range blobs {
		if strings.Contains(string(b), s) {
			keys = append(keys, key)
		}
	}
	sort.Strings(keys)
	if len(keys) == 0 {
		return ""
	}
	return keys[0]
}

// noGenAICase: the trace without a GenAI span reaches the Dynatrace
// stand-in, so the collector took it, and never Langfuse, which the
// canary's GenAI trace, sent in the same export, does reach; after both,
// Langfuse is watched for one more decision wait, since the two traces
// may be decided on different sampling replicas.
func noGenAICase(c *C) {
	e := c.Env
	k := e.canary(c)
	w := e.Cfg.Telemetry.Waits
	wait := w.Decision.Duration + w.Delivery.Duration + w.Langfuse.Duration
	var inDynatrace, twin, leaked bool
	var err error
	check := func() bool {
		var obs map[string]map[string]any
		if _, obs, err = e.langfuseObservations(c, k.plain); err != nil {
			return false
		}
		leaked = len(obs) > 0
		return leaked
	}
	poll(c, time.Until(k.sent.Add(wait)), func() bool {
		if !inDynatrace {
			lines, lerr := e.sinkLines(c, e.Cfg.Telemetry.Sinks.Dynatrace, k.start)
			if lerr != nil {
				err = lerr
				return false
			}
			for _, l := range lines {
				if x, ok := otlp.Parse([]byte(l)); ok {
					for _, s := range x.Spans(k.plain) {
						inDynatrace = inDynatrace || s.SpanID == k.plainRoot
					}
				}
			}
		}
		if !twin {
			var obs map[string]map[string]any
			if _, obs, err = e.langfuseObservations(c, k.trace); err != nil {
				return false
			}
			twin = len(obs) > 0
		}
		return check() || (inDynatrace && twin)
	})
	if err != nil {
		c.Fatalf("%v", err)
	}
	if !leaked && inDynatrace && twin {
		poll(c, w.Decision.Duration, check)
	}
	gaps := noteGaps(c, e.Cfg.Telemetry.Sinks.Dynatrace, k.start)
	switch {
	case leaked:
		c.Errorf("the trace without a GenAI span, %s, reached Langfuse: the Langfuse branch must keep only traces with a span that carries gen_ai.operation.name", k.plain)
	case !inDynatrace:
		c.Errorf("allowed twin: the trace without a GenAI span never reached the Dynatrace stand-in within %s, so its absence from Langfuse proves nothing%s", wait, gaps)
	case !twin:
		c.Errorf("allowed twin: the canary's GenAI trace, sent with it, never reached Langfuse within %s, so the other's absence proves nothing", wait)
	default:
		c.Logf("refused by %s, as due: in the Dynatrace stand-in, and still absent from Langfuse %s after the GenAI trace arrived there", LayerLangfuseBranch, w.Decision.Duration)
	}
}

// sinkLog is what the run has read of one stand-in's log since a time.
// The kubelet serves only a container's current log file, and rotates a
// busy one's every few minutes (B3's Dynatrace stand-in, printing span
// metrics, every 25 or so): a line read once is kept for every later
// read, by every case, and a rotation between two reads is named, since
// what the container printed between them and the rotation was never
// read.
type sinkLog struct {
	lines  []string
	seen   map[string]bool         // each line kept, by pod, stamp and text
	last   map[string]kube.LogLine // by pod, the latest line kept
	readAt time.Time               // the previous read
	gaps   []string                // the rotations seen between reads
}

func lineKey(l kube.LogLine) string {
	return l.Pod + "\x00" + l.Time.UTC().Format(time.RFC3339Nano) + "\x00" + l.Text
}

// SinkLines are what reached a telemetry stand-in, its container named,
// since a time, as the telemetry group reads them: for the kagent
// profile's telemetry case.
func (e *Env) SinkLines(ctx context.Context, container string, since time.Time) ([]string, error) {
	return e.sinkLines(ctx, container, since)
}

// LangfuseObservations are Langfuse's observations of a trace, by their
// span's ID, for the workload suites: the trace's spans as Langfuse keeps
// them, whole for every trace with a GenAI span.
func (e *Env) LangfuseObservations(ctx context.Context, traceID string) (map[string]map[string]any, error) {
	_, obs, err := e.langfuseObservations(ctx, traceID)
	return obs, err
}

// ObservationService is the service.name of the resource an observation's
// span came from, which Langfuse keeps in its metadata as
// resourceAttributes.service.name (Langfuse 4, checked 2026-11-18).
func ObservationService(o map[string]any) string {
	m, _ := o["metadata"].(map[string]any)
	return str(m["resourceAttributes.service.name"])
}

// observationOp is an observation's span's gen_ai.operation.name, which
// Langfuse keeps in its metadata as attributes.gen_ai.operation.name.
func observationOp(o map[string]any) string {
	m, _ := o["metadata"].(map[string]any)
	return str(m["attributes.gen_ai.operation.name"])
}

// ObservationOp is observationOp, for the workload suites' integration
// stage.
func ObservationOp(o map[string]any) string { return observationOp(o) }

// IsModelOp reports whether a gen_ai.operation.name is a model call's.
func IsModelOp(op string) bool { return contains(modelOps, op) }

// ModelOps are the GenAI operations of a model call.
func ModelOps() []string { return append([]string(nil), modelOps...) }

// storeMax bounds a read of the records store: its retention is the
// current file and three rotated ones of 20 MB each, per sink.
const storeMax = 128 << 20

// storeLines are what reached a stand-in since a time, from the store it
// keeps its records in (B5; environments' charts/telemetry-sink): the
// rotated files last written at or after since, oldest first, then the
// current file, one OTLP export request a line. A minute of slack covers
// the files' mtime granularity and clock skew. A rotated file is still
// served, so no rotation hides a line; a line cut short while the
// collector writes does not parse and is dropped. Every line any read of
// the run returned is kept, in the order first read, as for the log.
func (e *Env) storeLines(c context.Context, container string, since time.Time) ([]string, error) {
	u := e.Cfg.Telemetry.Sinks.RecordsURL + "/" + url.PathEscape(container) + "?since=" + strconv.FormatInt(since.Add(-time.Minute).Unix(), 10)
	var got [][]byte
	if err := e.Read.Lines(c, u, storeMax, func(l []byte) {
		if json.Valid(l) {
			got = append(got, l)
		}
	}); err != nil {
		return nil, fmt.Errorf("the %s stand-in's records store: %v", container, err)
	}
	e.sinkMu.Lock()
	defer e.sinkMu.Unlock()
	key := "store\x00" + container + "\x00" + since.UTC().Format(time.RFC3339Nano)
	if e.sinkLogs == nil {
		e.sinkLogs = map[string]*sinkLog{}
	}
	acc := e.sinkLogs[key]
	if acc == nil {
		acc = &sinkLog{seen: map[string]bool{}}
		e.sinkLogs[key] = acc
	}
	for _, l := range got {
		// Kept by digest: the store serves every line again on each read.
		h := sha256.Sum256(l)
		if k := string(h[:]); !acc.seen[k] {
			acc.seen[k] = true
			acc.lines = append(acc.lines, string(l))
		}
	}
	return append([]string(nil), acc.lines...), nil
}

// sinkLines are what reached a stand-in since a time: every line any read
// of the run returned, in the order first read. From its records store
// when there is one, else from its pod's log.
func (e *Env) sinkLines(c context.Context, container string, since time.Time) ([]string, error) {
	s := e.Cfg.Telemetry.Sinks
	if s.RecordsURL != "" {
		return e.storeLines(c, container, since)
	}
	got, err := e.Logs.Lines(c, s.Namespace, s.Selector, container, since)
	if err != nil {
		return nil, err
	}
	now := time.Now()
	e.sinkMu.Lock()
	defer e.sinkMu.Unlock()
	key := container + "\x00" + since.UTC().Format(time.RFC3339Nano)
	if e.sinkLogs == nil {
		e.sinkLogs = map[string]*sinkLog{}
	}
	acc := e.sinkLogs[key]
	if acc == nil {
		acc = &sinkLog{seen: map[string]bool{}, last: map[string]kube.LogLine{}}
		e.sinkLogs[key] = acc
	}
	present := map[string]bool{}
	first := map[string]time.Time{}
	for _, l := range got {
		present[lineKey(l)] = true
		if f, ok := first[l.Pod]; !ok || l.Time.Before(f) {
			first[l.Pod] = l.Time
		}
	}
	for pod, l := range acc.last {
		if present[lineKey(l)] {
			continue
		}
		// The line last kept from pod is no longer in its log: the log
		// rotated after the previous read, or the pod went away.
		until := "now"
		if f, ok := first[pod]; ok {
			until = f.UTC().Format("15:04:05.000")
		}
		acc.gaps = append(acc.gaps, fmt.Sprintf("%s's log rotated between reads: what it printed from %s to %s was not read",
			pod, acc.readAt.UTC().Format("15:04:05.000"), until))
		delete(acc.last, pod)
	}
	for _, l := range got {
		k := lineKey(l)
		if !acc.seen[k] {
			acc.seen[k] = true
			acc.lines = append(acc.lines, l.Text)
		}
		if prev, ok := acc.last[l.Pod]; !ok || !l.Time.Before(prev.Time) {
			acc.last[l.Pod] = l
		}
	}
	acc.readAt = now
	return append([]string(nil), acc.lines...), nil
}

// sinkGaps names the rotations of a stand-in's log seen between reads
// since a time, for messages; "" if there were none.
func (e *Env) sinkGaps(container string, since time.Time) string {
	e.sinkMu.Lock()
	defer e.sinkMu.Unlock()
	acc := e.sinkLogs[container+"\x00"+since.UTC().Format(time.RFC3339Nano)]
	if acc == nil || len(acc.gaps) == 0 {
		return ""
	}
	return strings.Join(acc.gaps, "; ")
}

// noteGaps logs a stand-in's rotations, which lines kept across them made
// harmless unless the case fails; then its message names them too.
func noteGaps(c *C, container string, since time.Time) string {
	g := c.Env.sinkGaps(container, since)
	if g != "" {
		c.Logf("the %s stand-in: %s; every line read before was kept", container, g)
		return " (the " + container + " stand-in: " + g + ")"
	}
	return ""
}

// langfuseObservations are a trace's observations through Langfuse's
// public API, by ID, with the answers' bodies. Langfuse 4 serves them at
// /api/public/v2/observations; the trace endpoint of v3 answers 404 in its
// default events_only write mode. The v2 endpoint returns only the core
// and basic field groups unless asked: input and output need io, read
// whole from its full events table.
func (e *Env) langfuseObservations(c context.Context, traceID string) ([]byte, map[string]map[string]any, error) {
	l := e.Cfg.Langfuse
	pub, err := e.secretFile("langfuse.public_key_file", l.PublicKeyFile)
	if err != nil {
		return nil, nil, err
	}
	sec, err := e.secretFile("langfuse.secret_key_file", l.SecretKeyFile)
	if err != nil {
		return nil, nil, err
	}
	auth := "Basic " + base64.StdEncoding.EncodeToString([]byte(pub+":"+sec))
	var all []byte
	obs := map[string]map[string]any{}
	cursor := ""
	for page := 0; page < 20; page++ {
		q := "traceId=" + traceID + "&fields=core,basic,io,metadata&limit=1000"
		if cursor != "" {
			q += "&cursor=" + url.QueryEscape(cursor)
		}
		resp, err := e.Read.Do(c, http.MethodGet, l.URL+"/api/public/v2/observations?"+q, map[string]string{"Authorization": auth}, nil)
		if err != nil {
			return nil, nil, fmt.Errorf("Langfuse's observations: %v", err)
		}
		if resp.Status != http.StatusOK {
			return nil, nil, fmt.Errorf("Langfuse's observations: HTTP %d: %s", resp.Status, short(resp.Body))
		}
		all = append(append(all, resp.Body...), '\n')
		var doc struct {
			Data []map[string]any `json:"data"`
			Meta struct {
				Cursor string `json:"cursor"`
			} `json:"meta"`
		}
		if err := json.Unmarshal(resp.Body, &doc); err != nil {
			return nil, nil, fmt.Errorf("Langfuse's observations: %v", err)
		}
		for _, o := range doc.Data {
			obs[str(o["id"])] = o
		}
		if doc.Meta.Cursor == "" {
			break
		}
		cursor = doc.Meta.Cursor
	}
	return all, obs, nil
}

// readObjects reads into seen every object under prefixes it has not read.
func (e *Env) readObjects(c *C, bucket string, prefixes []string, seen map[string][]byte) error {
	for _, p := range prefixes {
		objs, err := e.S3.List(c, bucket, p)
		if err != nil {
			return err
		}
		for _, o := range objs {
			if _, ok := seen[o.Key]; ok {
				continue
			}
			body, err := e.S3.Get(c, bucket, o.Key)
			if err != nil {
				return err
			}
			seen[o.Key] = body
		}
	}
	return nil
}

// minutes are the minutes, in UTC, from the one before since to now: the
// partitions written since.
func minutes(since time.Time) []time.Time {
	var out []time.Time
	for t := since.UTC().Truncate(time.Minute).Add(-time.Minute); !t.After(time.Now().UTC()); t = t.Add(time.Minute) {
		out = append(out, t)
	}
	return out
}

// auditPrefixes are the audit bucket's prefixes written since a time, as
// the S3 exporter's s3_prefix and s3_partition_format make them.
func (e *Env) auditPrefixes(since time.Time) []string {
	var out []string
	for _, t := range minutes(since) {
		out = append(out, strings.TrimRight(e.Cfg.Audit.Prefix, "/")+"/"+strftime(e.Cfg.Audit.Partition, t)+"/")
	}
	return out
}

// blobPrefixes are where Langfuse put the OTLP exports it received since
// a time: <prefix>otel/<project>/<yyyy>/<mm>/<dd>/<hh>/<mm>/.
func (e *Env) blobPrefixes(since time.Time) []string {
	var out []string
	for _, t := range minutes(since) {
		out = append(out, e.Cfg.Langfuse.EventsPrefix+"otel/"+e.Cfg.Langfuse.Project+"/"+t.Format("2006/01/02/15/04")+"/")
	}
	return out
}

// strftime formats t with the directives the S3 exporter's partitions
// use: %Y, %m, %d, %H, %M and %S.
func strftime(format string, t time.Time) string {
	return strings.NewReplacer("%Y", t.Format("2006"), "%m", t.Format("01"), "%d", t.Format("02"),
		"%H", t.Format("15"), "%M", t.Format("04"), "%S", t.Format("05")).Replace(format)
}

func b64url(s string) string { return base64.RawURLEncoding.EncodeToString([]byte(s)) }

// randomAlnum is n random letters and digits.
func randomAlnum(n int) string {
	const set = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
	raw := make([]byte, n)
	rand.Read(raw)
	out := make([]byte, n)
	for i := range out {
		out[i] = set[int(raw[i])%len(set)]
	}
	return string(out)
}
