# `spec`

Not a component: the check that components run against `agent-sdk`'s spec, which `sign`'s attest mode uses for its predicates. A job gets it by including [`spec.yml`](spec.yml) with `include:local` and extending its hidden job, `.agentic-spec`, so it runs at the component's own commit, although only YAML reaches a consumer's pipeline.

```text
templates/spec/
├── spec/         # agent-sdk's spec/schemas/, attestations/ and limits/, JSON only, vendored
├── SOURCE        # the agent-sdk commit spec/ came from
├── vendor.sh     # writes spec/ and SOURCE from an agent-sdk checkout
├── validate.py   # the check, Python's standard library alone
├── embed.py      # writes spec.yml from validate.py and spec/'s schemas
└── spec.yml      # generated: .agentic-spec, with SPEC_VALIDATE_PY, SPEC_SCHEMAS and SPEC_COMMIT
```

## The check

`validate.py --schemas <spec dir or bundle> --schema <path under spec/> <file.json>...` checks JSON files against one of the spec's schemas: 0 when every file is valid, 1 when one is not, with each problem's place and reason, 2 when it cannot run. YAML is converted to JSON first, as the spec's README says its YAML files are validated. It implements the JSON Schema 2020-12 keywords the spec uses, `$ref` across files by relative path among them, and asserts the formats `date`, `date-time` and `uri`; a keyword it does not know is an error, never ignored, so a spec that adds one cannot pass a rule by it unseen. Patterns match as ECMA-262's do: `$` ends the string, and `\d` is an ASCII digit.

Why not a validator from a package index: a component's job would then fetch code at run time, with its pins in every consumer's pipeline, where the kagent check, for the same reason, carries its own ([`kagent-package`](../kagent-package/README.md)).

## Updating the spec

From the repository root, with `agent-sdk` checked out beside this repository:

```sh
templates/spec/vendor.sh ../agent-sdk <commit or spec/vX.Y.Z>
python3 -I templates/spec/embed.py
python3 -I tests/spec/test_validate.py
```

Never edit `spec/` or `spec.yml` by hand. A spec that changes a rule a component's input depends on is a change to that component's contract, and its version follows.

## Tests

[`tests/spec/test_validate.py`](../../tests/spec/test_validate.py) runs every file under an `examples/` directory of the vendored spec, which must validate against the schema its name gives, `<case>.<schema>.json`, and every file under an `invalid/` directory, which must be refused; the bundle `spec.yml` carries must check as the directory does, an unknown keyword must be an error, and patterns and equality must follow JSON Schema's rules. CI runs it on every pipeline (`test:spec:unit`), with `embed.py --check`, which fails when `spec.yml` is stale.
