#!/bin/sh
# Copy the JSON files of agent-sdk's spec/schemas/, spec/attestations/ and
# spec/limits/ at one commit into spec/ beside this script, and record
# where they came from in SOURCE, as agentctl's internal/spec/vendor.sh
# does. The components check against these schemas; the examples and
# invalid files are the test vectors tests/spec/ runs. Never edit spec/ by
# hand: change agent-sdk, then run this again, then embed.py.
#
# Usage: templates/spec/vendor.sh [AGENT_SDK_DIR] [REV]
#   AGENT_SDK_DIR  a clone of devkit/agent-sdk; default: the workspace sibling
#   REV            a commit or tag, such as spec/v0.3.0; default: HEAD
set -eu
here=$(cd "$(dirname "$0")" && pwd)
sdk=${1:-$here/../../../agent-sdk}
rev=${2:-HEAD}

commit=$(git -C "$sdk" rev-parse --verify "$rev^{commit}")
tag=$(git -C "$sdk" tag --points-at "$commit" --list 'spec/v*' | sort -V | tail -n 1)

rm -rf "$here/spec"
git -C "$sdk" archive --format=tar "$commit" spec/schemas spec/attestations spec/limits | tar -x -C "$here"
find "$here/spec" -type f ! -name '*.json' -exec rm {} +

cat > "$here/SOURCE" <<END
# spec/ beside this file holds the JSON files of devkit/agent-sdk's
# spec/schemas/, spec/attestations/ and spec/limits/ at this commit,
# written by vendor.sh. Do not edit spec/ by hand.
repository: devkit/agent-sdk
commit: $commit
tag: ${tag:-none}
END
echo "vendored spec/ from $commit${tag:+ ($tag)}"
