"""The platform's JSON Schemas (agent-sdk's spec/), checked with Python's
standard library alone, so a component's job needs no package index.

Usage:
  python3 -I validate.py --schemas <spec dir or bundle.json> --schema <path> <file.json>...

--schemas is a directory holding the spec's schemas at their paths under
spec/ (schemas/artifact.schema.json, attestations/conformance.schema.json,
...), or a bundle: one JSON object mapping those paths to the schemas, as
embed.py writes it into a component. --schema is the path of the schema to
check against. Each file is JSON; YAML is converted first (yq), as the
spec's README says files are validated as the JSON they parse to.

It implements the JSON Schema 2020-12 keywords the spec uses: $ref between
files by relative path and JSON pointer, type, enum, const, the string,
number, object and array keywords, allOf, anyOf, oneOf, not, if/then/else,
and the formats date, date-time and uri, asserted. A keyword it does not
know is an error, never ignored, so a new spec cannot pass a rule by it
unseen. Patterns are matched as ECMA-262 would: $ ends the string, and \\d
is an ASCII digit.

Exit status: 0 every file valid, 1 a file invalid (each problem listed),
2 usage or input error.
"""

import datetime
import json
import os
import posixpath
import re
import sys
import urllib.parse

ANNOTATIONS = {"$schema", "$id", "$comment", "title", "description", "examples", "default", "deprecated",
               "readOnly", "writeOnly", "$defs"}
APPLICATORS = {"$ref", "type", "enum", "const", "minLength", "maxLength", "pattern", "format", "minimum",
               "maximum", "exclusiveMinimum", "exclusiveMaximum", "multipleOf", "required", "properties",
               "patternProperties", "additionalProperties", "propertyNames", "minProperties", "maxProperties",
               "items", "prefixItems", "minItems", "maxItems", "uniqueItems", "contains", "minContains",
               "maxContains", "allOf", "anyOf", "oneOf", "not", "if", "then", "else", "dependentRequired"}


class InputError(Exception):
    """A schema or file the check cannot use: exit status 2."""


def canonical(value):
    """A key for JSON equality: true is not 1, and 1.0 is 1."""
    if isinstance(value, bool):
        return ("bool", value)
    if isinstance(value, (int, float)):
        return ("number", float(value)) if float(value) != int(value) else ("number", int(value))
    if isinstance(value, str):
        return ("string", value)
    if value is None:
        return ("null",)
    if isinstance(value, list):
        return ("array", tuple(canonical(v) for v in value))
    if isinstance(value, dict):
        return ("object", tuple(sorted((k, canonical(v)) for k, v in value.items())))
    raise InputError(f"not a JSON value: {value!r}")


TYPES = {
    "object": lambda v: isinstance(v, dict),
    "array": lambda v: isinstance(v, list),
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool) and float(v).is_integer(),
    "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
    "null": lambda v: v is None,
}

DATE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
DATE_TIME = re.compile(r"^([0-9]{4}-[0-9]{2}-[0-9]{2})[Tt]([0-9]{2}):([0-9]{2}):([0-9]{2})(\.[0-9]+)?([Zz]|[+-][0-9]{2}:[0-9]{2})$")


def valid_date(s):
    if not DATE.match(s):
        return False
    try:
        datetime.date.fromisoformat(s)
    except ValueError:
        return False
    return True


def valid_date_time(s):
    m = DATE_TIME.match(s)
    if not m or not valid_date(m.group(1)):
        return False
    hour, minute, second = int(m.group(2)), int(m.group(3)), int(m.group(4))
    # RFC 3339 allows a leap second, 60; the spec's patterns refuse it.
    return hour <= 23 and minute <= 59 and second <= 60


def valid_uri(s):
    parts = urllib.parse.urlsplit(s)
    return bool(re.match(r"^[A-Za-z][A-Za-z0-9+.-]*$", parts.scheme)) and not re.search(r"[\s<>\"{}|\\^`]", s)


FORMATS = {"date": valid_date, "date-time": valid_date_time, "uri": valid_uri}


def ecma(pattern):
    """A Python pattern that matches as the ECMA-262 one does."""
    out, i, in_class = [], 0, False
    while i < len(pattern):
        c = pattern[i]
        if c == "\\" and i + 1 < len(pattern):
            n = pattern[i + 1]
            if n == "d":
                out.append("0-9" if in_class else "[0-9]")
            elif n == "D" and not in_class:
                out.append("[^0-9]")
            else:
                out.append(c + n)
            i += 2
            continue
        if c == "[" and not in_class:
            in_class = True
        elif c == "]" and in_class:
            in_class = False
        elif c == "$" and not in_class:
            c = r"\Z"
        out.append(c)
        i += 1
    return re.compile("".join(out))


class Schemas:
    """The spec's schemas by their paths under spec/."""

    def __init__(self, source):
        self.docs = {}
        if os.path.isdir(source):
            for root, _, files in os.walk(source):
                for name in files:
                    if name.endswith(".schema.json"):
                        full = os.path.join(root, name)
                        rel = os.path.relpath(full, source).replace(os.sep, "/")
                        self.docs[rel] = load_json(full)
        else:
            bundle = load_json(source)
            if not isinstance(bundle, dict):
                raise InputError(f"{source}: a bundle is an object of schemas by path")
            self.docs = bundle
        self.patterns = {}

    def get(self, path):
        if path not in self.docs:
            raise InputError(f"no schema {path} (have {', '.join(sorted(self.docs))})")
        return self.docs[path]

    def resolve(self, base, ref):
        """The schema ref names, from the file base, and the file it is in."""
        file, _, fragment = ref.partition("#")
        path = posixpath.normpath(posixpath.join(posixpath.dirname(base), file)) if file else base
        node = self.get(path)
        if fragment:
            if not fragment.startswith("/"):
                raise InputError(f"{base}: $ref {ref}: only JSON pointers are supported")
            for part in fragment[1:].split("/"):
                part = urllib.parse.unquote(part).replace("~1", "/").replace("~0", "~")
                if isinstance(node, list) and part.isdigit():
                    node = node[int(part)]
                elif isinstance(node, dict) and part in node:
                    node = node[part]
                else:
                    raise InputError(f"{base}: $ref {ref} does not resolve")
        return path, node

    def pattern(self, p):
        if p not in self.patterns:
            self.patterns[p] = ecma(p)
        return self.patterns[p]

    def check(self, value, path):
        """The problems of value against the schema at path: [] if valid."""
        problems = []
        self.validate(value, self.get(path), path, "$", problems)
        return problems

    def validate(self, value, schema, base, at, problems):
        if schema is True:
            return
        if schema is False:
            problems.append(f"{at}: no value is allowed here")
            return
        if not isinstance(schema, dict):
            raise InputError(f"{base}: a schema is an object or a boolean, not {schema!r}")
        unknown = set(schema) - ANNOTATIONS - APPLICATORS
        if unknown:
            raise InputError(f"{base}: uses {', '.join(sorted(unknown))}, which this check does not know")
        if "$ref" in schema:
            target_base, target = self.resolve(base, schema["$ref"])
            self.validate(value, target, target_base, at, problems)
        if "type" in schema:
            types = schema["type"] if isinstance(schema["type"], list) else [schema["type"]]
            if not any(TYPES[t](value) for t in types):
                problems.append(f"{at}: is {kind(value)}, not {' or '.join(types)}")
                return
        if "enum" in schema and canonical(value) not in [canonical(e) for e in schema["enum"]]:
            problems.append(f"{at}: {short(value)} is not one of {', '.join(short(e) for e in schema['enum'])}")
        if "const" in schema and canonical(value) != canonical(schema["const"]):
            problems.append(f"{at}: must be {short(schema['const'])}, not {short(value)}")
        if isinstance(value, str):
            self.string(value, schema, at, problems)
        if TYPES["number"](value):
            self.number(value, schema, at, problems)
        if isinstance(value, dict):
            self.object(value, schema, base, at, problems)
        if isinstance(value, list):
            self.array(value, schema, base, at, problems)
        for sub in schema.get("allOf", []):
            self.validate(value, sub, base, at, problems)
        if "anyOf" in schema:
            results = [self.sub(value, s, base, at) for s in schema["anyOf"]]
            if all(results):
                problems.append(f"{at}: matches none of anyOf: " + "; ".join(r[0] for r in results))
        if "oneOf" in schema:
            results = [self.sub(value, s, base, at) for s in schema["oneOf"]]
            matched = sum(1 for r in results if not r)
            if matched != 1:
                problems.append(f"{at}: matches {matched} of oneOf, not exactly one")
        if "not" in schema and not self.sub(value, schema["not"], base, at):
            problems.append(f"{at}: matches a schema it must not ({short(schema['not'])})")
        if "if" in schema:
            branch = "then" if not self.sub(value, schema["if"], base, at) else "else"
            if branch in schema:
                self.validate(value, schema[branch], base, at, problems)

    def sub(self, value, schema, base, at):
        problems = []
        self.validate(value, schema, base, at, problems)
        return problems

    def string(self, value, schema, at, problems):
        if "minLength" in schema and len(value) < schema["minLength"]:
            problems.append(f"{at}: is shorter than {schema['minLength']} characters")
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            problems.append(f"{at}: is longer than {schema['maxLength']} characters")
        if "pattern" in schema and not self.pattern(schema["pattern"]).search(value):
            problems.append(f"{at}: {short(value)} does not match {schema['pattern']}")
        if "format" in schema:
            check = FORMATS.get(schema["format"])
            if check is None:
                raise InputError(f"format {schema['format']} is not one this check knows")
            if not check(value):
                problems.append(f"{at}: {short(value)} is not a valid {schema['format']}")

    def number(self, value, schema, at, problems):
        for key, ok, words in (("minimum", lambda v, m: v >= m, "below"), ("maximum", lambda v, m: v <= m, "above"),
                               ("exclusiveMinimum", lambda v, m: v > m, "not above"),
                               ("exclusiveMaximum", lambda v, m: v < m, "not below")):
            if key in schema and not ok(value, schema[key]):
                problems.append(f"{at}: {value} is {words} {schema[key]}")
        if "multipleOf" in schema and (value / schema["multipleOf"]) != int(value / schema["multipleOf"]):
            problems.append(f"{at}: {value} is not a multiple of {schema['multipleOf']}")

    def object(self, value, schema, base, at, problems):
        for key in schema.get("required", []):
            if key not in value:
                problems.append(f"{at}.{key}: is required")
        for key, needed in schema.get("dependentRequired", {}).items():
            if key in value:
                for other in needed:
                    if other not in value:
                        problems.append(f"{at}.{other}: is required with {key}")
        if "minProperties" in schema and len(value) < schema["minProperties"]:
            problems.append(f"{at}: has fewer than {schema['minProperties']} members")
        if "maxProperties" in schema and len(value) > schema["maxProperties"]:
            problems.append(f"{at}: has more than {schema['maxProperties']} members")
        properties = schema.get("properties", {})
        patterns = schema.get("patternProperties", {})
        for key, item in value.items():
            where = f"{at}.{key}"
            if "propertyNames" in schema:
                for p in self.sub(key, schema["propertyNames"], base, where):
                    problems.append(f"{where}: the name {p.split(': ', 1)[-1]}")
            matched = False
            if key in properties:
                matched = True
                self.validate(item, properties[key], base, where, problems)
            for p, sub in patterns.items():
                if self.pattern(p).search(key):
                    matched = True
                    self.validate(item, sub, base, where, problems)
            if not matched and "additionalProperties" in schema:
                extra = schema["additionalProperties"]
                if extra is False:
                    problems.append(f"{where}: is not a member the schema allows")
                else:
                    self.validate(item, extra, base, where, problems)

    def array(self, value, schema, base, at, problems):
        if "minItems" in schema and len(value) < schema["minItems"]:
            problems.append(f"{at}: has fewer than {schema['minItems']} items")
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            problems.append(f"{at}: has more than {schema['maxItems']} items")
        if schema.get("uniqueItems"):
            seen = [canonical(v) for v in value]
            if len(set(seen)) != len(seen):
                problems.append(f"{at}: repeats an item")
        prefix = schema.get("prefixItems", [])
        for i, item in enumerate(value):
            if i < len(prefix):
                self.validate(item, prefix[i], base, f"{at}[{i}]", problems)
            elif "items" in schema:
                self.validate(item, schema["items"], base, f"{at}[{i}]", problems)
        if "contains" in schema:
            n = sum(1 for item in value if not self.sub(item, schema["contains"], base, at))
            low, high = schema.get("minContains", 1), schema.get("maxContains")
            if n < low or (high is not None and n > high):
                problems.append(f"{at}: holds {n} items matching contains, not between {low} and {high or 'any'}")


def kind(value):
    for name in ("boolean", "integer", "number", "string", "array", "object", "null"):
        if TYPES[name](value):
            return "an integer" if name == "integer" else ("an " if name[0] in "aeiou" else "a ") + name
    return type(value).__name__


def short(value):
    text = json.dumps(value, sort_keys=True)
    return text if len(text) <= 80 else text[:77] + "..."


def load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as e:
        raise InputError(f"{path}: {e}")


def main(argv):
    args, files = {}, []
    it = iter(argv)
    for a in it:
        if a in ("--schemas", "--schema"):
            args[a] = next(it, None)
        else:
            files.append(a)
    if not args.get("--schemas") or not args.get("--schema") or not files:
        print(__doc__.split("\n\n")[1], file=sys.stderr)
        return 2
    try:
        schemas = Schemas(args["--schemas"])
        bad = 0
        for f in files:
            problems = schemas.check(load_json(f), args["--schema"])
            if problems:
                bad = 1
                print(f"invalid: {f} against {args['--schema']}:")
                for p in problems:
                    print(f"  {p}")
            else:
                print(f"valid: {f} against {args['--schema']}")
        return bad
    except InputError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
