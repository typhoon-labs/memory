#!/bin/sh
# conformance-trigger's wait: polls until the image's conformance
# attestation verifies with the conformance key's public key, or the bound
# runs out. A failed run is never attested, so a run that fails shows here
# as the bound running out: "not attested", which is not "failed".
#
# Usage: sh wait.sh <image by digest> <public key file> <bound in seconds> [pipeline URL]
# CONFORMANCE_POLL_SECONDS (default 30) is the wait between two tries;
# CONFORMANCE_PLAIN_HTTP "true" lets cosign read a plain-HTTP registry.
#
# Exit status: 0 attested, 2 an input is missing or malformed, 3 not
# attested within the bound.
set -u
image="${1:-}" key="${2:-}" bound="${3:-}" url="${4:-}"
type=urn:agentic-platform:attestation:conformance:v1
poll="${CONFORMANCE_POLL_SECONDS:-30}"
http=""
if [ "${CONFORMANCE_PLAIN_HTTP:-}" = true ]; then http="--allow-http-registry"; fi
case "$image" in
  *@sha256:*) ;;
  *) echo "error: the image $image is not by digest" >&2; exit 2 ;;
esac
[ -s "$key" ] || { echo "error: no conformance public key at $key" >&2; exit 2; }
case "$bound" in ''|*[!0-9]*) echo "error: the bound $bound is not a number of seconds" >&2; exit 2 ;; esac
case "$poll" in ''|*[!0-9]*|0) echo "error: CONFORMANCE_POLL_SECONDS $poll is not a positive number" >&2; exit 2 ;; esac
work="${HOME:-/tmp}"
start="$(date +%s)"
tries=0
while :; do
  tries=$((tries + 1))
  if cosign verify-attestation --key "$key" --insecure-ignore-tlog $http --type "$type" "$image" > "$work/verified.json" 2> "$work/verify.err"; then
    echo "attested: $image has a conformance attestation by the conformance key ($type), after $(( $(date +%s) - start ))s and $tries tries"
    exit 0
  fi
  waited=$(( $(date +%s) - start ))
  if [ "$waited" -ge "$bound" ]; then
    echo "error: not attested: no conformance attestation by the conformance key on $image after ${waited}s, the bound. This is not a failed run: infra/conformance attests only a passing run, so its pipeline says why${url:+: $url}. cosign's last answer: $(tail -1 "$work/verify.err")" >&2
    exit 3
  fi
  left=$((bound - waited))
  if [ "$left" -lt "$poll" ]; then sleep "$left"; else sleep "$poll"; fi
done
