# `conformance-trigger`

A release's integration conformance (D38, T17): once the release is signed, it starts `infra/conformance`'s pipeline for the image's digest with that project's pipeline trigger token, and then waits, within a bound, until the image's conformance attestation verifies with the conformance key. From 1.1.0. The umbrella, [`workload`](../workload/README.md), includes it for a container workload when its `conformance-trigger` input is on; a workload may include it directly:

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/conformance-trigger@1
    inputs:
      needs: [build:publish, sign:image]
```

The inputs, with their defaults, are in [template.yml](template.yml).

## Jobs

| Job | Image | Does |
| --- | --- | --- |
| `conformance-trigger:start` | Python 3.14.10 | Checks the digest, the image by that digest and the conformance public key, then `POST <api>/projects/<infra/conformance>/trigger/pipeline` with `ref` (`main`), the token and `inputs[project_id]` (this project's) and `inputs[digest]`, and nothing else ([`trigger.py`](trigger.py)); records the pipeline it started and hands on its URL and the image as a dotenv report |
| `conformance-trigger:wait` | cosign v3.1.4 (dev) | Every `poll` seconds, `cosign verify-attestation --type urn:agentic-platform:attestation:conformance:v1` on the image with the conformance key's public key, until it verifies or `bound` seconds have passed ([`wait.sh`](wait.sh)) |

Both run on a release only (`release-if`), and after `needs`, which must hold the release's own signature and attestations: `infra/conformance` adds its attestation to the same digest, and without a referrers API the registry keeps a digest's bundles in one index, tagged `sha256-<hex>`, which each write rewrites.

## The token

`AGENTIC_CONFORMANCE_TRIGGER_TOKEN` is `infra/conformance`'s pipeline trigger token, a protected, masked CI/CD variable where release pipelines read it. A pipeline it starts runs as the token's owner, on `infra/conformance`'s protected `main`, whoever holds the token, so the release's developer needs no rights there ([B6 desk check](../../../../architecture/research/2026-11-18-b6-desk-check.md#the-conformance-attestation-and-its-trigger-t17)). The token goes in the request's body, never in its URL, and is never printed; GitLab's answer is printed with it masked. Without it the job fails at once, saying which variable to set, and sends nothing. The trigger passes inputs alone: `infra/conformance` refuses every pipeline variable and reads the level it tests from the image, never from its caller.

## The wait, and what a timeout means

A CI job token cannot read another project's pipeline: of the Pipelines API it may call only `PUT /projects/:id/pipelines/:pipeline_id/metadata` ([CI/CD job token](https://docs.gitlab.com/ci/jobs/ci_job_token/), `doc/ci/jobs/ci_job_token.md` at `gitlab-org/gitlab` `8c69061980`, read 2026-11-18), and a trigger token only creates one. So the release waits for what a passing run leaves, its conformance attestation, verified with the conformance key's public key, `alias/platform/conformance-signing` as PEM.

**The bound** is `bound`, 1800 seconds by default, at most 3300, under the wait job's hour. `infra/conformance` attests only a passing run, so a run that fails, or never starts, shows here as the bound running out: the job fails with **"not attested"**, exit status 3, which is not "failed". `infra/conformance`'s pipeline, whose URL the job prints, says why. A release left not attested is refused at admission outside the conformance pool, and a later run of `infra/conformance` on the same digest attests it without a new release.

**The key is the conformance key's alone:** a conformance attestation signed with the release key or any workload's key does not verify with it, so the wait never ends on one (TM13); the tests show it.

## Values per environment

`project`, `trigger-token`, `public-key`, `registry-plain-http`, `role-arn`, `aws-endpoint-url` and `aws-region` default to the group CI/CD variables `AGENTIC_CONFORMANCE_PROJECT`, `AGENTIC_CONFORMANCE_TRIGGER_TOKEN`, `AGENTIC_CONFORMANCE_PUBLIC_KEY`, `AGENTIC_REGISTRY_PLAIN_HTTP`, `AGENTIC_RELEASE_ROLE_ARN`, `AGENTIC_AWS_ENDPOINT_URL` and `AGENTIC_AWS_REGION`. The wait reads the registry as the release role, through its GitLab ID token, with `AWS_ENDPOINT_URL` and `AWS_ENDPOINT_URL_STS`, for cosign's ECR credential helper in dev; floci answers reads without credentials.

## Tests

[`tests/conformance-trigger/test_trigger.py`](../../tests/conformance-trigger/test_trigger.py) runs `trigger.py` against [a stand-in](../../tests/conformance-trigger/standin.py) of GitLab's trigger endpoint as `infra/conformance` answers it, which refuses a wrong token, a token in the URL, any variable, another ref and any input but the two, each beside the accepted twin. The trigger sends exactly `ref`, `token`, `inputs[project_id]` and `inputs[digest]`; an unset token, a malformed digest and a project ID that is not a number are refused before any request; a refused token fails without being printed. On protected main the component runs on the fixture app's release, after `sign:attest` has attested it with the pipeline's throwaway stand-in for the conformance key: `conformance-trigger:start` against the stand-in, started in its job, then `conformance-trigger:wait`, which must find the attestation; `test:conformance-trigger:not-attested` runs the same wait with the release stand-in's key and a short bound, which must end "not attested", exit status 3. On every pipeline, `test:conformance-trigger:no-token` runs the embedded `trigger.py`, as the start job writes it, with the token unset against the stand-in: it must fail saying which variable to set, and the stand-in must have received nothing.
