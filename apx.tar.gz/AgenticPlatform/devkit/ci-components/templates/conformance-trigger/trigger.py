"""conformance-trigger's trigger: starts infra/conformance's pipeline for one
image digest with a pipeline trigger token (T17), passing the two inputs
its pipeline takes and nothing else.

Usage:
  python3 -I trigger.py --api <GitLab API v4 URL> --project <infra/conformance's ID>
      --ref <ref> --workload-project <the caller's project ID> --digest sha256:<hex>
      [--out <pipeline.json>] [--dotenv <file>]

The token comes from the environment, CONFORMANCE_TRIGGER_TOKEN, never an
argument, and is sent in the request's body, never in its URL, and never
printed. The request carries ref, token, inputs[project_id] and
inputs[digest] alone: infra/conformance refuses every pipeline variable
(ci_pipeline_variables_minimum_override_role no_one_allowed) and reads the
level it tests from the image, never from its caller.

Exit status: 0 the pipeline was created, 1 GitLab refused the trigger or
could not be reached, 2 an input is missing or malformed, before any
request is sent.
"""

import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")
ID = re.compile(r"^[1-9][0-9]*$")


class InputError(Exception):
    """An input the trigger cannot use: exit status 2."""


def unset(value):
    return value is None or value == "" or value.startswith("$")


def request_body(token, ref, workload_project, digest):
    return urllib.parse.urlencode([("token", token), ("ref", ref),
                                   ("inputs[project_id]", workload_project), ("inputs[digest]", digest)]).encode()


def trigger(api, project, ref, workload_project, digest, token, timeout=30):
    """The created pipeline, as GitLab answers it."""
    if unset(token):
        raise InputError("AGENTIC_CONFORMANCE_TRIGGER_TOKEN is not set: the workloads/ group (or this project) needs "
                         "infra/conformance's pipeline trigger token as a protected, masked CI/CD variable, so that a "
                         "release can start its conformance run")
    if unset(api) or not api.startswith(("https://", "http://")):
        raise InputError(f"the API URL {api!r} is not an http(s) URL")
    if unset(project) or not ID.match(project):
        raise InputError(f"infra/conformance's project ID {project!r} is not a number: set AGENTIC_CONFORMANCE_PROJECT")
    if unset(workload_project) or not ID.match(workload_project):
        raise InputError(f"the workload's project ID {workload_project!r} is not a number")
    if unset(digest) or not DIGEST.match(digest):
        raise InputError(f"the digest {digest!r} is not sha256:<64 hex>: the release's image, by digest, from build:publish")
    if unset(ref):
        raise InputError("no ref to run infra/conformance's pipeline on")
    url = f"{api.rstrip('/')}/projects/{project}/trigger/pipeline"
    req = urllib.request.Request(url, data=request_body(token, ref, workload_project, digest), method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read()
    except urllib.error.HTTPError as e:
        detail = e.read()[:2000].decode("utf-8", "replace").replace(token, "[MASKED]")
        raise TriggerError(f"GitLab refused the trigger of project {project}: HTTP {e.code}: {detail}")
    except (urllib.error.URLError, OSError) as e:
        raise TriggerError(f"could not reach {url}: {e}")
    try:
        pipeline = json.loads(body)
    except ValueError:
        raise TriggerError(f"GitLab's answer is not JSON: {body[:200]!r}")
    if not isinstance(pipeline, dict) or not isinstance(pipeline.get("id"), int):
        raise TriggerError(f"GitLab's answer names no pipeline: {json.dumps(pipeline)[:300]}")
    return pipeline


class TriggerError(Exception):
    """GitLab refused the trigger or could not be reached: exit status 1."""


def main(argv, env):
    args = {}
    it = iter(argv)
    for a in it:
        if not a.startswith("--"):
            raise InputError(f"unexpected argument {a}")
        args[a[2:]] = next(it, None)
    pipeline = trigger(args.get("api"), args.get("project"), args.get("ref"), args.get("workload-project"),
                       args.get("digest"), env.get("CONFORMANCE_TRIGGER_TOKEN"))
    url = pipeline.get("web_url", "")
    print(f"infra/conformance's pipeline {pipeline['id']} started for {args['digest']} of project "
          f"{args['workload-project']}: {url}")
    if args.get("out"):
        with open(args["out"], "w") as f:
            json.dump({k: pipeline.get(k) for k in ("id", "iid", "project_id", "ref", "sha", "status", "source", "web_url")},
                      f, indent=2, sort_keys=True)
    if args.get("dotenv"):
        with open(args["dotenv"], "w") as f:
            f.write(f"CONFORMANCE_PIPELINE_ID={pipeline['id']}\nCONFORMANCE_PIPELINE_URL={url}\n")
    return 0


if __name__ == "__main__":
    import os
    try:
        sys.exit(main(sys.argv[1:], os.environ))
    except InputError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)
    except TriggerError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)
