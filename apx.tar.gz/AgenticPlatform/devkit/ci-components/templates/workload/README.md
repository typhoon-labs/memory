# `workload`

The umbrella a workload's `.gitlab-ci.yml` includes, in one line ([Repositories](../../../../architecture/design/repositories.md#the-developer-workflow)). By `runtime`, as the workload's `workload.yaml` gives it:

| Runtime | Merge request | Release (`release-if`, a protected tag) |
| --- | --- | --- |
| `container` | [`build`](../build/README.md) to the project's GitLab registry, then the contract stage, the `conformance` component, on `WORKLOAD_IMAGE` | `build` to ECR, then [`sign`](../sign/README.md): signature, SBOMs, provenance; with `conformance-trigger` on, then [`conformance-trigger`](../conformance-trigger/README.md): `infra/conformance`'s run on the image's digest, and the wait for its conformance attestation |
| `kagent` | [`kagent-package`](../kagent-package/README.md): the check and the skills' builds | `kagent-package` publishes the skills and the packaged definition to ECR, then `sign` on every skill and the definition |

A workflow pipeline includes [`step`](../step/README.md) once per bounded model step instead.

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/workload@1
    inputs:
      repository: <the workload's ECR repository>
      conformance-protocol: mcp
```

The inputs, with their defaults, are in [template.yml](template.yml). The parts come from this project at the umbrella's own commit, through `include:local`, which inside a component resolves against the component's project, not the consumer's (checked on 2026-11-17, B5's results). Each part keeps its own defaults for whatever the umbrella does not pass on; a workload that needs another of a part's inputs includes that part directly instead of the umbrella.

## The seam with the contract stage

`build:publish` exports `WORKLOAD_IMAGE` (the image by digest), `WORKLOAD_IMAGE_DIGEST` and `WORKLOAD_IMAGE_TAG` as a dotenv report. The `conformance` component, `templates/conformance/template.yml`, owned by the suites' stream, reads them through `needs: [build:publish]`; the umbrella passes it `stage`, `profile`, `protocol`, `scratch-repository`, `runner-image` and `database` (`none` or `postgres`). `scratch-repository` defaults to `$WORKLOAD_SCRATCH_REPOSITORY`, which `build:publish` exports: `ci-scratch/` and `repository` with its slashes as hyphens, as the registration creates it, since an input cannot replace characters, and the variable expands only where the job's variables do; and includes it only for a container workload with `conformance` on. `conformance` is on by default; `conformance-protocol` defaults to empty, so the component takes the protocol from `workload.yaml`'s kind; and `conformance-runner-image`, empty by default, is passed on only when set, through a second include of the component under the opposite rule, so the component's own pinned contract image applies otherwise.

## The release's integration conformance

From 1.1.0, with `conformance-trigger` on, a container workload's release starts `infra/conformance`'s pipeline for its image's digest once `sign:image` has written the release's own signature and attestations, and waits, at most `conformance-bound` seconds, until the image's conformance attestation verifies with the conformance key ([`conformance-trigger`](../conformance-trigger/README.md)). It is **on by default from 1.1.0**: it needs `infra/conformance`, its trigger token and the group variables `AGENTIC_CONFORMANCE_PROJECT`, `AGENTIC_CONFORMANCE_TRIGGER_TOKEN` and `AGENTIC_CONFORMANCE_PUBLIC_KEY`, which exist on `workloads/` from B6, and a workload opts out with `conformance-trigger: false`. Builds before the 1.1.0 release had it off, so that a release on 1.0 did not fail before they existed. A kagent agent's release does not trigger it: kagent agents are not deployed by `infra/conformance`.

## The deploy request

From 1.1.0 a release ends with [`deploy-request`](../deploy-request/README.md), for a container workload and a kagent agent alike: it prints the `agentctl deploy request` command with the release's image or packaged definition by digest, for the developer to run with their own GitLab token, and writes it to `out/deploy-request/command.txt`. It needs the group variable `AGENTIC_ENVIRONMENT` (`local` locally), or the `environment` input, and fails saying so without it; `deploy-request: false` leaves it out.

## Stages

`build-stage` (`build`), `test-stage` (`test`) and `sign-stage` (`deploy`) default to stages GitLab defines in every pipeline, so a workload's `.gitlab-ci.yml` needs no `stages:`. The jobs order themselves by `needs`.

## Tests

`tests/components.gitlab-ci.yml` starts [a child pipeline](../../tests/workload/pipeline.yml) that includes the umbrella at the parent's commit as a container workload, with the contract stage off and a stub in its place that checks `WORKLOAD_IMAGE` against the registry. The parts themselves, sign and the kagent runtime among them, are tested directly in the parent pipeline.
