# `library-release`

Releases one library artifact, a skill, prompt, workflow definition or plugin, from its tag, `<kind>/<name>/vX.Y.Z` ([Release tags](../../../../architecture/design/distribution.md#release-tags)): the library's `library.yaml` and every `artifact.yaml` are checked against `agent-sdk`'s spec, the artifact's directory is built as an image from scratch for amd64 and arm64, pushed with ORAS 1.4.0 to `library/<kind>/<name>:vX.Y.Z`, and signed and attested as [`sign`](../sign/README.md) does, with the release key. A merge request's pipeline checks the whole library and builds nothing. From 1.1.0. A library's `.gitlab-ci.yml`, at its root:

```yaml
workflow:
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
    - if: $CI_COMMIT_TAG && $CI_COMMIT_REF_PROTECTED == "true"

include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/library-release@1
```

The inputs, with their defaults, are in [template.yml](template.yml).

## The library

```text
<library>/
├── library.yaml          # owner, tier and, for a team's library, its prefix
├── skills/<name>/        # SKILL.md, artifact.yaml and the skill's files
├── prompts/<name>/       # artifact.yaml and the prompt's files
├── workflows/<name>/
└── plugins/<name>/
```

Each directory under a kind's directory is one artifact, and holds its `artifact.yaml`.

## Jobs

| Job | When | Image | Does |
| --- | --- | --- | --- |
| `library-release:render` | Always | yq 4.54.3 | `library.yaml` and each `artifact.yaml` to JSON; refuses a file of more than one document, and an unquoted date, which YAML 1.1 readers take for a timestamp, as `agentctl validate` does. On a release, the released copy of the tag's `artifact.yaml`, its `provenance` filled with the project's URL, the commit and the pipeline's ID |
| `library-release:check` | Always | Python 3.14.10 | The check below, embedded ([`checker/check.py`](checker/check.py), through `checker.yml`), against the spec [`templates/spec/`](../spec/README.md) vendors. Hands the release's kind, name, version and directory on as a dotenv report |
| `library-release:build` | Release | BuildKit 0.35.0, rootless | The artifact's directory, its `artifact.yaml` the released copy, as an image `FROM scratch` with the files at its root, for `linux/amd64` and `linux/arm64`, reproducible: the commit's time and modes 644 or 755 on every file; a link or special file is refused |
| `library-release:oras` | Release | ORAS 1.4.0 | ORAS for the publish job |
| `library-release:publish` | Release | AWS CLI 2.40.3 | As `role-arn`, through the job's GitLab ID token, with `AWS_ENDPOINT_URL` and `AWS_ENDPOINT_URL_STS`: pushes the index by digest to `<registry-host>/<repository-prefix>/<kind>/<name>:v<version>`, once, since a tag never moves; writes sign's record and `LIBRARY_ARTIFACT` (by digest) as a dotenv report |
| `sign:sbom`, `sign:image` | Release | sign's | An SPDX SBOM per platform, the signature, the SBOMs and SLSA provenance attested on the index digest, all verified; the provenance's build type is `urn:agentic-platform:ci-components:library-release@<this component's commit>` |

The check refuses, each with its reason: `library.yaml` or an `artifact.yaml` that breaks its schema; an artifact under another kind's directory, or under a directory not its name; two artifacts of one name, since the catalog keeps names unique across kinds and tiers; in a team's library, a name without its prefix; a committed `provenance`, which CI fills; a skill without `SKILL.md`; and on a release, a tag not `<kind>/<name>/vX.Y.Z`, a tag naming no artifact, a version other than `artifact.yaml`'s, and a released copy invalid, with provenance not this pipeline's, or differing in anything else. A release whose check fails stops there: nothing is built, pushed or signed.

## The artifact

What `agentctl install` fetches by digest and unpacks, and what a kagent agent binds when the artifact is a skill (D28):

- **An OCI image index** of two image manifests, `linux/amd64` and `linux/arm64`, each with one `application/vnd.oci.image.layer.v1.tar+gzip` layer: the artifact directory's files at the layer's root, `SKILL.md` at `/` for a skill. The same files on both platforms: kagent mounts a skill only from an image built from scratch, not from an ORAS artifact's layout, and Substrate pulls the node's platform.
- **`artifact.yaml` in the layer, with its provenance filled,** so a released artifact names where it was built. The provenance carries the pipeline's ID, so a version is released once: a new pipeline for a tag already pushed finds the tag holding another digest and fails, since tags never move.
- **Tagged `v<version>`,** the tag's last part, since an OCI tag cannot hold `/`; every consumer pins the digest, which the catalog index records.
- **Signed with the release key:** the signature, an SPDX SBOM per platform, which for files alone lists no package, and the provenance, whose `resolvedDependencies[0].digest.gitCommit` is the tag's commit.

## Values per environment

`registry-host`, `registry-plain-http`, `role-arn`, `signing-key`, `aws-endpoint-url` and `aws-region` default to the group CI/CD variables `AGENTIC_REGISTRY_HOST`, `AGENTIC_REGISTRY_PLAIN_HTTP`, `AGENTIC_LIBRARY_RELEASE_ROLE_ARN` (the role `ci-library-release`, which the library's registration trusts), `AGENTIC_SIGNING_KEY`, `AGENTIC_AWS_ENDPOINT_URL` and `AGENTIC_AWS_REGION`. A publishing or signing job with one of them empty fails before it pushes or signs. The library's ECR repositories, `library/<kind>/<name>`, come from its registration in `aws-foundation`.

## Tests

[`tests/library-release/test_check.py`](../../tests/library-release/test_check.py) runs the check against the fixture library under [`tests/library-release/fixture/`](../../tests/library-release/fixture/library.yaml), which it accepts, on its own and as the release of its skill or its prompt, and makes each refusal by one change, refused for that reason alone beside its accepted twin; `embed.py --check` fails when `checker.yml` is stale. The component itself runs in two child pipelines of ci-components' own, since its sign jobs take the names the parent's tests of sign use ([`tests/library-release/pipeline.yml`](../../tests/library-release/pipeline.yml)):

- **The fixture's skill,** `skill/ci-test-conventions/v0.1.0`: in a merge request, rendered, checked and built, and the image's layout checked ([`check_layout.py`](../../tests/library-release/check_layout.py): two platforms, one gzip layer each, exactly the directory's files, `artifact.yaml` with this pipeline's provenance). On protected main it is also pushed to the pipeline's own repository, `ci-components-test/library-p<pipeline>/skill/ci-test-conventions`, and signed with the pipeline's throwaway key, under a dead proxy for everything but floci; [`verify.sh`](../../tests/library-release/verify.sh) checks the signature, two SBOM attestations and the provenance naming the commit with the key, and refuses another key.
- **A refused library,** [`tests/library-release/refused/`](../../tests/library-release/refused/library.yaml), whose skill's `artifact.yaml` breaks the schema: its child pipeline fails at the check, as expected, and on main the parent checks that the skill's repository holds no image.
