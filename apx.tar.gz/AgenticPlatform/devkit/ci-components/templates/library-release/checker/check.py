"""library-release's check: a library's library.yaml and every artifact's
artifact.yaml, and on a release the artifact its tag names, before
anything is built or pushed.

Usage:
  python3 -I check.py --validator <validate.py> --schemas <spec dir or bundle>
      --root <library dir> --json <rendered JSON dir>
      [--release-tag <kind>/<name>/vX.Y.Z --released <filled artifact.json>
       --project-url <url> --commit <sha> --pipeline-id <id>] [--out <release.env>]

The library's YAML files are rendered to JSON first (yq), at the same
paths under --json: library.json, and <kind>s/<name>/artifact.json for each
artifact directory. --root is the library itself, whose files the check
reads. On a release, --released is the artifact.yaml the image will carry,
rendered, with provenance filled by CI. It is refused, with every reason
listed, when:

  library-schema   library.yaml breaks spec/schemas/library.schema.json
  schema           an artifact.yaml breaks spec/schemas/artifact.schema.json
  kind-dir         an artifact's kind is not its directory's: skills/ holds
                   skills, prompts/ prompts, workflows/ workflows, plugins/
                   plugins
  name-dir         an artifact's name is not its directory's name
  name-twice       two artifacts share a name, which the catalog keeps
                   unique across every kind and tier
  prefix           in a team's library, a name without <prefix>-
  provenance       a committed artifact.yaml has provenance, which CI fills
  skill-file       a skill without SKILL.md
  tag-form         the release tag is not <kind>/<name>/vX.Y.Z
  tag-artifact     the release tag names no artifact of the library
  tag-version      the tag's version is not artifact.yaml's
  released         the released artifact.yaml breaks the schema, or its
                   provenance is not this pipeline's, or it differs from the
                   committed one in anything but provenance

Exit status: 0 accepted, 1 refused, 2 usage or input error.
"""

import importlib.util
import json
import os
import re
import sys

KINDS = {"skill": "skills", "prompt": "prompts", "workflow": "workflows", "plugin": "plugins"}
TAG = re.compile(r"^(skill|prompt|workflow|plugin)/([a-z0-9]+(?:-[a-z0-9]+)*)/v([0-9][0-9A-Za-z.+-]*)$")


class InputError(Exception):
    """A file or argument the check cannot use: exit status 2."""


def load_validator(path):
    spec = importlib.util.spec_from_file_location("validate", path)
    if spec is None or spec.loader is None:
        raise InputError(f"no validator at {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as e:
        raise InputError(f"{path}: {e}")


def artifacts(json_dir):
    """(kind directory, name, rendered path) of each artifact, sorted."""
    out = []
    for kind_dir in sorted(KINDS.values()):
        base = os.path.join(json_dir, kind_dir)
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            path = os.path.join(base, name, "artifact.json")
            if os.path.isfile(path):
                out.append((kind_dir, name, path))
    return out


def check(schemas, root, json_dir, release=None):
    """Problems as (reason, where, message), and the released artifact as
    (kind, name, version, directory) or None."""
    problems = []
    library_path = os.path.join(json_dir, "library.json")
    if not os.path.isfile(library_path):
        raise InputError(f"no library.yaml rendered at {library_path}")
    library = load_json(library_path)
    for p in schemas.check(library, "schemas/library.schema.json"):
        problems.append(("library-schema", "library.yaml", p))
    prefix = library.get("prefix") if isinstance(library, dict) and library.get("tier") == "team" else None
    seen = {}
    found = {}
    for kind_dir, dir_name, path in artifacts(json_dir):
        where = f"{kind_dir}/{dir_name}/artifact.yaml"
        a = load_json(path)
        for p in schemas.check(a, "schemas/artifact.schema.json"):
            problems.append(("schema", where, p))
        if not isinstance(a, dict):
            continue
        kind, name = a.get("kind"), a.get("name")
        if kind in KINDS and KINDS[kind] != kind_dir:
            problems.append(("kind-dir", where, f"is a {kind}, which belongs under {KINDS[kind]}/, not {kind_dir}/"))
        if isinstance(name, str):
            if name != dir_name:
                problems.append(("name-dir", where, f"names {name}, but its directory is {dir_name}"))
            if name in seen:
                problems.append(("name-twice", where, f"names {name}, as {seen[name]} does"))
            seen.setdefault(name, where)
            if prefix and not name.startswith(prefix + "-"):
                problems.append(("prefix", where, f"names {name}, which in this team's library must start with {prefix}-"))
        if "provenance" in a:
            problems.append(("provenance", where, "has provenance, which CI fills on release; remove it"))
        if kind == "skill" and not os.path.isfile(os.path.join(root, kind_dir, dir_name, "SKILL.md")):
            problems.append(("skill-file", where, "is a skill without SKILL.md beside it"))
        found[(kind_dir, dir_name)] = a
    released = None
    if release is not None:
        tag = release["tag"]
        m = TAG.match(tag)
        if not m:
            problems.append(("tag-form", tag, "is not <kind>/<name>/vX.Y.Z, kind one of " + ", ".join(KINDS)))
        else:
            kind, name, version = m.groups()
            a = found.get((KINDS[kind], name))
            where = f"{KINDS[kind]}/{name}/artifact.yaml"
            if a is None:
                problems.append(("tag-artifact", tag, f"names {where}, which the library does not have"))
            else:
                if a.get("version") != version:
                    problems.append(("tag-version", tag, f"is version {version}, but {where} says {a.get('version')}"))
                filled = load_json(release["released"])
                for p in schemas.check(filled, "schemas/artifact.schema.json"):
                    problems.append(("released", where, p))
                want = {"repository": release["project_url"], "commit": release["commit"],
                        "pipeline_id": release["pipeline_id"]}
                if not isinstance(filled, dict) or filled.get("provenance") != want:
                    problems.append(("released", where, f"carries provenance {json.dumps(filled.get('provenance') if isinstance(filled, dict) else None)}, not this pipeline's {json.dumps(want)}"))
                elif {k: v for k, v in filled.items() if k != "provenance"} != a:
                    problems.append(("released", where, "differs from the committed artifact.yaml in more than its provenance"))
                released = (kind, name, version, f"{KINDS[kind]}/{name}")
    return problems, released


def main(argv):
    args = {}
    it = iter(argv)
    for a in it:
        if not a.startswith("--"):
            raise InputError(f"unexpected argument {a}")
        args[a[2:]] = next(it, None)
    for need in ("validator", "schemas", "root", "json"):
        if not args.get(need):
            raise InputError(f"--{need} is required\n\n{__doc__.split(chr(10) + chr(10))[1]}")
    validate = load_validator(args["validator"])
    try:
        schemas = validate.Schemas(args["schemas"])
    except validate.InputError as e:
        raise InputError(str(e))
    release = None
    if args.get("release-tag"):
        for need in ("released", "project-url", "commit", "pipeline-id"):
            if not args.get(need):
                raise InputError(f"--{need} is required with --release-tag")
        try:
            pipeline_id = int(args["pipeline-id"])
        except ValueError:
            raise InputError(f"--pipeline-id {args['pipeline-id']} is not a number")
        release = {"tag": args["release-tag"], "released": args["released"], "project_url": args["project-url"],
                   "commit": args["commit"], "pipeline_id": pipeline_id}
    try:
        problems, released = check(schemas, args["root"], args["json"], release)
    except validate.InputError as e:
        raise InputError(str(e))
    n = len(artifacts(args["json"]))
    if problems:
        for reason, where, message in problems:
            print(f"refused [{reason}] {where}: {message}")
        print(f"refused: {len(problems)} problem(s) in the library's {n} artifact(s); nothing is built or pushed")
        return 1
    print(f"accepted: library.yaml and {n} artifact(s)")
    if released:
        kind, name, version, directory = released
        print(f"release: {kind} {name} {version} from {directory}/")
        if args.get("out"):
            with open(args["out"], "w") as f:
                f.write(f"LIBRARY_KIND={kind}\nLIBRARY_NAME={name}\nLIBRARY_VERSION={version}\nLIBRARY_DIR={directory}\n")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except InputError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(2)
