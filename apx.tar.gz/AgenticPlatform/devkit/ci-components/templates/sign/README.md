# `sign`

Signs a release with cosign v3.1.4 and a KMS key, the release key by default, never keyless, so nothing reaches a public log. In image mode it signs every image the release published, attests an SPDX SBOM per platform and SLSA v1 provenance on each image's index digest, and verifies all of it. In blob mode it signs files, such as `agentctl`'s binaries, as sigstore bundles. In attest mode, from 1.1.0, it signs one of the platform's own attestations on one digest, checked against `agent-sdk`'s schema first: the conformance attestation, which `infra/conformance` signs with the conformance key, or a release record. It runs only in a release pipeline (`release-if`, a protected tag by default). The umbrella component, `workload`, includes it in image mode.

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/sign@1
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/sign@1
    inputs:
      mode: blob
      needs: [build:binaries]
      blobs: dist/*
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/sign@1
    inputs:
      mode: attest
      needs: [conformance:predicate]
      subject: $CONFORMANCE_SUBJECT
      predicate: out/conformance/predicate.json
      predicate-type: conformance
      release-if: $CI_COMMIT_BRANCH == "main" && $CI_COMMIT_REF_PROTECTED == "true"
      key: awskms:///alias/platform/conformance-signing
      role-arn: arn:aws:iam::000000000000:role/ci-conformance
```

The inputs, with their defaults, are in [template.yml](template.yml). Each mode's jobs are in a file of their own, so a pipeline may include the component once per mode. From 1.1.0, image mode's jobs are named by `job-prefix`, `sign` by default, as `<prefix>:sbom` and `<prefix>:image`, so that a pipeline may include image mode twice, with two keys: `ci-components`' own pipeline signs the platform's images as `sign-platform`, beside its tests' `sign`.

## Jobs

| Job | Mode | Image | Does |
| --- | --- | --- | --- |
| `sign:sbom` | image | syft 1.57.2 (debug, for its shell) | One SPDX SBOM per platform of each image, from the OCI layout its build left, so no registry is read |
| `sign:image` | image | cosign v3.1.4 (dev, for its shell) | Per image, strictly in order: `cosign sign`, `cosign attest --type spdxjson` per SBOM, `cosign attest --type slsaprovenance1`, then `verify` and `verify-attestation` of both types with the key's public key and `--insecure-ignore-tlog` |
| `sign:blobs` | blob | cosign v3.1.4 (dev) | Per file, `cosign sign-blob --bundle` and `cosign verify-blob`; the bundles go to `out/sign/blobs/<file name>.sigstore.json` |
| `sign:predicate` | attest | Python 3.14.10 | Resolves the subject, by digest; for a conformance attestation fills the predicate's `component`; checks the predicate against the spec's schema for its type (`templates/spec/`), and refuses to go on if it breaks it |
| `sign:attest` | attest | cosign v3.1.4 (dev) | `cosign attest --type <the type's URN>` on the subject with the key, then `verify-attestation` with its public key, which goes to `out/sign/attest/key.pub` |

What is signed comes from the records the publishing jobs write to `out/publish/<name>.env`: `PUBLISHED_NAME`, `PUBLISHED_REF` (by digest), `PUBLISHED_TAG`, and `PUBLISHED_LAYOUT` and `PUBLISHED_PLATFORMS` for an image built in the pipeline. `build` writes one for the workload's image, `kagent-package` one per skill and one for the packaged definition. The `needs` input names the jobs that hold them; its default covers both components.

## How it signs

- **The key** is `awskms:///<alias or key ID>`, with the endpoint in `aws-endpoint-url`, never in the URI: sigstore's AWS client would make it `https://`, and floci speaks plain HTTP.
- **As the role** in `role-arn`, through the job's GitLab ID token. cosign's AWS SDK takes the web identity's STS endpoint from `AWS_ENDPOINT_URL_STS` alone, so the job sets it beside `AWS_ENDPOINT_URL`; without it the token would go to AWS's own STS.
- **No transparency log and no timestamp authority:** every sign and attest passes a signing config from `cosign signing-config create`, which names no service. cosign v3 refuses `--tlog-upload=false` alone.
- **One digest, one writer at a time:** without a referrers API the registry keeps cosign's bundles in an index tagged `sha256-<hex>`, which each write rewrites, so the job never signs and attests in parallel. On floci the repository must be `MUTABLE` for that tag to move.
- **The provenance** names the project, the ref, the commit, the pipeline and the runner; its build type is `urn:agentic-platform:ci-components:build@<this component's commit>`.
- **cosign runs as root** (`image:docker:user: "0"`): its image's own user, UID 65532, cannot write into the directories the runner extracts other jobs' artifacts into, owned by root (pipeline 3081756785). The job container is the runner's, as every other job image's root is.
- **Artifacts:** `out/sign/release.pub`, the public key the job verified with, each image's provenance and `cosign verify` output, and `out/sign/signed.txt`, the references signed.

## Attest mode

The platform's two attestations ([`spec/attestations/`](../../../agent-sdk/spec/attestations/README.md), from `spec/v0.3.0`), by `predicate-type`:

| `predicate-type` | Type cosign writes | Schema checked | Signed by, with |
| --- | --- | --- | --- |
| `conformance` | `urn:agentic-platform:attestation:conformance:v1` | `attestations/conformance.schema.json` | `infra/conformance`, `alias/platform/conformance-signing` as `ci-conformance` |
| `release-record` | `urn:agentic-platform:attestation:release-record:v1` | `attestations/release-record.schema.json` | `environments`' deploy job, `alias/platform/record-signing` (D37) |

- **Checked before it is signed:** the predicate is checked against the schema of `agent-sdk`'s spec at the commit `templates/spec/SOURCE` names, by a standard-library check embedded in the job ([`templates/spec/`](../spec/README.md)). So a run with a failed case (`failed` is always 0), a member the schema refuses, or a time Kyverno cannot read is never attested: the job fails and nothing is signed.
- **The component:** for a conformance attestation, `component` is this component as GitLab's component context gives it, `name` `sign`, its `sha` and `reference`, and `version` only when it was included by a released version, replacing whatever the file had, unless `fill-component` is false.
- **The key is the caller's:** attest mode signs with `key` and nothing else, and verifies with that key's public key. Whether a key is the right one for a type is the verifier's to say: admission accepts a conformance attestation by the conformance key alone, so one the release key signs is refused there (TM13); the tests show both.
- **Ordering:** the subject's earlier bundles (the release's signature, SBOMs and provenance) must be written before this job starts, since without a referrers API the registry keeps them in one index, tagged `sha256-<hex>`, which each write rewrites. `infra/conformance` runs after the release's pipeline; within one pipeline, `needs` orders them.
- **The subject** is `<registry.host>/<repository>@sha256:<hex>`; it may be a variable from a needed job's dotenv report, which `sign:predicate` resolves and hands on in a file.

## Values per environment

`key`, `role-arn`, `aws-endpoint-url`, `aws-region` and `allow-http-registry` default to the group CI/CD variables `AGENTIC_SIGNING_KEY`, `AGENTIC_RELEASE_ROLE_ARN`, `AGENTIC_AWS_ENDPOINT_URL`, `AGENTIC_AWS_REGION` and `AGENTIC_REGISTRY_PLAIN_HTTP`. A signing job with an empty key, role or region fails before it signs.

## Tests

On every pipeline, two jobs start the syft and cosign images as the runner starts them, cosign's as root, as `sign:image` and `sign:blobs` run it, writing beside what syft's left under `out/`: as its own user, 65532, it cannot write into the directories the runner extracts artifacts into. On protected main, `tests/components.gitlab-ci.yml` signs the fixture app's release and a file with a key made for the pipeline under `alias/ci-components-test/`, never the platform's release key, while a dead proxy stands for everything but floci, so any call to a public service would fail. [`tests/sign/refusals.sh`](../../tests/sign/refusals.sh) then checks that the signature and both attestation types verify with the key's public key, that another key, a type never attested and a changed file are refused, that there are two SBOM attestations, and that the provenance names the commit. The cleanup job deletes the alias, schedules the key's deletion and removes the repository.

Attest mode, on protected main: the pipeline's second throwaway key, `alias/ci-components-test/p<pipeline>-conformance`, stands in for the conformance key, and attests a conformance predicate ([`tests/sign/conformance.predicate.json`](../../tests/sign/conformance.predicate.json)) on the fixture app's release after `sign:image`. [`tests/sign/attest-refusals.sh`](../../tests/sign/attest-refusals.sh) then checks that it verifies with that key and names this commit as its component's `sha`, that the release stand-in's key finds no conformance attestation of its own there, and that a conformance attestation the release stand-in signs on the kagent fixture's skill is refused with the conformance stand-in's key while the release stand-in's shows it is there. On every pipeline, `test:spec:unit` runs the spec check's own tests and refuses a failed run's predicate through the embedded copy, beside the fixture's passing one.
