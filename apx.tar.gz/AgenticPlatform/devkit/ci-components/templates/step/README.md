# `step`

One bounded model step of a workflow pipeline ([Workflows](../../../../architecture/design/workflows.md#a-bounded-model-step)): a job that runs `agentctl step run` with the step's definition and input, as the client of the hosted-workloads gateway that [D27](../../../../architecture/plan/open-items.md#close-by-decision) provisionally names. Include it once per step; each include makes the job `step:<name>`.

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/step@1
    inputs:
      name: summarise-changes
      definition: steps/summarise-changes.step.json
      input: out/changes.json
      needs: [collect-changes]
      image: <agentctl's image, by digest>
```

The inputs, with their defaults, are in [template.yml](template.yml).

**Pending:** `agentctl` and its image (another stream builds them), and D27's credential: the realm's `gitlab` provider and a client per workflow project. Until both exist the job's contract is fixed and tested against a stub, and no step has run against the gateway.

## The contract

- **The command:** `agentctl step run --definition <file> --input <file> --output out/step/<name>/output.json [--workload <file>] [--step-command <command>]`, absolute paths, as agent-sdk's `spec/step/command.json` describes the step command agentctl starts.
- **The environment:** `AGENTIC_GATEWAY_URL` (the hosted-workloads gateway), `AGENTIC_TOKEN_COMMAND` (a JSON array; the step appends `--scope <scope>`), `AGENTIC_CA_FILE` when set, `AGENTIC_TASK_ID` (by default `gitlab-<project ID>-<pipeline ID>`, one task per pipeline, so a retried job replays a state-changing tool call instead of repeating it), `AGENTIC_WORKFLOW_NAME` and `AGENTIC_WORKFLOW_VERSION` (the release tag without its `v`, or the commit).
- **The credential (D27):** the job's GitLab ID token, for the audience `id-token-audience`, in a file only the job's user reads, named by `AGENTCTL_ID_TOKEN_FILE`, with the workflow project's Keycloak client in `AGENTCTL_CLIENT_ID`. The token leaves the environment before agentctl starts; the token command turns it into one access token per route. Neither is printed.
- **The exit status** is the step's, passed through: 0 the output is valid; 1 the step failed and stops the pipeline; 3 its limits stopped it, with the error of agent-sdk's `spec/limits/`; 4 it failed and goes to a person; 5 its definition, input, workload or environment was invalid and nothing was called; 2 agentctl could not start it. The job says which, and keeps `out/step/<name>/` whatever happened.

## Tests

`tests/components.gitlab-ci.yml` runs the component three times against [a stub of agentctl](../../tests/step/agentctl-stub.py), which checks the command line, the environment's values by the spec's patterns, and the ID token's file, mode and audience, then ends as its input asks: valid output, stopped by its limits (3), and routed to a person (4). `test:step:verify` checks each outcome and that no token reached a file.
