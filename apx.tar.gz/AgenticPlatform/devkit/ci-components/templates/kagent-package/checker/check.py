"""kagent-package's check: a kagent agent's definition, before it is packaged.

Usage:
  python3 -I check.py --definition <agent.json> --schemas <dir>
      [--listing <server>=<file.json>]... [--server <server>=<url>]...
      [--local-skill <name>]... [--system-prompt <file>] [--out <packaged.json>]

The definition is one kagent object, kind Agent (with an inline template) or
AgentTemplate, of api.kagent.dev/v1alpha3, as JSON. It is refused, with every
reason listed, when:

  schema            it breaks kagent 1.0.1's CRD schema for its kind: types,
                    required fields, patterns, lengths, list rules and the
                    CRD's CEL rules, and no field the schema does not name
  not-inline        an Agent's template is a reference, not inline
  subagent          a tool binding is a subagent, which this check cannot see into
  server-unlisted   a tool binding names an MCP server with no tools/list here
  tool-unlisted     a bound tool is not in its server's tools/list
  approval-required a destructive tool is bound without requireApproval (K3):
                    a tool is destructive unless its annotations say
                    readOnlyHint true or destructiveHint false, as MCP defines
                    the hints' defaults
  skill-source      a skill or plugin comes from git or a bucket, not an image (D28)
  skill-digest      a skill or plugin image is not pinned by digest
  skill-duplicate   two skills share a name, or a listed skill a local one's
  skills-too-many   more than 29 skill images: Substrate mounts at most 32
                    volumes per ActorTemplate
  prompt-twice      a system prompt file is given and the template has its own

A listing is a tools/list result, {"tools": [...]}, with or without its JSON-RPC
envelope, or any object with such a tools list, such as the MCP server's own
workload.yaml as JSON. A --server is asked for its tools/list over MCP's
streamable HTTP, with KAGENT_PACKAGE_MCP_TOKEN as its bearer token when set.
--local-skill names a skill this pipeline builds; the publish step adds it to
the packaged definition by digest. --out writes the packaged definition: the
definition, with the system prompt file's text in its template.

Exit status: 0 accepted, 1 refused, 2 usage or input error.
"""

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request

API_VERSION = "api.kagent.dev/v1alpha3"
SCHEMAS = {"Agent": "agents.v1alpha3.json", "AgentTemplate": "agenttemplates.v1alpha3.json"}
MAX_SKILL_IMAGES = 29
DIGEST = re.compile(r"^[^\s@]+@sha256:[0-9a-f]{64}$")
DNS_SUBDOMAIN = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$")


class InputError(Exception):
    """A file or argument the check cannot use: exit status 2."""


def has(obj, key):
    return isinstance(obj, dict) and key in obj


# The CRD's CEL rules, each by its exact text. A rule not here is refused, so a
# new kagent version cannot slip a rule past the check unnoticed.
CEL_RULES = {
    "!has(self.apiGroup)": lambda s: not has(s, "apiGroup"),
    "!has(self.namespace) || size(self.namespace) <= 63": lambda s: not has(s, "namespace")
    or len(s["namespace"]) <= 63,
    "!has(self.outputSchemaStrict) || !self.outputSchemaStrict || has(self.outputSchema) || has(self.outputSchemaFrom)":
        lambda s: not s.get("outputSchemaStrict") or has(s, "outputSchema") or has(s, "outputSchemaFrom"),
    "!has(self.path) || (!self.path.startsWith('/') && !self.path.split('/').exists(p, p == '..'))":
        lambda s: not has(s, "path") or (not s["path"].startswith("/") and ".." not in s["path"].split("/")),
    "(has(self.inline)?1:0)+(has(self.ref)?1:0) == 1": lambda s: has(s, "inline") + has(s, "ref") == 1,
    "(has(self.mcp)?1:0)+(has(self.subAgent)?1:0) == 1": lambda s: has(s, "mcp") + has(s, "subAgent") == 1,
    "(has(self.oci)?1:0)+(has(self.git)?1:0)+(has(self.bucket)?1:0) == 1":
        lambda s: has(s, "oci") + has(s, "git") + has(s, "bucket") == 1,
    "(has(self.outputSchema)?1:0)+(has(self.outputSchemaFrom)?1:0) <= 1":
        lambda s: has(s, "outputSchema") + has(s, "outputSchemaFrom") <= 1,
    "(has(self.systemPrompt)?1:0)+(has(self.systemPromptFrom)?1:0) <= 1":
        lambda s: has(s, "systemPrompt") + has(s, "systemPromptFrom") <= 1,
    "has(self.name) && self.name != ''": lambda s: has(s, "name") and s["name"] != "",
    "self.all(ref, has(ref.name) && ref.name != '')": lambda s: all(has(r, "name") and r["name"] != "" for r in s),
    "self.kind == 'RemoteMCPServer'": lambda s: s.get("kind") == "RemoteMCPServer",
    "size(self.name) > 0 && size(self.name) <= 253": lambda s: 0 < len(s.get("name", "")) <= 253,
}

# Kubernetes evaluates patterns as RE2; Python's re lacks POSIX classes.
POSIX_CLASSES = {"[:space:]": r"\s", "[:alpha:]": "A-Za-z", "[:digit:]": "0-9", "[:alnum:]": "A-Za-z0-9",
                 "[:upper:]": "A-Z", "[:lower:]": "a-z"}


def compile_pattern(pattern):
    for posix, python in POSIX_CLASSES.items():
        pattern = pattern.replace(posix, python)
    return re.compile(pattern)


TYPES = {
    "object": lambda v: isinstance(v, dict),
    "array": lambda v: isinstance(v, list),
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "number": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
}


def validate(value, schema, path, problems):
    """Kubernetes' structural schema, strictly: a field the schema does not name is refused."""
    t = schema.get("type")
    if t and not TYPES[t](value):
        problems.append(("schema", path, f"is {type(value).__name__}, not {t}"))
        return
    if "enum" in schema and value not in schema["enum"]:
        problems.append(("schema", path, f"{value!r} is not one of {schema['enum']}"))
    if isinstance(value, str):
        if "minLength" in schema and len(value) < schema["minLength"]:
            problems.append(("schema", path, f"is shorter than {schema['minLength']}"))
        if "maxLength" in schema and len(value) > schema["maxLength"]:
            problems.append(("schema", path, f"is longer than {schema['maxLength']}"))
        if "pattern" in schema and not compile_pattern(schema["pattern"]).search(value):
            problems.append(("schema", path, f"{value!r} does not match {schema['pattern']}"))
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            problems.append(("schema", path, f"is below {schema['minimum']}"))
        if "maximum" in schema and value > schema["maximum"]:
            problems.append(("schema", path, f"is above {schema['maximum']}"))
    if isinstance(value, dict) and not schema.get("x-kubernetes-preserve-unknown-fields"):
        properties = schema.get("properties", {})
        extra = schema.get("additionalProperties")
        for key in schema.get("required", []):
            if key not in value:
                problems.append(("schema", f"{path}.{key}", "is required"))
        for key, item in value.items():
            if key in properties:
                validate(item, properties[key], f"{path}.{key}", problems)
            elif isinstance(extra, dict):
                validate(item, extra, f"{path}.{key}", problems)
            elif extra is not True:
                problems.append(("schema", f"{path}.{key}", "is not a field of the schema"))
    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            problems.append(("schema", path, f"has fewer than {schema['minItems']} items"))
        if "maxItems" in schema and len(value) > schema["maxItems"]:
            problems.append(("schema", path, f"has more than {schema['maxItems']} items"))
        list_type = schema.get("x-kubernetes-list-type")
        if list_type == "set" and len({json.dumps(v, sort_keys=True) for v in value}) != len(value):
            problems.append(("schema", path, "repeats an item of a set"))
        if list_type == "map":
            keys = schema.get("x-kubernetes-list-map-keys", [])
            seen = [tuple(json.dumps(v.get(k), sort_keys=True) for k in keys) for v in value if isinstance(v, dict)]
            if len(set(seen)) != len(seen):
                problems.append(("schema", path, f"repeats a key ({', '.join(keys)}) of a map list"))
        for i, item in enumerate(value):
            validate(item, schema.get("items", {}), f"{path}[{i}]", problems)
    for rule in schema.get("x-kubernetes-validations", []):
        check = CEL_RULES.get(rule["rule"])
        if check is None:
            problems.append(("schema", path, f"carries a CEL rule this check does not know: {rule['rule']}"))
            continue
        try:
            ok = check(value)
        except (TypeError, KeyError, AttributeError):
            ok = False
        if not ok:
            where = path + rule.get("fieldPath", "")
            problems.append(("schema", where, rule.get("message", rule["rule"])))


def validate_metadata(metadata, problems):
    if not isinstance(metadata, dict):
        problems.append(("schema", ".metadata", "is required, an object"))
        return
    name = metadata.get("name")
    if not isinstance(name, str) or len(name) > 253 or not DNS_SUBDOMAIN.match(name):
        problems.append(("schema", ".metadata.name", f"{name!r} is not a DNS subdomain name"))
    for key, value in metadata.items():
        if key in ("labels", "annotations"):
            if not isinstance(value, dict) or not all(isinstance(v, str) for v in value.values()):
                problems.append(("schema", f".metadata.{key}", "is not a map of strings"))
        elif key not in ("name", "namespace"):
            problems.append(("schema", f".metadata.{key}", "is not packaged: name, namespace, labels and annotations only"))


def tools_of(listing, where):
    """The tools of a tools/list result, its JSON-RPC envelope, or an object with a tools list."""
    if isinstance(listing, dict) and isinstance(listing.get("result"), dict):
        listing = listing["result"]
    tools = listing.get("tools") if isinstance(listing, dict) else None
    if not isinstance(tools, list) or not all(isinstance(t, dict) and isinstance(t.get("name"), str) for t in tools):
        raise InputError(f"{where}: no tools list of named tools")
    return {t["name"]: t for t in tools}


def destructive(tool):
    """MCP's hints: readOnlyHint defaults to false, destructiveHint to true."""
    hints = tool.get("annotations") or {}
    if hints.get("readOnlyHint") is True:
        return False
    return hints.get("destructiveHint", True) is not False


def template_of(definition, problems):
    if definition.get("kind") == "AgentTemplate":
        return definition.get("spec")
    template = (definition.get("spec") or {}).get("template") or {}
    if "inline" not in template:
        problems.append(("not-inline", ".spec.template", "is not inline: the packaged definition holds its own template"))
        return None
    return template["inline"]


def check(definition, schemas, listings, local_skills=(), prompt=None):
    """Every reason to refuse the definition, as (code, path, message); empty when accepted."""
    problems = []
    kind = definition.get("kind")
    if definition.get("apiVersion") != API_VERSION or kind not in SCHEMAS:
        return [("schema", ".", f"is {definition.get('apiVersion')}/{kind}, not {API_VERSION} Agent or AgentTemplate")]
    # ObjectMeta is the API server's to check, not the CRD's: checked below.
    schema = dict(schemas[kind])
    schema["properties"] = {**schema.get("properties", {}),
                            "metadata": {"type": "object", "x-kubernetes-preserve-unknown-fields": True}}
    validate(definition, schema, "", problems)
    validate_metadata(definition.get("metadata"), problems)
    if "status" in definition:
        problems.append(("schema", ".status", "is not packaged"))
    template = template_of(definition, problems)
    if not isinstance(template, dict):
        return problems
    base = ".spec" if kind == "AgentTemplate" else ".spec.template.inline"

    for i, binding in enumerate(template.get("tools") or []):
        where = f"{base}.tools[{i}]"
        if not isinstance(binding, dict):
            continue
        if "subAgent" in binding:
            problems.append(("subagent", where, "binds a subagent, whose tools this check cannot see"))
            continue
        mcp = binding.get("mcp") or {}
        server = (mcp.get("server") or {}).get("name")
        if server not in listings:
            problems.append(("server-unlisted", where, f"names MCP server {server!r}, whose tools/list is not given"))
            continue
        offered = listings[server]
        named = mcp.get("tools") or []
        for name in named:
            if name not in offered:
                problems.append(("tool-unlisted", where, f"binds {name!r}, which {server} does not list"))
        exposed = [n for n in named if n in offered] if named else sorted(offered)
        if not mcp.get("requireApproval"):
            for name in exposed:
                if destructive(offered[name]):
                    problems.append(("approval-required", where,
                                     f"exposes {server}'s destructive tool {name!r} without requireApproval (K3)"))

    names = []
    images = 0
    for field in ("skills", "plugins"):
        for i, entry in enumerate(template.get(field) or []):
            where = f"{base}.{field}[{i}]"
            source = entry.get("source") if isinstance(entry, dict) else None
            if not isinstance(source, dict):
                continue
            if field == "skills":
                names.append(entry.get("name"))
            if "oci" not in source:
                kinds = [k for k in ("git", "bucket") if k in source]
                problems.append(("skill-source", where, f"comes from {' and '.join(kinds) or 'nowhere'}, not an image built from scratch (D28)"))
            elif not isinstance(source["oci"], str) or not DIGEST.match(source["oci"]):
                problems.append(("skill-digest", where, f"{source['oci']!r} is not pinned by digest (<image>@sha256:<64 hex>)"))
            else:
                images += 1
    for name in sorted(set(n for n in names if names.count(n) > 1)):
        problems.append(("skill-duplicate", f"{base}.skills", f"names {name!r} twice"))
    for name in local_skills:
        if name in names:
            problems.append(("skill-duplicate", f"{base}.skills", f"names {name!r}, which is also a local skill"))
    if images + len(local_skills) > MAX_SKILL_IMAGES:
        problems.append(("skills-too-many", f"{base}.skills",
                         f"has {images + len(local_skills)} skill images, more than {MAX_SKILL_IMAGES}"))
    if prompt is not None and ("systemPrompt" in template or "systemPromptFrom" in template):
        problems.append(("prompt-twice", base, "has its own system prompt, and a prompt file is given too"))
    return problems


def packaged(definition, prompt):
    out = json.loads(json.dumps(definition))
    if prompt is not None:
        template = out["spec"] if out["kind"] == "AgentTemplate" else out["spec"]["template"]["inline"]
        template["systemPrompt"] = prompt
    return out


# --- MCP's tools/list, over streamable HTTP ----------------------------------

def _post(url, body, headers):
    data = json.dumps(body).encode()
    request = urllib.request.Request(url, data=data, method="POST", headers={
        "Content-Type": "application/json", "Accept": "application/json, text/event-stream", **headers})
    with urllib.request.urlopen(request, timeout=30) as response:
        raw = response.read().decode()
        kind = response.headers.get("Content-Type", "")
        session = response.headers.get("Mcp-Session-Id")
    if "id" not in body:
        return None, session
    messages = []
    if kind.startswith("text/event-stream"):
        for line in raw.splitlines():
            if line.startswith("data:"):
                messages.append(json.loads(line[5:].strip()))
    elif raw.strip():
        parsed = json.loads(raw)
        messages = parsed if isinstance(parsed, list) else [parsed]
    for message in messages:
        if isinstance(message, dict) and message.get("id") == body["id"]:
            if "error" in message:
                raise InputError(f"{url}: {body['method']}: {message['error']}")
            return message.get("result"), session
    raise InputError(f"{url}: no answer to {body['method']}")


def fetch_listing(url, token=None):
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    try:
        result, session = _post(url, {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": "2025-06-18", "capabilities": {},
            "clientInfo": {"name": "ci-components-kagent-package", "version": "1"}}}, headers)
        if session:
            headers["Mcp-Session-Id"] = session
        headers["MCP-Protocol-Version"] = (result or {}).get("protocolVersion", "2025-06-18")
        _post(url, {"jsonrpc": "2.0", "method": "notifications/initialized"}, headers)
        tools, cursor, n = [], None, 2
        while True:
            params = {"cursor": cursor} if cursor else {}
            page, _ = _post(url, {"jsonrpc": "2.0", "id": n, "method": "tools/list", "params": params}, headers)
            tools += (page or {}).get("tools", [])
            cursor = (page or {}).get("nextCursor")
            n += 1
            if not cursor:
                return {"tools": tools}
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise InputError(f"{url}: tools/list failed: {e}") from e


# --- the command ---------------------------------------------------------------

def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except (OSError, ValueError) as e:
        raise InputError(f"{path}: {e}") from e


def pairs(values, what):
    out = {}
    for value in values:
        name, sep, rest = value.partition("=")
        if not sep or not name or not rest:
            raise InputError(f"{what} {value!r} is not <server>=<value>")
        out[name] = rest
    return out


def main(argv):
    parser = argparse.ArgumentParser(description="kagent-package's check of a kagent agent's definition")
    parser.add_argument("--definition", required=True)
    parser.add_argument("--schemas", required=True)
    parser.add_argument("--listing", action="append", default=[])
    parser.add_argument("--server", action="append", default=[])
    parser.add_argument("--local-skill", action="append", default=[])
    parser.add_argument("--system-prompt")
    parser.add_argument("--out")
    args = parser.parse_args(argv)
    try:
        definition = load_json(args.definition)
        if not isinstance(definition, dict):
            raise InputError(f"{args.definition}: not one object")
        schemas = {kind: load_json(os.path.join(args.schemas, f)) for kind, f in SCHEMAS.items()}
        listings = {name: tools_of(load_json(path), path) for name, path in pairs(args.listing, "--listing").items()}
        token = os.environ.get("KAGENT_PACKAGE_MCP_TOKEN") or None
        for name, url in pairs(args.server, "--server").items():
            if name in listings:
                raise InputError(f"server {name} has both a listing and a URL")
            listings[name] = tools_of(fetch_listing(url, token), url)
            print(f"{name}: {len(listings[name])} tools from {url}")
        prompt = None
        if args.system_prompt:
            try:
                with open(args.system_prompt) as f:
                    prompt = f.read()
            except OSError as e:
                raise InputError(f"{args.system_prompt}: {e}") from e
    except InputError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    problems = check(definition, schemas, listings, args.local_skill, prompt)
    name = (definition.get("metadata") or {}).get("name")
    if problems:
        for code, path, message in problems:
            print(f"refused [{code}] {path or '.'}: {message}", file=sys.stderr)
        print(f"{definition.get('kind')} {name}: refused, {len(problems)} reason(s)", file=sys.stderr)
        return 1
    if args.out:
        with open(args.out, "w") as f:
            json.dump(packaged(definition, prompt), f, indent=2, sort_keys=True)
            f.write("\n")
    print(f"{definition.get('kind')} {name}: accepted, {len(listings)} server listing(s), "
          f"{len(args.local_skill)} local skill(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
