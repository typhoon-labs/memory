#!/usr/bin/env bash
# Replaces schemas/ with the v1alpha3 openAPIV3Schema of kagent's Agent and
# AgentTemplate CRDs, from the kagent-crds chart at the version pinned below,
# the same chart and digests as environments' versions.yaml (kagent-chart):
# the OCI artifact's digest, then the unpacked tree's digest (sha256 of
# `sha256sum` over every file, sorted by path), before anything is read.
# Upstream, unpatched: environments patches only an annotation on the CRDs.
# Then run embed.py, and commit schemas/ and checker.yml together.
#
# kagent 1.0.1 is the tag v1.0.1 of github.com/kagent-dev/kagent, commit
# 558e3d761d8ed2b0d23bfef1867a9d1915210121 (git ls-remote, 2026-11-17).
set -euo pipefail
version=1.0.1
chart=oci://ghcr.io/kagent-dev/kagent/helm/kagent-crds
chart_digest=sha256:6fda1c3d10ebc67b7e38dc8361700aebbe5ee73fcc205c5fd2cc2de9e1b85eeb
tree_digest=24aab2d302d0b83c538dad606f801e7f3854a45617782c8d33659e8a5d42e52b
here="$(cd "$(dirname "$0")" && pwd)"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
fail() { echo "vendor: $*" >&2; exit 1; }

have="$(helm pull "$chart" --version "$version" -d "$tmp" 2>&1 | awk '/^Digest:/ {print $2}')"
[ "$have" = "$chart_digest" ] || fail "kagent-crds:$version has digest ${have:-none}, not $chart_digest"
mkdir "$tmp/unpacked"
tar xzf "$tmp/kagent-crds-$version.tgz" -C "$tmp/unpacked"
src="$tmp/unpacked/kagent-crds"
have="$(cd "$src" && find . -type f -print0 | LC_ALL=C sort -z | xargs -0 sha256sum | sha256sum | awk '{print $1}')"
[ "$have" = "$tree_digest" ] || fail "the unpacked chart has tree digest $have, not $tree_digest"

for kind in agents agenttemplates; do
  yq -o=json '.spec.versions[] | select(.name == "v1alpha3") | .schema.openAPIV3Schema' \
    "$src/templates/api.kagent.dev_$kind.yaml" > "$tmp/$kind.json"
  python3 -I -c 'import json, sys; s = json.load(open(sys.argv[1])); assert s.get("type") == "object", sys.argv[1]
with open(sys.argv[2], "w") as f: json.dump(s, f, indent=1, sort_keys=True); f.write("\n")' \
    "$tmp/$kind.json" "$here/schemas/$kind.v1alpha3.json"
  echo "vendor: schemas/$kind.v1alpha3.json from kagent-crds $version"
done
