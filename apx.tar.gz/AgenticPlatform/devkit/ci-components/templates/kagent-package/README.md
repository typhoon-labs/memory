# `kagent-package`

Packages a declarative kagent agent: checks its definition against kagent 1.0.1 and builds each of its skills as an image from scratch, the only form kagent mounts ([D28](../../../../architecture/plan/open-items.md#close-by-decision)), on every pipeline; on a release it publishes the skills and the packaged definition to ECR as the release role. A merge request publishes nothing: its gates are the check and the skills' builds, and GitLab's container registry refuses the definition's artifact type ("manifest invalid: unknown media type"). The umbrella component, `workload`, includes it for a workload whose `runtime` is `kagent`; `sign` then signs every skill and the definition.

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/kagent-package@1
    inputs:
      repository: <the agent's ECR repository>
      system-prompt: .agents/prompts/system.md
```

The inputs, with their defaults, are in [template.yml](template.yml). A kagent agent's repository holds, by default:

```text
config/agent.yaml           # the definition: one AgentTemplate, or an Agent with an inline template
config/tools/<server>.yaml  # each bound MCP server's tools/list, recorded
.agents/prompts/system.md   # the system prompt, when system-prompt names it
.agents/skills/<name>/      # each skill: SKILL.md and its files
```

## The check

[`checker/check.py`](checker/check.py), Python's standard library alone, refuses the definition with every reason listed when:

| Code | The definition |
| --- | --- |
| `schema` | breaks the CRD's v1alpha3 schema for its kind: types, required fields, patterns, lengths, list rules and the CRD's CEL rules, each hand-coded by its exact text, so a rule the check does not know is itself a refusal; and any field the schema does not name, as `kubectl`'s strict validation would |
| `not-inline` | is an Agent whose template is a reference |
| `subagent` | binds a subagent, whose tools the check cannot see |
| `server-unlisted` | binds an MCP server whose `tools/list` is neither recorded nor fetched |
| `tool-unlisted` | binds a tool its server does not list |
| `approval-required` | binds a destructive tool without `requireApproval` (K3). A tool is destructive unless its annotations say `readOnlyHint: true` or `destructiveHint: false`, the defaults MCP gives the hints; a binding that names no tools exposes all of them |
| `skill-source` | takes a skill or plugin from git or a bucket, not an image |
| `skill-digest` | names a skill or plugin image by tag, not by digest |
| `skill-duplicate` | names a skill twice, or like a local one |
| `skills-too-many` | has more than 29 skill images: Substrate mounts at most 32 volumes per actor |
| `prompt-twice` | has a system prompt of its own, and `system-prompt` names a file too |

A listing is a `tools/list` result, with or without its JSON-RPC envelope, or any object with such a `tools` list, such as the MCP server's own `workload.yaml`. An MCP server's pipeline can record one from its running image; `servers` asks a running server instead, over streamable HTTP.

The schemas are kagent 1.0.1's, vendored by [`checker/vendor.sh`](checker/vendor.sh) from the `kagent-crds` chart, checked against its OCI digest and unpacked tree digest, the pins `environments` keeps; the tag `v1.0.1` is commit `558e3d761d8ed2b0d23bfef1867a9d1915210121`. A consumer's pipeline receives only YAML, so [`checker.yml`](checker.yml) carries the check and the schemas as job variables, written by [`checker/embed.py`](checker/embed.py); the components' tests fail when it is stale.

## Jobs

| Job | Image | Does |
| --- | --- | --- |
| `kagent-package:render` | yq 4.54.3 | The definition and the listings, from YAML to JSON |
| `kagent-package:check` | Python 3.14.10 | The check; writes the packaged definition, with the prompt file's text in its template |
| `kagent-package:skills` | BuildKit 0.35.0, rootless | Each skill directory as a `FROM scratch` image for linux/amd64 and linux/arm64, reproducible as `build`'s images are |
| `kagent-package:oras` | oras 1.3.6 | Hands its binary to publish |
| `kagent-package:publish` | AWS CLI 2.40.3 | A release only: pushes each skill by digest under `<release-tag>-skill-<name>`, adds it to the packaged definition by that digest, and pushes the definition as an OCI artifact (`application/vnd.agentic-platform.kagent-agent.v1`, one file, `agent.json`) under `<release-tag>`. Writes `sign`'s records and exports `KAGENT_AGENT_DEFINITION`, the definition by digest |

## Tests

[`tests/kagent-package/test_check.py`](../../tests/kagent-package/test_check.py) runs every refusal beside its allowed twin, the listing shapes, and `tools/list` from a stub server over JSON and SSE. `tests/components.gitlab-ci.yml` runs them, checks that `checker.yml` is current, runs the embedded check on the [refused fixtures](../../tests/kagent-package/refused), and packages [the fixture agent](../../tests/kagent-package/fixture/config/agent.yaml) through the component; on protected main its release goes to a throwaway floci repository and `sign` signs it.
