# `conformance`

The contract stage of a workload's conformance ([Conformance](../../../../architecture/design/conformance.md#how-conformance-runs-in-ci), [How conformance runs in B5](../../../../architecture/plan/local-build.md#b5-in-detail)): the workload's image, from the build component's `build:publish`, runs as a service container beside a harness, and the workload suites of [conformance/suites/workload](../../conformance/suites/workload) run against it. Their JUnit report is the merge request's. The umbrella component, `workload`, includes it; a project may include it alone.

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/conformance@1
    inputs:
      scratch-repository: ci-scratch/<project slug>
      database: postgres       # when the workload keeps data in PostgreSQL
```

The inputs, with their defaults, are in [template.yml](template.yml). `runner-image` defaults to the contract image main pushed last when the component was pinned; a commit of the component always names its own pin. The level comes from the image's `workload.yaml`, as the design says, with `profile` as the least: L2 for a destructive tool or write access; so does the protocol, `a2a` for an agent and `mcp` for an MCP server, unless `protocol` names it, when it must agree. The kagent profile is not this component's. The stage runs in merge request pipelines only, unless `run-if` says otherwise: a release's image was checked in its merge request, and release-time conformance is `infra/conformance`'s (B6).

## Jobs

| Job | Image | Does |
| --- | --- | --- |
| `<job-name>:prepare` | The contract image | Copies `WORKLOAD_IMAGE` by digest into `<scratch-registry>/<scratch-repository>`, tagged for the pipeline and job, with oras (the job token for the project's GitLab registry), and reads its `/etc/agentic/workload.yaml`: name, kind, level and so the protocol. Its dotenv report names the service image, `<service-registry>/<scratch-repository>@<digest>`, and the database's random alias and password |
| `<job-name>` | The contract image | Runs the workload as a service, alias `workload-<job ID>`, and PostgreSQL (CloudNativePG's image) beside it; starts the harness in its own container; waits for the workload's `/readyz`; runs the suites (`conform contract`); writes the JUnit report, the collector's export and the STS's configuration and policy as artifacts |

The scratch copy is deleted at the end, pass or fail: the second job's `after_script` deletes its tag with `conform scratch-delete` (ECR's `BatchDeleteImage` at `scratch-endpoint`, then the image if no other tag names it, as ECR does and floci does not), and a prepare job that fails after its copy deletes it itself. A failed deletion is reported, never the job's failure. A cancelled pipeline runs neither; the scratch repository's expiry, a day, removes what it leaves. Before the component's `runner-image` default moves to a contract image that has `scratch-delete`, the call fails harmlessly and the copy stays.

## Why two jobs and a harness in the job

Proven on the build runner before it was built ([B5's results](../../conformance/README.md#the-contract-stage)):

- **A service starts before its job's script,** with what its image and variables hold. So the image under test is copied in a job of its own, and the workload is configured by its environment alone (the variables agreed with `agent-sdk`'s Python core: `AGENTIC_*`, `OTEL_*`).
- **The runner's Docker daemon pulls through the sandbox's proxy,** which breaks pulls from the project's GitLab registry and from floci by name; it pulls `127.0.0.1:4566/…` directly. So services come from floci's loopback name, and the image under test from a scratch copy there.
- **Fixed service aliases collide** on the runner's shared `kind` network between concurrent jobs: `fake-model` in two jobs resolves to both. So the fixtures, the STS and the collector are the job's own processes, which the workload reaches at the job container's host name, `runner-<runner>-project-<project>-concurrent-<slot>`, unique per running job; the workload's and the database's aliases carry the job's ID or a random part.
- **No process control over a service:** the SIGTERM case of Lifecycle runs in the integration stage, where the suite can delete the pod.

## What the workload must do

- Carry its `workload.yaml` at `/etc/agentic/workload.yaml` (the build component copies it there).
- Read its configuration from the environment, make no network call at its start, and reach its dependencies lazily: the harness starts after it.
- Read `AGENTIC_ACTOR_TOKEN_FILE` at each exchange; the job writes it once the workload runs.
- Listen on `AGENTIC_LISTEN` (`0.0.0.0:<workload-port>`), with `/readyz` and `/healthz` answering without a token; an agent serves A2A at `/a2a/<name>` and its card at `/a2a/<name>/.well-known/agent-card.json`, an MCP server MCP at `/mcp` and its approval route at `/approvals/<name>/<id>`, `<name>` being `AGENTIC_WORKLOAD_NAME` (B5's seams, "Paths through the gateway").

What it receives, and what the stage lowers so its limit and expiry cases take seconds:

| Variable | In the stage |
| --- | --- |
| `AGENTIC_WORKLOAD_NAME` | The name in `workload.yaml` |
| `AGENTIC_GATEWAY_URL` | The harness's front, `http://<job host>:18080`: the model route at `/v1` ends at the fake model server, `/mcp/<server>` at the harness's MCP servers |
| `AGENTIC_RESOURCE_BASE` | `https://workloads-gateway.<domain>` |
| `AGENTIC_STS_TOKEN_ENDPOINT` | `/sts/token` on the front, which passes it to the STS's TLS port |
| `AGENTIC_ACTOR_TOKEN_FILE` | A file in the build volume the service shares |
| `AGENTIC_TRUST` | The test issuer (profile `keycloak`, the workload's developer-deployment route) and the STS (profile `chain`, its hosted-workloads route) |
| `AGENTIC_APPROVAL_AUDIENCE`, `AGENTIC_APPROVAL_TTL_SECONDS` | `https://gateway.<domain>/mcp/<name>`; 5 seconds |
| `AGENTIC_LIMIT_MODEL_CALLS`, `_TOOL_CALLS`, `_TOKENS`, `_WALL_TIME_SECONDS` | 2, 2, 20000 and 5, each lowering the declared cap, never raising it: one response asking for three tool calls passes the tool-call cap, three turns of one call each pass the model-call cap |
| `AGENTIC_DATABASE_URL` | With `database: postgres`, the harness's proxy on the job, port 15432, which forwards to the PostgreSQL service and can hold its answers back past the wall-time cap; empty otherwise |
| `OTEL_EXPORTER_OTLP_ENDPOINT`, `OTEL_EXPORTER_OTLP_PROTOCOL` | The collector on the job, `http/protobuf` on 4318 |
| `OTEL_SERVICE_NAME`, `OTEL_RESOURCE_ATTRIBUTES` | The workload's name; `platform.release.id=conformance-<pipeline>-<job>` |

## Local and dev

Locally the KMS alias, the registries and the credentials are floci's: the STS signs through `sts-signing-alias`, created at the job's start if absent and kept outside OpenTofu (D26), with floci's test credentials. In dev, a merge request pipeline assumes no AWS role, so the STS cannot reach KMS and the scratch copy cannot be written to ECR; how the stage signs there is [D26](../../../../architecture/plan/open-items.md#close-by-decision), and the service would be pulled from the project's GitLab registry by the runner, which this sandbox could not show.
