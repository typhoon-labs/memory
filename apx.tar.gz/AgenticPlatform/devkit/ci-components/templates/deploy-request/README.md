# `deploy-request`

Prints, on a release, the `agentctl deploy request` command that opens the release's merge request in `environments`, with the release's digest, for the developer to run with their own GitLab token (D39, its first option). From 1.1.0. A CI job token cannot open a merge request in another project, and the local build has no bot user ([B6 desk check](../../../../architecture/research/2026-11-18-b6-desk-check.md#the-conformance-attestation-and-its-trigger-t17)), so the job only prints: it calls nothing, and uses no token and no role. The umbrella, [`workload`](../workload/README.md), includes it for a container workload and a kagent agent.

```yaml
include:
  - component: $CI_SERVER_FQDN/<root>/devkit/ci-components/deploy-request@1
```

The inputs, with their defaults, are in [template.yml](template.yml).

## The command

One line, agreed with `agentctl` v0.2.0, which owns its flags and checks them again:

```text
agentctl deploy request --environment <env> --project <project path> --tag <release tag> --workload <name> --image <ref@sha256:…>
agentctl deploy request --environment <env> --project <project path> --tag <release tag> --workload <name> --definition <ref@sha256:…>
```

| Flag | From |
| --- | --- |
| `--environment` | `environment`, by default the group variable `AGENTIC_ENVIRONMENT` (`local` locally) |
| `--project` | `CI_PROJECT_PATH`: agentctl reads `workload.yaml` and `deploy/` there at the tag, as the person |
| `--tag` | `CI_COMMIT_TAG`, `vX.Y.Z` or `<workload>/vX.Y.Z` |
| `--workload` | `workload.yaml`'s `name`, which agentctl checks against the file at the tag |
| `--image` | A container workload's image by digest, `WORKLOAD_IMAGE` from `build:publish` |
| `--definition` | A kagent agent's packaged definition by digest, `KAGENT_AGENT_DEFINITION` from `kagent-package:publish` |

The chart versions and digests come from `environments`' `versions.yaml`, so the line names none. The job runs after the release's signature and, when the umbrella runs it, the conformance wait, so a release that admission would refuse gets no line. It refuses, writing nothing: no environment, a project that is not a path, a tag that is not a release tag, a name that is not one, a workflow (runtime `pipeline`, never deployed) or another runtime, and a reference that is not `<registry.host>/<repository>@sha256:<64 hex>`. The line goes to the job's log and to `out/deploy-request/command.txt`.

## Tests

[`tests/deploy-request/test_command.py`](../../tests/deploy-request/test_command.py) runs [`command.sh`](command.sh), which the job carries embedded (`scripts.yml`, by `embed.py`), for a container workload and a kagent agent, and makes each refusal by one change, beside its twin; `embed.py --check` fails when `scripts.yml` is stale. On protected main the component runs on the fixture app's release, and `test:deploy-request` checks the line it wrote, the image by the digest `build:publish` pushed.
