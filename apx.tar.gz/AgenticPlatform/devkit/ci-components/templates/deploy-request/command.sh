#!/bin/sh
# deploy-request's command: the `agentctl deploy request` line a developer
# runs, with their own GitLab token, to open the release's merge request in
# environments (D39). It prints the line and writes it to a file; it calls
# nothing, and uses no token and no role.
#
# Usage: sh command.sh <out file> <environment> <project path> <tag>
#        <workload name> <runtime> <image or definition, by digest>
#
# Exit status: 0 printed, 2 an input is missing or malformed.
set -u
out="${1:-}" environment="${2:-}" project="${3:-}" tag="${4:-}" name="${5:-}" runtime="${6:-}" ref="${7:-}"
fail() { echo "error: $*" >&2; exit 2; }
unset_() { case "$1" in ""|'$'*) return 0 ;; *) return 1 ;; esac; }
unset_ "$environment" && fail "no environment: set the deploy-request component's environment input, or the group variable AGENTIC_ENVIRONMENT"
printf '%s' "$environment" | grep -Eq '^[a-z0-9]+(-[a-z0-9]+)*$' || fail "the environment $environment is not a name, such as local or dev"
unset_ "$project" && fail "no project path"
printf '%s' "$project" | grep -Eq '^[A-Za-z0-9_.-]+(/[A-Za-z0-9_.-]+)+$' || fail "the project $project is not a project path"
unset_ "$tag" && fail "no release tag: a deploy request names the tag it releases"
printf '%s' "$tag" | grep -Eq '^([a-z0-9]+(-[a-z0-9]+)*/)?v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$' ||
  fail "the tag $tag is not vX.Y.Z or <workload>/vX.Y.Z"
printf '%s' "$name" | grep -Eq '^[a-z0-9]+(-[a-z0-9]+)*$' || fail "the workload's name $name is not lowercase kebab-case: is workload.yaml's name set?"
case "$runtime" in
  container) flag=--image ;;
  kagent) flag=--definition ;;
  pipeline) fail "a workflow (runtime pipeline) is not deployed: it has no deploy request" ;;
  *) fail "the runtime $runtime is not container or kagent" ;;
esac
unset_ "$ref" && fail "no $flag reference: the release's publishing job must export it"
printf '%s' "$ref" | grep -Eq '^[a-z0-9]([a-z0-9.-]*[a-z0-9])?(:[0-9]+)?(/[a-z0-9]+([._-][a-z0-9]+)*)+@sha256:[0-9a-f]{64}$' ||
  fail "the reference $ref is not <registry.host>/<repository>@sha256:<64 hex>: a deploy request pins a digest"
line="agentctl deploy request --environment $environment --project $project --tag $tag --workload $name $flag $ref"
mkdir -p "$(dirname "$out")"
printf '%s\n' "$line" > "$out"
echo "To open this release's deploy request in environments, run, with your own GitLab token:"
echo
echo "    $line"
echo
