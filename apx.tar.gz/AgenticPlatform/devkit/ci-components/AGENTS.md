# Agent instructions: ci-components

This repository holds the platform's CI/CD catalog: components, the conformance runner, its suites and fixtures. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. The layout is in [Repositories](../../architecture/design/repositories.md#repository-layouts), and the build phase that adds each part is in the [local build plan](../../architecture/plan/local-build.md#6-phased-local-build).

## Rules for this repository

- **Components are a contract.** A change to a component's inputs or behaviour that breaks a workload's pipeline is a major version (`BREAKING CHANGE:`), released by tag as `X.Y.Z` ([Distribution](../../architecture/design/distribution.md#release-tags)).
- **Every job has a tag** (`local-build` or `local-deploy` in the local build), so GitLab-hosted runners never pick one up.
- **Images by digest.** Every image a component runs is pinned by digest, with its version recorded in [Versions](../../architecture/reference/versions.md).
- **The fake model server is deterministic,** so a conformance result never depends on chance ([Conformance](../../architecture/design/conformance.md)). Its API, counting rule and fault-control contract are in [its README](conformance/fixtures/fake-model/README.md), which the suites are written against: a change to a response's shape, a directive key or the counting rule updates that README in the same commit, and is breaking unless it only adds.
- **The suites prove what they claim.** Each case proves a refusal and its allowed twin and asserts the layer that refused; a new case gets an expectation in `conformance/suites/platform/standin_test.go`, and a fault in the stand-in if none makes it fail ([conformance/README.md](conformance/README.md)).
- **Go modules:** the standard library first. A new dependency needs its reason in the commit message, and a pinned version.

## Before committing

- In each Go module (today `conformance/` and `conformance/fixtures/fake-model/`): `gofmt -l .` prints nothing, and `go vet ./...` and `go test -race ./...` pass.
- For `conformance/chart/`: `helm lint` and `helm template` with the platform values pass.
- For `templates/kagent-package/checker/`: `python3 -I tests/kagent-package/test_check.py` passes, and after a change to `check.py` or `schemas/`, `checker/embed.py` rewrites `checker.yml`, which `embed.py --check` confirms.
- For a component under `templates/`: `bash -n` on its scripts, and the pipeline lints at the pushed branch (`glab api "projects/<id>/ci/lint?content_ref=<branch>"`). A component reaches a consumer as YAML alone: its jobs read no file of this repository, and its job variables carry the component's prefix, so an input never names a variable of its own name.
- `python3 ../../architecture/tools/check_docs.py .` reports no problems.
