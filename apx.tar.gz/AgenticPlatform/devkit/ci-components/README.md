# ci-components

The platform's GitLab CI/CD catalog: the components every workload includes, and the conformance runner with its suites and fixtures. Workloads include the umbrella component as `$CI_SERVER_FQDN/<root>/devkit/ci-components/workload@1`, the newest 1.x release in the catalog.

Created in build phase B0. Its first content is the fake model server, a conformance fixture built in B2; [its README](conformance/fixtures/fake-model/README.md) is the contract the suites rely on. B2 adds the start of the conformance runner, the platform-controls suites and their fixtures ([conformance/README.md](conformance/README.md)), and the pipeline that builds their images. B5 adds the workload suites, the contract stage's harness and image, and the components. B6 adds `conformance-trigger`, `deploy-request` and `library-release`, sign's attest mode for the platform's own attestations, and the check against `agent-sdk`'s spec they share (`templates/spec/`). From B6 it also builds `platform/step` ([`images/step/`](images/step/Dockerfile)), the image a workflow pipeline's step job runs, agentctl and the shared SDK's `agentic-step`; and its main pipeline signs the images it pushes, the fake model, the runner (both its tags), the fixtures and `platform/step`, with the platform's own key, `alias/platform/platform-signing`, never a workload's release key: a signature, an SPDX SBOM per platform and SLSA provenance on each index digest (D36).

```text
ci-components/
├── templates/            # the CI/CD components, one directory each
│   ├── build/            # template.yml and its README
│   ├── conformance/      # the contract stage of a workload's conformance
│   ├── conformance-trigger/  # a release's integration conformance
│   ├── deploy-request/   # the release's deploy request command
│   ├── kagent-package/
│   ├── library-release/
│   ├── sign/
│   ├── spec/             # not a component: the check against agent-sdk's spec
│   ├── step/
│   └── workload/         # the umbrella
├── conformance/          # the runner, the suites and their fixtures: one Go module
│   ├── fixtures/
│   │   └── fake-model/   # the fake model server, its own Go module
│   └── chart/            # the fixtures and the suites as a Helm test
├── images/step/          # platform/step: agentctl and agentic-step, for workflow pipelines' steps
├── tests/                # the components' tests and their fixtures
├── .gitlab-ci.yml        # builds and pushes the images, and tests the components
├── AGENTS.md
└── README.md
```

## Components

B5 adds the components under `templates/`. A protected `X.Y.Z` tag publishes them to the catalog as that version, and consumers include them by major version (`@1`). The first change on `main` after a tag moves `conformance/runner/VERSION` to the next patch, so that the runners main builds report a version that sorts above the release ([conformance/README.md](conformance/README.md#running-them)).

- [`build`](templates/build/README.md): a workload's image, multi-arch and reproducible, to the project's GitLab registry on a merge request and to ECR on a release
- [`conformance`](templates/conformance/README.md): the contract stage, the workload suites against the workload's image as a service beside a harness, with a JUnit report
- [`conformance-trigger`](templates/conformance-trigger/README.md): from 1.1.0, a release's integration conformance: `infra/conformance`'s pipeline started for the image's digest with its trigger token, then a bounded wait for the image's conformance attestation
- [`deploy-request`](templates/deploy-request/README.md): from 1.1.0, the `agentctl deploy request` command a release prints, with its digest, for the developer to open its merge request in `environments` (D39)
- [`sign`](templates/sign/README.md): cosign with a KMS key, the release key by default, never keyless: images with SBOMs and provenance attested, files as sigstore bundles, or from 1.1.0 one of the platform's own attestations, the conformance attestation or a release record, checked against `agent-sdk`'s schema first ([`templates/spec/`](templates/spec/README.md))
- [`library-release`](templates/library-release/README.md): from 1.1.0, one library artifact from its `<kind>/<name>/vX.Y.Z` tag, `artifact.yaml` checked against `agent-sdk`'s spec, built as a scratch image for amd64 and arm64, pushed with ORAS to `library/<kind>/<name>` and signed as `sign` does
- [`kagent-package`](templates/kagent-package/README.md): a kagent agent's definition checked against kagent 1.0.1 and its skills built from scratch on every pipeline, both published on a release
- [`step`](templates/step/README.md): one bounded model step of a workflow pipeline, `agentctl step run`; its live run waits for agentctl and D27
- [`workload`](templates/workload/README.md): the umbrella a workload's `.gitlab-ci.yml` includes

The layout to come and the release rules are in the architecture repository:

- [Repositories](../../architecture/design/repositories.md#repository-layouts): the layout of this repository
- [Conformance](../../architecture/design/conformance.md): the runner, the suites and the fake model server
- [Distribution](../../architecture/design/distribution.md#release-tags): release tags, `X.Y.Z`
