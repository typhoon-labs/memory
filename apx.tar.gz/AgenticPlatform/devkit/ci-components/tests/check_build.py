"""Checks two builds of the fixture app from one commit, as the build component left them.

Usage: python3 -I tests/check_build.py <workload.yaml> <layout> <layout>

Each argument is an OCI layout the build component's build:image job wrote,
beside its BuildKit metadata (<layout>.json). The check passes when both
builds are the same multi-arch index, BuildKit's metadata names that index,
the index lists linux/amd64 and linux/arm64, each platform's layers carry
the compiled pydantic-core module of its own architecture, and each
platform's last layer is the workload's workload.yaml at
/etc/agentic/workload.yaml, as the fixture holds it.
"""

import gzip
import io
import json
import os
import sys
import tarfile

PLATFORMS = {"linux/amd64": "x86_64", "linux/arm64": "aarch64"}
WORKLOAD = "etc/agentic/workload.yaml"


def blob(layout, digest):
    algorithm, hexdigest = digest.split(":", 1)
    with open(os.path.join(layout, "blobs", algorithm, hexdigest), "rb") as f:
        return f.read()


def layer_files(layout, layer):
    """The layer's regular files, each with its content if it is workload.yaml."""
    data = blob(layout, layer["digest"])
    if layer["mediaType"].endswith("gzip"):
        data = gzip.decompress(data)
    with tarfile.open(fileobj=io.BytesIO(data)) as t:
        out = {}
        for m in t.getmembers():
            if m.isfile():
                out[m.name] = t.extractfile(m).read() if m.name == WORKLOAD else None
        return out


def inspect(layout):
    with open(os.path.join(layout, "index.json")) as f:
        top = json.load(f)["manifests"]
    if len(top) != 1:
        raise SystemExit(f"{layout}: index.json lists {len(top)} manifests, not one index")
    index_digest = top[0]["digest"]
    with open(layout.rstrip("/") + ".json") as f:
        metadata = json.load(f)["containerimage.digest"]
    if metadata != index_digest:
        raise SystemExit(f"{layout}: BuildKit's metadata names {metadata}, the layout holds {index_digest}")
    index = json.loads(blob(layout, index_digest))
    platforms = {}
    for m in index["manifests"]:
        p = m.get("platform", {})
        key = f'{p.get("os")}/{p.get("architecture")}'
        manifest = json.loads(blob(layout, m["digest"]))
        layers = [layer_files(layout, layer) for layer in manifest["layers"]]
        modules = [n for files in layers for n in files if "_pydantic_core" in n and n.endswith(".so")]
        platforms[key] = {"manifest": m["digest"], "modules": modules, "last": layers[-1]}
    return index_digest, platforms


def main(argv):
    if len(argv) != 3:
        raise SystemExit(__doc__)
    with open(argv[0], "rb") as f:
        workload = f.read()
    argv = argv[1:]
    results = [inspect(layout) for layout in argv]
    problems = []
    for layout, (digest, platforms) in zip(argv, results):
        print(f"{layout}: index {digest}")
        for key in sorted(platforms):
            print(f"   {key}: manifest {platforms[key]['manifest']}, {platforms[key]['modules']}")
        if sorted(platforms) != sorted(PLATFORMS):
            problems.append(f"{layout}: platforms {sorted(platforms)}, not {sorted(PLATFORMS)}")
        for key, machine in PLATFORMS.items():
            modules = platforms.get(key, {}).get("modules", [])
            if len(modules) != 1 or f"-{machine}-linux-gnu.so" not in modules[0]:
                problems.append(f"{layout}: {key} carries {modules}, not one {machine} module")
            last = platforms.get(key, {}).get("last", {})
            if list(last) != [WORKLOAD] or last[WORKLOAD] != workload:
                problems.append(f"{layout}: {key}'s last layer is {sorted(last)}, not the fixture's {WORKLOAD}")
    if results[0][0] != results[1][0]:
        problems.append(f"the two builds differ: {results[0][0]} and {results[1][0]}")
    else:
        print(f"reproducible: both builds are {results[0][0]}")
    for p in problems:
        print(f"error: {p}", file=sys.stderr)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
