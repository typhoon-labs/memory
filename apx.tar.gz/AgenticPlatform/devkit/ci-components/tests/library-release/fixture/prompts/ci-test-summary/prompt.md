Summarise the changes in one sentence. This prompt is a test fixture of
ci-components' library-release component.
