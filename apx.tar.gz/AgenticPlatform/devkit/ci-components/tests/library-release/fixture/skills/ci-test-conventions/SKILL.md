---
name: ci-test-conventions
description: A test skill of ci-components' library-release component. Use it for nothing.
---

# ci-test-conventions

This skill exists so that ci-components can release it in its own pipeline.
It holds no instructions.
