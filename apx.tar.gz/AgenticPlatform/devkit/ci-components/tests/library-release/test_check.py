"""library-release's check (templates/library-release/checker/check.py):
the fixture library is accepted, and on a release its skill's tag too;
each refusal is made by one change to the fixture, for its own reason
alone, beside its twin, which is accepted. Runs check.py as the
component's job does, against the vendored spec and the JSON the render
job would write (YAML parsed here by the stand-in below, which reads the
fixture's plain mappings, lists and scalars only).

Usage, from the repository root: python3 -I tests/library-release/test_check.py
"""

import copy
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CHECK = os.path.join(ROOT, "templates", "library-release", "checker", "check.py")
VALIDATE = os.path.join(ROOT, "templates", "spec", "validate.py")
SCHEMAS = os.path.join(ROOT, "templates", "spec", "spec")
FIXTURE = os.path.join(ROOT, "tests", "library-release", "fixture")
PROJECT = "https://gitlab.example.com/example/agent-library"
COMMIT = "b2a9b7236696bea19cc9e1e1518014ebf9210cb1"


def scalar(text):
    text = text.strip()
    if text.startswith('"') and text.endswith('"'):
        return text[1:-1]
    if text in ("true", "false"):
        return text == "true"
    return text


def parse(path):
    """The fixture's YAML, which is block mappings, lists of mappings and
    scalars, as yq would render it."""
    lines = [l.rstrip("\n") for l in open(path) if l.strip() and not l.lstrip().startswith("#")]
    pos = 0

    def block(indent):
        nonlocal pos
        if lines[pos].strip().startswith("- "):
            items = []
            while pos < len(lines) and lines[pos].startswith(" " * indent + "- "):
                first = lines[pos][indent + 2:]
                lines[pos] = " " * (indent + 2) + first
                items.append(block(indent + 2))
            return items
        out = {}
        while pos < len(lines):
            line = lines[pos]
            cur = len(line) - len(line.lstrip())
            if cur < indent or line.strip().startswith("- "):
                break
            key, _, value = line.strip().partition(":")
            pos += 1
            if value.strip():
                out[key] = scalar(value)
            else:
                nxt = lines[pos]
                out[key] = block(len(nxt) - len(nxt.lstrip()))
        return out

    return block(0)


class Library:
    """A copy of the fixture, with its rendered JSON beside it."""

    def __init__(self, tmp):
        self.root = os.path.join(tmp, "library")
        shutil.copytree(FIXTURE, self.root)
        self.json = os.path.join(tmp, "json")
        self.docs = {"library.json": parse(os.path.join(self.root, "library.yaml"))}
        for kind_dir in ("skills", "prompts"):
            for name in os.listdir(os.path.join(self.root, kind_dir)):
                rel = f"{kind_dir}/{name}/artifact.json"
                self.docs[rel] = parse(os.path.join(self.root, kind_dir, name, "artifact.yaml"))

    def write(self):
        if os.path.isdir(self.json):
            shutil.rmtree(self.json)
        for rel, doc in self.docs.items():
            path = os.path.join(self.json, rel)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w") as f:
                json.dump(doc, f)

    def release(self, tag, artifact, provenance=None):
        filled = copy.deepcopy(self.docs[artifact])
        filled["provenance"] = provenance or {"repository": PROJECT, "commit": COMMIT, "pipeline_id": 977}
        path = os.path.join(os.path.dirname(self.json), "release.artifact.json")
        with open(path, "w") as f:
            json.dump(filled, f)
        return ["--release-tag", tag, "--released", path, "--project-url", PROJECT, "--commit", COMMIT, "--pipeline-id", "977"]

    def run(self, *extra):
        r = subprocess.run([sys.executable, "-I", CHECK, "--validator", VALIDATE, "--schemas", SCHEMAS,
                            "--root", self.root, "--json", self.json, *extra], capture_output=True, text=True)
        return r.returncode, r.stdout + r.stderr


SKILL = "skills/ci-test-conventions/artifact.json"
PROMPT = "prompts/ci-test-summary/artifact.json"


class Check(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp)
        self.lib = Library(self.tmp)

    def accepted(self, *extra):
        self.lib.write()
        status, out = self.lib.run(*extra)
        self.assertEqual(status, 0, out)
        return out

    def refused(self, reason, *extra):
        self.lib.write()
        status, out = self.lib.run(*extra)
        self.assertEqual(status, 1, out)
        reasons = {line.split("]")[0][len("refused ["):] for line in out.splitlines() if line.startswith("refused [")}
        self.assertEqual(reasons, {reason}, out)
        return out

    def test_fixture_accepted(self):
        out = self.accepted()
        self.assertIn("accepted: library.yaml and 2 artifact(s)", out)

    def test_release_accepted(self):
        self.lib.write()
        env = os.path.join(self.tmp, "release.env")
        out = self.accepted(*self.lib.release("skill/ci-test-conventions/v0.1.0", SKILL), "--out", env)
        self.assertIn("release: skill ci-test-conventions 0.1.0 from skills/ci-test-conventions/", out)
        with open(env) as f:
            self.assertEqual(f.read(), "LIBRARY_KIND=skill\nLIBRARY_NAME=ci-test-conventions\nLIBRARY_VERSION=0.1.0\n"
                             "LIBRARY_DIR=skills/ci-test-conventions\n")
        self.lib.write()
        self.accepted(*self.lib.release("prompt/ci-test-summary/v0.1.0", PROMPT))

    def test_schema(self):
        self.lib.docs[SKILL]["support"] = "retired"
        self.refused("schema")

    def test_library_schema(self):
        self.lib.docs["library.json"]["tier"] = "team"
        self.refused("library-schema")
        self.lib.docs["library.json"]["prefix"] = "payments"
        # A team's library with its prefix: the names must carry it.
        out = self.refused("prefix")
        self.assertIn("must start with payments-", out)
        self.lib.docs["library.json"]["prefix"] = "ci-test"
        self.accepted()

    def test_kind_dir(self):
        self.lib.docs[PROMPT]["kind"] = "workflow"
        self.refused("kind-dir")

    def test_name_dir(self):
        self.lib.docs[SKILL]["name"] = "ci-test-other"
        self.refused("name-dir")

    def test_name_twice(self):
        os.makedirs(os.path.join(self.lib.root, "prompts", "ci-test-conventions"))
        twin = copy.deepcopy(self.lib.docs[PROMPT])
        twin["name"] = "ci-test-conventions"
        self.lib.docs["prompts/ci-test-conventions/artifact.json"] = twin
        self.refused("name-twice")
        twin["name"] = "ci-test-third"
        del self.lib.docs["prompts/ci-test-conventions/artifact.json"]
        self.accepted()

    def test_committed_provenance(self):
        self.lib.docs[PROMPT]["provenance"] = {"repository": PROJECT, "commit": COMMIT, "pipeline_id": 1}
        self.refused("provenance")

    def test_skill_file(self):
        os.remove(os.path.join(self.lib.root, "skills", "ci-test-conventions", "SKILL.md"))
        self.refused("skill-file")

    def test_tag_form(self):
        self.lib.write()
        self.refused("tag-form", *self.lib.release("ci-test-conventions/v0.1.0", SKILL))
        self.lib.write()
        self.refused("tag-form", *self.lib.release("agent/ci-test-conventions/v0.1.0", SKILL))

    def test_tag_artifact(self):
        self.lib.write()
        self.refused("tag-artifact", *self.lib.release("prompt/ci-test-conventions/v0.1.0", SKILL))

    def test_tag_version(self):
        self.lib.write()
        self.refused("tag-version", *self.lib.release("skill/ci-test-conventions/v0.2.0", SKILL))

    def test_released(self):
        self.lib.write()
        out = self.refused("released", *self.lib.release("skill/ci-test-conventions/v0.1.0", SKILL,
                                                         {"repository": PROJECT, "commit": COMMIT, "pipeline_id": 978}))
        self.assertIn("not this pipeline's", out)
        self.lib.write()
        args = self.lib.release("skill/ci-test-conventions/v0.1.0", SKILL)
        filled = json.load(open(args[3]))
        filled["support"] = "community"
        json.dump(filled, open(args[3], "w"))
        out = self.refused("released", *args)
        self.assertIn("more than its provenance", out)

    def test_unknown_input(self):
        self.lib.write()
        r = subprocess.run([sys.executable, "-I", CHECK, "--validator", VALIDATE, "--schemas", SCHEMAS,
                            "--root", self.lib.root, "--json", os.path.join(self.tmp, "nowhere")],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 2, r.stdout + r.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=1)
