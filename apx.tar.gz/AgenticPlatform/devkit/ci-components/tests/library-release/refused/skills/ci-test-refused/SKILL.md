---
name: ci-test-refused
description: A test skill whose artifact.yaml library-release must refuse.
---

# ci-test-refused

Never released.
