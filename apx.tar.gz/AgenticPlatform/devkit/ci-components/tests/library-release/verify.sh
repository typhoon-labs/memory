#!/bin/sh
# library-release's release, after sign ran on it: the artifact verifies
# with the key's public key, signature, an SPDX SBOM per platform and the
# provenance, which names this commit and the release; another key is
# refused. Runs in the cosign image (busybox), with LIBRARY_ARTIFACT from
# library-release:publish and sign:image's out/sign/.
set -u
http="--allow-http-registry"
ref="$LIBRARY_ARTIFACT"
export HOME="$(mktemp -d)"
export TUF_ROOT="$HOME/tuf"
bad=0
ok() {
  if "$@" > "$HOME/out" 2>&1; then echo "passes, as it must: $*"; else echo "error: refused, but must pass: $*"; tail -3 "$HOME/out"; bad=1; fi
}
no() { # no <the refusal's reason, a grep pattern> <command>...
  reason="$1"; shift
  if "$@" > "$HOME/out" 2>&1; then
    echo "error: passes, but must be refused: $*"; bad=1
  elif grep -q -- "$reason" "$HOME/out"; then
    echo "refused, as it must be: $* -- $reason"
  else
    echo "error: refused, but not for '$reason': $*"; tail -2 "$HOME/out"; bad=1
  fi
}
case "$ref" in *@sha256:*) ;; *) echo "error: LIBRARY_ARTIFACT $ref is not by digest"; exit 1 ;; esac
grep -qxF "$ref" out/sign/signed.txt || { echo "error: sign did not sign $ref"; exit 1; }
COSIGN_PASSWORD="" cosign generate-key-pair --output-key-prefix "$HOME/other" > /dev/null 2>&1 || { echo "error: no other key"; exit 1; }
key=out/sign/release.pub
ok cosign verify --key "$key" --insecure-ignore-tlog $http "$ref"
ok cosign verify-attestation --key "$key" --insecure-ignore-tlog $http --type spdxjson "$ref"
ok cosign verify-attestation --key "$key" --insecure-ignore-tlog $http --type slsaprovenance1 "$ref"
no "accepted signatures do not match threshold" cosign verify --key "$HOME/other.pub" --insecure-ignore-tlog $http "$ref"
n="$(cosign verify-attestation --key "$key" --insecure-ignore-tlog $http --type spdxjson "$ref" 2>/dev/null | grep -c '"payload"')"
if [ "$n" = 2 ]; then echo "two SBOM attestations, one per platform"; else echo "error: $n SBOM attestations, not 2"; bad=1; fi
payload="$(cosign verify-attestation --key "$key" --insecure-ignore-tlog $http --type slsaprovenance1 "$ref" 2>/dev/null |
  sed -n 's/.*"payload":"\([^"]*\)".*/\1/p' | head -1 | base64 -d 2>/dev/null)"
case "$payload" in
  *"\"gitCommit\":\"$CI_COMMIT_SHA\""*) echo "the provenance names commit $CI_COMMIT_SHA" ;;
  *) echo "error: the provenance does not name commit $CI_COMMIT_SHA"; bad=1 ;;
esac
case "$payload" in
  *"urn:agentic-platform:ci-components:library-release@"*) echo "its build type is library-release's" ;;
  *) echo "error: the provenance's build type is not library-release's"; bad=1 ;;
esac
exit "$bad"
