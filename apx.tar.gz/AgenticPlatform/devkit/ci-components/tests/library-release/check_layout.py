"""The scratch image library-release:build made, read from its OCI layout:
an index of exactly linux/amd64 and linux/arm64, each an image manifest
with one gzip layer, every layer holding exactly the artifact directory's
files at its root, artifact.yaml the released copy with this pipeline's
provenance, and the index the digest the build recorded.

Usage: python3 -I check_layout.py <build output dir> <library dir> <release tag>
"""

import gzip
import io
import json
import os
import sys
import tarfile

LAYER = "application/vnd.oci.image.layer.v1.tar+gzip"


def blob(layout, digest):
    with open(os.path.join(layout, "blobs", "sha256", digest.removeprefix("sha256:")), "rb") as f:
        return f.read()


def main(out, library, tag):
    layout = os.path.join(out, "image")
    with open(os.path.join(out, "image.json")) as f:
        want = json.load(f)["containerimage.digest"]
    with open(os.path.join(layout, "index.json")) as f:
        top = json.load(f)
    digests = [m["digest"] for m in top["manifests"]]
    assert digests == [want], f"the layout's index.json names {digests}, not the build's {want}"
    index = json.loads(blob(layout, want))
    platforms = sorted(f"{m['platform']['os']}/{m['platform']['architecture']}" for m in index["manifests"])
    assert platforms == ["linux/amd64", "linux/arm64"], f"platforms {platforms}"
    kind, name, _ = tag.split("/")
    source = os.path.join(library, kind + "s", name)
    expected = sorted(os.listdir(source))
    for m in index["manifests"]:
        manifest = json.loads(blob(layout, m["digest"]))
        layers = manifest["layers"]
        assert len(layers) == 1 and layers[0]["mediaType"] == LAYER, f"{m['platform']}: layers {layers}"
        with tarfile.open(fileobj=io.BytesIO(gzip.decompress(blob(layout, layers[0]["digest"])))) as t:
            members = {i.name.removeprefix("./"): i for i in t.getmembers() if i.name not in (".", "./")}
            files = sorted(n for n, i in members.items() if i.isfile())
            assert files == expected, f"{m['platform']}: files {files}, want {expected}"
            assert all(i.isfile() or i.isdir() for i in members.values()), "a link or special file in the layer"
            assert all(not n.startswith("/") and ".." not in n.split("/") for n in members), "a path leaving the root"
            released = t.extractfile(members["artifact.yaml"]).read().decode()
        for line in ("provenance:", f"commit: {os.environ['CI_COMMIT_SHA']}", f"pipeline_id: {os.environ['CI_PIPELINE_ID']}"):
            assert line in released, f"{m['platform']}: artifact.yaml lacks {line!r}:\n{released}"
        print(f"{m['platform']['os']}/{m['platform']['architecture']}: one layer {layers[0]['digest']}, files {files}")
    print(f"{tag}: index {want}, amd64 and arm64, artifact.yaml with this pipeline's provenance")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(*sys.argv[1:])
