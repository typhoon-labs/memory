#!/bin/sh
# sign's attest mode, after it ran on main: the fixture app's conformance
# attestation verifies with the conformance key's public key and names this
# component's commit; the release key is refused where the conformance key
# is required, either way round (TM13): it finds no conformance
# attestation of its own on the fixture app, and a conformance attestation
# the release key signs on the kagent fixture's skill is refused with the
# conformance key, while the release key shows that it is there. Runs in
# the cosign image (busybox), as root, after .agentic-sign:aws's
# before_script with the release stand-in's key (SIGN_KEY), with
# WORKLOAD_IMAGE from build:publish, sign:image's out/sign/signed.txt and
# sign:attest's out/sign/attest/.
set -u
http="--allow-http-registry"
ref="$WORKLOAD_IMAGE"
type=urn:agentic-platform:attestation:conformance:v1
conformance=out/sign/attest/key.pub
release=out/sign/release.pub
bad=0
ok() {
  if "$@" > "$HOME/out" 2>&1; then echo "passes, as it must: $*"; else echo "error: refused, but must pass: $*"; tail -3 "$HOME/out"; bad=1; fi
}
no() { # no <the refusal's reason, a grep pattern> <command>...
  reason="$1"; shift
  if "$@" > "$HOME/out" 2>&1; then
    echo "error: passes, but must be refused: $*"; bad=1
  elif grep -q -- "$reason" "$HOME/out"; then
    echo "refused, as it must be: $* -- $reason"
  else
    echo "error: refused, but not for '$reason': $*"; tail -2 "$HOME/out"; bad=1
  fi
}
cmp -s "$conformance" "$release" && { echo "error: the two stand-in keys are one key"; exit 1; }

# The conformance key's attestation, and what it holds.
ok cosign verify-attestation --key "$conformance" --insecure-ignore-tlog $http --type "$type" "$ref"
payload="$(cosign verify-attestation --key "$conformance" --insecure-ignore-tlog $http --type "$type" "$ref" 2>/dev/null |
  sed -n 's/.*"payload":"\([^"]*\)".*/\1/p' | head -1 | base64 -d 2>/dev/null)"
case "$payload" in
  *"\"predicateType\":\"$type\""*"\"name\":\"sign\""*) echo "the statement is of type $type and names the sign component" ;;
  *) echo "error: the statement's type or component: $payload" | cut -c1-400; bad=1 ;;
esac
case "$payload" in
  *"\"sha\":\"$CI_COMMIT_SHA\""*) echo "its component's sha is this commit, $CI_COMMIT_SHA" ;;
  *) echo "error: its component does not name commit $CI_COMMIT_SHA"; bad=1 ;;
esac

# The release key where the conformance key is required.
no "none of the attestations matched the predicate type" \
  cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type "$type" "$ref"
other="$(grep -v -F "$ref" out/sign/signed.txt | head -1)"
[ -n "$other" ] || { echo "error: sign:image signed nothing but the fixture app"; exit 1; }
cosign attest --key "$SIGN_KEY" --signing-config out/sign/signing-config.json $http -y \
  --type "$type" --predicate out/sign/attest/predicate.json "$other" > "$HOME/attest.out" 2>&1 ||
  { echo "error: could not attest $other with the release stand-in"; tail -3 "$HOME/attest.out"; exit 1; }
echo "attested $type on $other with the release stand-in's key"
no "accepted signatures do not match threshold" \
  cosign verify-attestation --key "$conformance" --insecure-ignore-tlog $http --type "$type" "$other"
ok cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type "$type" "$other"
exit "$bad"
