#!/bin/sh
# The sign component's checks, after it ran on main: what it signed verifies
# with the release key's public key, and the same with another key, a type
# never attested, or a changed file, is refused. Runs in the cosign image
# (busybox), with WORKLOAD_IMAGE from build:publish and the sign jobs'
# artifacts under out/sign/.
set -u
http="--allow-http-registry"
ref="$WORKLOAD_IMAGE"
blob="out/test-blobs/agentctl-fixture"
bundle="out/sign/blobs/agentctl-fixture.sigstore.json"
export HOME="$(mktemp -d)"
export TUF_ROOT="$HOME/tuf"
bad=0
ok() {
  if "$@" > "$HOME/out" 2>&1; then echo "passes, as it must: $*"; else echo "error: refused, but must pass: $*"; tail -3 "$HOME/out"; bad=1; fi
}
no() { # no <the refusal's reason, a grep pattern> <command>...
  reason="$1"; shift
  if "$@" > "$HOME/out" 2>&1; then
    echo "error: passes, but must be refused: $*"; bad=1
  elif grep -q -- "$reason" "$HOME/out"; then
    echo "refused, as it must be: $* -- $reason"
  else
    echo "error: refused, but not for '$reason': $*"; tail -2 "$HOME/out"; bad=1
  fi
}
threshold="accepted signatures do not match threshold"
asn1="invalid signature when validating ASN.1 encoded signature"
COSIGN_PASSWORD="" cosign generate-key-pair --output-key-prefix "$HOME/other" > /dev/null 2>&1 || { echo "error: no other key"; exit 1; }
other="$HOME/other.pub"
release=out/sign/release.pub

ok cosign verify --key "$release" --insecure-ignore-tlog $http "$ref"
ok cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type spdxjson "$ref"
ok cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type slsaprovenance1 "$ref"
no "$threshold" cosign verify --key "$other" --insecure-ignore-tlog $http "$ref"
no "$threshold" cosign verify-attestation --key "$other" --insecure-ignore-tlog $http --type spdxjson "$ref"
no "$threshold" cosign verify-attestation --key "$other" --insecure-ignore-tlog $http --type slsaprovenance1 "$ref"
no "none of the attestations matched the predicate type: cyclonedx" cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type cyclonedx "$ref"

# Everything sign:image signed, the skill and the packaged definition of
# kagent-package's fixture among them, verifies with the key.
while read -r signed; do
  [ -n "$signed" ] || continue
  ok cosign verify --key "$release" --insecure-ignore-tlog $http "$signed"
  ok cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type slsaprovenance1 "$signed"
done < out/sign/signed.txt
[ "$(grep -c . out/sign/signed.txt)" -ge 3 ] || { echo "error: sign signed fewer than the image, the skill and the definition"; bad=1; }

# One SPDX SBOM per platform on the index's digest, and the provenance
# naming this commit.
n="$(cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type spdxjson "$ref" 2>/dev/null | grep -c '"payload"')"
if [ "$n" = 2 ]; then echo "two SBOM attestations, one per platform"; else echo "error: $n SBOM attestations, not 2"; bad=1; fi
payload="$(cosign verify-attestation --key "$release" --insecure-ignore-tlog $http --type slsaprovenance1 "$ref" 2>/dev/null |
  sed -n 's/.*"payload":"\([^"]*\)".*/\1/p' | head -1 | base64 -d 2>/dev/null)"
case "$payload" in
  *"\"gitCommit\":\"$CI_COMMIT_SHA\""*) echo "the provenance names commit $CI_COMMIT_SHA" ;;
  *) echo "error: the provenance does not name commit $CI_COMMIT_SHA"; bad=1 ;;
esac

ok cosign verify-blob --key "$release" --insecure-ignore-tlog --bundle "$bundle" "$blob"
no "$asn1" cosign verify-blob --key "$other" --insecure-ignore-tlog --bundle "$bundle" "$blob"
cp "$blob" "$HOME/changed" && printf 'x' >> "$HOME/changed"
no "$asn1" cosign verify-blob --key "$release" --insecure-ignore-tlog --bundle "$bundle" "$HOME/changed"

# Nothing in the bundles points at a transparency log or a timestamp authority.
if grep -q '"tlogEntries":\[{' "$bundle" || grep -q 'timestampVerificationData":{"rfc3161' "$bundle"; then
  echo "error: the blob's bundle carries a log entry or a timestamp"; bad=1
else
  echo "the blob's bundle carries no log entry and no timestamp"
fi
exit "$bad"
