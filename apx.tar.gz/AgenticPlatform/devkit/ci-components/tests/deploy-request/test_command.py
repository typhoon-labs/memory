"""deploy-request's command.sh, as its job runs it: the line for a container
workload names its image, and for a kagent agent its packaged definition,
by digest; each refusal is made by one change, beside that twin, and
writes nothing.

Usage, from the repository root: python3 -I tests/deploy-request/test_command.py
"""

import os
import subprocess
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
COMMAND = os.path.join(ROOT, "templates", "deploy-request", "command.sh")
IMAGE = "floci:4566/000000000000/us-east-1/workloads/reference/reference-mcp@sha256:" + "ab" * 32
DEFINITION = "floci:4566/000000000000/us-east-1/workloads/reference/reference-notes-agent@sha256:" + "cd" * 32
OK = {"environment": "local", "project": "example/agentic-platform/workloads/reference/reference-mcp",
      "tag": "v0.1.2", "name": "reference-mcp", "runtime": "container", "ref": IMAGE}


class Command(unittest.TestCase):
    def run_command(self, **change):
        args = dict(OK, **change)
        out = os.path.join(tempfile.mkdtemp(), "out", "command.txt")
        r = subprocess.run(["sh", COMMAND, out, args["environment"], args["project"], args["tag"], args["name"],
                            args["runtime"], args["ref"]], capture_output=True, text=True)
        written = open(out).read() if os.path.exists(out) else None
        return r.returncode, r.stdout + r.stderr, written

    def test_container(self):
        status, out, written = self.run_command()
        self.assertEqual(status, 0, out)
        line = ("agentctl deploy request --environment local --project example/agentic-platform/workloads/reference/"
                f"reference-mcp --tag v0.1.2 --workload reference-mcp --image {IMAGE}")
        self.assertEqual(written, line + "\n")
        self.assertIn("    " + line, out)

    def test_kagent(self):
        status, out, written = self.run_command(name="reference-notes-agent", runtime="kagent", ref=DEFINITION,
                                                tag="reference-notes-agent/v0.2.0")
        self.assertEqual(status, 0, out)
        self.assertTrue(written.endswith(f"--workload reference-notes-agent --definition {DEFINITION}\n"), written)

    def refused(self, message, **change):
        status, out, written = self.run_command(**change)
        self.assertEqual(status, 2, out)
        self.assertIn(message, out)
        self.assertIsNone(written, "a refused request wrote its line")

    def test_refusals(self):
        self.refused("no environment", environment="$AGENTIC_ENVIRONMENT")
        self.refused("no environment", environment="")
        self.refused("is not a name", environment="Local Build")
        self.refused("not a project path", project="reference-mcp")
        self.refused("no release tag", tag="")
        self.refused("is not vX.Y.Z", tag="p3086000000")
        self.refused("is not lowercase kebab-case", name="")
        self.refused("a workflow (runtime pipeline) is not deployed", runtime="pipeline")
        self.refused("is not container or kagent", runtime="")
        self.refused("must export it", ref="$WORKLOAD_IMAGE")
        self.refused("pins a digest", ref=IMAGE.split("@")[0] + ":v0.1.2")
        self.refused("pins a digest", ref="sha256:" + "ab" * 32)


if __name__ == "__main__":
    unittest.main(verbosity=1)
