"""The umbrella's test fixture: prints the workload.yaml the build copied into the image."""
print(open("/etc/agentic/workload.yaml").read())
