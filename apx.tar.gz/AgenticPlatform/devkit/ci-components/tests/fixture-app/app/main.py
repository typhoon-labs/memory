"""The build component's test fixture: answers with the machine it runs on and the
compiled pydantic-core module it loaded, so a test can tell each platform's image
carries its own architecture's wheels."""
import platform
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

import pydantic
import pydantic_core


class Answer(pydantic.BaseModel):
    machine: str
    python: str
    pydantic: str
    pydantic_core_so: str


def answer() -> bytes:
    return Answer(
        machine=platform.machine(),
        python=platform.python_version(),
        pydantic=pydantic.VERSION,
        pydantic_core_so=pydantic_core._pydantic_core.__file__.rsplit("/", 1)[-1],
    ).model_dump_json().encode()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = answer()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    if sys.argv[1:] == ["--once"]:
        print(answer().decode())
    else:
        HTTPServer(("0.0.0.0", 8000), Handler).serve_forever()
