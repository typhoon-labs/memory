"""Checks the step component's three test runs against the stub of agentctl.

Run from the repository root after step:test-ok, step:test-limit and
step:test-human: python3 -I tests/step/verify.py
"""

import json
import os
import sys

TASK = f"gitlab-{os.environ['CI_PROJECT_ID']}-{os.environ['CI_PIPELINE_ID']}"
AUDIENCE = "https://keycloak.agentic.internal/realms/agentic"
EXPECT = {
    "test-ok": lambda o: o.get("title") and o.get("summary"),
    "test-limit": lambda o: o.get("error") == "limit_exceeded" and o.get("task_id") == TASK,
    "test-human": lambda o: o.get("error") == "step_failed" and o.get("on_failure") == "human",
}


def load(path):
    with open(path) as f:
        return json.load(f)


problems = []
for name, ok in EXPECT.items():
    out = f"out/step/{name}"
    try:
        record, output = load(f"{out}/stub-record.json"), load(f"{out}/output.json")
    except (OSError, ValueError) as e:
        problems.append(f"{name}: {e}")
        continue
    if record["problems"]:
        problems.append(f"{name}: the stub saw {record['problems']}")
    if not ok(output):
        problems.append(f"{name}: unexpected output {output}")
    if record["task_id"] != TASK or record["id_token"].get("aud") != AUDIENCE or record["id_token"].get("iss") != "https://gitlab.com":
        problems.append(f"{name}: task {record['task_id']}, ID token {record['id_token']}")
    if record["argv"][:2] != ["step", "run"] or "--workload" not in record["argv"]:
        problems.append(f"{name}: argv {record['argv']}")
    for root, _, files in os.walk(out):
        for f in files:
            with open(os.path.join(root, f), errors="replace") as fh:
                if "eyJ" in fh.read():
                    problems.append(f"{name}: {f} holds something shaped like a token")
    print(f"{name}: {json.dumps(output)}")
for p in problems:
    print(f"error: {p}", file=sys.stderr)
sys.exit(1 if problems else 0)
