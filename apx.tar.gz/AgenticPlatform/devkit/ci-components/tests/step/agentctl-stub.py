"""A stand-in for agentctl, for the step component's tests, until agentctl exists.

The step component runs it as `agentctl step run --definition <file> --input
<file> --output <file> [--workload <file>] [--step-command <command>]`. It
checks what agent-sdk's spec/step/command.json and the component promise:
absolute paths that exist, AGENTIC_GATEWAY_URL, AGENTIC_TOKEN_COMMAND as a
JSON array of strings, the task and workflow headers' values by their
patterns (spec/headers/headers.json), and the job's GitLab ID token in a file
only its user reads, for the audience the test asked. It records what it saw
beside the output, without the token, then behaves as the input's "behave"
asks: ok (0), stop (1), limit (3), human (4) or invalid (5).
"""

import base64
import json
import os
import re
import stat
import sys

TASK_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
WORKFLOW_NAME = re.compile(r"^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$")
WORKFLOW_VERSION = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$")
OUTCOMES = {
    "ok": (0, {"title": "Release 1.0.0", "summary": "The stub's output."}),
    "stop": (1, {"error": "step_failed", "reason": "output_invalid", "on_failure": "stop"}),
    "limit": (3, {"error": "limit_exceeded", "limit": "tokens", "cap": 20000, "used": 21342,
                  "task_id": None, "message": "The task used 21342 tokens, past its cap of 20000."}),
    "human": (4, {"error": "step_failed", "reason": "model_error", "on_failure": "human"}),
    "invalid": (5, {"error": "step_invalid", "reason": "input_invalid"}),
}


def claims(token):
    payload = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))


def main(argv):
    problems = []
    if argv[:2] != ["step", "run"]:
        print(f"agentctl stub: not 'step run': {argv}", file=sys.stderr)
        return 2
    args = dict(zip(argv[2::2], argv[3::2]))
    for flag in ("--definition", "--input", "--output"):
        if not os.path.isabs(args.get(flag, "")):
            problems.append(f"{flag} is not an absolute path: {args.get(flag)!r}")
    for flag in ("--definition", "--input", "--workload"):
        if flag in args and not os.path.isfile(args[flag]):
            problems.append(f"{flag} {args[flag]} does not exist")
    env = os.environ
    if not env.get("AGENTIC_GATEWAY_URL") or env["AGENTIC_GATEWAY_URL"].endswith("/"):
        problems.append("AGENTIC_GATEWAY_URL is empty or ends with a slash")
    try:
        command = json.loads(env.get("AGENTIC_TOKEN_COMMAND", ""))
        if not (isinstance(command, list) and command and all(isinstance(w, str) for w in command)):
            raise ValueError
    except ValueError:
        problems.append("AGENTIC_TOKEN_COMMAND is not a JSON array of strings")
    for name, pattern in (("AGENTIC_TASK_ID", TASK_ID), ("AGENTIC_WORKFLOW_NAME", WORKFLOW_NAME),
                          ("AGENTIC_WORKFLOW_VERSION", WORKFLOW_VERSION)):
        if not pattern.match(env.get(name, "")):
            problems.append(f"{name} {env.get(name)!r} does not match {pattern.pattern}")
    if "AGENTCTL_ID_TOKEN" in env:
        problems.append("the ID token is still in the environment")
    token_file = env.get("AGENTCTL_ID_TOKEN_FILE", "")
    seen_token = {}
    try:
        mode = stat.S_IMODE(os.stat(token_file).st_mode)
        if mode & 0o077:
            problems.append(f"the ID token file is mode {oct(mode)}, readable by others")
        with open(token_file) as f:
            c = claims(f.read().strip())
        seen_token = {"iss": c.get("iss"), "aud": c.get("aud"), "has_sub": bool(c.get("sub"))}
        if c.get("aud") != env.get("STUB_EXPECT_AUDIENCE"):
            problems.append(f"the ID token's audience is {c.get('aud')!r}, not {env.get('STUB_EXPECT_AUDIENCE')!r}")
    except (OSError, ValueError, IndexError) as e:
        problems.append(f"no readable GitLab ID token in AGENTCTL_ID_TOKEN_FILE: {e}")
    if not env.get("AGENTCTL_CLIENT_ID"):
        problems.append("AGENTCTL_CLIENT_ID is empty")

    out = args.get("--output", "")
    record = {
        "argv": [a if not os.path.isabs(a) else os.path.relpath(a, env.get("CI_PROJECT_DIR", "/")) for a in argv],
        "gateway": env.get("AGENTIC_GATEWAY_URL"), "token_command": env.get("AGENTIC_TOKEN_COMMAND"),
        "task_id": env.get("AGENTIC_TASK_ID"), "workflow": [env.get("AGENTIC_WORKFLOW_NAME"), env.get("AGENTIC_WORKFLOW_VERSION")],
        "ca_file": env.get("AGENTIC_CA_FILE"), "client_id": env.get("AGENTCTL_CLIENT_ID"), "id_token": seen_token,
        "problems": problems,
    }
    if out:
        with open(os.path.join(os.path.dirname(out), "stub-record.json"), "w") as f:
            json.dump(record, f, indent=2)
    if problems:
        for p in problems:
            print(f"agentctl stub: {p}", file=sys.stderr)
        return 2
    with open(args["--input"]) as f:
        behave = json.load(f).get("behave", "ok")
    status, result = OUTCOMES[behave]
    if behave == "limit":
        result["task_id"] = env["AGENTIC_TASK_ID"]
    with open(out, "w") as f:
        json.dump(result, f)
    print(f"agentctl stub: step run as {behave}, exit {status}")
    return status


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
