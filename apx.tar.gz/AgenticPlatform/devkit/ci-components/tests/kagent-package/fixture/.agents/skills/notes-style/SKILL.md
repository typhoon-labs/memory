---
name: notes-style
description: How to quote a note in an answer.
---

Quote a note by its title and its first line, then link it by its ID.
