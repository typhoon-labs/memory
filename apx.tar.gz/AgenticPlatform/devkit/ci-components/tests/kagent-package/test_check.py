"""Tests of kagent-package's check: each refusal beside its allowed twin.

Run from the repository root: python3 -I tests/kagent-package/test_check.py
"""

import copy
import importlib.util
import io
import json
import os
import sys
import tempfile
import threading
import unittest
from contextlib import redirect_stderr, redirect_stdout
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CHECKER = os.path.join(ROOT, "templates", "kagent-package", "checker")
spec = importlib.util.spec_from_file_location("check", os.path.join(CHECKER, "check.py"))
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)



def load(path):
    with open(path) as f:
        return json.load(f)


def dump(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f)


SCHEMAS = {kind: load(os.path.join(CHECKER, "schemas", f)) for kind, f in check.SCHEMAS.items()}
DIGEST = "sha256:" + "a" * 64
LISTINGS = {"notes-mcp": check.tools_of({"tools": [
    {"name": "list_notes", "annotations": {"readOnlyHint": True}},
    {"name": "get_note", "annotations": {"readOnlyHint": True}},
    {"name": "add_note", "annotations": {"readOnlyHint": False, "destructiveHint": True}},
    {"name": "touch_note"},
]}, "test")}
AGENT = {
    "apiVersion": "api.kagent.dev/v1alpha3",
    "kind": "Agent",
    "metadata": {"name": "notes-agent", "labels": {"app": "notes"}},
    "spec": {
        "harnessRef": {"name": "notes-agent"},
        "template": {"inline": {
            "description": "Answers questions about notes.",
            "modelConfig": {"name": "notes-agent"},
            "systemPrompt": "Answer from the notes.",
            "tools": [
                {"mcp": {"server": {"kind": "RemoteMCPServer", "name": "notes-mcp"}, "tools": ["list_notes", "get_note"]}},
                {"mcp": {"server": {"kind": "RemoteMCPServer", "name": "notes-mcp"}, "tools": ["add_note"],
                         "requireApproval": True}},
            ],
            "skills": [{"name": "notes-style", "source": {"oci": f"registry.example/skills/notes-style@{DIGEST}"}}],
        }},
    },
}


def agent(edit=None):
    d = copy.deepcopy(AGENT)
    if edit:
        edit(d, d["spec"]["template"]["inline"])
    return d


def codes(definition, listings=LISTINGS, local=(), prompt=None, schemas=SCHEMAS):
    return sorted({c for c, _, _ in check.check(definition, schemas, listings, local, prompt)})


class Accepted(unittest.TestCase):
    def test_the_reference_shape_is_accepted(self):
        self.assertEqual(check.check(agent(), SCHEMAS, LISTINGS), [])

    def test_an_agent_template_is_accepted(self):
        inline = agent()["spec"]["template"]["inline"]
        template = {"apiVersion": "api.kagent.dev/v1alpha3", "kind": "AgentTemplate",
                    "metadata": {"name": "notes-agent"}, "spec": inline}
        self.assertEqual(codes(template), [])


class Schema(unittest.TestCase):
    def test_a_misspelt_field_is_refused(self):
        def edit(d, t):
            t["tools"][1]["mcp"]["requireAproval"] = t["tools"][1]["mcp"].pop("requireApproval")
        self.assertIn("schema", codes(agent(edit)))

    def test_a_wrong_type_is_refused(self):
        self.assertIn("schema", codes(agent(lambda d, t: t.update(tools={"mcp": {}}))))

    def test_a_cel_rule_is_enforced(self):
        # Both an inline template and a reference: the CRD's rule allows exactly one.
        self.assertIn("schema", codes(agent(lambda d, t: d["spec"]["template"].update(ref={"name": "x"}))))
        # Its twin: the server reference's kind must be RemoteMCPServer.
        self.assertIn("schema", codes(agent(lambda d, t: t["tools"][0]["mcp"]["server"].update(kind="Service"))))

    def test_an_unknown_cel_rule_fails_closed(self):
        schemas = copy.deepcopy(SCHEMAS)
        schemas["Agent"]["properties"]["spec"].setdefault("x-kubernetes-validations", []).append(
            {"rule": "self.size() < 3", "message": "new"})
        self.assertIn("schema", codes(agent(), schemas=schemas))
        self.assertEqual(codes(agent()), [])

    def test_another_api_version_is_refused(self):
        self.assertEqual(codes(agent(lambda d, t: d.update(apiVersion="kagent.dev/v1alpha2"))), ["schema"])

    def test_metadata_beyond_name_labels_and_annotations_is_refused(self):
        self.assertIn("schema", codes(agent(lambda d, t: d["metadata"].update(generateName="x-"))))
        self.assertIn("schema", codes(agent(lambda d, t: d["metadata"].update(name="Not_A_Name"))))
        self.assertIn("schema", codes(agent(lambda d, t: d.update(status={}))))


class Template(unittest.TestCase):
    def test_a_referenced_template_is_refused(self):
        d = agent(lambda d, t: d["spec"].update(template={"ref": {"name": "notes"}}))
        self.assertEqual(codes(d), ["not-inline"])

    def test_a_subagent_is_refused(self):
        sub = {"subAgent": {"name": "helper", "description": "helps", "templateRef": {"name": "helper"}}}
        self.assertEqual(codes(agent(lambda d, t: t["tools"].append(sub))), ["subagent"])


class Tools(unittest.TestCase):
    def test_a_server_without_a_listing_is_refused(self):
        self.assertEqual(codes(agent(), listings={}), ["server-unlisted"])

    def test_a_tool_its_server_does_not_list_is_refused(self):
        self.assertEqual(codes(agent(lambda d, t: t["tools"][0]["mcp"]["tools"].append("delete_all"))), ["tool-unlisted"])

    def test_a_listed_tool_is_accepted(self):
        self.assertEqual(codes(agent(lambda d, t: t["tools"][0]["mcp"]["tools"].remove("get_note"))), [])


class Approval(unittest.TestCase):
    def test_a_destructive_tool_without_require_approval_is_refused(self):
        self.assertEqual(codes(agent(lambda d, t: t["tools"][1]["mcp"].pop("requireApproval"))), ["approval-required"])

    def test_require_approval_false_is_refused(self):
        self.assertEqual(codes(agent(lambda d, t: t["tools"][1]["mcp"].update(requireApproval=False))), ["approval-required"])

    def test_a_destructive_tool_with_require_approval_is_accepted(self):
        self.assertEqual(codes(agent()), [])

    def test_a_tool_without_hints_counts_as_destructive(self):
        self.assertEqual(codes(agent(lambda d, t: t["tools"][0]["mcp"]["tools"].append("touch_note"))), ["approval-required"])

    def test_a_binding_of_every_tool_needs_approval_when_one_is_destructive(self):
        def every(d, t):
            t["tools"] = [{"mcp": {"server": {"kind": "RemoteMCPServer", "name": "notes-mcp"}}}]
        self.assertEqual(codes(agent(every)), ["approval-required"])

        def every_approved(d, t):
            every(d, t)
            t["tools"][0]["mcp"]["requireApproval"] = True
        self.assertEqual(codes(agent(every_approved)), [])

    def test_read_only_tools_need_no_approval(self):
        self.assertEqual(codes(agent(lambda d, t: t["tools"].pop(1))), [])


class Skills(unittest.TestCase):
    def test_a_skill_by_tag_is_refused(self):
        tagged = {"name": "notes-style", "source": {"oci": "registry.example/skills/notes-style:v1"}}
        self.assertIn("skill-digest", codes(agent(lambda d, t: t.update(skills=[tagged]))))

    def test_a_skill_by_digest_is_accepted(self):
        self.assertEqual(codes(agent()), [])

    def test_a_skill_from_git_is_refused(self):
        git = {"name": "notes-style", "source": {"git": {"url": "https://git.example/s", "commit": "a" * 40}}}
        self.assertEqual(codes(agent(lambda d, t: t.update(skills=[git]))), ["skill-source"])

    def test_a_plugin_by_tag_is_refused_and_by_digest_accepted(self):
        plugin = {"source": {"oci": "registry.example/plugins/p:v1"}, "skills": ["a"]}
        self.assertIn("skill-digest", codes(agent(lambda d, t: t.update(plugins=[plugin]))))
        pinned = {"source": {"oci": f"registry.example/plugins/p@{DIGEST}"}, "skills": ["a"]}
        self.assertEqual(codes(agent(lambda d, t: t.update(plugins=[pinned]))), [])

    def test_a_skill_named_like_a_local_one_is_refused(self):
        self.assertEqual(codes(agent(), local=["notes-style"]), ["skill-duplicate"])
        self.assertEqual(codes(agent(), local=["notes-format"]), [])

    def test_more_than_29_skill_images_are_refused(self):
        self.assertEqual(codes(agent(), local=[f"s{i}" for i in range(29)]), ["skills-too-many"])
        self.assertEqual(codes(agent(), local=[f"s{i}" for i in range(28)]), [])


class Prompt(unittest.TestCase):
    def test_a_prompt_file_and_a_prompt_of_its_own_are_refused(self):
        self.assertEqual(codes(agent(), prompt="From the file."), ["prompt-twice"])

    def test_a_prompt_file_alone_is_packaged(self):
        d = agent(lambda d, t: t.pop("systemPrompt"))
        self.assertEqual(codes(d, prompt="From the file."), [])
        self.assertEqual(check.packaged(d, "From the file.")["spec"]["template"]["inline"]["systemPrompt"], "From the file.")


class Listings(unittest.TestCase):
    def test_listing_shapes(self):
        tools = [{"name": "list_notes"}]
        self.assertEqual(list(check.tools_of({"tools": tools}, "x")), ["list_notes"])
        self.assertEqual(list(check.tools_of({"jsonrpc": "2.0", "id": 1, "result": {"tools": tools}}, "x")), ["list_notes"])
        self.assertEqual(list(check.tools_of({"name": "notes-mcp", "kind": "mcp-server", "tools": tools}, "x")), ["list_notes"])
        with self.assertRaises(check.InputError):
            check.tools_of({"tools": [{"title": "no name"}]}, "x")


class StubMCP(BaseHTTPRequestHandler):
    """A streamable HTTP MCP server: tools/list in two pages, as SSE or JSON."""
    sse = False
    seen = []

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        StubMCP.seen.append((body.get("method"), self.headers.get("Mcp-Session-Id"), self.headers.get("Authorization")))
        if "id" not in body:
            self.send_response(202)
            self.end_headers()
            return
        if body["method"] == "initialize":
            result = {"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}, "serverInfo": {"name": "stub"}}
        elif body["params"].get("cursor") == "page2":
            result = {"tools": [{"name": "add_note", "annotations": {"destructiveHint": True}}]}
        else:
            result = {"tools": [{"name": "list_notes", "annotations": {"readOnlyHint": True}}], "nextCursor": "page2"}
        answer = json.dumps({"jsonrpc": "2.0", "id": body["id"], "result": result})
        payload = f"event: message\ndata: {answer}\n\n" if StubMCP.sse else answer
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream" if StubMCP.sse else "application/json")
        self.send_header("Mcp-Session-Id", "s-1")
        self.end_headers()
        self.wfile.write(payload.encode())

    def log_message(self, *args):
        pass


class Live(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), StubMCP)
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()
        cls.url = f"http://127.0.0.1:{cls.server.server_port}/mcp"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_tools_list_over_json_and_sse(self):
        for sse in (False, True):
            StubMCP.sse, StubMCP.seen = sse, []
            listing = check.fetch_listing(self.url, token="t0k")
            self.assertEqual([t["name"] for t in listing["tools"]], ["list_notes", "add_note"])
            self.assertEqual([m for m, _, _ in StubMCP.seen], ["initialize", "notifications/initialized", "tools/list", "tools/list"])
            self.assertTrue(all(s == "s-1" for m, s, _ in StubMCP.seen[1:]))
            self.assertTrue(all(a == "Bearer t0k" for _, _, a in StubMCP.seen))

    def test_an_unreachable_server_is_an_input_error(self):
        with self.assertRaises(check.InputError):
            check.fetch_listing("http://127.0.0.1:9/mcp")


class Command(unittest.TestCase):
    def run_main(self, definition, *extra):
        with tempfile.TemporaryDirectory() as tmp:
            d = os.path.join(tmp, "agent.json")
            listing = os.path.join(tmp, "notes-mcp.json")
            out = os.path.join(tmp, "packaged.json")
            dump(d, definition)
            dump(listing, {"tools": [{"name": n, **v} for n, v in LISTINGS["notes-mcp"].items()]})
            args = ["--definition", d, "--schemas", os.path.join(CHECKER, "schemas"),
                    "--listing", f"notes-mcp={listing}", "--out", out, *extra]
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()) as err:
                status = check.main(args)
            packaged = load(out) if os.path.exists(out) else None
            return status, packaged, err.getvalue()

    def test_exit_status(self):
        status, packaged, _ = self.run_main(agent())
        self.assertEqual((status, packaged["metadata"]["name"]), (0, "notes-agent"))
        status, packaged, err = self.run_main(agent(lambda d, t: t["tools"][1]["mcp"].pop("requireApproval")))
        self.assertEqual((status, packaged), (1, None))
        self.assertIn("refused [approval-required]", err)
        status, _, _ = self.run_main(agent(), "--listing", "broken")
        self.assertEqual(status, 2)


if __name__ == "__main__":
    unittest.main(verbosity=1)
