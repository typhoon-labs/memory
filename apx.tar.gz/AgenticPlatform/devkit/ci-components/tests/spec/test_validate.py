"""templates/spec/validate.py against the spec's own test vectors: every
file under an examples/ directory of the vendored spec validates against
the schema its name gives (<case>.<schema>.json), and every file under an
invalid/ directory is refused, so the components' standard-library check
agrees with the spec on each of them. Also the bundle embed.py writes
checks as the directory does, and a schema keyword the check does not
know is an error, never ignored.

Usage, from the repository root: python3 -I tests/spec/test_validate.py
"""

import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(ROOT, "templates", "spec"))
import validate  # noqa: E402

SPEC = os.path.join(ROOT, "templates", "spec", "spec")


def vectors(kind):
    for root, _, files in os.walk(SPEC):
        if os.path.basename(root) != kind:
            continue
        area = os.path.relpath(os.path.dirname(root), SPEC).replace(os.sep, "/")
        for name in sorted(files):
            schema = name.rsplit(".", 2)[-2]
            yield os.path.join(root, name), f"{area}/{schema}.schema.json"


class Vectors(unittest.TestCase):
    def setUp(self):
        self.schemas = validate.Schemas(SPEC)

    def test_examples_validate(self):
        n = 0
        for path, schema in vectors("examples"):
            with self.subTest(path=os.path.relpath(path, SPEC)):
                self.assertEqual(self.schemas.check(validate.load_json(path), schema), [])
            n += 1
        self.assertGreater(n, 20)

    def test_invalid_refused(self):
        n = 0
        for path, schema in vectors("invalid"):
            with self.subTest(path=os.path.relpath(path, SPEC)):
                self.assertNotEqual(self.schemas.check(validate.load_json(path), schema), [])
            n += 1
        self.assertGreater(n, 50)

    def test_bundle_as_directory(self):
        with tempfile.TemporaryDirectory() as d:
            bundle = os.path.join(d, "bundle.json")
            with open(bundle, "w") as f:
                json.dump(self.schemas.docs, f)
            b = validate.Schemas(bundle)
            for path, schema in list(vectors("examples")) + list(vectors("invalid")):
                value = validate.load_json(path)
                self.assertEqual(b.check(value, schema), self.schemas.check(value, schema), path)

    def test_unknown_keyword_is_an_error(self):
        s = validate.Schemas(SPEC)
        s.docs["x.schema.json"] = {"type": "object", "unevaluatedProperties": False}
        with self.assertRaises(validate.InputError):
            s.check({}, "x.schema.json")

    def test_ecma_patterns(self):
        s = validate.Schemas(SPEC)
        s.docs["p.schema.json"] = {"type": "string", "pattern": "^[a-z]+\\d$"}
        self.assertEqual(s.check("ab1", "p.schema.json"), [])
        self.assertNotEqual(s.check("ab1\n", "p.schema.json"), [], "$ must end the string, as in ECMA-262")
        self.assertNotEqual(s.check("ab١", "p.schema.json"), [], "\\d is an ASCII digit, as in ECMA-262")

    def test_equality_is_json_equality(self):
        s = validate.Schemas(SPEC)
        s.docs["c.schema.json"] = {"const": 1}
        self.assertNotEqual(s.check(True, "c.schema.json"), [], "true is not 1")
        self.assertEqual(s.check(1.0, "c.schema.json"), [])


if __name__ == "__main__":
    unittest.main(verbosity=1)
