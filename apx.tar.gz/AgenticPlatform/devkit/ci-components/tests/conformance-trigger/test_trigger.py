"""conformance-trigger's trigger.py against a stand-in of GitLab's trigger
endpoint (standin.py): the trigger sends ref main, the token in the body
and the two inputs alone, and the stand-in answers with a pipeline; each
refusal is made by one change, beside that twin: an unset token, a
malformed digest or project ID, all refused before any request, and
GitLab refusing the token, which fails without printing it.

Usage, from the repository root: python3 -I tests/conformance-trigger/test_trigger.py
"""

import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
TRIGGER = os.path.join(ROOT, "templates", "conformance-trigger", "trigger.py")
sys.path.insert(0, HERE)
import standin  # noqa: E402

TOKEN = "glptt-0123456789abcdef0123"
DIGEST = "sha256:" + "ab" * 32


class Trigger(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.record = os.path.join(self.tmp, "requests.jsonl")
        self.server = standin.serve(0, TOKEN, self.record)
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        self.addCleanup(self.server.shutdown)
        self.api = f"http://127.0.0.1:{self.server.server_address[1]}/api/v4"

    def run_trigger(self, token=TOKEN, project="4242", workload="88996242", digest=DIGEST, api=None):
        env = {"PATH": os.environ.get("PATH", "")}
        if token is not None:
            env["CONFORMANCE_TRIGGER_TOKEN"] = token
        dotenv = os.path.join(self.tmp, "trigger.env")
        r = subprocess.run([sys.executable, "-I", TRIGGER, "--api", api or self.api, "--project", project, "--ref", "main",
                            "--workload-project", workload, "--digest", digest, "--dotenv", dotenv],
                           capture_output=True, text=True, env=env)
        return r.returncode, r.stdout + r.stderr, dotenv

    def requests(self):
        if not os.path.exists(self.record):
            return []
        with open(self.record) as f:
            return [json.loads(line) for line in f]

    def test_twin_started(self):
        status, out, dotenv = self.run_trigger()
        self.assertEqual(status, 0, out)
        self.assertNotIn(TOKEN, out)
        [req] = self.requests()
        self.assertEqual(req["status"], 201)
        self.assertEqual(req["fields"], ["inputs[digest]", "inputs[project_id]", "ref", "token"])
        self.assertEqual(req["inputs"], {"project_id": "88996242", "digest": DIGEST})
        self.assertTrue(req["token_matched"])
        self.assertFalse(req["token_in_url"])
        self.assertEqual(req["query"], "")
        with open(dotenv) as f:
            self.assertEqual(f.read(), "CONFORMANCE_PIPELINE_ID=3090004242\nCONFORMANCE_PIPELINE_URL="
                             "https://gitlab.example.com/example/infra/conformance/-/pipelines/3090004242\n")

    def refused_before_any_request(self, message, **kw):
        status, out, _ = self.run_trigger(**kw)
        self.assertEqual(status, 2, out)
        self.assertIn(message, out)
        self.assertEqual(self.requests(), [], "a refused input still sent a request")

    def test_token_unset(self):
        self.refused_before_any_request("AGENTIC_CONFORMANCE_TRIGGER_TOKEN is not set", token=None)
        self.refused_before_any_request("AGENTIC_CONFORMANCE_TRIGGER_TOKEN is not set", token="")
        self.refused_before_any_request("AGENTIC_CONFORMANCE_TRIGGER_TOKEN is not set", token="$AGENTIC_CONFORMANCE_TRIGGER_TOKEN")

    def test_digest(self):
        self.refused_before_any_request("is not sha256:<64 hex>", digest="sha256:abc")
        self.refused_before_any_request("is not sha256:<64 hex>", digest="v0.1.0")

    def test_projects(self):
        self.refused_before_any_request("is not a number: set AGENTIC_CONFORMANCE_PROJECT", project="$AGENTIC_CONFORMANCE_PROJECT")
        self.refused_before_any_request("the workload's project ID", workload="reference/reference-mcp")

    def test_token_refused(self):
        status, out, _ = self.run_trigger(token="glptt-wrong")
        self.assertEqual(status, 1, out)
        self.assertIn("HTTP 404", out)
        self.assertNotIn("glptt-wrong", out)
        [req] = self.requests()
        self.assertFalse(req["token_matched"])

    def test_unreachable(self):
        status, out, _ = self.run_trigger(api="http://127.0.0.1:9/api/v4")
        self.assertEqual(status, 1, out)
        self.assertIn("could not reach", out)


class Standin(unittest.TestCase):
    """The stand-in refuses what infra/conformance refuses, so the twin's
    pass above means something."""

    def test_refusals(self):
        ok = [("token", TOKEN), ("ref", "main"), ("inputs[project_id]", "1"), ("inputs[digest]", DIGEST)]
        path = "/api/v4/projects/4242/trigger/pipeline"
        self.assertEqual(standin.judge(path, "", ok, TOKEN)[0], 201)
        for name, fields, query in [
            ("a variable", ok + [("variables[LEVEL]", "L1")], ""),
            ("another input", ok + [("inputs[level]", "L1")], ""),
            ("a tag for a digest", [f for f in ok if f[0] != "inputs[digest]"] + [("inputs[digest]", "v0.1.0")], ""),
            ("another ref", [f for f in ok if f[0] != "ref"] + [("ref", "feature")], ""),
            ("a token in the URL", ok, "token=" + TOKEN),
        ]:
            self.assertEqual(standin.judge(path, query, fields, TOKEN)[0], 400, name)
        self.assertEqual(standin.judge(path, "", [("token", "x")] + ok[1:], TOKEN)[0], 404)


if __name__ == "__main__":
    unittest.main(verbosity=1)
