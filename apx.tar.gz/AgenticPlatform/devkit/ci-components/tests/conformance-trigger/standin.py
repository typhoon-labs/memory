"""A stand-in for GitLab's pipeline trigger endpoint as infra/conformance
answers it: POST /api/v4/projects/<id>/trigger/pipeline with a form body.
It refuses a wrong token (404, as GitLab answers one), a token in the URL,
any pipeline variable (infra/conformance allows none), a ref other than
main, and inputs other than project_id and digest or not matching their
patterns (400, as GitLab answers an input that breaks its spec:inputs);
otherwise it answers 201 with a pipeline. Each request is recorded, the
token as whether it matched, never its value.

Usage: python3 -I standin.py --port <port> --token <token> --record <file.jsonl> [--ready <file>]
"""

import json
import re
import sys
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PATH = re.compile(r"^/api/v4/projects/([1-9][0-9]*)/trigger/pipeline$")
INPUTS = {"project_id": re.compile(r"^[1-9][0-9]*$"), "digest": re.compile(r"^sha256:[0-9a-f]{64}$")}


def judge(path, query, fields, token):
    """(status, body, record) for one request."""
    record = {"path": path, "query": query, "fields": sorted(k for k, _ in fields),
              "token_matched": any(k == "token" and v == token for k, v in fields),
              "token_in_url": "token" in urllib.parse.parse_qs(query),
              "ref": next((v for k, v in fields if k == "ref"), None),
              "inputs": {k[len("inputs["):-1]: v for k, v in fields if k.startswith("inputs[")}}
    m = PATH.match(path)
    if not m:
        return 404, {"message": "404 Not Found"}, record
    record["project"] = int(m.group(1))
    if record["token_in_url"]:
        return 400, {"message": "the stand-in refuses a token in the URL"}, record
    if not record["token_matched"]:
        return 404, {"message": "404 Not Found"}, record
    if any(k.startswith("variables[") for k, _ in fields):
        return 400, {"message": {"base": ["Insufficient permissions to set pipeline variables"]}}, record
    if record["ref"] != "main":
        return 400, {"message": {"base": ["Reference not found"]}}, record
    unknown = sorted(set(record["inputs"]) - set(INPUTS))
    if unknown:
        return 400, {"message": {"base": [f"unknown input name provided: `{unknown[0]}`"]}}, record
    for name, pattern in INPUTS.items():
        if not pattern.match(record["inputs"].get(name, "")):
            return 400, {"message": {"base": [f"`{name}` input: provided value does not match required RegEx pattern"]}}, record
    pid = 3090000000 + record["project"]
    return 201, {"id": pid, "iid": 7, "project_id": record["project"], "ref": "main", "sha": "0" * 40,
                 "status": "created", "source": "trigger",
                 "web_url": f"https://gitlab.example.com/example/infra/conformance/-/pipelines/{pid}"}, record


def serve(port, token, record_file, ready=None):
    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            path, _, query = self.path.partition("?")
            length = int(self.headers.get("Content-Length") or 0)
            fields = urllib.parse.parse_qsl(self.rfile.read(length).decode(), keep_blank_values=True)
            status, body, record = judge(path, query, fields, token)
            record["status"] = status
            with open(record_file, "a") as f:
                f.write(json.dumps(record, sort_keys=True) + "\n")
            data = json.dumps(body).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    if ready:
        with open(ready, "w") as f:
            f.write(str(server.server_address[1]))
    return server


if __name__ == "__main__":
    args = dict(zip(sys.argv[1::2], sys.argv[2::2]))
    if not all(k in args for k in ("--port", "--token", "--record")):
        sys.exit(__doc__)
    serve(int(args["--port"]), args["--token"], args["--record"], args.get("--ready")).serve_forever()
