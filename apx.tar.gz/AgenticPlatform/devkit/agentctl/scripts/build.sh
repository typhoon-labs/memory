#!/bin/sh
# Build agentctl for Linux and macOS on amd64 and arm64, reproducibly: the
# same commit and Go toolchain give the same bytes wherever it is built.
#
#   -trimpath          no build paths in the binary
#   -buildvcs=false    no VCS stamp, which would change with the checkout's
#                      untracked files (a CI cache directory, for one)
#   -buildid=          no build ID, which the linker would otherwise derive
#                      from inputs that include the build's own paths
#   CGO_ENABLED=0      a static binary, with no C toolchain in the result
#
# The version is the release tag when there is one, else sha-<12> of the
# commit, the same form as the platform's image tags.
#
# Usage: scripts/build.sh OUTDIR
#   VERSION and COMMIT override what git says; in CI they come from
#   CI_COMMIT_TAG and CI_COMMIT_SHA.
# Writes OUTDIR/agentctl-<os>-<arch> and OUTDIR/SHA256SUMS.
set -eu

out=${1:?usage: scripts/build.sh OUTDIR}
root=$(cd "$(dirname "$0")/.." && pwd)

commit=${COMMIT:-${CI_COMMIT_SHA:-$(git -C "$root" rev-parse HEAD)}}
if [ -z "${VERSION:-}" ]; then
  VERSION=${CI_COMMIT_TAG:-sha-$(printf '%.12s' "$commit")}
fi
pkg=./cmd/agentctl

mkdir -p "$out"
out=$(cd "$out" && pwd)
cd "$root"
for target in linux/amd64 linux/arm64 darwin/amd64 darwin/arm64; do
  goos=${target%/*}
  goarch=${target#*/}
  CGO_ENABLED=0 GOOS=$goos GOARCH=$goarch go build \
    -trimpath -buildvcs=false \
    -ldflags "-s -w -buildid= -X main.version=$VERSION -X main.commit=$commit" \
    -o "$out/agentctl-$goos-$goarch" "$pkg"
done
cd "$out"
if command -v sha256sum >/dev/null; then sum="sha256sum"; else sum="shasum -a 256"; fi
$sum agentctl-* > SHA256SUMS
cat SHA256SUMS
