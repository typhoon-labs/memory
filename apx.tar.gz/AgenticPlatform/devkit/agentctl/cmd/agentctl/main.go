// Command agentctl is the platform's developer CLI (design/distribution.md,
// "agentctl, the thin organization CLI"). It wraps existing tools and never
// holds more rights than the person running it.
//
//	agentctl <command> [flags] [arguments]
//
// Run agentctl help for the commands.
package main

import (
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
	"syscall"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// Set at build time by scripts/build.sh: the release tag or sha-<12>, and
// the full commit.
var (
	version = "dev"
	commit  = "unknown"
)

// env is what a command may read from the process: its streams, its
// environment and its arguments. Tests build one of their own.
type env struct {
	ctx    context.Context
	stdin  io.Reader
	stdout io.Writer
	stderr io.Writer
	getenv func(string) string
	// environ is the whole environment, for commands that pass it on.
	environ func() []string
	// runner runs every external command; tests give a fake.
	runner execx.Runner
	// goos is runtime.GOOS; lookPath reports whether a command exists.
	goos     string
	lookPath func(string) bool
	// open hands a URL to a browser and reports whether it could.
	open func(url string) bool
	// self is agentctl's own executable, for commands that hand it on.
	self func() (string, error)
	// loopback, when set, says whether a name resolves to loopback here;
	// tests set it.
	loopback func(name string) bool
	// httpClient, when set, replaces the client for services other than
	// the realm; tests point it at fakes.
	httpClient *http.Client
}

type command struct {
	name    string
	summary string
	run     func(e *env, args []string) int
}

func commands() []command {
	return []command{
		{"catalog", "build the signed catalog index, publish it to Agentregistry, or report drift (catalog build|publish|drift)", runCatalog},
		{"conform", "run the conformance runner's image against a deployment", runConform},
		{"deploy", "open the merge request in environments that deploys a release (deploy request)", runDeploy},
		{"doctor", "check Claude Code's setup here and in this repository, with a fix for each failure", runDoctor},
		{"harness", "set Claude Code up for the platform's gateway (harness setup)", runHarness},
		{"install", "install library artifacts from the signed catalog index into this repository", runInstall},
		{"local", "build (up) or remove (down) the local platform with environments' bootstrap", runLocal},
		{"login", "sign in to the realm and keep the refresh token", runLogin},
		{"new", "generate a workload's project through workload-templates' generation job", runNew},
		{"remove", "remove installed library artifacts from this repository", runRemove},
		{"search", "search the signed catalog index", runSearch},
		{"show", "show one entry of the signed catalog index", runShow},
		{"step", "run one bounded workflow step with the SDK's step command (step run)", runStep},
		{"token", "print an access token for one route", runToken},
		{"update", "move installed library artifacts to the release the signed index holds", runUpdate},
		{"validate", "check workload.yaml, artifact.yaml or a step against agent-sdk's schemas", runValidate},
		{"version", "print agentctl's version", runVersion},
	}
}

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	e := &env{
		ctx: ctx, stdin: os.Stdin, stdout: os.Stdout, stderr: os.Stderr, getenv: os.Getenv, environ: os.Environ,
		runner: execx.OS{}, goos: runtime.GOOS,
		lookPath: func(name string) bool { _, err := exec.LookPath(name); return err == nil },
		self:     os.Executable,
	}
	e.open = func(url string) bool { return openBrowser(e, url) }
	code := dispatch(e, os.Args[1:])
	stop()
	os.Exit(code)
}

// dispatch runs one command. Exit codes: 0 done, 1 the command failed, 2
// agentctl could not run it (usage, setup). Some commands pass a child's
// status through, as their help says.
func dispatch(e *env, args []string) int {
	if len(args) == 0 || args[0] == "help" || args[0] == "-h" || args[0] == "--help" {
		usage(e.stdout)
		if len(args) == 0 {
			return 2
		}
		return 0
	}
	for _, c := range commands() {
		if c.name == args[0] {
			return c.run(e, args[1:])
		}
	}
	fmt.Fprintf(e.stderr, "agentctl: unknown command %q\n\n", args[0])
	usage(e.stderr)
	return 2
}

func usage(w io.Writer) {
	fmt.Fprintln(w, "agentctl: the agentic platform's developer CLI")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Usage: agentctl <command> [flags] [arguments]")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Commands:")
	for _, c := range commands() {
		fmt.Fprintf(w, "  %-12s %s\n", c.name, c.summary)
	}
	fmt.Fprintln(w)
	fmt.Fprintln(w, "agentctl <command> -h prints a command's flags.")
}

func runVersion(e *env, args []string) int {
	if len(args) > 0 {
		fmt.Fprintln(e.stderr, "usage: agentctl version")
		return 2
	}
	fmt.Fprintf(e.stdout, "agentctl %s\ncommit %s\n%s %s/%s\n", version, commit, runtime.Version(), runtime.GOOS, runtime.GOARCH)
	if s, err := spec.Vendored(); err == nil {
		fmt.Fprintf(e.stdout, "spec %s\n", s.Source)
	}
	return 0
}
