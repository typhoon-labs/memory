package main

import (
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/catalog"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/cosign"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/lock"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/oci"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/validate"
)

// The provenance attestation every library artifact carries, as the sign
// component writes it.
const provenanceType = "slsaprovenance1"

// installer installs library artifacts into one repository.
type installer struct {
	e    *env
	c    *catalogEnv
	root string
	lk   *lock.Lock
	key  string // the release key, as cosign takes it
}

func newInstaller(e *env, c *catalogEnv, dir string) (*installer, error) {
	root, err := filepath.Abs(dir)
	if err != nil {
		return nil, err
	}
	if fi, err := os.Stat(root); err != nil || !fi.IsDir() {
		return nil, fmt.Errorf("%s is not a directory", dir)
	}
	lk, err := lock.Load(c.spec, root)
	if err != nil {
		return nil, err
	}
	key, err := c.key(e, defaults.ReleaseKey)
	if err != nil {
		return nil, err
	}
	return &installer{e: e, c: c, root: root, lk: lk, key: key}, nil
}

// refusal is an artifact install will not take, with why.
type refusal struct{ msg string }

func (r *refusal) Error() string { return r.msg }

func refuse(format string, a ...any) error { return &refusal{fmt.Sprintf(format, a...)} }

// wanted parses NAME, NAME@X.Y.Z or NAME@sha256:<hex> against the index:
// the index holds one release of each name, which must be the one asked
// for, and a digest must be the one the index records for it.
func wanted(ix *catalog.Verified, arg string) (*catalog.Entry, error) {
	name, want, _ := strings.Cut(arg, "@")
	en := ix.Find(name)
	if en == nil {
		return nil, refuse("%s is not in the index %s", name, ix.From)
	}
	if !en.IsArtifact() {
		return nil, refuse("%s is a workload (%s), not a library artifact: reach it by its route, %s", name, en.Kind(), dash(en.Route))
	}
	switch {
	case want == "":
	case strings.HasPrefix(want, "sha256:"):
		_, digest, _ := strings.Cut(en.Reference, "@")
		if want != digest {
			return nil, refuse("refusing %s: the digest %s is not in the index, which records %s for %s %s", name, want, digest, name, en.Version)
		}
	case want != en.Version:
		return nil, refuse("refusing %s@%s: the index holds %s at %s alone", name, want, name, en.Version)
	}
	return en, nil
}

// install fetches one artifact by the index's digest, verifies it, and
// puts its canonical copy and links in place. Nothing is written before
// the signature and the provenance verify with the release key, and the
// copy and links replace earlier ones only where the lock file says
// agentctl put them.
func (in *installer) install(en *catalog.Entry) (lock.Artifact, error) {
	kind, name := en.Kind(), en.Name()
	ref, err := oci.ParseReference(en.Reference)
	if err != nil {
		return lock.Artifact{}, refuse("refusing %s: %v", name, err)
	}
	if !strings.HasPrefix(en.Reference, in.c.values.Registry+"/") {
		return lock.Artifact{}, refuse("refusing %s: %s is not in the %s registry, %s", name, en.Reference, in.c.values.Name, in.c.values.Registry)
	}
	a := lock.Artifact{Kind: kind, Name: name, Version: en.Version, Reference: en.Reference, Path: lock.CanonicalPath(kind, name)}
	if kind == "skill" {
		a.Links = []lock.Link{{Harness: "claude-code", Path: lock.ClaudeSkillLink(name)}}
	}
	if err := in.preflight(a); err != nil {
		return lock.Artifact{}, err
	}

	// Verify before writing anything.
	plain := plainHTTP(in.e, in.c.values)(ref.Host)
	if err := in.c.cosign.VerifyImage(in.e.ctx, in.key, en.Reference, plain); err != nil {
		if cosign.IsRefused(err) {
			return lock.Artifact{}, refuse("refusing %s, checked with %s: %v", name, in.c.keyDesc[defaults.ReleaseKey], err)
		}
		return lock.Artifact{}, err
	}
	sts, err := in.c.cosign.VerifyAttestation(in.e.ctx, in.key, en.Reference, provenanceType, plain)
	if err != nil {
		if cosign.IsRefused(err) {
			return lock.Artifact{}, refuse("refusing %s, checked with %s: %v", name, in.c.keyDesc[defaults.ReleaseKey], err)
		}
		return lock.Artifact{}, err
	}
	// Only SLSA v1 provenance counts as the provenance.
	if sts = cosign.Of(sts, cosign.ProvenanceType); len(sts) == 0 {
		return lock.Artifact{}, refuse("refusing %s, checked with %s: no %s attestation verifies", name, in.c.keyDesc[defaults.ReleaseKey], cosign.ProvenanceType)
	}
	if !slices.ContainsFunc(sts, func(st cosign.Statement) bool {
		return slices.Contains(cosign.ProvenanceCommits(st), en.Source.Commit)
	}) {
		var named []string
		for _, st := range sts {
			named = append(named, cosign.ProvenanceCommits(st)...)
		}
		return lock.Artifact{}, refuse("refusing %s: its provenance names commit %s, and the index %s", name, strings.Join(named, ", "), en.Source.Commit)
	}

	// Fetch by digest, every manifest and layer checked against its
	// digest, into a directory of agentctl's own beside the copy.
	parent := filepath.Join(in.root, filepath.Dir(filepath.FromSlash(a.Path)))
	if err := os.MkdirAll(parent, 0o755); err != nil {
		return lock.Artifact{}, err
	}
	staging, err := os.MkdirTemp(parent, ".agentctl-"+name+"-")
	if err != nil {
		return lock.Artifact{}, err
	}
	defer os.RemoveAll(staging)
	content := filepath.Join(staging, "content")
	if err := in.c.oras.Unpack(in.e.ctx, ref, content); err != nil {
		return lock.Artifact{}, refuse("refusing %s: %v", name, err)
	}
	if err := in.checkContent(en, content); err != nil {
		return lock.Artifact{}, err
	}

	// Put it in place: the old copy aside, the new one in, the old one
	// gone.
	canonical := filepath.Join(in.root, filepath.FromSlash(a.Path))
	if _, err := os.Lstat(canonical); err == nil {
		if err := os.Rename(canonical, filepath.Join(staging, "old")); err != nil {
			return lock.Artifact{}, err
		}
	}
	if err := os.Rename(content, canonical); err != nil {
		return lock.Artifact{}, err
	}
	for _, l := range a.Links {
		if err := in.link(a, l); err != nil {
			return lock.Artifact{}, err
		}
	}
	return a, nil
}

// preflight refuses to replace what agentctl did not put there.
func (in *installer) preflight(a lock.Artifact) error {
	old := in.lk.Find(a.Name)
	if old != nil && old.Kind != a.Kind {
		return refuse("refusing %s: the lock file has it as a %s, the index as a %s", a.Name, old.Kind, a.Kind)
	}
	canonical := filepath.Join(in.root, filepath.FromSlash(a.Path))
	if _, err := os.Lstat(canonical); err == nil && (old == nil || old.Path != a.Path) {
		return refuse("refusing %s: %s is there and the lock file does not name it, so agentctl did not put it there; move it away first", a.Name, a.Path)
	}
	for _, l := range a.Links {
		p := filepath.Join(in.root, filepath.FromSlash(l.Path))
		fi, err := os.Lstat(p)
		if errors.Is(err, fs.ErrNotExist) {
			continue
		}
		if err != nil {
			return err
		}
		if fi.Mode()&os.ModeSymlink == 0 || !in.pointsAt(l.Path, a.Path) {
			return refuse("refusing %s: %s is there and is not agentctl's link to %s; move it away first", a.Name, l.Path, a.Path)
		}
	}
	return nil
}

// target is a link's relative target: from .claude/skills/x to
// ../../.agents/skills/x.
func target(linkPath, canonical string) string {
	rel, _ := filepath.Rel(filepath.Dir(filepath.FromSlash(linkPath)), filepath.FromSlash(canonical))
	return rel
}

func (in *installer) pointsAt(linkPath, canonical string) bool {
	t, err := os.Readlink(filepath.Join(in.root, filepath.FromSlash(linkPath)))
	return err == nil && t == target(linkPath, canonical)
}

func (in *installer) link(a lock.Artifact, l lock.Link) error {
	p := filepath.Join(in.root, filepath.FromSlash(l.Path))
	if in.pointsAt(l.Path, a.Path) {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		return err
	}
	return os.Symlink(target(l.Path, a.Path), p)
}

// checkContent holds the artifact to its own artifact.yaml: there, valid,
// and the entry's kind, name and version; a skill has its SKILL.md.
func (in *installer) checkContent(en *catalog.Entry, dir string) error {
	data, err := os.ReadFile(filepath.Join(dir, "artifact.yaml"))
	if err != nil {
		return refuse("refusing %s: the artifact holds no artifact.yaml at its root", en.Name())
	}
	problems, err := validate.File(in.c.spec, "artifact", data)
	if err != nil {
		return refuse("refusing %s: its artifact.yaml: %v", en.Name(), err)
	}
	if len(problems) > 0 {
		return refuse("refusing %s: its artifact.yaml does not match %s: %s", en.Name(), spec.ArtifactSchema, problems[0])
	}
	v, _ := validate.Decode(data)
	m, _ := v.(map[string]any)
	for _, k := range []string{"kind", "name", "version"} {
		if m[k] != en.Metadata[k] {
			return refuse("refusing %s: its artifact.yaml's %s is %v, the index's %v", en.Name(), k, m[k], en.Metadata[k])
		}
	}
	if en.Kind() == "skill" {
		if fi, err := os.Stat(filepath.Join(dir, "SKILL.md")); err != nil || !fi.Mode().IsRegular() {
			return refuse("refusing %s: a skill without SKILL.md at its root", en.Name())
		}
	}
	return nil
}

func (in *installer) save() error { return in.lk.Save(in.c.spec, in.root) }

func describe(a lock.Artifact) string {
	_, digest, _ := strings.Cut(a.Reference, "@")
	s := fmt.Sprintf("%s %s %s (%s) at %s", a.Kind, a.Name, a.Version, digest, a.Path)
	for _, l := range a.Links {
		s += fmt.Sprintf(", linked from %s for %s", l.Path, l.Harness)
	}
	return s
}

// artifactFlags are install's and update's flags beside the catalog's.
func artifactFlags(e *env, name, usage string) (*flag.FlagSet, catalogFlags, *string) {
	fs := newFlags(e, name, usage)
	cf := addCatalogFlags(e, fs)
	dir := fs.String("dir", ".", "the repository's root, where .agents/ and .claude/ are")
	return fs, cf, dir
}

// runInstall installs library artifacts from the signed index.
func runInstall(e *env, args []string) int {
	fs, cf, dir := artifactFlags(e, "install", "install [flags] NAME[@VERSION|@sha256:DIGEST]...")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() == 0 {
		fs.Usage()
		return 2
	}
	c, err := newCatalogEnv(e, *cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer c.cleanup()
	in, err := newInstaller(e, c, *dir)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	ix, err := c.readIndex(e, cf)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	code := 0
	for _, arg := range fs.Args() {
		en, err := wanted(ix, arg)
		if err == nil {
			if en.Support() == "deprecated" {
				fmt.Fprintf(e.stderr, "agentctl: warning: %s is deprecated%s\n", en.Name(), deprecationNote(en))
			}
			var a lock.Artifact
			if a, err = in.install(en); err == nil {
				in.lk.Put(a)
				if err = in.save(); err == nil {
					fmt.Fprintf(e.stdout, "installed %s\n", describe(a))
					fmt.Fprintf(e.stderr, "verified %s: its signature and its provenance (commit %s) with %s\n", a.Name, en.Source.Commit, c.keyDesc[defaults.ReleaseKey])
					continue
				}
			}
		}
		fmt.Fprintf(e.stderr, "agentctl: %v\n", err)
		code = 1
	}
	return code
}

// runUpdate moves installed artifacts to the release the index holds.
func runUpdate(e *env, args []string) int {
	fs, cf, dir := artifactFlags(e, "update", "update [flags] [NAME...]")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	c, err := newCatalogEnv(e, *cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer c.cleanup()
	in, err := newInstaller(e, c, *dir)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	names := fs.Args()
	if len(names) == 0 {
		for _, a := range in.lk.Artifacts {
			names = append(names, a.Name)
		}
	}
	if len(names) == 0 {
		fmt.Fprintf(e.stderr, "nothing is installed: %s names no artifact\n", lock.File)
		return 0
	}
	ix, err := c.readIndex(e, cf)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	code := 0
	for _, name := range names {
		found := in.lk.Find(name)
		if found == nil {
			fmt.Fprintf(e.stderr, "agentctl: %s is not installed here: run agentctl install %s\n", name, name)
			code = 1
			continue
		}
		old := *found
		en := ix.Find(name)
		if en == nil || !en.IsArtifact() {
			fmt.Fprintf(e.stderr, "agentctl: %s is no longer in the index %s: kept at %s; it may be retired, see agentctl search\n", name, ix.From, old.Version)
			code = 1
			continue
		}
		if en.Reference == old.Reference {
			fmt.Fprintf(e.stdout, "%s %s is up to date\n", name, old.Version)
			continue
		}
		if en.Support() == "deprecated" {
			fmt.Fprintf(e.stderr, "agentctl: warning: %s is deprecated%s\n", name, deprecationNote(en))
		}
		a, err := in.install(en)
		if err == nil {
			in.lk.Put(a)
			err = in.save()
		}
		if err != nil {
			fmt.Fprintf(e.stderr, "agentctl: %v\n", err)
			code = 1
			continue
		}
		fmt.Fprintf(e.stdout, "updated %s from %s to %s\n", name, old.Version, describe(a))
	}
	return code
}

// runRemove removes installed artifacts: the canonical copy, the links
// agentctl made, and the lock file's entry. It needs no index.
func runRemove(e *env, args []string) int {
	fs := newFlags(e, "remove", "remove [flags] NAME...")
	dir := fs.String("dir", ".", "the repository's root, where .agents/ and .claude/ are")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() == 0 {
		fs.Usage()
		return 2
	}
	s, err := spec.Vendored()
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	root, err := filepath.Abs(*dir)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	lk, err := lock.Load(s, root)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	in := &installer{e: e, root: root, lk: lk}
	code := 0
	for _, name := range fs.Args() {
		a := lk.Find(name)
		if a == nil {
			fmt.Fprintf(e.stderr, "agentctl: %s is not installed here (%s names it not)\n", name, lock.File)
			code = 1
			continue
		}
		if a.Path != lock.CanonicalPath(a.Kind, a.Name) {
			fmt.Fprintf(e.stderr, "agentctl: refusing to remove %s: the lock file puts it at %s, not %s\n", name, a.Path, lock.CanonicalPath(a.Kind, a.Name))
			code = 1
			continue
		}
		for _, l := range a.Links {
			if in.pointsAt(l.Path, a.Path) {
				if err := os.Remove(filepath.Join(root, filepath.FromSlash(l.Path))); err != nil {
					return fail(e, 1, "%v", err)
				}
			} else {
				fmt.Fprintf(e.stderr, "agentctl: warning: %s is not agentctl's link to %s, so it stays\n", l.Path, a.Path)
			}
		}
		if err := os.RemoveAll(filepath.Join(root, filepath.FromSlash(a.Path))); err != nil {
			return fail(e, 1, "%v", err)
		}
		lk.Remove(name)
		if err := lk.Save(s, root); err != nil {
			return fail(e, 1, "%v", err)
		}
		fmt.Fprintf(e.stdout, "removed %s %s from %s\n", a.Kind, a.Name, a.Path)
	}
	return code
}
