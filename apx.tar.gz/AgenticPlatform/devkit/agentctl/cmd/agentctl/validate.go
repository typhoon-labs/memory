package main

import (
	"fmt"
	"os"
	"sort"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/validate"
)

// runValidate checks workload.yaml, artifact.yaml or a step's definition
// against agent-sdk's schemas: the copy vendored in agentctl, or a working
// copy of spec/ given with -spec.
func runValidate(e *env, args []string) int {
	fs := newFlags(e, "validate", "validate [-kind workload|artifact|step] [-spec DIR] [FILE...]")
	kind := fs.String("kind", "", "the schema to check against: workload, artifact or step; by default from each file's name")
	specDir := fs.String("spec", "", "a working copy of agent-sdk's spec/ to check against instead of the vendored one")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	files := fs.Args()
	if len(files) == 0 {
		for _, name := range []string{"workload.yaml", "workload.yml", "artifact.yaml", "artifact.yml"} {
			if fileExists(name) {
				files = append(files, name)
			}
		}
		if len(files) == 0 {
			return fail(e, 2, "no workload.yaml or artifact.yaml here: name the files to check")
		}
	}
	if *kind != "" {
		if _, ok := validate.Kinds[*kind]; !ok {
			return fail(e, 2, "-kind %q: use workload, artifact or step", *kind)
		}
	}
	var s *spec.Spec
	var err error
	if *specDir != "" {
		s, err = spec.LoadDir(*specDir)
	} else {
		s, err = spec.Vendored()
	}
	if err != nil {
		return fail(e, 2, "the spec: %v", err)
	}
	code := 0
	for _, f := range files {
		k := *kind
		if k == "" {
			k = validate.KindOf(f)
		}
		if k == "" {
			fmt.Fprintf(e.stderr, "%s: cannot tell its kind from its name: give -kind\n", f)
			code = 2
			continue
		}
		data, err := os.ReadFile(f)
		if err != nil {
			fmt.Fprintf(e.stderr, "%s: %v\n", f, err)
			code = 2
			continue
		}
		problems, err := validate.File(s, k, data)
		if err != nil {
			fmt.Fprintf(e.stdout, "%s: invalid %s: %v\n", f, k, err)
			code = max(code, 1)
			continue
		}
		if len(problems) == 0 {
			fmt.Fprintf(e.stdout, "%s: valid %s (%s, %s)\n", f, k, validate.Kinds[k], s.Source)
			continue
		}
		code = max(code, 1)
		sort.Slice(problems, func(i, j int) bool { return problems[i].Location < problems[j].Location })
		fmt.Fprintf(e.stdout, "%s: invalid %s (%s, %s):\n", f, k, validate.Kinds[k], s.Source)
		for _, p := range problems {
			fmt.Fprintf(e.stdout, "  %s\n", p)
		}
	}
	return code
}
