package main

// The install integration test runs the real oras and cosign against a
// throwaway registry: registry:2 in docker, on a loopback port, removed
// at the end. It signs with throwaway cosign keys made for the test, so it
// never touches floci, the platform's registry or any platform key. It is
// the second exception to "tests never run docker" (AGENTS.md), and runs
// only when AGENTCTL_INTEGRATION_REGISTRY_IMAGE names the registry image,
// by digest, and oras, cosign and docker are on PATH; otherwise it skips.

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/cosign"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/lock"
)

// realTools runs the named tools for real, found on the PATH the tests
// started with, with no proxy variables, and refuses every other command.
type realTools struct {
	allow map[string]bool
	env   []string
}

func newRealTools(t *testing.T, names ...string) realTools {
	t.Helper()
	r := realTools{allow: map[string]bool{}}
	for _, n := range names {
		r.allow[n] = true
	}
	for _, kv := range os.Environ() {
		k, _, _ := strings.Cut(kv, "=")
		switch strings.ToUpper(k) {
		case "PATH", "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "ALL_PROXY":
			continue
		}
		r.env = append(r.env, kv)
	}
	r.env = append(r.env, "PATH="+realPath)
	return r
}

func (r realTools) Run(ctx context.Context, c execx.Cmd) (int, error) {
	if !r.allow[filepath.Base(c.Name)] {
		return -1, fmt.Errorf("an integration test ran %s", c.Name)
	}
	p, err := lookReal(filepath.Base(c.Name))
	if err != nil {
		return -1, err
	}
	c.Name = p
	if c.Env == nil {
		c.Env = r.env
	} else {
		var env []string
		for _, kv := range c.Env {
			k, _, _ := strings.Cut(kv, "=")
			switch strings.ToUpper(k) {
			case "PATH", "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "ALL_PROXY":
				continue
			}
			env = append(env, kv)
		}
		c.Env = append(env, "PATH="+realPath)
	}
	return execx.OS{}.Run(ctx, c)
}

func lookReal(name string) (string, error) {
	for _, dir := range filepath.SplitList(realPath) {
		p := filepath.Join(dir, name)
		if fi, err := os.Stat(p); err == nil && fi.Mode().IsRegular() && fi.Mode()&0o111 != 0 {
			return p, nil
		}
	}
	return "", fmt.Errorf("%s is not on PATH", name)
}

// sh runs a real tool for the test's own setup.
func (r realTools) sh(t *testing.T, stdin string, name string, args ...string) string {
	t.Helper()
	var out, errOut bytes.Buffer
	status, err := r.Run(context.Background(), execx.Cmd{Name: name, Args: args, Env: append(append([]string{}, r.env...), "COSIGN_PASSWORD="), Stdin: strings.NewReader(stdin), Stdout: &out, Stderr: &errOut})
	if err != nil || status != 0 {
		t.Fatalf("%s %s: status %d, %v: %s", name, strings.Join(args, " "), status, err, errOut.String())
	}
	return strings.TrimSpace(out.String())
}

func freePort(t *testing.T) int {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer l.Close()
	return l.Addr().(*net.TCPAddr).Port
}

func TestInstallRealTools(t *testing.T) {
	image := os.Getenv("AGENTCTL_INTEGRATION_REGISTRY_IMAGE")
	if image == "" {
		t.Skip("set AGENTCTL_INTEGRATION_REGISTRY_IMAGE to a registry:2 image by digest to run oras and cosign for real")
	}
	for _, n := range []string{"docker", "oras", "cosign"} {
		if _, err := lookReal(n); err != nil {
			t.Skip(err)
		}
	}
	tools := newRealTools(t, "docker", "oras", "cosign")
	port := freePort(t)
	name := fmt.Sprintf("agentctl-it-registry-%d", port)
	tools.sh(t, "", "docker", "run", "-d", "--rm", "--name", name, "-p", fmt.Sprintf("127.0.0.1:%d:5000", port), image)
	t.Cleanup(func() { exec.Command(must(lookReal("docker")), "rm", "-f", name).Run() })
	host := fmt.Sprintf("127.0.0.1:%d", port)
	for i := 0; ; i++ {
		resp, err := http.Get("http://" + host + "/v2/")
		if err == nil {
			resp.Body.Close()
			break
		}
		if i > 50 {
			t.Fatalf("the registry did not start: %v", err)
		}
		time.Sleep(200 * time.Millisecond)
	}

	work := t.TempDir()
	key := func(prefix string) string {
		tools.sh(t, "", "cosign", "generate-key-pair", "--output-key-prefix", filepath.Join(work, prefix))
		return filepath.Join(work, prefix)
	}
	releaseKey, recordKey, otherKey := key("release"), key("record"), key("other")
	sc := filepath.Join(work, "signing-config.json")
	tools.sh(t, "", "cosign", "signing-config", "create", "--out", sc)

	// push builds a scratch image as library-release does: an index of two
	// manifests with one tar+gzip layer, tagged v<version>.
	push := func(kind, name, version, commit string, files map[string]string) string {
		repo := host + "/library/" + kind + "/" + name
		dir := t.TempDir()
		files["artifact.yaml"] = artifactYAML(kind, name, version, commit)
		layer := tarGz(t, files)
		os.WriteFile(filepath.Join(dir, "layer.tar.gz"), layer, 0o644)
		cfg := []byte(`{"architecture":"amd64","os":"linux","rootfs":{"type":"layers","diff_ids":[]}}`)
		os.WriteFile(filepath.Join(dir, "config.json"), cfg, 0o644)
		tools.sh(t, "", "oras", "blob", "push", "--plain-http", repo, filepath.Join(dir, "layer.tar.gz"))
		tools.sh(t, "", "oras", "blob", "push", "--plain-http", repo, filepath.Join(dir, "config.json"))
		var manifests []map[string]any
		for _, arch := range []string{"amd64", "arm64"} {
			m, _ := json.Marshal(map[string]any{
				"schemaVersion": 2, "mediaType": "application/vnd.oci.image.manifest.v1+json",
				"config":      map[string]any{"mediaType": "application/vnd.oci.image.config.v1+json", "digest": sha256Digest(cfg), "size": len(cfg)},
				"layers":      []map[string]any{{"mediaType": "application/vnd.oci.image.layer.v1.tar+gzip", "digest": sha256Digest(layer), "size": len(layer)}},
				"annotations": map[string]string{"org.example.arch": arch},
			})
			p := filepath.Join(dir, arch+".json")
			os.WriteFile(p, m, 0o644)
			tools.sh(t, "", "oras", "manifest", "push", "--plain-http", "--media-type", "application/vnd.oci.image.manifest.v1+json", repo+"@"+sha256Digest(m), p)
			manifests = append(manifests, map[string]any{"mediaType": "application/vnd.oci.image.manifest.v1+json", "digest": sha256Digest(m), "size": len(m), "platform": map[string]string{"os": "linux", "architecture": arch}})
		}
		idx, _ := json.Marshal(map[string]any{"schemaVersion": 2, "mediaType": "application/vnd.oci.image.index.v1+json", "manifests": manifests})
		p := filepath.Join(dir, "index.json")
		os.WriteFile(p, idx, 0o644)
		tools.sh(t, "", "oras", "manifest", "push", "--plain-http", "--media-type", "application/vnd.oci.image.index.v1+json", repo+":v"+version, p)
		return repo + "@" + sha256Digest(idx)
	}
	signAndAttest := func(key, ref, commit string) {
		tools.sh(t, "", "cosign", "sign", "--key", key+".key", "--signing-config", sc, "-y", "--allow-http-registry", ref)
		pred := filepath.Join(t.TempDir(), "provenance.json")
		b, _ := json.Marshal(provenance(commit)["predicate"])
		os.WriteFile(pred, b, 0o644)
		tools.sh(t, "", "cosign", "attest", "--key", key+".key", "--signing-config", sc, "-y", "--allow-http-registry", "--type", "slsaprovenance1", "--predicate", pred, ref)
	}

	skill := push("skill", "platform-conventions", "0.1.0", commitA, skillFiles())
	signAndAttest(releaseKey, skill, commitA)
	// The prompt is signed with another key than the release key.
	prompt := push("prompt", "summarise-changes", "0.1.0", commitB, map[string]string{"prompt.md": "Summarise.\n"})
	signAndAttest(otherKey, prompt, commitB)

	// The index, signed with the throwaway record key.
	var ix map[string]any
	json.Unmarshal(exampleIndex(t), &ix)
	for _, raw := range ix["entries"].([]any) {
		en := raw.(map[string]any)
		switch en["metadata"].(map[string]any)["name"] {
		case "platform-conventions":
			en["reference"] = skill
			en["source"].(map[string]any)["commit"] = commitA
		case "summarise-changes":
			en["reference"] = prompt
			en["source"].(map[string]any)["commit"] = commitB
		}
	}
	b, _ := json.Marshal(ix)
	idxDir := t.TempDir()
	index := filepath.Join(idxDir, "catalog.json")
	os.WriteFile(index, b, 0o644)
	tools.sh(t, "", "cosign", "sign-blob", "--key", recordKey+".key", "--signing-config", sc, "-y", "--bundle", index+".sigstore.json", index)

	te := newTestEnv(t)
	te.vars["AGENTCTL_RELEASE_KEY"] = releaseKey + ".pub"
	te.vars["AGENTCTL_RECORD_KEY"] = recordKey + ".pub"
	te.vars["AGENTCTL_REGISTRY"] = host
	te.vars["AGENTCTL_PLAIN_HTTP_REGISTRIES"] = host
	run := func(args ...string) (int, string, string) {
		return te.runWith(func(e *env) { e.runner = newRealTools(t, "oras", "cosign") }, args...)
	}
	repo := t.TempDir()

	code, out, errOut := run("install", "-index", index, "-dir", repo, "platform-conventions")
	if code != 0 {
		t.Fatalf("install: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	if b, _ := os.ReadFile(filepath.Join(repo, ".claude/skills/platform-conventions/SKILL.md")); !strings.Contains(string(b), "# Conventions") {
		t.Errorf("SKILL.md through the link: %q", b)
	}
	if a := readLock(t, repo).Find("platform-conventions"); a == nil || a.Reference != skill {
		t.Errorf("lock: %+v", a)
	}
	t.Logf("installed: %s", strings.TrimSpace(out))

	// Another key's signature.
	if code, _, errOut := run("install", "-index", index, "-dir", repo, "summarise-changes"); code != 1 || !strings.Contains(errOut, "no signature verifies with the key") {
		t.Errorf("another key's signature: code %d, stderr %q", code, errOut)
	} else {
		t.Logf("refused: %s", strings.TrimSpace(errOut))
	}
	// A digest not in the index: a newer release the index does not hold.
	newer := push("skill", "platform-conventions", "0.2.0", commitC, skillFiles())
	signAndAttest(releaseKey, newer, commitC)
	_, digest, _ := strings.Cut(newer, "@")
	if code, _, errOut := run("install", "-index", index, "-dir", repo, "platform-conventions@"+digest); code != 1 || !strings.Contains(errOut, "is not in the index") {
		t.Errorf("a digest not in the index: code %d, stderr %q", code, errOut)
	}
	// The release key's attestations, provenance and an SBOM, on a digest
	// it never signed: cosign verify alone takes them for a signature,
	// install must not.
	attestedOnly := push("skill", "platform-conventions", "0.3.0", commitC, skillFiles())
	attestOnly := func(ref, commit string) {
		dir := t.TempDir()
		b, _ := json.Marshal(provenance(commit)["predicate"])
		os.WriteFile(filepath.Join(dir, "provenance.json"), b, 0o644)
		os.WriteFile(filepath.Join(dir, "sbom.json"), []byte(`{"spdxVersion":"SPDX-2.3","SPDXID":"SPDXRef-DOCUMENT","name":"x","dataLicense":"CC0-1.0","documentNamespace":"https://example.test/x","creationInfo":{"created":"2026-11-19T00:00:00Z","creators":["Tool: test"]},"packages":[]}`), 0o644)
		tools.sh(t, "", "cosign", "attest", "--key", releaseKey+".key", "--signing-config", sc, "-y", "--allow-http-registry", "--type", "slsaprovenance1", "--predicate", filepath.Join(dir, "provenance.json"), ref)
		tools.sh(t, "", "cosign", "attest", "--key", releaseKey+".key", "--signing-config", sc, "-y", "--allow-http-registry", "--type", "spdxjson", "--predicate", filepath.Join(dir, "sbom.json"), ref)
	}
	attestOnly(attestedOnly, commitC)
	// cosign verify alone passes on it, which is the defect agentctl must
	// not have.
	if out := tools.sh(t, "", "cosign", "verify", "--key", releaseKey+".pub", "--insecure-ignore-tlog", "--allow-http-registry", "--output", "json", attestedOnly); strings.Contains(out, cosign.SignStatementType) {
		t.Fatalf("the fixture has a sign statement: %s", out)
	}
	t.Logf("cosign verify alone accepted %s, which holds no sign statement", attestedOnly)
	var ix2 map[string]any
	json.Unmarshal(b, &ix2)
	for _, raw := range ix2["entries"].([]any) {
		en := raw.(map[string]any)
		if en["metadata"].(map[string]any)["name"] == "platform-conventions" {
			en["reference"], en["version"] = attestedOnly, "0.3.0"
			en["metadata"].(map[string]any)["version"] = "0.3.0"
			en["source"].(map[string]any)["commit"] = commitC
			en["source"].(map[string]any)["tag"] = "skill/platform-conventions/v0.3.0"
		}
	}
	b2, _ := json.Marshal(ix2)
	index2 := filepath.Join(t.TempDir(), "catalog.json")
	os.WriteFile(index2, b2, 0o644)
	tools.sh(t, "", "cosign", "sign-blob", "--key", recordKey+".key", "--signing-config", sc, "-y", "--bundle", index2+".sigstore.json", index2)
	repo2 := t.TempDir()
	if code, _, errOut := run("install", "-index", index2, "-dir", repo2, "platform-conventions"); code != 1 || !strings.Contains(errOut, "no signature verifies with the key") {
		t.Errorf("attestations without a sign statement: code %d, stderr %q", code, errOut)
	} else {
		t.Logf("refused: %s", strings.TrimSpace(errOut))
	}
	if entries, _ := os.ReadDir(repo2); len(entries) != 0 {
		t.Errorf("the refusal wrote %v", entries)
	}

	// An index signed with the release key.
	tools.sh(t, "", "cosign", "sign-blob", "--key", releaseKey+".key", "--signing-config", sc, "-y", "--bundle", index+".sigstore.json", index)
	if code, _, errOut := run("search", "-index", index); code != 1 || !strings.Contains(errOut, "refusing the index") {
		t.Errorf("an index signed with the release key: code %d, stderr %q", code, errOut)
	}
	if code, _, errOut := run("remove", "-dir", repo, "platform-conventions"); code != 0 {
		t.Errorf("remove: code %d, stderr %q", code, errOut)
	}
	if l := readLock(t, repo); len(l.Artifacts) != 0 {
		t.Errorf("lock after remove: %+v", l)
	}
	_ = lock.File
}

func must(s string, err error) string {
	if err != nil {
		panic(err)
	}
	return s
}
