package main

import (
	"encoding/json"
	"fmt"
	"io"
	"sort"
	"strings"
	"text/tabwriter"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/catalog"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
)

// runSearch lists the catalog index's entries that match, after verifying
// the index's signature with the environment's record key (D37).
func runSearch(e *env, args []string) int {
	fs := newFlags(e, "search", "search [flags] [TERM...]")
	cf := addCatalogFlags(e, fs)
	kind := fs.String("kind", "", "only this kind: agent, mcp-server, workflow, skill, prompt or plugin")
	owner := fs.String("owner", "", "only this owning team")
	tier := fs.String("tier", "", "only artifacts of this tier: global, team or project")
	asJSON := fs.Bool("json", false, "print the matching entries as JSON, as the index holds them")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	c, err := newCatalogEnv(e, *cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer c.cleanup()
	ix, err := c.readIndex(e, cf)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	found := ix.Search(fs.Args(), catalog.Filter{Kind: *kind, Owner: *owner, Tier: *tier})
	if *asJSON {
		if found == nil {
			found = []catalog.Entry{}
		}
		return printJSON(e, found)
	}
	fmt.Fprintf(e.stderr, "index %s, built %s, signature verified with %s\n", ix.From, ix.Timestamp, c.keyDesc[defaults.RecordKey])
	if len(found) == 0 {
		fmt.Fprintln(e.stderr, "no entry matches")
		return 1
	}
	w := tabwriter.NewWriter(e.stdout, 0, 4, 2, ' ', 0)
	fmt.Fprintln(w, "NAME\tKIND\tVERSION\tOWNER\tSUPPORT\tWHERE\tDESCRIPTION")
	for _, en := range found {
		where := en.Tier
		if en.Route != "" {
			where = en.Route
		}
		fmt.Fprintf(w, "%s\t%s\t%s\t%s\t%s\t%s\t%s\n", en.Name(), en.Kind(), en.Version, en.Owner(), en.Support(), dash(where), oneLine(en.Description(), 60))
	}
	w.Flush()
	return 0
}

// runShow prints one entry of the verified index.
func runShow(e *env, args []string) int {
	fs := newFlags(e, "show", "show [flags] NAME")
	cf := addCatalogFlags(e, fs)
	asJSON := fs.Bool("json", false, "print the entry as JSON, as the index holds it")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() != 1 {
		fs.Usage()
		return 2
	}
	c, err := newCatalogEnv(e, *cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer c.cleanup()
	ix, err := c.readIndex(e, cf)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	en := ix.Find(fs.Arg(0))
	if en == nil {
		return fail(e, 1, "%q is not in the index %s", fs.Arg(0), ix.From)
	}
	if *asJSON {
		return printJSON(e, en)
	}
	gateway := defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway)
	showEntry(e.stdout, en, gateway)
	fmt.Fprintf(e.stderr, "from the index %s, built %s, signature verified with %s\n", ix.From, ix.Timestamp, c.keyDesc[defaults.RecordKey])
	if en.Support() == "deprecated" {
		fmt.Fprintf(e.stderr, "agentctl: warning: %s is deprecated%s\n", en.Name(), deprecationNote(en))
	}
	return 0
}

func showEntry(w io.Writer, en *catalog.Entry, gateway string) {
	tw := tabwriter.NewWriter(w, 0, 4, 2, ' ', 0)
	row := func(k, v string) {
		if v != "" {
			fmt.Fprintf(tw, "%s:\t%s\n", k, v)
		}
	}
	row("name", en.Name())
	row("kind", en.Kind())
	if rt, _ := en.Metadata["runtime"].(string); rt != "" {
		row("runtime", rt)
	}
	row("version", en.Version)
	row("owner", en.Owner())
	row("support", en.Support())
	row("tier", en.Tier)
	row("description", en.Description())
	if en.Route != "" {
		row("route", en.Route+" ("+catalog.RouteURL(gateway, en.Route)+")")
	}
	row("reference", en.Reference)
	src := fmt.Sprintf("project %d, tag %s, commit %s", en.Source.ProjectID, en.Source.Tag, en.Source.Commit)
	if en.Source.Path != "" {
		src += ", " + en.Source.Path
	}
	row("source", src)
	for _, k := range []string{"compatibility", "requires", "tools", "limits", "conformance", "evaluation", "deprecation"} {
		if v, ok := en.Metadata[k]; ok {
			b, _ := json.Marshal(v)
			row(k, string(b))
		}
	}
	if en.IsArtifact() {
		row("install", "agentctl install "+en.Name())
	}
	tw.Flush()
}

func deprecationNote(en *catalog.Entry) string {
	d, _ := en.Metadata["deprecation"].(map[string]any)
	var parts []string
	keys := make([]string, 0, len(d))
	for k := range d {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		parts = append(parts, fmt.Sprintf("%s %v", k, d[k]))
	}
	if len(parts) == 0 {
		return ""
	}
	return ": " + strings.Join(parts, ", ")
}

func printJSON(e *env, v any) int {
	enc := json.NewEncoder(e.stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(v); err != nil {
		return fail(e, 1, "%v", err)
	}
	return 0
}

func dash(s string) string {
	if s == "" {
		return "-"
	}
	return s
}

func oneLine(s string, n int) string {
	s = strings.Join(strings.Fields(s), " ")
	if r := []rune(s); len(r) > n {
		return string(r[:n-1]) + "…"
	}
	return s
}
