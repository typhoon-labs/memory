package main

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// TestMain points PATH at a directory of fakes that fail loudly, so a
// test that reached for a real tool by mistake (kind, docker, the
// keychain tools) runs the fake instead. Commands go through env.runner,
// which tests replace; this is the second guard.
func TestMain(m *testing.M) {
	dir, err := os.MkdirTemp("", "agentctl-fake-path-")
	if err != nil {
		panic(err)
	}
	for _, name := range []string{"kind", "docker", "security", "secret-tool", "xdg-open", "open", "agentic-step", "cosign", "oras", "aws", "claude"} {
		script := "#!/bin/sh\necho \"a test reached the real $0\" >&2\nexit 99\n"
		if err := os.WriteFile(filepath.Join(dir, name), []byte(script), 0o755); err != nil {
			panic(err)
		}
	}
	// git is real: local up's tests clone a repository of their own.
	if git, err := exec.LookPath("git"); err == nil {
		gitPath = git
		os.Symlink(git, filepath.Join(dir, "git"))
	}
	realPath = os.Getenv("PATH")
	os.Setenv("PATH", dir)
	code := m.Run()
	os.RemoveAll(dir)
	os.Exit(code)
}

// gitPath is the real git, for tests that build a repository.
var gitPath string

// realPath is PATH as the tests started with it, before the fakes, for
// the integration tests alone (conform_integration_test.go).
var realPath string

// testEnv is an environment for one command: variables, a fake runner,
// and an opener that records URLs or plays a browser.
type testEnv struct {
	vars   map[string]string
	runner *execx.Fake
	open   func(url string) bool
	stdin  string

	mu     sync.Mutex
	opened []string
}

func newTestEnv(t *testing.T) *testEnv {
	t.Helper()
	return &testEnv{
		vars: map[string]string{
			"AGENTCTL_CONFIG_DIR":  filepath.Join(t.TempDir(), "config"),
			"AGENTCTL_CACHE_DIR":   filepath.Join(t.TempDir(), "cache"),
			"AGENTCTL_TOKEN_STORE": "file",
			"HOME":                 t.TempDir(),
		},
		runner: &execx.Fake{},
	}
}

func (te *testEnv) env(out, errOut *bytes.Buffer) *env {
	return &env{
		ctx:    context.Background(),
		stdin:  strings.NewReader(te.stdin),
		stdout: out,
		stderr: errOut,
		getenv: func(k string) string { return te.vars[k] },
		environ: func() []string {
			var kv []string
			for k, v := range te.vars {
				kv = append(kv, k+"="+v)
			}
			return kv
		},
		runner:   te.runner,
		goos:     "linux",
		lookPath: func(string) bool { return false },
		open: func(u string) bool {
			te.mu.Lock()
			te.opened = append(te.opened, u)
			te.mu.Unlock()
			if te.open != nil {
				return te.open(u)
			}
			return false
		},
		self: func() (string, error) { return "/opt/agentctl/bin/agentctl", nil },
	}
}

// run runs one command and returns its exit code and output.
func (te *testEnv) run(args ...string) (int, string, string) {
	return te.runWith(nil, args...)
}

// runWith is run, with a change to the environment first.
func (te *testEnv) runWith(change func(*env), args ...string) (int, string, string) {
	var out, errOut bytes.Buffer
	e := te.env(&out, &errOut)
	if change != nil {
		change(e)
	}
	code := dispatch(e, args)
	return code, out.String(), errOut.String()
}

func TestVersion(t *testing.T) {
	code, out, _ := newTestEnv(t).run("version")
	if code != 0 || !strings.HasPrefix(out, "agentctl dev\n") {
		t.Fatalf("version: code %d, output %q", code, out)
	}
}

func TestUsage(t *testing.T) {
	te := newTestEnv(t)
	if code, out, _ := te.run(); code != 2 || !strings.Contains(out, "Commands:") {
		t.Fatalf("no arguments: code %d, output %q", code, out)
	}
	if code, _, _ := te.run("help"); code != 0 {
		t.Fatalf("help: code %d", code)
	}
	if code, _, errOut := te.run("no-such-command"); code != 2 || !strings.Contains(errOut, "unknown command") {
		t.Fatalf("unknown command: code %d, stderr %q", code, errOut)
	}
}
