package main

import (
	"encoding/json"
	"io/fs"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// exampleIndex is the vendored spec's example of a local index.
func exampleIndex(t *testing.T) []byte {
	t.Helper()
	s, err := spec.Vendored()
	if err != nil {
		t.Fatal(err)
	}
	b, err := fs.ReadFile(s.FS, "schemas/examples/local.catalog.json")
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// writeIndex writes catalog.json and a bundle signed by pem into dir.
func writeIndex(t *testing.T, dir string, data, pem []byte) string {
	t.Helper()
	p := filepath.Join(dir, "catalog.json")
	if err := os.WriteFile(p, data, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(p+".sigstore.json", bundleFor(pem, data), 0o644); err != nil {
		t.Fatal(err)
	}
	return p
}

func catalogTestEnv(t *testing.T) (*testEnv, *fakeTools) {
	te := newTestEnv(t)
	f := newFakeTools(t)
	f.install(te)
	return te, f
}

func TestSearchVerifiesTheIndex(t *testing.T) {
	te, _ := catalogTestEnv(t)
	idx := writeIndex(t, t.TempDir(), exampleIndex(t), envKey(t, defaults.RecordKey))

	code, out, errOut := te.run("search", "-index", idx)
	if code != 0 {
		t.Fatalf("search: code %d, stderr %q", code, errOut)
	}
	for _, want := range []string{"platform-conventions", "skill", "summarise-changes", "reference-mcp", "gateway/mcp/reference-mcp", "reference-workflow"} {
		if !strings.Contains(out, want) {
			t.Errorf("search output lacks %q:\n%s", want, out)
		}
	}
	if !strings.Contains(errOut, "signature verified with the local record key") {
		t.Errorf("stderr: %q", errOut)
	}

	code, out, _ = te.run("search", "-index", idx, "-kind", "skill")
	if code != 0 || !strings.Contains(out, "platform-conventions") || strings.Contains(out, "reference-mcp") {
		t.Errorf("search -kind skill: code %d:\n%s", code, out)
	}
	code, out, _ = te.run("search", "-index", idx, "notes", "database")
	if code != 0 || !strings.Contains(out, "reference-mcp") || strings.Contains(out, "reference-agent ") {
		t.Errorf("search notes database: code %d:\n%s", code, out)
	}
	if code, _, _ = te.run("search", "-index", idx, "no-such-thing"); code != 1 {
		t.Errorf("search with no match: code %d, want 1", code)
	}
	code, out, _ = te.run("search", "-index", idx, "-json", "-tier", "global")
	var entries []map[string]any
	if code != 0 || json.Unmarshal([]byte(out), &entries) != nil || len(entries) != 2 {
		t.Errorf("search -json -tier global: code %d, %d entries:\n%s", code, len(entries), out)
	}
}

func TestSearchRefusesAnIndexThatDoesNotVerify(t *testing.T) {
	cases := []struct {
		name   string
		mutate func(t *testing.T, idx string)
		want   string
	}{
		{"changed after signing", func(t *testing.T, idx string) {
			b, _ := os.ReadFile(idx)
			os.WriteFile(idx, []byte(strings.Replace(string(b), "experimental", "supported", 1)), 0o644)
		}, "refusing the index"},
		{"signed with the release key", func(t *testing.T, idx string) {
			b, _ := os.ReadFile(idx)
			os.WriteFile(idx+".sigstore.json", bundleFor(envKey(t, defaults.ReleaseKey), b), 0o644)
		}, "refusing the index"},
		{"signed with another key", func(t *testing.T, idx string) {
			b, _ := os.ReadFile(idx)
			os.WriteFile(idx+".sigstore.json", bundleFor(otherKey, b), 0o644)
		}, "refusing the index"},
		{"no bundle", func(t *testing.T, idx string) { os.Remove(idx + ".sigstore.json") }, "the index's signature"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			te, _ := catalogTestEnv(t)
			idx := writeIndex(t, t.TempDir(), exampleIndex(t), envKey(t, defaults.RecordKey))
			c.mutate(t, idx)
			for _, cmd := range [][]string{{"search", "-index", idx}, {"show", "-index", idx, "reference-mcp"}} {
				code, out, errOut := te.run(cmd...)
				if code != 1 || !strings.Contains(errOut, c.want) || out != "" {
					t.Errorf("%s: code %d, stdout %q, stderr %q", cmd[0], code, out, errOut)
				}
			}
		})
	}
}

func TestSearchRefusesAnInvalidIndex(t *testing.T) {
	te, _ := catalogTestEnv(t)
	key := envKey(t, defaults.RecordKey)
	var ix map[string]any
	json.Unmarshal(exampleIndex(t), &ix)

	// Signed, but the schema refuses it: an artifact without its digest.
	entries := ix["entries"].([]any)
	delete(entries[4].(map[string]any), "reference")
	bad, _ := json.Marshal(ix)
	idx := writeIndex(t, t.TempDir(), bad, key)
	if code, _, errOut := te.run("search", "-index", idx); code != 1 || !strings.Contains(errOut, "catalog.schema.json") {
		t.Errorf("an index without a reference: code %d, stderr %q", code, errOut)
	}

	// Signed and valid, but one name twice.
	json.Unmarshal(exampleIndex(t), &ix)
	entries = ix["entries"].([]any)
	ix["entries"] = append(entries, entries[0])
	twice, _ := json.Marshal(ix)
	idx = writeIndex(t, t.TempDir(), twice, key)
	if code, _, errOut := te.run("search", "-index", idx); code != 1 || !strings.Contains(errOut, "twice") {
		t.Errorf("a name twice: code %d, stderr %q", code, errOut)
	}

	// Another environment's index.
	if code, _, errOut := te.run("search", "-index", writeIndex(t, t.TempDir(), exampleIndex(t), key), "-environment", "dev"); code != 2 || !strings.Contains(errOut, `"dev"`) {
		t.Errorf("-environment dev: code %d, stderr %q", code, errOut)
	}
}

func TestShow(t *testing.T) {
	te, _ := catalogTestEnv(t)
	idx := writeIndex(t, t.TempDir(), exampleIndex(t), envKey(t, defaults.RecordKey))
	code, out, errOut := te.run("show", "-index", idx, "reference-mcp")
	if code != 0 {
		t.Fatalf("show: code %d, stderr %q", code, errOut)
	}
	for _, want := range []string{"mcp-server", "https://gateway.agentic.internal/mcp/reference-mcp", "@sha256:cb71aa6e", "project 81000102, tag v0.1.1", `"level":"L2"`} {
		if !strings.Contains(out, want) {
			t.Errorf("show lacks %q:\n%s", want, out)
		}
	}
	code, out, _ = te.run("show", "-index", idx, "platform-conventions")
	if code != 0 || !strings.Contains(out, "agentctl install platform-conventions") || !strings.Contains(out, "skills/platform-conventions") {
		t.Errorf("show of a skill: code %d:\n%s", code, out)
	}
	if code, _, errOut := te.run("show", "-index", idx, "nothing-here"); code != 1 || !strings.Contains(errOut, "not in the index") {
		t.Errorf("show of a missing name: code %d, stderr %q", code, errOut)
	}
	if code, _, _ := te.run("show", "-index", idx); code != 2 {
		t.Errorf("show without a name: code %d", code)
	}
}

func TestSearchFromTheBucket(t *testing.T) {
	te, f := catalogTestEnv(t)
	key := envKey(t, defaults.RecordKey)
	good := exampleIndex(t)
	var ix map[string]any
	json.Unmarshal(good, &ix)
	ix["timestamp"] = "2026-11-19T21:00:12Z"
	newer, _ := json.Marshal(ix)

	bucket := "s3://agentic-catalog-index-local/indexes/"
	f.put(bucket+"20261118T210012Z/catalog.json", good)
	f.put(bucket+"20261118T210012Z/catalog.json.sigstore.json", bundleFor(key, good))
	// The newest build's signature is another key's: passed over, named.
	f.put(bucket+"20261119T210012Z/catalog.json", newer)
	f.put(bucket+"20261119T210012Z/catalog.json.sigstore.json", bundleFor(otherKey, newer))
	f.put(bucket+"20261119T210012Z/index.html", []byte("<html></html>"))

	code, out, errOut := te.run("search")
	if code != 0 || !strings.Contains(out, "platform-conventions") {
		t.Fatalf("search from the bucket: code %d, stderr %q", code, errOut)
	}
	if !strings.Contains(errOut, "passing over") || !strings.Contains(errOut, "20261119T210012Z") || !strings.Contains(errOut, "index "+bucket+"20261118T210012Z/catalog.json") {
		t.Errorf("stderr: %q", errOut)
	}
	// The endpoint locally, since AWS_ENDPOINT_URL is unset.
	found := false
	for _, c := range te.runner.Calls() {
		for _, kv := range c.Cmd.Env {
			found = found || kv == "AWS_ENDPOINT_URL=http://floci:4566"
		}
	}
	if !found {
		t.Error("the aws CLI did not get floci's endpoint")
	}

	// A valid older build copied under a newer prefix is passed over.
	f.put(bucket+"20261120T000000Z/catalog.json", good)
	f.put(bucket+"20261120T000000Z/catalog.json.sigstore.json", bundleFor(key, good))
	code, _, errOut = te.run("search")
	if code != 0 || !strings.Contains(errOut, "its prefix says 20261120T000000Z and its signed timestamp 2026-11-18T21:00:12Z") || !strings.Contains(errOut, "index "+bucket+"20261118T210012Z/catalog.json") {
		t.Errorf("a replayed index: code %d, stderr %q", code, errOut)
	}

	// Once no build verifies, nothing is read.
	f.put(bucket+"20261118T210012Z/catalog.json.sigstore.json", bundleFor(otherKey, good))
	if code, _, errOut := te.run("search"); code != 1 || !strings.Contains(errOut, "no index under") {
		t.Errorf("no verifying build: code %d, stderr %q", code, errOut)
	}
}

func TestSearchOverHTTPS(t *testing.T) {
	te, _ := catalogTestEnv(t)
	data := exampleIndex(t)
	key := envKey(t, defaults.RecordKey)
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Header.Get("Authorization") != "" {
			t.Errorf("a token was sent to %s", r.Host)
		}
		switch r.URL.Path {
		case "/catalog.json":
			w.Write(data)
		case "/catalog.json.sigstore.json":
			w.Write(bundleFor(key, data))
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()
	te.vars["GITLAB_TOKEN"] = "glpat-secret"
	code, out, errOut := te.runWith(func(e *env) { e.httpClient = srv.Client() }, "search", "-index", srv.URL+"/catalog.json")
	if code != 0 || !strings.Contains(out, "summarise-changes") {
		t.Fatalf("search over https: code %d, stderr %q", code, errOut)
	}
	if code, _, errOut := te.runWith(func(e *env) { e.httpClient = srv.Client() }, "search", "-index", "http://example.invalid/catalog.json"); code != 1 || !strings.Contains(errOut, "a file, an https:// URL or an s3:// location") {
		t.Errorf("plain http: code %d, stderr %q", code, errOut)
	}
}
