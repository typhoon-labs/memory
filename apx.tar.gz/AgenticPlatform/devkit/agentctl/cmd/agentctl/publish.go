package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"slices"
	"sort"
	"strings"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/catalog"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
)

// Agentregistry 0.4.0's apply API (D40): documents of ar.dev/v1alpha1,
// one per entry, under the platform's labels and annotations (R3).
const (
	arAPIVersion   = "ar.dev/v1alpha1"
	labelOwner     = "agentic-platform/owner"
	labelSupport   = "agentic-platform/support"
	labelKind      = "agentic-platform/kind"
	annoDigest     = "agentic-platform/digest"
	annoReference  = "agentic-platform/reference"
	annoSource     = "agentic-platform/source"
	annoRoute      = "agentic-platform/route"
	annoIndex      = "agentic-platform/index"
	registryDefURL = "https://workloads-gateway.agentic.internal/registry"
)

// arDoc is one Agentregistry document.
type arDoc struct {
	APIVersion string         `yaml:"apiVersion" json:"apiVersion"`
	Kind       string         `yaml:"kind" json:"kind"`
	Metadata   arMeta         `yaml:"metadata" json:"metadata"`
	Spec       map[string]any `yaml:"spec" json:"spec"`
}

type arMeta struct {
	Namespace   string            `yaml:"namespace" json:"namespace,omitempty"`
	Name        string            `yaml:"name" json:"name"`
	Tag         string            `yaml:"tag" json:"tag,omitempty"`
	Labels      map[string]string `yaml:"labels" json:"labels,omitempty"`
	Annotations map[string]string `yaml:"annotations" json:"annotations,omitempty"`
}

// documents are the index's agents and MCP servers, each listed by its
// route on the developer deployment: Agentregistry 0.4.0 refuses an
// OCI reference outside its own registries and takes skills from public
// Git alone, so the artifacts stay in the signed index (D40, R4).
func documents(ix *catalog.Verified, gateway string) []arDoc {
	var docs []arDoc
	for _, en := range ix.Entries {
		kind := map[string]string{"agent": "Agent", "mcp-server": "MCPServer"}[en.Kind()]
		if kind == "" || en.IsArtifact() || en.Route == "" {
			continue
		}
		_, digest, _ := strings.Cut(en.Reference, "@")
		url := catalog.RouteURL(gateway, en.Route)
		d := arDoc{APIVersion: arAPIVersion, Kind: kind,
			Metadata: arMeta{Namespace: "default", Name: en.Name(), Tag: en.Version,
				Labels: map[string]string{labelOwner: en.Owner(), labelSupport: en.Support(), labelKind: en.Kind()},
				Annotations: map[string]string{
					annoDigest: digest, annoReference: en.Reference, annoRoute: url, annoIndex: ix.Timestamp,
					annoSource: fmt.Sprintf("project %d, tag %s, commit %s", en.Source.ProjectID, en.Source.Tag, en.Source.Commit),
				}},
			Spec: map[string]any{}}
		if desc := en.Description(); desc != "" {
			d.Spec["description"] = desc
		}
		if kind == "MCPServer" {
			d.Spec["remote"] = map[string]any{"type": "streamable-http", "url": url}
		}
		docs = append(docs, d)
	}
	return docs
}

func marshalDocs(docs []arDoc) ([]byte, error) {
	var b bytes.Buffer
	for i, d := range docs {
		if i > 0 {
			b.WriteString("---\n")
		}
		enc := yaml.NewEncoder(&b)
		enc.SetIndent(2)
		if err := enc.Encode(d); err != nil {
			return nil, err
		}
		enc.Close()
	}
	return b.Bytes(), nil
}

// runCatalogPublish applies the newest verified index to Agentregistry
// through its write route, as the realm's catalog-publisher client, and
// reads each document's result, since the write answers 200 whatever
// happens (R1, R2, R3, R6). With drift it writes nothing: it reads the
// registry and reports every entry that differs from the index (R2).
func runCatalogPublish(e *env, args []string, drift bool) int {
	name := "catalog publish"
	if drift {
		name = "catalog drift"
	}
	fs := newFlags(e, name, name+" [flags]")
	cf := addCatalogFlags(e, fs)
	registry := fs.String("registry", defaults.Get(e.getenv, "AGENTCTL_REGISTRY_URL", registryDefURL), "Agentregistry's route, under which /v0/ is its API ($AGENTCTL_REGISTRY_URL)")
	gateway := fs.String("gateway", defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway), "the developer gateway, whose routes the entries name")
	issuer := fs.String("issuer", defaults.Get(e.getenv, "AGENTCTL_ISSUER", defaults.Issuer), "the realm's issuer")
	clientID := fs.String("client-id", "catalog-publisher", "the realm's client")
	assertion := fs.String("assertion-file", e.getenv("AGENTCTL_ASSERTION_FILE"), "the projected service-account token the client authenticates with ($AGENTCTL_ASSERTION_FILE)")
	scope := fs.String("scope", "registry", "the write route's scope")
	caFlag := fs.String("ca-file", "", "a PEM file of CA certificates to trust besides the system's ($AGENTCTL_CA_FILE)")
	dryRun := fs.Bool("dry-run", false, "print the documents and apply nothing (publish alone)")
	force := fs.Bool("force", false, "publish even when it would delete more than half the rows the registry lists")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	c, err := newCatalogEnv(e, *cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer c.cleanup()
	ix, err := c.readIndex(e, cf)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	docs := documents(ix, *gateway)
	fmt.Fprintf(e.stderr, "index %s, built %s, signature verified with %s: %d agents and MCP servers\n", ix.From, ix.Timestamp, c.keyDesc[defaults.RecordKey], len(docs))
	if *dryRun && !drift {
		body, err := marshalDocs(docs)
		if err != nil {
			return fail(e, 1, "%v", err)
		}
		e.stdout.Write(body)
		return 0
	}

	ca := caFileFor(e, *caFlag, *issuer)
	hc, err := httpClient(e)
	if e.httpClient == nil && ca != "" {
		hc, err = httpClientWithCA(ca)
	}
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	token, err := publisherToken(e, *issuer, *clientID, ca, *assertion, *scope, strings.TrimSuffix(*registry, "/"))
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	base := strings.TrimSuffix(*registry, "/")
	have, err := listRegistry(e, hc, base, token)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if drift {
		return reportDrift(e, have, docs)
	}
	// Apply the index, then delete what the registry holds that the index
	// does not: an older version of a name, or a name the index dropped.
	// Only the catalog job writes there (R2), so the registry converges on
	// the index and is rebuilt from it at will (R6).
	want := map[string]bool{}
	for _, d := range docs {
		want[docKey(d)] = true
	}
	var extra []arDoc
	for k, d := range have {
		if !want[k] {
			extra = append(extra, d)
		}
	}
	sort.Slice(extra, func(i, j int) bool { return docKey(extra[i]) < docKey(extra[j]) })
	// A second guard beside catalog build's fail-closed: an index that
	// would take away most of what the registry lists is more likely a
	// broken build than a withdrawal.
	if len(have) > 0 && 2*len(extra) > len(have) && !*force {
		return fail(e, 1, "refusing to publish: the index would delete %d of the %d agents and MCP servers the registry lists; check the build, or publish -force", len(extra), len(have))
	}
	failed := applyDocs(e, hc, http.MethodPost, base, token, docs, "created", "configured", "unchanged")
	if failed == 0 && len(extra) > 0 {
		failed += applyDocs(e, hc, http.MethodDelete, base, token, extra, "deleted")
	}
	if failed > 0 {
		return fail(e, 1, "%d documents were not applied or deleted", failed)
	}
	return 0
}

func docKey(d arDoc) string { return d.Kind + "/" + d.Metadata.Name + "/" + d.Metadata.Tag }

// applyDocs sends documents to /v0/apply, which answers 200 whatever
// happens, and counts every document whose result is not one of ok.
func applyDocs(e *env, hc *http.Client, method, base, token string, docs []arDoc, ok ...string) int {
	if len(docs) == 0 {
		return 0
	}
	body, err := marshalDocs(docs)
	if err != nil {
		fmt.Fprintf(e.stderr, "agentctl: %v\n", err)
		return len(docs)
	}
	req, _ := http.NewRequestWithContext(e.ctx, method, base+"/v0/apply", bytes.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/yaml")
	req.Header.Set("Accept", "application/json")
	resp, err := hc.Do(req)
	if err != nil {
		fmt.Fprintf(e.stderr, "agentctl: %v\n", err)
		return len(docs)
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 8<<20))
	if resp.StatusCode != http.StatusOK {
		fmt.Fprintf(e.stderr, "agentctl: %s %s/v0/apply: %s: %s\n", method, base, resp.Status, oneLine(string(raw), 200))
		return len(docs)
	}
	var out struct {
		Results []struct {
			Kind, Name, Tag, Status, Error string
		} `json:"results"`
	}
	if err := json.Unmarshal(raw, &out); err != nil {
		fmt.Fprintf(e.stderr, "agentctl: %s %s/v0/apply: the answer is not apply's results: %v\n", method, base, err)
		return len(docs)
	}
	failed := 0
	if len(out.Results) != len(docs) {
		fmt.Fprintf(e.stderr, "agentctl: %d documents sent, %d results back\n", len(docs), len(out.Results))
		failed++
	}
	for _, r := range out.Results {
		if slices.Contains(ok, r.Status) {
			fmt.Fprintf(e.stdout, "%s %s %s: %s\n", r.Kind, r.Name, r.Tag, r.Status)
			continue
		}
		failed++
		fmt.Fprintf(e.stderr, "agentctl: %s %s %s: %s: %s\n", r.Kind, r.Name, r.Tag, r.Status, r.Error)
	}
	return failed
}

// publisherToken signs the catalog's publisher in with its projected
// service-account token, for the write route alone.
func publisherToken(e *env, issuer, clientID, ca, assertionFile, scope, audience string) (string, error) {
	if assertionFile == "" {
		return "", fmt.Errorf("no -assertion-file: the publisher signs in with its projected service-account token")
	}
	a, err := os.ReadFile(assertionFile)
	if err != nil {
		return "", err
	}
	c, err := authClient(e, strings.TrimSuffix(issuer, "/"), clientID, ca)
	if err != nil {
		return "", err
	}
	if e.httpClient != nil {
		c.HTTP = e.httpClient
	}
	m, err := c.Discover(e.ctx)
	if err != nil {
		return "", err
	}
	t, err := c.ClientCredentials(e.ctx, m, strings.TrimSpace(string(a)), scope)
	if err != nil {
		return "", err
	}
	if err := auth.CheckAudienceIs(t.AccessToken, audience); err != nil {
		return "", fmt.Errorf("not using the publisher's token: %v", err)
	}
	return t.AccessToken, nil
}

// listRegistry reads the registry's agents and MCP servers, every page,
// keyed by kind, name and tag; the kind is the endpoint's.
func listRegistry(e *env, hc *http.Client, base, token string) (map[string]arDoc, error) {
	have := map[string]arDoc{}
	for _, ep := range []struct{ path, kind string }{{"agents", "Agent"}, {"mcpservers", "MCPServer"}} {
		cursor := ""
		for page := 0; page < 100; page++ {
			q := url.Values{"namespace": {"default"}, "limit": {"200"}}
			if cursor != "" {
				q.Set("cursor", cursor)
			}
			req, _ := http.NewRequestWithContext(e.ctx, http.MethodGet, base+"/v0/"+ep.path+"?"+q.Encode(), nil)
			req.Header.Set("Authorization", "Bearer "+token)
			req.Header.Set("Accept", "application/json")
			resp, err := hc.Do(req)
			if err != nil {
				return nil, err
			}
			raw, _ := io.ReadAll(io.LimitReader(resp.Body, 16<<20))
			resp.Body.Close()
			if resp.StatusCode != http.StatusOK {
				return nil, fmt.Errorf("GET %s/v0/%s: %s", base, ep.path, resp.Status)
			}
			var list struct {
				Items      []arDoc `json:"items"`
				NextCursor string  `json:"nextCursor"`
			}
			if err := json.Unmarshal(raw, &list); err != nil {
				return nil, fmt.Errorf("GET %s/v0/%s: %v", base, ep.path, err)
			}
			for _, it := range list.Items {
				it.Kind = ep.kind
				if it.APIVersion == "" {
					it.APIVersion = arAPIVersion
				}
				if it.Metadata.Namespace == "" {
					it.Metadata.Namespace = "default"
				}
				have[docKey(it)] = it
			}
			if cursor = list.NextCursor; cursor == "" {
				break
			}
		}
	}
	return have, nil
}

// reportDrift compares the registry's agents and MCP servers with the
// index's documents and reports each difference.
func reportDrift(e *env, have map[string]arDoc, want []arDoc) int {
	var drift []string
	seen := map[string]bool{}
	for _, w := range want {
		k := docKey(w)
		seen[k] = true
		h, ok := have[k]
		if !ok {
			drift = append(drift, k+": in the index, not in the registry")
			continue
		}
		for _, l := range []string{labelOwner, labelSupport} {
			if h.Metadata.Labels[l] != w.Metadata.Labels[l] {
				drift = append(drift, fmt.Sprintf("%s: label %s is %q, the index's %q", k, l, h.Metadata.Labels[l], w.Metadata.Labels[l]))
			}
		}
		for _, a := range []string{annoDigest, annoRoute} {
			if h.Metadata.Annotations[a] != w.Metadata.Annotations[a] {
				drift = append(drift, fmt.Sprintf("%s: annotation %s is %q, the index's %q", k, a, h.Metadata.Annotations[a], w.Metadata.Annotations[a]))
			}
		}
		if w.Kind == "MCPServer" {
			hu, _ := h.Spec["remote"].(map[string]any)
			wu, _ := w.Spec["remote"].(map[string]any)
			if hu["url"] != wu["url"] {
				drift = append(drift, fmt.Sprintf("%s: spec.remote.url is %v, the index's %v", k, hu["url"], wu["url"]))
			}
		}
	}
	for k := range have {
		if !seen[k] {
			drift = append(drift, k+": in the registry, not in the index")
		}
	}
	sort.Strings(drift)
	for _, d := range drift {
		fmt.Fprintln(e.stdout, "drift: "+d)
	}
	if len(drift) > 0 {
		return fail(e, 1, "the registry differs from the index in %d ways", len(drift))
	}
	fmt.Fprintf(e.stdout, "no drift: the registry holds the index's %d agents and MCP servers, as the index has them\n", len(want))
	return 0
}
