package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/lock"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// doctor's verdicts.
const (
	vOK      = "ok"
	vFail    = "FAIL"
	vWarn    = "warn"
	vPending = "pending"
)

type finding struct {
	verdict, what, detail, fix string
}

type doctorRun struct {
	e        *env
	findings []finding
}

func (d *doctorRun) add(verdict, what, detail, fix string) {
	d.findings = append(d.findings, finding{verdict, what, detail, fix})
}

// runDoctor checks Claude Code's setup on this machine and in a
// repository, and names the fix for each failure: its version, the
// managed settings harness setup writes and what could override them,
// the credential helper, the gateway, telemetry, and the repository's
// instructions, skills and .mcp.json.
func runDoctor(e *env, args []string) int {
	fs := newFlags(e, "doctor", "doctor [flags]")
	h := addCommonHarness(e, fs)
	offline := fs.Bool("offline", false, "check files and settings alone: run no credential helper and call no gateway")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	if !h.check(e) {
		return 2
	}
	values, err := defaults.ForEnvironment(*h.cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	d := &doctorRun{e: e}
	gateway := strings.TrimSuffix(*h.gateway, "/")

	d.claudeVersion()
	settings := d.managed(*h.managedDir, gateway, values)
	d.overrides(*h.dir)
	token := ""
	if !*offline {
		token = d.helper(settings)
		d.reach(gateway, token, values, settings)
	}
	d.telemetry(settings)
	d.repository(*h.dir)

	failed := 0
	w := e.stdout
	for _, f := range d.findings {
		fmt.Fprintf(w, "%-7s %s", f.verdict, f.what)
		if f.detail != "" {
			fmt.Fprintf(w, ": %s", f.detail)
		}
		fmt.Fprintln(w)
		if f.fix != "" && f.verdict != vOK {
			fmt.Fprintf(w, "        fix: %s\n", f.fix)
		}
		if f.verdict == vFail {
			failed++
		}
	}
	if failed > 0 {
		fmt.Fprintf(e.stderr, "agentctl: %d check(s) failed\n", failed)
		return 1
	}
	return 0
}

var versionRE = regexp.MustCompile(`(\d+)\.(\d+)\.(\d+)`)

// compareVersions compares two X.Y.Z versions.
func compareVersions(a, b string) int {
	pa, pb := versionRE.FindStringSubmatch(a), versionRE.FindStringSubmatch(b)
	for i := 1; i <= 3; i++ {
		x, _ := strconv.Atoi(pa[i])
		y, _ := strconv.Atoi(pb[i])
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	return 0
}

func (d *doctorRun) claudeVersion() {
	out, err := execx.Output(d.e.ctx, d.e.runner, execx.Cmd{Name: defaults.Get(d.e.getenv, "AGENTCTL_CLAUDE", "claude"), Args: []string{"--version"}})
	v := versionRE.FindString(string(out))
	switch {
	case err != nil || v == "":
		d.add(vFail, "Claude Code", "claude --version did not run", "install Claude Code "+claudePin+" (npm install -g @anthropic-ai/claude-code@"+claudePin+")")
	case compareVersions(v, claudeFloor) < 0:
		d.add(vFail, "Claude Code", v+" is older than "+claudeFloor+", below which managed allowedProviders does not hold", "install "+claudePin)
	case v != claudePin:
		d.add(vWarn, "Claude Code", v+", not the pinned "+claudePin, "install "+claudePin+", the version the platform checks")
	default:
		d.add(vOK, "Claude Code", v, "")
	}
}

// effective merges Claude Code's managed files as it does:
// managed-settings.json first, then managed-settings.d/*.json in name
// order; later single values win, lists combine, blocks merge by key.
func effective(dir string) (map[string]any, []string, error) {
	files := []string{filepath.Join(dir, "managed-settings.json")}
	more, _ := filepath.Glob(filepath.Join(dir, "managed-settings.d", "*.json"))
	sort.Strings(more)
	for _, m := range more {
		if !strings.HasPrefix(filepath.Base(m), ".") {
			files = append(files, m)
		}
	}
	out := map[string]any{}
	var read []string
	for _, f := range files {
		data, err := os.ReadFile(f)
		if os.IsNotExist(err) {
			continue
		}
		if err != nil {
			return nil, read, err
		}
		var v map[string]any
		if err := json.Unmarshal(data, &v); err != nil {
			return nil, read, fmt.Errorf("%s: %w", f, err)
		}
		mergeSettings(out, v)
		read = append(read, f)
	}
	return out, read, nil
}

func mergeSettings(dst, src map[string]any) {
	for k, v := range src {
		switch sv := v.(type) {
		case map[string]any:
			if dv, ok := dst[k].(map[string]any); ok {
				mergeSettings(dv, sv)
				continue
			}
		case []any:
			if dv, ok := dst[k].([]any); ok {
				seen := map[string]bool{}
				var merged []any
				for _, x := range append(append([]any{}, dv...), sv...) {
					b, _ := json.Marshal(x)
					if !seen[string(b)] {
						seen[string(b)] = true
						merged = append(merged, x)
					}
				}
				dst[k] = merged
				continue
			}
		}
		dst[k] = v
	}
}

func settingsEnv(settings map[string]any) map[string]any {
	m, _ := settings["env"].(map[string]any)
	if m == nil {
		return map[string]any{}
	}
	return m
}

func (d *doctorRun) managed(dir, gateway string, values defaults.Env) map[string]any {
	const fix = "run agentctl harness setup (as root, since managed settings are machine-wide)"
	s, read, err := effective(dir)
	if err != nil {
		d.add(vFail, "managed settings", err.Error(), "fix or remove the file; then "+fix)
		return map[string]any{}
	}
	if len(read) == 0 {
		d.add(vFail, "managed settings", "none in "+dir, fix)
		return s
	}
	d.add(vOK, "managed settings", strings.Join(read, ", "), "")
	env := settingsEnv(s)
	str := func(m map[string]any, k string) string { v, _ := m[k].(string); return v }

	if p, _ := s["allowedProviders"].([]any); len(p) == 1 && p[0] == "customEndpoint" {
		d.add(vOK, "allowedProviders", `["customEndpoint"]`, "")
	} else {
		b, _ := json.Marshal(s["allowedProviders"])
		d.add(vFail, "allowedProviders", string(b)+", not the gateway alone", `managed lists combine: remove other providers from every file in `+dir+`, then `+fix)
	}
	check := func(what string, ok bool, got, fix2 string) {
		if ok {
			d.add(vOK, what, got, "")
		} else {
			if got == "" {
				got = "unset"
			}
			d.add(vFail, what, got, fix2)
		}
	}
	check("ANTHROPIC_BASE_URL", str(env, "ANTHROPIC_BASE_URL") == gateway, str(env, "ANTHROPIC_BASE_URL"), "the gateway, "+gateway+": "+fix)
	helper := str(s, "apiKeyHelper")
	check("apiKeyHelper", strings.HasSuffix(helper, " token --scope "+defaults.RouteScope), helper, "agentctl token --scope "+defaults.RouteScope+": "+fix)
	ttl, err := strconv.Atoi(str(env, "CLAUDE_CODE_API_KEY_HELPER_TTL_MS"))
	check("CLAUDE_CODE_API_KEY_HELPER_TTL_MS", err == nil && ttl > 0 && ttl < 300000, str(env, "CLAUDE_CODE_API_KEY_HELPER_TTL_MS"), "under 300000, a route token's life: "+fix)
	aliases := []string{values.MainModel, values.FastModel}
	for _, k := range []string{"ANTHROPIC_MODEL", "ANTHROPIC_DEFAULT_OPUS_MODEL", "ANTHROPIC_DEFAULT_SONNET_MODEL", "ANTHROPIC_DEFAULT_HAIKU_MODEL"} {
		v := str(env, k)
		check(k, v == values.MainModel || v == values.FastModel, v, "one of the gateway's aliases ("+strings.Join(aliases, ", ")+"): "+fix)
	}
	win, err := strconv.Atoi(str(env, "CLAUDE_CODE_AUTO_COMPACT_WINDOW"))
	check("CLAUDE_CODE_AUTO_COMPACT_WINDOW", err == nil && win >= 100000 && win <= values.ContextWindow, str(env, "CLAUDE_CODE_AUTO_COMPACT_WINDOW"), fmt.Sprintf("at most the route's window, %d: %s", values.ContextWindow, fix))
	check("CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC", str(env, "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC") == "1", str(env, "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"), "1, so nothing goes to Anthropic around the gateway: "+fix)
	skip, _ := s["skipWebFetchPreflight"].(bool)
	check("skipWebFetchPreflight", skip, fmt.Sprint(s["skipWebFetchPreflight"]), "true, so WebFetch asks api.anthropic.com nothing: "+fix)
	if ca := str(env, "NODE_EXTRA_CA_CERTS"); ca != "" {
		check("NODE_EXTRA_CA_CERTS", fileExists(ca), ca, "the CA file the gateway's certificate chains to: "+fix+" -ca-file FILE")
	} else if strings.HasSuffix(hostOf(gateway), ".agentic.internal") {
		d.add(vFail, "NODE_EXTRA_CA_CERTS", "unset, and the local gateway's certificate is the local CA's", fix+" -ca-file FILE")
	}
	return s
}

func hostOf(u string) string {
	u = strings.TrimPrefix(strings.TrimPrefix(u, "https://"), "http://")
	h, _, _ := strings.Cut(u, "/")
	h, _, _ = strings.Cut(h, ":")
	return h
}

// providerVars select a provider other than the gateway, which
// allowedProviders refuses; authToken stops the helper's refresh.
var providerVars = []string{"CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY", "CLAUDE_CODE_USE_ANTHROPIC_AWS", "CLAUDE_CODE_USE_MANTLE"}

// overrides looks for what a person's own settings or environment set
// against the managed ones: the managed values win for ANTHROPIC_BASE_URL
// and the provider, but a token in ANTHROPIC_AUTH_TOKEN stops the
// helper's refresh, and prompts in telemetry are refused.
func (d *doctorRun) overrides(dir string) {
	sources := map[string]map[string]any{"the environment": {}}
	for _, k := range append(append([]string{}, providerVars...), "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_API_KEY", "ANTHROPIC_BASE_URL", "OTEL_LOG_USER_PROMPTS") {
		if v := d.e.getenv(k); v != "" {
			sources["the environment"][k] = v
		}
	}
	files := []string{filepath.Join(dir, ".claude", "settings.json"), filepath.Join(dir, ".claude", "settings.local.json")}
	if home := d.e.getenv("HOME"); home != "" {
		files = append([]string{filepath.Join(home, ".claude", "settings.json")}, files...)
	}
	for _, f := range files {
		data, err := os.ReadFile(f)
		if err != nil {
			continue
		}
		var v map[string]any
		if json.Unmarshal(data, &v) != nil {
			d.add(vWarn, "settings", f+" is not JSON", "fix it, or Claude Code may not start")
			continue
		}
		sources[f] = settingsEnv(v)
		if h, _ := v["apiKeyHelper"].(string); h != "" {
			sources[f]["apiKeyHelper"] = h
		}
	}
	names := make([]string, 0, len(sources))
	for n := range sources {
		names = append(names, n)
	}
	sort.Strings(names)
	clean := true
	for _, src := range names {
		vars := sources[src]
		for _, k := range providerVars {
			if v, ok := vars[k]; ok && v != "" && v != "0" {
				clean = false
				d.add(vFail, k, "set in "+src+": Claude Code would leave the gateway, and allowedProviders refuses to start", "unset "+k+" in "+src)
			}
		}
		if _, ok := vars["ANTHROPIC_AUTH_TOKEN"]; ok {
			clean = false
			d.add(vFail, "ANTHROPIC_AUTH_TOKEN", "set in "+src+": Claude Code then never runs the helper again on expiry or a 401", "unset ANTHROPIC_AUTH_TOKEN in "+src)
		}
		if _, ok := vars["ANTHROPIC_API_KEY"]; ok {
			clean = false
			d.add(vWarn, "ANTHROPIC_API_KEY", "set in "+src+": a provider key has no use through the gateway", "unset ANTHROPIC_API_KEY in "+src)
		}
		if v, ok := vars["ANTHROPIC_BASE_URL"]; ok {
			clean = false
			d.add(vWarn, "ANTHROPIC_BASE_URL", fmt.Sprintf("%v in %s: the managed value wins, and allowedProviders refuses any other", v, src), "unset it in "+src)
		}
		if h, ok := vars["apiKeyHelper"]; ok {
			clean = false
			d.add(vWarn, "apiKeyHelper", fmt.Sprintf("%v in %s: the managed one wins", h, src), "remove it from "+src)
		}
		if v, ok := vars["OTEL_LOG_USER_PROMPTS"]; ok && v != "0" && v != "" {
			clean = false
			d.add(vFail, "OTEL_LOG_USER_PROMPTS", "set in "+src+": prompts would leave the machine in telemetry, and the platform keeps content capture off", "unset OTEL_LOG_USER_PROMPTS in "+src)
		}
	}
	if clean {
		d.add(vOK, "overrides", "no provider, token, base URL or prompt logging set against the managed settings", "")
	}
}

// helper runs the managed credential helper as Claude Code would, and
// keeps its output, a token, for the gateway check alone: it is never
// printed.
func (d *doctorRun) helper(settings map[string]any) string {
	h, _ := settings["apiKeyHelper"].(string)
	if h == "" {
		return ""
	}
	out, err := execx.Output(d.e.ctx, d.e.runner, execx.Cmd{Name: "/bin/sh", Args: []string{"-c", h}})
	tok := strings.TrimSpace(string(out))
	if err != nil || tok == "" || strings.ContainsAny(tok, " \n") {
		msg := "the helper gave no token"
		var se *execx.StatusError
		if ok := asStatus(err, &se); ok {
			msg = lastNonEmpty(se.Stderr)
		}
		d.add(vFail, "credential", msg, "sign in: agentctl login (the browser may be on another machine: -flow device)")
		return ""
	}
	d.add(vOK, "credential", "the helper printed a token", "")
	return tok
}

func asStatus(err error, se **execx.StatusError) bool {
	e, ok := err.(*execx.StatusError)
	if ok {
		*se = e
	}
	return ok
}

func lastNonEmpty(s string) string {
	lines := strings.Split(strings.TrimSpace(s), "\n")
	return strings.TrimSpace(lines[len(lines)-1])
}

// reach asks the gateway's model route to count a message's tokens with
// the helper's token: the route, the token and the alias together,
// without a model call.
func (d *doctorRun) reach(gateway, token string, values defaults.Env, settings map[string]any) {
	hc, err := d.gatewayClient(settings)
	if err != nil {
		d.add(vFail, "gateway", err.Error(), "check NODE_EXTRA_CA_CERTS")
		return
	}
	if token == "" {
		req, _ := http.NewRequestWithContext(d.e.ctx, http.MethodGet, gateway+"/", nil)
		resp, err := hc.Do(req)
		if err != nil {
			d.add(vFail, "gateway", err.Error(), "check that "+gateway+" resolves and answers here")
			return
		}
		resp.Body.Close()
		d.add(vWarn, "gateway", fmt.Sprintf("%s answers (%s), not checked with a token", gateway, resp.Status), "sign in, then run agentctl doctor again")
		return
	}
	body, _ := json.Marshal(map[string]any{"model": values.MainModel, "messages": []map[string]string{{"role": "user", "content": "agentctl doctor"}}})
	req, _ := http.NewRequestWithContext(d.e.ctx, http.MethodPost, gateway+"/v1/messages/count_tokens", bytes.NewReader(body))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("anthropic-version", "2023-06-01")
	resp, err := hc.Do(req)
	if err != nil {
		d.add(vFail, "gateway", err.Error(), "check that "+gateway+" resolves and answers here")
		return
	}
	defer resp.Body.Close()
	msg, _ := io.ReadAll(io.LimitReader(resp.Body, 4096))
	switch {
	case resp.StatusCode == http.StatusOK:
		d.add(vOK, "gateway", fmt.Sprintf("the model route counted tokens for %s with the helper's token", values.MainModel), "")
	case resp.StatusCode == http.StatusUnauthorized || resp.StatusCode == http.StatusForbidden:
		d.add(vFail, "gateway", fmt.Sprintf("the model route refused the token (%s)", resp.Status), "agentctl login -scope "+defaults.RouteScope+", or ask for the model route's role")
	default:
		d.add(vFail, "gateway", fmt.Sprintf("the model route answered %s: %s", resp.Status, oneLine(string(msg), 120)), "check the gateway's model route and the alias "+values.MainModel)
	}
}

func (d *doctorRun) gatewayClient(settings map[string]any) (*http.Client, error) {
	if d.e.httpClient != nil {
		return d.e.httpClient, nil
	}
	ca, _ := settingsEnv(settings)["NODE_EXTRA_CA_CERTS"].(string)
	hc, err := httpClientWithCA(ca)
	if err != nil {
		return nil, err
	}
	hc.Timeout = 15 * time.Second
	return hc, nil
}

func (d *doctorRun) telemetry(settings map[string]any) {
	env := settingsEnv(settings)
	if v, _ := env["OTEL_LOG_USER_PROMPTS"].(string); v != "" && v != "0" {
		d.add(vFail, "telemetry", "the managed settings log prompts", "remove OTEL_LOG_USER_PROMPTS from the managed settings")
		return
	}
	if env["CLAUDE_CODE_ENABLE_TELEMETRY"] != "1" || env["OTEL_EXPORTER_OTLP_ENDPOINT"] == nil {
		d.add(vPending, "telemetry", "not set: the platform has no collector endpoint for workstations yet", "once it has one, agentctl harness setup -otel-endpoint URL")
		return
	}
	d.add(vOK, "telemetry", fmt.Sprintf("to %v, prompts redacted", env["OTEL_EXPORTER_OTLP_ENDPOINT"]), "")
}

// repository checks the repository's instructions, skills, lock file and
// .mcp.json.
func (d *doctorRun) repository(dir string) {
	root, err := filepath.Abs(dir)
	if err != nil {
		d.add(vFail, "repository", err.Error(), "")
		return
	}
	for _, n := range []string{"CLAUDE.md", "CLAUDE.local.md", ".claude/CLAUDE.md"} {
		if fileExists(filepath.Join(root, n)) {
			d.add(vFail, "instructions", n+" is there, so Claude Code does not read AGENTS.md here", "remove "+n+"; AGENTS.md is the one instructions file")
		}
	}
	if !fileExists(filepath.Join(root, "AGENTS.md")) {
		d.add(vWarn, "instructions", "no AGENTS.md in "+root, "add AGENTS.md, if this is a repository's root")
	} else {
		d.add(vOK, "instructions", "AGENTS.md", "")
	}
	skills, _ := filepath.Glob(filepath.Join(root, ".agents", "skills", "*", "SKILL.md"))
	sort.Strings(skills)
	for _, s := range skills {
		name := filepath.Base(filepath.Dir(s))
		link := ".claude/skills/" + name
		if got, err := os.Readlink(filepath.Join(root, filepath.FromSlash(link))); err == nil && got == target(link, ".agents/skills/"+name) {
			d.add(vOK, "skill "+name, "linked from "+link, "")
		} else {
			d.add(vFail, "skill "+name, "Claude Code does not see it: "+link+" is not its link", "agentctl harness setup")
		}
	}
	if sp, err := spec.Vendored(); err == nil {
		if lk, err := lock.Load(sp, root); err != nil {
			d.add(vFail, "lock file", err.Error(), "agentctl install again what it names")
		} else {
			for _, a := range lk.Artifacts {
				if !fileExists(filepath.Join(root, filepath.FromSlash(a.Path))) {
					d.add(vFail, a.Kind+" "+a.Name, a.Path+" is missing", "agentctl install "+a.Name)
				}
			}
		}
	}
	servers, err := requiredServers(root, nil)
	if err != nil {
		d.add(vFail, mcpFile, err.Error(), "")
		return
	}
	if len(servers) == 0 {
		return
	}
	var doc struct {
		MCPServers map[string]any `json:"mcpServers"`
	}
	data, _ := os.ReadFile(filepath.Join(root, mcpFile))
	json.Unmarshal(data, &doc)
	var missing []string
	for _, s := range servers {
		entry, ok := doc.MCPServers[s].(map[string]any)
		if !ok {
			missing = append(missing, s)
			continue
		}
		if o, _ := entry["oauth"].(map[string]any); o["clientId"] != mcpClient {
			d.add(vFail, mcpFile, s+" signs in as no pre-registered client, and the realm refuses dynamic registration", "agentctl harness setup, which names the "+mcpClient+" client")
		}
	}
	if len(missing) > 0 {
		d.add(vFail, mcpFile, "workload.yaml requires "+strings.Join(missing, ", ")+", which it does not name", "agentctl harness setup")
	} else {
		d.add(vOK, mcpFile, "names "+strings.Join(servers, ", "), "")
	}
}

func httpClientWithCA(ca string) (*http.Client, error) {
	return auth.HTTPClient(ca, "agentctl/"+version)
}
