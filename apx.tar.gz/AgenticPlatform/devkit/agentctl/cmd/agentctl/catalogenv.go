package main

import (
	"flag"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/catalog"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/cosign"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/gitlab"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/oci"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/s3"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// catalogFlags are the flags of every command that reads the signed
// catalog index: which environment, and where its index is.
type catalogFlags struct {
	environment *string
	index       *string
}

func addCatalogFlags(e *env, fs *flag.FlagSet) catalogFlags {
	return catalogFlags{
		environment: fs.String("environment", defaults.Get(e.getenv, "AGENTCTL_ENVIRONMENT", defaults.Environment), "the environment whose catalog index, registry and keys to use ($AGENTCTL_ENVIRONMENT)"),
		index:       fs.String("index", "", "the signed catalog index: a file, an https:// URL of catalog.json, or s3://<bucket>/<prefix>/ for the newest build under it ($AGENTCTL_CATALOG_INDEX; default the environment's index bucket)"),
	}
}

// catalogEnv is what a catalog command needs from one environment.
type catalogEnv struct {
	values defaults.Env
	spec   *spec.Spec
	cosign cosign.Cosign
	oras   oci.Client
	s3     s3.Client
	// tmp holds the keys written for cosign; cleanup removes it.
	tmp string
	// keyDesc says which key verified, for messages: the environment's,
	// or the one an AGENTCTL_*_KEY variable names.
	keyDesc map[string]string
}

func (c *catalogEnv) cleanup() {
	if c.tmp != "" {
		os.RemoveAll(c.tmp)
	}
}

func newCatalogEnv(e *env, environment string) (*catalogEnv, error) {
	values, err := defaults.ForEnvironment(environment)
	if err != nil {
		return nil, err
	}
	// The environment's registry.host, for a registry of one's own.
	if v := e.getenv("AGENTCTL_REGISTRY"); v != "" {
		values.Registry = v
	}
	s, err := spec.Vendored()
	if err != nil {
		return nil, err
	}
	if !s.Has(spec.CatalogSchema) {
		return nil, fmt.Errorf("the vendored spec (%s) has no catalog index schema", s.Source)
	}
	c := &catalogEnv{values: values, spec: s, keyDesc: map[string]string{}}
	c.cosign = cosign.Cosign{Runner: e.runner, Path: e.getenv("AGENTCTL_COSIGN")}
	c.oras = oci.Client{Runner: e.runner, Path: e.getenv("AGENTCTL_ORAS"), PlainHTTP: plainHTTP(e, values)}
	awsEnv := e.environ()
	if e.getenv("AWS_ENDPOINT_URL") == "" && values.AWSEndpoint != "" {
		awsEnv = append(awsEnv, "AWS_ENDPOINT_URL="+values.AWSEndpoint)
	}
	c.s3 = s3.Client{Runner: e.runner, Path: e.getenv("AGENTCTL_AWS"), Env: awsEnv}
	return c, nil
}

// plainHTTP says which registry hosts speak plain HTTP: the
// environment's, or AGENTCTL_PLAIN_HTTP_REGISTRIES.
func plainHTTP(e *env, values defaults.Env) func(string) bool {
	hosts := values.PlainHTTP
	if v := e.getenv("AGENTCTL_PLAIN_HTTP_REGISTRIES"); v != "" {
		hosts = strings.Split(v, ",")
	}
	return func(h string) bool { return slices.Contains(hosts, h) }
}

// key returns what cosign takes as --key for one of the environment's
// keys: AGENTCTL_RELEASE_KEY or AGENTCTL_RECORD_KEY (a PEM file or a KMS
// URI) when set, else the public key agentctl carries, written to a file
// of its own. Never a key fetched from where the index or an artifact
// came from.
func (c *catalogEnv) key(e *env, which string) (string, error) {
	envVar := map[string]string{defaults.ReleaseKey: "AGENTCTL_RELEASE_KEY", defaults.RecordKey: "AGENTCTL_RECORD_KEY"}[which]
	if v := e.getenv(envVar); v != "" {
		c.keyDesc[which] = "the " + strings.TrimSuffix(which, "-signing") + " key $" + envVar + " names"
		return v, nil
	}
	c.keyDesc[which] = "the " + c.values.Name + " " + strings.TrimSuffix(which, "-signing") + " key"
	pem, err := defaults.PublicKey(c.values.Name, which)
	if err != nil {
		return "", fmt.Errorf("%v: set %s", err, envVar)
	}
	if c.tmp == "" {
		if c.tmp, err = os.MkdirTemp("", "agentctl-keys-"); err != nil {
			return "", err
		}
	}
	p := filepath.Join(c.tmp, which+".pub")
	if err := os.WriteFile(p, pem, 0o600); err != nil {
		return "", err
	}
	return p, nil
}

// readIndex fetches the environment's signed index and verifies it with
// the record key.
func (c *catalogEnv) readIndex(e *env, f catalogFlags) (*catalog.Verified, error) {
	location := *f.index
	if location == "" {
		location = defaults.Get(e.getenv, "AGENTCTL_CATALOG_INDEX", c.values.Index)
	}
	key, err := c.key(e, defaults.RecordKey)
	if err != nil {
		return nil, err
	}
	hc, err := httpClient(e)
	if err != nil {
		return nil, err
	}
	r := &catalog.Reader{
		Spec: c.spec, Cosign: c.cosign, S3: c.s3, HTTP: hc,
		Header: func(u *url.URL, h http.Header) { gitlabHeader(e, u, h) },
		Warn:   func(s string) { fmt.Fprintln(e.stderr, "agentctl: warning: "+s) },
	}
	return r.Read(e.ctx, location, key, c.values.Name)
}

// gitlabHeader adds the person's GitLab token to a request for the
// GitLab instance alone, such as an index in a generic package registry.
func gitlabHeader(e *env, u *url.URL, h http.Header) {
	base, err := url.Parse(gitlabBase(e))
	if err != nil || !strings.EqualFold(u.Host, base.Host) {
		return
	}
	if tok, _, err := gitlab.Token(e.getenv, base.Host); err == nil {
		h.Set("Authorization", "Bearer "+tok)
	}
}
