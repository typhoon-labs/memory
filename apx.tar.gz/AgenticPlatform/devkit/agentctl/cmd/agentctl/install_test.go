package main

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/lock"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

const libraryRegistry = "floci:4566/000000000000/us-east-1/library/"

// library is one released library artifact in the fake registry.
type library struct {
	kind, name, version, commit string
	repo, digest, layerDigest   string
	layer                       []byte
}

func tarGz(t *testing.T, files map[string]string) []byte {
	t.Helper()
	var buf bytes.Buffer
	z := gzip.NewWriter(&buf)
	tw := tar.NewWriter(z)
	for name, body := range files {
		tw.WriteHeader(&tar.Header{Name: name, Typeflag: tar.TypeReg, Mode: 0o644, Size: int64(len(body))})
		tw.Write([]byte(body))
	}
	tw.Close()
	z.Close()
	return buf.Bytes()
}

func artifactYAML(kind, name, version, commit string) string {
	return "kind: " + kind + "\nname: " + name + "\nversion: " + version + "\n" +
		"description: A test artifact.\nowner: platform\nsupport: experimental\n" +
		"provenance:\n  repository: https://gitlab.example.com/example/agent-library\n  commit: " + commit + "\n  pipeline_id: 3085170001\n"
}

// release pushes a scratch image, as library-release does, and signs and
// attests it with the release key.
func release(t *testing.T, f *fakeTools, kind, name, version, commit string, files map[string]string) *library {
	t.Helper()
	if files == nil {
		files = map[string]string{}
	}
	if _, ok := files["artifact.yaml"]; !ok {
		files["artifact.yaml"] = artifactYAML(kind, name, version, commit)
	}
	l := &library{kind: kind, name: name, version: version, commit: commit, repo: libraryRegistry + kind + "/" + name}
	l.layer = tarGz(t, files)
	l.layerDigest = f.push(l.repo, l.layer)
	cfg := f.push(l.repo, []byte(`{"architecture":"amd64","os":"linux","rootfs":{"type":"layers"}}`))
	var manifests []map[string]any
	for _, arch := range []string{"amd64", "arm64"} {
		m, _ := json.Marshal(map[string]any{
			"schemaVersion": 2, "mediaType": "application/vnd.oci.image.manifest.v1+json",
			"config":      map[string]any{"mediaType": "application/vnd.oci.image.config.v1+json", "digest": cfg, "size": 60},
			"layers":      []map[string]any{{"mediaType": "application/vnd.oci.image.layer.v1.tar+gzip", "digest": l.layerDigest, "size": len(l.layer)}},
			"annotations": map[string]string{"arch": arch},
		})
		manifests = append(manifests, map[string]any{"mediaType": "application/vnd.oci.image.manifest.v1+json", "digest": f.push(l.repo, m), "size": len(m), "platform": map[string]string{"os": "linux", "architecture": arch}})
	}
	idx, _ := json.Marshal(map[string]any{"schemaVersion": 2, "mediaType": "application/vnd.oci.image.index.v1+json", "manifests": manifests})
	l.digest = f.push(l.repo, idx)
	f.tag(l.repo, "v"+version, l.digest)
	key := envKey(t, defaults.ReleaseKey)
	f.sign(l.digest, key)
	f.attest(l.digest, "slsaprovenance1", key, provenance(commit))
	return l
}

func provenance(commit string) map[string]any {
	return map[string]any{
		"_type": "https://in-toto.io/Statement/v1", "predicateType": "https://slsa.dev/provenance/v1",
		"predicate": map[string]any{"buildDefinition": map[string]any{"resolvedDependencies": []map[string]any{
			{"uri": "git+https://gitlab.example.com/example/agent-library", "digest": map[string]string{"gitCommit": commit}},
		}}},
	}
}

func (l *library) ref() string { return l.repo + "@" + l.digest }

// indexWith is the spec's example index with the two library entries
// pointing at these releases, signed with the record key.
func indexWith(t *testing.T, libs ...*library) string {
	t.Helper()
	var ix map[string]any
	json.Unmarshal(exampleIndex(t), &ix)
	for _, raw := range ix["entries"].([]any) {
		en := raw.(map[string]any)
		md := en["metadata"].(map[string]any)
		for _, l := range libs {
			if md["name"] == l.name {
				en["reference"] = l.ref()
				en["version"] = l.version
				md["version"] = l.version
				en["source"].(map[string]any)["commit"] = l.commit
				en["source"].(map[string]any)["tag"] = l.kind + "/" + l.name + "/v" + l.version
			}
		}
	}
	b, _ := json.Marshal(ix)
	return writeIndex(t, t.TempDir(), b, envKey(t, defaults.RecordKey))
}

const (
	commitA = "cc3f8a46114bd26b08a51b8c04bc321a0863f6d8"
	commitB = "d2b359f4e5e625e8a60f90dddb36ea67131f3164"
	commitC = "0123456789abcdef0123456789abcdef01234567"
)

func skillFiles() map[string]string {
	return map[string]string{"SKILL.md": "---\nname: platform-conventions\n---\n# Conventions\n", "references/names.md": "kebab-case\n"}
}

func readLock(t *testing.T, repo string) *lock.Lock {
	t.Helper()
	s, _ := spec.Vendored()
	l, err := lock.Load(s, repo)
	if err != nil {
		t.Fatal(err)
	}
	return l
}

func TestInstallSkill(t *testing.T) {
	te, f := catalogTestEnv(t)
	skill := release(t, f, "skill", "platform-conventions", "0.1.0", commitA, skillFiles())
	prompt := release(t, f, "prompt", "summarise-changes", "0.1.0", commitB, map[string]string{"prompt.md": "Summarise the changes.\n"})
	idx := indexWith(t, skill, prompt)
	repo := t.TempDir()

	code, out, errOut := te.run("install", "-index", idx, "-dir", repo, "platform-conventions", "summarise-changes@0.1.0")
	if code != 0 {
		t.Fatalf("install: code %d, stderr %q", code, errOut)
	}
	if !strings.Contains(out, "installed skill platform-conventions 0.1.0 ("+skill.digest+") at .agents/skills/platform-conventions, linked from .claude/skills/platform-conventions") {
		t.Errorf("stdout: %q", out)
	}
	if !strings.Contains(errOut, "provenance (commit "+commitA+") with the local release key") {
		t.Errorf("stderr: %q", errOut)
	}
	if b, _ := os.ReadFile(filepath.Join(repo, ".agents/skills/platform-conventions/SKILL.md")); !strings.Contains(string(b), "# Conventions") {
		t.Errorf("SKILL.md: %q", b)
	}
	if b, _ := os.ReadFile(filepath.Join(repo, ".claude/skills/platform-conventions/references/names.md")); string(b) != "kebab-case\n" {
		t.Errorf("through the link: %q", b)
	}
	if tgt, _ := os.Readlink(filepath.Join(repo, ".claude/skills/platform-conventions")); tgt != "../../.agents/skills/platform-conventions" {
		t.Errorf("link: %q", tgt)
	}
	if _, err := os.Stat(filepath.Join(repo, ".agents/prompts/summarise-changes/prompt.md")); err != nil {
		t.Errorf("the prompt: %v", err)
	}
	l := readLock(t, repo)
	if len(l.Artifacts) != 2 || l.Artifacts[0].Kind != "prompt" || len(l.Artifacts[0].Links) != 0 ||
		l.Artifacts[1].Reference != skill.ref() || l.Artifacts[1].Links[0].Path != ".claude/skills/platform-conventions" {
		t.Errorf("lock: %+v", l)
	}
	raw, _ := os.ReadFile(filepath.Join(repo, lock.File))
	if !strings.HasPrefix(string(raw), "# Written by agentctl") || !strings.Contains(string(raw), "lockfile_version: 1") {
		t.Errorf("lock file:\n%s", raw)
	}
	// No staging directory is left behind.
	if m, _ := filepath.Glob(filepath.Join(repo, ".agents/*/.agentctl-*")); len(m) != 0 {
		t.Errorf("left behind: %v", m)
	}

	// Again: the same release, replaced in place.
	if code, _, errOut := te.run("install", "-index", idx, "-dir", repo, "platform-conventions"); code != 0 {
		t.Fatalf("install again: code %d, stderr %q", code, errOut)
	}
	// By the digest the index records.
	if code, _, errOut := te.run("install", "-index", idx, "-dir", repo, "platform-conventions@"+skill.digest); code != 0 {
		t.Fatalf("install by digest: code %d, stderr %q", code, errOut)
	}
	// Every fetch was by digest.
	for _, c := range f.cmds {
		if strings.HasPrefix(c, "oras") && !strings.Contains(c, "@sha256:") {
			t.Errorf("not by digest: %s", c)
		}
	}
}

// TestInstallRefuses is check 9's refusals and their kin: each leaves the
// repository as it was.
func TestInstallRefuses(t *testing.T) {
	cases := []struct {
		name  string
		setup func(t *testing.T, f *fakeTools, l *library) (arg string, idx string)
		want  string
	}{
		{"a changed artifact", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			f.serve[l.layerDigest] = tarGz(t, map[string]string{"SKILL.md": "# Changed\n", "artifact.yaml": artifactYAML("skill", l.name, l.version, l.commit)})
			return l.name, indexWith(t, l)
		}, "the registry answered with other content"},
		{"another key's signature", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			f.unsign(l.digest)
			f.sign(l.digest, otherKey)
			return l.name, indexWith(t, l)
		}, "no signature verifies with the key"},
		{"signed by the record key", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			f.unsign(l.digest)
			f.sign(l.digest, envKey(t, defaults.RecordKey))
			return l.name, indexWith(t, l)
		}, "no signature verifies with the key"},
		{"the release key's attestations, but no sign statement", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			// Provenance and an SBOM by the release key are bundles the key
			// made on the digest, which cosign v3's verify alone accepts:
			// neither is a signature.
			f.unsign(l.digest)
			f.attest(l.digest, "spdxjson", envKey(t, defaults.ReleaseKey), map[string]any{"predicateType": "https://spdx.dev/Document"})
			return l.name, indexWith(t, l)
		}, "no signature verifies with the key"},
		{"another key's sign statement beside the release key's provenance", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			f.unsign(l.digest)
			f.sign(l.digest, envKey(t, defaults.RecordKey))
			return l.name, indexWith(t, l)
		}, "no signature verifies with the key"},
		{"a digest not in the index", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			other := release(t, f, "skill", l.name, "0.2.0", commitC, skillFiles())
			return l.name + "@" + other.digest, indexWith(t, l)
		}, "is not in the index"},
		{"a version not in the index", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			return l.name + "@0.0.9", indexWith(t, l)
		}, "holds platform-conventions at 0.1.0 alone"},
		{"no provenance by the release key", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			delete(f.attested[l.digest], "slsaprovenance1")
			f.attest(l.digest, "slsaprovenance1", otherKey, provenance(l.commit))
			return l.name, indexWith(t, l)
		}, "no slsaprovenance1 attestation verifies"},
		{"provenance of another commit", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			delete(f.attested[l.digest], "slsaprovenance1")
			f.attest(l.digest, "slsaprovenance1", envKey(t, defaults.ReleaseKey), provenance(commitC))
			return l.name, indexWith(t, l)
		}, "its provenance names commit " + commitC},
		{"an artifact.yaml for another name", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			files := skillFiles()
			files["artifact.yaml"] = artifactYAML("skill", "platform-other", l.version, l.commit)
			l2 := release(t, f, "skill", l.name, l.version, l.commit, files)
			return l.name, indexWith(t, l2)
		}, "artifact.yaml's name is platform-other"},
		{"a skill without SKILL.md", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			l2 := release(t, f, "skill", l.name, l.version, l.commit, map[string]string{"README.md": "x"})
			return l.name, indexWith(t, l2)
		}, "without SKILL.md"},
		{"a workload", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			return "reference-mcp", indexWith(t, l)
		}, "is a workload (mcp-server)"},
		{"a name not in the index", func(t *testing.T, f *fakeTools, l *library) (string, string) {
			return "no-such-skill", indexWith(t, l)
		}, "is not in the index"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			te, f := catalogTestEnv(t)
			l := release(t, f, "skill", "platform-conventions", "0.1.0", commitA, skillFiles())
			arg, idx := c.setup(t, f, l)
			repo := t.TempDir()
			code, out, errOut := te.run("install", "-index", idx, "-dir", repo, arg)
			if code != 1 || !strings.Contains(errOut, c.want) || out != "" {
				t.Fatalf("code %d, stdout %q, stderr %q", code, out, errOut)
			}
			left, _ := os.ReadDir(repo)
			var names []string
			for _, d := range left {
				sub, _ := os.ReadDir(filepath.Join(repo, d.Name()))
				for _, s := range sub {
					more, _ := os.ReadDir(filepath.Join(repo, d.Name(), s.Name()))
					if len(more) > 0 || s.Name() != "skills" {
						names = append(names, d.Name()+"/"+s.Name())
					}
				}
			}
			if len(names) > 0 {
				t.Errorf("the refusal left %v", names)
			}
		})
	}
}

func TestInstallKeepsWhatIsNotItsOwn(t *testing.T) {
	te, f := catalogTestEnv(t)
	l := release(t, f, "skill", "platform-conventions", "0.1.0", commitA, skillFiles())
	idx := indexWith(t, l)

	repo := t.TempDir()
	os.MkdirAll(filepath.Join(repo, ".claude/skills/platform-conventions"), 0o755)
	os.WriteFile(filepath.Join(repo, ".claude/skills/platform-conventions/SKILL.md"), []byte("mine"), 0o644)
	if code, _, errOut := te.run("install", "-index", idx, "-dir", repo, l.name); code != 1 || !strings.Contains(errOut, "not agentctl's link") {
		t.Fatalf("over a skill of the person's own: code %d, stderr %q", code, errOut)
	}
	if f.ran("cosign verify ") {
		t.Error("verified before refusing what it could not replace")
	}

	repo = t.TempDir()
	os.MkdirAll(filepath.Join(repo, ".agents/skills/platform-conventions"), 0o755)
	if code, _, errOut := te.run("install", "-index", idx, "-dir", repo, l.name); code != 1 || !strings.Contains(errOut, "does not name it") {
		t.Fatalf("over a copy the lock file does not name: code %d, stderr %q", code, errOut)
	}
}

func TestUpdateAndRemove(t *testing.T) {
	te, f := catalogTestEnv(t)
	v1 := release(t, f, "skill", "platform-conventions", "0.1.0", commitA, skillFiles())
	repo := t.TempDir()
	if code, _, errOut := te.run("install", "-index", indexWith(t, v1), "-dir", repo, v1.name); code != 0 {
		t.Fatalf("install: code %d, stderr %q", code, errOut)
	}
	files := skillFiles()
	files["SKILL.md"] = "---\nname: platform-conventions\n---\n# Conventions, second edition\n"
	v2 := release(t, f, "skill", "platform-conventions", "0.2.0", commitC, files)
	idx2 := indexWith(t, v2)

	code, out, errOut := te.run("update", "-index", idx2, "-dir", repo)
	if code != 0 || !strings.Contains(out, "updated platform-conventions from 0.1.0 to skill platform-conventions 0.2.0") {
		t.Fatalf("update: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	if b, _ := os.ReadFile(filepath.Join(repo, ".claude/skills/platform-conventions/SKILL.md")); !strings.Contains(string(b), "second edition") {
		t.Errorf("after update: %q", b)
	}
	if a := readLock(t, repo).Find(v1.name); a == nil || a.Version != "0.2.0" || a.Reference != v2.ref() {
		t.Errorf("lock after update: %+v", a)
	}
	if code, out, _ := te.run("update", "-index", idx2, "-dir", repo, v1.name); code != 0 || !strings.Contains(out, "is up to date") {
		t.Errorf("update again: code %d, stdout %q", code, out)
	}
	// An update whose new release fails to verify keeps the installed one.
	v3 := release(t, f, "skill", "platform-conventions", "0.3.0", commitB, skillFiles())
	f.unsign(v3.digest)
	if code, _, errOut := te.run("update", "-index", indexWith(t, v3), "-dir", repo); code != 1 || !strings.Contains(errOut, "no signature verifies") {
		t.Errorf("update to an unsigned release: code %d, stderr %q", code, errOut)
	}
	if a := readLock(t, repo).Find(v1.name); a.Version != "0.2.0" {
		t.Errorf("lock after a refused update: %+v", a)
	}
	if b, _ := os.ReadFile(filepath.Join(repo, ".agents/skills/platform-conventions/SKILL.md")); !strings.Contains(string(b), "second edition") {
		t.Errorf("after a refused update: %q", b)
	}

	code, out, errOut = te.run("remove", "-dir", repo, v1.name)
	if code != 0 || !strings.Contains(out, "removed skill platform-conventions") {
		t.Fatalf("remove: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	for _, p := range []string{".agents/skills/platform-conventions", ".claude/skills/platform-conventions"} {
		if _, err := os.Lstat(filepath.Join(repo, p)); err == nil {
			t.Errorf("%s is still there", p)
		}
	}
	if l := readLock(t, repo); len(l.Artifacts) != 0 {
		t.Errorf("lock after remove: %+v", l)
	}
	if code, _, errOut := te.run("remove", "-dir", repo, v1.name); code != 1 || !strings.Contains(errOut, "not installed here") {
		t.Errorf("remove again: code %d, stderr %q", code, errOut)
	}
}

func TestRemoveKeepsALinkNotItsOwn(t *testing.T) {
	te, f := catalogTestEnv(t)
	l := release(t, f, "skill", "platform-conventions", "0.1.0", commitA, skillFiles())
	repo := t.TempDir()
	if code, _, errOut := te.run("install", "-index", indexWith(t, l), "-dir", repo, l.name); code != 0 {
		t.Fatalf("install: code %d, stderr %q", code, errOut)
	}
	link := filepath.Join(repo, ".claude/skills/platform-conventions")
	os.Remove(link)
	os.WriteFile(link, []byte("the person's own"), 0o644)
	code, _, errOut := te.run("remove", "-dir", repo, l.name)
	if code != 0 || !strings.Contains(errOut, "is not agentctl's link") {
		t.Fatalf("remove: code %d, stderr %q", code, errOut)
	}
	if b, _ := os.ReadFile(link); string(b) != "the person's own" {
		t.Errorf("the person's file: %q", b)
	}
}

func TestLockFileRefusedWhenInvalid(t *testing.T) {
	te, f := catalogTestEnv(t)
	l := release(t, f, "skill", "platform-conventions", "0.1.0", commitA, skillFiles())
	repo := t.TempDir()
	os.MkdirAll(filepath.Join(repo, ".agents"), 0o755)
	os.WriteFile(filepath.Join(repo, lock.File), []byte("lockfile_version: 1\nartifacts:\n  - kind: skill\n    name: x\n    version: 0.1.0\n    reference: floci:4566/x@sha256:"+strings.Repeat("a", 64)+"\n    path: .agents/skills/x\n    links:\n      - harness: claude-code\n        path: ../outside\n"), 0o644)
	for _, cmd := range [][]string{{"install", "-index", indexWith(t, l), "-dir", repo, l.name}, {"remove", "-dir", repo, "x"}} {
		if code, _, errOut := te.run(cmd...); code != 1 || !strings.Contains(errOut, "lock.schema.json") {
			t.Errorf("%s with an invalid lock file: code %d, stderr %q", cmd[0], code, errOut)
		}
	}
}
