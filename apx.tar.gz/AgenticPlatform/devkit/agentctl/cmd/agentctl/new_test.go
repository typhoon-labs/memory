package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"
)

// fakeGitLab plays GitLab's API for the generation job: the templates
// project, projects by path, and one pipeline whose statuses it steps
// through, creating the project when the pipeline succeeds, as the job
// would.
type fakeGitLab struct {
	srv      *httptest.Server
	token    string
	forbid   bool
	statuses []string // the pipeline's statuses, one per read
	creates  string   // the path the job creates on success

	mu       sync.Mutex
	projects map[string]int
	inputs   map[string]any
	body     map[string]any
	reads    int
	started  int
}

const templatesPath = "acme/platform/devkit/workload-templates"

func newFakeGitLab(t *testing.T) *fakeGitLab {
	f := &fakeGitLab{token: "glpat-test-token", projects: map[string]int{templatesPath: 89082549},
		statuses: []string{"created", "running", "running", "success"}}
	mux := http.NewServeMux()
	mux.HandleFunc("/api/v4/", f.serve)
	f.srv = httptest.NewTLSServer(mux)
	t.Cleanup(f.srv.Close)
	return f
}

func (f *fakeGitLab) serve(w http.ResponseWriter, r *http.Request) {
	f.mu.Lock()
	defer f.mu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	if r.Header.Get("Authorization") != "Bearer "+f.token || r.Header.Get("PRIVATE-TOKEN") != "" {
		w.WriteHeader(401)
		w.Write([]byte(`{"message":"401 Unauthorized"}`))
		return
	}
	p := strings.TrimPrefix(r.URL.EscapedPath(), "/api/v4/projects/")
	id, rest, _ := strings.Cut(p, "/")
	project, _ := url.PathUnescape(id)
	if _, ok := f.projects[project]; !ok && project != "89082549" {
		w.WriteHeader(404)
		w.Write([]byte(`{"message":"404 Project Not Found"}`))
		return
	}
	switch {
	case r.Method == "GET" && rest == "":
		ns := project[:strings.LastIndex(project, "/")]
		json.NewEncoder(w).Encode(map[string]any{"id": f.projects[project], "path_with_namespace": project,
			"web_url": "https://gitlab.example.test/" + project, "namespace": map[string]any{"full_path": ns}})
	case r.Method == "POST" && rest == "pipeline":
		if f.forbid {
			w.WriteHeader(403)
			w.Write([]byte(`{"message":"403 Forbidden"}`))
			return
		}
		json.NewDecoder(r.Body).Decode(&f.body)
		f.inputs, _ = f.body["inputs"].(map[string]any)
		f.started++
		w.WriteHeader(201)
		json.NewEncoder(w).Encode(map[string]any{"id": 7, "status": "created", "ref": "main", "web_url": "https://gitlab.example.test/pipelines/7"})
	case r.Method == "GET" && rest == "pipelines/7":
		st := f.statuses[min(f.reads, len(f.statuses)-1)]
		f.reads++
		if st == "success" && f.creates != "" {
			f.projects[f.creates] = 99
		}
		json.NewEncoder(w).Encode(map[string]any{"id": 7, "status": st, "ref": "main", "web_url": "https://gitlab.example.test/pipelines/7"})
	case r.Method == "GET" && strings.HasPrefix(rest, "pipelines/7/jobs"):
		json.NewEncoder(w).Encode([]map[string]any{
			{"id": 1, "name": "generate", "stage": "generate", "status": "failed", "web_url": "https://gitlab.example.test/jobs/1"},
			{"id": 2, "name": "check", "stage": "check", "status": "success", "web_url": "https://gitlab.example.test/jobs/2"},
		})
	default:
		w.WriteHeader(404)
		w.Write([]byte(`{"message":"404 Not Found"}`))
	}
}

func newEnv(t *testing.T, f *fakeGitLab) *testEnv {
	te := newTestEnv(t)
	te.vars["GITLAB_TOKEN"] = f.token
	te.vars["AGENTCTL_TEMPLATES"] = templatesPath
	te.vars["GITLAB_HOST"] = f.srv.URL
	return te
}

func (te *testEnv) runNew(f *fakeGitLab, args ...string) (int, string, string) {
	return te.runWith(func(e *env) { e.httpClient = f.srv.Client() }, append([]string{"new", "-poll", "1ms"}, args...)...)
}

func TestNewGenerates(t *testing.T) {
	f := newFakeGitLab(t)
	f.creates = "acme/platform/workloads/reference/notes-agent"
	te := newEnv(t, f)
	code, out, errOut := te.runNew(f, "-team", "reference", "adk-agent", "notes-agent")
	if code != 0 || strings.TrimSpace(out) != "https://gitlab.example.test/acme/platform/workloads/reference/notes-agent" {
		t.Fatalf("code %d, out %q, err %q", code, out, errOut)
	}
	want := map[string]any{"template": "adk-agent", "name": "notes-agent", "team": "reference", "placement": "team"}
	for k, v := range want {
		if f.inputs[k] != v {
			t.Errorf("input %s = %v, want %v", k, f.inputs[k], v)
		}
	}
	if _, ok := f.body["variables"]; ok || f.body["ref"] != "main" {
		t.Errorf("the request: %v", f.body)
	}
	if strings.Contains(out+errOut, f.token) {
		t.Fatal("the GitLab token was printed")
	}
	if !strings.Contains(errOut, "pipeline 7: running") || !strings.Contains(errOut, "pipeline 7: success") {
		t.Errorf("progress: %q", errOut)
	}
}

func TestNewPlacements(t *testing.T) {
	for _, c := range []struct {
		args []string
		path string
	}{
		{[]string{"-shared", "-team", "payments", "mcp-server-python", "ledger-mcp"}, "acme/platform/workloads/shared/ledger-mcp"},
		{[]string{"-incubator", "-team", "reference", "workflow-pipeline", "triage-workflow"}, "acme/platform/incubator/triage-workflow"},
	} {
		f := newFakeGitLab(t)
		f.creates = c.path
		code, out, errOut := newEnv(t, f).runNew(f, c.args...)
		if code != 0 || !strings.HasSuffix(strings.TrimSpace(out), c.path) {
			t.Errorf("%v: code %d, out %q, err %q", c.args, code, out, errOut)
		}
	}
}

func TestNewRefusals(t *testing.T) {
	f := newFakeGitLab(t)
	f.projects["acme/platform/workloads/reference/notes-agent"] = 5
	te := newEnv(t, f)
	for _, c := range []struct {
		args []string
		code int
		want string
	}{
		{[]string{"-team", "reference", "adk-agent", "notes"}, 2, "ends in -agent"},
		{[]string{"-team", "reference", "kagent-agent", "notes-kagent-agent"}, 2, "framework or runtime"},
		{[]string{"-team", "reference", "mcp-server-python", "Notes-mcp"}, 2, "kebab-case"},
		{[]string{"-team", "reference", "go-agent", "notes-agent"}, 2, "unknown template"},
		{[]string{"adk-agent", "notes-agent"}, 2, "-team"},
		{[]string{"-incubator", "workflow-pipeline", "triage-workflow"}, 2, "-team"},
		{[]string{"-incubator", "-team", "Reference", "workflow-pipeline", "triage-workflow"}, 2, "-team"},
		{[]string{"-shared", "-incubator", "adk-agent", "notes-agent"}, 2, "exclude"},
		{[]string{"-team", "reference", "adk-agent", "notes-agent"}, 1, "is taken"},
	} {
		code, _, errOut := te.runNew(f, c.args...)
		if code != c.code || !strings.Contains(errOut, c.want) {
			t.Errorf("%v: code %d, %q; want %d and %q", c.args, code, errOut, c.code, c.want)
		}
	}
	if f.started != 0 {
		t.Fatalf("%d pipelines started for refused requests", f.started)
	}
}

func TestNewForbiddenAndFailed(t *testing.T) {
	f := newFakeGitLab(t)
	f.forbid = true
	code, _, errOut := newEnv(t, f).runNew(f, "-team", "reference", "adk-agent", "notes-agent")
	if code != 1 || !strings.Contains(errOut, "T17") {
		t.Fatalf("forbidden: code %d, %q", code, errOut)
	}
	f = newFakeGitLab(t)
	f.statuses = []string{"running", "failed"}
	code, _, errOut = newEnv(t, f).runNew(f, "-team", "reference", "adk-agent", "notes-agent")
	if code != 1 || !strings.Contains(errOut, "job generate: failed https://gitlab.example.test/jobs/1") || strings.Contains(errOut, "job check") {
		t.Fatalf("failed: code %d, %q", code, errOut)
	}
	// Without a token.
	te := newEnv(t, f)
	delete(te.vars, "GITLAB_TOKEN")
	if code, _, errOut := te.runNew(f, "-team", "reference", "adk-agent", "notes-agent"); code != 2 || !strings.Contains(errOut, "no GitLab token") {
		t.Fatalf("no token: code %d, %q", code, errOut)
	}
}
