package main

import (
	"fmt"
	"os"
	"path/filepath"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/conform"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// runConform runs the conformance runner's image, pinned in environments'
// versions.yaml, with docker, against the deployment a configuration
// names. Arguments after -- go to the runner (-run, -skip, -suite,
// -list). The runner's exit status is agentctl's: 0 passed, 1 a case
// failed, 2 it could not run. When docker cannot start the runner (its
// statuses 125 to 127: a mount it cannot make, an image it cannot pull,
// an entrypoint it cannot run), agentctl could not run it either: 2.
func runConform(e *env, args []string) int {
	fs := newFlags(e, "conform", "conform -config FILE [flags] [-- RUNNER FLAGS]")
	config := fs.String("config", "", "the run's configuration, JSON, as the runner's README describes; ca_file and sign_in.personas_file are this machine's paths")
	envDir := fs.String("environments", "", "the checkout of environments whose versions.yaml pins the runner; default: agentctl's own (local up)")
	registry := fs.String("registry", defaults.Get(e.getenv, "AGENTCTL_RUNNER_REGISTRY", conform.Registry), "the registry the Docker daemon pulls the runner from ($AGENTCTL_RUNNER_REGISTRY)")
	image := fs.String("image", "", "the runner's image, instead of versions.yaml's pin")
	junit := fs.String("junit", "", "write the JUnit report here")
	jsonOut := fs.String("json", "", "write the results as JSON here")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if *config == "" {
		fs.Usage()
		return 2
	}
	img := *image
	if img == "" {
		dir := *envDir
		if dir == "" {
			var err error
			if dir, err = checkoutDir(e); err != nil {
				return fail(e, 2, "%v", err)
			}
		}
		var err error
		if img, err = conform.Image(filepath.Join(dir, conform.VersionsFile), *registry); err != nil {
			return fail(e, 2, "the runner's pin: %v (give -environments or -image)", err)
		}
	}
	p, err := conform.Prepare(conform.Run{
		Image: img, Config: *config, JUnit: *junit, JSON: *jsonOut, Args: fs.Args(),
		UID: os.Getuid(), GID: os.Getgid(), Loopback: e.loopback,
	})
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer p.Close()
	fmt.Fprintf(e.stderr, "Running %s\n", img)
	status, err := e.runner.Run(e.ctx, execx.Cmd{Name: "docker", Args: p.Args, Stdout: e.stdout, Stderr: e.stderr})
	if err != nil {
		return fail(e, 2, "docker: %v", err)
	}
	if !conform.Started(status) {
		return fail(e, 2, "docker could not start the runner: status %d", status)
	}
	if status == 0 || status == 1 {
		if err := p.Collect(); err != nil {
			fmt.Fprintf(e.stderr, "agentctl: %v\n", err)
			return max(status, 1)
		}
	}
	return status
}
