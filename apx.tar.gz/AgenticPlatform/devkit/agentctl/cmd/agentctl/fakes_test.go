package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strings"
	"sync"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/cosign"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// fakeTools stands in for cosign, oras and the aws CLI: a bucket, a
// registry and signatures in memory. Its "signatures" are no
// cryptography: a bundle names the hash of the public key that "signed"
// and the hash of what was signed, so a test can sign with one key and
// verify with another, or change a file after signing, and see cosign's
// verdict as the real one would give it. The real tools' flags are
// proven by the integration tests.
type fakeTools struct {
	t *testing.T

	mu      sync.Mutex
	objects map[string][]byte // s3://bucket/key
	puts    []string
	// blobs and tags: the registry, by repository (host/repo).
	blobs map[string]map[string][]byte // repo -> digest -> bytes
	tags  map[string]map[string]string // repo -> tag -> digest
	// serve, when set, replaces what the registry answers for a digest.
	serve map[string][]byte
	// signed: digest -> key hashes that signed it; attested: digest ->
	// predicate type -> statements, with the key hash that signed each.
	signed   map[string][]string
	attested map[string]map[string][]fakeStatement
	// signBlobKey is the key catalog build "signs" with: the hash of the
	// public key cosign public-key writes for it.
	kmsKeys map[string][]byte
	cmds    []string
}

type fakeStatement struct {
	key       string
	statement map[string]any
}

func newFakeTools(t *testing.T) *fakeTools {
	return &fakeTools{
		t: t, objects: map[string][]byte{}, blobs: map[string]map[string][]byte{}, tags: map[string]map[string]string{},
		serve: map[string][]byte{}, signed: map[string][]string{}, attested: map[string]map[string][]fakeStatement{},
		kmsKeys: map[string][]byte{},
	}
}

func sha256Digest(b []byte) string {
	h := sha256.Sum256(b)
	return "sha256:" + hex.EncodeToString(h[:])
}

func keyHash(pem []byte) string {
	h := sha256.Sum256(pem)
	return hex.EncodeToString(h[:8])
}

func envKey(t *testing.T, which string) []byte {
	t.Helper()
	b, err := defaults.PublicKey("local", which)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// otherKey is a public key no environment uses.
var otherKey = []byte("-----BEGIN PUBLIC KEY-----\nother\n-----END PUBLIC KEY-----\n")

// bundleFor is a fake bundle: data signed by the key whose PEM is given.
func bundleFor(pem, data []byte) []byte {
	b, _ := json.Marshal(map[string]string{"fake_key": keyHash(pem), "fake_digest": sha256Digest(data)})
	return b
}

func (f *fakeTools) handle(c execx.Cmd, stdin []byte) (int, string, string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.cmds = append(f.cmds, filepath.Base(c.Name)+" "+strings.Join(c.Args, " "))
	switch filepath.Base(c.Name) {
	case "cosign":
		return f.cosign(c.Args)
	case "oras":
		return f.oras(c.Args)
	case "aws":
		return f.aws(c.Args)
	}
	return -1, "", "", fmt.Errorf("%s: %w", c.Name, execx.ErrNotFound)
}

func flagValue(args []string, name string) string {
	for i, a := range args {
		if a == name && i+1 < len(args) {
			return args[i+1]
		}
	}
	return ""
}

func (f *fakeTools) keyArg(args []string) (string, bool) {
	k := flagValue(args, "--key")
	if pem, ok := f.kmsKeys[k]; ok {
		return keyHash(pem), true
	}
	pem, err := os.ReadFile(k)
	if err != nil {
		return "", false
	}
	return keyHash(pem), true
}

func (f *fakeTools) cosign(args []string) (int, string, string, error) {
	switch args[0] {
	case "verify-blob":
		key, ok := f.keyArg(args)
		bundle, err1 := os.ReadFile(flagValue(args, "--bundle"))
		data, err2 := os.ReadFile(args[len(args)-1])
		if !ok || err1 != nil || err2 != nil {
			return 1, "", "Error: reading the key, bundle or file\n", nil
		}
		var b map[string]string
		json.Unmarshal(bundle, &b)
		if b["fake_key"] != key || b["fake_digest"] != sha256Digest(data) {
			return 1, "", "Error: invalid signature when validating ASN.1 encoded signature\n", nil
		}
		return 0, "Verified OK\n", "", nil
	case "signing-config":
		os.WriteFile(flagValue(args, "--out"), []byte(`{"fake":"signing config naming no service"}`), 0o644)
		return 0, "", "", nil
	case "public-key":
		pem, ok := f.kmsKeys[flagValue(args, "--key")]
		if !ok {
			return 1, "", "Error: no such key\n", nil
		}
		os.WriteFile(flagValue(args, "--outfile"), pem, 0o644)
		return 0, "", "", nil
	case "sign-blob":
		pem, ok := f.kmsKeys[flagValue(args, "--key")]
		data, err := os.ReadFile(args[len(args)-1])
		if !ok || err != nil || flagValue(args, "--signing-config") == "" {
			return 1, "", "Error: cannot sign\n", nil
		}
		os.WriteFile(flagValue(args, "--bundle"), bundleFor(pem, data), 0o644)
		return 0, "", "", nil
	case "verify", "verify-attestation":
		key, ok := f.keyArg(args)
		ref := args[len(args)-1]
		_, digest, _ := strings.Cut(ref, "@")
		if !ok {
			return 1, "", "Error: reading the key\n", nil
		}
		if args[0] == "verify" {
			// As cosign v3 does: any bundle the key made on the digest
			// passes, an attestation included, which is why agentctl must
			// never take this for a signature.
			any := slices.Contains(f.signed[digest], key)
			for _, sts := range f.attested[digest] {
				for _, st := range sts {
					any = any || st.key == key
				}
			}
			if !any {
				return 1, "", "Error: no signatures found\n", nil
			}
			return 0, "[{}]\n", "", nil
		}
		var out strings.Builder
		for _, st := range f.attested[digest][flagValue(args, "--type")] {
			if st.key != key {
				continue
			}
			raw, _ := json.Marshal(st.statement)
			env, _ := json.Marshal(map[string]string{"payloadType": "application/vnd.in-toto+json", "payload": base64.StdEncoding.EncodeToString(raw)})
			out.Write(env)
			out.WriteString("\n")
		}
		if out.Len() == 0 {
			return 1, "", "Error: none of the attestations matched the predicate type\n", nil
		}
		return 0, out.String(), "", nil
	}
	return 2, "", "fake cosign: unknown " + args[0] + "\n", nil
}

func splitRepo(ref string) (repo, sep, rest string) {
	if i := strings.LastIndex(ref, "@"); i >= 0 {
		return ref[:i], "@", ref[i+1:]
	}
	i := strings.LastIndex(ref, ":")
	if i > strings.LastIndex(ref, "/") {
		return ref[:i], ":", ref[i+1:]
	}
	return ref, "", ""
}

func (f *fakeTools) oras(args []string) (int, string, string, error) {
	ref := args[len(args)-1]
	repo, sep, rest := splitRepo(ref)
	switch {
	case args[0] == "resolve":
		d, ok := f.tags[repo][rest]
		if sep != ":" || !ok {
			return 1, "", "Error: " + ref + ": not found\n", nil
		}
		return 0, d + "\n", "", nil
	case args[0] == "manifest" && args[1] == "fetch", args[0] == "blob" && args[1] == "fetch":
		if sep != "@" {
			return 1, "", "Error: by digest only\n", nil
		}
		if b, ok := f.serve[rest]; ok {
			return 0, string(b), "", nil
		}
		b, ok := f.blobs[repo][rest]
		if !ok {
			return 1, "", "Error: " + ref + ": not found\n", nil
		}
		return 0, string(b), "", nil
	}
	return 2, "", "fake oras: unknown " + strings.Join(args, " ") + "\n", nil
}

func (f *fakeTools) aws(args []string) (int, string, string, error) {
	switch {
	case args[0] == "s3api" && args[1] == "list-objects-v2":
		prefix := "s3://" + flagValue(args, "--bucket") + "/" + flagValue(args, "--prefix")
		var keys []string
		for k := range f.objects {
			if strings.HasPrefix(k, prefix) {
				keys = append(keys, strings.TrimPrefix(k, "s3://"+flagValue(args, "--bucket")+"/"))
			}
		}
		sort.Strings(keys)
		if flagValue(args, "--query") != "Contents[].Key" {
			return 2, "", "fake aws: list without --query Contents[].Key\n", nil
		}
		if keys == nil {
			return 0, "null\n", "", nil
		}
		b, _ := json.Marshal(keys)
		return 0, string(b), "", nil
	case args[0] == "s3" && args[1] == "cp":
		src, dst := args[len(args)-2], args[len(args)-1]
		if strings.HasPrefix(src, "s3://") {
			b, ok := f.objects[src]
			if !ok {
				return 1, "", "fatal error: An error occurred (404) when calling the HeadObject operation: Not Found\n", nil
			}
			os.WriteFile(dst, b, 0o600)
			return 0, "", "", nil
		}
		b, err := os.ReadFile(src)
		if err != nil {
			return 1, "", "The user-provided path " + src + " does not exist.\n", nil
		}
		f.objects[dst] = b
		f.puts = append(f.puts, dst)
		return 0, "", "", nil
	}
	return 2, "", "fake aws: unknown " + strings.Join(args, " ") + "\n", nil
}

// push stores content in the registry and returns its digest.
func (f *fakeTools) push(repo string, content []byte) string {
	f.mu.Lock()
	defer f.mu.Unlock()
	d := sha256Digest(content)
	if f.blobs[repo] == nil {
		f.blobs[repo] = map[string][]byte{}
	}
	f.blobs[repo][d] = content
	return d
}

func (f *fakeTools) tag(repo, tag, digest string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.tags[repo] == nil {
		f.tags[repo] = map[string]string{}
	}
	f.tags[repo][tag] = digest
}

// sign signs a digest as cosign v3's sign does: a bundle holding its sign
// statement, https://sigstore.dev/cosign/sign/v1, on the digest.
func (f *fakeTools) sign(digest string, pem []byte) {
	f.mu.Lock()
	f.signed[digest] = append(f.signed[digest], keyHash(pem))
	f.mu.Unlock()
	f.attest(digest, cosign.SignStatementType, pem, map[string]any{
		"_type": "https://in-toto.io/Statement/v1", "predicateType": cosign.SignStatementType,
		"subject":   []map[string]any{{"name": "x", "digest": map[string]string{"sha256": strings.TrimPrefix(digest, "sha256:")}}},
		"predicate": map[string]any{},
	})
}

// unsign takes away every sign statement on a digest, leaving its other
// attestations.
func (f *fakeTools) unsign(digest string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.signed[digest] = nil
	if f.attested[digest] != nil {
		delete(f.attested[digest], cosign.SignStatementType)
	}
}

func (f *fakeTools) attest(digest, typ string, pem []byte, statement map[string]any) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.attested[digest] == nil {
		f.attested[digest] = map[string][]fakeStatement{}
	}
	f.attested[digest][typ] = append(f.attested[digest][typ], fakeStatement{key: keyHash(pem), statement: statement})
}

func (f *fakeTools) put(location string, data []byte) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.objects[location] = data
}

func (f *fakeTools) ran(prefix string) bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	return slices.ContainsFunc(f.cmds, func(c string) bool { return strings.HasPrefix(c, prefix) })
}

// install wires the fakes into a test environment.
func (f *fakeTools) install(te *testEnv) {
	te.runner.Handle = f.handle
}
