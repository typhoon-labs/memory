package main

// The integration tests run the real conformance runner image, the one
// environments' versions.yaml pins, with the real docker, through
// agentctl's own conform command: its mounts, the runner's flags and the
// exit statuses agentctl gives back. They are the one exception to "tests
// never run docker" (AGENTS.md), and run only when
// AGENTCTL_INTEGRATION_ENVIRONMENTS names a checkout of environments and
// the Docker daemon can pull the image from AGENTCTL_RUNNER_REGISTRY
// (default floci's loopback registry); otherwise they skip, so go test
// stays hermetic. They never reach a deployment: the one case they select
// needs a probe the configuration does not name, so it skips before it
// sends anything, and the Okta org they name is never called.

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"math/big"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/conform"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// integrationCase is a case of the runner's that needs only a probe, which
// the configuration leaves out: it skips without a request.
const integrationCase = "bypass/ingress/networkpolicy/sidecar-port"

// realDocker runs docker for real, found on the PATH the tests started
// with and given it, and refuses every other command.
type realDocker struct{ path string }

func (d realDocker) Run(ctx context.Context, c execx.Cmd) (int, error) {
	if c.Name != "docker" {
		return -1, fmt.Errorf("an integration test ran %s", c.Name)
	}
	c.Name = d.path
	if c.Env == nil {
		for _, kv := range os.Environ() {
			if !strings.HasPrefix(kv, "PATH=") {
				c.Env = append(c.Env, kv)
			}
		}
		c.Env = append(c.Env, "PATH="+realPath)
	}
	return execx.OS{}.Run(ctx, c)
}

// integration returns the real docker and the pinned runner's image, or
// skips the test.
func integration(t *testing.T) (realDocker, string) {
	t.Helper()
	envDir := os.Getenv("AGENTCTL_INTEGRATION_ENVIRONMENTS")
	if envDir == "" {
		t.Skip("set AGENTCTL_INTEGRATION_ENVIRONMENTS to a checkout of environments to run the real runner image")
	}
	registry := os.Getenv("AGENTCTL_RUNNER_REGISTRY")
	if registry == "" {
		registry = conform.Registry
	}
	image, err := conform.Image(filepath.Join(envDir, conform.VersionsFile), registry)
	if err != nil {
		t.Fatal(err)
	}
	for _, dir := range filepath.SplitList(realPath) {
		p := filepath.Join(dir, "docker")
		if fi, err := os.Stat(p); err == nil && fi.Mode().IsRegular() && fi.Mode()&0o111 != 0 {
			return realDocker{path: p}, image
		}
	}
	t.Fatal("AGENTCTL_INTEGRATION_ENVIRONMENTS is set, but docker is not on PATH")
	return realDocker{}, ""
}

// integrationConfig writes a workstation configuration with relative
// paths: a CA the runner parses, a personas file it reads at start-up
// because sign_in names an Okta org, and no probes.
func integrationConfig(t *testing.T, strict bool) string {
	t.Helper()
	dir := t.TempDir()
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := &x509.Certificate{
		SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "agentctl integration test CA"},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour),
		IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign,
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		t.Fatal(err)
	}
	ca := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	cfg := map[string]any{
		"platform_domain": "agentic.internal", "cluster": "agentic-local", "ca_file": "ca.crt",
		"strict": strict, "slow": false, "runner_meshed": false,
		"routes":       map[string]any{"gateway/v1": map[string]any{"kind": "model", "scope": "models", "roles": []string{"developer"}}},
		"token_routes": []string{"gateway/v1"},
		"sign_in":      map[string]any{"okta": "https://okta.example.invalid", "client_id": "agentctl", "personas_file": "personas.json"},
	}
	raw, _ := json.Marshal(cfg)
	for name, data := range map[string][]byte{
		"ca.crt":           ca,
		"personas.json":    []byte(`{"agentic.developer@example.invalid": {"password": "not-a-password", "totp": "JBSWY3DPEHPK3PXP"}}`),
		"workstation.json": raw,
	} {
		if err := os.WriteFile(filepath.Join(dir, name), data, 0o600); err != nil {
			t.Fatal(err)
		}
	}
	return filepath.Join(dir, "workstation.json")
}

// TestConformRealRunner starts the pinned image with agentctl's mounts:
// the runner reads the configuration, CA and personas where agentctl
// mounted them, runs the case, and writes both reports, which agentctl
// copies out; strict, the skip fails the run and the runner's 1 is
// agentctl's.
func TestConformRealRunner(t *testing.T) {
	docker, image := integration(t)
	for _, tc := range []struct {
		strict  bool
		code    int
		summary string
	}{
		{false, 0, "conform: 0 passed, 0 failed, 1 skipped\n"},
		{true, 1, "conform: 0 passed, 0 failed, 1 skipped (strict: a skipped case fails the run)\n"},
	} {
		t.Run(fmt.Sprintf("strict=%v", tc.strict), func(t *testing.T) {
			config := integrationConfig(t, tc.strict)
			reports := t.TempDir()
			junit, jsonOut := filepath.Join(reports, "junit.xml"), filepath.Join(reports, "results.json")
			te := newTestEnv(t)
			code, out, errOut := te.runWith(func(e *env) { e.runner = docker },
				"conform", "-config", config, "-image", image, "-junit", junit, "-json", jsonOut, "--", "-run", "^"+integrationCase+"$")
			if code != tc.code || !strings.Contains(out, "conform: 1 cases, run ") || !strings.Contains(out, tc.summary) {
				t.Fatalf("code %d, want %d\nstdout:\n%s\nstderr:\n%s", code, tc.code, out, errOut)
			}
			var report struct {
				Results []struct{ ID, Status, Message string }
			}
			data, err := os.ReadFile(jsonOut)
			if err == nil {
				err = json.Unmarshal(data, &report)
			}
			if err != nil || len(report.Results) != 1 || report.Results[0].ID != integrationCase || report.Results[0].Status != "skip" {
				t.Fatalf("the JSON report: %v\n%s", err, data)
			}
			t.Logf("%s: %s: %s", report.Results[0].ID, report.Results[0].Status, report.Results[0].Message)
			if data, err := os.ReadFile(junit); err != nil || !strings.Contains(string(data), integrationCase) {
				t.Fatalf("the JUnit report: %v\n%s", err, data)
			}
		})
	}
}

// TestConformRealRunnerCannotRun: an image docker cannot pull, and a
// runner that refuses its flags, both exit 2, "could not run".
func TestConformRealRunnerCannotRun(t *testing.T) {
	docker, image := integration(t)
	config := integrationConfig(t, false)
	te := newTestEnv(t)
	missing := image[:strings.LastIndex(image, "@")] + "@sha256:" + strings.Repeat("0", 64)
	code, out, errOut := te.runWith(func(e *env) { e.runner = docker }, "conform", "-config", config, "-image", missing)
	if code != 2 || !strings.Contains(errOut, "status 125") {
		t.Fatalf("an image that cannot be pulled: code %d, want 2\nstdout:\n%s\nstderr:\n%s", code, out, errOut)
	}
	code, out, errOut = te.runWith(func(e *env) { e.runner = docker }, "conform", "-config", config, "-image", image, "--", "-run", "(")
	if code != 2 || !strings.Contains(errOut, "conform: -run") {
		t.Fatalf("the runner's own 2: code %d\nstdout:\n%s\nstderr:\n%s", code, out, errOut)
	}
}
