package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

const runnerDigest = "sha256:928fd1cde245e00c7f3810969ee34a2a01125080395b4abe8eb9e071e244a89f"

// conformSetup writes an environments checkout holding only versions.yaml,
// and a workstation configuration with relative paths.
func conformSetup(t *testing.T) (envDir, config string) {
	envDir = t.TempDir()
	os.WriteFile(filepath.Join(envDir, "versions.yaml"), []byte("conformance-runner:\n  version: sha-b00e3eb9e9eb\n  image: platform/conformance-runner\n  digest: "+runnerDigest+"\n"), 0o644)
	cfgDir := t.TempDir()
	os.WriteFile(filepath.Join(cfgDir, "ca.crt"), []byte("pem"), 0o644)
	os.WriteFile(filepath.Join(cfgDir, "personas.json"), []byte("{}"), 0o600)
	config = filepath.Join(cfgDir, "workstation.json")
	os.WriteFile(config, []byte(`{"platform_domain": "agentic.internal", "ca_file": "ca.crt", "strict": false,
		"sign_in": {"okta": "https://okta.example.test", "client_id": "agentctl", "personas_file": "personas.json"}}`), 0o644)
	return envDir, config
}

// fakeRunner plays the runner's container: it reads the configuration
// agentctl mounted, writes the reports where the mounts say, and exits
// with status.
func fakeRunner(t *testing.T, status int, seen *map[string]any) *execx.Fake {
	return &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
		mounts := map[string]string{}
		for i, a := range c.Args {
			if a == "-v" {
				parts := strings.Split(c.Args[i+1], ":")
				mounts[parts[1]] = parts[0]
			}
		}
		data, err := os.ReadFile(mounts["/run/conform/config.json"])
		if err != nil {
			t.Errorf("no configuration mounted: %v", err)
		}
		json.Unmarshal(data, seen)
		os.WriteFile(filepath.Join(mounts["/run/conform/out"], "junit.xml"), []byte("<testsuites/>"), 0o644)
		return status, "gateway-path/token/gateway/v1/missing\tPASS\n", "", nil
	}}
}

func TestConform(t *testing.T) {
	envDir, config := conformSetup(t)
	te := newTestEnv(t)
	var seen map[string]any
	te.runner = fakeRunner(t, 1, &seen)
	junit := filepath.Join(t.TempDir(), "junit.xml")
	code, out, errOut := te.runWith(func(e *env) { e.loopback = func(n string) bool { return n != "kagent.agentic.internal" } },
		"conform", "-config", config, "-environments", envDir, "-junit", junit, "--", "-run", "gateway-path/token")
	if code != 1 || !strings.Contains(out, "PASS") {
		t.Fatalf("a failed case: code %d, out %q, err %q", code, out, errOut)
	}
	args := te.runner.Calls()[0].Cmd.Args
	joined := strings.Join(args, " ")
	image := "127.0.0.1:4566/000000000000/us-east-1/platform/conformance-runner@" + runnerDigest
	for _, want := range []string{
		"run --rm --network host",
		"-e HTTP_PROXY= -e HTTPS_PROXY= -e NO_PROXY=",
		"--add-host keycloak.agentic.internal:127.0.0.1",
		"--add-host floci:127.0.0.1",
		filepath.Join(filepath.Dir(config), "ca.crt") + ":/run/conform/ca.crt:ro",
		filepath.Join(filepath.Dir(config), "personas.json") + ":/run/conform/personas.json:ro",
		image + " -config=/run/conform/config.json -junit=/run/conform/out/junit.xml -run gateway-path/token",
	} {
		if !strings.Contains(joined, want) {
			t.Errorf("docker's arguments lack %q:\n%s", want, joined)
		}
	}
	// The runner's image is the file /conform, its entrypoint: nothing
	// can be mounted under it (v0.1.0 did, and docker exited 125).
	for i, a := range args {
		if a == "-v" {
			if target := strings.Split(args[i+1], ":")[1]; target == "/conform" || strings.HasPrefix(target, "/conform/") {
				t.Errorf("a mount under the runner's entrypoint: %s", args[i+1])
			}
		}
	}
	if strings.Contains(joined, "kagent.agentic.internal") {
		t.Errorf("a name that does not resolve here was mapped: %s", joined)
	}
	if seen["ca_file"] != "/run/conform/ca.crt" || seen["sign_in"].(map[string]any)["personas_file"] != "/run/conform/personas.json" || seen["strict"] != false {
		t.Errorf("the configuration the runner saw: %v", seen)
	}
	if data, err := os.ReadFile(junit); err != nil || string(data) != "<testsuites/>" {
		t.Errorf("the JUnit report: %q %v", data, err)
	}
	if slices.Contains(args, "--privileged") {
		t.Error("privileged")
	}
}

func TestConformRefusals(t *testing.T) {
	envDir, config := conformSetup(t)
	te := newTestEnv(t)
	if code, _, _ := te.run("conform"); code != 2 {
		t.Fatalf("no configuration: code %d", code)
	}
	if code, _, errOut := te.run("conform", "-config", config, "-environments", t.TempDir()); code != 2 || !strings.Contains(errOut, "pin") {
		t.Fatalf("no versions.yaml: code %d, %q", code, errOut)
	}
	os.WriteFile(filepath.Join(envDir, "versions.yaml"), []byte("conformance-runner:\n  image: platform/conformance-runner\n  digest: latest\n"), 0o644)
	if code, _, errOut := te.run("conform", "-config", config, "-environments", envDir); code != 2 || !strings.Contains(errOut, "by digest") {
		t.Fatalf("a tag, not a digest: code %d, %q", code, errOut)
	}
	// A CA or personas file that is not there: docker would create it,
	// as a directory owned by root.
	cfgDir := filepath.Dir(config)
	os.Remove(filepath.Join(cfgDir, "personas.json"))
	if code, _, errOut := te.run("conform", "-config", config, "-image", "example.test/runner@"+runnerDigest); code != 2 || !strings.Contains(errOut, "sign_in.personas_file") {
		t.Fatalf("no personas file: code %d, %q", code, errOut)
	}
	os.Mkdir(filepath.Join(cfgDir, "personas.json"), 0o700)
	os.Remove(filepath.Join(cfgDir, "ca.crt"))
	if code, _, errOut := te.run("conform", "-config", config, "-image", "example.test/runner@"+runnerDigest); code != 2 || !strings.Contains(errOut, "ca_file") {
		t.Fatalf("no CA file: code %d, %q", code, errOut)
	}
	os.WriteFile(filepath.Join(cfgDir, "ca.crt"), []byte("pem"), 0o644)
	if code, _, errOut := te.run("conform", "-config", config, "-image", "example.test/runner@"+runnerDigest); code != 2 || !strings.Contains(errOut, "is not a file") {
		t.Fatalf("a directory for the personas file: code %d, %q", code, errOut)
	}
	if len(te.runner.Calls()) != 0 {
		t.Fatal("docker ran")
	}
	// The runner could not run: its status 2 is agentctl's.
	te.runner = &execx.Fake{Handle: func(execx.Cmd, []byte) (int, string, string, error) { return 2, "", "conform: bad config", nil }}
	if code, _, _ := te.run("conform", "-config", config, "-image", "example.test/runner@"+runnerDigest); code != 2 {
		t.Fatalf("the runner's status 2: code %d", code)
	}
}

// TestConformStatus: docker's own statuses, when it cannot start the
// container, are agentctl's 2; the runner's are passed through, and the
// reports copied only when it ran its cases.
func TestConformStatus(t *testing.T) {
	_, config := conformSetup(t)
	for _, tc := range []struct {
		docker, want int
		err          error
		reports      bool
	}{
		{docker: 0, want: 0, reports: true},
		{docker: 1, want: 1, reports: true},
		{docker: 2, want: 2},
		{docker: 125, want: 2}, // the daemon: a mount, a pull, the runtime
		{docker: 126, want: 2}, // the entrypoint cannot be run
		{docker: 127, want: 2}, // the entrypoint is not found
		{docker: 137, want: 137},
		{docker: -1, want: 2, err: execx.ErrNotFound}, // no docker
	} {
		te := newTestEnv(t)
		te.runner = &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
			for i, a := range c.Args {
				if a == "-v" && strings.HasSuffix(c.Args[i+1], ":/run/conform/out") {
					os.WriteFile(filepath.Join(strings.Split(c.Args[i+1], ":")[0], "junit.xml"), []byte("<testsuites/>"), 0o644)
				}
			}
			return tc.docker, "", "", tc.err
		}}
		junit := filepath.Join(t.TempDir(), "junit.xml")
		code, _, errOut := te.run("conform", "-config", config, "-image", "example.test/runner@"+runnerDigest, "-junit", junit)
		if code != tc.want {
			t.Errorf("docker's status %d: code %d, want %d (%q)", tc.docker, code, tc.want, errOut)
		}
		if tc.docker >= 125 && tc.docker <= 127 && !strings.Contains(errOut, fmt.Sprintf("docker could not start the runner: status %d", tc.docker)) {
			t.Errorf("docker's status %d: %q", tc.docker, errOut)
		}
		if _, err := os.Stat(junit); (err == nil) != tc.reports {
			t.Errorf("docker's status %d: the report copied: %v", tc.docker, err == nil)
		}
	}
}
