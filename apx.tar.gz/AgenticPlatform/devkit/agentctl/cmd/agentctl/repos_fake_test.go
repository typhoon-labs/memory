package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"sync"
	"testing"
)

// fakeRepos plays the part of GitLab's API that deploy request and
// catalog build call: files at refs, tags, branches, commits and merge
// requests, for a person's token or a job's.
type fakeRepos struct {
	srv             *httptest.Server
	token, jobToken string

	mu sync.Mutex
	// files: project path -> ref -> file path -> content.
	files map[string]map[string]map[string]string
	// tags: project path -> tag -> commit.
	tags     map[string]map[string]string
	branches map[string]map[string]bool
	ids      map[string]string // numeric ID -> path
	// jobReads: the projects whose job-token allowlist admits the job.
	jobReads map[string]bool
	commits  []map[string]any
	mrs      []map[string]any
	requests []string
}

func newFakeRepos(t *testing.T) *fakeRepos {
	f := &fakeRepos{token: "glpat-person", jobToken: "glcbt-job",
		files: map[string]map[string]map[string]string{}, tags: map[string]map[string]string{},
		branches: map[string]map[string]bool{}, ids: map[string]string{}, jobReads: map[string]bool{}}
	f.srv = httptest.NewTLSServer(http.HandlerFunc(f.serve))
	t.Cleanup(f.srv.Close)
	return f
}

func (f *fakeRepos) project(path string, id int) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.ids[strconv.Itoa(id)] = path
	if f.files[path] == nil {
		f.files[path] = map[string]map[string]string{}
		f.tags[path] = map[string]string{}
		f.branches[path] = map[string]bool{"main": true}
	}
}

func (f *fakeRepos) file(project, ref, path, content string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.files[project][ref] == nil {
		f.files[project][ref] = map[string]string{}
	}
	f.files[project][ref][path] = content
}

func (f *fakeRepos) tag(project, tag, commit string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.tags[project][tag] = commit
}

func (f *fakeRepos) serve(w http.ResponseWriter, r *http.Request) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.requests = append(f.requests, r.Method+" "+r.URL.RequestURI())
	w.Header().Set("Content-Type", "application/json")
	job := r.Header.Get("JOB-TOKEN")
	person := r.Header.Get("Authorization") == "Bearer "+f.token
	if !person && job != f.jobToken {
		w.WriteHeader(401)
		w.Write([]byte(`{"message":"401 Unauthorized"}`))
		return
	}
	p := strings.TrimPrefix(r.URL.EscapedPath(), "/api/v4/projects/")
	id, rest, _ := strings.Cut(p, "/")
	project, _ := url.PathUnescape(id)
	if path, ok := f.ids[project]; ok {
		project = path
	}
	if _, ok := f.files[project]; !ok || (!person && !f.jobReads[project]) {
		w.WriteHeader(404)
		w.Write([]byte(`{"message":"404 Project Not Found"}`))
		return
	}
	notFound := func() { w.WriteHeader(404); w.Write([]byte(`{"message":"404 Not Found"}`)) }
	switch {
	case r.Method == "GET" && strings.HasPrefix(rest, "repository/files/") && strings.HasSuffix(rest, "/raw"):
		fp, _ := url.PathUnescape(strings.TrimSuffix(strings.TrimPrefix(rest, "repository/files/"), "/raw"))
		ref := r.URL.Query().Get("ref")
		c, ok := f.files[project][ref][fp]
		if !ok {
			notFound()
			return
		}
		w.Header().Set("Content-Type", "text/plain")
		w.Write([]byte(c))
	case r.Method == "GET" && rest == "repository/tags":
		var names []string
		for n := range f.tags[project] {
			names = append(names, n)
		}
		sort.Strings(names)
		var out []map[string]any
		for _, n := range names {
			out = append(out, map[string]any{"name": n, "commit": map[string]string{"id": f.tags[project][n]}, "protected": true})
		}
		if out == nil {
			out = []map[string]any{}
		}
		json.NewEncoder(w).Encode(out)
	case r.Method == "GET" && strings.HasPrefix(rest, "repository/tags/"):
		tg, _ := url.PathUnescape(strings.TrimPrefix(rest, "repository/tags/"))
		c, ok := f.tags[project][tg]
		if !ok {
			notFound()
			return
		}
		json.NewEncoder(w).Encode(map[string]any{"name": tg, "commit": map[string]string{"id": c}})
	case r.Method == "GET" && strings.HasPrefix(rest, "repository/branches/"):
		b, _ := url.PathUnescape(strings.TrimPrefix(rest, "repository/branches/"))
		if !f.branches[project][b] {
			notFound()
			return
		}
		json.NewEncoder(w).Encode(map[string]any{"name": b})
	case r.Method == "POST" && rest == "repository/commits" && person:
		var body map[string]any
		json.NewDecoder(r.Body).Decode(&body)
		body["project"] = project
		f.commits = append(f.commits, body)
		f.branches[project][body["branch"].(string)] = true
		w.WriteHeader(201)
		w.Write([]byte(`{"id":"1111111111111111111111111111111111111111"}`))
	case r.Method == "POST" && rest == "merge_requests" && person:
		var body map[string]any
		json.NewDecoder(r.Body).Decode(&body)
		body["project"] = project
		f.mrs = append(f.mrs, body)
		w.WriteHeader(201)
		json.NewEncoder(w).Encode(map[string]any{"iid": len(f.mrs), "web_url": "https://gitlab.example.test/" + project + "/-/merge_requests/" + strconv.Itoa(len(f.mrs))})
	default:
		w.WriteHeader(403)
		w.Write([]byte(`{"message":"403 Forbidden"}`))
	}
}
