package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth/authtest"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
)

const (
	foundationPath = "acme/platform/infra/aws-foundation"
	libraryPath    = "acme/platform/agent-library"
	strayPath      = "acme/platform/workloads/stray/stray-mcp"
	recordKMS      = "awskms:///alias/platform/record-signing"
	releaseKMS     = "awskms:///alias/platform/release-signing"
	workloadsRepo  = "floci:4566/000000000000/us-east-1/workloads/reference/"
)

// catalogWorld is a GitLab of registered projects, a registry of their
// releases, and the files environments' scheduled pipeline has.
type catalogWorld struct {
	te    *testEnv
	repos *fakeRepos
	tools *fakeTools
	dir   string
	regs  map[string][]map[string]any
}

func mcpWorkload(name, owner string) string {
	return "name: " + name + "\nkind: mcp-server\nruntime: container\nowner: " + owner + "\nsupport: experimental\ndescription: Notes.\ntools:\n  - name: list_notes\n    annotations:\n      readOnlyHint: true\nlimits:\n  wall_time_seconds: 30\n"
}

func newCatalogWorld(t *testing.T) *catalogWorld {
	te, tools := catalogTestEnv(t)
	repos := newFakeRepos(t)
	w := &catalogWorld{te: te, repos: repos, tools: tools, dir: t.TempDir()}
	release := envKey(t, defaults.ReleaseKey)
	tools.kmsKeys[recordKMS] = envKey(t, defaults.RecordKey)
	tools.kmsKeys[releaseKMS] = release

	// Workloads, each released to its repository and signed.
	workload := func(path string, id int, tag, commit, file string, image bool, name string) {
		repos.project(path, id)
		repos.jobReads[path] = true
		repos.tag(path, tag, commit)
		repos.tag(path, "v0.0.1", "0000000000000000000000000000000000000001")
		repos.file(path, tag, "workload.yaml", file)
		if image {
			d := tools.push(workloadsRepo+name, []byte("image "+name+" "+tag))
			tools.tag(workloadsRepo+name, tag, d)
			tools.sign(d, release)
		}
	}
	workload(mcpPath, 89090989, "v0.1.2", commitA, mcpWorkload("reference-mcp", "reference"), true, "reference-mcp")
	workload(notesPath, 89090991, "v0.1.0", commitB, "name: reference-notes-agent\nkind: agent\nruntime: kagent\nowner: reference\nsupport: experimental\n", true, "reference-notes-agent")
	workload(flowPath, 89090993, "v0.1.0", commitC, "name: reference-workflow\nkind: workflow\nruntime: pipeline\nowner: reference\nsupport: experimental\nlimits:\n  model_calls: 4\n  tool_calls: 4\n  tokens: 20000\n  wall_time_seconds: 120\n", false, "reference-workflow")
	// A project with a valid release that is not registered.
	workload(strayPath, 89099999, "v1.0.0", commitA, mcpWorkload("stray-mcp", "reference"), true, "stray-mcp")

	// The global library: two releases of a skill and one prompt.
	repos.project(libraryPath, 81000001)
	repos.jobReads[libraryPath] = true
	for _, r := range []struct{ kind, name, version, commit string }{
		{"skill", "platform-conventions", "0.1.0", commitA}, {"skill", "platform-conventions", "0.0.9", commitC}, {"prompt", "summarise-changes", "0.1.0", commitB},
	} {
		tag := r.kind + "/" + r.name + "/v" + r.version
		repos.tag(libraryPath, tag, r.commit)
		repos.file(libraryPath, tag, "library.yaml", "owner: platform\ntier: global\n")
		yamlNoProv := strings.Split(artifactYAML(r.kind, r.name, r.version, r.commit), "provenance:")[0]
		repos.file(libraryPath, tag, r.kind+"s/"+r.name+"/artifact.yaml", yamlNoProv)
		files := map[string]string{"x.md": "x"}
		if r.kind == "skill" {
			files = skillFiles()
		}
		releaseArtifact(t, tools, r.kind, r.name, r.version, r.commit, files)
	}

	w.regs = map[string][]map[string]any{
		"ci-environments":     {{"id": 88996235, "path": "infra/environments"}},
		"ci-workload-release": {{"id": 89090989, "path": "workloads/reference/reference-mcp"}, {"id": 89090991, "path": "workloads/reference/reference-notes-agent"}, {"id": 89090993, "path": "workloads/reference/reference-workflow"}},
		"ci-library-release":  {{"id": 81000001, "path": "agent-library"}},
	}
	repos.project(foundationPath, 88996240)
	repos.jobReads[foundationPath] = true
	w.writeRegistrations()
	os.WriteFile(filepath.Join(w.dir, "teams.yaml"), []byte("teams:\n  - slug: platform\n    group: g1\n  - slug: reference\n    group: g2\n"), 0o644)

	te.vars["CI_JOB_TOKEN"] = repos.jobToken
	te.vars["CI_SERVER_URL"] = repos.srv.URL
	te.vars["CI_PROJECT_URL"] = "https://gitlab.example.test/acme/platform/infra/environments"
	te.vars["CI_COMMIT_SHA"] = "3b145e438f23c9f16f53758e7c0920264f658d19"
	te.vars["CI_PIPELINE_ID"] = "3086000001"
	te.vars["AGENTCTL_FOUNDATION_PROJECT"] = foundationPath
	return w
}

// releaseArtifact is release() without the signing helper's defaults
// changing: the artifact as library-release pushes it.
func releaseArtifact(t *testing.T, f *fakeTools, kind, name, version, commit string, files map[string]string) *library {
	return release(t, f, kind, name, version, commit, files)
}

func (w *catalogWorld) writeRegistrations() {
	b, _ := yaml.Marshal(w.regs)
	w.repos.file(foundationPath, "main", "registrations/local.yaml", string(b))
}

func (w *catalogWorld) build(args ...string) (int, string, string) {
	return w.te.runWith(func(e *env) { e.httpClient = w.repos.srv.Client() },
		append([]string{"catalog", "build", "-out", filepath.Join(w.dir, "out"), "-teams", filepath.Join(w.dir, "teams.yaml")}, args...)...)
}

func (w *catalogWorld) index(t *testing.T) map[string]any {
	t.Helper()
	return readJSONFile(t, filepath.Join(w.dir, "out", "catalog.json"))
}

func entryNames(ix map[string]any) map[string]map[string]any {
	out := map[string]map[string]any{}
	for _, e := range ix["entries"].([]any) {
		m := e.(map[string]any)
		out[m["metadata"].(map[string]any)["name"].(string)] = m
	}
	return out
}

func TestCatalogBuild(t *testing.T) {
	w := newCatalogWorld(t)
	code, out, errOut := w.build("-sign-key", recordKMS, "-bucket", "agentic-catalog-index-local")
	if code != 0 {
		t.Fatalf("build: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	ix := w.index(t)
	en := entryNames(ix)
	if len(en) != 5 {
		t.Fatalf("entries: %v", en)
	}
	if _, ok := en["stray-mcp"]; ok {
		t.Error("a project not registered is in the index")
	}
	if m := en["reference-mcp"]; m["route"] != "gateway/mcp/reference-mcp" || !strings.HasPrefix(m["reference"].(string), workloadsRepo+"reference-mcp@sha256:") || m["version"] != "0.1.2" {
		t.Errorf("reference-mcp: %v", m)
	}
	if m := en["reference-notes-agent"]; m["route"] != "gateway/a2a/reference-notes-agent" || m["reference"] == nil {
		t.Errorf("reference-notes-agent: %v", m)
	}
	if m := en["reference-workflow"]; m["reference"] != nil || m["route"] != nil {
		t.Errorf("reference-workflow: %v", m)
	}
	skill := en["platform-conventions"]
	if skill["version"] != "0.1.0" || skill["tier"] != "global" || skill["source"].(map[string]any)["path"] != "skills/platform-conventions" {
		t.Errorf("platform-conventions: %v", skill)
	}
	if p, _ := skill["metadata"].(map[string]any)["provenance"].(map[string]any); p["commit"] != commitA {
		t.Errorf("the skill's metadata is not the released file: %v", skill["metadata"])
	}
	if b := ix["build"].(map[string]any); b["pipeline_id"] != float64(3086000001) || ix["environment"] != "local" {
		t.Errorf("build: %v", ix["build"])
	}
	// Signed with the record key; the three files under one new prefix,
	// the index last.
	if len(w.tools.puts) != 3 || !strings.HasSuffix(w.tools.puts[2], "/catalog.json") || !strings.HasPrefix(w.tools.puts[0], "s3://agentic-catalog-index-local/indexes/") {
		t.Errorf("puts: %v", w.tools.puts)
	}
	page, _ := os.ReadFile(filepath.Join(w.dir, "out", "index.html"))
	if !strings.Contains(string(page), "https://gateway.agentic.internal/mcp/reference-mcp") {
		t.Errorf("index.html:\n%s", page)
	}
	// Every read was by the job's token.
	for _, r := range w.repos.requests {
		if !strings.HasPrefix(r, "GET ") {
			t.Errorf("the build sent %s", r)
		}
	}

	// And search reads it back from the bucket.
	code, out, errOut = w.te.run("search", "-json")
	if code != 0 || !strings.Contains(out, "platform-conventions") {
		t.Errorf("search the built index: code %d, stderr %q", code, errOut)
	}
}

func TestCatalogBuildRefuses(t *testing.T) {
	cases := []struct {
		name   string
		change func(t *testing.T, w *catalogWorld)
		gone   string
		want   string
	}{
		{"an owner not in teams.yaml", func(t *testing.T, w *catalogWorld) {
			w.repos.file(mcpPath, "v0.1.2", "workload.yaml", mcpWorkload("reference-mcp", "nobody"))
		}, "reference-mcp", `its owner "nobody" is not a team in access/teams.yaml`},
		{"a name taken twice", func(t *testing.T, w *catalogWorld) {
			w.regs["ci-workload-release"] = append(w.regs["ci-workload-release"], map[string]any{"id": 89099999, "path": "workloads/stray/stray-mcp"})
			w.repos.file(strayPath, "v1.0.0", "workload.yaml", mcpWorkload("reference-mcp", "reference"))
			d := w.tools.push(workloadsRepo+"reference-mcp", []byte("another"))
			w.tools.tag(workloadsRepo+"reference-mcp", "v1.0.0", d)
			w.tools.sign(d, envKey(t, defaults.ReleaseKey))
			w.writeRegistrations()
		}, "reference-mcp", "the name reference-mcp is taken 2 times"},
		{"an unsigned release", func(t *testing.T, w *catalogWorld) {
			for d := range w.tools.blobs[workloadsRepo+"reference-notes-agent"] {
				w.tools.unsign(d)
				// Its provenance by the release key is no signature.
				w.tools.attest(d, "slsaprovenance1", envKey(t, defaults.ReleaseKey), provenance(commitB))
			}
		}, "reference-notes-agent", "is not signed by the release key"},
		{"a release not in the registry", func(t *testing.T, w *catalogWorld) {
			delete(w.tools.tags[workloadsRepo+"reference-mcp"], "v0.1.2")
		}, "reference-mcp", "is not in the registry"},
		{"a tag that is not its artifact.yaml", func(t *testing.T, w *catalogWorld) {
			w.repos.file(libraryPath, "prompt/summarise-changes/v0.1.0", "prompts/summarise-changes/artifact.yaml", strings.Split(artifactYAML("prompt", "summarise-changes", "0.2.0", commitB), "provenance:")[0])
		}, "summarise-changes", "the tag is prompt summarise-changes 0.1.0"},
		{"a team library's name without its prefix", func(t *testing.T, w *catalogWorld) {
			w.repos.file(libraryPath, "prompt/summarise-changes/v0.1.0", "library.yaml", "owner: platform\ntier: team\nprefix: sre\n")
		}, "summarise-changes", "named sre-<name>"},
		{"an invalid workload.yaml", func(t *testing.T, w *catalogWorld) {
			w.repos.file(mcpPath, "v0.1.2", "workload.yaml", "name: reference-mcp\nkind: mcp-server\n")
		}, "reference-mcp", "does not match schemas/workload.schema.json"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			w := newCatalogWorld(t)
			c.change(t, w)
			code, _, errOut := w.build("-sign-key", recordKMS, "-bucket", "agentic-catalog-index-local")
			if code != exitRefused || !strings.Contains(errOut, c.want) {
				t.Fatalf("code %d, stderr %q", code, errOut)
			}
			if _, ok := entryNames(w.index(t))[c.gone]; ok {
				t.Errorf("%s is still in the index", c.gone)
			}
			if len(w.tools.puts) != 3 {
				t.Errorf("the rest was not published: %v", w.tools.puts)
			}
		})
	}
}

// TestCatalogBuildFailsClosed: a registered project the job cannot read
// would withdraw all its entries, so nothing is written or published.
func TestCatalogBuildFailsClosed(t *testing.T) {
	for _, c := range []struct {
		name   string
		change func(w *catalogWorld)
	}{
		{"its tags", func(w *catalogWorld) { w.repos.jobReads[notesPath] = false }},
		{"a registered project that is not there", func(w *catalogWorld) {
			w.regs["ci-library-release"] = append(w.regs["ci-library-release"], map[string]any{"id": 81999999, "path": "gone-library"})
			w.writeRegistrations()
		}},
	} {
		t.Run(c.name, func(t *testing.T) {
			w := newCatalogWorld(t)
			c.change(w)
			code, out, errOut := w.build("-sign-key", recordKMS, "-bucket", "agentic-catalog-index-local")
			if code != 1 || !strings.Contains(errOut, "the job cannot read") || !strings.Contains(errOut, "Nothing is published") {
				t.Fatalf("code %d, stdout %q, stderr %q", code, out, errOut)
			}
			if _, err := os.Stat(filepath.Join(w.dir, "out", "catalog.json")); err == nil {
				t.Error("catalog.json written")
			}
			if len(w.tools.puts) != 0 {
				t.Errorf("published: %v", w.tools.puts)
			}
		})
	}
}

// TestCatalogBuildKeepsThePreviousRelease: a newest release that fails a
// check never removes the entry the one before it holds; a withdrawal
// does.
func TestCatalogBuildKeepsThePreviousRelease(t *testing.T) {
	w := newCatalogWorld(t)
	// reference-mcp v0.1.3, tagged and pushed but not signed yet.
	w.repos.tag(mcpPath, "v0.1.3", commitC)
	w.repos.file(mcpPath, "v0.1.3", "workload.yaml", mcpWorkload("reference-mcp", "reference"))
	d := w.tools.push(workloadsRepo+"reference-mcp", []byte("unsigned v0.1.3"))
	w.tools.tag(workloadsRepo+"reference-mcp", "v0.1.3", d)
	// The skill's newest release, unsigned: 0.0.9 stays.
	for dg := range w.tools.blobs[libraryRegistry+"skill/platform-conventions"] {
		if w.tools.tags[libraryRegistry+"skill/platform-conventions"]["v0.1.0"] == dg {
			w.tools.unsign(dg)
		}
	}
	code, _, errOut := w.build()
	if code != exitRefused {
		t.Fatalf("code %d, stderr %q", code, errOut)
	}
	en := entryNames(w.index(t))
	if m := en["reference-mcp"]; m == nil || m["version"] != "0.1.2" {
		t.Errorf("reference-mcp: %v", m)
	}
	if m := en["platform-conventions"]; m == nil || m["version"] != "0.0.9" {
		t.Errorf("platform-conventions: %v", m)
	}
	for _, want := range []string{"tag v0.1.3: floci:4566/000000000000/us-east-1/workloads/reference/reference-mcp@" + d + " is not signed by the release key", "the index keeps v0.1.2", "the index keeps skill/platform-conventions/v0.0.9"} {
		if !strings.Contains(errOut, want) {
			t.Errorf("stderr lacks %q: %s", want, errOut)
		}
	}

	// v0.1.4 retires it: a withdrawal, which no older release undoes.
	w.repos.tag(mcpPath, "v0.1.4", commitB)
	w.repos.file(mcpPath, "v0.1.4", "workload.yaml", strings.Replace(mcpWorkload("reference-mcp", "reference"), "support: experimental", "support: retired\ndeprecation:\n  replacement: notes-mcp\n  removal_date: \"2027-01-31\"", 1))
	code, _, errOut = w.build()
	if _, ok := entryNames(w.index(t))["reference-mcp"]; ok {
		t.Errorf("a retired workload is in the index (code %d, stderr %q)", code, errOut)
	}
	// And a newer release that fails does not bring back what v0.1.4
	// withdrew.
	w.repos.tag(mcpPath, "v0.1.5", commitA)
	w.repos.file(mcpPath, "v0.1.5", "workload.yaml", mcpWorkload("reference-mcp", "nobody"))
	code, _, errOut = w.build()
	if _, ok := entryNames(w.index(t))["reference-mcp"]; ok || !strings.Contains(errOut, "tag v0.1.5: its owner \"nobody\" is not a team in access/teams.yaml; v0.1.4 withdrew it") {
		t.Errorf("after the withdrawal: code %d, stderr %q", code, errOut)
	}
}

func TestCatalogBuildSignsWithTheRecordKeyAlone(t *testing.T) {
	w := newCatalogWorld(t)
	code, _, errOut := w.build("-sign-key", releaseKMS, "-bucket", "agentic-catalog-index-local")
	if code != 1 || !strings.Contains(errOut, "does not verify with the local record key") {
		t.Fatalf("signed with the release key: code %d, stderr %q", code, errOut)
	}
	if len(w.tools.puts) != 0 {
		t.Errorf("published: %v", w.tools.puts)
	}
	if _, err := os.Stat(filepath.Join(w.dir, "out", "catalog.json.sigstore.json")); err == nil {
		t.Error("the wrong key's bundle was left")
	}
	if code, _, _ := w.build("-bucket", "b"); code != 2 {
		t.Errorf("-bucket without -sign-key: code %d", code)
	}
	delete(w.te.vars, "CI_PIPELINE_ID")
	if code, _, errOut := w.build(); code != 2 || !strings.Contains(errOut, "provenance") {
		t.Errorf("no pipeline ID: code %d, stderr %q", code, errOut)
	}
}

// registryWorld is Agentregistry's API behind its write route, as its
// store keeps rows (one per kind, name and tag; apply upserts, delete
// removes), and the realm's catalog-publisher client.
type registryWorld struct {
	srv     *httptest.Server
	issuer  *authtest.Issuer
	applied []string
	deleted []string
	rows    map[string]map[string]any // kind/name/tag -> the item as listed
	fail    string
}

func newRegistryWorld(t *testing.T, te *testEnv) *registryWorld {
	r := &registryWorld{issuer: authtest.New(t), rows: map[string]map[string]any{}}
	r.srv = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		c, _ := tokenClaims(req.Header.Get("Authorization"))
		if c["aud"] != r.srv.URL+"/registry" {
			w.WriteHeader(401)
			return
		}
		switch {
		case (req.Method == "POST" || req.Method == "DELETE") && req.URL.Path == "/registry/v0/apply":
			if req.Header.Get("Content-Type") != "application/yaml" {
				w.WriteHeader(415)
				return
			}
			dec := yaml.NewDecoder(req.Body)
			var results []map[string]any
			for {
				var d arDoc
				if dec.Decode(&d) != nil {
					break
				}
				k := d.Kind + "/" + d.Metadata.Name + "/" + d.Metadata.Tag
				st := map[string]any{"kind": d.Kind, "name": d.Metadata.Name, "tag": d.Metadata.Tag}
				switch {
				case d.Metadata.Name == r.fail:
					st["status"], st["error"] = "failed", "remote.url: invalid"
				case req.Method == "DELETE":
					r.deleted = append(r.deleted, k)
					delete(r.rows, k)
					st["status"] = "deleted"
				default:
					r.applied = append(r.applied, k)
					b, _ := json.Marshal(d)
					var m map[string]any
					json.Unmarshal(b, &m)
					m["metadata"].(map[string]any)["uid"] = "u-" + k
					st["status"] = "created"
					if _, ok := r.rows[k]; ok {
						st["status"] = "configured"
					}
					r.rows[k] = m
				}
				results = append(results, st)
			}
			json.NewEncoder(w).Encode(map[string]any{"results": results})
		case req.Method == "GET" && (req.URL.Path == "/registry/v0/agents" || req.URL.Path == "/registry/v0/mcpservers"):
			kind := map[string]string{"/registry/v0/agents": "Agent", "/registry/v0/mcpservers": "MCPServer"}[req.URL.Path]
			items := []map[string]any{}
			for k, m := range r.rows {
				if strings.HasPrefix(k, kind+"/") {
					items = append(items, m)
				}
			}
			json.NewEncoder(w).Encode(map[string]any{"items": items})
		default:
			w.WriteHeader(404)
		}
	}))
	t.Cleanup(r.srv.Close)
	r.issuer.Federated = map[string]authtest.Federated{"catalog-publisher": {Assertion: "sa-token-of-the-cronjob", Audiences: map[string]string{"registry": r.srv.URL + "/registry"}}}
	sa := filepath.Join(t.TempDir(), "token")
	os.WriteFile(sa, []byte("sa-token-of-the-cronjob\n"), 0o600)
	te.vars["AGENTCTL_ASSERTION_FILE"] = sa
	te.vars["AGENTCTL_ISSUER"] = r.issuer.URL
	te.vars["AGENTCTL_REGISTRY_URL"] = r.srv.URL + "/registry"
	return r
}

// trustBoth trusts the registry's and the issuer's test certificates.
func (r *registryWorld) client() *http.Client {
	c := r.srv.Client()
	pool := c.Transport.(*http.Transport).TLSClientConfig.RootCAs
	pool.AddCert(r.issuer.Server.Certificate())
	return c
}

func TestCatalogPublish(t *testing.T) {
	te, _ := catalogTestEnv(t)
	idx := writeIndex(t, t.TempDir(), exampleIndex(t), envKey(t, defaults.RecordKey))
	r := newRegistryWorld(t, te)
	run := func(args ...string) (int, string, string) {
		return te.runWith(func(e *env) { e.httpClient = r.client() }, append([]string{"catalog"}, args...)...)
	}

	code, out, errOut := run("publish", "-index", idx, "-dry-run")
	if code != 0 || !strings.Contains(out, "kind: MCPServer") || !strings.Contains(out, "url: https://gateway.agentic.internal/mcp/reference-mcp") || strings.Contains(out, "kind: Skill") {
		t.Fatalf("dry run: code %d, stderr %q:\n%s", code, errOut, out)
	}
	if !strings.Contains(out, "agentic-platform/digest: sha256:cb71aa6e") || !strings.Contains(out, "agentic-platform/owner: reference") {
		t.Errorf("R3's labels and annotations:\n%s", out)
	}
	if r.issuer.ClientCredentials != 0 {
		t.Error("a dry run signed in")
	}

	code, out, errOut = run("publish", "-index", idx)
	if code != 0 || len(r.applied) != 3 || !strings.Contains(out, "MCPServer reference-mcp 0.1.1: created") {
		t.Fatalf("publish: code %d, applied %v, stdout %q, stderr %q", code, r.applied, out, errOut)
	}
	if r.issuer.ClientCredentials != 1 {
		t.Errorf("%d client-credentials grants", r.issuer.ClientCredentials)
	}

	// A document the registry refuses inside its 200.
	r.fail = "reference-agent"
	if code, _, errOut := run("publish", "-index", idx); code != 1 || !strings.Contains(errOut, "reference-agent 0.1.0: failed: remote.url: invalid") {
		t.Errorf("a failed document: code %d, stderr %q", code, errOut)
	}
	r.fail = ""

	// A wrong assertion: no token, nothing applied.
	os.WriteFile(te.vars["AGENTCTL_ASSERTION_FILE"], []byte("another"), 0o600)
	n := len(r.applied)
	if code, _, errOut := run("publish", "-index", idx); code != 1 || !strings.Contains(errOut, "invalid_client") || len(r.applied) != n {
		t.Errorf("a wrong assertion: code %d, stderr %q", code, errOut)
	}
	os.WriteFile(te.vars["AGENTCTL_ASSERTION_FILE"], []byte("sa-token-of-the-cronjob"), 0o600)

	// An index whose signature fails: nothing is read from it.
	bad := writeIndex(t, t.TempDir(), exampleIndex(t), otherKey)
	if code, _, errOut := run("publish", "-index", bad); code != 1 || !strings.Contains(errOut, "refusing the index") || len(r.applied) != n {
		t.Errorf("an unverified index: code %d, stderr %q", code, errOut)
	}
}

// TestCatalogPublishRefusesAMassDeletion: an index that would delete more
// than half of what the registry lists is refused unless forced.
func TestCatalogPublishRefusesAMassDeletion(t *testing.T) {
	te, _ := catalogTestEnv(t)
	key := envKey(t, defaults.RecordKey)
	full := writeIndex(t, t.TempDir(), exampleIndex(t), key)
	var ix map[string]any
	json.Unmarshal(exampleIndex(t), &ix)
	var kept []any
	for _, raw := range ix["entries"].([]any) {
		if raw.(map[string]any)["metadata"].(map[string]any)["name"] != "reference-mcp" && raw.(map[string]any)["metadata"].(map[string]any)["name"] != "reference-agent" {
			kept = append(kept, raw)
		}
	}
	ix["entries"] = kept
	ix["timestamp"] = "2026-11-19T21:00:12Z"
	thin, _ := json.Marshal(ix)
	small := writeIndex(t, t.TempDir(), thin, key)
	r := newRegistryWorld(t, te)
	run := func(args ...string) (int, string, string) {
		return te.runWith(func(e *env) { e.httpClient = r.client() }, append([]string{"catalog"}, args...)...)
	}
	if code, _, errOut := run("publish", "-index", full); code != 0 {
		t.Fatalf("publish: code %d, stderr %q", code, errOut)
	}
	n := len(r.applied)
	code, _, errOut := run("publish", "-index", small)
	if code != 1 || !strings.Contains(errOut, "would delete 2 of the 3") || len(r.applied) != n || len(r.deleted) != 0 {
		t.Fatalf("a mass deletion: code %d, stderr %q, applied %v, deleted %v", code, errOut, r.applied, r.deleted)
	}
	if code, _, errOut := run("publish", "-index", small, "-force"); code != 0 || len(r.deleted) != 2 {
		t.Errorf("-force: code %d, stderr %q, deleted %v", code, errOut, r.deleted)
	}
}

func TestCatalogDrift(t *testing.T) {
	te, _ := catalogTestEnv(t)
	idx := writeIndex(t, t.TempDir(), exampleIndex(t), envKey(t, defaults.RecordKey))
	r := newRegistryWorld(t, te)
	run := func(args ...string) (int, string, string) {
		return te.runWith(func(e *env) { e.httpClient = r.client() }, append([]string{"catalog"}, args...)...)
	}
	if code, _, errOut := run("publish", "-index", idx); code != 0 {
		t.Fatalf("publish: code %d, stderr %q", code, errOut)
	}
	if code, out, errOut := run("drift", "-index", idx); code != 0 || !strings.Contains(out, "no drift") {
		t.Fatalf("no drift: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	// An entry changed by hand, and one added by hand.
	r.rows["MCPServer/reference-mcp/0.1.1"]["spec"].(map[string]any)["remote"].(map[string]any)["url"] = "https://elsewhere.example/mcp"
	r.rows["Agent/rogue-agent/latest"] = map[string]any{"apiVersion": "ar.dev/v1alpha1", "kind": "Agent", "metadata": map[string]any{"name": "rogue-agent", "tag": "latest"}, "spec": map[string]any{}}
	code, out, _ := run("drift", "-index", idx)
	if code != 1 || !strings.Contains(out, "spec.remote.url is https://elsewhere.example/mcp") || !strings.Contains(out, "Agent/rogue-agent/latest: in the registry, not in the index") {
		t.Errorf("drift: code %d:\n%s", code, out)
	}
	// The next publish puts the index back, and drift finds nothing.
	if code, out, errOut := run("publish", "-index", idx); code != 0 || !strings.Contains(out, "Agent rogue-agent latest: deleted") {
		t.Fatalf("publish again: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	if code, out, _ := run("drift", "-index", idx); code != 0 {
		t.Errorf("after publish: code %d:\n%s", code, out)
	}
}

// TestCatalogPublishAfterABump: a newer release replaces the older one in
// the registry, so publish and drift agree after every build.
func TestCatalogPublishAfterABump(t *testing.T) {
	te, _ := catalogTestEnv(t)
	key := envKey(t, defaults.RecordKey)
	a := writeIndex(t, t.TempDir(), exampleIndex(t), key)
	var ix map[string]any
	json.Unmarshal(exampleIndex(t), &ix)
	for _, raw := range ix["entries"].([]any) {
		en := raw.(map[string]any)
		if en["metadata"].(map[string]any)["name"] == "reference-mcp" {
			en["version"], en["source"].(map[string]any)["tag"] = "0.1.2", "v0.1.2"
		}
	}
	ix["timestamp"] = "2026-11-19T21:00:12Z"
	bumped, _ := json.Marshal(ix)
	b := writeIndex(t, t.TempDir(), bumped, key)
	r := newRegistryWorld(t, te)
	run := func(args ...string) (int, string, string) {
		return te.runWith(func(e *env) { e.httpClient = r.client() }, append([]string{"catalog"}, args...)...)
	}
	if code, _, errOut := run("publish", "-index", a); code != 0 {
		t.Fatalf("publish A: code %d, stderr %q", code, errOut)
	}
	code, out, errOut := run("publish", "-index", b)
	if code != 0 || !strings.Contains(out, "MCPServer reference-mcp 0.1.2: created") || !strings.Contains(out, "MCPServer reference-mcp 0.1.1: deleted") {
		t.Fatalf("publish B: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	if _, ok := r.rows["MCPServer/reference-mcp/0.1.1"]; ok {
		t.Error("the older release is still listed")
	}
	if code, out, _ := run("drift", "-index", b); code != 0 {
		t.Errorf("drift after the bump: code %d:\n%s", code, out)
	}
}
