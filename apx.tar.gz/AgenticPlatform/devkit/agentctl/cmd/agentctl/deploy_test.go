package main

import (
	"strings"
	"testing"
)

const (
	envPath    = "acme/platform/infra/environments"
	mcpPath    = "acme/platform/workloads/reference/reference-mcp"
	notesPath  = "acme/platform/workloads/reference/reference-notes-agent"
	flowPath   = "acme/platform/workloads/reference/reference-workflow"
	digestA    = "sha256:cb71aa6e4e60c486f8e5dae946fe9ebc782ae4b15cab5a5d94018cb42142200c"
	digestB    = "sha256:62459fa356118645d17ad08c4ff5839645f3c2accbd2e8b299c97bd9a056d3fe"
	appBasePin = "sha256:723048506f6be16fa003f7a1693c2bc84cd7076d1f4e7595e452e06d8fe31c04"
	integPin   = "sha256:d4667a02f9eb7fa48bd6077ceb7429aeca2ab2844a21a901fbfb610df5fc7ac7"
	floci      = "floci:4566/000000000000/us-east-1"
)

func deployWorld(t *testing.T) (*testEnv, *fakeRepos) {
	f := newFakeRepos(t)
	f.project(envPath, 88996235)
	f.file(envPath, "main", "clusters/local/platform/values.yaml", "registry:\n  host: "+floci+"\n  plainHttp: true\n")
	f.file(envPath, "main", "versions.yaml", "app-base-chart:\n  chartVersion: 0.1.0\n  chartDigest: "+appBasePin+"\nagent-integration-chart:\n  chartVersion: 0.1.0\n  chartDigest: "+integPin+"\n")

	f.project(mcpPath, 89090989)
	f.tag(mcpPath, "v0.1.2", "75aacad235360898afac4dcfbaf28b89ea535ece")
	f.file(mcpPath, "v0.1.2", "workload.yaml", "name: reference-mcp\nkind: mcp-server\nruntime: container\nowner: reference\nsupport: experimental\ntools:\n  - name: list_notes\n    annotations:\n      readOnlyHint: true\nlimits:\n  wall_time_seconds: 30\n")
	f.file(mcpPath, "v0.1.2", "deploy/app-base.yaml", "workload:\n  name: reference-mcp\n")
	f.file(mcpPath, "v0.1.2", "deploy/agent-integration.yaml", "approvals:\n  enabled: true\n")
	f.file(mcpPath, "v0.1.2", "deploy/access.yaml", "routes:\n  reference-mcp:\n    path: mcp/reference-mcp\n    gateway: gateway\n")

	f.project(notesPath, 89090991)
	f.tag(notesPath, "v0.1.0", "b8d64c06d39052a3084a7117910aa999226081e5")
	f.file(notesPath, "v0.1.0", "workload.yaml", "name: reference-notes-agent\nkind: agent\nruntime: kagent\nowner: reference\nsupport: experimental\n")
	f.file(notesPath, "v0.1.0", "deploy/agent-integration.yaml", "workload:\n  name: reference-notes-agent\n")

	f.project(flowPath, 89090993)
	f.tag(flowPath, "v0.1.0", "f388c66c4410addae6d2ed4017e1aa7f211d7bdd")
	f.file(flowPath, "v0.1.0", "workload.yaml", "name: reference-workflow\nkind: workflow\nruntime: pipeline\nowner: reference\nsupport: experimental\nlimits:\n  model_calls: 4\n  tool_calls: 4\n  tokens: 20000\n  wall_time_seconds: 120\n")

	te := newTestEnv(t)
	te.vars["GITLAB_TOKEN"] = f.token
	te.vars["GITLAB_HOST"] = f.srv.URL
	te.vars["AGENTCTL_ENVIRONMENTS_PROJECT"] = envPath
	return te, f
}

func (te *testEnv) deploy(f *fakeRepos, args ...string) (int, string, string) {
	return te.runWith(func(e *env) { e.httpClient = f.srv.Client() }, append([]string{"deploy", "request"}, args...)...)
}

func actionsOf(c map[string]any) map[string]map[string]any {
	out := map[string]map[string]any{}
	for _, a := range c["actions"].([]any) {
		m := a.(map[string]any)
		out[m["file_path"].(string)] = m
	}
	return out
}

func TestDeployRequestFirstDeploy(t *testing.T) {
	te, f := deployWorld(t)
	code, out, errOut := te.deploy(f, "--environment", "local", "--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", floci+"/workloads/reference/reference-mcp@"+digestA)
	if code != 0 {
		t.Fatalf("code %d, stderr %q", code, errOut)
	}
	if !strings.HasSuffix(strings.TrimSpace(out), "/-/merge_requests/1") {
		t.Errorf("stdout %q", out)
	}
	if len(f.commits) != 1 || len(f.mrs) != 1 {
		t.Fatalf("%d commits, %d merge requests", len(f.commits), len(f.mrs))
	}
	c := f.commits[0]
	if c["project"] != envPath || c["branch"] != "feat/deploy-reference-mcp-v0-1-2" || c["start_branch"] != "main" {
		t.Errorf("commit: %v", c)
	}
	acts := actionsOf(c)
	rel := acts["clusters/local/workloads/reference-mcp/release.yaml"]
	content, _ := rel["content"].(string)
	for _, want := range []string{"team: reference\n", "namespace: reference-mcp\n", "releases: [app-base, agent-integration]\n", "app-base: {version: 0.1.0, digest: \"" + appBasePin + "\"}", "agent-integration: {version: 0.1.0, digest: \"" + integPin + "\"}", "  tag: v0.1.2\n", "  digest: \"" + digestA + "\"\n", "75aacad235360898afac4dcfbaf28b89ea535ece"} {
		if !strings.Contains(content, want) {
			t.Errorf("release.yaml lacks %q:\n%s", want, content)
		}
	}
	if rel["action"] != "create" {
		t.Errorf("release.yaml action %v", rel["action"])
	}
	if v, _ := acts["clusters/local/workloads/reference-mcp/app-base.yaml"]["content"].(string); !strings.HasSuffix(v, "workload:\n  name: reference-mcp\n") || !strings.HasPrefix(v, "# From "+mcpPath+"'s\n# deploy/app-base.yaml at v0.1.2") {
		t.Errorf("app-base.yaml:\n%s", v)
	}
	if v, _ := acts["clusters/local/domains/reference/reference-mcp.yaml"]["content"].(string); !strings.Contains(v, "a stub") || !strings.Contains(v, "path: mcp/reference-mcp") {
		t.Errorf("access stub:\n%s", v)
	}
	msg := c["commit_message"].(string)
	if !strings.HasPrefix(msg, "feat(workloads): deploy reference-mcp v0.1.2\n\n") || !strings.HasSuffix(msg, "\n\nRefs: D39\n") {
		t.Errorf("commit message:\n%s", msg)
	}
	for _, l := range strings.Split(msg, "\n") {
		if len(l) > 72 {
			t.Errorf("a line over 72: %q", l)
		}
	}
	for _, bad := range []string{"Co-Authored-By", "Generated with", "Signed-off-by"} {
		if strings.Contains(msg, bad) || strings.Contains(f.mrs[0]["description"].(string), bad) {
			t.Errorf("an attribution line: %s", bad)
		}
	}
	mr := f.mrs[0]
	if mr["title"] != "feat(workloads): deploy reference-mcp v0.1.2" || mr["target_branch"] != "main" || mr["remove_source_branch"] != true {
		t.Errorf("merge request: %v", mr)
	}
	if d := mr["description"].(string); !strings.Contains(d, "The access file is a stub") || !strings.Contains(d, digestA) || !strings.Contains(d, "a first deploy") {
		t.Errorf("description:\n%s", d)
	}
}

func TestDeployRequestDryRun(t *testing.T) {
	te, f := deployWorld(t)
	code, out, errOut := te.deploy(f, "--dry-run", "--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", floci+"/workloads/reference/reference-mcp@"+digestA)
	if code != 0 || !strings.Contains(out, "branch: feat/deploy-reference-mcp-v0-1-2") || !strings.Contains(out, "--- create clusters/local/domains/reference/reference-mcp.yaml") {
		t.Fatalf("code %d, stdout:\n%s\nstderr %q", code, out, errOut)
	}
	if len(f.commits) != 0 || len(f.mrs) != 0 {
		t.Error("a dry run wrote to GitLab")
	}
	for _, r := range f.requests {
		if !strings.HasPrefix(r, "GET ") {
			t.Errorf("a dry run sent %s", r)
		}
	}
}

func TestDeployRequestUpdate(t *testing.T) {
	te, f := deployWorld(t)
	f.file(envPath, "main", "clusters/local/workloads/reference-mcp/release.yaml", "team: reference\n")
	f.file(envPath, "main", "clusters/local/domains/reference/reference-mcp.yaml", "routes: {}\n")
	args := []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", floci + "/workloads/reference/reference-mcp@" + digestA}
	code, _, errOut := te.deploy(f, args...)
	if code != 0 {
		t.Fatalf("code %d, stderr %q", code, errOut)
	}
	acts := actionsOf(f.commits[0])
	if acts["clusters/local/workloads/reference-mcp/release.yaml"]["action"] != "update" {
		t.Errorf("release.yaml: %v", acts)
	}
	if _, ok := acts["clusters/local/domains/reference/reference-mcp.yaml"]; ok {
		t.Error("the environment's access file was replaced")
	}
	if d := f.mrs[0]["description"].(string); !strings.Contains(d, "differs from it") || !strings.Contains(d, "an update") {
		t.Errorf("description:\n%s", d)
	}

	// Once main has exactly those files, there is nothing to request.
	for _, a := range f.commits[0]["actions"].([]any) {
		m := a.(map[string]any)
		f.file(envPath, "main", m["file_path"].(string), m["content"].(string))
	}
	delete(f.branches[envPath], "feat/deploy-reference-mcp-v0-1-2")
	code, out, _ := te.deploy(f, args...)
	if code != 0 || !strings.Contains(out, "nothing to request") || len(f.commits) != 1 {
		t.Errorf("again: code %d, stdout %q, %d commits", code, out, len(f.commits))
	}
}

func TestDeployRequestKagent(t *testing.T) {
	te, f := deployWorld(t)
	ref := floci + "/workloads/reference/reference-notes-agent@" + digestB
	if code, _, errOut := te.deploy(f, "--project", notesPath, "--tag", "v0.1.0", "--workload", "reference-notes-agent", "--image", ref); code != 1 || !strings.Contains(errOut, "give its packaged definition with -definition") {
		t.Fatalf("-image for a kagent agent: code %d, stderr %q", code, errOut)
	}
	code, _, errOut := te.deploy(f, "--project", notesPath, "--tag", "v0.1.0", "--workload", "reference-notes-agent", "--definition", ref)
	if code != 0 {
		t.Fatalf("code %d, stderr %q", code, errOut)
	}
	acts := actionsOf(f.commits[0])
	rel := acts["clusters/local/workloads/reference-notes-agent/release.yaml"]["content"].(string)
	if !strings.Contains(rel, "releases: [agent-integration]\n") || strings.Contains(rel, "app-base:") || !strings.Contains(rel, digestB) {
		t.Errorf("release.yaml:\n%s", rel)
	}
	if _, ok := acts["clusters/local/workloads/reference-notes-agent/app-base.yaml"]; ok {
		t.Error("an app-base.yaml for a kagent agent")
	}
	if v := acts["clusters/local/domains/reference/reference-notes-agent.yaml"]["content"].(string); !strings.Contains(v, "has no deploy/access.yaml") || !strings.Contains(v, "routes: {}") {
		t.Errorf("access stub without deploy/access.yaml:\n%s", v)
	}
}

func TestDeployRequestRefuses(t *testing.T) {
	img := floci + "/workloads/reference/reference-mcp@" + digestA
	cases := []struct {
		name string
		args []string
		code int
		want string
	}{
		{"a workflow", []string{"--project", flowPath, "--tag", "v0.1.0", "--workload", "reference-workflow", "--image", floci + "/workloads/reference/reference-workflow@" + digestA}, 1, "a workflow, which runs in its pipeline"},
		{"another name", []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "notes-mcp", "--image", img}, 1, `names "reference-mcp", not "notes-mcp"`},
		{"another repository", []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", floci + "/workloads/reference/reference-agent@" + digestA}, 1, "not floci:4566/000000000000/us-east-1/workloads/reference/reference-mcp"},
		{"another registry", []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", "ghcr.io/acme/workloads/reference/reference-mcp@" + digestA}, 1, "the workload's repository (D4)"},
		{"a tag that is not there", []string{"--project", mcpPath, "--tag", "v9.9.9", "--workload", "reference-mcp", "--image", img}, 1, "the tag v9.9.9"},
		{"an environment that is not there", []string{"--environment", "prod", "--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", img}, 1, "is \"prod\" an environment"},
		{"an image by tag", []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", floci + "/workloads/reference/reference-mcp:v0.1.2"}, 2, "@sha256"},
		{"not a release tag", []string{"--project", mcpPath, "--tag", "main", "--workload", "reference-mcp", "--image", img}, 2, "not a release tag"},
		{"both", []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", img, "--definition", img}, 2, "exactly one"},
		{"neither", []string{"--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp"}, 2, "exactly one"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			te, f := deployWorld(t)
			code, _, errOut := te.deploy(f, c.args...)
			if code != c.code || !strings.Contains(errOut, c.want) {
				t.Errorf("code %d, stderr %q", code, errOut)
			}
			if len(f.commits) != 0 || len(f.mrs) != 0 {
				t.Error("it wrote to GitLab")
			}
		})
	}
	t.Run("an open request", func(t *testing.T) {
		te, f := deployWorld(t)
		f.branches[envPath]["feat/deploy-reference-mcp-v0-1-2"] = true
		if code, _, errOut := te.deploy(f, "--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", img); code != 1 || !strings.Contains(errOut, "exists in") {
			t.Errorf("code %d, stderr %q", code, errOut)
		}
	})
	t.Run("no token", func(t *testing.T) {
		te, f := deployWorld(t)
		delete(te.vars, "GITLAB_TOKEN")
		if code, _, errOut := te.deploy(f, "--project", mcpPath, "--tag", "v0.1.2", "--workload", "reference-mcp", "--image", img); code != 2 || !strings.Contains(errOut, "no GitLab token") {
			t.Errorf("code %d, stderr %q", code, errOut)
		}
	})
}
