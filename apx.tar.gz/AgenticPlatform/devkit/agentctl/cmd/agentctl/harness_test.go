package main

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// harnessEnv is a test environment with Claude Code's managed directory
// under a temporary directory, never /etc/claude-code, and a repository.
func harnessEnv(t *testing.T) (*testEnv, *fakeTools, string, string) {
	te, f := catalogTestEnv(t)
	managed := filepath.Join(t.TempDir(), "claude-code")
	te.vars["AGENTCTL_CLAUDE_MANAGED_DIR"] = managed
	repo := t.TempDir()
	os.WriteFile(filepath.Join(repo, "AGENTS.md"), []byte("# Agents\n"), 0o644)
	return te, f, managed, repo
}

func readJSONFile(t *testing.T, p string) map[string]any {
	t.Helper()
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatal(err)
	}
	var v map[string]any
	if err := json.Unmarshal(b, &v); err != nil {
		t.Fatalf("%s: %v", p, err)
	}
	return v
}

func TestHarnessSetupWritesManagedSettings(t *testing.T) {
	te, _, managed, repo := harnessEnv(t)
	ca := filepath.Join(t.TempDir(), "ca.crt")
	os.WriteFile(ca, []byte("ca"), 0o644)
	code, out, errOut := te.run("harness", "setup", "-dir", repo, "-ca-file", ca)
	if code != 0 {
		t.Fatalf("setup: code %d, stderr %q", code, errOut)
	}
	p := filepath.Join(managed, "managed-settings.d", "50-agentic-platform.json")
	if !strings.Contains(out, p) || !strings.Contains(errOut, "no collector endpoint for workstations") {
		t.Errorf("stdout %q, stderr %q", out, errOut)
	}
	s := readJSONFile(t, p)
	if s["apiKeyHelper"] != "/opt/agentctl/bin/agentctl token --scope models" {
		t.Errorf("apiKeyHelper: %v", s["apiKeyHelper"])
	}
	if p, _ := s["allowedProviders"].([]any); len(p) != 1 || p[0] != "customEndpoint" || s["skipWebFetchPreflight"] != true {
		t.Errorf("allowedProviders %v, skipWebFetchPreflight %v", s["allowedProviders"], s["skipWebFetchPreflight"])
	}
	want := map[string]string{
		"ANTHROPIC_BASE_URL":                       "https://gateway.agentic.internal",
		"CLAUDE_CODE_API_KEY_HELPER_TTL_MS":        "240000",
		"ANTHROPIC_MODEL":                          "reasoning-default",
		"ANTHROPIC_DEFAULT_OPUS_MODEL":             "reasoning-default",
		"ANTHROPIC_DEFAULT_SONNET_MODEL":           "reasoning-default",
		"ANTHROPIC_DEFAULT_HAIKU_MODEL":            "fast-default",
		"CLAUDE_CODE_AUTO_COMPACT_WINDOW":          "200000",
		"CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
		"NODE_EXTRA_CA_CERTS":                      ca,
	}
	env := s["env"].(map[string]any)
	for k, v := range want {
		if env[k] != v {
			t.Errorf("env %s = %v, want %s", k, env[k], v)
		}
	}
	for _, k := range []string{"CLAUDE_CODE_ENABLE_TELEMETRY", "OTEL_LOG_USER_PROMPTS", "ANTHROPIC_AUTH_TOKEN"} {
		if _, ok := env[k]; ok {
			t.Errorf("env sets %s", k)
		}
	}

	// With a collector: telemetry, prompts still redacted.
	code, _, errOut = te.run("harness", "setup", "-dir", repo, "-otel-endpoint", "https://otel.example.internal:4318", "-team", "reference")
	env = readJSONFile(t, p)["env"].(map[string]any)
	if code != 0 || env["CLAUDE_CODE_ENABLE_TELEMETRY"] != "1" || env["OTEL_EXPORTER_OTLP_ENDPOINT"] != "https://otel.example.internal:4318" || env["OTEL_RESOURCE_ATTRIBUTES"] != "team=reference" || env["OTEL_LOG_USER_PROMPTS"] != nil {
		t.Errorf("with telemetry: code %d, env %v, stderr %q", code, env, errOut)
	}
	// A machine's own managed-settings.json is never written.
	if _, err := os.Stat(filepath.Join(managed, "managed-settings.json")); err == nil {
		t.Error("managed-settings.json written")
	}
	if code, _, _ := te.run("harness", "setup", "-harness", "codex"); code != 2 {
		t.Errorf("-harness codex: code %d", code)
	}
	if code, _, _ := te.run("harness"); code != 2 {
		t.Errorf("harness without setup: code %d", code)
	}
}

func TestHarnessSetupNeedsRootForManagedSettings(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("root writes anywhere")
	}
	te, _, _, repo := harnessEnv(t)
	ro := filepath.Join(t.TempDir(), "ro")
	os.MkdirAll(ro, 0o555)
	code, _, errOut := te.run("harness", "setup", "-dir", repo, "-managed-dir", ro)
	if code != 1 || !strings.Contains(errOut, "run it as root") {
		t.Errorf("code %d, stderr %q", code, errOut)
	}
}

func TestHarnessSetupLinksSkillsAndWritesMCP(t *testing.T) {
	te, _, _, repo := harnessEnv(t)
	for _, n := range []string{"notes-style", "platform-conventions"} {
		os.MkdirAll(filepath.Join(repo, ".agents/skills", n), 0o755)
		os.WriteFile(filepath.Join(repo, ".agents/skills", n, "SKILL.md"), []byte("# "+n), 0o644)
	}
	os.WriteFile(filepath.Join(repo, "workload.yaml"), []byte("name: x-agent\nkind: agent\nrequires:\n  tools:\n    - server: reference-mcp\n      tools: [list_notes]\n"), 0o644)
	os.WriteFile(filepath.Join(repo, ".mcp.json"), []byte(`{"mcpServers":{"local-files":{"type":"stdio","command":"files-mcp"}}}`), 0o644)
	idx := writeIndex(t, t.TempDir(), exampleIndex(t), envKey(t, defaults.RecordKey))

	code, out, errOut := te.run("harness", "setup", "-skip-managed", "-dir", repo, "-index", idx)
	if code != 0 {
		t.Fatalf("setup: code %d, stderr %q", code, errOut)
	}
	for _, n := range []string{"notes-style", "platform-conventions"} {
		if b, _ := os.ReadFile(filepath.Join(repo, ".claude/skills", n, "SKILL.md")); string(b) != "# "+n {
			t.Errorf("%s through its link: %q", n, b)
		}
	}
	mcp := readJSONFile(t, filepath.Join(repo, ".mcp.json"))["mcpServers"].(map[string]any)
	r, _ := mcp["reference-mcp"].(map[string]any)
	if r["url"] != "https://gateway.agentic.internal/mcp/reference-mcp" || r["type"] != "http" {
		t.Errorf(".mcp.json: %v", mcp)
	}
	if o, _ := r["oauth"].(map[string]any); o["clientId"] != "claude-code" || o["scopes"] != "mcp/reference-mcp" || o["callbackPort"] != float64(33418) ||
		o["authServerMetadataUrl"] != "https://keycloak.agentic.internal/realms/agentic/.well-known/openid-configuration" {
		t.Errorf(".mcp.json's sign-in: %v", r["oauth"])
	}
	if _, ok := mcp["local-files"]; !ok {
		t.Errorf("a server of the person's own was dropped: %v", mcp)
	}
	if !strings.Contains(out, "wrote .mcp.json: reference-mcp") {
		t.Errorf("stdout %q", out)
	}

	// Again: nothing new to link; a server not in the index, refused.
	code, out, errOut = te.run("harness", "setup", "-skip-managed", "-dir", repo, "-index", idx, "-mcp", "no-such-mcp")
	if code != 1 || strings.Contains(out, "linked") || !strings.Contains(errOut, "no-such-mcp is not an MCP server in the index") {
		t.Errorf("again: code %d, stdout %q, stderr %q", code, out, errOut)
	}
	// An agent is not an MCP server.
	if code, _, errOut := te.run("harness", "setup", "-skip-managed", "-dir", repo, "-index", idx, "-mcp", "reference-agent"); code != 1 || !strings.Contains(errOut, "reference-agent is not an MCP server") {
		t.Errorf("an agent as -mcp: code %d, stderr %q", code, errOut)
	}
	// A skill directory of the person's own in .claude/skills stays.
	os.MkdirAll(filepath.Join(repo, ".agents/skills/third"), 0o755)
	os.WriteFile(filepath.Join(repo, ".agents/skills/third/SKILL.md"), []byte("# third"), 0o644)
	os.MkdirAll(filepath.Join(repo, ".claude/skills/third"), 0o755)
	if code, _, errOut := te.run("harness", "setup", "-skip-managed", "-dir", repo, "-index", idx); code != 1 || !strings.Contains(errOut, "is not the link") {
		t.Errorf("over a directory: code %d, stderr %q", code, errOut)
	}
	// A signature that fails stops .mcp.json.
	os.WriteFile(idx+".sigstore.json", bundleFor(otherKey, exampleIndex(t)), 0o644)
	if code, _, errOut := te.run("harness", "setup", "-skip-managed", "-dir", repo, "-index", idx); code != 1 || !strings.Contains(errOut, "refusing the index") {
		t.Errorf("an index that does not verify: code %d, stderr %q", code, errOut)
	}
}

// doctorWorld is a machine harness setup has set up, with Claude Code at
// a version, a helper that prints a token, and a gateway.
type doctorWorld struct {
	te                *testEnv
	managed, repo     string
	srv               *httptest.Server
	claude, token     string
	helperFails       bool
	gatewayStatus     int
	gotAuth, gotModel string
}

func newDoctorWorld(t *testing.T) *doctorWorld {
	te, _, managed, repo := harnessEnv(t)
	w := &doctorWorld{te: te, managed: managed, repo: repo, claude: "2.1.311 (Claude Code)", token: "eyJhbGciOi.payload.sig", gatewayStatus: 200}
	w.srv = httptest.NewTLSServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/v1/messages/count_tokens" || r.Method != http.MethodPost {
			http.NotFound(rw, r)
			return
		}
		w.gotAuth = r.Header.Get("Authorization")
		var body map[string]any
		json.NewDecoder(r.Body).Decode(&body)
		w.gotModel, _ = body["model"].(string)
		rw.WriteHeader(w.gatewayStatus)
		rw.Write([]byte(`{"input_tokens": 9}`))
	}))
	t.Cleanup(w.srv.Close)
	te.vars["AGENTCTL_GATEWAY"] = w.srv.URL
	te.runner.Handle = func(c execx.Cmd, _ []byte) (int, string, string, error) {
		switch {
		case c.Name == "claude" && c.Args[0] == "--version":
			return 0, w.claude + "\n", "", nil
		case c.Name == "/bin/sh" && strings.HasSuffix(c.Args[1], "token --scope models"):
			if w.helperFails {
				return 1, "", "agentctl: not signed in: run agentctl login\n", nil
			}
			return 0, w.token + "\n", "", nil
		}
		return -1, "", "", execx.ErrNotFound
	}
	ca := filepath.Join(t.TempDir(), "ca.crt")
	os.WriteFile(ca, []byte("ca"), 0o644)
	if code, _, errOut := te.run("harness", "setup", "-dir", repo, "-ca-file", ca); code != 0 {
		t.Fatalf("setup: code %d, stderr %q", code, errOut)
	}
	return w
}

func (w *doctorWorld) doctor(args ...string) (int, string, string) {
	return w.te.runWith(func(e *env) { e.httpClient = w.srv.Client() }, append([]string{"doctor", "-dir", w.repo}, args...)...)
}

func TestDoctorPassesWhatSetupWrote(t *testing.T) {
	w := newDoctorWorld(t)
	code, out, errOut := w.doctor()
	if code != 0 {
		t.Fatalf("doctor: code %d, stdout:\n%s\nstderr %q", code, out, errOut)
	}
	for _, want := range []string{"ok      Claude Code: 2.1.311", "ok      allowedProviders", "ok      apiKeyHelper", "ok      credential", "ok      gateway: the model route counted tokens for reasoning-default", "pending telemetry", "ok      overrides"} {
		if !strings.Contains(out, want) {
			t.Errorf("doctor lacks %q:\n%s", want, out)
		}
	}
	if strings.Contains(out, w.token) || strings.Contains(errOut, w.token) {
		t.Error("doctor printed the token")
	}
	t.Logf("doctor:\n%s", out)
	if w.gotAuth != "Bearer "+w.token || w.gotModel != "reasoning-default" {
		t.Errorf("gateway got %q, model %q", w.gotAuth, w.gotModel)
	}
}

// TestDoctorNamesTheFix breaks one thing at a time; doctor fails on it
// and says what to do.
func TestDoctorNamesTheFix(t *testing.T) {
	cases := []struct {
		name   string
		break_ func(t *testing.T, w *doctorWorld)
		want   []string
	}{
		{"old Claude Code", func(t *testing.T, w *doctorWorld) { w.claude = "2.1.200 (Claude Code)" },
			[]string{"FAIL    Claude Code: 2.1.200 is older than 2.1.285", "fix: install 2.1.311"}},
		{"another provider in another file", func(t *testing.T, w *doctorWorld) {
			os.WriteFile(filepath.Join(w.managed, "managed-settings.d", "90-other.json"), []byte(`{"allowedProviders":["anthropic"]}`), 0o644)
		}, []string{`FAIL    allowedProviders: ["customEndpoint","anthropic"]`, "fix: managed lists combine"}},
		{"a later file moves the base URL", func(t *testing.T, w *doctorWorld) {
			os.WriteFile(filepath.Join(w.managed, "managed-settings.d", "90-other.json"), []byte(`{"env":{"ANTHROPIC_BASE_URL":"https://api.anthropic.com"}}`), 0o644)
		}, []string{"FAIL    ANTHROPIC_BASE_URL: https://api.anthropic.com", "fix: the gateway"}},
		{"no managed settings", func(t *testing.T, w *doctorWorld) { os.RemoveAll(w.managed) },
			[]string{"FAIL    managed settings: none in", "fix: run agentctl harness setup"}},
		{"a provider variable", func(t *testing.T, w *doctorWorld) { w.te.vars["CLAUDE_CODE_USE_BEDROCK"] = "1" },
			[]string{"FAIL    CLAUDE_CODE_USE_BEDROCK: set in the environment", "fix: unset CLAUDE_CODE_USE_BEDROCK"}},
		{"a token in the user's settings", func(t *testing.T, w *doctorWorld) {
			os.MkdirAll(filepath.Join(w.te.vars["HOME"], ".claude"), 0o755)
			os.WriteFile(filepath.Join(w.te.vars["HOME"], ".claude", "settings.json"), []byte(`{"env":{"ANTHROPIC_AUTH_TOKEN":"sk-x","ANTHROPIC_BASE_URL":"https://elsewhere.example"}}`), 0o644)
		}, []string{"FAIL    ANTHROPIC_AUTH_TOKEN: set in ", "never runs the helper again", "warn    ANTHROPIC_BASE_URL: https://elsewhere.example in", "the managed value wins"}},
		{"prompts in telemetry", func(t *testing.T, w *doctorWorld) { w.te.vars["OTEL_LOG_USER_PROMPTS"] = "1" },
			[]string{"FAIL    OTEL_LOG_USER_PROMPTS", "fix: unset OTEL_LOG_USER_PROMPTS"}},
		{"not signed in", func(t *testing.T, w *doctorWorld) { w.helperFails = true },
			[]string{"FAIL    credential: agentctl: not signed in", "fix: sign in: agentctl login", "warn    gateway"}},
		{"the gateway refuses the token", func(t *testing.T, w *doctorWorld) { w.gatewayStatus = 401 },
			[]string{"FAIL    gateway: the model route refused the token (401", "fix: agentctl login -scope models"}},
		{"a CLAUDE.md", func(t *testing.T, w *doctorWorld) {
			os.WriteFile(filepath.Join(w.repo, "CLAUDE.md"), []byte("x"), 0o644)
		},
			[]string{"FAIL    instructions: CLAUDE.md is there", "fix: remove CLAUDE.md"}},
		{"a skill without its link", func(t *testing.T, w *doctorWorld) {
			os.MkdirAll(filepath.Join(w.repo, ".agents/skills/notes-style"), 0o755)
			os.WriteFile(filepath.Join(w.repo, ".agents/skills/notes-style/SKILL.md"), []byte("x"), 0o644)
		}, []string{"FAIL    skill notes-style", "fix: agentctl harness setup"}},
		{"an MCP server signing in as no pre-registered client", func(t *testing.T, w *doctorWorld) {
			os.WriteFile(filepath.Join(w.repo, "workload.yaml"), []byte("requires:\n  tools:\n    - server: reference-mcp\n"), 0o644)
			os.WriteFile(filepath.Join(w.repo, ".mcp.json"), []byte(`{"mcpServers":{"reference-mcp":{"type":"http","url":"https://gateway.agentic.internal/mcp/reference-mcp"}}}`), 0o644)
		}, []string{"FAIL    .mcp.json: reference-mcp signs in as no pre-registered client", "fix: agentctl harness setup"}},
		{"an MCP server workload.yaml requires, not in .mcp.json", func(t *testing.T, w *doctorWorld) {
			os.WriteFile(filepath.Join(w.repo, "workload.yaml"), []byte("requires:\n  tools:\n    - server: reference-mcp\n"), 0o644)
		}, []string{"FAIL    .mcp.json: workload.yaml requires reference-mcp", "fix: agentctl harness setup"}},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			w := newDoctorWorld(t)
			c.break_(t, w)
			code, out, _ := w.doctor()
			if code != 1 {
				t.Errorf("code %d, want 1", code)
			}
			for _, want := range c.want {
				if !strings.Contains(out, want) {
					t.Errorf("doctor lacks %q:\n%s", want, out)
				}
			}
		})
	}
}

func TestDoctorOffline(t *testing.T) {
	w := newDoctorWorld(t)
	w.helperFails = true
	code, out, _ := w.doctor("-offline")
	if code != 0 || strings.Contains(out, "credential") || strings.Contains(out, "gateway") || w.gotAuth != "" {
		t.Errorf("offline: code %d:\n%s", code, out)
	}
}
