package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestValidate(t *testing.T) {
	te := newTestEnv(t)
	dir := t.TempDir()
	write := func(name, body string) string {
		p := filepath.Join(dir, name)
		os.WriteFile(p, []byte(body), 0o644)
		return p
	}
	good := write("workload.yaml", "name: notes-agent\nkind: agent\nruntime: kagent\nowner: reference\nsupport: experimental\n")
	bad := write("bad.workload.yaml", "name: notes-kagent-agent\nkind: agent\nruntime: kagent\nowner: reference\nsupport: experimental\nlimits: {tokens: 5}\n")
	other := write("notes.yaml", "kind: skill\n")

	code, out, _ := te.run("validate", good)
	if code != 0 || !strings.Contains(out, "valid workload") || !strings.Contains(out, "devkit/agent-sdk") {
		t.Fatalf("a valid workload.yaml: code %d, %q", code, out)
	}
	code, out, _ = te.run("validate", good, bad)
	if code != 1 || !strings.Contains(out, "bad.workload.yaml: invalid workload") || !strings.Contains(out, "/name") {
		t.Fatalf("an invalid one: code %d, %q", code, out)
	}
	if code, _, errOut := te.run("validate", other); code != 2 || !strings.Contains(errOut, "give -kind") {
		t.Fatalf("an unknown name: code %d, %q", code, errOut)
	}
	if code, out, _ := te.run("validate", "-kind", "artifact", other); code != 1 || !strings.Contains(out, "invalid artifact") {
		t.Fatalf("-kind artifact: code %d, %q", code, out)
	}
	// Without arguments: the files in the working directory.
	t.Chdir(dir)
	if code, out, _ := te.run("validate"); code != 0 || !strings.HasPrefix(out, "workload.yaml: valid") {
		t.Fatalf("no arguments: code %d, %q", code, out)
	}
	t.Chdir(t.TempDir())
	if code, _, _ := te.run("validate"); code != 2 {
		t.Fatalf("nothing to check: code %d", code)
	}
}
