package main

import (
	"crypto/rand"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

func runStep(e *env, args []string) int {
	if len(args) == 0 || args[0] != "run" {
		fmt.Fprintln(e.stderr, "usage: agentctl step run [flags] DEFINITION")
		return 2
	}
	return runStepRun(e, args[1:])
}

// stepCommand is the SDK's step command (spec/step/command.json).
const stepCommand = "agentic-step"

// runStepRun runs one bounded step (design/workflows.md, "A bounded model
// step") with the SDK's step command, as spec/step/command.json describes:
// agentctl finds the command, hands it the definition, input and output
// paths, the gateway's URL, a command for fresh tokens (agentctl token)
// and the task's ID, and passes its exit status through: 0 done, 1 failed
// (stop), 3 stopped by its limits, 4 failed (to a person), 5 invalid.
// agentctl itself exits 2 when it cannot start the command.
func runStepRun(e *env, args []string) int {
	fs := newFlags(e, "step run", "step run -input FILE [flags] (-definition FILE | DEFINITION)")
	definitionFlag := fs.String("definition", "", "the step's definition, or give it as the one argument")
	input := fs.String("input", "", "the step's input, JSON; - reads standard input")
	output := fs.String("output", "step-output.json", "where the step writes its result, JSON")
	workload := fs.String("workload", "", "the workflow's workload.yaml, whose limits bound the step; default ./workload.yaml when there is one")
	command := fs.String("step-command", e.getenv("AGENTCTL_STEP_COMMAND"), "the step command ($AGENTCTL_STEP_COMMAND; default agentic-step on PATH)")
	// What a pipeline's step component exports is kept: its gateway, task,
	// workflow and CA, unless a flag says otherwise.
	gateway := fs.String("gateway", defaults.Get(e.getenv, "AGENTIC_GATEWAY_URL", defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway)), "the gateway's URL ($AGENTIC_GATEWAY_URL, else $AGENTCTL_GATEWAY)")
	caFlag := fs.String("ca-file", e.getenv("AGENTIC_CA_FILE"), "PEM certificates the step trusts for the gateway ($AGENTIC_CA_FILE, else $AGENTCTL_CA_FILE; the local CA for *.agentic.internal)")
	taskID := fs.String("task-id", e.getenv("AGENTIC_TASK_ID"), "the task's ID ($AGENTIC_TASK_ID); default a new one")
	wfName := fs.String("workflow-name", e.getenv("AGENTIC_WORKFLOW_NAME"), "the workflow's name, sent as Agentic-Workflow-Name ($AGENTIC_WORKFLOW_NAME)")
	wfVersion := fs.String("workflow-version", e.getenv("AGENTIC_WORKFLOW_VERSION"), "the workflow's version, sent as Agentic-Workflow-Version ($AGENTIC_WORKFLOW_VERSION)")
	ci := fs.Bool("ci", false, "in a CI job: the step gets its tokens with agentctl token --ci, from the job's GitLab ID token (D27); on whenever $AGENTCTL_ID_TOKEN_FILE is set")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	defArg := *definitionFlag
	switch {
	case fs.NArg() == 0 && defArg != "":
	case fs.NArg() == 1 && (defArg == "" || defArg == fs.Arg(0)):
		defArg = fs.Arg(0)
	default:
		fs.Usage()
		return 2
	}
	if *input == "" {
		fs.Usage()
		return 2
	}
	// A job's ID token in a file is the step component's sign of a CI job:
	// its tokens are then the job's own, never a person's.
	ciMode := *ci || e.getenv("AGENTCTL_ID_TOKEN_FILE") != ""
	s, err := spec.Vendored()
	if err != nil {
		return fail(e, 2, "the spec: %v", err)
	}
	if *taskID == "" {
		*taskID = newUUID()
	}
	if (*wfName == "") != (*wfVersion == "") {
		return fail(e, 2, "-workflow-name and -workflow-version go together ($AGENTIC_WORKFLOW_NAME and $AGENTIC_WORKFLOW_VERSION too)")
	}
	for header, v := range map[string]string{"Agentic-Task-Id": *taskID, "Agentic-Workflow-Name": *wfName, "Agentic-Workflow-Version": *wfVersion} {
		if err := checkHeader(s, header, v); err != nil {
			return fail(e, 2, "%v", err)
		}
	}

	cmd := *command
	if cmd == "" {
		if !e.lookPath(stepCommand) {
			return fail(e, 2, "%s is not on PATH: install the SDK's Python core (agentic-agent-sdk), or give -step-command", stepCommand)
		}
		cmd = stepCommand
	}
	self, err := e.self()
	if err != nil {
		return fail(e, 2, "agentctl's own path: %v", err)
	}

	definition, err := filepath.Abs(defArg)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	if !fileExists(definition) {
		return fail(e, 2, "no definition %s", defArg)
	}
	inPath := *input
	if inPath == "-" {
		f, err := os.CreateTemp("", "agentctl-step-input-*.json")
		if err != nil {
			return fail(e, 2, "%v", err)
		}
		defer os.Remove(f.Name())
		_, err = io.Copy(f, e.stdin)
		if cerr := f.Close(); err == nil {
			err = cerr
		}
		if err != nil {
			return fail(e, 2, "reading the input: %v", err)
		}
		inPath = f.Name()
	}
	inPath, _ = filepath.Abs(inPath)
	if !fileExists(inPath) {
		return fail(e, 2, "no input %s", *input)
	}
	outPath, _ := filepath.Abs(*output)
	argv := []string{"run", "--definition", definition, "--input", inPath, "--output", outPath}
	wl := *workload
	if wl == "" && fileExists("workload.yaml") {
		wl = "workload.yaml"
	}
	if wl != "" {
		abs, _ := filepath.Abs(wl)
		if !fileExists(abs) {
			return fail(e, 2, "no workload file %s", wl)
		}
		argv = append(argv, "--workload", abs)
	}

	tokenArgv := []string{self, "token"}
	if ciMode {
		tokenArgv = append(tokenArgv, "--ci")
	}
	tokenCmd, _ := json.Marshal(tokenArgv)
	add := map[string]string{
		"AGENTIC_GATEWAY_URL":   strings.TrimSuffix(*gateway, "/"),
		"AGENTIC_TOKEN_COMMAND": string(tokenCmd),
		"AGENTIC_TASK_ID":       *taskID,
	}
	if ca := caFileFor(e, *caFlag, *gateway); ca != "" {
		add["AGENTIC_CA_FILE"] = ca
	}
	if *wfName != "" {
		add["AGENTIC_WORKFLOW_NAME"], add["AGENTIC_WORKFLOW_VERSION"] = *wfName, *wfVersion
	}
	childEnv := []string{}
	for _, kv := range e.environ() {
		name, _, _ := strings.Cut(kv, "=")
		// What agentctl sets replaces what it inherited; none of the step's
		// headers leaks in from an earlier run.
		if _, set := add[name]; set || name == "AGENTIC_CA_FILE" || strings.HasPrefix(name, "AGENTIC_WORKFLOW_") {
			continue
		}
		childEnv = append(childEnv, kv)
	}
	for k, v := range add {
		childEnv = append(childEnv, k+"="+v)
	}

	// A result left from an earlier run must not pass for this run's.
	if err := os.Remove(outPath); err != nil && !os.IsNotExist(err) {
		return fail(e, 2, "removing the earlier %s: %v", *output, err)
	}
	fmt.Fprintf(e.stderr, "Running the step %s as task %s\n", filepath.Base(definition), *taskID)
	status, err := e.runner.Run(e.ctx, execx.Cmd{Name: cmd, Args: argv, Env: childEnv, Stdout: e.stdout, Stderr: e.stderr})
	if err != nil {
		return fail(e, 2, "the step command: %v", err)
	}
	report(e, s, status, outPath)
	return status
}

// report checks the object the step wrote on a status that has one, and
// says what it holds.
func report(e *env, s *spec.Spec, status int, outPath string) {
	schema := ""
	switch status {
	case 3:
		schema = spec.LimitErrorSchema
	case 1, 4, 5:
		schema = spec.StepFailure
	default:
		return
	}
	data, err := os.ReadFile(outPath)
	if err != nil {
		fmt.Fprintf(e.stderr, "agentctl: the step exited %d without its result object in %s\n", status, outPath)
		return
	}
	v, err := spec.ParseJSON(data)
	if err == nil {
		var problems []spec.Problem
		problems, err = s.Validate(schema, v)
		if err == nil && len(problems) > 0 {
			err = fmt.Errorf("%v", problems)
		}
	}
	if err != nil {
		fmt.Fprintf(e.stderr, "agentctl: the step exited %d, but %s does not match %s: %v\n", status, outPath, schema, err)
		return
	}
	m := v.(map[string]any)
	if status == 3 {
		fmt.Fprintf(e.stderr, "limit_exceeded: %v cap %v used %v\n", m["limit"], m["cap"], m["used"])
		return
	}
	fmt.Fprintf(e.stderr, "%v: %v\n", m["error"], m["reason"])
}

// checkHeader checks a value against its header's pattern in
// spec/headers/headers.json; an empty value is not sent.
func checkHeader(s *spec.Spec, name, value string) error {
	if value == "" {
		return nil
	}
	data, err := readSpecFile(s, spec.HeadersFile)
	if err != nil {
		return err
	}
	var h struct {
		Headers []struct {
			Name    string `json:"name"`
			Pattern string `json:"pattern"`
		} `json:"headers"`
	}
	if err := json.Unmarshal(data, &h); err != nil {
		return err
	}
	for _, x := range h.Headers {
		if x.Name == name {
			if !regexp.MustCompile(x.Pattern).MatchString(value) {
				return fmt.Errorf("%q is not a valid %s (%s)", value, name, x.Pattern)
			}
			return nil
		}
	}
	return fmt.Errorf("the spec names no header %s", name)
}

func readSpecFile(s *spec.Spec, name string) ([]byte, error) {
	f, err := s.FS.Open(name)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return io.ReadAll(f)
}

// newUUID is a random (version 4) UUID, the new_value of the task header.
func newUUID() string {
	b := make([]byte, 16)
	rand.Read(b)
	b[6] = b[6]&0x0f | 0x40
	b[8] = b[8]&0x3f | 0x80
	return fmt.Sprintf("%x-%x-%x-%x-%x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:])
}
