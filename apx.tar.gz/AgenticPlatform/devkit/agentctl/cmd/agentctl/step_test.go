package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// stepFiles writes a definition and an input in a temporary directory,
// which becomes the working directory.
func stepFiles(t *testing.T, withWorkload bool) string {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, "summarise.step.yaml"), []byte("name: summarise-changes\n"), 0o644)
	os.WriteFile(filepath.Join(dir, "in.json"), []byte(`{"version": "1.0.0", "changes": []}`), 0o644)
	if withWorkload {
		os.WriteFile(filepath.Join(dir, "workload.yaml"), []byte("name: release-notes-workflow\n"), 0o644)
	}
	t.Chdir(dir)
	return dir
}

func envOf(c execx.Cmd) map[string]string {
	m := map[string]string{}
	for _, kv := range c.Env {
		k, v, _ := strings.Cut(kv, "=")
		m[k] = v
	}
	return m
}

func TestStepRunSeam(t *testing.T) {
	dir := stepFiles(t, true)
	te := newTestEnv(t)
	te.vars["UNRELATED"] = "kept"
	te.runner = &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
		os.WriteFile(filepath.Join(dir, "step-output.json"), []byte(`{"title": "t", "summary": "s"}`), 0o644)
		return 0, "", "", nil
	}}
	code, _, errOut := te.runWith(func(e *env) { e.lookPath = func(n string) bool { return n == "agentic-step" } },
		"step", "run", "-input", "in.json", "-gateway", "https://gateway.example.test/", "summarise.step.yaml")
	if code != 0 {
		t.Fatalf("code %d: %s", code, errOut)
	}
	c := te.runner.Calls()[0].Cmd
	want := []string{"run", "--definition", filepath.Join(dir, "summarise.step.yaml"), "--input", filepath.Join(dir, "in.json"),
		"--output", filepath.Join(dir, "step-output.json"), "--workload", filepath.Join(dir, "workload.yaml")}
	if c.Name != "agentic-step" || strings.Join(c.Args, " ") != strings.Join(want, " ") {
		t.Fatalf("ran %s %v", c.Name, c.Args)
	}
	env := envOf(c)
	var tokenCmd []string
	if err := json.Unmarshal([]byte(env["AGENTIC_TOKEN_COMMAND"]), &tokenCmd); err != nil || strings.Join(tokenCmd, " ") != "/opt/agentctl/bin/agentctl token" {
		t.Errorf("AGENTIC_TOKEN_COMMAND %q", env["AGENTIC_TOKEN_COMMAND"])
	}
	if env["AGENTIC_GATEWAY_URL"] != "https://gateway.example.test" {
		t.Errorf("AGENTIC_GATEWAY_URL %q", env["AGENTIC_GATEWAY_URL"])
	}
	if !regexp.MustCompile(`^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$`).MatchString(env["AGENTIC_TASK_ID"]) {
		t.Errorf("AGENTIC_TASK_ID %q", env["AGENTIC_TASK_ID"])
	}
	if _, ok := env["AGENTIC_WORKFLOW_NAME"]; ok || env["UNRELATED"] != "kept" {
		t.Errorf("the environment: %v", env)
	}
	if _, ok := env["AGENTIC_CA_FILE"]; ok {
		t.Errorf("a CA file without one asked for: %v", env)
	}
}

func TestStepRunStatuses(t *testing.T) {
	cases := []struct {
		status int
		output string
		want   string
	}{
		{3, `{"error": "limit_exceeded", "limit": "tokens", "cap": 2000, "used": 2311, "task_id": "t-1"}`, "limit_exceeded: tokens cap 2000 used 2311"},
		{3, `{"error": "limit_exceeded", "limit": "steps", "cap": 1, "used": 1}`, "does not match limits/error.schema.json"},
		{1, `{"error": "step_failed", "reason": "output_invalid", "on_failure": "stop"}`, "step_failed: output_invalid"},
		{4, `{"error": "step_failed", "reason": "model_error", "on_failure": "human"}`, "step_failed: model_error"},
		{5, `{"error": "step_invalid", "reason": "input_invalid"}`, "step_invalid: input_invalid"},
		{5, ``, "without its result object"},
		// An earlier run's result at the path is not this run's.
		{1, ``, "without its result object"},
	}
	for _, c := range cases {
		dir := stepFiles(t, false)
		os.WriteFile(filepath.Join(dir, "out.json"), []byte(`{"error": "step_failed", "reason": "model_error", "on_failure": "stop"}`), 0o644)
		te := newTestEnv(t)
		te.runner = &execx.Fake{Handle: func(execx.Cmd, []byte) (int, string, string, error) {
			if c.output != "" {
				os.WriteFile(filepath.Join(dir, "out.json"), []byte(c.output), 0o644)
			}
			return c.status, "", "", nil
		}}
		code, _, errOut := te.run("step", "run", "-step-command", "/opt/sdk/bin/agentic-step", "-input", "in.json", "-output", "out.json",
			"-workflow-name", "release-notes-workflow", "-workflow-version", "1.2.0", "summarise.step.yaml")
		if code != c.status || !strings.Contains(errOut, c.want) {
			t.Errorf("status %d: code %d, %q; want %q", c.status, code, errOut, c.want)
		}
		call := te.runner.Calls()[0]
		if slicesContains(call.Cmd.Args, "--workload") {
			t.Errorf("a workload file without one here: %v", call.Cmd.Args)
		}
		if env := envOf(call.Cmd); env["AGENTIC_WORKFLOW_NAME"] != "release-notes-workflow" || env["AGENTIC_WORKFLOW_VERSION"] != "1.2.0" {
			t.Errorf("workflow headers: %v", env)
		}
	}
}

func slicesContains(s []string, v string) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}

func TestStepRunRefusals(t *testing.T) {
	stepFiles(t, false)
	te := newTestEnv(t)
	for _, c := range []struct {
		args []string
		want string
	}{
		{[]string{"-input", "in.json", "summarise.step.yaml"}, "not on PATH"},
		{[]string{"-step-command", "/x", "summarise.step.yaml"}, "usage"},
		{[]string{"-step-command", "/x", "-input", "missing.json", "summarise.step.yaml"}, "no input"},
		{[]string{"-step-command", "/x", "-input", "in.json", "missing.step.yaml"}, "no definition"},
		{[]string{"-step-command", "/x", "-input", "in.json", "-task-id", "has space", "summarise.step.yaml"}, "Agentic-Task-Id"},
		{[]string{"-step-command", "/x", "-input", "in.json", "-workflow-name", "Release", "-workflow-version", "1", "summarise.step.yaml"}, "Agentic-Workflow-Name"},
		{[]string{"-step-command", "/x", "-input", "in.json", "-workflow-name", "release-workflow", "summarise.step.yaml"}, "go together"},
		{[]string{"-step-command", "/x", "-input", "in.json", "-workload", "nope.yaml", "summarise.step.yaml"}, "no workload file"},
	} {
		code, _, errOut := te.run(append([]string{"step", "run"}, c.args...)...)
		if code != 2 || !strings.Contains(errOut, c.want) {
			t.Errorf("%v: code %d, %q; want 2 and %q", c.args, code, errOut, c.want)
		}
	}
	if len(te.runner.Calls()) != 0 {
		t.Fatal("the step command ran")
	}
}

// TestStepRunProcess runs a stub of the step command as a real process:
// a shell script that records its arguments and environment, writes the
// limit error to its output and exits 3, as the core does when a step
// passes its token cap. Input comes from standard input.
func TestStepRunProcess(t *testing.T) {
	dir := stepFiles(t, false)
	stub := filepath.Join(dir, "agentic-step")
	os.WriteFile(stub, []byte(`#!/bin/sh
{ echo "args: $*"; echo "AGENTIC_TASK_ID=$AGENTIC_TASK_ID"; } > "$(dirname "$0")/stub.log"
while [ $# -gt 0 ]; do case "$1" in --output) out=$2; shift 2;; --input) in=$2; shift 2;; *) shift;; esac; done
read -r line < "$in"; echo "input: $line" >> "$(dirname "$0")/stub.log"
printf '{"error": "limit_exceeded", "limit": "tokens", "cap": 100, "used": 140, "task_id": "%s"}' "$AGENTIC_TASK_ID" > "$out"
exit 3
`), 0o755)
	te := newTestEnv(t)
	te.stdin = `{"version": "2.0.0", "changes": ["a"]}`
	code, _, errOut := te.runWith(osRunner, "step", "run", "-step-command", stub, "-input", "-", "-task-id", "task-42", "summarise.step.yaml")
	if code != 3 || !strings.Contains(errOut, "limit_exceeded: tokens cap 100 used 140") {
		t.Fatalf("code %d, %q", code, errOut)
	}
	log, _ := os.ReadFile(filepath.Join(dir, "stub.log"))
	for _, want := range []string{"args: run --definition " + filepath.Join(dir, "summarise.step.yaml") + " --input /", "AGENTIC_TASK_ID=task-42", `input: {"version": "2.0.0", "changes": ["a"]}`} {
		if !strings.Contains(string(log), want) {
			t.Errorf("the stub's log lacks %q:\n%s", want, log)
		}
	}
	out, _ := os.ReadFile(filepath.Join(dir, "step-output.json"))
	if !strings.Contains(string(out), `"task_id": "task-42"`) {
		t.Errorf("output %s", out)
	}
}
