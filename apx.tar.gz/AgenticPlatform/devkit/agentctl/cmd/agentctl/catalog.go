package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/catalog"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/gitlab"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/oci"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/s3"
)

// runCatalog dispatches catalog build, publish and drift.
func runCatalog(e *env, args []string) int {
	if len(args) > 0 {
		switch args[0] {
		case "build":
			return runCatalogBuild(e, args[1:])
		case "publish":
			return runCatalogPublish(e, args[1:], false)
		case "drift":
			return runCatalogPublish(e, args[1:], true)
		}
	}
	fmt.Fprintln(e.stderr, "usage: agentctl catalog build|publish|drift [flags]")
	return 2
}

// exitRefused is catalog build's status when it built and published the
// index but left sources out: the pipeline shows it as a warning.
const exitRefused = 3

// runCatalogBuild builds the environment's catalog index from the
// registered projects (D41), in environments' scheduled pipeline: reads
// the registrations from aws-foundation and each registered project's
// files and tags by the job's token, checks owners against
// access/teams.yaml and names for uniqueness, resolves and verifies each
// release's digest, writes catalog.json and a static page, signs the
// index with the record key and puts all three under a new prefix of the
// index bucket.
func runCatalogBuild(e *env, args []string) int {
	fs := newFlags(e, "catalog build", "catalog build [flags]")
	environment := fs.String("environment", defaults.Get(e.getenv, "AGENTCTL_ENVIRONMENT", defaults.Environment), "the environment whose index this is")
	out := fs.String("out", "catalog", "the directory to write catalog.json, its bundle and index.html into")
	regFile := fs.String("registrations", "", "aws-foundation's registrations file, if read from a checkout; default it is read from the project by the job's token")
	foundation := fs.String("foundation", defaults.Get(e.getenv, "AGENTCTL_FOUNDATION_PROJECT", defaults.FoundationProject), "aws-foundation's project, whose registrations/<environment>.yaml names the sources")
	teamsFile := fs.String("teams", "access/teams.yaml", "environments' access/teams.yaml")
	signKey := fs.String("sign-key", "", "the record key to sign the index with, as cosign takes it, such as awskms:///alias/platform/record-signing; none writes an unsigned index and publishes nothing")
	bucket := fs.String("bucket", "", "the index bucket to put the build in, under indexes/<UTC time>/; needs -sign-key")
	noVerify := fs.Bool("no-verify", false, "do not require each release's signature by the release key")
	gitlabURL := fs.String("gitlab", defaults.Get(e.getenv, "CI_SERVER_URL", gitlabBase(e)), "the GitLab instance")
	repo := fs.String("build-repository", e.getenv("CI_PROJECT_URL"), "the building pipeline's repository URL ($CI_PROJECT_URL)")
	commit := fs.String("build-commit", e.getenv("CI_COMMIT_SHA"), "its commit ($CI_COMMIT_SHA)")
	pipeline := fs.String("build-pipeline", e.getenv("CI_PIPELINE_ID"), "its pipeline ID ($CI_PIPELINE_ID)")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	if *bucket != "" && *signKey == "" {
		return fail(e, 2, "-bucket needs -sign-key: the bucket takes signed indexes alone")
	}
	pid, err := strconv.ParseInt(*pipeline, 10, 64)
	if err != nil || pid < 1 || *repo == "" || *commit == "" {
		return fail(e, 2, "the build's provenance: give -build-repository, -build-commit and -build-pipeline, or run in a pipeline that sets CI_PROJECT_URL, CI_COMMIT_SHA and CI_PIPELINE_ID")
	}
	build, _ := json.Marshal(map[string]any{"repository": *repo, "commit": *commit, "pipeline_id": pid})
	c, err := newCatalogEnv(e, *environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	defer c.cleanup()
	gl, err := ciGitLab(e, *gitlabURL)
	if err != nil {
		return fail(e, 2, "%v", err)
	}

	teamsData, err := os.ReadFile(*teamsFile)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	teams, err := catalog.ParseTeams(teamsData)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	var regData []byte
	if *regFile != "" {
		regData, err = os.ReadFile(*regFile)
	} else {
		regData, err = gl.RawFile(e.ctx, *foundation, "registrations/"+*environment+".yaml", "main")
		if gitlab.IsStatus(err, http.StatusNotFound) {
			err = fmt.Errorf("%s has no registrations/%s.yaml the job can read: does its job token allowlist admit this project? (%w)", *foundation, *environment, err)
		}
	}
	if err != nil {
		return fail(e, 1, "the registrations: %v", err)
	}
	regs, err := catalog.ParseRegistrations(regData)
	if err != nil {
		return fail(e, 1, "%v", err)
	}

	host, path, _ := strings.Cut(c.values.Registry, "/")
	b := &catalog.Builder{
		Spec: c.spec, GitLab: gl, Registry: c.values.Registry, Teams: teams,
		Resolve: func(ctx context.Context, repository, tag string) (string, error) {
			return c.oras.Resolve(ctx, host, path+"/"+repository, tag)
		},
		Released: func(ctx context.Context, ref string) ([]byte, error) {
			r, err := oci.ParseReference(ref)
			if err != nil {
				return nil, err
			}
			dir, err := os.MkdirTemp("", "agentctl-release-")
			if err != nil {
				return nil, err
			}
			defer os.RemoveAll(dir)
			if err := c.oras.Unpack(ctx, r, filepath.Join(dir, "a")); err != nil {
				return nil, err
			}
			return catalog.ReleasedArtifactFile(filepath.Join(dir, "a"))
		},
	}
	if !*noVerify {
		key, err := c.key(e, defaults.ReleaseKey)
		if err != nil {
			return fail(e, 2, "%v", err)
		}
		plain := plainHTTP(e, c.values)(host)
		b.Verify = func(ctx context.Context, ref string) error { return c.cosign.VerifyImage(ctx, key, ref, plain) }
	}
	now := time.Now().UTC().Truncate(time.Second)
	ix, refused, err := b.Build(e.ctx, regs, c.values.Name, build, now)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	data, err := catalog.Marshal(c.spec, ix)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if err := os.MkdirAll(*out, 0o755); err != nil {
		return fail(e, 1, "%v", err)
	}
	index := filepath.Join(*out, catalog.IndexFile)
	pages := filepath.Join(*out, catalog.PagesFile)
	if err := os.WriteFile(index, data, 0o644); err != nil {
		return fail(e, 1, "%v", err)
	}
	page, err := renderPages(ix, refused, defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway))
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if err := os.WriteFile(pages, page, 0o644); err != nil {
		return fail(e, 1, "%v", err)
	}
	for _, r := range refused {
		fmt.Fprintf(e.stderr, "agentctl: left out: %s\n", r)
	}
	fmt.Fprintf(e.stdout, "built %s: %d entries from %d workload and %d library projects, %d left out\n", index, len(ix.Entries), len(regs.Workloads), len(regs.Libraries), len(refused))

	if *signKey != "" {
		bundle := filepath.Join(*out, catalog.BundleFile)
		if err := signIndex(e, c, *signKey, index, bundle); err != nil {
			return fail(e, 1, "%v", err)
		}
		fmt.Fprintf(e.stdout, "signed it: %s, verified with %s\n", bundle, c.keyDesc[defaults.RecordKey])
		if *bucket != "" {
			prefix := catalog.IndexesPrefix + now.Format(catalog.StampLayout) + "/"
			for _, f := range []struct{ file, ctype string }{{pages, "text/html"}, {bundle, "application/json"}, {index, "application/json"}} {
				loc := s3.Location{Bucket: *bucket, Key: prefix + filepath.Base(f.file)}
				if err := c.s3.Put(e.ctx, f.file, loc, f.ctype); err != nil {
					return fail(e, 1, "%v", err)
				}
			}
			fmt.Fprintf(e.stdout, "put it in s3://%s/%s\n", *bucket, prefix)
		}
	}
	if len(refused) > 0 {
		return exitRefused
	}
	return 0
}

// signIndex signs the index as a blob with a signing config that names no
// service, then verifies it with the record key consumers verify with,
// so an index signed with any other key is never published.
func signIndex(e *env, c *catalogEnv, key, index, bundle string) error {
	sc := filepath.Join(filepath.Dir(bundle), ".signing-config.json")
	defer os.Remove(sc)
	if err := c.cosign.SigningConfig(e.ctx, sc); err != nil {
		return err
	}
	if err := c.cosign.SignBlob(e.ctx, key, sc, bundle, index); err != nil {
		return err
	}
	record, err := c.key(e, defaults.RecordKey)
	if err != nil {
		return err
	}
	if err := c.cosign.VerifyBlob(e.ctx, record, bundle, index); err != nil {
		os.Remove(bundle)
		return fmt.Errorf("the index signed with %s does not verify with %s, which consumers verify with: %v", key, c.keyDesc[defaults.RecordKey], err)
	}
	return nil
}

// ciGitLab is GitLab with the job's token in a pipeline, else the
// person's.
func ciGitLab(e *env, base string) (*gitlab.Client, error) {
	hc, err := httpClient(e)
	if err != nil {
		return nil, err
	}
	if tok := e.getenv("CI_JOB_TOKEN"); tok != "" {
		return &gitlab.Client{BaseURL: base, Token: tok, JobToken: true, HTTP: hc}, nil
	}
	u, err := url.Parse(base)
	if err != nil {
		return nil, err
	}
	tok, _, err := gitlab.Token(e.getenv, u.Host)
	if err != nil {
		return nil, err
	}
	return &gitlab.Client{BaseURL: base, Token: tok, HTTP: hc}, nil
}

var pagesTemplate = template.Must(template.New("index").Funcs(template.FuncMap{
	"url": catalog.RouteURL,
}).Parse(`<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Catalog: {{.Index.Environment}}</title></head>
<body>
<h1>The {{.Index.Environment}} catalog</h1>
<p>Built {{.Index.Timestamp}}. The signed index, catalog.json, is the source of truth; this page is generated from it.</p>
<table>
<thead><tr><th>Name</th><th>Kind</th><th>Version</th><th>Owner</th><th>Support</th><th>Where</th><th>Reference</th><th>Description</th></tr></thead>
<tbody>
{{- range .Index.Entries}}
<tr><td>{{.Name}}</td><td>{{.Kind}}</td><td>{{.Version}}</td><td>{{.Owner}}</td><td>{{.Support}}</td><td>{{if .Route}}{{url $.Gateway .Route}}{{else}}{{.Tier}}{{end}}</td><td><code>{{.Reference}}</code></td><td>{{.Description}}</td></tr>
{{- end}}
</tbody>
</table>
{{- if .Refused}}
<h2>Left out of this build</h2>
<ul>
{{- range .Refused}}
<li>{{.}}</li>
{{- end}}
</ul>
{{- end}}
</body>
</html>
`))

func renderPages(ix *catalog.Index, refused []catalog.Refusal, gateway string) ([]byte, error) {
	var b bytes.Buffer
	err := pagesTemplate.Execute(&b, map[string]any{"Index": ix, "Refused": refused, "Gateway": gateway})
	return b.Bytes(), err
}
