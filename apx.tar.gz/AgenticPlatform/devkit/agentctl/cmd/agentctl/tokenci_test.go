package main

import (
	"encoding/base64"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth/authtest"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

func ciEnv(t *testing.T) (*testEnv, *authtest.Issuer) {
	is := authtest.New(t)
	is.Federated = map[string]authtest.Federated{"reference-workflow": {
		Assertion: "gitlab-id-token-of-the-job",
		Audiences: map[string]string{"models": is.Gateway + "/v1", "mcp/notes-mcp": "https://gateway.other.test/mcp/notes-mcp"},
	}}
	te := loginEnv(t, is)
	te.vars["AGENTCTL_ID_TOKEN"] = "gitlab-id-token-of-the-job"
	te.vars["AGENTCTL_CI_CLIENT_ID"] = "reference-workflow"
	return te, is
}

func TestTokenCI(t *testing.T) {
	te, is := ciEnv(t)
	code, out, errOut := te.run("token", "--ci", "--scope", "models")
	if code != 0 || strings.Count(out, ".") != 2 || is.ClientCredentials != 1 {
		t.Fatalf("code %d, stdout %q, stderr %q", code, out, errOut)
	}
	c, _ := tokenClaims("Bearer " + strings.TrimSpace(out))
	if c["aud"] != is.Gateway+"/v1" || c["azp"] != "reference-workflow" {
		t.Errorf("claims %v", c)
	}
	// Nothing is kept: no store, no lock.
	if entries, _ := os.ReadDir(te.vars["AGENTCTL_CONFIG_DIR"]); len(entries) != 0 {
		t.Errorf("token --ci wrote %v", entries)
	}
}

func TestTokenCIRefusals(t *testing.T) {
	cases := []struct {
		name   string
		change func(te *testEnv)
		args   []string
		code   int
		want   string
	}{
		{"no ID token", func(te *testEnv) { delete(te.vars, "AGENTCTL_ID_TOKEN") }, nil, 1, "no GitLab ID token in $AGENTCTL_ID_TOKEN"},
		{"no client", func(te *testEnv) { delete(te.vars, "AGENTCTL_CI_CLIENT_ID") }, nil, 2, "-ci needs the workflow's client"},
		{"another job's token", func(te *testEnv) { te.vars["AGENTCTL_ID_TOKEN"] = "a merge request pipeline's token" }, nil, 1, "invalid_client"},
		{"a route the client does not have", nil, []string{"--scope", "a2a/notes-agent"}, 1, "invalid_scope"},
		{"another gateway's audience", nil, []string{"--scope", "mcp/notes-mcp"}, 1, "not printing the token"},
		{"the ID token from another variable", func(te *testEnv) {
			te.vars["KEYCLOAK_ID_TOKEN"] = te.vars["AGENTCTL_ID_TOKEN"]
			delete(te.vars, "AGENTCTL_ID_TOKEN")
		}, []string{"--id-token-var", "KEYCLOAK_ID_TOKEN"}, 0, ""},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			te, _ := ciEnv(t)
			if c.change != nil {
				c.change(te)
			}
			code, out, errOut := te.run(append([]string{"token", "--ci"}, c.args...)...)
			if code != c.code || !strings.Contains(errOut, c.want) {
				t.Errorf("code %d, stderr %q", code, errOut)
			}
			if c.code != 0 && out != "" {
				t.Errorf("printed %q", out)
			}
			noToken(t, c.name, errOut)
		})
	}
}

func TestStepRunCI(t *testing.T) {
	dir := stepFiles(t, true)
	te := newTestEnv(t)
	te.runner = &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
		os.WriteFile(filepath.Join(dir, "step-output.json"), []byte(`{"title": "t", "summary": "s"}`), 0o644)
		return 0, "", "", nil
	}}
	code, _, errOut := te.runWith(func(e *env) { e.lookPath = func(n string) bool { return n == "agentic-step" } },
		"step", "run", "-ci", "-input", "in.json", "-gateway", "https://workloads-gateway.example.test", "summarise.step.yaml")
	if code != 0 {
		t.Fatalf("code %d: %s", code, errOut)
	}
	var tokenCmd []string
	json.Unmarshal([]byte(envOf(te.runner.Calls()[0].Cmd)["AGENTIC_TOKEN_COMMAND"]), &tokenCmd)
	if strings.Join(tokenCmd, " ") != "/opt/agentctl/bin/agentctl token --ci" {
		t.Errorf("AGENTIC_TOKEN_COMMAND %v", tokenCmd)
	}
}

func tokenClaims(h string) (map[string]any, error) {
	tok := strings.TrimPrefix(h, "Bearer ")
	parts := strings.Split(tok, ".")
	if len(parts) != 3 {
		return nil, nil
	}
	b, err := decodeSegment(parts[1])
	if err != nil {
		return nil, err
	}
	var c map[string]any
	return c, json.Unmarshal(b, &c)
}

func decodeSegment(s string) ([]byte, error) { return base64.RawURLEncoding.DecodeString(s) }

// TestStepComponentInvocation runs ci-components' step component's exact
// command line and environment (templates/step/template.yml at ea216ae6,
// 1.1.0's candidate), with a stub agentic-step as a real process: the
// definition as a flag, the job's ID token in AGENTCTL_ID_TOKEN_FILE and
// AGENTCTL_ID_TOKEN unset, the client in AGENTCTL_CLIENT_ID, and the
// step's gateway, task, workflow and CA exported as AGENTIC_*. agentctl
// must keep what the component exported, hand the step agentctl token
// --ci, and that token command must sign the job in by the file.
func TestStepComponentInvocation(t *testing.T) {
	is := authtest.New(t)
	gateway := "https://workloads-gateway.example.test"
	is.Federated = map[string]authtest.Federated{"reference-workflow": {
		Assertion: "the-jobs-gitlab-id-token",
		Audiences: map[string]string{"models": gateway + "/v1"},
	}}
	project := t.TempDir()
	os.MkdirAll(filepath.Join(project, "steps"), 0o755)
	os.WriteFile(filepath.Join(project, "steps", "summarise-changes.step.yaml"), []byte("name: summarise-changes\n"), 0o644)
	os.WriteFile(filepath.Join(project, "steps", "input.json"), []byte(`{"changes": []}`), 0o644)
	os.WriteFile(filepath.Join(project, "workload.yaml"), []byte("name: reference-workflow\n"), 0o644)
	out := filepath.Join(project, "out", "step", "summarise-changes")
	os.MkdirAll(out, 0o755)
	idFile := filepath.Join(t.TempDir(), "id-token")
	os.WriteFile(idFile, []byte("the-jobs-gitlab-id-token"), 0o600)
	stub := filepath.Join(t.TempDir(), "agentic-step")
	os.WriteFile(stub, []byte(`#!/bin/sh
{ echo "args: $*"; env; } > "$(dirname "$0")/stub.log"
while [ $# -gt 0 ]; do case "$1" in --output) o=$2; shift 2;; *) shift;; esac; done
printf '{"title": "t", "summary": "s"}' > "$o"
`), 0o755)

	te := newTestEnv(t)
	for k, v := range map[string]string{
		// The component's exports, as its script sets them.
		"AGENTIC_GATEWAY_URL":      gateway,
		"AGENTIC_TOKEN_COMMAND":    `["agentctl", "token", "--ci"]`,
		"AGENTIC_TASK_ID":          "gitlab-89131953-3086000001",
		"AGENTIC_WORKFLOW_NAME":    "reference-workflow",
		"AGENTIC_WORKFLOW_VERSION": "f388c66c4410addae6d2ed4017e1aa7f211d7bdd",
		"AGENTCTL_CLIENT_ID":       "reference-workflow",
		"AGENTIC_CA_FILE":          is.CAFile,
		"AGENTCTL_ID_TOKEN_FILE":   idFile,
		"CI_PROJECT_DIR":           project,
		// The realm's issuer in the test; the default in a job.
		"AGENTCTL_ISSUER": is.URL,
	} {
		te.vars[k] = v
	}
	code, stdout, errOut := te.runWith(osRunner, "step", "run",
		"--definition", project+"/steps/summarise-changes.step.yaml",
		"--input", project+"/steps/input.json",
		"--output", out+"/output.json",
		"--workload", project+"/workload.yaml",
		"--step-command", stub)
	if code != 0 {
		t.Fatalf("step run: code %d, stdout %q, stderr %q", code, stdout, errOut)
	}
	log, _ := os.ReadFile(filepath.Join(filepath.Dir(stub), "stub.log"))
	got := map[string]string{}
	for _, line := range strings.Split(string(log), "\n") {
		if k, v, ok := strings.Cut(line, "="); ok {
			got[k] = v
		}
	}
	wantArgs := "args: run --definition " + project + "/steps/summarise-changes.step.yaml --input " + project + "/steps/input.json --output " + out + "/output.json --workload " + project + "/workload.yaml"
	if !strings.Contains(string(log), wantArgs) {
		t.Errorf("the step's argv:\n%s\nwant %s", log, wantArgs)
	}
	for k, v := range map[string]string{
		"AGENTIC_GATEWAY_URL": gateway, "AGENTIC_TASK_ID": "gitlab-89131953-3086000001",
		"AGENTIC_WORKFLOW_NAME": "reference-workflow", "AGENTIC_WORKFLOW_VERSION": "f388c66c4410addae6d2ed4017e1aa7f211d7bdd",
		"AGENTIC_CA_FILE": is.CAFile, "AGENTCTL_ID_TOKEN_FILE": idFile, "AGENTCTL_CLIENT_ID": "reference-workflow",
	} {
		if got[k] != v {
			t.Errorf("the step's %s = %q, want %q", k, got[k], v)
		}
	}
	var tokenCmd []string
	if json.Unmarshal([]byte(got["AGENTIC_TOKEN_COMMAND"]), &tokenCmd) != nil || strings.Join(tokenCmd, " ") != "/opt/agentctl/bin/agentctl token --ci" {
		t.Fatalf("AGENTIC_TOKEN_COMMAND %q: not agentctl token --ci", got["AGENTIC_TOKEN_COMMAND"])
	}

	// The step runs its token command with the environment it was given,
	// adding --scope: the job's token for the hosted-workloads gateway's
	// model route, from the file, with no AGENTCTL_GATEWAY or CA of
	// agentctl's own set.
	child := newTestEnv(t)
	for k, v := range got {
		if strings.HasPrefix(k, "AGENTIC_") || strings.HasPrefix(k, "AGENTCTL_") {
			child.vars[k] = v
		}
	}
	code, stdout, errOut = child.run(append(tokenCmd[1:], "--scope", "models")...)
	if code != 0 {
		t.Fatalf("the token command: code %d, stderr %q", code, errOut)
	}
	c, _ := tokenClaims("Bearer " + strings.TrimSpace(stdout))
	if c["aud"] != gateway+"/v1" || c["azp"] != "reference-workflow" || is.ClientCredentials != 1 {
		t.Errorf("the job's token: claims %v, %d grants", c, is.ClientCredentials)
	}

	// The positional definition still works, and both forms at once
	// must agree.
	if code, _, errOut := te.runWith(osRunner, "step", "run", "--input", project+"/steps/input.json", "--output", out+"/output.json", "--step-command", stub, project+"/steps/summarise-changes.step.yaml"); code != 0 {
		t.Errorf("positional: code %d, stderr %q", code, errOut)
	}
	if code, _, _ := te.runWith(osRunner, "step", "run", "--definition", project+"/steps/summarise-changes.step.yaml", "--input", project+"/steps/input.json", "--step-command", stub, project+"/workload.yaml"); code != 2 {
		t.Errorf("two different definitions: code %d", code)
	}
	// Without the file or -ci, a person's token command.
	delete(te.vars, "AGENTCTL_ID_TOKEN_FILE")
	te.runWith(osRunner, "step", "run", "--definition", project+"/steps/summarise-changes.step.yaml", "--input", project+"/steps/input.json", "--output", out+"/output.json", "--step-command", stub)
	log, _ = os.ReadFile(filepath.Join(filepath.Dir(stub), "stub.log"))
	if !strings.Contains(string(log), `AGENTIC_TOKEN_COMMAND=["/opt/agentctl/bin/agentctl","token"]`) {
		t.Errorf("outside CI the token command is the person's: %s", log)
	}
}

// TestTokenCIRealmScopePrefix: in CI mode the realm is asked for the
// route scope under AGENTCTL_REALM_SCOPE_PREFIX, since scope names are
// realm-wide and the realm's models scope is the developer gateway's;
// the route, and the one audience the token must carry, stay the
// route's on the gateway the step names.
func TestTokenCIRealmScopePrefix(t *testing.T) {
	gateway := "https://workloads-gateway.example.test"
	setup := func(t *testing.T, scopes map[string]string) (*testEnv, *authtest.Issuer) {
		is := authtest.New(t)
		is.Federated = map[string]authtest.Federated{"reference-workflow": {Assertion: "the-jobs-gitlab-id-token", Audiences: scopes}}
		te := newTestEnv(t)
		for k, v := range map[string]string{
			"AGENTCTL_ISSUER": is.URL, "AGENTIC_CA_FILE": is.CAFile, "AGENTIC_GATEWAY_URL": gateway,
			"AGENTCTL_CLIENT_ID": "reference-workflow", "AGENTCTL_ID_TOKEN": "the-jobs-gitlab-id-token",
		} {
			te.vars[k] = v
		}
		return te, is
	}

	t.Run("the prefixed scope is sent", func(t *testing.T) {
		// The realm's models scope is the developer gateway's; its
		// workloads-models scope the hosted-workloads deployment's.
		te, is := setup(t, map[string]string{"models": "https://gateway.example.test/v1", "workloads-models": gateway + "/v1"})
		te.vars["AGENTCTL_REALM_SCOPE_PREFIX"] = "workloads-"
		code, out, errOut := te.run("token", "--ci", "--scope", "models")
		if code != 0 {
			t.Fatalf("code %d, stderr %q", code, errOut)
		}
		c, _ := tokenClaims("Bearer " + strings.TrimSpace(out))
		if c["scope"] != "workloads-models" || c["aud"] != gateway+"/v1" || is.ClientCredentials != 1 {
			t.Errorf("claims %v", c)
		}
	})

	t.Run("an unset prefix asks for the route scope", func(t *testing.T) {
		te, _ := setup(t, map[string]string{"models": gateway + "/v1"})
		code, out, errOut := te.run("token", "--ci", "--scope", "models")
		if c, _ := tokenClaims("Bearer " + strings.TrimSpace(out)); code != 0 || c["scope"] != "models" {
			t.Errorf("code %d, claims %v, stderr %q", code, c, errOut)
		}
	})

	t.Run("the audience check still holds", func(t *testing.T) {
		// A realm whose prefixed scope gives the developer gateway's
		// audience: the token is not for the step's gateway.
		te, _ := setup(t, map[string]string{"workloads-models": "https://gateway.example.test/v1"})
		te.vars["AGENTCTL_REALM_SCOPE_PREFIX"] = "workloads-"
		code, out, errOut := te.run("token", "--ci", "--scope", "models")
		if code != 1 || out != "" || !strings.Contains(errOut, "not printing the token") {
			t.Errorf("code %d, stdout %q, stderr %q", code, out, errOut)
		}
		noToken(t, "a wrong audience", errOut)
	})

	t.Run("the realm's invalid_scope", func(t *testing.T) {
		te, _ := setup(t, map[string]string{"models": "https://gateway.example.test/v1"})
		te.vars["AGENTCTL_REALM_SCOPE_PREFIX"] = "workloads-"
		code, out, errOut := te.run("token", "--ci", "--scope", "models")
		if code != 1 || out != "" || !strings.Contains(errOut, `the realm refused the scope "workloads-models" for the client reference-workflow (the route models, AGENTCTL_REALM_SCOPE_PREFIX "workloads-")`) || !strings.Contains(errOut, "invalid_scope") {
			t.Errorf("code %d, stdout %q, stderr %q", code, out, errOut)
		}
		noToken(t, "invalid_scope", errOut)
	})

	t.Run("a prefix that is not a scope name's", func(t *testing.T) {
		te, is := setup(t, map[string]string{"models": gateway + "/v1"})
		te.vars["AGENTCTL_REALM_SCOPE_PREFIX"] = "workloads models "
		if code, _, errOut := te.run("token", "--ci", "--scope", "models"); code != 2 || is.ClientCredentials != 0 || !strings.Contains(errOut, "AGENTCTL_REALM_SCOPE_PREFIX") {
			t.Errorf("code %d, %d grants, stderr %q", code, is.ClientCredentials, errOut)
		}
	})

	t.Run("a person's token ignores the prefix", func(t *testing.T) {
		is := authtest.New(t)
		is.AutoApprove = true
		te := loginEnv(t, is)
		te.vars["AGENTCTL_REALM_SCOPE_PREFIX"] = "workloads-"
		if code, _, errOut := te.run("login", "-flow", "device"); code != 0 {
			t.Fatalf("login: %d %s", code, errOut)
		}
		if code, _, errOut := te.run("token", "--scope", "models"); code != 0 || is.LastRefreshScope != "openid models" {
			t.Errorf("code %d, refresh scope %q, stderr %q", code, is.LastRefreshScope, errOut)
		}
	})
}
