package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strconv"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/catalog"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/validate"
)

// Claude Code's settings that harness setup writes and doctor checks
// (design/harnesses.md, "Making it work through the gateway"; the B6 desk
// check's "Claude Code through the gateway").
const (
	// managedDropIn is harness setup's file in managed-settings.d/, which
	// Claude Code merges after managed-settings.json, in name order, so a
	// machine's own policy file is never overwritten.
	managedDropIn = "50-agentic-platform.json"
	// helperTTL is how long Claude Code keeps the helper's token, in
	// milliseconds: under the 300 seconds a route token lives.
	helperTTL = 240000
	// claudeFloor is the oldest Claude Code whose managed allowedProviders
	// holds; claudePin the version Versions pins.
	claudeFloor = "2.1.285"
	claudePin   = "2.1.311"
	mcpFile     = ".mcp.json"
	// mcpClient is the realm's pre-registered public client for Claude
	// Code's MCP sign-ins (T6): without it Claude Code tries dynamic
	// registration, which the realm refuses. Its redirect admits any
	// loopback port; mcpCallbackPort is the one T6 used.
	mcpClient       = "claude-code"
	mcpCallbackPort = 33418
)

// mcpEntry is .mcp.json's entry for a platform MCP server: its route on
// the developer gateway, signed in through the realm as the claude-code
// client for that route's scope alone, with the realm's own metadata,
// as T6 proved it.
func mcpEntry(gateway, issuer, route string) map[string]any {
	_, scope, _ := strings.Cut(route, "/")
	return map[string]any{
		"type": "http",
		"url":  catalog.RouteURL(gateway, route),
		"oauth": map[string]any{
			"clientId":              mcpClient,
			"callbackPort":          mcpCallbackPort,
			"scopes":                scope,
			"authServerMetadataUrl": strings.TrimSuffix(issuer, "/") + "/.well-known/openid-configuration",
		},
	}
}

// runHarness dispatches harness setup.
func runHarness(e *env, args []string) int {
	if len(args) == 0 || args[0] != "setup" {
		fmt.Fprintln(e.stderr, "usage: agentctl harness setup [flags]")
		return 2
	}
	return runHarnessSetup(e, args[1:])
}

// claudeManagedDir is Claude Code's system directory for managed
// settings: AGENTCTL_CLAUDE_MANAGED_DIR, else the operating system's.
func claudeManagedDir(e *env) string {
	if d := e.getenv("AGENTCTL_CLAUDE_MANAGED_DIR"); d != "" {
		return d
	}
	if e.goos == "darwin" {
		return "/Library/Application Support/ClaudeCode"
	}
	return "/etc/claude-code"
}

// harnessValues are what the managed settings say.
type harnessValues struct {
	gateway, helper, caFile string
	otelEndpoint, otelProto string
	team                    string
	env                     defaults.Env
}

// managedSettings is harness setup's drop-in: the gateway as the one
// provider, agentctl as the credential helper, the gateway's aliases, the
// route's window, nothing sent around the gateway, the local CA, and
// telemetry to the collector with prompts redacted (OTEL_LOG_USER_PROMPTS
// is never set).
func managedSettings(v harnessValues) map[string]any {
	env := map[string]any{
		"ANTHROPIC_BASE_URL":                       v.gateway,
		"CLAUDE_CODE_API_KEY_HELPER_TTL_MS":        strconv.Itoa(helperTTL),
		"ANTHROPIC_MODEL":                          v.env.MainModel,
		"ANTHROPIC_DEFAULT_OPUS_MODEL":             v.env.MainModel,
		"ANTHROPIC_DEFAULT_SONNET_MODEL":           v.env.MainModel,
		"ANTHROPIC_DEFAULT_HAIKU_MODEL":            v.env.FastModel,
		"CLAUDE_CODE_AUTO_COMPACT_WINDOW":          strconv.Itoa(v.env.ContextWindow),
		"CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
	}
	if v.caFile != "" {
		env["NODE_EXTRA_CA_CERTS"] = v.caFile
	}
	if v.otelEndpoint != "" {
		env["CLAUDE_CODE_ENABLE_TELEMETRY"] = "1"
		env["OTEL_METRICS_EXPORTER"] = "otlp"
		env["OTEL_LOGS_EXPORTER"] = "otlp"
		env["OTEL_EXPORTER_OTLP_PROTOCOL"] = v.otelProto
		env["OTEL_EXPORTER_OTLP_ENDPOINT"] = v.otelEndpoint
		if v.team != "" {
			env["OTEL_RESOURCE_ATTRIBUTES"] = "team=" + v.team
		}
	}
	return map[string]any{
		"apiKeyHelper":          v.helper,
		"allowedProviders":      []any{"customEndpoint"},
		"skipWebFetchPreflight": true,
		"env":                   env,
	}
}

// shellQuote quotes a path for /bin/sh, which runs the helper.
func shellQuote(s string) string {
	if s != "" && strings.Trim(s, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/._-") == "" {
		return s
	}
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func defaultHelper(e *env) string {
	self, err := e.self()
	if err != nil || self == "" {
		self = "agentctl"
	}
	return shellQuote(self) + " token --scope " + defaults.RouteScope
}

// commonHarness are setup's and doctor's shared flags.
type commonHarness struct {
	harness, gateway, caFile, managedDir, dir *string
	cf                                        catalogFlags
}

func addCommonHarness(e *env, fs *flag.FlagSet) commonHarness {
	return commonHarness{
		harness:    fs.String("harness", "claude-code", "the harness: claude-code; Codex is not supported yet"),
		gateway:    fs.String("gateway", defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway), "the developer gateway's URL ($AGENTCTL_GATEWAY)"),
		caFile:     fs.String("ca-file", "", "a PEM file of CA certificates Claude Code trusts besides its own ($AGENTCTL_CA_FILE; the local CA for *.agentic.internal)"),
		managedDir: fs.String("managed-dir", claudeManagedDir(e), "Claude Code's managed settings directory ($AGENTCTL_CLAUDE_MANAGED_DIR)"),
		dir:        fs.String("dir", ".", "the repository's root, for its skills' links and .mcp.json"),
		cf:         addCatalogFlags(e, fs),
	}
}

func (h commonHarness) check(e *env) bool {
	if *h.harness != "claude-code" {
		fmt.Fprintf(e.stderr, "agentctl: -harness %q: only claude-code is supported; Codex needs a team to maintain its configuration first (design/harnesses.md)\n", *h.harness)
		return false
	}
	return true
}

// runHarnessSetup writes Claude Code's managed settings, links the
// repository's skills, and writes its .mcp.json from one source.
func runHarnessSetup(e *env, args []string) int {
	fs := newFlags(e, "harness setup", "harness setup [flags]")
	h := addCommonHarness(e, fs)
	otel := fs.String("otel-endpoint", "", "the collector's OTLP endpoint for workstations; without it no telemetry is set, and none exists yet")
	proto := fs.String("otel-protocol", "http/protobuf", "the OTLP protocol: grpc or http/protobuf")
	team := fs.String("team", "", "the person's team, as telemetry's team attribute")
	helper := fs.String("api-key-helper", defaultHelper(e), "the command Claude Code runs for its credential")
	issuer := fs.String("issuer", defaults.Get(e.getenv, "AGENTCTL_ISSUER", defaults.Issuer), "the realm's issuer, through which Claude Code signs in to MCP servers ($AGENTCTL_ISSUER)")
	skip := fs.Bool("skip-managed", false, "write only the repository's links and .mcp.json, not the managed settings")
	var mcp listFlag
	fs.Var(&mcp, "mcp", "an MCP server from the catalog index to add to .mcp.json, besides those workload.yaml requires; repeat for more")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	if !h.check(e) {
		return 2
	}
	values, err := defaults.ForEnvironment(*h.cf.environment)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	if *proto != "grpc" && *proto != "http/protobuf" {
		return fail(e, 2, "-otel-protocol %q: use grpc or http/protobuf", *proto)
	}
	ca := caFileFor(e, *h.caFile, *h.gateway)
	if ca != "" {
		if abs, err := filepath.Abs(ca); err == nil {
			ca = abs
		}
	}

	if !*skip {
		v := harnessValues{gateway: strings.TrimSuffix(*h.gateway, "/"), helper: *helper, caFile: ca, otelEndpoint: *otel, otelProto: *proto, team: *team, env: values}
		p := filepath.Join(*h.managedDir, "managed-settings.d", managedDropIn)
		if err := writeJSON(p, managedSettings(v), 0o644); err != nil {
			if errors.Is(err, os.ErrPermission) {
				return fail(e, 1, "cannot write %s: managed settings are machine-wide; run it as root (sudo), or give -managed-dir", p)
			}
			return fail(e, 1, "%v", err)
		}
		fmt.Fprintf(e.stdout, "wrote Claude Code's managed settings: %s\n", p)
		if *otel == "" {
			fmt.Fprintln(e.stderr, "agentctl: warning: no -otel-endpoint, so Claude Code sends no telemetry: the platform has no collector endpoint for workstations yet")
		}
	}

	root, err := filepath.Abs(*h.dir)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	code := 0
	linked, problems := linkSkills(root)
	for _, l := range linked {
		fmt.Fprintf(e.stdout, "linked %s to %s\n", l, ".agents/skills/"+filepath.Base(l))
	}
	for _, p := range problems {
		fmt.Fprintln(e.stderr, "agentctl: "+p)
		code = 1
	}
	for _, n := range []string{"CLAUDE.md", "CLAUDE.local.md", ".claude/CLAUDE.md"} {
		if fileExists(filepath.Join(root, n)) {
			fmt.Fprintf(e.stderr, "agentctl: warning: %s stops Claude Code reading AGENTS.md here; AGENTS.md is the instructions file (design/harnesses.md)\n", n)
		}
	}

	servers, err := requiredServers(root, mcp)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if len(servers) > 0 {
		c, err := newCatalogEnv(e, *h.cf.environment)
		if err != nil {
			return fail(e, 2, "%v", err)
		}
		defer c.cleanup()
		ix, err := c.readIndex(e, h.cf)
		if err != nil {
			return fail(e, 1, "%v", err)
		}
		entries := map[string]any{}
		for _, name := range servers {
			en := ix.Find(name)
			if en == nil || en.Kind() != "mcp-server" || en.Route == "" {
				fmt.Fprintf(e.stderr, "agentctl: %s is not an MCP server in the index %s, so .mcp.json leaves it out\n", name, ix.From)
				code = 1
				continue
			}
			entries[name] = mcpEntry(*h.gateway, *issuer, en.Route)
		}
		if err := mergeMCP(filepath.Join(root, mcpFile), entries); err != nil {
			return fail(e, 1, "%v", err)
		}
		names := make([]string, 0, len(entries))
		for n := range entries {
			names = append(names, n)
		}
		sort.Strings(names)
		fmt.Fprintf(e.stdout, "wrote %s: %s, through the gateway's routes\n", mcpFile, strings.Join(names, ", "))
	}
	return code
}

// linkSkills links every skill under .agents/skills, the repository's one
// copy, into Claude Code's .claude/skills; Codex reads .agents/skills
// itself. Something there that is not the link is left and reported.
func linkSkills(root string) (linked, problems []string) {
	dirs, _ := filepath.Glob(filepath.Join(root, ".agents", "skills", "*", "SKILL.md"))
	sort.Strings(dirs)
	for _, skillMD := range dirs {
		name := filepath.Base(filepath.Dir(skillMD))
		if strings.HasPrefix(name, ".") {
			continue
		}
		linkPath, canonical := ".claude/skills/"+name, ".agents/skills/"+name
		p := filepath.Join(root, filepath.FromSlash(linkPath))
		want := target(linkPath, canonical)
		if got, err := os.Readlink(p); err == nil && got == want {
			continue
		}
		if _, err := os.Lstat(p); err == nil {
			problems = append(problems, fmt.Sprintf("%s is there and is not the link to %s, so it stays: move it away and run agentctl harness setup again", linkPath, canonical))
			continue
		}
		if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
			problems = append(problems, err.Error())
			continue
		}
		if err := os.Symlink(want, p); err != nil {
			problems = append(problems, err.Error())
			continue
		}
		linked = append(linked, linkPath)
	}
	return linked, problems
}

// requiredServers is .mcp.json's one source: the MCP servers the
// repository's workload.yaml requires, and those named with -mcp.
func requiredServers(root string, extra []string) ([]string, error) {
	names := append([]string{}, extra...)
	data, err := os.ReadFile(filepath.Join(root, "workload.yaml"))
	if err == nil {
		v, err := validate.Decode(data)
		if err != nil {
			return nil, fmt.Errorf("workload.yaml: %w", err)
		}
		m, _ := v.(map[string]any)
		req, _ := m["requires"].(map[string]any)
		tools, _ := req["tools"].([]any)
		for _, t := range tools {
			tm, _ := t.(map[string]any)
			if s, _ := tm["server"].(string); s != "" {
				names = append(names, s)
			}
		}
	} else if !errors.Is(err, fs.ErrNotExist) {
		return nil, err
	}
	sort.Strings(names)
	return slices.Compact(names), nil
}

// mergeMCP writes servers into .mcp.json, keeping every other server
// there as it is.
func mergeMCP(path string, servers map[string]any) error {
	doc := map[string]any{}
	if data, err := os.ReadFile(path); err == nil {
		if err := json.Unmarshal(data, &doc); err != nil {
			return fmt.Errorf("%s: %w; not changing it", path, err)
		}
	} else if !errors.Is(err, fs.ErrNotExist) {
		return err
	}
	have, _ := doc["mcpServers"].(map[string]any)
	if have == nil {
		have = map[string]any{}
	}
	for k, v := range servers {
		have[k] = v
	}
	doc["mcpServers"] = have
	return writeJSON(path, doc, 0o644)
}

// writeJSON writes a JSON document to a new file renamed over the old.
func writeJSON(path string, v any, mode os.FileMode) error {
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), "."+filepath.Base(path)+"-")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.Write(append(b, '\n')); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Chmod(mode); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmp.Name(), path)
}
