package main

import (
	"errors"
	"fmt"
	"os"
	"regexp"
	"slices"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/store"
)

// runToken prints an access token for one route, for Claude Code's
// apiKeyHelper and the step command's AGENTIC_TOKEN_COMMAND. It refreshes
// with exactly that route's scope, keeps the rotated refresh token before
// printing anything, and holds the lock throughout, since a refresh token
// used twice ends the session (T20).
func runToken(e *env, args []string) int {
	fs := newFlags(e, "token", "token [--scope SCOPE]")
	scope := fs.String("scope", defaults.RouteScope, "the route scope: models, mcp/<name> or a2a/<name>")
	ci := fs.Bool("ci", false, "sign in by the CI job's GitLab ID token, as the workflow's own client (D27), not by a person's sign-in")
	clientID := fs.String("client-id", defaults.Get(e.getenv, "AGENTCTL_CI_CLIENT_ID", e.getenv("AGENTCTL_CLIENT_ID")), "with -ci: the realm's client for this workflow ($AGENTCTL_CI_CLIENT_ID, else $AGENTCTL_CLIENT_ID, as the step component exports it)")
	idTokenVar := fs.String("id-token-var", defaults.Get(e.getenv, "AGENTCTL_ID_TOKEN_VAR", "AGENTCTL_ID_TOKEN"), "with -ci: the variable the job's id_tokens names for its GitLab ID token")
	idTokenFile := fs.String("id-token-file", e.getenv("AGENTCTL_ID_TOKEN_FILE"), "with -ci: a file holding the job's GitLab ID token, when the variable is unset ($AGENTCTL_ID_TOKEN_FILE, as the step component writes it)")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	if err := auth.CheckRouteScope(*scope); err != nil {
		return fail(e, 2, "%v", err)
	}
	if *ci {
		return runTokenCI(e, *scope, *clientID, *idTokenVar, *idTokenFile)
	}
	st, dir, err := tokenStore(e)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	unlock, err := store.Lock(dir)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	defer unlock()

	rec, err := st.Load()
	if errors.Is(err, store.ErrNotFound) {
		return fail(e, 1, "not signed in: run agentctl login")
	}
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if err := rec.Valid(); err != nil {
		return fail(e, 1, "%v: run agentctl login", err)
	}
	if !slices.Contains(rec.Scopes, *scope) {
		return fail(e, 1, "the sign-in was not granted %s, and a refresh can only narrow (granted: %s): run agentctl login --scope %s, with every other route scope you need",
			*scope, strings.Join(rec.Scopes, ", "), *scope)
	}
	c, err := authClient(e, rec.Issuer, rec.ClientID, rec.CAFile)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	m, err := c.Discover(e.ctx)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	t, err := c.Refresh(e.ctx, m, rec.RefreshToken, *scope)
	if auth.IsSessionEnded(err) {
		return fail(e, 1, "the session has ended (%v): run agentctl login", err)
	}
	if err != nil {
		return fail(e, 1, "refresh: %v", err)
	}
	// The refresh token sent is spent: keep the new one before anything
	// else can fail.
	rec.RefreshToken = t.RefreshToken
	rec.Saved = time.Now().UTC()
	if t.RefreshExpiresIn > 0 {
		rec.RefreshExpires = rec.Saved.Add(time.Duration(t.RefreshExpiresIn) * time.Second)
	}
	if err := st.Save(rec); err != nil {
		return fail(e, 1, "the refresh token was rotated but could not be kept, so the sign-in is lost: %v; run agentctl login", err)
	}
	gateway := rec.Gateway
	if gateway == "" {
		gateway = defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway)
	}
	if err := auth.CheckAudience(t.AccessToken, gateway, *scope); err != nil {
		return fail(e, 1, "not printing the token: %v", err)
	}
	fmt.Fprintln(e.stdout, t.AccessToken)
	return 0
}

var realmScopePrefix = regexp.MustCompile(`^[a-z0-9][a-z0-9-]*$`)

// runTokenCI prints an access token for one route for a CI job: the
// client-credentials grant of the workflow's own client, authenticated by
// the job's GitLab ID token, which the realm's gitlab provider checks on
// its issuer, key set and sub, the project and protected ref (D27). It
// keeps nothing: each call is a new grant, and the ID token lives as long
// as the job.
func runTokenCI(e *env, scope, clientID, idTokenVar, idTokenFile string) int {
	if clientID == "" {
		return fail(e, 2, "-ci needs the workflow's client: -client-id, AGENTCTL_CI_CLIENT_ID or AGENTCTL_CLIENT_ID")
	}
	idToken := strings.TrimSpace(e.getenv(idTokenVar))
	if idToken == "" && idTokenFile != "" {
		b, err := os.ReadFile(idTokenFile)
		if err != nil {
			return fail(e, 1, "the job's ID token: %v", err)
		}
		idToken = strings.TrimSpace(string(b))
	}
	if idToken == "" {
		return fail(e, 1, "no GitLab ID token in $%s or $AGENTCTL_ID_TOKEN_FILE: give the job id_tokens: {%s: {aud: <the realm's issuer>}}", idTokenVar, idTokenVar)
	}
	// Scope names are realm-wide, and the realm's models scope gives the
	// developer gateway's audience: a route on the hosted-workloads
	// deployment has a realm scope of its own, the route scope under the
	// prefix AGENTCTL_REALM_SCOPE_PREFIX names (workloads- locally). The
	// route, and the audience the token must carry, stay the route's.
	prefix := e.getenv("AGENTCTL_REALM_SCOPE_PREFIX")
	if prefix != "" && !realmScopePrefix.MatchString(prefix) {
		return fail(e, 2, "AGENTCTL_REALM_SCOPE_PREFIX %q is not lowercase letters, digits and hyphens", prefix)
	}
	realmScope := prefix + scope
	issuer := strings.TrimSuffix(defaults.Get(e.getenv, "AGENTCTL_ISSUER", defaults.Issuer), "/")
	ca := caFileFor(e, "", issuer)
	if ca == "" {
		// The CA a step component hands the step, which the realm's
		// certificate chains to as the gateway's does locally.
		ca = e.getenv("AGENTIC_CA_FILE")
	}
	c, err := authClient(e, issuer, clientID, ca)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if e.httpClient != nil {
		c.HTTP = e.httpClient
	}
	m, err := c.Discover(e.ctx)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	t, err := c.ClientCredentials(e.ctx, m, idToken, realmScope)
	var oe *auth.OAuthError
	if errors.As(err, &oe) && oe.Code == "invalid_scope" {
		return fail(e, 1, "the realm refused the scope %q for the client %s (the route %s, AGENTCTL_REALM_SCOPE_PREFIX %q): the realm has no such scope, or the client may not ask for it: %v", realmScope, clientID, scope, prefix, err)
	}
	if err != nil {
		return fail(e, 1, "signing in as %s by the job's ID token: %v", clientID, err)
	}
	// A step's token command runs with the step's gateway in
	// AGENTIC_GATEWAY_URL, the hosted-workloads deployment's in a job.
	gateway := defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Get(e.getenv, "AGENTIC_GATEWAY_URL", defaults.Gateway))
	if err := auth.CheckAudience(t.AccessToken, gateway, scope); err != nil {
		return fail(e, 1, "not printing the token: %v", err)
	}
	fmt.Fprintln(e.stdout, t.AccessToken)
	return 0
}
