package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/url"
	"os"
	"slices"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/store"
)

// listFlag is a flag that may be given more than once.
type listFlag []string

func (l *listFlag) String() string     { return strings.Join(*l, ",") }
func (l *listFlag) Set(v string) error { *l = append(*l, v); return nil }

func newFlags(e *env, name, usage string) *flag.FlagSet {
	fs := flag.NewFlagSet(name, flag.ContinueOnError)
	fs.SetOutput(e.stderr)
	fs.Usage = func() {
		fmt.Fprintf(e.stderr, "usage: agentctl %s\n\nFlags:\n", usage)
		fs.PrintDefaults()
	}
	return fs
}

// parse parses flags; it returns false and the exit code when it should
// stop: 0 after -h, 2 on a bad flag.
func parse(fs *flag.FlagSet, args []string) (int, bool) {
	err := fs.Parse(args)
	if errors.Is(err, flag.ErrHelp) {
		return 0, false
	}
	if err != nil {
		return 2, false
	}
	return 0, true
}

func fail(e *env, code int, format string, a ...any) int {
	fmt.Fprintf(e.stderr, "agentctl: "+format+"\n", a...)
	return code
}

// tokenStore opens the store the sign-in is kept in.
func tokenStore(e *env) (store.Store, string, error) {
	dir, err := defaults.ConfigDir(e.getenv)
	if err != nil {
		return nil, "", err
	}
	s, err := store.Select(store.Choice{
		Dir: dir, Mode: e.getenv("AGENTCTL_TOKEN_STORE"), GOOS: e.goos,
		Getenv: e.getenv, LookPath: e.lookPath, Runner: e.runner,
	})
	return s, dir, err
}

// caFileFor picks the CA file: the flag, AGENTCTL_CA_FILE, or, for the
// local build's issuer under agentic.internal, the local CA where the
// bootstrap wrote it.
func caFileFor(e *env, flagValue, issuer string) string {
	if flagValue != "" {
		return flagValue
	}
	if v := e.getenv("AGENTCTL_CA_FILE"); v != "" {
		return v
	}
	if u, err := url.Parse(issuer); err == nil && strings.HasSuffix(u.Hostname(), ".agentic.internal") {
		if home := e.getenv("HOME"); home != "" {
			if f := defaults.LocalCAFile(home); fileExists(f) {
				return f
			}
		}
	}
	return ""
}

func fileExists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

func authClient(e *env, issuer, clientID, caFile string) (*auth.Client, error) {
	hc, err := auth.HTTPClient(caFile, "agentctl/"+version)
	if err != nil {
		return nil, err
	}
	return &auth.Client{Issuer: issuer, ClientID: clientID, HTTP: hc}, nil
}

func runLogin(e *env, args []string) int {
	fs := newFlags(e, "login", "login [flags]")
	issuer := fs.String("issuer", defaults.Get(e.getenv, "AGENTCTL_ISSUER", defaults.Issuer), "the realm's issuer URL ($AGENTCTL_ISSUER)")
	clientID := fs.String("client-id", defaults.Get(e.getenv, "AGENTCTL_CLIENT_ID", defaults.ClientID), "the realm's client ($AGENTCTL_CLIENT_ID)")
	gateway := fs.String("gateway", defaults.Get(e.getenv, "AGENTCTL_GATEWAY", defaults.Gateway), "the developer gateway's URL, which route tokens' audiences name ($AGENTCTL_GATEWAY)")
	caFlag := fs.String("ca-file", "", "a PEM file of CA certificates to trust besides the system's ($AGENTCTL_CA_FILE; the local CA for *.agentic.internal)")
	flow := fs.String("flow", "auto", "device, loopback, or auto: loopback where a browser can open on this machine, else device")
	noBrowser := fs.Bool("no-browser", false, "print the URL and do not try to open a browser")
	timeout := fs.Duration("timeout", 10*time.Minute, "how long to wait for the sign-in")
	var scopes listFlag
	fs.Var(&scopes, "scope", "a route scope to be able to get tokens for: models, mcp/<name> or a2a/<name>; repeat for more (default models)")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	if len(scopes) == 0 {
		scopes = listFlag{defaults.RouteScope}
	}
	for _, s := range scopes {
		if err := auth.CheckRouteScope(s); err != nil {
			return fail(e, 2, "%v", err)
		}
	}
	slices.Sort(scopes)
	scopes = slices.Compact(scopes)
	switch *flow {
	case "auto":
		*flow = "device"
		if !*noBrowser && canOpenBrowser(e) {
			*flow = "loopback"
		}
	case "device", "loopback":
	default:
		return fail(e, 2, "-flow %q: use device, loopback or auto", *flow)
	}

	st, dir, err := tokenStore(e)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	caFile := caFileFor(e, *caFlag, *issuer)
	c, err := authClient(e, strings.TrimSuffix(*issuer, "/"), *clientID, caFile)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	ctx, cancel := context.WithTimeout(e.ctx, *timeout)
	defer cancel()
	m, err := c.Discover(ctx)
	if err != nil {
		return fail(e, 1, "%v", err)
	}

	var t *auth.Tokens
	if *flow == "device" {
		t, err = c.Device(ctx, m, scopes, func(dc auth.DeviceCode) {
			fmt.Fprintf(e.stderr, "To sign in, open %s in a browser and confirm the code %s.\n", dc.VerificationURI, dc.UserCode)
			if dc.VerificationURIComplete != "" {
				fmt.Fprintf(e.stderr, "Or open this link, which holds the code: %s\n", dc.VerificationURIComplete)
				if !*noBrowser {
					e.open(dc.VerificationURIComplete)
				}
			}
			fmt.Fprintf(e.stderr, "Waiting for the sign-in (the code expires in %s)...\n", time.Duration(dc.ExpiresIn)*time.Second)
		})
	} else {
		t, err = c.Loopback(ctx, m, scopes, func(u string) {
			fmt.Fprintf(e.stderr, "Sign in in your browser. If it does not open, open this link on this machine:\n%s\n", u)
			if !*noBrowser {
				e.open(u)
			}
		})
	}
	if err != nil {
		return fail(e, 1, "sign-in failed: %v", err)
	}
	claims, err := auth.Claims(t.AccessToken)
	if err != nil {
		return fail(e, 1, "the access token: %v", err)
	}
	granted := grantedRoutes(t.Scope, auth.String(claims, "scope"))
	var missing []string
	for _, s := range scopes {
		if !slices.Contains(granted, s) {
			missing = append(missing, s)
		}
	}
	rec := &store.Record{
		Issuer: c.Issuer, ClientID: c.ClientID, RefreshToken: t.RefreshToken, Scopes: granted,
		CAFile: caFile, Gateway: strings.TrimSuffix(*gateway, "/"),
		Subject: auth.String(claims, "sub"), Username: auth.String(claims, "preferred_username"),
		Saved: time.Now().UTC(),
	}
	if t.RefreshExpiresIn > 0 {
		rec.RefreshExpires = rec.Saved.Add(time.Duration(t.RefreshExpiresIn) * time.Second)
	}
	unlock, err := store.Lock(dir)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	err = st.Save(rec)
	unlock()
	if err != nil {
		return fail(e, 1, "signed in, but the refresh token could not be kept: %v", err)
	}
	who := rec.Username
	if who == "" {
		who = rec.Subject
	}
	fmt.Fprintf(e.stdout, "Signed in to %s as %s.\nRoute scopes: %s.\nThe refresh token is kept in %s.\n",
		rec.Issuer, who, strings.Join(granted, ", "), st.Describe())
	if len(missing) > 0 {
		fmt.Fprintf(e.stderr, "agentctl: not granted: %s; tokens for them will be refused\n", strings.Join(missing, ", "))
		return 1
	}
	return 0
}

// grantedRoutes returns the route scopes among a token response's scope,
// or, without one, the access token's.
func grantedRoutes(scopes ...string) []string {
	var out []string
	for _, s := range scopes {
		for _, f := range strings.Fields(s) {
			if auth.CheckRouteScope(f) == nil && !slices.Contains(out, f) {
				out = append(out, f)
			}
		}
		if len(out) > 0 {
			break
		}
	}
	slices.Sort(out)
	return out
}

// canOpenBrowser reports whether a browser can open on this machine: not
// over SSH, and with $BROWSER, macOS, or a Linux desktop with xdg-open.
func canOpenBrowser(e *env) bool {
	if e.getenv("SSH_CONNECTION") != "" || e.getenv("SSH_TTY") != "" {
		return false
	}
	switch {
	case e.getenv("BROWSER") != "":
		return true
	case e.goos == "darwin":
		return true
	case e.goos == "linux":
		return (e.getenv("DISPLAY") != "" || e.getenv("WAYLAND_DISPLAY") != "") && e.lookPath("xdg-open")
	}
	return false
}

// openBrowser starts a browser on url without waiting for it: $BROWSER,
// as one command (no shell), else open on macOS or xdg-open on Linux. It
// reports whether it tried; the URL is printed either way.
func openBrowser(e *env, u string) bool {
	name := e.getenv("BROWSER")
	switch {
	case name != "":
	case e.goos == "darwin":
		name = "open"
	case e.goos == "linux" && e.lookPath("xdg-open"):
		name = "xdg-open"
	default:
		return false
	}
	go e.runner.Run(context.WithoutCancel(e.ctx), execx.Cmd{Name: name, Args: []string{u}, Stdout: io.Discard, Stderr: io.Discard})
	return true
}
