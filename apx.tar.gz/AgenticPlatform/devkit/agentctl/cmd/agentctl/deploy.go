package main

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strings"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/gitlab"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/oci"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/validate"
)

// runDeploy dispatches deploy request.
func runDeploy(e *env, args []string) int {
	if len(args) == 0 || args[0] != "request" {
		fmt.Fprintln(e.stderr, "usage: agentctl deploy request [flags]")
		return 2
	}
	return runDeployRequest(e, args[1:])
}

var releaseTagRE = regexp.MustCompile(`^(?:[a-z0-9]+(?:-[a-z0-9]+)*/)?v(\d+\.\d+\.\d+)$`)

// deployRequest is what one deploy request needs, read before anything is
// written.
type deployRequest struct {
	environment, project, tag, commit string
	name, team, kind, runtime         string
	ref                               oci.Reference
	releases                          []string
	charts                            map[string]chartPin
	values                            map[string][]byte // chart -> the project's deploy/<chart>.yaml
	access                            []byte            // the project's deploy/access.yaml, or nil
	haveAccess                        bool              // the environment has the access file
	envAccess                         []byte
	existing                          map[string][]byte // the environment's files of the workload, at main
}

type chartPin struct {
	Version string `yaml:"chartVersion"`
	Digest  string `yaml:"chartDigest"`
}

// runDeployRequest opens the merge request in environments that deploys
// one release of a workload (D39): its release.yaml with the pinned
// digests, its values for each chart from the project's deploy/ at the
// tag, and, for a first deploy, its access file from the project's
// deploy/access.yaml as a stub for the platform's review. It runs as the
// person, with their own GitLab token, and never deploys anything itself:
// the merge request's review and environments' pipeline do.
func runDeployRequest(e *env, args []string) int {
	fs := newFlags(e, "deploy request", "deploy request -environment ENV -project PATH -tag TAG -workload NAME (-image REF | -definition REF)")
	environment := fs.String("environment", defaults.Get(e.getenv, "AGENTCTL_ENVIRONMENT", defaults.Environment), "the environment to deploy to, as environments' clusters/ names it")
	project := fs.String("project", "", "the workload's project: its path, as $CI_PROJECT_PATH, or its numeric ID")
	tag := fs.String("tag", "", "the release tag, as $CI_COMMIT_TAG: vX.Y.Z")
	workload := fs.String("workload", "", "the workload's name, which workload.yaml at the tag must give")
	image := fs.String("image", "", "a container workload's image index, by digest: <registry.host>/<repository>@sha256:<64 hex>")
	definition := fs.String("definition", "", "a kagent agent's packaged definition, by digest: <registry.host>/<repository>@sha256:<64 hex>")
	envProject := fs.String("environments", defaults.Get(e.getenv, "AGENTCTL_ENVIRONMENTS_PROJECT", defaults.EnvironmentsProject), "the environments project ($AGENTCTL_ENVIRONMENTS_PROJECT)")
	gitlabURL := fs.String("gitlab", gitlabBase(e), "the GitLab instance ($GITLAB_HOST)")
	dryRun := fs.Bool("dry-run", false, "read everything and print the branch, commit, merge request and files, writing nothing to GitLab")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 || *project == "" || *tag == "" || *workload == "" {
		fs.Usage()
		return 2
	}
	if (*image == "") == (*definition == "") {
		return fail(e, 2, "give exactly one of -image (a container workload) and -definition (a kagent agent)")
	}
	if !releaseTagRE.MatchString(*tag) {
		return fail(e, 2, "-tag %q is not a release tag, vX.Y.Z", *tag)
	}
	given, flag := *image, "-image"
	if *definition != "" {
		given, flag = *definition, "-definition"
	}
	ref, err := oci.ParseReference(given)
	if err != nil {
		return fail(e, 2, "%s: %v", flag, err)
	}
	u, err := url.Parse(*gitlabURL)
	if err != nil || u.Host == "" {
		return fail(e, 2, "-gitlab %q is not a URL", *gitlabURL)
	}
	token, source, err := gitlab.Token(e.getenv, u.Host)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	hc, err := httpClient(e)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	gl := &gitlab.Client{BaseURL: *gitlabURL, Token: token, HTTP: hc}
	s, err := spec.Vendored()
	if err != nil {
		return fail(e, 2, "%v", err)
	}

	r := &deployRequest{environment: *environment, project: *project, tag: *tag, ref: ref}
	if err := r.read(e.ctx, gl, s, *envProject, *workload, flag); err != nil {
		if gitlab.IsStatus(err, http.StatusUnauthorized) || gitlab.IsStatus(err, http.StatusForbidden) {
			return fail(e, 1, "%v (the token from %s)", err, source)
		}
		return fail(e, 1, "%v", err)
	}
	actions, err := r.actions()
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if len(actions) == 0 {
		fmt.Fprintf(e.stdout, "%s already deploys %s %s at %s: nothing to request\n", r.environment, r.name, r.tag, r.ref.Digest)
		return 0
	}
	branch := "feat/deploy-" + r.name + "-" + strings.NewReplacer(".", "-", "/", "-").Replace(r.tag)
	if *dryRun {
		fmt.Fprintf(e.stdout, "branch: %s (from main of %s)\n\ncommit:\n%s\nmerge request: %s\n\n%s\n", branch, *envProject, r.commitMessage(), r.title(), r.description(actions))
		for _, a := range actions {
			fmt.Fprintf(e.stdout, "--- %s %s\n%s", a.Action, a.FilePath, a.Content)
		}
		return 0
	}
	exists, err := gl.BranchExists(e.ctx, *envProject, branch)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	if exists {
		return fail(e, 1, "the branch %s exists in %s already: a deploy request for %s %s is open, or was not cleaned up", branch, *envProject, r.name, r.tag)
	}
	if _, err := gl.Commit(e.ctx, *envProject, branch, "main", r.commitMessage(), actions); err != nil {
		return fail(e, 1, "committing to %s: %v", branch, err)
	}
	mr, err := gl.OpenMergeRequest(e.ctx, *envProject, branch, "main", r.title(), r.description(actions))
	if err != nil {
		return fail(e, 1, "the branch %s is pushed, but the merge request could not be opened: %v", branch, err)
	}
	fmt.Fprintf(e.stdout, "%s\n", mr.WebURL)
	fmt.Fprintf(e.stderr, "opened the deploy request for %s %s in %s as the token's owner: review and merge it there\n", r.name, r.tag, r.environment)
	return 0
}

func (r *deployRequest) read(ctx context.Context, gl *gitlab.Client, s *spec.Spec, envProject, want, flag string) error {
	t, err := gl.GetTag(ctx, r.project, r.tag)
	if err != nil {
		return fmt.Errorf("the tag %s of %s: %w", r.tag, r.project, err)
	}
	r.commit = t.Commit.ID
	raw, err := gl.RawFile(ctx, r.project, "workload.yaml", r.tag)
	if err != nil {
		return fmt.Errorf("workload.yaml of %s at %s: %w", r.project, r.tag, err)
	}
	problems, err := validate.File(s, "workload", raw)
	if err != nil {
		return fmt.Errorf("workload.yaml at %s: %w", r.tag, err)
	}
	if len(problems) > 0 {
		return fmt.Errorf("workload.yaml at %s does not match %s: %s", r.tag, spec.WorkloadSchema, problems[0])
	}
	v, _ := validate.Decode(raw)
	w, _ := v.(map[string]any)
	r.name, _ = w["name"].(string)
	r.team, _ = w["owner"].(string)
	r.kind, _ = w["kind"].(string)
	r.runtime, _ = w["runtime"].(string)
	if r.name != want {
		return fmt.Errorf("refusing: workload.yaml at %s names %q, not %q", r.tag, r.name, want)
	}
	if sup, _ := w["support"].(string); sup == "retired" {
		return fmt.Errorf("refusing: %s is retired", r.name)
	}
	switch {
	case r.runtime == "pipeline":
		return fmt.Errorf("refusing: %s is a workflow, which runs in its pipeline and is never deployed", r.name)
	case r.runtime == "kagent" && flag != "-definition":
		return fmt.Errorf("refusing: %s is a kagent agent: give its packaged definition with -definition, not -image", r.name)
	case r.runtime == "container" && flag != "-image":
		return fmt.Errorf("refusing: %s runs in a container: give its image with -image, not -definition", r.name)
	}
	r.releases = []string{"app-base", "agent-integration"}
	if r.runtime == "kagent" {
		r.releases = []string{"agent-integration"}
	}

	// The environment: its registry, its chart pins, and what it has of
	// the workload already.
	pv, err := gl.RawFile(ctx, envProject, "clusters/"+r.environment+"/platform/values.yaml", "main")
	if gitlab.IsStatus(err, http.StatusNotFound) {
		return fmt.Errorf("environments has no clusters/%s/platform/values.yaml: is %q an environment?", r.environment, r.environment)
	}
	if err != nil {
		return err
	}
	var platform struct {
		Registry struct {
			Host string `yaml:"host"`
		} `yaml:"registry"`
	}
	if err := yaml.Unmarshal(pv, &platform); err != nil || platform.Registry.Host == "" {
		return fmt.Errorf("clusters/%s/platform/values.yaml names no registry.host", r.environment)
	}
	repo := "workloads/" + r.team + "/" + r.name
	if r.ref.Host+"/"+r.ref.Repository != platform.Registry.Host+"/"+repo {
		return fmt.Errorf("refusing %s: %s is not %s/%s, the workload's repository (D4) in %s's registry", flag, r.ref, platform.Registry.Host, repo, r.environment)
	}
	vy, err := gl.RawFile(ctx, envProject, "versions.yaml", "main")
	if err != nil {
		return fmt.Errorf("environments' versions.yaml: %w", err)
	}
	var pins map[string]chartPin
	if err := yaml.Unmarshal(vy, &pins); err != nil {
		return fmt.Errorf("environments' versions.yaml: %w", err)
	}
	r.charts = map[string]chartPin{}
	r.values = map[string][]byte{}
	for _, c := range r.releases {
		p := pins[c+"-chart"]
		if p.Version == "" || !oci.ValidDigest(p.Digest) {
			return fmt.Errorf("environments' versions.yaml pins no %s-chart by version and digest", c)
		}
		r.charts[c] = p
		b, err := gl.RawFile(ctx, r.project, "deploy/"+c+".yaml", r.tag)
		if err != nil {
			return fmt.Errorf("deploy/%s.yaml of %s at %s: %w", c, r.project, r.tag, err)
		}
		r.values[c] = b
	}
	if b, err := gl.RawFile(ctx, r.project, "deploy/access.yaml", r.tag); err == nil {
		r.access = b
	} else if !gitlab.IsStatus(err, http.StatusNotFound) {
		return err
	}
	if b, err := gl.RawFile(ctx, envProject, r.accessPath(), "main"); err == nil {
		r.haveAccess, r.envAccess = true, b
	} else if !gitlab.IsStatus(err, http.StatusNotFound) {
		return err
	}
	r.existing = map[string][]byte{}
	for _, p := range r.paths() {
		b, err := gl.RawFile(ctx, envProject, p, "main")
		if err == nil {
			r.existing[p] = b
		} else if !gitlab.IsStatus(err, http.StatusNotFound) {
			return err
		}
	}
	return nil
}

func (r *deployRequest) dir() string         { return "clusters/" + r.environment + "/workloads/" + r.name }
func (r *deployRequest) releasePath() string { return r.dir() + "/release.yaml" }
func (r *deployRequest) accessPath() string {
	return "clusters/" + r.environment + "/domains/" + r.team + "/" + r.name + ".yaml"
}

func (r *deployRequest) paths() []string {
	ps := []string{r.releasePath()}
	for _, c := range r.releases {
		ps = append(ps, r.dir()+"/"+c+".yaml")
	}
	return ps
}

// releaseYAML is the deploy request's release.yaml, as
// workloads.yaml.gotmpl reads it.
func (r *deployRequest) releaseYAML() string {
	what := "image"
	if r.runtime == "kagent" {
		what = "packaged definition"
	}
	var b strings.Builder
	b.WriteString(comment(fmt.Sprintf("%s's deploy request (clusters/<environment>/workloads.yaml.gotmpl), opened by agentctl deploy request from %s at %s (%s): its team, whose access file is domains/%s/%s.yaml; the namespace the environment's setup made for it; the releases it takes; each chart by the version and digest versions.yaml pins; and its %s by digest.", r.name, r.project, r.tag, r.commit, r.team, r.name, what)))
	fmt.Fprintf(&b, "team: %s\nnamespace: %s\nreleases: [%s]\ncharts:\n", r.team, r.name, strings.Join(r.releases, ", "))
	for _, c := range r.releases {
		fmt.Fprintf(&b, "  %s: {version: %s, digest: %q}\n", c, r.charts[c].Version, r.charts[c].Digest)
	}
	fmt.Fprintf(&b, "image:\n  tag: %s\n  digest: %q\n", r.tag, r.ref.Digest)
	return b.String()
}

func (r *deployRequest) valuesFile(chart string) string {
	return comment(fmt.Sprintf("From %s's deploy/%s.yaml at %s (%s), as agentctl deploy request copied it.", r.project, chart, r.tag, r.commit)) + string(r.values[chart])
}

func (r *deployRequest) accessStub() string {
	head := fmt.Sprintf("Access file of %s, the team %s's %s: a stub that agentctl deploy request opened from %s at %s, for the platform's review.", r.name, r.team, r.kind, r.project, r.tag)
	if r.access != nil {
		return comment(head+" From its deploy/access.yaml.") + string(r.access)
	}
	return comment(head+" Its project has no deploy/access.yaml: name its routes here.") + "routes: {}\n"
}

// comment is text as a YAML comment, wrapped at 72 columns.
func comment(text string) string {
	var b strings.Builder
	for _, l := range strings.Split(wrap(text, 70), "\n") {
		b.WriteString("# " + l + "\n")
	}
	return b.String()
}

// actions are the files the request writes: release.yaml and each chart's
// values, and the access file when the environment has none. A file
// already as it would be is left out.
func (r *deployRequest) actions() ([]gitlab.Action, error) {
	var acts []gitlab.Action
	add := func(path, content string) {
		old, ok := r.existing[path]
		if ok && string(old) == content {
			return
		}
		a := "create"
		if ok {
			a = "update"
		}
		acts = append(acts, gitlab.Action{Action: a, FilePath: path, Content: content})
	}
	add(r.releasePath(), r.releaseYAML())
	for _, c := range r.releases {
		add(r.dir()+"/"+c+".yaml", r.valuesFile(c))
	}
	if len(acts) > 0 && !r.haveAccess {
		acts = append(acts, gitlab.Action{Action: "create", FilePath: r.accessPath(), Content: r.accessStub()})
	}
	return acts, nil
}

func (r *deployRequest) title() string {
	return fmt.Sprintf("feat(workloads): deploy %s %s", r.name, r.tag)
}

func (r *deployRequest) commitMessage() string {
	what := "the image"
	if r.runtime == "kagent" {
		what = "the packaged definition"
	}
	body := fmt.Sprintf("Deploy %s's release %s in %s, %s by digest\n%s, with its values from %s's deploy/ at\n%s.", r.name, r.tag, r.environment, what, r.ref.Digest, r.project, r.commit)
	if !r.haveAccess {
		body += "\n\nIts access file is a stub from the project's deploy/access.yaml,\nfor the platform's review."
	}
	return r.title() + "\n\n" + wrap(body, 72) + "\n\nRefs: D39\n"
}

func (r *deployRequest) description(acts []gitlab.Action) string {
	var b strings.Builder
	first := "a first deploy"
	if _, ok := r.existing[r.releasePath()]; ok {
		first = "an update of what the environment runs"
	}
	fmt.Fprintf(&b, "Deploy request for **%s** %s in `%s`, %s, opened with `agentctl deploy request` (D39) by the person whose token it ran with.\n\n", r.name, r.tag, r.environment, first)
	fmt.Fprintf(&b, "| | |\n| --- | --- |\n| Workload | `%s`, %s on `%s`, team `%s` |\n| Source | `%s` at `%s` (`%s`) |\n", r.name, r.kind, r.runtime, r.team, r.project, r.tag, r.commit)
	fmt.Fprintf(&b, "| Image | `%s` |\n", r.ref)
	for _, c := range r.releases {
		fmt.Fprintf(&b, "| Chart `%s` | %s, `%s` (versions.yaml) |\n", c, r.charts[c].Version, r.charts[c].Digest)
	}
	b.WriteString("\nFiles:\n\n")
	for _, a := range acts {
		fmt.Fprintf(&b, "- %s `%s`\n", a.Action, a.FilePath)
	}
	switch {
	case !r.haveAccess:
		fmt.Fprintf(&b, "\n**The access file is a stub** from the project's `deploy/access.yaml`: review its routes, roles and clients before merging. The namespace `%s` must exist from the environment's setup first; the pipeline creates none.\n", r.name)
	case r.access != nil && string(r.envAccess) != string(r.access):
		b.WriteString("\nThe environment's access file is kept as it is; the project's `deploy/access.yaml` at this tag differs from it, so check whether its routes changed.\n")
	}
	b.WriteString("\nAdmission verifies the image's signature and attestations when the deploy job applies it.\n")
	return b.String()
}

// wrap wraps text at width, keeping paragraphs.
func wrap(s string, width int) string {
	var out []string
	for _, para := range strings.Split(s, "\n\n") {
		var line string
		var lines []string
		for _, w := range strings.Fields(para) {
			if line != "" && len(line)+1+len(w) > width {
				lines = append(lines, line)
				line = w
				continue
			}
			if line == "" {
				line = w
			} else {
				line += " " + w
			}
		}
		if line != "" {
			lines = append(lines, line)
		}
		out = append(out, strings.Join(lines, "\n"))
	}
	return strings.Join(out, "\n\n")
}
