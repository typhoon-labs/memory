package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth/authtest"
)

func loginEnv(t *testing.T, is *authtest.Issuer) *testEnv {
	te := newTestEnv(t)
	te.vars["AGENTCTL_ISSUER"] = is.URL
	te.vars["AGENTCTL_CA_FILE"] = is.CAFile
	te.vars["AGENTCTL_GATEWAY"] = is.Gateway
	return te
}

func savedRecord(t *testing.T, te *testEnv) map[string]any {
	t.Helper()
	p := filepath.Join(te.vars["AGENTCTL_CONFIG_DIR"], "credentials.json")
	info, err := os.Stat(p)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm() != 0o600 {
		t.Fatalf("%s has mode %v, want 0600", p, info.Mode().Perm())
	}
	var r map[string]any
	data, _ := os.ReadFile(p)
	if err := json.Unmarshal(data, &r); err != nil {
		t.Fatal(err)
	}
	return r
}

func noToken(t *testing.T, what, text string) {
	t.Helper()
	// Every token the fake issues starts with its header's encoding.
	if strings.Contains(text, "eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0") {
		t.Fatalf("%s holds a token: %q", what, text)
	}
}

func TestLoginDeviceThenToken(t *testing.T) {
	is := authtest.New(t)
	is.AutoApprove = true
	te := loginEnv(t, is)
	code, out, errOut := te.run("login", "-flow", "device", "-scope", "models", "-scope", "mcp/notes-mcp")
	if code != 0 {
		t.Fatalf("login: code %d\n%s%s", code, out, errOut)
	}
	noToken(t, "login's output", out+errOut)
	if !strings.Contains(errOut, "ABCD-") || !strings.Contains(errOut, "/device") {
		t.Fatalf("login did not show the code and page: %q", errOut)
	}
	if !strings.Contains(out, "Route scopes: mcp/notes-mcp, models.") {
		t.Fatalf("login's summary: %q", out)
	}
	rec := savedRecord(t, te)
	first := rec["refresh_token"].(string)

	for _, scope := range []string{"models", "mcp/notes-mcp", "models"} {
		code, out, errOut = te.run("token", "-scope", scope)
		if code != 0 {
			t.Fatalf("token %s: code %d: %s", scope, code, errOut)
		}
		tok := strings.TrimSpace(out)
		if strings.Count(out, "\n") != 1 || strings.Contains(tok, " ") {
			t.Fatalf("token %s printed more than one token line: %q", scope, out)
		}
		c, err := auth.Claims(tok)
		if err != nil {
			t.Fatal(err)
		}
		if aud := auth.Audiences(c); len(aud) != 1 || aud[0] != auth.Audience(is.Gateway, scope) {
			t.Fatalf("token %s: audiences %v", scope, aud)
		}
		if is.LastRefreshScope != "openid "+scope {
			t.Fatalf("token %s refreshed with scope %q", scope, is.LastRefreshScope)
		}
	}
	if now := savedRecord(t, te)["refresh_token"]; now == first {
		t.Fatal("the refresh token was not rotated")
	}
	if is.Reuses != 0 || is.Refreshes != 3 {
		t.Fatalf("refreshes %d, reuses %d", is.Refreshes, is.Reuses)
	}
}

func TestLoginLoopback(t *testing.T) {
	is := authtest.New(t)
	te := loginEnv(t, is)
	// The browser: follow the authorization URL, which the fake issuer
	// answers with a redirect to the loopback listener, and load that.
	te.open = func(u string) bool {
		go func() {
			resp, err := is.Client().Get(u)
			if err == nil {
				resp.Body.Close()
			}
		}()
		return true
	}
	code, out, errOut := te.run("login", "-flow", "loopback")
	if code != 0 {
		t.Fatalf("login: code %d\n%s%s", code, out, errOut)
	}
	noToken(t, "login's output", out+errOut)
	if len(te.opened) != 1 || !strings.Contains(te.opened[0], "redirect_uri=http%3A%2F%2F127.0.0.1%3A") ||
		!strings.Contains(te.opened[0], "code_challenge_method=S256") {
		t.Fatalf("opened %v", te.opened)
	}
	if code, _, errOut := te.run("token"); code != 0 {
		t.Fatalf("token: code %d: %s", code, errOut)
	}
}

func TestLoginLoopbackOtherIssuer(t *testing.T) {
	is := authtest.New(t)
	is.WrongIss = true
	te := loginEnv(t, is)
	te.open = func(u string) bool {
		go func() {
			if resp, err := is.Client().Get(u); err == nil {
				resp.Body.Close()
			}
		}()
		return true
	}
	code, _, errOut := te.run("login", "-flow", "loopback")
	if code != 1 || !strings.Contains(errOut, "came from the issuer") {
		t.Fatalf("a mixed-up issuer: code %d, %q", code, errOut)
	}
}

func TestTokenRefusals(t *testing.T) {
	is := authtest.New(t)
	is.AutoApprove = true
	te := loginEnv(t, is)
	if code, _, errOut := te.run("token"); code != 1 || !strings.Contains(errOut, "not signed in") {
		t.Fatalf("before login: code %d, %q", code, errOut)
	}
	if code, _, errOut := te.run("login", "-flow", "device"); code != 0 {
		t.Fatalf("login: %d %s", code, errOut)
	}
	// Not granted at sign-in: a refresh can only narrow.
	if code, _, errOut := te.run("token", "-scope", "mcp/notes-mcp"); code != 1 || !strings.Contains(errOut, "agentctl login --scope mcp/notes-mcp") {
		t.Fatalf("ungranted scope: code %d, %q", code, errOut)
	}
	if code, _, _ := te.run("token", "-scope", "openid"); code != 2 {
		t.Fatalf("not a route scope: code %d", code)
	}
	// The gateway's audience must match exactly.
	te.vars["AGENTCTL_GATEWAY"] = "https://gateway.other.test"
	p := filepath.Join(te.vars["AGENTCTL_CONFIG_DIR"], "credentials.json")
	data, _ := os.ReadFile(p)
	os.WriteFile(p, []byte(strings.Replace(string(data), is.Gateway, "https://gateway.other.test", 1)), 0o600)
	code, out, errOut := te.run("token")
	if code != 1 || out != "" || !strings.Contains(errOut, "not printing the token") {
		t.Fatalf("other gateway: code %d, out %q, %q", code, out, errOut)
	}
	noToken(t, "token's refusal", errOut)
	// A file others can read is refused.
	os.Chmod(p, 0o644)
	if code, _, errOut := te.run("token"); code != 1 || !strings.Contains(errOut, "readable or writable by others") {
		t.Fatalf("mode 0644: code %d, %q", code, errOut)
	}
}

func TestTokenSessionEnded(t *testing.T) {
	is := authtest.New(t)
	is.AutoApprove = true
	te := loginEnv(t, is)
	if code, _, errOut := te.run("login", "-flow", "device"); code != 0 {
		t.Fatalf("login: %d %s", code, errOut)
	}
	stale := savedRecord(t, te)["refresh_token"].(string)
	if code, _, _ := te.run("token"); code != 0 {
		t.Fatal("token")
	}
	// Put the spent token back, as a store that lost a write would: the
	// issuer ends the session, and agentctl says to sign in again.
	p := filepath.Join(te.vars["AGENTCTL_CONFIG_DIR"], "credentials.json")
	data, _ := os.ReadFile(p)
	var r map[string]any
	json.Unmarshal(data, &r)
	r["refresh_token"] = stale
	data, _ = json.Marshal(r)
	os.WriteFile(p, data, 0o600)
	code, _, errOut := te.run("token")
	if code != 1 || !strings.Contains(errOut, "run agentctl login") || is.Reuses != 1 {
		t.Fatalf("reused token: code %d, reuses %d, %q", code, is.Reuses, errOut)
	}
	noToken(t, "token's refusal", errOut)
}

// TestTokenConcurrent runs many token commands at once against one
// sign-in, as harnesses calling apiKeyHelper may: the lock must keep any
// refresh token from being used twice, which would end the session.
func TestTokenConcurrent(t *testing.T) {
	is := authtest.New(t)
	is.AutoApprove = true
	te := loginEnv(t, is)
	if code, _, errOut := te.run("login", "-flow", "device"); code != 0 {
		t.Fatalf("login: %d %s", code, errOut)
	}
	const n = 12
	var wg sync.WaitGroup
	codes := make([]int, n)
	for i := range n {
		wg.Add(1)
		go func() {
			defer wg.Done()
			codes[i], _, _ = te.run("token")
		}()
	}
	wg.Wait()
	for i, c := range codes {
		if c != 0 {
			t.Errorf("run %d: code %d", i, c)
		}
	}
	if is.Reuses != 0 || is.Refreshes != n {
		t.Fatalf("refreshes %d, reuses %d: want %d and 0", is.Refreshes, is.Reuses, n)
	}
}

func TestLoginRefusals(t *testing.T) {
	is := authtest.New(t)
	te := loginEnv(t, is)
	if code, _, _ := te.run("login", "-scope", "admin"); code != 2 {
		t.Fatalf("bad scope: code %d", code)
	}
	if code, _, _ := te.run("login", "-flow", "carrier-pigeon"); code != 2 {
		t.Fatalf("bad flow: code %d", code)
	}
	// Plain HTTP is refused.
	te.vars["AGENTCTL_ISSUER"] = strings.Replace(is.URL, "https://", "http://", 1)
	if code, _, errOut := te.run("login", "-flow", "device"); code != 1 || !strings.Contains(errOut, "not an https URL") {
		t.Fatalf("http issuer: code %d, %q", code, errOut)
	}
}
