package main

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"path"
	"regexp"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/gitlab"
)

// templates are workload-templates' templates and the suffix each one's
// workload name takes (design/repositories.md, "Naming").
var templates = map[string]string{
	"adk-agent":         "-agent",
	"kagent-agent":      "-agent",
	"mcp-server-python": "-mcp",
	"workflow-pipeline": "-workflow",
}

var slug = regexp.MustCompile(`^[a-z0-9]+(-[a-z0-9]+)*$`)

// checkName applies the naming rules before asking the generation job,
// which applies them again: lowercase kebab-case, at most 63 characters,
// the template's suffix, and never a framework or runtime as a word.
func checkName(template, name string) error {
	if len(name) > 63 || !slug.MatchString(name) {
		return fmt.Errorf("%q is not a workload name: lowercase kebab-case, at most 63 characters", name)
	}
	if suffix := templates[template]; !strings.HasSuffix(name, suffix) {
		return fmt.Errorf("%q: a %s workload's name ends in %s", name, template, suffix)
	}
	for _, w := range strings.Split(name, "-") {
		if w == "adk" || w == "kagent" {
			return fmt.Errorf("%q: a name never holds the framework or runtime (%s)", name, w)
		}
	}
	return nil
}

// runNew starts workload-templates' generation job as the person, with
// their own GitLab token, waits for it, and prints the new project's URL
// (design/development.md, "Project generation and updates"). The job takes
// pipeline inputs: template, name, team and placement.
func runNew(e *env, args []string) int {
	fs := newFlags(e, "new", "new [flags] TEMPLATE NAME\n\nTemplates: adk-agent, kagent-agent, mcp-server-python, workflow-pipeline")
	team := fs.String("team", e.getenv("AGENTCTL_TEAM"), "the owning team's slug: the project goes to workloads/<team>/ ($AGENTCTL_TEAM)")
	shared := fs.Bool("shared", false, "a workload used across the organization: workloads/shared/, with a named owning team (-team)")
	incubator := fs.Bool("incubator", false, "an experiment: incubator/, with a named owning team (-team)")
	templatesProject := fs.String("templates", defaults.Get(e.getenv, "AGENTCTL_TEMPLATES", defaults.TemplatesProject), "the workload-templates project, by path or ID ($AGENTCTL_TEMPLATES)")
	ref := fs.String("ref", "main", "the templates project's branch the generation job runs on")
	gitlabURL := fs.String("gitlab", gitlabBase(e), "the GitLab instance ($GITLAB_HOST)")
	noWait := fs.Bool("no-wait", false, "start the job and print its pipeline, without waiting")
	timeout := fs.Duration("timeout", 30*time.Minute, "how long to wait for the job")
	poll := fs.Duration("poll", 5*time.Second, "how often to look at the job")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() != 2 {
		fs.Usage()
		return 2
	}
	template, name := fs.Arg(0), fs.Arg(1)
	if _, ok := templates[template]; !ok {
		return fail(e, 2, "unknown template %q: use adk-agent, kagent-agent, mcp-server-python or workflow-pipeline", template)
	}
	if err := checkName(template, name); err != nil {
		return fail(e, 2, "%v", err)
	}
	placement := "team"
	switch {
	case *shared && *incubator:
		return fail(e, 2, "-shared and -incubator exclude each other")
	case *shared:
		placement = "shared"
	case *incubator:
		placement = "incubator"
	}
	// Every placement names its owning team, incubator/ too: workload.yaml's
	// owner, which the generation job refuses empty.
	if *team == "" || len(*team) > 63 || !slug.MatchString(*team) {
		return fail(e, 2, "-team: the owning team's slug, as in environments' access/teams.yaml")
	}

	u, err := url.Parse(*gitlabURL)
	if err != nil || u.Scheme != "https" || u.Host == "" {
		return fail(e, 2, "-gitlab %q is not an https URL", *gitlabURL)
	}
	token, source, err := gitlab.Token(e.getenv, u.Host)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	hc, err := httpClient(e)
	if err != nil {
		return fail(e, 2, "%v", err)
	}
	gl := &gitlab.Client{BaseURL: *gitlabURL, Token: token, HTTP: hc}
	ctx, cancel := context.WithTimeout(e.ctx, *timeout)
	defer cancel()

	tp, err := gl.Project(ctx, *templatesProject)
	if err != nil {
		return fail(e, 1, "the templates project %s: %v (token from %s)", *templatesProject, err, source)
	}
	// The templates project is <root>/devkit/workload-templates; the new
	// project goes under the same root.
	root := path.Dir(tp.Namespace.FullPath)
	target := path.Join(root, "workloads", *team, name)
	switch placement {
	case "shared":
		target = path.Join(root, "workloads", "shared", name)
	case "incubator":
		target = path.Join(root, "incubator", name)
	}
	if p, err := gl.Project(ctx, target); err == nil {
		return fail(e, 1, "%s is taken: %s", target, p.WebURL)
	} else if !gitlab.IsStatus(err, http.StatusNotFound) {
		return fail(e, 1, "looking for %s: %v", target, err)
	}

	inputs := map[string]any{"template": template, "name": name, "team": *team, "placement": placement}
	pl, err := gl.CreatePipeline(ctx, tp.PathWithNamespace, *ref, inputs)
	switch {
	case gitlab.IsStatus(err, http.StatusForbidden), gitlab.IsStatus(err, http.StatusUnauthorized):
		return fail(e, 1, "GitLab refused to start the generation job on %s's %s: %v. Starting it needs merge rights on that protected branch; how others start it is open item T17", tp.PathWithNamespace, *ref, err)
	case err != nil:
		return fail(e, 1, "starting the generation job: %v", err)
	}
	fmt.Fprintf(e.stderr, "Generating %s from %s: %s\n", target, template, pl.WebURL)
	if *noWait {
		fmt.Fprintln(e.stdout, pl.WebURL)
		return 0
	}
	pl, err = gl.Wait(ctx, tp.PathWithNamespace, pl.ID, *poll, func(p *gitlab.Pipeline) {
		fmt.Fprintf(e.stderr, "  pipeline %d: %s\n", p.ID, p.Status)
	})
	if err != nil {
		return fail(e, 1, "waiting for %s: %v", pl.WebURL, err)
	}
	if pl.Status != "success" {
		jobs, _ := gl.Jobs(ctx, tp.PathWithNamespace, pl.ID)
		for _, j := range jobs {
			if j.Status == "failed" || j.Status == "manual" {
				fmt.Fprintf(e.stderr, "  job %s: %s %s\n", j.Name, j.Status, j.WebURL)
			}
		}
		return fail(e, 1, "the generation job ended %s: %s", pl.Status, pl.WebURL)
	}
	p, err := gl.Project(ctx, target)
	if err != nil {
		return fail(e, 1, "the generation job succeeded, but %s cannot be read: %v", target, err)
	}
	fmt.Fprintln(e.stdout, p.WebURL)
	return 0
}

func gitlabBase(e *env) string {
	h := e.getenv("GITLAB_HOST")
	switch {
	case h == "":
		return defaults.GitLab
	case strings.Contains(h, "://"):
		return h
	default:
		return "https://" + h
	}
}

// httpClient is the HTTP client for services other than the realm: the
// system's roots and AGENTCTL_CA_FILE.
func httpClient(e *env) (*http.Client, error) {
	if e.httpClient != nil {
		return e.httpClient, nil
	}
	return auth.HTTPClient(e.getenv("AGENTCTL_CA_FILE"), "agentctl/"+version)
}
