package main

// The harness integration test runs the real Claude Code in a throwaway
// container, never on this machine's own configuration: the Node.js image
// Versions pins, Claude Code installed in it with npm, agentctl built for
// it and mounted, on the host network with no proxy variables, removed at
// the end. agentctl harness setup writes the managed settings inside it;
// Claude Code then talks to a capture server of the test's own on a
// loopback port, which answers as the Messages API does, so nothing
// reaches the platform or Anthropic. It is the third exception to "tests
// never run docker" (AGENTS.md), and runs only when
// AGENTCTL_INTEGRATION_NODE_IMAGE names the Node.js image by digest
// (AGENTCTL_INTEGRATION_CLAUDE_CODE the version, default the pin);
// otherwise it skips.

import (
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
)

// capture answers Claude Code as the Messages API does, and records what
// it was sent.
type capture struct {
	mu       sync.Mutex
	requests []capturedRequest
}

type capturedRequest struct {
	method, path, auth, apiKey, session, model string
	systemRoles                                int
}

func (c *capture) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	body, _ := io.ReadAll(io.LimitReader(r.Body, 8<<20))
	var req struct {
		Model    string `json:"model"`
		Stream   bool   `json:"stream"`
		Messages []struct {
			Role string `json:"role"`
		} `json:"messages"`
	}
	json.Unmarshal(body, &req)
	cr := capturedRequest{method: r.Method, path: r.URL.Path, auth: r.Header.Get("Authorization"), apiKey: r.Header.Get("x-api-key"), session: r.Header.Get("x-claude-code-session-id"), model: req.Model}
	for _, m := range req.Messages {
		if m.Role == "system" {
			cr.systemRoles++
		}
	}
	c.mu.Lock()
	c.requests = append(c.requests, cr)
	c.mu.Unlock()
	switch {
	case r.Method == http.MethodPost && r.URL.Path == "/v1/messages/count_tokens":
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"input_tokens": 12}`))
	case r.Method == http.MethodPost && r.URL.Path == "/v1/messages":
		if !req.Stream {
			w.Header().Set("Content-Type", "application/json")
			fmt.Fprintf(w, `{"id":"msg_it","type":"message","role":"assistant","model":%q,"content":[{"type":"text","text":"pong-from-capture"}],"stop_reason":"end_turn","stop_sequence":null,"usage":{"input_tokens":12,"output_tokens":3}}`, req.Model)
			return
		}
		w.Header().Set("Content-Type", "text/event-stream")
		events := []string{
			fmt.Sprintf(`{"type":"message_start","message":{"id":"msg_it","type":"message","role":"assistant","model":%q,"content":[],"stop_reason":null,"stop_sequence":null,"usage":{"input_tokens":12,"output_tokens":1}}}`, req.Model),
			`{"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}`,
			`{"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"pong-from-capture"}}`,
			`{"type":"content_block_stop","index":0}`,
			`{"type":"message_delta","delta":{"stop_reason":"end_turn","stop_sequence":null},"usage":{"output_tokens":3}}`,
			`{"type":"message_stop"}`,
		}
		for _, ev := range events {
			var t struct{ Type string }
			json.Unmarshal([]byte(ev), &t)
			fmt.Fprintf(w, "event: %s\ndata: %s\n\n", t.Type, ev)
			if f, ok := w.(http.Flusher); ok {
				f.Flush()
			}
		}
	default:
		http.NotFound(w, r)
	}
}

func (c *capture) since(n int) []capturedRequest {
	c.mu.Lock()
	defer c.mu.Unlock()
	return append([]capturedRequest(nil), c.requests[n:]...)
}

func (c *capture) count() int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return len(c.requests)
}

func TestHarnessRealClaudeCode(t *testing.T) {
	image := os.Getenv("AGENTCTL_INTEGRATION_NODE_IMAGE")
	if image == "" {
		t.Skip("set AGENTCTL_INTEGRATION_NODE_IMAGE to the Node.js image by digest to run Claude Code in a throwaway container")
	}
	version := os.Getenv("AGENTCTL_INTEGRATION_CLAUDE_CODE")
	if version == "" {
		version = claudePin
	}
	docker, err := lookReal("docker")
	if err != nil {
		t.Skip(err)
	}
	goTool, err := lookReal("go")
	if err != nil {
		t.Skip(err)
	}
	tools := newRealTools(t, "docker")

	// agentctl, built for the container.
	bin := t.TempDir()
	build := exec.Command(goTool, "build", "-o", filepath.Join(bin, "agentctl"), ".")
	build.Env = append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux", "GOARCH="+runtime.GOARCH)
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("go build: %v\n%s", err, out)
	}

	// The capture server, on loopback, which the container's host network
	// shares.
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	cap := &capture{}
	srv := &http.Server{Handler: cap}
	go srv.Serve(l)
	t.Cleanup(func() { srv.Close() })
	gateway := "http://" + l.Addr().String()

	// The work directory: the helper, which stands in for agentctl token
	// and takes its arguments, since no sign-in is possible in the test;
	// and a repository.
	work := t.TempDir()
	os.WriteFile(filepath.Join(work, "helper.sh"), []byte("#!/bin/sh\necho it-token-123\n"), 0o755)
	repo := filepath.Join(work, "repo")
	os.MkdirAll(filepath.Join(repo, ".agents/skills/notes-style"), 0o755)
	os.WriteFile(filepath.Join(repo, ".agents/skills/notes-style/SKILL.md"), []byte("---\nname: notes-style\ndescription: How notes are written.\n---\nWrite short notes.\n"), 0o644)
	os.WriteFile(filepath.Join(repo, "AGENTS.md"), []byte("# Agents\n"), 0o644)
	os.Chmod(work, 0o777)

	name := fmt.Sprintf("agentctl-it-claude-%d", time.Now().UnixNano())
	tools.sh(t, "", "docker", "run", "-d", "--rm", "--name", name, "--network", "host",
		"-e", "HTTP_PROXY=", "-e", "HTTPS_PROXY=", "-e", "NO_PROXY=", "-e", "http_proxy=", "-e", "https_proxy=", "-e", "no_proxy=",
		"-v", filepath.Join(bin, "agentctl")+":/usr/local/bin/agentctl:ro", "-v", work+":/work",
		image, "sleep", "1800")
	t.Cleanup(func() { exec.Command(docker, "rm", "-f", name).Run() })
	// Root writes in /work: give it back before the test removes it.
	t.Cleanup(func() {
		exec.Command(docker, "exec", name, "chown", "-R", fmt.Sprintf("%d:%d", os.Getuid(), os.Getgid()), "/work").Run()
	})
	exe := func(env []string, args ...string) (int, string) {
		cmd := []string{"exec"}
		for _, kv := range env {
			cmd = append(cmd, "-e", kv)
		}
		cmd = append(append(cmd, name), args...)
		c := exec.Command(docker, cmd...)
		c.Env = tools.env
		out, err := c.CombinedOutput()
		code := 0
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		} else if err != nil {
			t.Fatalf("docker exec: %v", err)
		}
		return code, string(out)
	}

	if code, out := exe(nil, "npm", "install", "-g", "--no-fund", "--no-audit", "@anthropic-ai/claude-code@"+version); code != 0 {
		t.Fatalf("npm install: %d\n%s", code, out)
	}
	code, out := exe(nil, "claude", "--version")
	if code != 0 || !strings.Contains(out, version) {
		t.Fatalf("claude --version: %d %q", code, out)
	}
	t.Logf("in the container: Claude Code %s", strings.TrimSpace(out))

	// harness setup inside the container, as root, as a person would with
	// sudo.
	code, out = exe(nil, "agentctl", "harness", "setup", "-gateway", gateway, "-api-key-helper", "/work/helper.sh token --scope models", "-dir", "/work/repo")
	if code != 0 {
		t.Fatalf("harness setup: %d\n%s", code, out)
	}
	t.Logf("harness setup:\n%s", out)
	if code, out := exe(nil, "test", "-L", "/work/repo/.claude/skills/notes-style"); code != 0 {
		t.Errorf("the skill's link: %d %s", code, out)
	}
	// The person's own settings name another base URL: the managed one
	// must win.
	exe(nil, "sh", "-c", `mkdir -p /root/.claude && printf '{"env":{"ANTHROPIC_BASE_URL":"http://127.0.0.1:9"}}' > /root/.claude/settings.json`)

	before := cap.count()
	code, out = exe([]string{"CI=1"}, "sh", "-c", "cd /work/repo && claude -p 'Reply with the word pong.' --output-format json")
	if code != 0 || !strings.Contains(out, "pong-from-capture") {
		t.Fatalf("claude -p: %d\n%s", code, out)
	}
	got := cap.since(before)
	var messages int
	for _, r := range got {
		if r.path != "/v1/messages" {
			continue
		}
		messages++
		if r.auth != "Bearer it-token-123" || r.apiKey != "it-token-123" {
			t.Errorf("credential headers: Authorization %q, x-api-key %q", r.auth, r.apiKey)
		}
		if r.session == "" {
			t.Error("no x-claude-code-session-id")
		}
		if r.model != "reasoning-default" && r.model != "fast-default" {
			t.Errorf("model %q, not a gateway alias", r.model)
		}
	}
	if messages == 0 {
		t.Fatalf("Claude Code sent no /v1/messages to the gateway: %+v", got)
	}
	for _, r := range got {
		t.Logf("claude -p sent %s %s model=%s session=%t system-role-entries=%d", r.method, r.path, r.model, r.session != "", r.systemRoles)
	}

	// A provider variable: refused by allowedProviders, nothing sent.
	before = cap.count()
	code, out = exe([]string{"CI=1", "CLAUDE_CODE_USE_BEDROCK=1", "AWS_REGION=us-east-1"}, "sh", "-c", "cd /work/repo && claude -p 'hi' --output-format json")
	if code == 0 {
		t.Errorf("CLAUDE_CODE_USE_BEDROCK=1 was not refused:\n%s", out)
	}
	t.Logf("CLAUDE_CODE_USE_BEDROCK=1: exit %d: %s", code, oneLine(out, 300))
	if n := cap.count() - before; n != 0 {
		t.Errorf("%d requests reached the gateway with another provider selected", n)
	}

	// The person's own base URL in the environment: the managed value
	// wins, or the session is refused; either way nothing goes elsewhere.
	before = cap.count()
	code, out = exe([]string{"CI=1", "ANTHROPIC_BASE_URL=http://127.0.0.1:9"}, "sh", "-c", "cd /work/repo && claude -p 'Reply with the word pong.' --output-format json")
	t.Logf("ANTHROPIC_BASE_URL in the environment: exit %d, %d requests to the gateway: %s", code, cap.count()-before, oneLine(out, 300))
	if code == 0 && cap.count() == before {
		t.Errorf("a session ran with the person's base URL and sent nothing to the gateway")
	}

	// doctor, inside the container, against the capture server.
	code, out = exe(nil, "agentctl", "doctor", "-gateway", gateway, "-dir", "/work/repo")
	t.Logf("doctor:\n%s", out)
	if code != 0 {
		t.Errorf("doctor: %d", code)
	}
	for _, want := range []string{"ok      Claude Code: " + version, "ok      allowedProviders", "ok      credential", "ok      gateway", "warn    ANTHROPIC_BASE_URL"} {
		if !strings.Contains(out, want) {
			t.Errorf("doctor lacks %q", want)
		}
	}
	// And doctor names the fix once a later file breaks the lock.
	exe(nil, "sh", "-c", `printf '{"allowedProviders":["anthropic"]}' > /etc/claude-code/managed-settings.d/90-broken.json`)
	if code, out := exe(nil, "agentctl", "doctor", "-gateway", gateway, "-dir", "/work/repo"); code != 1 || !strings.Contains(out, "fix: managed lists combine") {
		t.Errorf("doctor with a broken lock: %d\n%s", code, out)
	}
}
