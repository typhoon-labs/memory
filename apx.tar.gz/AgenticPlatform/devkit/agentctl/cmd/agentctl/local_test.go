package main

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// fakeEnvironments makes a repository shaped like environments, whose
// bootstrap.sh only records how it was run, and returns its path and
// commit. The script uses shell builtins alone: PATH holds only fakes.
func fakeEnvironments(t *testing.T) (repo, commit string) {
	t.Helper()
	if gitPath == "" {
		t.Skip("no git")
	}
	repo = t.TempDir()
	script := `#!/bin/sh
{ echo "run"; echo "dir=$(pwd)"; echo "HTTPS_PROXY=$HTTPS_PROXY"; echo "NO_PROXY=$NO_PROXY"; } >> "$FAKE_BOOTSTRAP_OUT"
exit "${FAKE_BOOTSTRAP_STATUS:-0}"
`
	os.MkdirAll(filepath.Join(repo, "clusters/local/00-local/floci"), 0o755)
	os.WriteFile(filepath.Join(repo, "clusters/local/00-local/bootstrap.sh"), []byte(script), 0o755)
	os.WriteFile(filepath.Join(repo, "clusters/local/00-local/floci/compose.yaml"), []byte("services: {}\n"), 0o644)
	return repo, gitCommit(t, repo, "the bootstrap")
}

func gitRun(t *testing.T, dir string, args ...string) string {
	t.Helper()
	cmd := exec.Command(gitPath, append([]string{"-C", dir, "-c", "user.name=test", "-c", "user.email=test@example.test", "-c", "init.defaultBranch=main"}, args...)...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("git %v: %v\n%s", args, err, out)
	}
	return strings.TrimSpace(string(out))
}

func gitCommit(t *testing.T, repo, msg string) string {
	if _, err := os.Stat(filepath.Join(repo, ".git")); err != nil {
		gitRun(t, repo, "init", "-q")
	}
	gitRun(t, repo, "add", "-A")
	gitRun(t, repo, "commit", "-q", "-m", msg)
	return gitRun(t, repo, "rev-parse", "HEAD")
}

func localEnv(t *testing.T, source string) (*testEnv, string) {
	te := newTestEnv(t)
	te.vars["AGENTCTL_ENVIRONMENTS_SOURCE"] = source
	out := filepath.Join(t.TempDir(), "bootstrap.log")
	t.Setenv("FAKE_BOOTSTRAP_OUT", out)
	return te, out
}

func osRunner(e *env) { e.runner = execx.OS{} }

func TestLocalUp(t *testing.T) {
	repo, commit := fakeEnvironments(t)
	te, log := localEnv(t, repo)
	// The bootstrap gets agentctl's environment unchanged, proxies too.
	t.Setenv("HTTPS_PROXY", "http://proxy.example.test:3128")
	t.Setenv("NO_PROXY", "floci,.agentic.internal")

	code, _, errOut := te.runWith(osRunner, "local", "up", "-commit", commit)
	if code != 0 || !strings.Contains(errOut, "Cloning") {
		t.Fatalf("first up: code %d, %q", code, errOut)
	}
	checkout := filepath.Join(te.vars["AGENTCTL_CACHE_DIR"], "environments")
	got, _ := os.ReadFile(log)
	for _, want := range []string{"dir=" + checkout, "HTTPS_PROXY=http://proxy.example.test:3128", "NO_PROXY=floci,.agentic.internal"} {
		if !strings.Contains(string(got), want) {
			t.Errorf("the bootstrap's run lacks %s:\n%s", want, got)
		}
	}
	if head := gitRun(t, checkout, "rev-parse", "HEAD"); head != commit {
		t.Fatalf("checkout at %s", head)
	}
	// Again: no clone, the bootstrap runs again; its status is agentctl's.
	t.Setenv("FAKE_BOOTSTRAP_STATUS", "7")
	code, _, errOut = te.runWith(osRunner, "local", "up", "-commit", commit)
	if code != 7 || strings.Contains(errOut, "Cloning") || strings.Contains(errOut, "Fetching") {
		t.Fatalf("second up: code %d, %q", code, errOut)
	}
	got, _ = os.ReadFile(log)
	if n := strings.Count(string(got), "run\n"); n != 2 {
		t.Fatalf("the bootstrap ran %d times", n)
	}
	// A new pin the clone lacks is fetched.
	os.WriteFile(filepath.Join(repo, "README.md"), []byte("next\n"), 0o644)
	next := gitCommit(t, repo, "next")
	t.Setenv("FAKE_BOOTSTRAP_STATUS", "0")
	code, _, errOut = te.runWith(osRunner, "local", "up", "-commit", next)
	if code != 0 || !strings.Contains(errOut, "Fetching") || gitRun(t, checkout, "rev-parse", "HEAD") != next {
		t.Fatalf("new pin: code %d, %q", code, errOut)
	}
}

func TestLocalUpGivenCheckout(t *testing.T) {
	repo, commit := fakeEnvironments(t)
	te, _ := localEnv(t, repo)
	if code, _, errOut := te.runWith(osRunner, "local", "up", "-environments", repo, "-commit", commit); code != 0 {
		t.Fatalf("at the pin: code %d, %q", code, errOut)
	}
	if code, _, errOut := te.runWith(osRunner, "local", "up", "-environments", repo); code != 2 || !strings.Contains(errOut, "not the pinned") {
		t.Fatalf("at another commit: code %d, %q", code, errOut)
	}
	os.WriteFile(filepath.Join(repo, "clusters/local/00-local/floci/compose.yaml"), []byte("changed\n"), 0o644)
	if code, _, errOut := te.runWith(osRunner, "local", "up", "-environments", repo, "-commit", commit); code != 2 || !strings.Contains(errOut, "changes") {
		t.Fatalf("dirty: code %d, %q", code, errOut)
	}
	if code, _, _ := te.run("local", "up", "-commit", "10bbca4"); code != 2 {
		t.Fatalf("a short commit: code %d", code)
	}
}

func TestLocalDown(t *testing.T) {
	repo, _ := fakeEnvironments(t)
	te, _ := localEnv(t, repo)
	code, _, errOut := te.run("local", "down", "-environments", repo)
	if code != 2 || !strings.Contains(errOut, "-yes") || len(te.runner.Calls()) != 0 {
		t.Fatalf("without -yes: code %d, %d commands, %q", code, len(te.runner.Calls()), errOut)
	}
	if code, _, errOut := te.run("local", "down", "-environments", repo, "-yes"); code != 0 {
		t.Fatalf("down: code %d, %q", code, errOut)
	}
	compose := filepath.Join(repo, "clusters/local/00-local/floci/compose.yaml")
	want := []string{"kind [delete cluster --name agentic-local]", "docker [compose -f " + compose + " stop]"}
	calls := te.runner.Calls()
	if len(calls) != 2 {
		t.Fatalf("commands: %v", calls)
	}
	for i, c := range calls {
		if c.Cmd.String() != want[i] {
			t.Errorf("command %d: %s, want %s", i, c.Cmd, want[i])
		}
		for _, a := range c.Cmd.Args {
			if a == "kill" || a == "rm" || a == "down" {
				t.Errorf("down ran %s", c.Cmd)
			}
		}
	}
	// A failed delete still stops floci, and fails the command.
	te.runner = &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
		if c.Name == "kind" {
			return 1, "", "no cluster", nil
		}
		return 0, "", "", nil
	}}
	code, _, errOut = te.run("local", "down", "-environments", repo, "-yes")
	if code != 1 || len(te.runner.Calls()) != 2 || !strings.Contains(errOut, "kind delete cluster exited with status 1") {
		t.Fatalf("failed delete: code %d, %v, %q", code, te.runner.Calls(), errOut)
	}
	if code, _, _ := te.run("local", "down", "-yes", "-environments", t.TempDir()); code != 2 {
		t.Fatalf("no compose file: code %d", code)
	}
}
