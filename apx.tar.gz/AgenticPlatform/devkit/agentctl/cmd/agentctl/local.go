package main

import (
	"fmt"
	"os"
	"path/filepath"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/defaults"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/local"
)

func runLocal(e *env, args []string) int {
	if len(args) == 0 {
		fmt.Fprintln(e.stderr, "usage: agentctl local up|down [flags]")
		return 2
	}
	switch args[0] {
	case "up":
		return runLocalUp(e, args[1:])
	case "down":
		return runLocalDown(e, args[1:])
	}
	fmt.Fprintf(e.stderr, "agentctl: unknown local command %q: use up or down\n", args[0])
	return 2
}

// checkoutDir is where agentctl keeps its own checkout of environments.
func checkoutDir(e *env) (string, error) {
	cache, err := defaults.CacheDir(e.getenv)
	if err != nil {
		return "", err
	}
	return filepath.Join(cache, "environments"), nil
}

// runLocalUp runs environments' bootstrap from a checkout at the pinned
// commit: agentctl's own, cloned and moved to the pin as needed, or one
// given with -environments, which must already be at the pin. The
// bootstrap gets agentctl's environment unchanged, and its exit status is
// agentctl's.
func runLocalUp(e *env, args []string) int {
	fs := newFlags(e, "local up", "local up [-environments DIR] [-commit SHA] [-source URL]")
	envDir := fs.String("environments", "", "an existing checkout of environments to run from, which must be at the commit; default: agentctl's own, under its cache directory")
	commit := fs.String("commit", local.EnvironmentsCommit, "the environments commit to run the bootstrap from")
	source := fs.String("source", defaults.Get(e.getenv, "AGENTCTL_ENVIRONMENTS_SOURCE", local.EnvironmentsSource), "where to clone environments from ($AGENTCTL_ENVIRONMENTS_SOURCE)")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	if err := local.CheckCommit(*commit); err != nil {
		return fail(e, 2, "-commit: %v", err)
	}
	dir := *envDir
	if dir != "" {
		if err := local.Verify(e.ctx, e.runner, dir, *commit); err != nil {
			return fail(e, 2, "%v", err)
		}
	} else {
		var err error
		if dir, err = checkoutDir(e); err != nil {
			return fail(e, 2, "%v", err)
		}
		if err := local.Prepare(e.ctx, e.runner, dir, *source, *commit, e.stderr); err != nil {
			return fail(e, 1, "the environments checkout: %v", err)
		}
	}
	if e.getenv("AWS_FOUNDATION_DIR") == "" && !fileExists(filepath.Join(dir, "..", "aws-foundation")) {
		fmt.Fprintf(e.stderr, "agentctl: note: the bootstrap's OpenTofu step needs aws-foundation beside %s or in $AWS_FOUNDATION_DIR\n", dir)
	}
	fmt.Fprintf(e.stderr, "Running %s at %.12s\n", local.Bootstrap, *commit)
	status, err := local.Up(e.ctx, e.runner, dir, e.stdin, e.stdout, e.stderr)
	if err != nil {
		return fail(e, 1, "%v", err)
	}
	return status
}

// runLocalDown deletes the local cluster and stops floci, only with -yes:
// it ends everything running locally.
func runLocalDown(e *env, args []string) int {
	fs := newFlags(e, "local down", "local down -yes [-environments DIR]")
	yes := fs.Bool("yes", false, "confirm: delete the kind cluster "+"agentic-local"+" and stop floci")
	envDir := fs.String("environments", "", "the checkout of environments whose floci compose file to stop; default: agentctl's own")
	if code, ok := parse(fs, args); !ok {
		return code
	}
	if fs.NArg() > 0 {
		fs.Usage()
		return 2
	}
	dir := *envDir
	if dir == "" {
		var err error
		if dir, err = checkoutDir(e); err != nil {
			return fail(e, 2, "%v", err)
		}
	}
	compose := filepath.Join(dir, local.FlociCompose)
	if _, err := os.Stat(compose); err != nil {
		return fail(e, 2, "no %s: give -environments, or run agentctl local up once", compose)
	}
	if !*yes {
		fmt.Fprintf(e.stderr, "agentctl local down deletes the kind cluster %s, with everything in it, and stops floci:\n  kind delete cluster --name %s\n  docker compose -f %s stop\nRun it again with -yes to go ahead.\n", local.Cluster, local.Cluster, compose)
		return 2
	}
	if err := local.Down(e.ctx, e.runner, dir, e.stdout, e.stderr); err != nil {
		return fail(e, 1, "%v", err)
	}
	return 0
}
