# Agent instructions: agentctl

This repository holds `agentctl`, the platform's developer CLI, in Go. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. What it does is in [Distribution](../../architecture/design/distribution.md#agentctl-the-thin-organization-cli), its sign-in in [The realm](../../architecture/design/identity.md#the-realm), the layout in [Repositories](../../architecture/design/repositories.md#repository-layouts), and what B5 builds of it in [the local build plan](../../architecture/plan/local-build.md#b5-in-detail). How to run and build it is in the [README](README.md). The rules below are specific to this repository.

## Rules for this repository

- **Thin.** `agentctl` wraps existing tools and services and never holds more rights than the person running it. Anything that changes shared state goes through a merge request or a pipeline the person starts.
- **Never print a token.** Not in output, errors or logs; `agentctl token` printing one access token on standard output is the only exception. A refresh token is kept in the OS keychain, or in a file only its user can read ([D29](../../architecture/plan/open-items.md#close-by-decision)), and written atomically.
- **One refresh at a time.** A refresh token is usable once, and reusing one ends the session ([T20](../../architecture/research/2026-11-16-t20-keycloak-refresh-narrowing.md)): every read, refresh and write of it holds the lock, and every refresh names exactly one route scope.
- **Tests never reach the real tools or services.** External commands go through an injected runner or a fake on a test-only `PATH`; `kind`, `docker`, the keychain tools and the bootstrap are never run for real by a test. Never run `agentctl local down`, or `local up` against a live cluster, to test a change.
- **Exceptions, each gated on a variable and skipped without it:**
  - `conform`'s integration tests (`cmd/agentctl/conform_integration_test.go`) run the real `docker` with the runner image `environments` pins, and only when `AGENTCTL_INTEGRATION_ENVIRONMENTS` names a checkout of `environments`. They run no other command, and select only cases that skip before sending a request, so they never reach a deployment.
  - `install`'s integration test (`cmd/agentctl/install_integration_test.go`) runs the real `oras`, `cosign` and `docker` against a throwaway `registry:2` on a loopback port, with cosign keys it makes, only when `AGENTCTL_INTEGRATION_REGISTRY_IMAGE` names that image by digest. It never reaches floci or uses a platform key, and removes its container.
  - `harness setup`'s integration test (`cmd/agentctl/harness_integration_test.go`) runs Claude Code in a throwaway container from the Node.js image `AGENTCTL_INTEGRATION_NODE_IMAGE` names by digest, against a capture server of its own on loopback, and removes the container. **Never run `harness setup` on this machine:** managed settings are machine-wide and `~/.claude` is the build's own; Claude Code's checks run only in a throwaway container.
- **The spec is vendored.** `internal/spec/spec/` is a copy of `agent-sdk`'s `spec/`: refresh it with `internal/spec/vendor.sh`, never by hand, and keep its tests, which run every example and invalid file it holds.
- **Releases are reproducible and signed.** `scripts/build.sh` is the only way binaries are built; release tags `vX.Y.Z` sign them with the release key and publish them to the project's generic package registry ([Distribution](../../architecture/design/distribution.md#release-tags)). Tag only when asked.
- **Dependencies:** the standard library first. A new module needs its reason in the commit message, and a pinned version.

## Before committing

- `gofmt -l .` prints nothing, and `go vet ./...` and `go test -race ./...` pass.
- For a change to `conform` or `internal/conform`: `AGENTCTL_INTEGRATION_ENVIRONMENTS=<environments checkout> go test -run TestConformRealRunner ./cmd/agentctl` passes, and does not skip.
- For a change to `install`, `update`, `remove`, `internal/oci`, `internal/cosign` or `internal/lock`: `AGENTCTL_INTEGRATION_REGISTRY_IMAGE=<registry:2 by digest> go test -run TestInstallRealTools ./cmd/agentctl` passes, and does not skip.
- For a change to `harness setup` or `doctor`: `AGENTCTL_INTEGRATION_NODE_IMAGE=<the pinned Node.js image> go test -run TestHarnessRealClaudeCode ./cmd/agentctl` passes, and does not skip.
- `python3 ../../architecture/tools/check_docs.py .` reports no problems. It runs here, before committing, and not in CI, as in the other repositories: the pipeline has no architecture checkout to resolve the links against.
