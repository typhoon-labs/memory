module gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl

go 1.27.4

require (
	github.com/santhosh-tekuri/jsonschema/v6 v6.0.3
	go.yaml.in/yaml/v3 v3.0.6
	golang.org/x/text v0.14.0
)
