// Package validate checks the files a workload or library artifact
// carries, workload.yaml and artifact.yaml, and a workflow's step
// definitions, against agent-sdk's schemas. They are written as YAML and
// validated as the JSON they parse to (spec/schemas/README.md).
package validate

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"path/filepath"
	"strings"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// Kinds are the schemas validate knows by name.
var Kinds = map[string]string{
	"workload": spec.WorkloadSchema,
	"artifact": spec.ArtifactSchema,
	"step":     spec.StepSchema,
}

// KindOf names the schema for a file from its name: workload.yaml (or
// .yml, .json), artifact.yaml and step.yaml, or <name>.<kind>.yaml, as the
// spec names its vectors. It returns "" for any other name.
func KindOf(file string) string {
	base := strings.ToLower(filepath.Base(file))
	ext := filepath.Ext(base)
	switch ext {
	case ".yaml", ".yml", ".json":
	default:
		return ""
	}
	stem := strings.TrimSuffix(base, ext)
	for kind := range Kinds {
		if stem == kind || strings.HasSuffix(stem, "."+kind) {
			return kind
		}
	}
	return ""
}

// Decode parses one YAML document, or JSON, which is YAML too, into the
// JSON value it stands for: mappings with string keys, numbers as
// json.Number. More than one document, a key that is not a string, or a
// value JSON cannot hold is refused.
//
// So is an unquoted date. YAML 1.1 reads 2027-03-31 as a timestamp, as
// this parser and Python's PyYAML both do, and a timestamp is not the
// string the schemas' "format": "date" asks for: a file that passed here
// would then fail wherever a consumer reads it that way. Quoted, it is a
// string everywhere.
func Decode(data []byte) (any, error) {
	d := yaml.NewDecoder(bytes.NewReader(data))
	var doc yaml.Node
	if err := d.Decode(&doc); err != nil {
		if errors.Is(err, io.EOF) {
			return nil, errors.New("the file is empty")
		}
		return nil, err
	}
	var extra yaml.Node
	if err := d.Decode(&extra); !errors.Is(err, io.EOF) {
		return nil, errors.New("the file holds more than one YAML document")
	}
	if err := noTimestamps(&doc, "", 0); err != nil {
		return nil, err
	}
	var v any
	if err := doc.Decode(&v); err != nil {
		return nil, err
	}
	if err := jsonable(v, ""); err != nil {
		return nil, err
	}
	raw, err := json.Marshal(v)
	if err != nil {
		return nil, err
	}
	return spec.ParseJSON(raw)
}

// noTimestamps refuses a scalar YAML reads as a timestamp, naming where it
// is and how to write it instead.
func noTimestamps(n *yaml.Node, at string, depth int) error {
	if depth > 100 {
		return fmt.Errorf("%s: nested too deeply", where(at))
	}
	switch n.Kind {
	case yaml.DocumentNode, yaml.SequenceNode:
		for i, c := range n.Content {
			next := at
			if n.Kind == yaml.SequenceNode {
				next = fmt.Sprintf("%s/%d", at, i)
			}
			if err := noTimestamps(c, next, depth+1); err != nil {
				return err
			}
		}
	case yaml.MappingNode:
		for i := 0; i+1 < len(n.Content); i += 2 {
			if err := noTimestamps(n.Content[i+1], at+"/"+n.Content[i].Value, depth+1); err != nil {
				return err
			}
		}
	case yaml.ScalarNode:
		if n.Tag == "!!timestamp" {
			return fmt.Errorf("%s: %s is read by YAML as a timestamp, not a string: quote it, \"%s\"", where(at), n.Value, n.Value)
		}
	}
	return nil
}

// jsonable refuses what YAML can hold and JSON cannot.
func jsonable(v any, at string) error {
	switch x := v.(type) {
	case nil, bool, string, int, int64, uint64, float64:
		return nil
	case []any:
		for i, e := range x {
			if err := jsonable(e, fmt.Sprintf("%s/%d", at, i)); err != nil {
				return err
			}
		}
		return nil
	case map[string]any:
		for k, e := range x {
			if err := jsonable(e, at+"/"+k); err != nil {
				return err
			}
		}
		return nil
	case map[any]any:
		return fmt.Errorf("%s: a mapping with a key that is not a string", where(at))
	default:
		return fmt.Errorf("%s: a value JSON cannot hold (%T)", where(at), v)
	}
}

func where(at string) string {
	if at == "" {
		return "(the document)"
	}
	return at
}

// File validates one file's contents against a kind's schema.
func File(s *spec.Spec, kind string, data []byte) ([]spec.Problem, error) {
	schema, ok := Kinds[kind]
	if !ok {
		return nil, fmt.Errorf("unknown kind %q: use workload, artifact or step", kind)
	}
	v, err := Decode(data)
	if err != nil {
		return nil, err
	}
	return s.Validate(schema, v)
}
