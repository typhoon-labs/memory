package validate

import (
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"strings"
	"testing"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

func vendored(t *testing.T) *spec.Spec {
	t.Helper()
	s, err := spec.Vendored()
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func TestFixtures(t *testing.T) {
	s := vendored(t)
	cases := []struct {
		file, kind string
		valid      bool
		want       string // in the error or a problem, when invalid
	}{
		{"workload.yaml", "workload", true, ""},
		{"deprecated.workload.yaml", "workload", true, ""},
		{"artifact.yaml", "artifact", true, ""},
		{"release-notes.step.yaml", "step", true, ""},
		{"bad-date.workload.yaml", "workload", false, "/deprecation/removal_date"},
		{"runtime-in-name.workload.yaml", "workload", false, "/name"},
		{"destructive-at-l1.workload.yaml", "workload", false, "/conformance/level"},
		{"two-documents.workload.yaml", "workload", false, "more than one YAML document"},
		{"number-key.workload.yaml", "workload", false, "not a string"},
		{"unquoted-date.workload.yaml", "workload", false, `/deprecation/removal_date: 2027-03-31 is read by YAML as a timestamp, not a string: quote it, "2027-03-31"`},
	}
	for _, c := range cases {
		data, err := os.ReadFile(filepath.Join("testdata", c.file))
		if err != nil {
			t.Fatal(err)
		}
		if k := KindOf(c.file); k != c.kind {
			t.Errorf("%s: kind %q, want %q", c.file, k, c.kind)
		}
		problems, err := File(s, c.kind, data)
		var text string
		if err != nil {
			text = err.Error()
		}
		for _, p := range problems {
			text += p.String() + "\n"
		}
		valid := err == nil && len(problems) == 0
		if valid != c.valid {
			t.Errorf("%s: valid %v, want %v: %s", c.file, valid, c.valid, text)
		}
		if !c.valid && !strings.Contains(text, c.want) {
			t.Errorf("%s: %q does not mention %q", c.file, text, c.want)
		}
	}
}

// TestYAMLAgreesWithJSON writes every schemas/ and step/ test vector of
// the spec as YAML and checks that its verdict does not change, so the
// YAML path adds nothing and loses nothing.
func TestYAMLAgreesWithJSON(t *testing.T) {
	s := vendored(t)
	n := 0
	fs.WalkDir(s.FS, ".", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		dir := path.Dir(p)
		if !strings.HasPrefix(dir, "schemas/") && !strings.HasPrefix(dir, "step/") {
			return nil
		}
		parts := strings.Split(path.Base(p), ".")
		kind := parts[len(parts)-2]
		if _, ok := Kinds[kind]; !ok {
			return nil // step/'s failure objects are not files people write
		}
		raw, _ := fs.ReadFile(s.FS, p)
		jv, err := spec.ParseJSON(raw)
		if err != nil {
			t.Fatal(err)
		}
		var generic any
		yaml.Unmarshal(raw, &generic)
		y, err := yaml.Marshal(generic)
		if err != nil {
			t.Fatal(err)
		}
		fromJSON, _ := s.Validate(Kinds[kind], jv)
		fromYAML, err := File(s, kind, y)
		if err != nil {
			t.Errorf("%s as YAML: %v", p, err)
			return nil
		}
		if (len(fromJSON) == 0) != (len(fromYAML) == 0) {
			t.Errorf("%s: as JSON %d problems, as YAML %d", p, len(fromJSON), len(fromYAML))
		}
		n++
		return nil
	})
	if n < 30 {
		t.Fatalf("only %d vectors checked", n)
	}
}

func TestDecode(t *testing.T) {
	for in, want := range map[string]string{
		"":                                       "empty",
		"a: !!binary aGk=":                       "", // a string to JSON
		"when: !!timestamp 2027-01-01T00:00:00Z": "quote it",
		"when: [2027-01-01]":                     "/when/0: 2027-01-01 is read by YAML as a timestamp",
		"[1, {2: 3}]":                            "not a string",
	} {
		_, err := Decode([]byte(in))
		switch {
		case want == "" && err != nil:
			t.Errorf("%q: %v", in, err)
		case want != "" && (err == nil || !strings.Contains(err.Error(), want)):
			t.Errorf("%q: %v, want %q", in, err, want)
		}
	}
	v, err := Decode([]byte("n: 3\nf: 1.5\nd: '2027-03-31'\n"))
	if err != nil {
		t.Fatal(err)
	}
	m := v.(map[string]any)
	if m["d"] != "2027-03-31" {
		t.Errorf("a quoted date became %#v", m["d"])
	}
	if s, ok := m["n"].(interface{ String() string }); !ok || s.String() != "3" {
		t.Errorf("an integer became %#v", m["n"])
	}
}
