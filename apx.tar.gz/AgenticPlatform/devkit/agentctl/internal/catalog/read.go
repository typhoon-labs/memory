package catalog

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/cosign"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/s3"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// MaxIndex is the largest catalog.json or bundle agentctl reads.
const MaxIndex = 32 << 20

// Reader fetches the signed index and verifies it before anything reads
// it.
type Reader struct {
	Spec   *spec.Spec
	Cosign cosign.Cosign
	S3     s3.Client
	// HTTP fetches an https index; Header, when set, adds headers for a
	// URL, such as the person's GitLab token for GitLab's package
	// registry.
	HTTP   *http.Client
	Header func(u *url.URL, h http.Header)
	// Warn reports an index that was passed over, under an s3 prefix.
	Warn func(string)
}

// Verified is an index whose signature verified with the key, and where
// it came from.
type Verified struct {
	*Index
	From string
	// Bytes are catalog.json as verified.
	Bytes []byte
}

// Refused is an index agentctl will not read: its bundle does not verify
// with the key (Signature), or its content breaks the schema or the
// index's rules.
type Refused struct {
	From      string
	Signature bool
	Err       error
}

func (e *Refused) Error() string {
	return fmt.Sprintf("refusing the index %s: %v", e.From, e.Err)
}

func (e *Refused) Unwrap() error { return e.Err }

// Read fetches catalog.json and its bundle from a location and verifies
// the signature with key (a PEM path or KMS URI) before parsing it:
//
//   - a file path, or file://: the bundle is the file's name plus
//     .sigstore.json;
//   - https://…/catalog.json: the bundle beside it, the same way;
//   - s3://bucket/…/catalog.json: that object and its bundle;
//   - s3://bucket/prefix/, ending in a slash: the newest build under it,
//     indexes/<stamp>/catalog.json, whose signature verifies, as a
//     publisher takes it; each newer one that does not verify is named
//     through Warn.
//
// A single index whose signature does not verify is refused, as is one
// the schema refuses.
func (r *Reader) Read(ctx context.Context, location, key, environment string) (*Verified, error) {
	dir, err := os.MkdirTemp("", "agentctl-index-")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)

	if strings.HasPrefix(location, "s3://") {
		loc, err := s3.Parse(location)
		if err != nil {
			return nil, err
		}
		if loc.Key == "" || strings.HasSuffix(loc.Key, "/") {
			return r.newest(ctx, dir, loc, key, environment)
		}
		return r.one(ctx, dir, location, key, environment, func(name, dst string) error {
			k := loc.Key
			if name == BundleFile {
				k += BundleSuffix
			}
			return r.S3.Get(ctx, s3.Location{Bucket: loc.Bucket, Key: k}, dst)
		})
	}
	if strings.HasPrefix(location, "https://") {
		return r.one(ctx, dir, location, key, environment, func(name, dst string) error {
			u := location
			if name == BundleFile {
				u += BundleSuffix
			}
			return r.get(ctx, u, dst)
		})
	}
	if strings.Contains(location, "://") && !strings.HasPrefix(location, "file://") {
		return nil, fmt.Errorf("%q: the index is a file, an https:// URL or an s3:// location", location)
	}
	path := strings.TrimPrefix(location, "file://")
	return r.one(ctx, dir, path, key, environment, func(name, dst string) error {
		src := path
		if name == BundleFile {
			src += BundleSuffix
		}
		return copyFile(src, dst)
	})
}

// one fetches one index and its bundle with fetch, then verifies.
func (r *Reader) one(ctx context.Context, dir, from, key, environment string, fetch func(name, dst string) error) (*Verified, error) {
	index, bundle := filepath.Join(dir, IndexFile), filepath.Join(dir, BundleFile)
	if err := fetch(IndexFile, index); err != nil {
		return nil, err
	}
	if err := fetch(BundleFile, bundle); err != nil {
		return nil, fmt.Errorf("the index's signature: %w", err)
	}
	return r.verify(ctx, from, index, bundle, key, environment)
}

func (r *Reader) verify(ctx context.Context, from, index, bundle, key, environment string) (*Verified, error) {
	data, err := readLimited(index)
	if err != nil {
		return nil, err
	}
	if err := r.Cosign.VerifyBlob(ctx, key, bundle, index); err != nil {
		if cosign.IsRefused(err) {
			return nil, &Refused{From: from, Signature: true, Err: err}
		}
		return nil, err
	}
	// cosign verified the file; parse the same bytes, read before it ran
	// and checked against the file again after.
	again, err := readLimited(index)
	if err != nil {
		return nil, err
	}
	if string(again) != string(data) {
		return nil, fmt.Errorf("%s changed while it was verified", index)
	}
	ix, err := Parse(r.Spec, data, environment)
	if err != nil {
		return nil, &Refused{From: from, Err: err}
	}
	return &Verified{Index: ix, From: from, Bytes: data}, nil
}

// newest lists the builds under a prefix and takes the newest that
// verifies.
func (r *Reader) newest(ctx context.Context, dir string, loc s3.Location, key, environment string) (*Verified, error) {
	keys, err := r.S3.List(ctx, loc.Bucket, loc.Key)
	if err != nil {
		return nil, err
	}
	have := map[string]bool{}
	for _, k := range keys {
		have[k] = true
	}
	var builds []string
	for _, k := range keys {
		rest := strings.TrimPrefix(k, loc.Key)
		stamp, file, ok := strings.Cut(rest, "/")
		if !ok || file != IndexFile {
			continue
		}
		if _, err := time.Parse(StampLayout, stamp); err != nil {
			continue
		}
		builds = append(builds, k)
	}
	if len(builds) == 0 {
		return nil, fmt.Errorf("no index under s3://%s/%s", loc.Bucket, loc.Key)
	}
	sort.Sort(sort.Reverse(sort.StringSlice(builds)))
	var refused []error
	for _, k := range builds {
		from := "s3://" + loc.Bucket + "/" + k
		if !have[k+BundleSuffix] {
			r.warn(fmt.Sprintf("passing over %s: it has no %s beside it", from, BundleFile))
			refused = append(refused, fmt.Errorf("%s: no bundle", from))
			continue
		}
		sub, err := os.MkdirTemp(dir, "build-")
		if err != nil {
			return nil, err
		}
		v, err := r.one(ctx, sub, from, key, environment, func(name, dst string) error {
			kk := k
			if name == BundleFile {
				kk += BundleSuffix
			}
			return r.S3.Get(ctx, s3.Location{Bucket: loc.Bucket, Key: kk}, dst)
		})
		if err == nil {
			// The prefix's time is not signed; the index's timestamp is. A
			// valid older index copied under a newer prefix would otherwise
			// pass for the newest.
			stamp := strings.TrimSuffix(strings.TrimPrefix(k, loc.Key), "/"+IndexFile)
			ts, perr := time.Parse(time.RFC3339, v.Timestamp)
			if perr == nil && ts.UTC().Format(StampLayout) == stamp {
				return v, nil
			}
			err = &Refused{From: from, Err: fmt.Errorf("its prefix says %s and its signed timestamp %s: a copy of another build", stamp, v.Timestamp)}
		}
		var rf *Refused
		if !errors.As(err, &rf) {
			return nil, err
		}
		r.warn("passing over " + err.Error())
		refused = append(refused, err)
	}
	return nil, fmt.Errorf("no index under s3://%s/%s verifies with the record key: %w", loc.Bucket, loc.Key, errors.Join(refused...))
}

func (r *Reader) warn(s string) {
	if r.Warn != nil {
		r.Warn(s)
	}
}

func (r *Reader) get(ctx context.Context, u, dst string) error {
	pu, err := url.Parse(u)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return err
	}
	if r.Header != nil {
		r.Header(pu, req.Header)
	}
	hc := r.HTTP
	if hc == nil {
		hc = http.DefaultClient
	}
	resp, err := hc.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("GET %s: %s", pu.Redacted(), resp.Status)
	}
	return writeLimited(dst, resp.Body)
}

func copyFile(src, dst string) error {
	f, err := os.Open(src)
	if err != nil {
		return err
	}
	defer f.Close()
	return writeLimited(dst, f)
}

func writeLimited(dst string, r io.Reader) error {
	f, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if err != nil {
		return err
	}
	n, err := io.Copy(f, io.LimitReader(r, MaxIndex+1))
	if cerr := f.Close(); err == nil {
		err = cerr
	}
	if err == nil && n > MaxIndex {
		err = fmt.Errorf("larger than %d bytes", MaxIndex)
	}
	return err
}

func readLimited(p string) ([]byte, error) {
	f, err := os.Open(p)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, MaxIndex+1))
	if err == nil && len(data) > MaxIndex {
		err = fmt.Errorf("%s is larger than %d bytes", p, MaxIndex)
	}
	return data, err
}
