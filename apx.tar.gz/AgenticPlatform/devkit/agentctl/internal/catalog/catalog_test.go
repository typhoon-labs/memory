package catalog

import (
	"encoding/json"
	"io/fs"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

func example(t *testing.T) (*spec.Spec, map[string]any) {
	t.Helper()
	s, err := spec.Vendored()
	if err != nil {
		t.Fatal(err)
	}
	b, err := fs.ReadFile(s.FS, "schemas/examples/local.catalog.json")
	if err != nil {
		t.Fatal(err)
	}
	var v map[string]any
	json.Unmarshal(b, &v)
	return s, v
}

func TestParse(t *testing.T) {
	s, v := example(t)
	b, _ := json.Marshal(v)
	ix, err := Parse(s, b, "local")
	if err != nil {
		t.Fatal(err)
	}
	if len(ix.Entries) != 6 || ix.Find("platform-conventions").Kind() != "skill" || !ix.Find("summarise-changes").IsArtifact() || ix.Find("reference-mcp").IsArtifact() {
		t.Fatalf("%+v", ix)
	}
	got := ix.Search([]string{"REFERENCE"}, Filter{Kind: "agent"})
	if len(got) != 2 || got[0].Name() != "reference-agent" || got[1].Name() != "reference-notes-agent" {
		t.Errorf("search: %v", got)
	}

	// An artifact whose file says another version than its entry.
	entries := v["entries"].([]any)
	entries[4].(map[string]any)["metadata"].(map[string]any)["version"] = "0.2.0"
	b, _ = json.Marshal(v)
	if _, err := Parse(s, b, "local"); err == nil || !strings.Contains(err.Error(), "not the entry's") {
		t.Errorf("version mismatch: %v", err)
	}
}

func TestRouteURL(t *testing.T) {
	if got := RouteURL("https://gateway.agentic.internal/", "gateway/mcp/reference-mcp"); got != "https://gateway.agentic.internal/mcp/reference-mcp" {
		t.Errorf("%q", got)
	}
}
