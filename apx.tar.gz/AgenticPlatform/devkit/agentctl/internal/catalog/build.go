package catalog

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/gitlab"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/validate"
)

// The registrations' roles whose projects the catalog is built from
// (D41): every registered workload's release role, and every registered
// library's.
const (
	WorkloadRole = "ci-workload-release"
	LibraryRole  = "ci-library-release"
)

// Registered is one registered project.
type Registered struct {
	ID   int64  `yaml:"id"`
	Path string `yaml:"path"`
}

// Registrations are the projects the catalog reads, by role.
type Registrations struct {
	Workloads, Libraries []Registered
}

// ParseRegistrations reads aws-foundation's registrations/<stack>.yaml:
// role names to the projects, by numeric ID, each role trusts.
func ParseRegistrations(data []byte) (*Registrations, error) {
	var m map[string][]Registered
	if err := yaml.Unmarshal(data, &m); err != nil {
		return nil, fmt.Errorf("the registrations: %w", err)
	}
	r := &Registrations{Workloads: m[WorkloadRole], Libraries: m[LibraryRole]}
	for _, p := range append(append([]Registered{}, r.Workloads...), r.Libraries...) {
		if p.ID < 1 {
			return nil, fmt.Errorf("the registrations name a project without a numeric ID (%q)", p.Path)
		}
	}
	return r, nil
}

// ParseTeams reads environments' access/teams.yaml: the team slugs.
func ParseTeams(data []byte) (map[string]bool, error) {
	var f struct {
		Teams []struct {
			Slug string `yaml:"slug"`
		} `yaml:"teams"`
	}
	if err := yaml.Unmarshal(data, &f); err != nil {
		return nil, fmt.Errorf("teams.yaml: %w", err)
	}
	teams := map[string]bool{}
	for _, t := range f.Teams {
		if t.Slug != "" {
			teams[t.Slug] = true
		}
	}
	if len(teams) == 0 {
		return nil, errors.New("teams.yaml names no team")
	}
	return teams, nil
}

// Files is the GitLab a build reads from, by its job token.
type Files interface {
	RawFile(ctx context.Context, project, path, ref string) ([]byte, error)
	Tags(ctx context.Context, project string) ([]gitlab.Tag, error)
}

// Builder builds one environment's index from the registered projects.
type Builder struct {
	Spec   *spec.Spec
	GitLab Files
	// Registry is the environment's registry.host.
	Registry string
	// Resolve returns the digest a tag in a repository under Registry
	// points at.
	Resolve func(ctx context.Context, repository, tag string) (string, error)
	// Verify, when set, checks a release's signature on its reference;
	// an entry that fails it is refused.
	Verify func(ctx context.Context, ref string) error
	// Released, when set, reads a library artifact's own artifact.yaml
	// from its release, as released, with the provenance CI filled.
	Released func(ctx context.Context, ref string) ([]byte, error)
	Teams    map[string]bool
}

// Refusal is a release, or a whole project, left out of the index, and
// why.
type Refusal struct {
	Project int64  `json:"project_id"`
	Tag     string `json:"tag,omitempty"`
	Name    string `json:"name,omitempty"`
	Reason  string `json:"reason"`
}

func (r Refusal) String() string {
	s := fmt.Sprintf("project %d", r.Project)
	if r.Tag != "" {
		s += " tag " + r.Tag
	}
	if r.Name != "" {
		s += " (" + r.Name + ")"
	}
	return s + ": " + r.Reason
}

var (
	workloadTagRE = regexp.MustCompile(`^v(\d+)\.(\d+)\.(\d+)$`)
	artifactTagRE = regexp.MustCompile(`^(skill|prompt|workflow|plugin)/([a-z0-9]+(?:-[a-z0-9]+)*)/v(\d+)\.(\d+)\.(\d+)$`)
)

type semver [3]int

func parseSemver(parts []string) semver {
	var v semver
	for i := range 3 {
		v[i], _ = strconv.Atoi(parts[i])
	}
	return v
}

func (a semver) less(b semver) bool {
	for i := range 3 {
		if a[i] != b[i] {
			return a[i] < b[i]
		}
	}
	return false
}

func (a semver) String() string { return fmt.Sprintf("%d.%d.%d", a[0], a[1], a[2]) }

// Build reads each registered project's newest release of each workload
// or artifact, checks it, and returns the index of those that pass,
// with each one left out and why. The index holds one release of each
// name; a name two sources give is refused from both.
func (b *Builder) Build(ctx context.Context, regs *Registrations, environment string, build json.RawMessage, now time.Time) (*Index, []Refusal, error) {
	var entries []Entry
	var refused []Refusal
	for _, p := range regs.Workloads {
		e, r, err := b.workload(ctx, p)
		if err != nil {
			return nil, nil, err
		}
		entries, refused = append(entries, e...), append(refused, r...)
	}
	for _, p := range regs.Libraries {
		e, r, err := b.library(ctx, p)
		if err != nil {
			return nil, nil, err
		}
		entries, refused = append(entries, e...), append(refused, r...)
	}

	// A name given twice: neither source is trusted with it.
	count := map[string]int{}
	for _, e := range entries {
		count[e.Name()]++
	}
	var kept []Entry
	for _, e := range entries {
		if count[e.Name()] > 1 {
			refused = append(refused, Refusal{Project: e.Source.ProjectID, Tag: e.Source.Tag, Name: e.Name(), Reason: fmt.Sprintf("the name %s is taken %d times across the registered projects", e.Name(), count[e.Name()])})
			continue
		}
		kept = append(kept, e)
	}
	sort.Slice(kept, func(i, j int) bool { return kept[i].Name() < kept[j].Name() })
	if kept == nil {
		kept = []Entry{}
	}
	ix := &Index{Timestamp: now.UTC().Format(time.RFC3339), Environment: environment, Build: build, Entries: kept}
	if err := ix.Check(); err != nil {
		return nil, nil, err
	}
	return ix, refused, nil
}

// Unreadable is a registered project the job cannot read: not there, or
// its job token allowlist does not admit the catalog's project. The build
// fails closed on it and publishes nothing, since leaving the project out
// would withdraw every entry it has.
type Unreadable struct {
	Project int64
	What    string
	Status  int
}

func (u *Unreadable) Error() string {
	return fmt.Sprintf("registered project %d: the job cannot read %s (%d): is it there, and does its job token allowlist admit the catalog's project? Nothing is published", u.Project, u.What, u.Status)
}

func accessStatus(err error) int {
	for _, s := range []int{http.StatusUnauthorized, http.StatusForbidden, http.StatusNotFound} {
		if gitlab.IsStatus(err, s) {
			return s
		}
	}
	return 0
}

// readFile reads a file at a tag; a missing one is reported, not fatal,
// but one the job may not read is Unreadable.
func (b *Builder) readFile(ctx context.Context, project int64, path, ref string) ([]byte, string, error) {
	data, err := b.GitLab.RawFile(ctx, strconv.FormatInt(project, 10), path, ref)
	switch s := accessStatus(err); {
	case s == http.StatusNotFound:
		return nil, fmt.Sprintf("no %s at %s", path, ref), nil
	case s != 0:
		return nil, "", &Unreadable{Project: project, What: path + " at " + ref, Status: s}
	case err != nil:
		return nil, "", err
	}
	return data, "", nil
}

// checked decodes and validates one file against its schema.
func (b *Builder) checked(data []byte, schema string) (map[string]any, string) {
	v, err := validate.Decode(data)
	if err != nil {
		return nil, err.Error()
	}
	problems, err := b.Spec.Validate(schema, v)
	if err != nil {
		return nil, err.Error()
	}
	if len(problems) > 0 {
		return nil, fmt.Sprintf("does not match %s: %s", schema, problems[0])
	}
	m, _ := v.(map[string]any)
	return m, ""
}

func (b *Builder) tags(ctx context.Context, p Registered) ([]gitlab.Tag, error) {
	tags, err := b.GitLab.Tags(ctx, strconv.FormatInt(p.ID, 10))
	if s := accessStatus(err); s != 0 {
		return nil, &Unreadable{Project: p.ID, What: "its tags", Status: s}
	}
	return tags, err
}

func (b *Builder) reference(ctx context.Context, repository, tag string) (string, string) {
	d, err := b.Resolve(ctx, repository, tag)
	if err != nil {
		return "", fmt.Sprintf("%s/%s:%s is not in the registry: %v", b.Registry, repository, tag, err)
	}
	ref := b.Registry + "/" + repository + "@" + d
	if b.Verify != nil {
		if err := b.Verify(ctx, ref); err != nil {
			return "", fmt.Sprintf("%s is not signed by the release key: %v", ref, err)
		}
	}
	return ref, ""
}

// MaxFallback bounds how many older releases of one name a build tries
// when the newer ones fail a check.
const MaxFallback = 10

type release struct {
	tag        gitlab.Tag
	v          semver
	kind, name string // a library artifact's, from its tag
}

func newestFirst(rs []release) {
	sort.Slice(rs, func(i, j int) bool { return rs[j].v.less(rs[i].v) })
}

// pick takes the newest release that passes its checks, trying older
// ones while the newer fail, so a release that is not ready yet (not
// signed, its files wrong) never removes an entry its predecessor
// holds. Each newer one that failed is reported, naming the release
// kept. A withdrawal (a retired workload) ends the entry, and nothing
// older than it is tried.
func pick(p Registered, rs []release, try func(release) (*Entry, bool, string, error)) (*Entry, []Refusal, error) {
	var failed []Refusal
	for i, r := range rs {
		if i == MaxFallback {
			break
		}
		e, withdrawn, why, err := try(r)
		if err != nil {
			return nil, nil, err
		}
		if withdrawn {
			// The latest release that passes withdrew the entry: nothing
			// older brings it back.
			for j := range failed {
				failed[j].Reason += "; " + r.tag.Name + " withdrew it"
			}
			return nil, failed, nil
		}
		if e != nil {
			for j := range failed {
				failed[j].Reason += "; the index keeps " + r.tag.Name
			}
			return e, failed, nil
		}
		failed = append(failed, Refusal{Project: p.ID, Tag: r.tag.Name, Name: r.name, Reason: why})
	}
	for j := range failed {
		failed[j].Reason += "; no earlier release passes"
	}
	return nil, failed, nil
}

// workload is a workload project's newest vX.Y.Z release that passes.
func (b *Builder) workload(ctx context.Context, p Registered) ([]Entry, []Refusal, error) {
	tags, err := b.tags(ctx, p)
	if err != nil {
		return nil, nil, err
	}
	var rs []release
	for _, t := range tags {
		if m := workloadTagRE.FindStringSubmatch(t.Name); m != nil {
			rs = append(rs, release{tag: t, v: parseSemver(m[1:])})
		}
	}
	newestFirst(rs)
	e, refused, err := pick(p, rs, func(r release) (*Entry, bool, string, error) {
		return b.workloadRelease(ctx, p, r)
	})
	if e == nil || err != nil {
		return nil, refused, err
	}
	return []Entry{*e}, refused, nil
}

func (b *Builder) workloadRelease(ctx context.Context, p Registered, r release) (*Entry, bool, string, error) {
	data, why, err := b.readFile(ctx, p.ID, WorkloadFile, r.tag.Name)
	if err != nil || why != "" {
		return nil, false, why, err
	}
	m, why := b.checked(data, spec.WorkloadSchema)
	if why != "" {
		return nil, false, WorkloadFile + " " + why, nil
	}
	name, _ := m["name"].(string)
	owner, _ := m["owner"].(string)
	kind, _ := m["kind"].(string)
	if s, _ := m["support"].(string); s == "retired" {
		return nil, true, "", nil
	}
	if !b.Teams[owner] {
		return nil, false, fmt.Sprintf("its owner %q is not a team in access/teams.yaml", owner), nil
	}
	e := &Entry{File: WorkloadFile, Version: r.v.String(), Source: Source{ProjectID: p.ID, Tag: r.tag.Name, Commit: r.tag.Commit.ID}, Metadata: m}
	switch kind {
	case "agent":
		e.Route = "gateway/a2a/" + name
	case "mcp-server":
		e.Route = "gateway/mcp/" + name
	}
	if kind != "workflow" {
		ref, why := b.reference(ctx, "workloads/"+owner+"/"+name, r.tag.Name)
		if why != "" {
			return nil, false, why, nil
		}
		e.Reference = ref
	}
	return e, false, "", nil
}

// library is a library project's newest release that passes, of each
// artifact.
func (b *Builder) library(ctx context.Context, p Registered) ([]Entry, []Refusal, error) {
	tags, err := b.tags(ctx, p)
	if err != nil {
		return nil, nil, err
	}
	byName := map[string][]release{}
	for _, t := range tags {
		m := artifactTagRE.FindStringSubmatch(t.Name)
		if m == nil {
			continue
		}
		k := m[1] + "/" + m[2]
		byName[k] = append(byName[k], release{tag: t, v: parseSemver(m[3:]), kind: m[1], name: m[2]})
	}
	keys := make([]string, 0, len(byName))
	for k := range byName {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var entries []Entry
	var refused []Refusal
	for _, k := range keys {
		rs := byName[k]
		newestFirst(rs)
		e, r, err := pick(p, rs, func(r release) (*Entry, bool, string, error) {
			return b.artifactRelease(ctx, p, r)
		})
		if err != nil {
			return nil, nil, err
		}
		refused = append(refused, r...)
		if e != nil {
			entries = append(entries, *e)
		}
	}
	return entries, refused, nil
}

func (b *Builder) artifactRelease(ctx context.Context, p Registered, r release) (*Entry, bool, string, error) {
	data, why, err := b.readFile(ctx, p.ID, "library.yaml", r.tag.Name)
	if err != nil || why != "" {
		return nil, false, why, err
	}
	lib, why := b.checked(data, spec.LibrarySchema)
	if why != "" {
		return nil, false, "library.yaml " + why, nil
	}
	tier, _ := lib["tier"].(string)
	prefix, _ := lib["prefix"].(string)
	if lo, _ := lib["owner"].(string); !b.Teams[lo] {
		return nil, false, fmt.Sprintf("the library's owner %q is not a team in access/teams.yaml", lo), nil
	}
	dir := r.kind + "s/" + r.name
	data, why, err = b.readFile(ctx, p.ID, dir+"/"+ArtifactFile, r.tag.Name)
	if err != nil || why != "" {
		return nil, false, why, err
	}
	art, why := b.checked(data, spec.ArtifactSchema)
	if why != "" {
		return nil, false, dir + "/" + ArtifactFile + " " + why, nil
	}
	if art["kind"] != r.kind || art["name"] != r.name || art["version"] != r.v.String() {
		return nil, false, fmt.Sprintf("the tag is %s %s %s, and %s/%s says %v %v %v", r.kind, r.name, r.v, dir, ArtifactFile, art["kind"], art["name"], art["version"]), nil
	}
	owner, _ := art["owner"].(string)
	if !b.Teams[owner] {
		return nil, false, fmt.Sprintf("its owner %q is not a team in access/teams.yaml", owner), nil
	}
	if tier == "team" && !strings.HasPrefix(r.name, prefix+"-") {
		return nil, false, fmt.Sprintf("a team library's artifacts are named %s-<name>", prefix), nil
	}
	ref, why := b.reference(ctx, "library/"+r.kind+"/"+r.name, "v"+r.v.String())
	if why != "" {
		return nil, false, why, nil
	}
	// The file as released: the one in the artifact, with the provenance
	// CI filled, which must name the tag's commit.
	md := art
	if b.Released != nil {
		raw, err := b.Released(ctx, ref)
		if err != nil {
			return nil, false, fmt.Sprintf("its release %s cannot be read: %v", ref, err), nil
		}
		rel, why := b.checked(raw, spec.ArtifactSchema)
		if why != "" {
			return nil, false, "the released artifact.yaml " + why, nil
		}
		prov, _ := rel["provenance"].(map[string]any)
		if rel["kind"] != r.kind || rel["name"] != r.name || rel["version"] != r.v.String() || prov["commit"] != r.tag.Commit.ID {
			return nil, false, fmt.Sprintf("the released artifact.yaml is not the tag's: %v %v %v from commit %v", rel["kind"], rel["name"], rel["version"], prov["commit"]), nil
		}
		md = rel
	}
	return &Entry{File: ArtifactFile, Version: r.v.String(), Tier: tier,
		Source:    Source{ProjectID: p.ID, Tag: r.tag.Name, Commit: r.tag.Commit.ID, Path: dir},
		Reference: ref, Metadata: md}, false, "", nil
}

// Marshal writes the index as the build publishes it, and checks it
// against the schema first.
func Marshal(s *spec.Spec, ix *Index) ([]byte, error) {
	data, err := json.MarshalIndent(ix, "", "  ")
	if err != nil {
		return nil, err
	}
	data = append(data, '\n')
	if _, err := Parse(s, data, ix.Environment); err != nil {
		return nil, fmt.Errorf("not writing an index the spec refuses: %w", err)
	}
	return data, nil
}

// ReleasedArtifactFile reads artifact.yaml from an unpacked artifact.
func ReleasedArtifactFile(dir string) ([]byte, error) {
	return os.ReadFile(filepath.Join(dir, ArtifactFile))
}
