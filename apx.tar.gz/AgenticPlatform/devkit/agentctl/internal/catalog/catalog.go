// Package catalog is the catalog index for agentctl: catalog.json, as
// agent-sdk's spec/schemas/catalog.schema.json defines it, signed as a
// blob with the environment's record key (D37). search, show, install,
// update and remove read it; catalog build writes it, and catalog publish
// applies it to Agentregistry.
package catalog

import (
	"encoding/json"
	"fmt"
	"slices"
	"sort"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
)

// Files of one build of the index, under one prefix of the bucket.
const (
	IndexFile    = "catalog.json"
	BundleSuffix = ".sigstore.json"
	BundleFile   = IndexFile + BundleSuffix
	PagesFile    = "index.html"
	// IndexesPrefix is where each build's files go in the index bucket:
	// indexes/<UTC time, 20060102T150405Z>/, a new prefix for every build,
	// since Object Lock keeps every object version anyway.
	IndexesPrefix = "indexes/"
	StampLayout   = "20060102T150405Z"
)

// Index is one environment's catalog index.
type Index struct {
	Timestamp   string          `json:"timestamp"`
	Environment string          `json:"environment"`
	Build       json.RawMessage `json:"build"`
	Entries     []Entry         `json:"entries"`
}

// Entry is one release in the index.
type Entry struct {
	File      string         `json:"file"`
	Version   string         `json:"version"`
	Tier      string         `json:"tier,omitempty"`
	Source    Source         `json:"source"`
	Reference string         `json:"reference,omitempty"`
	Route     string         `json:"route,omitempty"`
	Metadata  map[string]any `json:"metadata"`
}

// Source is the registered project, tag and commit an entry came from.
type Source struct {
	ProjectID int64  `json:"project_id"`
	Tag       string `json:"tag"`
	Commit    string `json:"commit"`
	Path      string `json:"path,omitempty"`
}

// The files an entry can come from.
const (
	WorkloadFile = "workload.yaml"
	ArtifactFile = "artifact.yaml"
)

func (e Entry) str(k string) string {
	s, _ := e.Metadata[k].(string)
	return s
}

// Name is the entry's name, unique across the index.
func (e Entry) Name() string { return e.str("name") }

// Kind is workload.yaml's kind (agent, mcp-server, workflow) or
// artifact.yaml's (skill, prompt, workflow, plugin).
func (e Entry) Kind() string { return e.str("kind") }

// Owner is the owning team.
func (e Entry) Owner() string { return e.str("owner") }

// Support is the support status.
func (e Entry) Support() string { return e.str("support") }

// Description is the entry's description, if any.
func (e Entry) Description() string { return e.str("description") }

// IsArtifact reports whether the entry is a library artifact, which
// install takes.
func (e Entry) IsArtifact() bool { return e.File == ArtifactFile }

// Parse checks catalog.json against the spec's schema, then the rules the
// schema cannot hold: one environment, names unique across the index,
// and an artifact's version equal to its entry's.
func Parse(s *spec.Spec, data []byte, environment string) (*Index, error) {
	v, err := spec.ParseJSON(data)
	if err != nil {
		return nil, fmt.Errorf("%s: %w", IndexFile, err)
	}
	problems, err := s.Validate(spec.CatalogSchema, v)
	if err != nil {
		return nil, err
	}
	if len(problems) > 0 {
		return nil, &Invalid{Problems: problems}
	}
	var ix Index
	d := json.NewDecoder(strings.NewReader(string(data)))
	d.UseNumber()
	if err := d.Decode(&ix); err != nil {
		return nil, fmt.Errorf("%s: %w", IndexFile, err)
	}
	if environment != "" && ix.Environment != environment {
		return nil, fmt.Errorf("the index is %s's, not %s's", ix.Environment, environment)
	}
	if err := ix.Check(); err != nil {
		return nil, err
	}
	return &ix, nil
}

// Check holds the rules a JSON Schema cannot: names unique, and an
// artifact's version equal to its entry's.
func (ix *Index) Check() error {
	seen := map[string]bool{}
	for i := range ix.Entries {
		e := &ix.Entries[i]
		if seen[e.Name()] {
			return fmt.Errorf("the index names %q twice", e.Name())
		}
		seen[e.Name()] = true
		if e.IsArtifact() && e.str("version") != e.Version {
			return fmt.Errorf("%s: artifact.yaml's version %q is not the entry's %q", e.Name(), e.str("version"), e.Version)
		}
	}
	return nil
}

// Invalid is an index the schema refuses.
type Invalid struct{ Problems []spec.Problem }

func (i *Invalid) Error() string {
	var b strings.Builder
	b.WriteString("the index does not match spec/schemas/catalog.schema.json:")
	for _, p := range i.Problems {
		b.WriteString("\n  " + p.String())
	}
	return b.String()
}

// Find returns the entry with a name, or nil.
func (ix *Index) Find(name string) *Entry {
	for i := range ix.Entries {
		if ix.Entries[i].Name() == name {
			return &ix.Entries[i]
		}
	}
	return nil
}

// Filter narrows a search.
type Filter struct {
	Kind, Owner, Tier string
}

// Search returns the entries whose name, kind, owner or description holds
// every term, case-insensitively, sorted by name.
func (ix *Index) Search(terms []string, f Filter) []Entry {
	var out []Entry
	for _, e := range ix.Entries {
		if f.Kind != "" && e.Kind() != f.Kind {
			continue
		}
		if f.Owner != "" && e.Owner() != f.Owner {
			continue
		}
		if f.Tier != "" && e.Tier != f.Tier {
			continue
		}
		hay := strings.ToLower(strings.Join([]string{e.Name(), e.Kind(), e.Owner(), e.Description()}, " "))
		if !slices.ContainsFunc(terms, func(t string) bool { return !strings.Contains(hay, strings.ToLower(t)) }) {
			out = append(out, e)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name() < out[j].Name() })
	return out
}

// RouteURL is an entry's route as a URL on its gateway: gateway/mcp/x on
// https://gateway.<domain> is https://gateway.<domain>/mcp/x.
func RouteURL(gatewayURL, route string) string {
	_, rest, ok := strings.Cut(route, "/")
	if !ok {
		return ""
	}
	return strings.TrimSuffix(gatewayURL, "/") + "/" + rest
}
