// Package local builds and removes the local build's platform by wrapping
// environments' own tools (design/distribution.md, "agentctl, the thin
// organization CLI"): up runs clusters/local/00-local/bootstrap.sh from a
// checkout of environments at a pinned commit; down deletes the kind
// cluster and stops floci with docker compose stop, never docker kill,
// since floci's hybrid storage flushes on a clean shutdown (environments'
// AGENTS.md).
package local

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

const (
	// EnvironmentsCommit is THE PIN: the environments commit local up runs
	// the bootstrap from, and whose versions.yaml conform reads. Today
	// main's merge commit 3b145e4 of 2026-11-18, B5's close: the platform
	// with the workload charts at their 0.1.0 releases, CoreDNS serving
	// stale answers, and the disk guard removing digest-pulled images. It
	// is bumped by a merge request here with each release that needs a
	// newer platform.
	EnvironmentsCommit = "3b145e438f23c9f16f53758e7c0920264f658d19"
	// EnvironmentsSource is where agentctl clones environments from: the
	// sandbox group until the swap to dev. AGENTCTL_ENVIRONMENTS_SOURCE
	// overrides it.
	EnvironmentsSource = "git@gitlab.com:typhoon_labs/agentic-platform-sandbox/infra/environments.git"

	Cluster      = "agentic-local"
	Bootstrap    = "clusters/local/00-local/bootstrap.sh"
	FlociCompose = "clusters/local/00-local/floci/compose.yaml"
)

var fullSHA = regexp.MustCompile(`^[0-9a-f]{40}$`)

// CheckCommit accepts a full commit SHA, the only form a pin takes.
func CheckCommit(c string) error {
	if !fullSHA.MatchString(c) {
		return fmt.Errorf("%q is not a full commit SHA", c)
	}
	return nil
}

func git(ctx context.Context, r execx.Runner, dir string, args ...string) (string, error) {
	out, err := execx.Output(ctx, r, execx.Cmd{Name: "git", Args: append([]string{"-C", dir}, args...)})
	return strings.TrimSpace(string(out)), err
}

// Verify requires dir to be a checkout of commit with no changes to
// tracked files.
func Verify(ctx context.Context, r execx.Runner, dir, commit string) error {
	head, err := git(ctx, r, dir, "rev-parse", "--verify", "HEAD^{commit}")
	if err != nil {
		return fmt.Errorf("%s is not a checkout of environments: %w", dir, err)
	}
	if head != commit {
		return fmt.Errorf("%s is at %s, not the pinned %s: check out the pin, or pass -commit", dir, head, commit)
	}
	status, err := git(ctx, r, dir, "status", "--porcelain", "--untracked-files=no")
	if err != nil {
		return err
	}
	if status != "" {
		return fmt.Errorf("%s has changes to tracked files; the bootstrap runs from the pinned commit as it is", dir)
	}
	return nil
}

// Prepare makes dir a clean checkout of commit, cloning source into it
// when it is missing and fetching when the commit is not there yet. dir is
// agentctl's own: it is moved to commit whatever it held.
func Prepare(ctx context.Context, r execx.Runner, dir, source, commit string, log io.Writer) error {
	if _, err := os.Stat(filepath.Join(dir, ".git")); errors.Is(err, os.ErrNotExist) {
		if err := os.MkdirAll(filepath.Dir(dir), 0o755); err != nil {
			return err
		}
		fmt.Fprintf(log, "Cloning %s into %s\n", source, dir)
		if _, err := execx.Output(ctx, r, execx.Cmd{Name: "git", Args: []string{"clone", "--quiet", "--no-checkout", source, dir}}); err != nil {
			return err
		}
	}
	if _, err := git(ctx, r, dir, "cat-file", "-e", commit+"^{commit}"); err != nil {
		fmt.Fprintf(log, "Fetching %s\n", source)
		if _, err := git(ctx, r, dir, "fetch", "--quiet", "origin"); err != nil {
			return err
		}
		if _, err := git(ctx, r, dir, "cat-file", "-e", commit+"^{commit}"); err != nil {
			return fmt.Errorf("%s has no commit %s", source, commit)
		}
	}
	// Always: a clone made with --no-checkout has HEAD at the commit and
	// no files yet, and the checkout is agentctl's, so nothing is lost.
	if _, err := git(ctx, r, dir, "-c", "advice.detachedHead=false", "checkout", "--quiet", "--force", "--detach", commit); err != nil {
		return err
	}
	return Verify(ctx, r, dir, commit)
}

// Up runs the bootstrap from the checkout, with agentctl's environment
// unchanged: the bootstrap unsets the proxy variables itself where kind
// needs them unset, and its GitLab and download steps may need them set.
// It returns the bootstrap's exit status.
func Up(ctx context.Context, r execx.Runner, dir string, stdin io.Reader, stdout, stderr io.Writer) (int, error) {
	script := filepath.Join(dir, Bootstrap)
	if _, err := os.Stat(script); err != nil {
		return -1, fmt.Errorf("the checkout has no %s", Bootstrap)
	}
	return r.Run(ctx, execx.Cmd{Name: script, Dir: dir, Stdin: stdin, Stdout: stdout, Stderr: stderr})
}

// Down deletes the cluster, then stops floci's containers with docker
// compose stop. It runs both even when the first fails, and reports
// each.
func Down(ctx context.Context, r execx.Runner, dir string, stdout, stderr io.Writer) error {
	compose := filepath.Join(dir, FlociCompose)
	var errs []error
	status, err := r.Run(ctx, execx.Cmd{Name: "kind", Args: []string{"delete", "cluster", "--name", Cluster}, Stdout: stdout, Stderr: stderr})
	if err == nil && status != 0 {
		err = fmt.Errorf("kind delete cluster exited with status %d", status)
	}
	if err != nil {
		errs = append(errs, err)
	}
	status, err = r.Run(ctx, execx.Cmd{Name: "docker", Args: []string{"compose", "-f", compose, "stop"}, Stdout: stdout, Stderr: stderr})
	if err == nil && status != 0 {
		err = fmt.Errorf("docker compose stop exited with status %d", status)
	}
	if err != nil {
		errs = append(errs, err)
	}
	return errors.Join(errs...)
}
