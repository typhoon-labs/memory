// Package cosign runs cosign for agentctl: it verifies the catalog index
// and library artifacts, and signs the index, as the platform's pipelines
// do (ci-components' sign component). agentctl wraps cosign rather than
// linking sigstore's libraries, so it verifies exactly as admission and
// the pipelines do.
//
// Every signature the platform makes is a cosign v3 bundle with no
// transparency log entry and no timestamp: the pipelines sign with a
// signing config that names no service (design/distribution.md,
// Provenance). So every verification passes --insecure-ignore-tlog, and
// trusts the key alone.
package cosign

import (
	"bufio"
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// Cosign runs one cosign binary.
type Cosign struct {
	Runner execx.Runner
	// Path is the command; empty is cosign on PATH.
	Path string
	// Env is the command's whole environment; nil inherits agentctl's.
	Env []string
}

// Refused is a verification that cosign ran and refused: a signature
// that does not verify with the key, a changed file, an attestation that
// is not there.
type Refused struct {
	What   string
	Detail string
}

func (r *Refused) Error() string {
	if r.Detail == "" {
		return r.What
	}
	return r.What + ": " + r.Detail
}

// IsRefused reports whether err is a refusal rather than a failure to
// run cosign.
func IsRefused(err error) bool {
	var r *Refused
	return errors.As(err, &r)
}

func (c Cosign) cmd(args ...string) execx.Cmd {
	name := c.Path
	if name == "" {
		name = "cosign"
	}
	return execx.Cmd{Name: name, Args: args, Env: c.Env}
}

// run runs cosign and returns its standard output; a non-zero status is
// a Refused with what cosign said, its last line, as the detail.
func (c Cosign) run(ctx context.Context, what string, args ...string) ([]byte, error) {
	out, err := execx.Output(ctx, c.Runner, c.cmd(args...))
	var se *execx.StatusError
	if errors.As(err, &se) {
		return out, &Refused{What: what, Detail: lastLine(se.Stderr)}
	}
	if err != nil {
		return nil, fmt.Errorf("cosign: %w", err)
	}
	return out, nil
}

func lastLine(s string) string {
	lines := strings.Split(strings.TrimSpace(s), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		if l := strings.TrimSpace(lines[i]); l != "" {
			return strings.TrimPrefix(l, "Error: ")
		}
	}
	return ""
}

// VerifyBlob checks a file against its bundle with a key: a PEM file's
// path or a KMS URI.
func (c Cosign) VerifyBlob(ctx context.Context, key, bundle, file string) error {
	_, err := c.run(ctx, "the signature does not verify with the key",
		"verify-blob", "--key", key, "--insecure-ignore-tlog", "--bundle", bundle, file)
	return err
}

// SigningConfig writes a signing config that names no service, so
// signing reaches no transparency log and no timestamp authority, as the
// sign component's does.
func (c Cosign) SigningConfig(ctx context.Context, out string) error {
	_, err := c.run(ctx, "cosign could not write a signing config", "signing-config", "create", "--out", out)
	return err
}

// SignBlob signs a file with a key, writing its bundle.
func (c Cosign) SignBlob(ctx context.Context, key, signingConfig, bundle, file string) error {
	_, err := c.run(ctx, "cosign could not sign", "sign-blob", "--key", key, "--signing-config", signingConfig, "-y", "--bundle", bundle, file)
	return err
}

// PublicKey writes a key's public half as PEM: for a KMS key, what
// GetPublicKey returns.
func (c Cosign) PublicKey(ctx context.Context, key, out string) error {
	_, err := c.run(ctx, "cosign could not read the public key", "public-key", "--key", key, "--outfile", out)
	return err
}

func registryArgs(plainHTTP bool) []string {
	if plainHTTP {
		return []string{"--allow-http-registry"}
	}
	return nil
}

// SignStatementType is the predicate type of cosign v3's own signature
// statement, the bundle cosign sign writes: what makes a bundle a
// signature rather than an attestation.
const SignStatementType = "https://sigstore.dev/cosign/sign/v1"

// ProvenanceType is SLSA v1 provenance's predicate type, which
// verify-attestation --type slsaprovenance1 selects.
const ProvenanceType = "https://slsa.dev/provenance/v1"

// VerifyImage checks the signature on an image or OCI artifact, by
// digest, with a key: cosign's sign statement on that digest, which the
// key signed. cosign verify alone will not do: with v3's bundles it
// takes any bundle the key made on the digest as the signature, an
// attestation included, so a release-key provenance or SBOM, or a
// conformance attestation with the conformance key, would pass. The
// statement is checked as admission checks it, as an attestation of the
// sign statement's type, and must name the digest as its subject.
func (c Cosign) VerifyImage(ctx context.Context, key, ref string, plainHTTP bool) error {
	sts, err := c.VerifyAttestation(ctx, key, ref, SignStatementType, plainHTTP)
	if err != nil {
		if IsRefused(err) {
			return &Refused{What: "no signature verifies with the key", Detail: err.(*Refused).Detail}
		}
		return err
	}
	_, digest, _ := strings.Cut(ref, "@sha256:")
	for _, st := range sts {
		if st.PredicateType != SignStatementType {
			continue
		}
		for _, sub := range st.Subject {
			if digest != "" && sub.Digest["sha256"] == digest {
				return nil
			}
		}
	}
	return &Refused{What: "no signature verifies with the key", Detail: "the key's bundles on " + ref + " hold no sign statement for that digest"}
}

// Of keeps the statements of one predicate type.
func Of(sts []Statement, predicateType string) []Statement {
	var out []Statement
	for _, st := range sts {
		if st.PredicateType == predicateType {
			out = append(out, st)
		}
	}
	return out
}

// Statement is an in-toto statement, as a DSSE envelope carries it.
type Statement struct {
	Type          string          `json:"_type"`
	PredicateType string          `json:"predicateType"`
	Subject       []Subject       `json:"subject"`
	Predicate     json.RawMessage `json:"predicate"`
}

// Subject is one subject of a statement.
type Subject struct {
	Name   string            `json:"name"`
	Digest map[string]string `json:"digest"`
}

// VerifyAttestation checks the attestations of one type on an image or
// artifact, by digest, with a key, and returns their statements: every
// one cosign verified. cosign refuses when none of that type verifies.
func (c Cosign) VerifyAttestation(ctx context.Context, key, ref, typ string, plainHTTP bool) ([]Statement, error) {
	args := append([]string{"verify-attestation", "--key", key, "--insecure-ignore-tlog", "--type", typ, "--output", "json"}, registryArgs(plainHTTP)...)
	out, err := c.run(ctx, fmt.Sprintf("no %s attestation verifies with the key", typ), append(args, ref)...)
	if err != nil {
		return nil, err
	}
	return parseEnvelopes(out)
}

// parseEnvelopes reads cosign's output: one DSSE envelope per line.
func parseEnvelopes(out []byte) ([]Statement, error) {
	var sts []Statement
	sc := bufio.NewScanner(bytes.NewReader(out))
	sc.Buffer(make([]byte, 0, 64<<10), 16<<20)
	for sc.Scan() {
		line := bytes.TrimSpace(sc.Bytes())
		if len(line) == 0 || line[0] != '{' {
			continue
		}
		var env struct {
			PayloadType string `json:"payloadType"`
			Payload     string `json:"payload"`
		}
		if err := json.Unmarshal(line, &env); err != nil {
			return nil, fmt.Errorf("cosign's output: %w", err)
		}
		raw, err := base64.StdEncoding.DecodeString(env.Payload)
		if err != nil {
			return nil, fmt.Errorf("cosign's output: the payload: %w", err)
		}
		var st Statement
		if err := json.Unmarshal(raw, &st); err != nil {
			return nil, fmt.Errorf("cosign's output: the statement: %w", err)
		}
		sts = append(sts, st)
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	if len(sts) == 0 {
		return nil, &Refused{What: "cosign verified no statement"}
	}
	return sts, nil
}

// ProvenanceCommits returns the commits a SLSA v1 provenance names among
// its resolved dependencies, as the sign component writes them.
func ProvenanceCommits(st Statement) []string {
	var p struct {
		BuildDefinition struct {
			ResolvedDependencies []struct {
				Digest map[string]string `json:"digest"`
			} `json:"resolvedDependencies"`
		} `json:"buildDefinition"`
	}
	if json.Unmarshal(st.Predicate, &p) != nil {
		return nil
	}
	var commits []string
	for _, d := range p.BuildDefinition.ResolvedDependencies {
		if c := d.Digest["gitCommit"]; c != "" {
			commits = append(commits, c)
		}
	}
	return commits
}
