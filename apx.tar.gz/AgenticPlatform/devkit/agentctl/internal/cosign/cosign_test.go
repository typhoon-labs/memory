package cosign

import (
	"encoding/base64"
	"encoding/json"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

func TestVerifyBlobArgs(t *testing.T) {
	f := &execx.Fake{}
	c := Cosign{Runner: f}
	if err := c.VerifyBlob(t.Context(), "/k.pub", "/i.json.sigstore.json", "/i.json"); err != nil {
		t.Fatal(err)
	}
	got := strings.Join(f.Calls()[0].Cmd.Args, " ")
	if got != "verify-blob --key /k.pub --insecure-ignore-tlog --bundle /i.json.sigstore.json /i.json" || f.Calls()[0].Cmd.Name != "cosign" {
		t.Errorf("cosign %s", got)
	}
}

func TestRefused(t *testing.T) {
	f := &execx.Fake{Handle: func(execx.Cmd, []byte) (int, string, string, error) {
		return 1, "", "some progress\nError: invalid signature when validating ASN.1 encoded signature\n", nil
	}}
	err := Cosign{Runner: f}.VerifyImage(t.Context(), "/k.pub", "r@sha256:x", true)
	if !IsRefused(err) || !strings.Contains(err.Error(), "invalid signature when validating") || strings.Contains(err.Error(), "Error:") {
		t.Fatalf("%v", err)
	}
	if args := strings.Join(f.Calls()[0].Cmd.Args, " "); !strings.Contains(args, "--allow-http-registry") {
		t.Errorf("cosign %s", args)
	}
	// Not starting cosign is no refusal.
	f.Handle = func(execx.Cmd, []byte) (int, string, string, error) { return -1, "", "", execx.ErrNotFound }
	if err := (Cosign{Runner: f}).VerifyBlob(t.Context(), "k", "b", "f"); err == nil || IsRefused(err) {
		t.Fatalf("%v", err)
	}
}

func TestVerifyAttestationStatements(t *testing.T) {
	st := map[string]any{
		"_type": "https://in-toto.io/Statement/v1", "predicateType": "https://slsa.dev/provenance/v1",
		"subject": []map[string]any{{"name": "x", "digest": map[string]string{"sha256": "ab"}}},
		"predicate": map[string]any{"buildDefinition": map[string]any{"resolvedDependencies": []map[string]any{
			{"uri": "git+https://gitlab.example.com/x", "digest": map[string]string{"gitCommit": "cc3f8a46114bd26b08a51b8c04bc321a0863f6d8"}},
		}}},
	}
	raw, _ := json.Marshal(st)
	env, _ := json.Marshal(map[string]string{"payloadType": "application/vnd.in-toto+json", "payload": base64.StdEncoding.EncodeToString(raw)})
	f := &execx.Fake{Handle: func(execx.Cmd, []byte) (int, string, string, error) {
		return 0, "\n" + string(env) + "\n", "Verification for r@sha256:x --\n", nil
	}}
	sts, err := Cosign{Runner: f}.VerifyAttestation(t.Context(), "/k.pub", "r@sha256:x", "slsaprovenance1", false)
	if err != nil || len(sts) != 1 || sts[0].PredicateType != "https://slsa.dev/provenance/v1" {
		t.Fatalf("%+v, %v", sts, err)
	}
	if c := ProvenanceCommits(sts[0]); len(c) != 1 || c[0] != "cc3f8a46114bd26b08a51b8c04bc321a0863f6d8" {
		t.Errorf("commits %v", c)
	}
	// Status 0 with nothing verified is still a refusal.
	f.Handle = func(execx.Cmd, []byte) (int, string, string, error) { return 0, "", "", nil }
	if _, err := (Cosign{Runner: f}).VerifyAttestation(t.Context(), "/k.pub", "r@sha256:x", "slsaprovenance1", false); !IsRefused(err) {
		t.Fatalf("%v", err)
	}
}

// envelope is one line of cosign's output for a statement.
func envelope(st map[string]any) string {
	raw, _ := json.Marshal(st)
	e, _ := json.Marshal(map[string]string{"payloadType": "application/vnd.in-toto+json", "payload": base64.StdEncoding.EncodeToString(raw)})
	return string(e) + "\n"
}

// TestVerifyImageNeedsTheSignStatement: a signature is cosign's sign
// statement on the digest, never just any bundle the key made there.
func TestVerifyImageNeedsTheSignStatement(t *testing.T) {
	digest := strings.Repeat("ab", 32)
	ref := "floci:4566/library/skill/x@sha256:" + digest
	sign := map[string]any{"_type": "https://in-toto.io/Statement/v1", "predicateType": SignStatementType,
		"subject": []map[string]any{{"name": "x", "digest": map[string]string{"sha256": digest}}}, "predicate": map[string]any{}}
	var out string
	f := &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
		if out == "" {
			return 1, "", "Error: none of the attestations matched the predicate type\n", nil
		}
		return 0, out, "", nil
	}}
	c := Cosign{Runner: f}

	out = envelope(sign)
	if err := c.VerifyImage(t.Context(), "/k.pub", ref, true); err != nil {
		t.Fatalf("the sign statement: %v", err)
	}
	args := strings.Join(f.Calls()[0].Cmd.Args, " ")
	if !strings.HasPrefix(args, "verify-attestation ") || !strings.Contains(args, "--type "+SignStatementType) || !strings.Contains(args, "--allow-http-registry") {
		t.Errorf("cosign %s", args)
	}

	out = ""
	if err := c.VerifyImage(t.Context(), "/k.pub", ref, true); !IsRefused(err) || !strings.Contains(err.Error(), "no signature verifies") {
		t.Errorf("no sign statement: %v", err)
	}
	// A sign statement on another digest.
	other := map[string]any{"predicateType": SignStatementType, "subject": []map[string]any{{"digest": map[string]string{"sha256": strings.Repeat("cd", 32)}}}}
	out = envelope(other)
	if err := c.VerifyImage(t.Context(), "/k.pub", ref, true); !IsRefused(err) {
		t.Errorf("another digest's sign statement: %v", err)
	}
	// Another type's statement, should cosign hand one back.
	prov := map[string]any{"predicateType": ProvenanceType, "subject": []map[string]any{{"digest": map[string]string{"sha256": digest}}}}
	out = envelope(prov)
	if err := c.VerifyImage(t.Context(), "/k.pub", ref, true); !IsRefused(err) {
		t.Errorf("a provenance as the signature: %v", err)
	}
}
