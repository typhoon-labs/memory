package store

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

const token = "eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiJyZWZyZXNoIn0.c2ln"

func record() *Record {
	return &Record{Issuer: "https://issuer.test/realms/x", ClientID: "agentctl", RefreshToken: token, Scopes: []string{"models"}, Saved: time.Unix(0, 0).UTC()}
}

func TestFileRoundTrip(t *testing.T) {
	dir := filepath.Join(t.TempDir(), "agentctl")
	f := File{Dir: dir}
	if _, err := f.Load(); !errors.Is(err, ErrNotFound) {
		t.Fatalf("empty store: %v", err)
	}
	if err := f.Save(record()); err != nil {
		t.Fatal(err)
	}
	for p, want := range map[string]os.FileMode{dir: 0o700, f.Path(): 0o600} {
		info, err := os.Stat(p)
		if err != nil || info.Mode().Perm() != want {
			t.Fatalf("%s: mode %v, want %v (%v)", p, info.Mode().Perm(), want, err)
		}
	}
	got, err := f.Load()
	if err != nil || got.RefreshToken != token || got.Issuer != record().Issuer {
		t.Fatalf("load: %+v, %v", got, err)
	}
	// Saving again leaves no temporary file behind.
	if err := f.Save(record()); err != nil {
		t.Fatal(err)
	}
	entries, _ := os.ReadDir(dir)
	if len(entries) != 1 {
		t.Fatalf("the directory holds %d entries, want only credentials.json", len(entries))
	}
	if err := f.Delete(); err != nil {
		t.Fatal(err)
	}
	if _, err := f.Load(); !errors.Is(err, ErrNotFound) {
		t.Fatalf("after delete: %v", err)
	}
}

func TestFileRefusesOpenModes(t *testing.T) {
	f := File{Dir: t.TempDir()}
	if err := f.Save(record()); err != nil {
		t.Fatal(err)
	}
	for _, mode := range []os.FileMode{0o640, 0o604, 0o620} {
		os.Chmod(f.Path(), mode)
		if _, err := f.Load(); err == nil || !strings.Contains(err.Error(), "by others") {
			t.Fatalf("mode %v: %v", mode, err)
		}
	}
}

func TestLockExcludes(t *testing.T) {
	dir := t.TempDir()
	var mu sync.Mutex
	inside, most := 0, 0
	var wg sync.WaitGroup
	for range 8 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			unlock, err := Lock(dir)
			if err != nil {
				t.Error(err)
				return
			}
			mu.Lock()
			inside++
			most = max(most, inside)
			mu.Unlock()
			time.Sleep(5 * time.Millisecond)
			mu.Lock()
			inside--
			mu.Unlock()
			unlock()
		}()
	}
	wg.Wait()
	if most != 1 {
		t.Fatalf("%d holders at once", most)
	}
}

// keychainFake plays security(1) or secret-tool with one stored secret.
func keychainFake(t *testing.T) (*execx.Fake, *string) {
	secret := new(string)
	f := &execx.Fake{Handle: func(c execx.Cmd, stdin []byte) (int, string, string, error) {
		for _, a := range c.Args {
			if strings.Contains(a, token) {
				t.Errorf("the token is on %s's command line: %v", c.Name, c.Args)
			}
		}
		switch {
		case c.Name == securityPath && c.Args[0] == "-i":
			fields := strings.Fields(string(stdin))
			*secret = fields[len(fields)-1]
		case c.Name == securityPath && c.Args[0] == "find-generic-password":
			if *secret == "" {
				return 44, "", "security: SecKeychainSearchCopyNext: The specified item could not be found in the keychain.", nil
			}
			return 0, *secret + "\n", "", nil
		case c.Name == securityPath && c.Args[0] == "delete-generic-password":
			*secret = ""
		case c.Name == "secret-tool" && c.Args[0] == "store":
			*secret = string(stdin)
		case c.Name == "secret-tool" && c.Args[0] == "lookup":
			if *secret == "" {
				return 1, "", "", nil
			}
			return 0, *secret, "", nil
		case c.Name == "secret-tool" && c.Args[0] == "clear":
			*secret = ""
		default:
			t.Errorf("unexpected command %v", c)
		}
		return 0, "", "", nil
	}}
	return f, secret
}

func TestKeychains(t *testing.T) {
	for _, tool := range []KeychainTool{MacOS{}, SecretService{}} {
		t.Run(tool.Name(), func(t *testing.T) {
			fake, secret := keychainFake(t)
			k := Keychain{Dir: t.TempDir(), Tool: tool, Runner: fake}
			if _, err := k.Load(); !errors.Is(err, ErrNotFound) {
				t.Fatalf("empty: %v", err)
			}
			if err := k.Save(record()); err != nil {
				t.Fatal(err)
			}
			if *secret != token {
				t.Fatalf("the keychain holds %q", *secret)
			}
			meta, _ := os.ReadFile(filepath.Join(k.Dir, metaName))
			if strings.Contains(string(meta), token) {
				t.Fatal("the token is in the metadata file")
			}
			got, err := k.Load()
			if err != nil || got.RefreshToken != token || got.Issuer != record().Issuer {
				t.Fatalf("load: %+v, %v", got, err)
			}
			if err := k.Delete(); err != nil {
				t.Fatal(err)
			}
			if _, err := k.Load(); !errors.Is(err, ErrNotFound) {
				t.Fatalf("after delete: %v", err)
			}
		})
	}
	// security(1)'s interactive mode splits on spaces and quotes.
	if err := (MacOS{}).Write(t.Context(), &execx.Fake{}, `a "b`); err == nil {
		t.Fatal("a token with a quote and a space was written")
	}
}

func TestSelect(t *testing.T) {
	has := func(names ...string) func(string) bool {
		return func(n string) bool {
			for _, x := range names {
				if x == n {
					return true
				}
			}
			return false
		}
	}
	env := func(kv ...string) func(string) string {
		return func(k string) string {
			for i := 0; i < len(kv); i += 2 {
				if kv[i] == k {
					return kv[i+1]
				}
			}
			return ""
		}
	}
	cases := []struct {
		name, mode, goos string
		getenv           func(string) string
		look             func(string) bool
		want             string // type of the store, or "error"
	}{
		{"sandbox", "", "linux", env(), has(), "File"},
		{"linux without D-Bus", "", "linux", env(), has("secret-tool"), "File"},
		{"linux desktop", "", "linux", env("DBUS_SESSION_BUS_ADDRESS", "unix:path=/run/bus"), has("secret-tool"), "Secret Service"},
		{"macOS", "auto", "darwin", env(), has(securityPath), "macOS"},
		{"forced file", "file", "darwin", env(), has(securityPath), "File"},
		{"forced keychain, none", "keychain", "linux", env(), has(), "error"},
		{"unknown mode", "vault", "linux", env(), has(), "error"},
	}
	for _, c := range cases {
		s, err := Select(Choice{Dir: "/x", Mode: c.mode, GOOS: c.goos, Getenv: c.getenv, LookPath: c.look})
		got := "error"
		if err == nil {
			got = s.Describe()
			if _, ok := s.(File); ok {
				got = "File"
			}
		}
		if !strings.Contains(got, c.want) {
			t.Errorf("%s: got %q, want %q", c.name, got, c.want)
		}
	}
}
