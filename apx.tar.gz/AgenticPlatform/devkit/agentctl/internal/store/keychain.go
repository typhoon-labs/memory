package store

import (
	"context"
	"errors"
	"fmt"
	"path/filepath"
	"regexp"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// Keychain keeps the refresh token in the OS keychain, through the OS's
// own command, so agentctl needs no cgo and the token never appears on a
// command line; the rest of the record, which holds no secret, goes to
// Dir/sign-in.json. Tool is MacOS or SecretService.
type Keychain struct {
	Dir    string
	Tool   KeychainTool
	Runner execx.Runner
}

// KeychainTool is one OS keychain's command.
type KeychainTool interface {
	Name() string
	Read(ctx context.Context, r execx.Runner) (string, error) // ErrNotFound when absent
	Write(ctx context.Context, r execx.Runner, secret string) error
	Remove(ctx context.Context, r execx.Runner) error
}

const (
	keychainService = "agentctl"
	keychainAccount = "sign-in"
	metaName        = "sign-in.json"
)

// Describe implements Store.
func (k Keychain) Describe() string { return k.Tool.Name() }

func (k Keychain) metaPath() string { return filepath.Join(k.Dir, metaName) }

// Load implements Store.
func (k Keychain) Load() (*Record, error) {
	meta, err := loadRecord(k.metaPath())
	if err != nil {
		return nil, err
	}
	secret, err := k.Tool.Read(context.Background(), k.Runner)
	if err != nil {
		return nil, err
	}
	meta.RefreshToken = secret
	return meta, nil
}

// Save implements Store: the token first, then the record without it.
func (k Keychain) Save(r *Record) error {
	if err := k.Tool.Write(context.Background(), k.Runner, r.RefreshToken); err != nil {
		return err
	}
	meta := *r
	meta.RefreshToken = ""
	return writeAtomic(k.metaPath(), &meta)
}

// Delete implements Store.
func (k Keychain) Delete() error {
	if err := k.Tool.Remove(context.Background(), k.Runner); err != nil {
		return err
	}
	return removeFile(k.metaPath())
}

// tokenChars is what a refresh token may hold for the macOS tool, whose
// interactive mode splits its input on spaces and quotes: a JWT's
// characters. Keycloak's refresh tokens are JWTs.
var tokenChars = regexp.MustCompile(`^[A-Za-z0-9._~+/=-]+$`)

// MacOS is the login keychain, through /usr/bin/security.
type MacOS struct{}

// Name implements KeychainTool.
func (MacOS) Name() string { return "the macOS keychain" }

const securityPath = "/usr/bin/security"

// Read implements KeychainTool.
func (MacOS) Read(ctx context.Context, r execx.Runner) (string, error) {
	out, err := execx.Output(ctx, r, execx.Cmd{Name: securityPath, Args: []string{"find-generic-password", "-s", keychainService, "-a", keychainAccount, "-w"}})
	var st *execx.StatusError
	if errors.As(err, &st) && st.Status == 44 { // errSecItemNotFound
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("read the keychain: %w", err)
	}
	return strings.TrimSpace(string(out)), nil
}

// Write implements KeychainTool. security(1) takes a password only as an
// argument, so the command goes to its interactive mode on standard input,
// where no other process can see it.
func (MacOS) Write(ctx context.Context, r execx.Runner, secret string) error {
	if !tokenChars.MatchString(secret) {
		return errors.New("the refresh token holds characters the macOS keychain tool cannot take")
	}
	line := fmt.Sprintf("add-generic-password -U -s %s -a %s -l %s -w %s\n", keychainService, keychainAccount, "agentctl-sign-in", secret)
	_, err := execx.Output(ctx, r, execx.Cmd{Name: securityPath, Args: []string{"-i"}, Stdin: strings.NewReader(line)})
	if err != nil {
		return fmt.Errorf("write the keychain: %w", scrub(err, secret))
	}
	return nil
}

// Remove implements KeychainTool.
func (MacOS) Remove(ctx context.Context, r execx.Runner) error {
	_, err := execx.Output(ctx, r, execx.Cmd{Name: securityPath, Args: []string{"delete-generic-password", "-s", keychainService, "-a", keychainAccount}})
	var st *execx.StatusError
	if err != nil && !(errors.As(err, &st) && st.Status == 44) {
		return fmt.Errorf("remove from the keychain: %w", err)
	}
	return nil
}

// SecretService is a Linux desktop's keyring (GNOME Keyring, KWallet)
// through libsecret's secret-tool, which reads the secret from standard
// input.
type SecretService struct{}

// Name implements KeychainTool.
func (SecretService) Name() string { return "the Secret Service keyring" }

func secretToolAttrs() []string {
	return []string{"service", keychainService, "account", keychainAccount}
}

// Read implements KeychainTool.
func (SecretService) Read(ctx context.Context, r execx.Runner) (string, error) {
	out, err := execx.Output(ctx, r, execx.Cmd{Name: "secret-tool", Args: append([]string{"lookup"}, secretToolAttrs()...)})
	var st *execx.StatusError
	if errors.As(err, &st) && st.Status == 1 && strings.TrimSpace(st.Stderr) == "" {
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("read the keyring: %w", err)
	}
	s := strings.TrimSpace(string(out))
	if s == "" {
		return "", ErrNotFound
	}
	return s, nil
}

// Write implements KeychainTool.
func (SecretService) Write(ctx context.Context, r execx.Runner, secret string) error {
	args := append([]string{"store", "--label=agentctl sign-in"}, secretToolAttrs()...)
	if _, err := execx.Output(ctx, r, execx.Cmd{Name: "secret-tool", Args: args, Stdin: strings.NewReader(secret)}); err != nil {
		return fmt.Errorf("write the keyring: %w", scrub(err, secret))
	}
	return nil
}

// Remove implements KeychainTool.
func (SecretService) Remove(ctx context.Context, r execx.Runner) error {
	if _, err := execx.Output(ctx, r, execx.Cmd{Name: "secret-tool", Args: append([]string{"clear"}, secretToolAttrs()...)}); err != nil {
		var st *execx.StatusError
		if errors.As(err, &st) && st.Status == 1 {
			return nil
		}
		return fmt.Errorf("remove from the keyring: %w", err)
	}
	return nil
}

// scrub removes the secret from an error's text, in case a tool echoed
// its input.
func scrub(err error, secret string) error {
	if secret == "" || !strings.Contains(err.Error(), secret) {
		return err
	}
	return errors.New(strings.ReplaceAll(err.Error(), secret, "[redacted]"))
}
