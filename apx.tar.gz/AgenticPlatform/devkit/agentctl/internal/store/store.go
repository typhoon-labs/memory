// Package store keeps agentctl's sign-in: the latest refresh token and what
// it was issued for. It goes to the OS keychain where there is one, else
// to a file only its user can read, written atomically (decision D29). A
// refresh token is usable once, so every read, refresh and write of it
// holds Lock (design/identity.md, "The realm"; T20).
package store

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"syscall"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// Record is one sign-in. The refresh token is the only secret in it.
type Record struct {
	Issuer       string `json:"issuer"`
	ClientID     string `json:"client_id"`
	RefreshToken string `json:"refresh_token"`
	// Scopes are the route scopes the sign-in was granted; a refresh may
	// only narrow to one of them.
	Scopes []string `json:"scopes"`
	CAFile string   `json:"ca_file,omitempty"`
	// Gateway is the developer gateway's URL, which the audiences of the
	// route scopes' tokens are built from.
	Gateway  string `json:"gateway,omitempty"`
	Subject  string `json:"sub,omitempty"`
	Username string `json:"preferred_username,omitempty"`
	// RefreshExpires is when the refresh token stops working unless used,
	// from the token response's refresh_expires_in; zero if not given.
	RefreshExpires time.Time `json:"refresh_expires,omitempty"`
	Saved          time.Time `json:"saved"`
}

// Valid reports whether r can be used to refresh.
func (r *Record) Valid() error {
	switch {
	case r.Issuer == "", r.ClientID == "":
		return errors.New("the saved sign-in names no issuer or client")
	case r.RefreshToken == "":
		return errors.New("the saved sign-in holds no refresh token")
	}
	return nil
}

// ErrNotFound means nothing is saved: the person has not signed in.
var ErrNotFound = errors.New("not signed in")

// Store keeps one Record.
type Store interface {
	Load() (*Record, error)
	Save(*Record) error
	Delete() error
	// Describe names where the record is kept, for people.
	Describe() string
}

// Lock takes agentctl's exclusive lock in dir, waiting for another
// process that holds it, and returns the function that releases it. The
// lock is flock(2) on dir/agentctl.lock, which the system releases if the
// process dies.
func Lock(dir string) (func(), error) {
	if err := ensureDir(dir); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(filepath.Join(dir, "agentctl.lock"), os.O_RDWR|os.O_CREATE, 0o600)
	if err != nil {
		return nil, fmt.Errorf("lock: %w", err)
	}
	for {
		err = syscall.Flock(int(f.Fd()), syscall.LOCK_EX)
		if !errors.Is(err, syscall.EINTR) {
			break
		}
	}
	if err != nil {
		f.Close()
		return nil, fmt.Errorf("lock %s: %w", f.Name(), err)
	}
	return func() {
		syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
		f.Close()
	}, nil
}

// ensureDir creates dir, readable by its user alone, if it is missing.
func ensureDir(dir string) error {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return fmt.Errorf("create %s: %w", dir, err)
	}
	return nil
}

// Choice is what Select needs to know about the system.
type Choice struct {
	Dir    string // agentctl's configuration directory
	Mode   string // AGENTCTL_TOKEN_STORE: "", "auto", "keychain" or "file"
	GOOS   string // runtime.GOOS
	Getenv func(string) string
	// LookPath reports whether a command exists, as exec.LookPath does.
	LookPath func(string) bool
	Runner   execx.Runner
}

// Select returns the store to use: the OS keychain where there is one,
// else the file (D29). AGENTCTL_TOKEN_STORE=file or =keychain forces one;
// keychain fails where there is none.
func Select(c Choice) (Store, error) {
	var tool KeychainTool
	switch {
	case c.GOOS == "darwin" && c.LookPath(securityPath):
		tool = MacOS{}
	case c.GOOS == "linux" && c.Getenv("DBUS_SESSION_BUS_ADDRESS") != "" && c.LookPath("secret-tool"):
		tool = SecretService{}
	}
	switch c.Mode {
	case "", "auto":
		if tool == nil {
			return File{Dir: c.Dir}, nil
		}
	case "file":
		return File{Dir: c.Dir}, nil
	case "keychain":
		if tool == nil {
			return nil, errors.New("AGENTCTL_TOKEN_STORE=keychain, but there is no keychain: on Linux, secret-tool and a D-Bus session; on macOS, /usr/bin/security")
		}
	default:
		return nil, fmt.Errorf("AGENTCTL_TOKEN_STORE=%q: use auto, keychain or file", c.Mode)
	}
	return Keychain{Dir: c.Dir, Tool: tool, Runner: c.Runner}, nil
}
