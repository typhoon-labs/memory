package store

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
)

// File keeps the record in Dir/credentials.json, mode 0600 in a directory
// mode 0700: the store where there is no keychain (D29), as in the build
// sandbox and in CI.
type File struct {
	Dir string
}

const fileName = "credentials.json"

// Path is the file's path.
func (f File) Path() string { return filepath.Join(f.Dir, fileName) }

// Describe implements Store.
func (f File) Describe() string { return "the file " + f.Path() }

// Load implements Store.
func (f File) Load() (*Record, error) { return loadRecord(f.Path()) }

// Save implements Store.
func (f File) Save(r *Record) error { return writeAtomic(f.Path(), r) }

// Delete implements Store.
func (f File) Delete() error { return removeFile(f.Path()) }

// loadRecord reads a record from path. It refuses a file that others can
// read or write, as ssh does a private key, since a refresh token is a
// credential.
func loadRecord(path string) (*Record, error) {
	file, err := os.Open(path)
	if errors.Is(err, fs.ErrNotExist) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil {
		return nil, err
	}
	if perm := info.Mode().Perm(); perm&0o077 != 0 {
		return nil, fmt.Errorf("%s is readable or writable by others (mode %04o): run chmod 600 %s, then sign in again, since the token may have been read", path, perm, path)
	}
	data, err := io.ReadAll(io.LimitReader(file, 1<<20))
	if err != nil {
		return nil, err
	}
	var r Record
	if err := json.Unmarshal(data, &r); err != nil {
		return nil, fmt.Errorf("%s: not a saved sign-in: %w", path, err)
	}
	return &r, nil
}

// writeAtomic writes r to path through a new file beside it, mode 0600
// from its creation, synced, then renamed over it, so a reader sees the
// old record or the new one and never a part of either.
func writeAtomic(path string, r *Record) error {
	dir := filepath.Dir(path)
	if err := ensureDir(dir); err != nil {
		return err
	}
	data, err := json.MarshalIndent(r, "", "  ")
	if err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, "."+filepath.Base(path)+"-*.tmp") // mode 0600
	if err != nil {
		return fmt.Errorf("save sign-in: %w", err)
	}
	done := false
	defer func() {
		if !done {
			tmp.Close()
			os.Remove(tmp.Name())
		}
	}()
	for _, step := range []func() error{
		func() error { return tmp.Chmod(0o600) },
		func() error { _, err := tmp.Write(append(data, '\n')); return err },
		tmp.Sync,
		tmp.Close,
		func() error { return os.Rename(tmp.Name(), path) },
	} {
		if err := step(); err != nil {
			return fmt.Errorf("save sign-in: %w", err)
		}
	}
	done = true
	// Make the rename itself durable.
	if d, err := os.Open(dir); err == nil {
		d.Sync()
		d.Close()
	}
	return nil
}

func removeFile(path string) error {
	err := os.Remove(path)
	if errors.Is(err, fs.ErrNotExist) {
		return nil
	}
	return err
}
