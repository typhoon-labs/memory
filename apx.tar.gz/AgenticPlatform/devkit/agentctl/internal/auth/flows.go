package auth

import (
	"context"
	"crypto/subtle"
	"errors"
	"fmt"
	"html"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// DeviceCode is what the person needs to approve a device sign-in: the
// page to open and the code to confirm there.
type DeviceCode struct {
	UserCode                string `json:"user_code"`
	VerificationURI         string `json:"verification_uri"`
	VerificationURIComplete string `json:"verification_uri_complete"`
	DeviceCode              string `json:"device_code"`
	ExpiresIn               int    `json:"expires_in"`
	Interval                int    `json:"interval"`
}

// Device signs in with the device authorization grant (RFC 8628) and
// PKCE: it asks for a device code, hands the page and code to show, then
// polls the token endpoint until the person approves, refuses, or the
// code expires.
func (c *Client) Device(ctx context.Context, m *Metadata, routeScopes []string, show func(DeviceCode)) (*Tokens, error) {
	if err := httpsURL("device_authorization_endpoint", m.DeviceAuthorizationEndpoint); err != nil {
		return nil, fmt.Errorf("the issuer offers no device sign-in: %w", err)
	}
	p, err := newPKCE()
	if err != nil {
		return nil, err
	}
	var dc DeviceCode
	err = c.post(ctx, m.DeviceAuthorizationEndpoint, "the device authorization endpoint", url.Values{
		"client_id":             {c.ClientID},
		"scope":                 {Scope(routeScopes)},
		"code_challenge":        {p.challenge},
		"code_challenge_method": {"S256"},
	}, &dc)
	if err != nil {
		return nil, err
	}
	if dc.DeviceCode == "" || dc.UserCode == "" || dc.VerificationURI == "" {
		return nil, errors.New("the device authorization endpoint answered without a device code, user code and verification URI")
	}
	if err := httpsURL("verification_uri", dc.VerificationURI); err != nil {
		return nil, err
	}
	if dc.VerificationURIComplete != "" {
		if err := httpsURL("verification_uri_complete", dc.VerificationURIComplete); err != nil {
			return nil, err
		}
	}
	show(dc)

	interval := time.Duration(dc.Interval) * time.Second
	if interval <= 0 {
		interval = 5 * time.Second // RFC 8628, section 3.2
	}
	expiresIn := dc.ExpiresIn
	if expiresIn <= 0 {
		expiresIn = 600
	}
	deadline := c.now().Add(time.Duration(expiresIn) * time.Second)
	for {
		if err := c.sleep(ctx, interval); err != nil {
			return nil, err
		}
		if c.now().After(deadline) {
			return nil, errors.New("the device code expired before the sign-in was approved")
		}
		t, err := c.tokenRequest(ctx, m, url.Values{
			"grant_type":    {"urn:ietf:params:oauth:grant-type:device_code"},
			"device_code":   {dc.DeviceCode},
			"code_verifier": {p.verifier},
		})
		var oe *OAuthError
		switch {
		case err == nil:
			return t, nil
		case errors.As(err, &oe) && oe.Code == "authorization_pending":
			continue
		case errors.As(err, &oe) && oe.Code == "slow_down":
			interval += 5 * time.Second // RFC 8628, section 3.5
			continue
		case errors.As(err, &oe) && oe.Code == "access_denied":
			return nil, errors.New("the sign-in was refused in the browser")
		case errors.As(err, &oe) && oe.Code == "expired_token":
			return nil, errors.New("the device code expired before the sign-in was approved")
		default:
			return nil, err
		}
	}
}

// Loopback signs in with the authorization code grant and PKCE on a
// loopback redirect (RFC 8252, sections 7.3 and 8.3): it listens on
// 127.0.0.1 on a port the system picks, hands the authorization URL to
// open, and waits for the browser to come back with the code. The realm's
// client allows http://127.0.0.1/* with any port; localhost is refused.
func (c *Client) Loopback(ctx context.Context, m *Metadata, routeScopes []string, open func(authURL string)) (*Tokens, error) {
	if err := httpsURL("authorization_endpoint", m.AuthorizationEndpoint); err != nil {
		return nil, err
	}
	p, err := newPKCE()
	if err != nil {
		return nil, err
	}
	state, err := randomString(24)
	if err != nil {
		return nil, err
	}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, fmt.Errorf("listen on loopback: %w", err)
	}
	redirect := fmt.Sprintf("http://127.0.0.1:%d/callback", ln.Addr().(*net.TCPAddr).Port)

	type result struct {
		code string
		err  error
	}
	results := make(chan result, 1)
	mux := http.NewServeMux()
	mux.HandleFunc("/callback", func(w http.ResponseWriter, r *http.Request) {
		q := r.URL.Query()
		var res result
		switch {
		case subtle.ConstantTimeCompare([]byte(q.Get("state")), []byte(state)) != 1:
			// Not this sign-in's answer: ignore it, keep waiting.
			http.Error(w, "This is not the sign-in agentctl is waiting for.", http.StatusBadRequest)
			return
		case q.Get("iss") != "" && q.Get("iss") != strings.TrimSuffix(c.Issuer, "/"):
			// RFC 9207: an answer from another issuer is a mix-up.
			res.err = fmt.Errorf("the authorization response came from the issuer %q, not %q", q.Get("iss"), c.Issuer)
		case m.AuthorizationResponseIss && q.Get("iss") == "":
			res.err = errors.New("the authorization response names no issuer, though the issuer says it always does")
		case q.Get("error") != "":
			res.err = &OAuthError{Endpoint: "the authorization endpoint", Code: q.Get("error"), Description: q.Get("error_description")}
		case q.Get("code") == "":
			res.err = errors.New("the authorization response holds no code")
		default:
			res.code = q.Get("code")
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		if res.err != nil {
			fmt.Fprintf(w, "<!doctype html><title>agentctl</title><p>Sign-in failed: %s</p><p>Return to the terminal.</p>", html.EscapeString(res.err.Error()))
		} else {
			fmt.Fprint(w, "<!doctype html><title>agentctl</title><p>Signed in. You can close this tab and return to the terminal.</p>")
		}
		select {
		case results <- res:
		default:
		}
	})
	srv := &http.Server{Handler: mux, ReadHeaderTimeout: 10 * time.Second}
	go srv.Serve(ln)
	defer srv.Close()

	q := url.Values{
		"client_id":             {c.ClientID},
		"response_type":         {"code"},
		"redirect_uri":          {redirect},
		"scope":                 {Scope(routeScopes)},
		"state":                 {state},
		"code_challenge":        {p.challenge},
		"code_challenge_method": {"S256"},
	}
	sep := "?"
	if strings.Contains(m.AuthorizationEndpoint, "?") {
		sep = "&"
	}
	open(m.AuthorizationEndpoint + sep + q.Encode())

	var res result
	select {
	case <-ctx.Done():
		return nil, fmt.Errorf("waiting for the browser: %w", ctx.Err())
	case res = <-results:
	}
	if res.err != nil {
		return nil, res.err
	}
	return c.tokenRequest(ctx, m, url.Values{
		"grant_type":    {"authorization_code"},
		"code":          {res.code},
		"redirect_uri":  {redirect},
		"code_verifier": {p.verifier},
	})
}
