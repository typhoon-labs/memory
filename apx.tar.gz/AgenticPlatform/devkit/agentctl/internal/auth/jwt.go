package auth

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"strings"
)

// Claims decodes a JWT's payload without verifying its signature. agentctl
// reads its own tokens' claims to check what it was given, never to trust
// a token someone else sent.
func Claims(token string) (map[string]any, error) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return nil, errors.New("not a JWT")
	}
	raw, err := base64.RawURLEncoding.DecodeString(strings.TrimRight(parts[1], "="))
	if err != nil {
		return nil, errors.New("not a JWT: its payload is not base64url")
	}
	var c map[string]any
	if err := json.Unmarshal(raw, &c); err != nil {
		return nil, errors.New("not a JWT: its payload is not a JSON object")
	}
	return c, nil
}

// Audiences returns a token's aud claim as a list, whether it is a string
// or an array.
func Audiences(c map[string]any) []string {
	switch a := c["aud"].(type) {
	case string:
		return []string{a}
	case []any:
		var out []string
		for _, v := range a {
			if s, ok := v.(string); ok {
				out = append(out, s)
			}
		}
		return out
	}
	return nil
}

// String returns a string claim, or "".
func String(c map[string]any, name string) string {
	s, _ := c[name].(string)
	return s
}

var routeScope = regexp.MustCompile(`^(models|(mcp|a2a)/[a-z0-9]+(-[a-z0-9]+)*)$`)

// CheckRouteScope accepts a route scope's name: models, for the model
// route, or mcp/<name> or a2a/<name>, for a route on the developer
// gateway (design/identity.md, "The realm").
func CheckRouteScope(s string) error {
	if !routeScope.MatchString(s) {
		return fmt.Errorf("%q is not a route scope: use models, mcp/<name> or a2a/<name>", s)
	}
	return nil
}

// Audience is the audience a route scope's tokens carry: the route's URL
// on the gateway (design/identity.md, "Endpoints and audiences"). The
// model route's path is v1.
func Audience(gateway, scope string) string {
	path := scope
	if scope == "models" {
		path = "v1"
	}
	return strings.TrimSuffix(gateway, "/") + "/" + path
}

// CheckAudience requires a token to carry exactly one audience, the
// route's, as the gateway does.
func CheckAudience(token, gateway, scope string) error {
	c, err := Claims(token)
	if err != nil {
		return err
	}
	aud := Audiences(c)
	want := Audience(gateway, scope)
	if len(aud) != 1 || aud[0] != want {
		if u, err := url.Parse(want); err == nil && len(aud) == 1 && strings.HasSuffix(aud[0], u.Path) {
			return fmt.Errorf("the token's audience is %s, not %s: set AGENTCTL_GATEWAY to the gateway's URL", aud[0], want)
		}
		return fmt.Errorf("the token carries %d audiences %v, not exactly %s", len(aud), aud, want)
	}
	return nil
}

// CheckAudienceIs requires a token to carry exactly one audience, want.
func CheckAudienceIs(token, want string) error {
	c, err := Claims(token)
	if err != nil {
		return err
	}
	if aud := Audiences(c); len(aud) != 1 || aud[0] != want {
		return fmt.Errorf("the token carries %d audiences %v, not exactly %s", len(aud), aud, want)
	}
	return nil
}
