// Package auth signs a person in to the realm as the public client
// agentctl, and refreshes their tokens (design/identity.md, "The realm").
// Two ways to sign in, each with PKCE (S256), which Keycloak 26.8.2 also
// requires on the device authorization request: the device authorization
// grant (RFC 8628), for a terminal without a browser beside it, and the
// authorization code grant on a loopback redirect (RFC 8252), on
// 127.0.0.1 and a port chosen at random. The endpoints come from the
// issuer's OpenID Connect discovery document.
//
// Nothing here prints or logs a token; errors carry the server's error
// code and description, never a token.
package auth

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"os"
	"slices"
	"strings"
	"time"
)

// Client talks to one issuer as one OAuth client.
type Client struct {
	Issuer   string
	ClientID string
	HTTP     *http.Client
	// Sleep waits between device-flow polls; tests replace it.
	Sleep func(ctx context.Context, d time.Duration) error
	// Now is the clock; tests replace it.
	Now func() time.Time
}

// HTTPClient returns an HTTP client that trusts the system's roots and,
// when caFile is set, the certificates in it (the local build's CA). It
// takes proxies from the environment, as Go does by default.
func HTTPClient(caFile, userAgent string) (*http.Client, error) {
	pool, err := x509.SystemCertPool()
	if err != nil || pool == nil {
		pool = x509.NewCertPool()
	}
	if caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return nil, fmt.Errorf("CA file: %w", err)
		}
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("CA file %s holds no PEM certificate", caFile)
		}
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.TLSClientConfig = &tls.Config{RootCAs: pool, MinVersion: tls.VersionTLS12}
	return &http.Client{
		Timeout:   30 * time.Second,
		Transport: userAgentTransport{tr, userAgent},
		// An OAuth endpoint answers; it never redirects a client.
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}, nil
}

type userAgentTransport struct {
	rt http.RoundTripper
	ua string
}

func (t userAgentTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	if t.ua != "" {
		r = r.Clone(r.Context())
		r.Header.Set("User-Agent", t.ua)
	}
	return t.rt.RoundTrip(r)
}

// Metadata is the part of the issuer's discovery document agentctl uses.
type Metadata struct {
	Issuer                      string   `json:"issuer"`
	AuthorizationEndpoint       string   `json:"authorization_endpoint"`
	TokenEndpoint               string   `json:"token_endpoint"`
	DeviceAuthorizationEndpoint string   `json:"device_authorization_endpoint"`
	CodeChallengeMethods        []string `json:"code_challenge_methods_supported"`
	AuthorizationResponseIss    bool     `json:"authorization_response_iss_parameter_supported"`
}

// Discover reads the issuer's OpenID Connect discovery document. The
// document must name the issuer exactly as configured (OpenID Connect
// Discovery, section 4.3), every endpoint must be HTTPS, and S256 must be
// among the PKCE methods.
func (c *Client) Discover(ctx context.Context) (*Metadata, error) {
	issuer := strings.TrimSuffix(c.Issuer, "/")
	if err := httpsURL("issuer", issuer); err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, issuer+"/.well-known/openid-configuration", nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Accept", "application/json")
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return nil, fmt.Errorf("discovery: %w", err)
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return nil, fmt.Errorf("discovery: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("discovery: %s answered %s", req.URL, resp.Status)
	}
	var m Metadata
	if err := json.Unmarshal(body, &m); err != nil {
		return nil, fmt.Errorf("discovery: %s: %w", req.URL, err)
	}
	if m.Issuer != issuer {
		return nil, fmt.Errorf("discovery: the document names the issuer %q, not %q", m.Issuer, issuer)
	}
	if err := httpsURL("token_endpoint", m.TokenEndpoint); err != nil {
		return nil, fmt.Errorf("discovery: %w", err)
	}
	if !slices.Contains(m.CodeChallengeMethods, "S256") {
		return nil, errors.New("discovery: the issuer does not list S256 among its PKCE methods")
	}
	return &m, nil
}

func httpsURL(name, s string) error {
	u, err := url.Parse(s)
	if err != nil || u.Scheme != "https" || u.Host == "" {
		return fmt.Errorf("%s %q is not an https URL", name, s)
	}
	return nil
}

// Tokens is a token response. Its String hides every token.
type Tokens struct {
	AccessToken      string `json:"access_token"`
	RefreshToken     string `json:"refresh_token"`
	IDToken          string `json:"id_token"`
	TokenType        string `json:"token_type"`
	ExpiresIn        int    `json:"expires_in"`
	RefreshExpiresIn int    `json:"refresh_expires_in"`
	Scope            string `json:"scope"`
}

func (t *Tokens) String() string {
	return fmt.Sprintf("tokens{scope=%q, expires_in=%d}", t.Scope, t.ExpiresIn)
}

// GoString keeps %#v from printing tokens too.
func (t *Tokens) GoString() string { return t.String() }

// OAuthError is an error response from the issuer (RFC 6749, section 5.2).
type OAuthError struct {
	Endpoint    string
	Status      int
	Code        string `json:"error"`
	Description string `json:"error_description"`
}

func (e *OAuthError) Error() string {
	s := fmt.Sprintf("%s refused: %s", e.Endpoint, e.Code)
	if e.Description != "" {
		s += ": " + e.Description
	}
	return s
}

// IsSessionEnded reports whether err means the refresh token or its
// session can no longer be used, so the person must sign in again.
func IsSessionEnded(err error) bool {
	var oe *OAuthError
	return errors.As(err, &oe) && oe.Code == "invalid_grant"
}

// post sends a form to an endpoint and decodes a token response, or the
// error response, into an OAuthError.
func (c *Client) post(ctx context.Context, endpoint, name string, form url.Values, out any) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return fmt.Errorf("%s: %w", name, err)
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return fmt.Errorf("%s: %w", name, err)
	}
	if resp.StatusCode != http.StatusOK {
		oe := &OAuthError{Endpoint: name, Status: resp.StatusCode}
		if mt, _, _ := mime.ParseMediaType(resp.Header.Get("Content-Type")); mt == "application/json" {
			json.Unmarshal(body, oe)
		}
		if oe.Code == "" {
			oe.Code = fmt.Sprintf("HTTP %d", resp.StatusCode)
		}
		return oe
	}
	if err := json.Unmarshal(body, out); err != nil {
		return fmt.Errorf("%s: the answer is not JSON: %w", name, err)
	}
	return nil
}

// tokenRequest posts a grant to the token endpoint and checks that the
// answer holds what every grant here must return.
func (c *Client) tokenRequest(ctx context.Context, m *Metadata, form url.Values) (*Tokens, error) {
	form.Set("client_id", c.ClientID)
	var t Tokens
	if err := c.post(ctx, m.TokenEndpoint, "the token endpoint", form, &t); err != nil {
		return nil, err
	}
	if t.AccessToken == "" || t.RefreshToken == "" {
		return nil, errors.New("the token endpoint answered without an access token and a refresh token")
	}
	if !strings.EqualFold(t.TokenType, "bearer") {
		return nil, fmt.Errorf("the token endpoint answered a token of type %q, not Bearer", t.TokenType)
	}
	return &t, nil
}

// Refresh exchanges a refresh token for new tokens, narrowed to one route
// scope (T20): without a scope the access token would carry every route
// granted at sign-in, which the gateway refuses. The answer holds the
// rotated refresh token, which replaces the one sent: that one is spent.
func (c *Client) Refresh(ctx context.Context, m *Metadata, refreshToken, routeScope string) (*Tokens, error) {
	if routeScope == "" {
		return nil, errors.New("a refresh must name one route scope")
	}
	return c.tokenRequest(ctx, m, url.Values{
		"grant_type":    {"refresh_token"},
		"refresh_token": {refreshToken},
		"scope":         {"openid " + routeScope},
	})
}

// pkce is a PKCE verifier and its S256 challenge (RFC 7636).
type pkce struct{ verifier, challenge string }

func newPKCE() (pkce, error) {
	v, err := randomString(32)
	if err != nil {
		return pkce{}, err
	}
	sum := sha256.Sum256([]byte(v))
	return pkce{verifier: v, challenge: base64.RawURLEncoding.EncodeToString(sum[:])}, nil
}

func randomString(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

func (c *Client) now() time.Time {
	if c.Now != nil {
		return c.Now()
	}
	return time.Now()
}

func (c *Client) sleep(ctx context.Context, d time.Duration) error {
	if c.Sleep != nil {
		return c.Sleep(ctx, d)
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}

// Scope is the scope parameter of a sign-in: openid and every route scope
// the person will want tokens for, since a refresh may only narrow.
func Scope(routeScopes []string) string {
	return strings.Join(append([]string{"openid"}, routeScopes...), " ")
}

// AssertionType is RFC 7523's client assertion type, which Keycloak's
// federated client authentication takes.
const AssertionType = "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"

// ClientCredentials gets an access token for a client that authenticates
// with a signed JWT another issuer gave it (RFC 7523): a projected
// service-account token for the catalog's publisher, or a CI job's
// GitLab ID token for a workflow, which Keycloak checks against its
// kubernetes or gitlab provider. The scope names the one route the token
// is for. No refresh token comes back, and none is kept.
func (c *Client) ClientCredentials(ctx context.Context, m *Metadata, assertion, scope string) (*Tokens, error) {
	if assertion == "" {
		return nil, errors.New("no client assertion")
	}
	form := url.Values{
		"grant_type":            {"client_credentials"},
		"client_id":             {c.ClientID},
		"client_assertion_type": {AssertionType},
		"client_assertion":      {assertion},
	}
	if scope != "" {
		form.Set("scope", scope)
	}
	var t Tokens
	if err := c.post(ctx, m.TokenEndpoint, "the token endpoint", form, &t); err != nil {
		return nil, err
	}
	if t.AccessToken == "" {
		return nil, errors.New("the token endpoint answered without an access token")
	}
	if !strings.EqualFold(t.TokenType, "bearer") {
		return nil, fmt.Errorf("the token endpoint answered a token of type %q, not Bearer", t.TokenType)
	}
	return &t, nil
}
