// Package authtest is a fake OpenID Connect issuer for agentctl's tests,
// shaped like the realm's agentctl client (design/identity.md, "The
// realm"): a public client, PKCE S256 required on the device request as
// Keycloak 26.8.2 does, loopback redirects on 127.0.0.1 with any port,
// optional route scopes whose tokens carry that route's audience alone,
// and refresh tokens that are usable once, where a reuse ends the session
// (T20).
package authtest

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"testing"
	"time"
)

// Issuer is a running fake issuer.
type Issuer struct {
	Server   *httptest.Server
	URL      string // the issuer: <server>/realms/test
	CAFile   string // the server's certificate as PEM
	ClientID string
	Gateway  string
	// Routes are the optional route scopes the client may ask for.
	Routes []string
	// AutoApprove approves a device code as soon as it is issued.
	AutoApprove bool
	// SendIss puts iss in authorization responses (RFC 9207).
	SendIss bool
	// WrongIss puts another issuer in authorization responses.
	WrongIss bool
	// Federated are the confidential clients that authenticate with a
	// JWT another issuer gave them (RFC 7523), as Keycloak's federated
	// client authentication checks one, by client ID.
	Federated map[string]Federated

	mu       sync.Mutex
	devices  map[string]*device // by device code
	codes    map[string]*grant  // authorization codes
	refresh  map[string]*grant  // live refresh tokens
	spent    map[string]*grant  // used refresh tokens
	sessions map[string]bool    // live sessions
	n        int
	// Counters for tests.
	Refreshes, Reuses, DeviceRequests, ClientCredentials int
	LastRefreshScope                                     string
}

// Federated is one federated client: the assertion it is accepted with,
// and the audience each of its scopes gives.
type Federated struct {
	Assertion string
	Audiences map[string]string
}

type device struct {
	userCode, challenge, scope string
	approved                   bool
}

type grant struct {
	scope, challenge, redirect, session string
}

// New starts an issuer; the test stops it.
func New(t *testing.T) *Issuer {
	t.Helper()
	is := &Issuer{
		ClientID: "agentctl", Gateway: "https://gateway.example.test",
		Routes:  []string{"models", "mcp/notes-mcp", "a2a/notes-agent"},
		SendIss: true,
		devices: map[string]*device{}, codes: map[string]*grant{}, refresh: map[string]*grant{},
		spent: map[string]*grant{}, sessions: map[string]bool{},
	}
	mux := http.NewServeMux()
	is.Server = httptest.NewTLSServer(mux)
	t.Cleanup(is.Server.Close)
	is.URL = is.Server.URL + "/realms/test"
	p := "/realms/test"
	mux.HandleFunc(p+"/.well-known/openid-configuration", is.discovery)
	mux.HandleFunc(p+"/protocol/openid-connect/auth", is.authorize)
	mux.HandleFunc(p+"/protocol/openid-connect/auth/device", is.deviceAuth)
	mux.HandleFunc(p+"/protocol/openid-connect/token", is.token)
	is.CAFile = filepath.Join(t.TempDir(), "ca.crt")
	cert := is.Server.Certificate()
	if err := os.WriteFile(is.CAFile, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: cert.Raw}), 0o644); err != nil {
		t.Fatal(err)
	}
	return is
}

// Client returns an HTTP client that trusts the issuer.
func (is *Issuer) Client() *http.Client { return is.Server.Client() }

func (is *Issuer) discovery(w http.ResponseWriter, r *http.Request) {
	base := is.URL + "/protocol/openid-connect"
	writeJSON(w, 200, map[string]any{
		"issuer":                                         is.URL,
		"authorization_endpoint":                         base + "/auth",
		"token_endpoint":                                 base + "/token",
		"device_authorization_endpoint":                  base + "/auth/device",
		"code_challenge_methods_supported":               []string{"plain", "S256"},
		"authorization_response_iss_parameter_supported": is.SendIss,
	})
}

func oauthError(w http.ResponseWriter, status int, code, desc string) {
	writeJSON(w, status, map[string]string{"error": code, "error_description": desc})
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// checkScope returns the route scopes of a scope parameter, refusing ones
// the client does not have.
func (is *Issuer) checkScope(scope string) ([]string, bool) {
	var routes []string
	for _, s := range strings.Fields(scope) {
		if s == "openid" {
			continue
		}
		if !slices.Contains(is.Routes, s) {
			return nil, false
		}
		routes = append(routes, s)
	}
	return routes, true
}

func (is *Issuer) next(prefix string) string {
	is.n++
	return fmt.Sprintf("%s-%d", prefix, is.n)
}

func (is *Issuer) authorize(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	redirect := q.Get("redirect_uri")
	u, err := url.Parse(redirect)
	if q.Get("client_id") != is.ClientID || err != nil || u.Scheme != "http" || u.Hostname() != "127.0.0.1" {
		http.Error(w, "Invalid parameter: redirect_uri", 400)
		return
	}
	if q.Get("code_challenge_method") != "S256" || q.Get("code_challenge") == "" {
		http.Error(w, "Missing parameter: code_challenge_method", 400)
		return
	}
	if _, ok := is.checkScope(q.Get("scope")); !ok {
		http.Error(w, "invalid_scope", 400)
		return
	}
	is.mu.Lock()
	code := is.next("code")
	is.codes[code] = &grant{scope: q.Get("scope"), challenge: q.Get("code_challenge"), redirect: redirect}
	is.mu.Unlock()
	back := url.Values{"code": {code}, "state": {q.Get("state")}}
	switch {
	case is.WrongIss:
		back.Set("iss", "https://elsewhere.example.test/realms/test")
	case is.SendIss:
		back.Set("iss", is.URL)
	}
	http.Redirect(w, r, redirect+"?"+back.Encode(), http.StatusFound)
}

func (is *Issuer) deviceAuth(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	is.mu.Lock()
	defer is.mu.Unlock()
	is.DeviceRequests++
	if r.PostForm.Get("client_id") != is.ClientID {
		oauthError(w, 401, "invalid_client", "")
		return
	}
	if r.PostForm.Get("code_challenge_method") == "" {
		oauthError(w, 400, "invalid_request", "Missing parameter: code_challenge_method")
		return
	}
	if r.PostForm.Get("code_challenge_method") != "S256" {
		oauthError(w, 400, "invalid_request", "Invalid parameter: code_challenge_method")
		return
	}
	if _, ok := is.checkScope(r.PostForm.Get("scope")); !ok {
		oauthError(w, 400, "invalid_scope", "")
		return
	}
	dc := is.next("device")
	uc := fmt.Sprintf("ABCD-%04d", is.n)
	is.devices[dc] = &device{userCode: uc, challenge: r.PostForm.Get("code_challenge"), scope: r.PostForm.Get("scope"), approved: is.AutoApprove}
	writeJSON(w, 200, map[string]any{
		"device_code": dc, "user_code": uc,
		"verification_uri":          is.Server.URL + "/realms/test/device",
		"verification_uri_complete": is.Server.URL + "/realms/test/device?user_code=" + uc,
		"expires_in":                600, "interval": 1,
	})
}

// Approve plays the person approving a device code in the browser.
func (is *Issuer) Approve(userCode string) bool {
	is.mu.Lock()
	defer is.mu.Unlock()
	for _, d := range is.devices {
		if d.userCode == userCode {
			d.approved = true
			return true
		}
	}
	return false
}

func s256(verifier string) string {
	sum := sha256.Sum256([]byte(verifier))
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

func (is *Issuer) token(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()
	f := r.PostForm
	is.mu.Lock()
	defer is.mu.Unlock()
	if f.Get("grant_type") == "client_credentials" {
		fc, ok := is.Federated[f.Get("client_id")]
		switch {
		case !ok || f.Get("client_assertion_type") != "urn:ietf:params:oauth:client-assertion-type:jwt-bearer" || f.Get("client_assertion") != fc.Assertion:
			oauthError(w, 401, "invalid_client", "Invalid client or Invalid client credentials")
		case fc.Audiences[f.Get("scope")] == "":
			oauthError(w, 400, "invalid_scope", "Invalid scopes: "+f.Get("scope"))
		default:
			is.ClientCredentials++
			writeJSON(w, 200, map[string]any{
				"access_token": jwt(map[string]any{"iss": is.URL, "azp": f.Get("client_id"), "aud": fc.Audiences[f.Get("scope")], "scope": f.Get("scope"), "exp": time.Now().Add(5 * time.Minute).Unix()}),
				"token_type":   "Bearer", "expires_in": 300, "scope": f.Get("scope"),
			})
		}
		return
	}
	if f.Get("client_id") != is.ClientID {
		oauthError(w, 401, "invalid_client", "")
		return
	}
	switch f.Get("grant_type") {
	case "urn:ietf:params:oauth:grant-type:device_code":
		d := is.devices[f.Get("device_code")]
		switch {
		case d == nil:
			oauthError(w, 400, "invalid_grant", "unknown device code")
		case !d.approved:
			oauthError(w, 400, "authorization_pending", "")
		case s256(f.Get("code_verifier")) != d.challenge:
			oauthError(w, 400, "invalid_grant", "PKCE verification failed")
		default:
			delete(is.devices, f.Get("device_code"))
			is.issue(w, d.scope, d.scope, is.next("session"))
		}
	case "authorization_code":
		g := is.codes[f.Get("code")]
		switch {
		case g == nil:
			oauthError(w, 400, "invalid_grant", "Code not valid")
		case g.redirect != f.Get("redirect_uri"):
			oauthError(w, 400, "invalid_grant", "Incorrect redirect_uri")
		case s256(f.Get("code_verifier")) != g.challenge:
			oauthError(w, 400, "invalid_grant", "PKCE verification failed")
		default:
			delete(is.codes, f.Get("code"))
			is.issue(w, g.scope, g.scope, is.next("session"))
		}
	case "refresh_token":
		rt := f.Get("refresh_token")
		if g, used := is.spent[rt]; used {
			// A reuse ends the client's session (T20, steps 8 and 9).
			is.Reuses++
			delete(is.sessions, g.session)
			oauthError(w, 400, "invalid_grant", "Stale token")
			return
		}
		g := is.refresh[rt]
		if g == nil || !is.sessions[g.session] {
			oauthError(w, 400, "invalid_grant", "Session not active")
			return
		}
		granted, _ := is.checkScope(g.scope)
		asked, ok := is.checkScope(f.Get("scope"))
		for _, s := range asked {
			if !slices.Contains(granted, s) {
				ok = false
			}
		}
		if !ok {
			oauthError(w, 400, "invalid_scope", "Invalid scopes: "+f.Get("scope"))
			return
		}
		is.Refreshes++
		is.LastRefreshScope = f.Get("scope")
		delete(is.refresh, rt)
		is.spent[rt] = g
		access := f.Get("scope")
		if access == "" {
			access = g.scope
		}
		is.issue(w, access, g.scope, g.session)
	default:
		oauthError(w, 400, "unsupported_grant_type", "")
	}
}

// issue answers with an access token for accessScope and a refresh token
// that keeps grantScope; the caller holds the lock.
func (is *Issuer) issue(w http.ResponseWriter, accessScope, grantScope, session string) {
	is.sessions[session] = true
	routes, _ := is.checkScope(accessScope)
	var aud []string
	for _, s := range routes {
		path := s
		if s == "models" {
			path = "v1"
		}
		aud = append(aud, is.Gateway+"/"+path)
	}
	refresh := jwt(map[string]any{"jti": is.next("refresh"), "typ": "Refresh", "scope": grantScope})
	is.refresh[refresh] = &grant{scope: grantScope, session: session}
	claims := map[string]any{
		"iss": is.URL, "sub": "user-1", "preferred_username": "agentic.developer@example.com",
		"scope": strings.TrimSpace("openid " + strings.Join(routes, " ")), "azp": is.ClientID,
		"exp": time.Now().Add(5 * time.Minute).Unix(), "sid": session,
	}
	if len(aud) == 1 {
		claims["aud"] = aud[0]
	} else if len(aud) > 1 {
		claims["aud"] = aud
	}
	writeJSON(w, 200, map[string]any{
		"access_token": jwt(claims), "refresh_token": refresh, "token_type": "Bearer",
		"expires_in": 300, "refresh_expires_in": 3600, "scope": claims["scope"],
	})
}

// jwt makes an unsigned token in a JWT's shape; deterministic for the same
// claims, so the refresh map's key and the token sent agree.
func jwt(claims map[string]any) string {
	h := base64.RawURLEncoding.EncodeToString([]byte(`{"alg":"none","typ":"JWT"}`))
	b, _ := json.Marshal(claims)
	return h + "." + base64.RawURLEncoding.EncodeToString(b) + ".c2ln"
}

// Live reports whether a session is still active.
func (is *Issuer) Live(session string) bool {
	is.mu.Lock()
	defer is.mu.Unlock()
	return is.sessions[session]
}

// Sessions counts the live sessions.
func (is *Issuer) Sessions() int {
	is.mu.Lock()
	defer is.mu.Unlock()
	n := 0
	for _, live := range is.sessions {
		if live {
			n++
		}
	}
	return n
}
