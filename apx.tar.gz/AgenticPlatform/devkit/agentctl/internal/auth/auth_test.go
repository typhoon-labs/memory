package auth

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/auth/authtest"
)

func client(is *authtest.Issuer) *Client {
	return &Client{Issuer: is.URL, ClientID: "agentctl", HTTP: is.Client(),
		Sleep: func(context.Context, time.Duration) error { return nil }}
}

func TestDiscoverRefusals(t *testing.T) {
	doc := map[string]any{}
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewEncoder(w).Encode(doc)
	}))
	defer srv.Close()
	c := &Client{Issuer: srv.URL + "/realms/x", ClientID: "agentctl", HTTP: srv.Client()}
	good := func() map[string]any {
		return map[string]any{
			"issuer": c.Issuer, "token_endpoint": srv.URL + "/token",
			"code_challenge_methods_supported": []string{"S256"},
		}
	}
	doc = good()
	if _, err := c.Discover(t.Context()); err != nil {
		t.Fatalf("a good document: %v", err)
	}
	for name, change := range map[string]func(map[string]any){
		"another issuer":      func(d map[string]any) { d["issuer"] = srv.URL + "/realms/y" },
		"http token endpoint": func(d map[string]any) { d["token_endpoint"] = "http://127.0.0.1/token" },
		"no S256":             func(d map[string]any) { d["code_challenge_methods_supported"] = []string{"plain"} },
		"no PKCE":             func(d map[string]any) { delete(d, "code_challenge_methods_supported") },
	} {
		doc = good()
		change(doc)
		if _, err := c.Discover(t.Context()); err == nil {
			t.Errorf("%s: accepted", name)
		}
	}
}

func TestDeviceApproved(t *testing.T) {
	is := authtest.New(t)
	c := client(is)
	m, _ := c.Discover(t.Context())
	polls := 0
	var userCode string
	c.Sleep = func(context.Context, time.Duration) error {
		polls++
		if polls == 3 {
			is.Approve(userCode)
		}
		return nil
	}
	tok, err := c.Device(t.Context(), m, []string{"models", "mcp/notes-mcp"}, func(dc DeviceCode) { userCode = dc.UserCode })
	if err != nil {
		t.Fatal(err)
	}
	if polls != 3 || tok.RefreshToken == "" {
		t.Fatalf("polls %d, tokens %v", polls, tok)
	}
	// The sign-in holds both routes; a refresh narrows to one.
	if c, _ := Claims(tok.AccessToken); len(Audiences(c)) != 2 {
		t.Fatalf("sign-in audiences %v", Audiences(c))
	}
	r, err := client(is).Refresh(t.Context(), m, tok.RefreshToken, "mcp/notes-mcp")
	if err != nil {
		t.Fatal(err)
	}
	if c, _ := Claims(r.AccessToken); fmt.Sprint(Audiences(c)) != "["+is.Gateway+"/mcp/notes-mcp]" {
		t.Fatalf("refresh audiences %v", Audiences(c))
	}
	if _, err := client(is).Refresh(t.Context(), m, tok.RefreshToken, "models"); !IsSessionEnded(err) {
		t.Fatalf("a reused refresh token: %v", err)
	}
	if _, err := client(is).Refresh(t.Context(), m, r.RefreshToken, ""); err == nil {
		t.Fatal("a refresh without a route scope was sent")
	}
}

func TestDeviceExpires(t *testing.T) {
	is := authtest.New(t)
	c := client(is)
	m, _ := c.Discover(t.Context())
	now := time.Now()
	c.Now = func() time.Time { return now }
	c.Sleep = func(context.Context, time.Duration) error { now = now.Add(time.Minute); return nil }
	_, err := c.Device(t.Context(), m, []string{"models"}, func(DeviceCode) {})
	if err == nil || !strings.Contains(err.Error(), "expired") {
		t.Fatalf("an unapproved code: %v", err)
	}
}

func TestDeviceRequiresPKCE(t *testing.T) {
	// The fake refuses a device request without a challenge, as Keycloak
	// 26.8.2 does; agentctl always sends one, so the request goes through.
	is := authtest.New(t)
	is.AutoApprove = true
	c := client(is)
	m, _ := c.Discover(t.Context())
	if _, err := c.Device(t.Context(), m, []string{"models"}, func(DeviceCode) {}); err != nil {
		t.Fatal(err)
	}
	resp, err := is.Client().PostForm(m.DeviceAuthorizationEndpoint, map[string][]string{"client_id": {"agentctl"}, "scope": {"openid"}})
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if resp.StatusCode != 400 {
		t.Fatalf("the fake took a device request without PKCE: %d", resp.StatusCode)
	}
}

func TestTokensHideSecrets(t *testing.T) {
	tk := &Tokens{AccessToken: "secret-access", RefreshToken: "secret-refresh", Scope: "openid models"}
	for _, s := range []string{fmt.Sprint(tk), fmt.Sprintf("%v %+v %#v %s", tk, tk, tk, tk)} {
		if strings.Contains(s, "secret") {
			t.Fatalf("printed a token: %s", s)
		}
	}
}

func TestAudience(t *testing.T) {
	cases := map[string]string{"models": "https://gw.test/v1", "mcp/notes-mcp": "https://gw.test/mcp/notes-mcp", "a2a/x-agent": "https://gw.test/a2a/x-agent"}
	for scope, want := range cases {
		if got := Audience("https://gw.test/", scope); got != want {
			t.Errorf("%s: %s", scope, got)
		}
	}
	for _, bad := range []string{"", "openid", "mcp/", "mcp/Notes", "tools/x", "models extra"} {
		if CheckRouteScope(bad) == nil {
			t.Errorf("%q accepted as a route scope", bad)
		}
	}
}
