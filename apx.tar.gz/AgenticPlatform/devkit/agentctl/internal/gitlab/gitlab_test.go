package gitlab

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestToken(t *testing.T) {
	home := t.TempDir()
	vars := map[string]string{"HOME": home}
	get := func(k string) string { return vars[k] }
	if _, _, err := Token(get, "gitlab.com"); err == nil || !strings.Contains(err.Error(), "GITLAB_TOKEN") {
		t.Fatalf("nothing set: %v", err)
	}
	dir := filepath.Join(home, ".config", "glab-cli")
	os.MkdirAll(dir, 0o700)
	os.WriteFile(filepath.Join(dir, "config.yml"), []byte("hosts:\n  gitlab.com:\n    token: from-glab\n    api_protocol: https\n  other.test:\n    token: other\n"), 0o600)
	if tok, src, err := Token(get, "gitlab.com"); err != nil || tok != "from-glab" || !strings.HasSuffix(src, "config.yml") {
		t.Fatalf("glab config: %q %q %v", tok, src, err)
	}
	if _, _, err := Token(get, "gitlab.example.test"); err == nil || strings.Contains(err.Error(), "from-glab") {
		t.Fatalf("another host: %v", err)
	}
	vars["GITLAB_TOKEN"] = "from-env"
	if tok, src, _ := Token(get, "gitlab.com"); tok != "from-env" || src != "$GITLAB_TOKEN" {
		t.Fatalf("environment first: %q %q", tok, src)
	}
}

func TestID(t *testing.T) {
	if got := ID("a/b c/d"); got != "a%2Fb%20c%2Fd" {
		t.Fatal(got)
	}
	if got := ID("89082549"); got != "89082549" {
		t.Fatal(got)
	}
}
