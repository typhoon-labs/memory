// Package gitlab is the small part of GitLab's REST API agentctl uses, as
// the person running it, with their own token: read a project, start a
// pipeline with inputs, and follow it.
package gitlab

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"go.yaml.in/yaml/v3"
)

// Client calls one GitLab instance's API.
type Client struct {
	BaseURL string // https://gitlab.com
	Token   string
	// JobToken says Token is a CI job's token, sent as JOB-TOKEN, which
	// GitLab takes on the endpoints a job token may call alone.
	JobToken bool
	HTTP     *http.Client
}

// APIError is an answer other than 2xx.
type APIError struct {
	Method, Path string
	Status       int
	Message      string
}

func (e *APIError) Error() string {
	s := fmt.Sprintf("GitLab answered %d to %s %s", e.Status, e.Method, e.Path)
	if e.Message != "" {
		s += ": " + e.Message
	}
	return s
}

// IsStatus reports whether err is an APIError with that status.
func IsStatus(err error, status int) bool {
	var ae *APIError
	return errors.As(err, &ae) && ae.Status == status
}

// ID turns a project's numeric ID or full path into its form in a URL.
func ID(project string) string {
	return strings.ReplaceAll(url.PathEscape(project), "/", "%2F")
}

func (c *Client) do(ctx context.Context, method, path string, body, out any) error {
	var rd io.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return err
		}
		rd = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, strings.TrimSuffix(c.BaseURL, "/")+"/api/v4/"+path, rd)
	if err != nil {
		return err
	}
	c.auth(req)
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(io.LimitReader(resp.Body, 4<<20))
	if err != nil {
		return err
	}
	if resp.StatusCode/100 != 2 {
		ae := &APIError{Method: method, Path: "/api/v4/" + path, Status: resp.StatusCode}
		var m struct {
			Message any    `json:"message"`
			Error   string `json:"error"`
		}
		if json.Unmarshal(data, &m) == nil {
			switch v := m.Message.(type) {
			case string:
				ae.Message = v
			case nil:
				ae.Message = m.Error
			default:
				b, _ := json.Marshal(v)
				ae.Message = string(b)
			}
		}
		return ae
	}
	if out == nil {
		return nil
	}
	return json.Unmarshal(data, out)
}

func (c *Client) auth(req *http.Request) {
	if c.JobToken {
		req.Header.Set("JOB-TOKEN", c.Token)
		return
	}
	// A personal access token works as a Bearer token too, and an OAuth
	// token from glab only as one.
	req.Header.Set("Authorization", "Bearer "+c.Token)
}

// MaxFile is the largest repository file agentctl reads.
const MaxFile = 4 << 20

// RawFile reads one file of a repository at a ref, through the raw-file
// endpoint, the one a job token may read files with. A file that is not
// there is an APIError with status 404.
func (c *Client) RawFile(ctx context.Context, project, path, ref string) ([]byte, error) {
	p := "projects/" + ID(project) + "/repository/files/" + url.PathEscape(path) + "/raw?ref=" + url.QueryEscape(ref)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, strings.TrimSuffix(c.BaseURL, "/")+"/api/v4/"+p, nil)
	if err != nil {
		return nil, err
	}
	c.auth(req)
	resp, err := c.HTTP.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(io.LimitReader(resp.Body, MaxFile+1))
	if err != nil {
		return nil, err
	}
	if resp.StatusCode/100 != 2 {
		return nil, &APIError{Method: http.MethodGet, Path: "/api/v4/projects/" + ID(project) + "/repository/files/" + path, Status: resp.StatusCode}
	}
	if len(data) > MaxFile {
		return nil, fmt.Errorf("%s at %s is larger than %d bytes", path, ref, MaxFile)
	}
	return data, nil
}

// Tag is the part of a tag agentctl reads.
type Tag struct {
	Name   string `json:"name"`
	Commit struct {
		ID string `json:"id"`
	} `json:"commit"`
	Protected bool `json:"protected"`
}

// Tags lists a project's tags, every page.
func (c *Client) Tags(ctx context.Context, project string) ([]Tag, error) {
	var all []Tag
	for page := 1; page <= 50; page++ {
		var tags []Tag
		if err := c.do(ctx, http.MethodGet, fmt.Sprintf("projects/%s/repository/tags?per_page=100&page=%d", ID(project), page), nil, &tags); err != nil {
			return nil, err
		}
		all = append(all, tags...)
		if len(tags) < 100 {
			return all, nil
		}
	}
	return nil, fmt.Errorf("project %s has more than 5000 tags", project)
}

// GetTag reads one tag.
func (c *Client) GetTag(ctx context.Context, project, tag string) (*Tag, error) {
	var t Tag
	err := c.do(ctx, http.MethodGet, "projects/"+ID(project)+"/repository/tags/"+url.PathEscape(tag), nil, &t)
	return &t, err
}

// BranchExists reports whether a branch exists.
func (c *Client) BranchExists(ctx context.Context, project, branch string) (bool, error) {
	err := c.do(ctx, http.MethodGet, "projects/"+ID(project)+"/repository/branches/"+url.PathEscape(branch), nil, nil)
	if IsStatus(err, http.StatusNotFound) {
		return false, nil
	}
	return err == nil, err
}

// Action is one file of a commit.
type Action struct {
	Action   string `json:"action"` // create or update
	FilePath string `json:"file_path"`
	Content  string `json:"content"`
}

// Commit makes one commit on a new branch from start, with the actions.
func (c *Client) Commit(ctx context.Context, project, branch, start, message string, actions []Action) (string, error) {
	var out struct {
		ID string `json:"id"`
	}
	err := c.do(ctx, http.MethodPost, "projects/"+ID(project)+"/repository/commits", map[string]any{
		"branch": branch, "start_branch": start, "commit_message": message, "actions": actions,
	}, &out)
	return out.ID, err
}

// MergeRequest is the part of a merge request agentctl reads.
type MergeRequest struct {
	IID    int    `json:"iid"`
	WebURL string `json:"web_url"`
}

// OpenMergeRequest opens a merge request from branch into target, its
// source branch removed when it merges.
func (c *Client) OpenMergeRequest(ctx context.Context, project, branch, target, title, description string) (*MergeRequest, error) {
	var mr MergeRequest
	err := c.do(ctx, http.MethodPost, "projects/"+ID(project)+"/merge_requests", map[string]any{
		"source_branch": branch, "target_branch": target, "title": title, "description": description, "remove_source_branch": true,
	}, &mr)
	return &mr, err
}

// Project is the part of a project agentctl reads.
type Project struct {
	ID                int    `json:"id"`
	PathWithNamespace string `json:"path_with_namespace"`
	WebURL            string `json:"web_url"`
	Namespace         struct {
		FullPath string `json:"full_path"`
	} `json:"namespace"`
}

// Project reads a project by numeric ID or full path.
func (c *Client) Project(ctx context.Context, project string) (*Project, error) {
	var p Project
	if err := c.do(ctx, http.MethodGet, "projects/"+ID(project), nil, &p); err != nil {
		return nil, err
	}
	return &p, nil
}

// Pipeline is the part of a pipeline agentctl reads.
type Pipeline struct {
	ID     int    `json:"id"`
	Status string `json:"status"`
	Ref    string `json:"ref"`
	WebURL string `json:"web_url"`
}

// Finished reports whether a pipeline's status will not change without
// someone acting: done, or waiting for a manual job or a schedule.
func (p *Pipeline) Finished() bool {
	switch p.Status {
	case "success", "failed", "canceled", "skipped", "manual", "scheduled":
		return true
	}
	return false
}

// CreatePipeline starts a pipeline on ref with pipeline inputs, not
// variables: projects may refuse variables to everyone
// (ci_pipeline_variables_minimum_override_role), and inputs are typed and
// checked against the pipeline's spec:inputs.
func (c *Client) CreatePipeline(ctx context.Context, project, ref string, inputs map[string]any) (*Pipeline, error) {
	var p Pipeline
	err := c.do(ctx, http.MethodPost, "projects/"+ID(project)+"/pipeline", map[string]any{"ref": ref, "inputs": inputs}, &p)
	return &p, err
}

// Pipeline reads a pipeline.
func (c *Client) Pipeline(ctx context.Context, project string, id int) (*Pipeline, error) {
	var p Pipeline
	err := c.do(ctx, http.MethodGet, fmt.Sprintf("projects/%s/pipelines/%d", ID(project), id), nil, &p)
	return &p, err
}

// Job is the part of a job agentctl reads.
type Job struct {
	ID     int    `json:"id"`
	Name   string `json:"name"`
	Stage  string `json:"stage"`
	Status string `json:"status"`
	WebURL string `json:"web_url"`
}

// Jobs lists a pipeline's jobs.
func (c *Client) Jobs(ctx context.Context, project string, pipeline int) ([]Job, error) {
	var jobs []Job
	err := c.do(ctx, http.MethodGet, fmt.Sprintf("projects/%s/pipelines/%d/jobs?per_page=100", ID(project), pipeline), nil, &jobs)
	return jobs, err
}

// Wait polls a pipeline until it finishes or ctx ends, calling seen on
// every change of status.
func (c *Client) Wait(ctx context.Context, project string, id int, every time.Duration, seen func(*Pipeline)) (*Pipeline, error) {
	last := ""
	for {
		p, err := c.Pipeline(ctx, project, id)
		if err != nil {
			return nil, err
		}
		if p.Status != last {
			seen(p)
			last = p.Status
		}
		if p.Finished() {
			return p, nil
		}
		t := time.NewTimer(every)
		select {
		case <-ctx.Done():
			t.Stop()
			return p, ctx.Err()
		case <-t.C:
		}
	}
}

// Token finds the person's own GitLab token for host, as glab does: the
// environment (GITLAB_TOKEN, GITLAB_ACCESS_TOKEN, OAUTH_TOKEN), then
// glab's config.yml (GLAB_CONFIG_DIR, else glab-cli under
// XDG_CONFIG_HOME or ~/.config). It returns the token and where it came
// from, for messages; never the token in a message.
func Token(getenv func(string) string, host string) (token, source string, err error) {
	for _, name := range []string{"GITLAB_TOKEN", "GITLAB_ACCESS_TOKEN", "OAUTH_TOKEN"} {
		if v := getenv(name); v != "" {
			return v, "$" + name, nil
		}
	}
	dir := getenv("GLAB_CONFIG_DIR")
	if dir == "" {
		base := getenv("XDG_CONFIG_HOME")
		if base == "" && getenv("HOME") != "" {
			base = filepath.Join(getenv("HOME"), ".config")
		}
		if base != "" {
			dir = filepath.Join(base, "glab-cli")
		}
	}
	if dir == "" {
		return "", "", errors.New("no GitLab token: set GITLAB_TOKEN, or sign in with glab auth login")
	}
	file := filepath.Join(dir, "config.yml")
	data, err := os.ReadFile(file)
	if err != nil {
		return "", "", errors.New("no GitLab token: set GITLAB_TOKEN, or sign in with glab auth login")
	}
	var cfg struct {
		Hosts map[string]struct {
			Token string `yaml:"token"`
		} `yaml:"hosts"`
	}
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return "", "", fmt.Errorf("%s: %w", file, err)
	}
	if t := cfg.Hosts[host].Token; t != "" {
		return t, file, nil
	}
	return "", "", fmt.Errorf("no GitLab token for %s in $GITLAB_TOKEN or %s (glab may keep it in the OS keyring, which agentctl does not read): set GITLAB_TOKEN", host, file)
}
