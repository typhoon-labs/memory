// Package conform runs the conformance runner's image, as environments
// pins it, against the local deployment from this machine
// (design/conformance.md: one runner image everywhere). The runner's own
// README says how a workstation run works: a configuration whose ca_file
// is the local CA and whose sign_in names the personas file; cases that
// need a position inside the cluster skip.
//
// The container gets no proxy variables, as no container here does, and
// reaches the platform's hostnames where this machine does: on its
// loopback, through the host network.
package conform

import (
	"encoding/json"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"

	"go.yaml.in/yaml/v3"
)

const (
	// Registry is where the Docker daemon pulls the runner's image from
	// locally: floci's registry by its loopback address, which the
	// sandbox's daemon reaches without its proxy and treats as insecure,
	// where registry.host's floci:4566 fails (B5 spikes, spike 2).
	Registry = "127.0.0.1:4566/000000000000/us-east-1"
	// VersionsFile is environments' pin file, relative to its checkout.
	VersionsFile = "versions.yaml"
	// VersionsKey is the runner's entry there.
	VersionsKey = "conformance-runner"

	// inDir is where the container finds the run's files: a directory
	// the runner's image does not have. Not /conform, which is the
	// image's entrypoint, a file: docker cannot mount anything under it
	// and fails to start the container.
	inDir      = "/run/conform"
	inConfig   = inDir + "/config.json"
	inCA       = inDir + "/ca.crt"
	inPersonas = inDir + "/personas.json"
	inOut      = inDir + "/out"
)

// Image reads the runner's image from environments' versions.yaml and
// names it under registry, by digest.
func Image(versionsFile, registry string) (string, error) {
	data, err := os.ReadFile(versionsFile)
	if err != nil {
		return "", err
	}
	var pins map[string]struct {
		Image  string `yaml:"image"`
		Digest string `yaml:"digest"`
	}
	if err := yaml.Unmarshal(data, &pins); err != nil {
		return "", fmt.Errorf("%s: %w", versionsFile, err)
	}
	p, ok := pins[VersionsKey]
	if !ok || p.Image == "" || !strings.HasPrefix(p.Digest, "sha256:") || len(p.Digest) != 71 {
		return "", fmt.Errorf("%s has no %s image pinned by digest", versionsFile, VersionsKey)
	}
	return strings.TrimSuffix(registry, "/") + "/" + p.Image + "@" + p.Digest, nil
}

// Run is one run's settings.
type Run struct {
	Image  string
	Config string // the run's configuration, JSON, with this machine's paths
	JUnit  string // where to copy the JUnit report; "" for none
	JSON   string // where to copy the JSON report; "" for none
	Args   []string
	UID    int
	GID    int
	// Loopback reports whether this machine resolves a name to a loopback
	// address; nil looks it up.
	Loopback func(name string) bool
}

// Prepared is a run ready for docker: its arguments, and what to do after.
type Prepared struct {
	Args []string
	dir  string
	run  Run
}

// Prepare rewrites the configuration for the container, its CA file and
// personas file mounted at fixed paths under inDir, and builds docker's
// arguments: the runner's flags in the form the conformance chart's Job
// gives them (-config=FILE, -junit=FILE). Close removes what it wrote.
func Prepare(r Run) (*Prepared, error) {
	raw, err := os.ReadFile(r.Config)
	if err != nil {
		return nil, err
	}
	var cfg map[string]any
	if err := json.Unmarshal(raw, &cfg); err != nil {
		return nil, fmt.Errorf("%s: %w", r.Config, err)
	}
	base := filepath.Dir(r.Config)
	// A file to mount must exist: given a path that does not, docker
	// would create it on this machine, as a directory owned by root.
	mounts := []string{}
	mount := func(key, path, in string) error {
		if !filepath.IsAbs(path) {
			path = filepath.Join(base, path)
		}
		if fi, err := os.Stat(path); err != nil {
			return fmt.Errorf("%s: %s: %w", r.Config, key, err)
		} else if !fi.Mode().IsRegular() {
			return fmt.Errorf("%s: %s: %s is not a file", r.Config, key, path)
		}
		mounts = append(mounts, path+":"+in+":ro")
		return nil
	}
	if ca, _ := cfg["ca_file"].(string); ca != "" {
		if err := mount("ca_file", ca, inCA); err != nil {
			return nil, err
		}
		cfg["ca_file"] = inCA
	}
	if si, ok := cfg["sign_in"].(map[string]any); ok {
		if pf, _ := si["personas_file"].(string); pf != "" {
			if err := mount("sign_in.personas_file", pf, inPersonas); err != nil {
				return nil, err
			}
			si["personas_file"] = inPersonas
		}
	}
	dir, err := os.MkdirTemp("", "agentctl-conform-")
	if err != nil {
		return nil, err
	}
	p := &Prepared{dir: dir, run: r}
	out := filepath.Join(dir, "out")
	if err := os.Mkdir(out, 0o700); err != nil {
		p.Close()
		return nil, err
	}
	rewritten, _ := json.MarshalIndent(cfg, "", "  ")
	cfgFile := filepath.Join(dir, "config.json")
	if err := os.WriteFile(cfgFile, rewritten, 0o600); err != nil {
		p.Close()
		return nil, err
	}

	args := []string{"run", "--rm", "--network", "host", "--user", fmt.Sprintf("%d:%d", r.UID, r.GID)}
	// Empty, not absent: the Docker CLI would otherwise add its own
	// configured proxies.
	for _, v := range []string{"HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "no_proxy", "all_proxy"} {
		args = append(args, "-e", v+"=")
	}
	domain, _ := cfg["platform_domain"].(string)
	if domain == "" {
		domain = "agentic.internal"
	}
	loopback := r.Loopback
	if loopback == nil {
		loopback = resolvesToLoopback
	}
	for _, name := range []string{"floci", "keycloak." + domain, "gateway." + domain, "workloads-gateway." + domain, "langfuse." + domain, "kagent." + domain} {
		if loopback(name) {
			args = append(args, "--add-host", name+":127.0.0.1")
		}
	}
	args = append(args, "-v", cfgFile+":"+inConfig+":ro", "-v", out+":"+inOut)
	for _, m := range mounts {
		args = append(args, "-v", m)
	}
	args = append(args, r.Image, "-config="+inConfig)
	if r.JUnit != "" {
		args = append(args, "-junit="+inOut+"/junit.xml")
	}
	if r.JSON != "" {
		args = append(args, "-json="+inOut+"/results.json")
	}
	p.Args = append(args, r.Args...)
	return p, nil
}

// Started reports whether a status of docker run's is the runner's own.
// docker run exits 125 when the daemon cannot create or start the
// container, a mount it cannot make or an image it cannot pull among
// them, 126 when the entrypoint cannot be run and 127 when it is not
// found; the runner itself exits 0, 1 or 2, and any other status, a
// signal's 128+n among them, is passed through as the runner's.
func Started(status int) bool { return status < 125 || status > 127 }

// Collect copies the reports the runner wrote to where they were asked
// for.
func (p *Prepared) Collect() error {
	for from, to := range map[string]string{"junit.xml": p.run.JUnit, "results.json": p.run.JSON} {
		if to == "" {
			continue
		}
		if err := copyFile(filepath.Join(p.dir, "out", from), to); err != nil {
			return fmt.Errorf("the runner's %s: %w", from, err)
		}
	}
	return nil
}

// Close removes the run's temporary files.
func (p *Prepared) Close() { os.RemoveAll(p.dir) }

func copyFile(from, to string) error {
	in, err := os.Open(from)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(to)
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

func resolvesToLoopback(name string) bool {
	addrs, err := net.LookupHost(name)
	if err != nil {
		return false
	}
	for _, a := range addrs {
		if ip := net.ParseIP(a); ip != nil && ip.IsLoopback() {
			return true
		}
	}
	return false
}
