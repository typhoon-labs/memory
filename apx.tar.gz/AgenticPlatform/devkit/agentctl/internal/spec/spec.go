// Package spec loads the platform's contracts from agent-sdk's spec/ and
// validates documents against its JSON Schemas (draft 2020-12).
//
// agentctl carries a vendored copy, embedded in the binary, so that it
// validates the same way wherever it runs; SOURCE records the agent-sdk
// commit and tag it came from, and vendor.sh refreshes it. LoadDir reads a
// working copy of spec/ instead, to try a spec change before it lands.
//
// The validator is github.com/santhosh-tekuri/jsonschema/v6 at v6.0.3, the
// module and version delegation-sts' contract tests use and with which
// the spec's schemas were checked (spec/schemas/README.md), with format
// assertions on, as there. Every schema is loaded under spec:///<path>,
// which keeps its path within spec/, so the schemas' relative $refs
// resolve (spec/README.md, "References").
package spec

import (
	"bufio"
	"bytes"
	"embed"
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"path"
	"strings"

	"github.com/santhosh-tekuri/jsonschema/v6"
	"golang.org/x/text/language"
	"golang.org/x/text/message"
)

//go:embed spec SOURCE
var vendored embed.FS

// The schemas agentctl validates with, relative to spec/.
const (
	WorkloadSchema   = "schemas/workload.schema.json"
	ArtifactSchema   = "schemas/artifact.schema.json"
	StepSchema       = "step/step.schema.json"
	StepFailure      = "step/failure.schema.json"
	LimitErrorSchema = "limits/error.schema.json"
	HeadersFile      = "headers/headers.json"
	// From 0.3.0.
	CatalogSchema = "schemas/catalog.schema.json"
	LibrarySchema = "schemas/library.schema.json"
	LockSchema    = "schemas/lock.schema.json"
)

// Source is where a spec came from.
type Source struct {
	Repository, Commit, Tag string
}

func (s Source) String() string {
	short := s.Commit
	if len(short) > 12 {
		short = short[:12]
	}
	if s.Tag != "" && s.Tag != "none" {
		return fmt.Sprintf("%s %s (%s)", s.Repository, s.Tag, short)
	}
	return fmt.Sprintf("%s at %s", s.Repository, short)
}

// Spec is a loaded spec: its files and every schema in it, compiled.
type Spec struct {
	FS      fs.FS // rooted at spec/
	Source  Source
	schemas map[string]*jsonschema.Schema
}

// Vendored loads the copy embedded in agentctl.
func Vendored() (*Spec, error) {
	sub, err := fs.Sub(vendored, "spec")
	if err != nil {
		return nil, err
	}
	src, err := readSource(vendored)
	if err != nil {
		return nil, err
	}
	return load(sub, src)
}

// LoadDir loads a working copy of spec/.
func LoadDir(dir string) (*Spec, error) {
	return load(os.DirFS(dir), Source{Repository: dir, Commit: "working copy", Tag: "none"})
}

func readSource(fsys fs.FS) (Source, error) {
	f, err := fsys.Open("SOURCE")
	if err != nil {
		return Source{}, err
	}
	defer f.Close()
	var s Source
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		k, v, ok := strings.Cut(sc.Text(), ": ")
		switch {
		case !ok || strings.HasPrefix(k, "#"):
		case k == "repository":
			s.Repository = v
		case k == "commit":
			s.Commit = v
		case k == "tag":
			s.Tag = v
		}
	}
	if s.Commit == "" {
		return s, fmt.Errorf("SOURCE names no commit")
	}
	return s, sc.Err()
}

// load adds every *.schema.json to one compiler, then compiles each, so
// that references between them resolve whatever the order.
func load(fsys fs.FS, src Source) (*Spec, error) {
	c := jsonschema.NewCompiler()
	c.DefaultDraft(jsonschema.Draft2020)
	c.AssertFormat()
	var names []string
	err := fs.WalkDir(fsys, ".", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(p, ".schema.json") {
			return err
		}
		raw, err := fs.ReadFile(fsys, p)
		if err != nil {
			return err
		}
		doc, err := jsonschema.UnmarshalJSON(bytes.NewReader(raw))
		if err != nil {
			return fmt.Errorf("%s: %w", p, err)
		}
		if err := c.AddResource(url(p), doc); err != nil {
			return fmt.Errorf("%s: %w", p, err)
		}
		names = append(names, p)
		return nil
	})
	if err != nil {
		return nil, err
	}
	s := &Spec{FS: fsys, Source: src, schemas: map[string]*jsonschema.Schema{}}
	for _, p := range names {
		sch, err := c.Compile(url(p))
		if err != nil {
			return nil, fmt.Errorf("%s: %w", p, err)
		}
		s.schemas[p] = sch
	}
	for _, want := range []string{WorkloadSchema, ArtifactSchema, LimitErrorSchema} {
		if s.schemas[want] == nil {
			return nil, fmt.Errorf("the spec (%s) has no %s", src, want)
		}
	}
	return s, nil
}

func url(p string) string { return "spec:///" + path.Clean(p) }

// Has reports whether the spec holds a schema.
func (s *Spec) Has(schema string) bool { return s.schemas[schema] != nil }

// Problem is one reason a document is invalid: where in the document, and
// what is wrong.
type Problem struct {
	Location string // a JSON pointer into the document; "" is the whole
	Message  string
}

func (p Problem) String() string {
	loc := p.Location
	if loc == "" {
		loc = "(the document)"
	}
	return loc + ": " + p.Message
}

// Validate checks a JSON value (as encoding/json or UnmarshalJSON decode
// it) against one of the spec's schemas. It returns the problems, none
// when the value is valid.
func (s *Spec) Validate(schema string, value any) ([]Problem, error) {
	sch := s.schemas[schema]
	if sch == nil {
		return nil, fmt.Errorf("the spec (%s) has no %s", s.Source, schema)
	}
	err := sch.Validate(value)
	if err == nil {
		return nil, nil
	}
	ve, ok := err.(*jsonschema.ValidationError)
	if !ok {
		return nil, err
	}
	return problems(ve), nil
}

// problems flattens a validation error to its leaves, the errors that say
// what is wrong, rather than every schema keyword that led to them.
func problems(ve *jsonschema.ValidationError) []Problem {
	var out []Problem
	var walk func(e *jsonschema.ValidationError)
	walk = func(e *jsonschema.ValidationError) {
		if len(e.Causes) == 0 {
			loc := ""
			for _, tok := range e.InstanceLocation {
				loc += "/" + strings.NewReplacer("~", "~0", "/", "~1").Replace(tok)
			}
			out = append(out, Problem{Location: loc, Message: e.ErrorKind.LocalizedString(printer)})
			return
		}
		for _, c := range e.Causes {
			walk(c)
		}
	}
	walk(ve)
	return out
}

var printer = message.NewPrinter(language.English)

// ParseJSON decodes JSON the way the validator expects: numbers as
// json.Number, so integers stay integers.
func ParseJSON(data []byte) (any, error) {
	d := json.NewDecoder(bytes.NewReader(data))
	d.UseNumber()
	var v any
	if err := d.Decode(&v); err != nil {
		return nil, err
	}
	if d.More() {
		return nil, fmt.Errorf("more than one JSON value")
	}
	return v, nil
}
