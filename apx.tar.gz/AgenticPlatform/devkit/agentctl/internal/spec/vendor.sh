#!/bin/sh
# Copy the JSON files of agent-sdk's spec/ at one commit into spec/ beside
# this script, and record where they came from in SOURCE, as delegation-sts'
# interop/contract/vendor.sh does. The READMEs stay in agent-sdk, since
# their links are relative to it. Never edit spec/ by hand: change
# agent-sdk, then run this again.
#
# Usage: internal/spec/vendor.sh [AGENT_SDK_DIR] [REV]
#   AGENT_SDK_DIR  a clone of devkit/agent-sdk; default: the workspace sibling
#   REV            a commit or tag, such as spec/v0.2.0; default: HEAD
set -eu
here=$(cd "$(dirname "$0")" && pwd)
sdk=${1:-$here/../../../agent-sdk}
rev=${2:-HEAD}

commit=$(git -C "$sdk" rev-parse --verify "$rev^{commit}")
tag=$(git -C "$sdk" tag --points-at "$commit" --list 'spec/v*' | sort -V | tail -n 1)

rm -rf "$here/spec"
git -C "$sdk" archive --format=tar "$commit" spec | tar -x -C "$here"
find "$here/spec" -type f ! -name '*.json' -exec rm {} +

cat > "$here/SOURCE" <<END
# spec/ beside this file holds the JSON files of devkit/agent-sdk's spec/
# at this commit, written by vendor.sh. Do not edit spec/ by hand.
repository: devkit/agent-sdk
commit: $commit
tag: ${tag:-none}
END
echo "vendored spec/ from $commit${tag:+ ($tag)}"
