package spec

import (
	"io/fs"
	"path"
	"strings"
	"testing"
)

// The 0.1.0 directories that predate the <case>.<schema>.json naming
// (spec/README.md, "Conventions"); delegation-sts' contract tests read
// them.
var legacy = map[string]bool{"audit/examples": true, "claims/examples": true}

// vectors yields every example and invalid file of the vendored spec with
// the schema its name gives.
func vectors(t *testing.T, s *Spec) (valid, invalid map[string]string) {
	t.Helper()
	valid, invalid = map[string]string{}, map[string]string{}
	fs.WalkDir(s.FS, ".", func(p string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(p, ".json") {
			return err
		}
		dir := path.Dir(p)
		kind := path.Base(dir)
		if (kind != "examples" && kind != "invalid") || legacy[dir] {
			return nil
		}
		parts := strings.Split(path.Base(p), ".")
		if len(parts) < 3 {
			t.Errorf("%s: not named <case>.<schema>.json", p)
			return nil
		}
		schema := path.Join(path.Dir(dir), parts[len(parts)-2]+".schema.json")
		if !s.Has(schema) {
			t.Errorf("%s: no schema %s", p, schema)
			return nil
		}
		if kind == "examples" {
			valid[p] = schema
		} else {
			invalid[p] = schema
		}
		return nil
	})
	return valid, invalid
}

// TestVendoredVectors runs every test vector of the vendored spec: each
// example validates and each invalid file does not, so agentctl agrees
// with the spec's own verdicts.
func TestVendoredVectors(t *testing.T) {
	s, err := Vendored()
	if err != nil {
		t.Fatal(err)
	}
	if s.Source.Commit == "" || s.Source.Repository != "devkit/agent-sdk" {
		t.Fatalf("SOURCE: %+v", s.Source)
	}
	valid, invalid := vectors(t, s)
	if len(valid) < 20 || len(invalid) < 20 {
		t.Fatalf("only %d examples and %d invalid files", len(valid), len(invalid))
	}
	for _, want := range []string{WorkloadSchema, ArtifactSchema, StepSchema, StepFailure, LimitErrorSchema} {
		if !s.Has(want) {
			t.Errorf("no %s", want)
		}
	}
	check := func(files map[string]string, wantValid bool) {
		for p, schema := range files {
			raw, _ := fs.ReadFile(s.FS, p)
			v, err := ParseJSON(raw)
			if err != nil {
				t.Errorf("%s: %v", p, err)
				continue
			}
			problems, err := s.Validate(schema, v)
			if err != nil {
				t.Errorf("%s: %v", p, err)
			}
			if wantValid && len(problems) > 0 {
				t.Errorf("%s should validate against %s: %v", p, schema, problems)
			}
			if !wantValid && len(problems) == 0 {
				t.Errorf("%s should not validate against %s", p, schema)
			}
		}
	}
	check(valid, true)
	check(invalid, false)
}

func TestProblemsNameTheField(t *testing.T) {
	s, err := Vendored()
	if err != nil {
		t.Fatal(err)
	}
	v, _ := ParseJSON([]byte(`{"name": "notes-agent", "kind": "agent", "runtime": "container", "owner": "reference", "support": "experimental",
		"limits": {"model_calls": 0, "tool_calls": 1, "tokens": 1, "wall_time_seconds": 1}, "colour": "blue"}`))
	problems, err := s.Validate(WorkloadSchema, v)
	if err != nil {
		t.Fatal(err)
	}
	text := ""
	for _, p := range problems {
		text += p.String() + "\n"
	}
	for _, want := range []string{"/limits/model_calls", "colour"} {
		if !strings.Contains(text, want) {
			t.Errorf("the problems do not name %s:\n%s", want, text)
		}
	}
}
