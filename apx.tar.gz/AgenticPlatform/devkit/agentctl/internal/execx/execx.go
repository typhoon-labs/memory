// Package execx runs external commands for agentctl through one interface,
// so that tests replace every command with a fake and never reach the real
// tools: kind, docker, git, the keychain tools or the bootstrap.
package execx

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os/exec"
	"syscall"
	"time"
)

// Cmd is one command to run.
type Cmd struct {
	Name   string    // looked up on PATH unless it holds a slash
	Args   []string  // without the name
	Dir    string    // the working directory; empty is the current one
	Env    []string  // the whole environment; nil inherits agentctl's
	Stdin  io.Reader // nil reads nothing
	Stdout io.Writer // nil discards
	Stderr io.Writer // nil discards
}

func (c Cmd) String() string {
	return fmt.Sprintf("%s %v", c.Name, c.Args)
}

// Runner runs a command to its end and returns its exit status. err is
// set only when the command could not be started (not found, not
// executable) or was stopped by the context; a non-zero status is not an
// error.
type Runner interface {
	Run(ctx context.Context, c Cmd) (status int, err error)
}

// ErrNotFound is returned when the command is not on PATH.
var ErrNotFound = errors.New("not found")

// OS runs commands for real.
type OS struct{}

// Run implements Runner.
func (OS) Run(ctx context.Context, c Cmd) (int, error) {
	path, err := exec.LookPath(c.Name)
	if err != nil {
		return -1, fmt.Errorf("%s: %w", c.Name, ErrNotFound)
	}
	cmd := exec.CommandContext(ctx, path, c.Args...)
	cmd.Dir, cmd.Env, cmd.Stdin, cmd.Stdout, cmd.Stderr = c.Dir, c.Env, c.Stdin, c.Stdout, c.Stderr
	// When agentctl is interrupted, ask the command to stop, as a
	// pipeline's cancel does, and kill it only if it has not after 10
	// seconds.
	cmd.Cancel = func() error { return cmd.Process.Signal(syscall.SIGTERM) }
	cmd.WaitDelay = 10 * time.Second
	err = cmd.Run()
	var exit *exec.ExitError
	switch {
	case err == nil:
		return 0, nil
	case errors.As(err, &exit) && exit.ExitCode() >= 0:
		return exit.ExitCode(), nil
	case ctx.Err() != nil:
		return -1, ctx.Err()
	default:
		return -1, err
	}
}

// Output runs c and returns its standard output, failing on a non-zero
// status with the command's standard error in the message.
func Output(ctx context.Context, r Runner, c Cmd) ([]byte, error) {
	var out, errOut limitedBuffer
	c.Stdout, c.Stderr = &out, &errOut
	status, err := r.Run(ctx, c)
	if err != nil {
		return nil, err
	}
	if status != 0 {
		return out.Bytes(), &StatusError{Cmd: c.Name, Status: status, Stderr: errOut.String()}
	}
	return out.Bytes(), nil
}

// StatusError is a command that ended with a non-zero status.
type StatusError struct {
	Cmd    string
	Status int
	Stderr string
}

func (e *StatusError) Error() string {
	if e.Stderr == "" {
		return fmt.Sprintf("%s exited with status %d", e.Cmd, e.Status)
	}
	return fmt.Sprintf("%s exited with status %d: %s", e.Cmd, e.Status, e.Stderr)
}

// limitedBuffer keeps at most 1 MiB, so a runaway command cannot exhaust
// memory through Output.
type limitedBuffer struct{ b []byte }

const maxOutput = 1 << 20

func (l *limitedBuffer) Write(p []byte) (int, error) {
	if room := maxOutput - len(l.b); room > 0 {
		if len(p) > room {
			l.b = append(l.b, p[:room]...)
		} else {
			l.b = append(l.b, p...)
		}
	}
	return len(p), nil
}

func (l *limitedBuffer) Bytes() []byte  { return l.b }
func (l *limitedBuffer) String() string { return string(l.b) }
