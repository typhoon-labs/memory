package execx

import (
	"context"
	"io"
	"sync"
)

// Fake is a Runner for tests: it records every command and answers with
// Handle, or with status 0 and no output when Handle is nil. It never
// starts a process.
type Fake struct {
	Handle func(c Cmd, stdin []byte) (status int, stdout, stderr string, err error)

	mu    sync.Mutex
	calls []Call
}

// Call is one command a Fake was asked to run.
type Call struct {
	Cmd   Cmd
	Stdin []byte
}

// Run implements Runner.
func (f *Fake) Run(ctx context.Context, c Cmd) (int, error) {
	var in []byte
	if c.Stdin != nil {
		in, _ = io.ReadAll(c.Stdin)
	}
	f.mu.Lock()
	f.calls = append(f.calls, Call{Cmd: c, Stdin: in})
	f.mu.Unlock()
	if f.Handle == nil {
		return 0, nil
	}
	status, out, errOut, err := f.Handle(c, in)
	if c.Stdout != nil {
		io.WriteString(c.Stdout, out)
	}
	if c.Stderr != nil {
		io.WriteString(c.Stderr, errOut)
	}
	return status, err
}

// Calls returns the commands run so far.
func (f *Fake) Calls() []Call {
	f.mu.Lock()
	defer f.mu.Unlock()
	return append([]Call(nil), f.calls...)
}
