package execx

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// TestCancelAsksFirst: when agentctl is interrupted, the command gets
// SIGTERM and its own exit status is reported, as a step command that
// writes its result on the way out needs.
func TestCancelAsksFirst(t *testing.T) {
	dir := t.TempDir()
	stub := filepath.Join(dir, "stub")
	ready := filepath.Join(dir, "ready")
	os.WriteFile(stub, []byte("#!/bin/sh\ntrap 'echo stopping; exit 42' TERM\n: > \""+ready+"\"\nwhile :; do sleep 0.05; done\n"), 0o755)
	ctx, cancel := context.WithCancel(context.Background())
	go func() {
		for range 200 {
			if _, err := os.Stat(ready); err == nil {
				break
			}
			time.Sleep(10 * time.Millisecond)
		}
		cancel()
	}()
	var out strings.Builder
	status, err := OS{}.Run(ctx, Cmd{Name: stub, Stdout: &out})
	if err != nil || status != 42 || !strings.Contains(out.String(), "stopping") {
		t.Fatalf("status %d, err %v, output %q", status, err, out.String())
	}
}

func TestStatusAndNotFound(t *testing.T) {
	stub := filepath.Join(t.TempDir(), "stub")
	os.WriteFile(stub, []byte("#!/bin/sh\necho oops >&2\nexit 3\n"), 0o755)
	if status, err := (OS{}).Run(context.Background(), Cmd{Name: stub}); err != nil || status != 3 {
		t.Fatalf("status %d, err %v", status, err)
	}
	_, err := Output(context.Background(), OS{}, Cmd{Name: stub})
	if st, ok := err.(*StatusError); !ok || st.Status != 3 || !strings.Contains(st.Stderr, "oops") {
		t.Fatalf("Output: %v", err)
	}
	if _, err := (OS{}).Run(context.Background(), Cmd{Name: "agentctl-no-such-command"}); err == nil {
		t.Fatal("a missing command ran")
	}
}
