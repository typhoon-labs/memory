// Package s3 reads and writes the catalog index's bucket for agentctl
// through the aws CLI, with whatever credentials and endpoint the
// person's or the job's environment gives it: agentctl holds none of its
// own.
package s3

import (
	"context"
	"encoding/json"
	"fmt"
	"net/url"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// Client runs one aws binary.
type Client struct {
	Runner execx.Runner
	// Path is the command; empty is aws on PATH.
	Path string
	// Env is the command's whole environment; nil inherits agentctl's.
	Env []string
}

// Location is a bucket and a key or key prefix.
type Location struct{ Bucket, Key string }

func (l Location) String() string { return "s3://" + l.Bucket + "/" + l.Key }

// Parse reads s3://bucket/key.
func Parse(s string) (Location, error) {
	u, err := url.Parse(s)
	if err != nil || u.Scheme != "s3" || u.Host == "" || u.RawQuery != "" || u.Fragment != "" {
		return Location{}, fmt.Errorf("%q is not s3://<bucket>/<key>", s)
	}
	return Location{Bucket: u.Host, Key: strings.TrimPrefix(u.Path, "/")}, nil
}

func (c Client) cmd(args ...string) execx.Cmd {
	name := c.Path
	if name == "" {
		name = "aws"
	}
	return execx.Cmd{Name: name, Args: args, Env: c.Env}
}

// List returns the keys under a prefix, every page. It asks the CLI for
// the keys alone, so a bucket that Object Lock keeps growing stays well
// under what agentctl reads of a command's output.
func (c Client) List(ctx context.Context, bucket, prefix string) ([]string, error) {
	out, err := execx.Output(ctx, c.Runner, c.cmd("s3api", "list-objects-v2", "--bucket", bucket, "--prefix", prefix, "--query", "Contents[].Key", "--output", "json"))
	if err != nil {
		return nil, fmt.Errorf("listing s3://%s/%s: %w", bucket, prefix, err)
	}
	var keys []string
	if t := strings.TrimSpace(string(out)); t == "" || t == "null" {
		return nil, nil
	}
	if err := json.Unmarshal(out, &keys); err != nil {
		return nil, fmt.Errorf("listing s3://%s/%s: %w", bucket, prefix, err)
	}
	return keys, nil
}

// Get copies one object to a local file.
func (c Client) Get(ctx context.Context, l Location, file string) error {
	if _, err := execx.Output(ctx, c.Runner, c.cmd("s3", "cp", "--only-show-errors", l.String(), file)); err != nil {
		return fmt.Errorf("reading %s: %w", l, err)
	}
	return nil
}

// Put copies a local file to one object, with a content type.
func (c Client) Put(ctx context.Context, file string, l Location, contentType string) error {
	if _, err := execx.Output(ctx, c.Runner, c.cmd("s3", "cp", "--only-show-errors", "--content-type", contentType, file, l.String())); err != nil {
		return fmt.Errorf("writing %s: %w", l, err)
	}
	return nil
}
