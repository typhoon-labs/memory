// Package defaults holds the values agentctl assumes when neither a flag
// nor an environment variable gives one: the local build's. They change at
// the swap to dev, and only here; each has an environment variable that
// overrides it.
package defaults

import (
	"embed"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const (
	// Issuer is the realm's issuer (design/identity.md, "The realm").
	// AGENTCTL_ISSUER overrides it.
	Issuer = "https://keycloak.agentic.internal/realms/agentic"
	// ClientID is the realm's public client for agentctl.
	// AGENTCTL_CLIENT_ID overrides it.
	ClientID = "agentctl"
	// Gateway is the developer deployment's base URL (design/identity.md,
	// "Endpoints and audiences"). AGENTCTL_GATEWAY overrides it.
	Gateway = "https://gateway.agentic.internal"
	// RouteScope is the route scope login asks for and token refreshes with
	// when none is named: the model route's, which Claude Code's
	// apiKeyHelper needs.
	RouteScope = "models"
	// TemplatesProject is devkit/workload-templates, whose generation job
	// agentctl new starts; the group it sits in is the sandbox group until
	// the swap to dev. AGENTCTL_TEMPLATES overrides it.
	TemplatesProject = "typhoon_labs/agentic-platform-sandbox/devkit/workload-templates"
	// EnvironmentsProject is infra/environments, where deploy request
	// opens its merge request. AGENTCTL_ENVIRONMENTS_PROJECT overrides it.
	EnvironmentsProject = "typhoon_labs/agentic-platform-sandbox/infra/environments"
	// FoundationProject is infra/aws-foundation, whose registrations
	// catalog build reads. AGENTCTL_FOUNDATION_PROJECT overrides it.
	FoundationProject = "typhoon_labs/agentic-platform-sandbox/infra/aws-foundation"
	// GitLab is the GitLab instance. GITLAB_HOST, as glab reads it,
	// overrides it.
	GitLab = "https://gitlab.com"
	// Environment is the environment whose catalog index, registry and
	// keys agentctl uses when -environment names none.
	// AGENTCTL_ENVIRONMENT overrides it.
	Environment = "local"
)

// An environment's values: where its catalog index is, its registry, and
// the public halves of the keys that sign its artifacts and its index.
// Only local's are known before the swap to dev.
type Env struct {
	Name string
	// Index is where the signed catalog index is read from: the newest
	// index under the index bucket's indexes/ prefix, through the aws
	// CLI. AGENTCTL_CATALOG_INDEX overrides it.
	Index string
	// Registry is registry.host, as clusters/<environment>/platform/
	// values.yaml names it.
	Registry string
	// PlainHTTP lists the registry hosts reached over plain HTTP: floci
	// locally. AGENTCTL_PLAIN_HTTP_REGISTRIES, comma-separated, overrides
	// it.
	PlainHTTP []string
	// ModelAliases are access/models.yaml's aliases: Claude Code's main
	// model, and its fast one.
	MainModel, FastModel string
	// ContextWindow is the model route's context window in input tokens:
	// the fake model's locally.
	ContextWindow int
	// AWSEndpoint is the endpoint the aws CLI is given when
	// AWS_ENDPOINT_URL is unset: floci locally, none in AWS.
	AWSEndpoint string
}

var envs = map[string]Env{
	"local": {
		Name:          "local",
		Index:         "s3://agentic-catalog-index-local/indexes/",
		Registry:      "floci:4566/000000000000/us-east-1",
		PlainHTTP:     []string{"floci:4566"},
		MainModel:     "reasoning-default",
		FastModel:     "fast-default",
		ContextWindow: 200000,
		AWSEndpoint:   "http://floci:4566",
	},
}

// ForEnvironment returns an environment's values.
func ForEnvironment(name string) (Env, error) {
	e, ok := envs[name]
	if !ok {
		return Env{}, fmt.Errorf("no values for the environment %q: agentctl knows %s", name, strings.Join(Environments(), ", "))
	}
	return e, nil
}

// Environments lists the environments agentctl has values for.
func Environments() []string {
	var names []string
	for n := range envs {
		names = append(names, n)
	}
	return names
}

//go:embed keys
var keys embed.FS

// The keys agentctl verifies with (design/distribution.md; D37): the
// release key signs every workload's and library artifact's release, the
// record key the catalog index and the release records.
const (
	ReleaseKey = "release-signing"
	RecordKey  = "record-signing"
)

// PublicKey returns the PEM of an environment's key, as agentctl carries
// it: read from KMS (GetPublicKey) when the environment's keys were
// made, and never fetched from where the index or an artifact comes from.
// AGENTCTL_RELEASE_KEY and AGENTCTL_RECORD_KEY override them.
func PublicKey(environment, key string) ([]byte, error) {
	b, err := keys.ReadFile("keys/" + environment + "/" + key + ".pub")
	if err != nil {
		return nil, fmt.Errorf("agentctl carries no %s public key for the environment %q", key, environment)
	}
	return b, nil
}

// LocalCAFile is the local build's CA certificate, which the bootstrap
// writes outside Git. It is used when it exists and AGENTCTL_CA_FILE is
// unset.
func LocalCAFile(home string) string {
	return filepath.Join(home, ".local", "share", "agentic-platform", "ca", "ca.crt")
}

// ConfigDir is where agentctl keeps its state: AGENTCTL_CONFIG_DIR, else
// agentctl under the user's configuration directory (~/.config on Linux,
// ~/Library/Application Support on macOS).
func ConfigDir(getenv func(string) string) (string, error) {
	if d := getenv("AGENTCTL_CONFIG_DIR"); d != "" {
		return d, nil
	}
	d, err := os.UserConfigDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(d, "agentctl"), nil
}

// CacheDir is where agentctl keeps what it can fetch again, such as the
// environments checkout: AGENTCTL_CACHE_DIR, else agentctl under the
// user's cache directory.
func CacheDir(getenv func(string) string) (string, error) {
	if d := getenv("AGENTCTL_CACHE_DIR"); d != "" {
		return d, nil
	}
	d, err := os.UserCacheDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(d, "agentctl"), nil
}

// Get returns getenv(name), or def when it is empty.
func Get(getenv func(string) string, name, def string) string {
	if v := getenv(name); v != "" {
		return v
	}
	return def
}
