// Package lock reads and writes a repository's .agents/lock.yaml: each
// library artifact installed, by digest, with its canonical copy under
// .agents/ and the link each harness reads it through
// (design/distribution.md, "Installing into local harnesses"), as
// agent-sdk's spec/schemas/lock.schema.json defines it.
package lock

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/spec"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/validate"
)

// File is the lock file's path, relative to the repository's root.
const File = ".agents/lock.yaml"

// Version is the lock file format agentctl writes and reads.
const Version = 1

// Lock is the lock file.
type Lock struct {
	LockfileVersion int        `yaml:"lockfile_version" json:"lockfile_version"`
	Artifacts       []Artifact `yaml:"artifacts" json:"artifacts"`
}

// Artifact is one installed artifact.
type Artifact struct {
	Kind      string `yaml:"kind" json:"kind"`
	Name      string `yaml:"name" json:"name"`
	Version   string `yaml:"version" json:"version"`
	Reference string `yaml:"reference" json:"reference"`
	Path      string `yaml:"path" json:"path"`
	Links     []Link `yaml:"links,omitempty" json:"links,omitempty"`
}

// Link is one harness's link to the canonical copy.
type Link struct {
	Harness string `yaml:"harness" json:"harness"`
	Path    string `yaml:"path" json:"path"`
}

// CanonicalPath is where an artifact's canonical copy lives:
// .agents/<kind>s/<name>.
func CanonicalPath(kind, name string) string {
	return ".agents/" + kind + "s/" + name
}

// ClaudeSkillLink is Claude Code's link to a skill: .claude/skills/<name>.
// Codex reads .agents/skills itself, and neither harness has a place of
// its own for a prompt, so a skill's is the only link.
func ClaudeSkillLink(name string) string { return ".claude/skills/" + name }

// Load reads the lock file under root, or an empty one if there is none,
// and checks it against the spec's schema.
func Load(s *spec.Spec, root string) (*Lock, error) {
	data, err := os.ReadFile(filepath.Join(root, File))
	if errors.Is(err, fs.ErrNotExist) {
		return &Lock{LockfileVersion: Version, Artifacts: []Artifact{}}, nil
	}
	if err != nil {
		return nil, err
	}
	v, err := validate.Decode(data)
	if err != nil {
		return nil, fmt.Errorf("%s: %w", File, err)
	}
	if err := check(s, v); err != nil {
		return nil, err
	}
	var l Lock
	if err := yaml.Unmarshal(data, &l); err != nil {
		return nil, fmt.Errorf("%s: %w", File, err)
	}
	return &l, nil
}

func check(s *spec.Spec, v any) error {
	problems, err := s.Validate(spec.LockSchema, v)
	if err != nil {
		return err
	}
	if len(problems) > 0 {
		var b bytes.Buffer
		fmt.Fprintf(&b, "%s does not match spec/schemas/lock.schema.json:", File)
		for _, p := range problems {
			b.WriteString("\n  " + p.String())
		}
		return errors.New(b.String())
	}
	return nil
}

// Find returns an installed artifact by name, or nil.
func (l *Lock) Find(name string) *Artifact {
	for i := range l.Artifacts {
		if l.Artifacts[i].Name == name {
			return &l.Artifacts[i]
		}
	}
	return nil
}

// Put adds an artifact or replaces the one of that name.
func (l *Lock) Put(a Artifact) {
	if old := l.Find(a.Name); old != nil {
		*old = a
		return
	}
	l.Artifacts = append(l.Artifacts, a)
}

// Remove drops an artifact by name.
func (l *Lock) Remove(name string) {
	out := l.Artifacts[:0]
	for _, a := range l.Artifacts {
		if a.Name != name {
			out = append(out, a)
		}
	}
	l.Artifacts = out
}

const header = `# Written by agentctl install, update and remove: each library artifact
# installed here, by digest (agent-sdk's spec/schemas/lock.schema.json).
# Commit it with the repository; do not edit it by hand.
`

// Save checks the lock file against the schema, then writes it under
// root: to a new file, renamed over the old one.
func (l *Lock) Save(s *spec.Spec, root string) error {
	l.LockfileVersion = Version
	if l.Artifacts == nil {
		l.Artifacts = []Artifact{}
	}
	sort.Slice(l.Artifacts, func(i, j int) bool {
		if l.Artifacts[i].Kind != l.Artifacts[j].Kind {
			return l.Artifacts[i].Kind < l.Artifacts[j].Kind
		}
		return l.Artifacts[i].Name < l.Artifacts[j].Name
	})
	raw, err := json.Marshal(l)
	if err != nil {
		return err
	}
	v, err := spec.ParseJSON(raw)
	if err != nil {
		return err
	}
	if err := check(s, v); err != nil {
		return fmt.Errorf("not writing it: %w", err)
	}
	var b bytes.Buffer
	b.WriteString(header)
	enc := yaml.NewEncoder(&b)
	enc.SetIndent(2)
	if err := enc.Encode(l); err != nil {
		return err
	}
	enc.Close()
	path := filepath.Join(root, File)
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".lock.yaml-")
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.Write(b.Bytes()); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Chmod(0o644); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmp.Name(), path)
}
