// Package oci fetches images and OCI artifacts for agentctl with ORAS
// (design/distribution.md, "Installing into local harnesses"), by digest
// alone, and checks every manifest and blob against its digest itself, so
// a registry that answers with other bytes is refused.
//
// A library artifact is a scratch image, as library-release pushes it: an
// OCI index of per-platform image manifests, each with one tar layer that
// holds the artifact's files at its root (D28; the seam with
// ci-components). Unpack extracts such a layer, regular files and
// directories alone.
package oci

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// Limits on what agentctl fetches: a library artifact is a few files.
const (
	MaxManifest = 4 << 20
	MaxLayer    = 64 << 20
	MaxFiles    = 10000
	MaxUnpacked = 256 << 20
)

// Client runs one oras binary.
type Client struct {
	Runner execx.Runner
	// Path is the command; empty is oras on PATH.
	Path string
	// Env is the command's whole environment; nil inherits agentctl's.
	Env []string
	// PlainHTTP says whether a registry host speaks plain HTTP.
	PlainHTTP func(host string) bool
}

// Reference is an image or artifact by digest: host/repository@sha256:hex.
type Reference struct {
	Host, Repository, Digest string
}

func (r Reference) String() string { return r.Host + "/" + r.Repository + "@" + r.Digest }

// Repo is the reference without its digest.
func (r Reference) Repo() string { return r.Host + "/" + r.Repository }

var (
	digestRE = regexp.MustCompile(`^sha256:[0-9a-f]{64}$`)
	refRE    = regexp.MustCompile(`^([a-z0-9]([a-z0-9.-]*[a-z0-9])?(:[0-9]+)?)/([a-z0-9]+([._-][a-z0-9]+)*(/[a-z0-9]+([._-][a-z0-9]+)*)*)@(sha256:[0-9a-f]{64})$`)
)

// ParseReference reads a reference by digest, as the catalog index's
// schema writes one; a tag is refused.
func ParseReference(s string) (Reference, error) {
	m := refRE.FindStringSubmatch(s)
	if m == nil {
		return Reference{}, fmt.Errorf("%q is not <registry>/<repository>@sha256:<64 hex>", s)
	}
	return Reference{Host: m[1], Repository: m[4], Digest: m[8]}, nil
}

// ValidDigest reports whether s is sha256: and 64 lowercase hex digits.
func ValidDigest(s string) bool { return digestRE.MatchString(s) }

func (c Client) cmd(host string, args ...string) execx.Cmd {
	name := c.Path
	if name == "" {
		name = "oras"
	}
	if c.PlainHTTP != nil && c.PlainHTTP(host) {
		last := len(args) - 1
		args = append(append(append([]string{}, args[:last]...), "--plain-http"), args[last])
	}
	return execx.Cmd{Name: name, Args: args, Env: c.Env}
}

// Resolve returns the digest a tag points at now: host/repository:tag.
func (c Client) Resolve(ctx context.Context, host, repository, tag string) (string, error) {
	out, err := execx.Output(ctx, c.Runner, c.cmd(host, "resolve", host+"/"+repository+":"+tag))
	if err != nil {
		return "", fmt.Errorf("oras resolve %s/%s:%s: %w", host, repository, tag, err)
	}
	d := strings.TrimSpace(string(out))
	if !ValidDigest(d) {
		return "", fmt.Errorf("oras resolve %s/%s:%s: %q is not a digest", host, repository, tag, d)
	}
	return d, nil
}

// fetch runs oras writing to a file of at most max bytes, and checks that
// the bytes hash to digest.
func (c Client) fetch(ctx context.Context, host string, max int64, digest string, args ...string) ([]byte, error) {
	f, err := os.CreateTemp("", "agentctl-oci-")
	if err != nil {
		return nil, err
	}
	defer os.Remove(f.Name())
	defer f.Close()
	var errOut strings.Builder
	cmd := c.cmd(host, args...)
	cmd.Stdout = &capped{w: f, left: max + 1}
	cmd.Stderr = &capped{w: &errOut, left: 64 << 10}
	status, err := c.Runner.Run(ctx, cmd)
	if err != nil {
		return nil, fmt.Errorf("oras: %w", err)
	}
	if status != 0 {
		return nil, fmt.Errorf("oras %s: exited with status %d: %s", strings.Join(args[:2], " "), status, strings.TrimSpace(errOut.String()))
	}
	if _, err := f.Seek(0, io.SeekStart); err != nil {
		return nil, err
	}
	data, err := io.ReadAll(io.LimitReader(f, max+1))
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > max {
		return nil, fmt.Errorf("%s is larger than %d bytes", digest, max)
	}
	if got := Digest(data); got != digest {
		return nil, &Changed{Want: digest, Got: got}
	}
	return data, nil
}

// Changed is content whose digest is not the one asked for.
type Changed struct{ Want, Got string }

func (c *Changed) Error() string {
	return fmt.Sprintf("the registry answered with other content: %s hashes to %s", c.Want, c.Got)
}

// IsChanged reports whether err is a Changed.
func IsChanged(err error) bool {
	var c *Changed
	return errors.As(err, &c)
}

// Digest is the OCI digest of data.
func Digest(data []byte) string {
	h := sha256.Sum256(data)
	return "sha256:" + hex.EncodeToString(h[:])
}

// Manifest fetches a manifest or index by digest.
func (c Client) Manifest(ctx context.Context, r Reference, digest string) ([]byte, error) {
	return c.fetch(ctx, r.Host, MaxManifest, digest, "manifest", "fetch", "--output", "-", r.Repo()+"@"+digest)
}

// Blob fetches a blob by digest, of at most max bytes.
func (c Client) Blob(ctx context.Context, r Reference, digest string, max int64) ([]byte, error) {
	return c.fetch(ctx, r.Host, max, digest, "blob", "fetch", "--output", "-", r.Repo()+"@"+digest)
}

// Descriptor is an OCI descriptor.
type Descriptor struct {
	MediaType   string            `json:"mediaType"`
	Digest      string            `json:"digest"`
	Size        int64             `json:"size"`
	Platform    *Platform         `json:"platform,omitempty"`
	Annotations map[string]string `json:"annotations,omitempty"`
}

// Platform is an index entry's platform.
type Platform struct {
	OS           string `json:"os"`
	Architecture string `json:"architecture"`
}

type manifest struct {
	MediaType string       `json:"mediaType"`
	Manifests []Descriptor `json:"manifests"`
	Layers    []Descriptor `json:"layers"`
}

const (
	mediaIndex       = "application/vnd.oci.image.index.v1+json"
	mediaDockerList  = "application/vnd.docker.distribution.manifest.list.v2+json"
	mediaManifest    = "application/vnd.oci.image.manifest.v1+json"
	mediaDockerImage = "application/vnd.docker.distribution.manifest.v2+json"
)

var layerTypes = map[string]bool{
	"application/vnd.oci.image.layer.v1.tar+gzip":       true,
	"application/vnd.oci.image.layer.v1.tar":            false,
	"application/vnd.docker.image.rootfs.diff.tar.gzip": true,
}

// Unpack fetches the artifact r names and extracts its files into dir,
// which must not exist yet. An index's linux/amd64 manifest is taken, or
// its first, since a library artifact's files are the same on every
// platform. Every manifest and layer is checked against its digest; only
// tar layers are taken, and in them only regular files and directories
// under the root.
func (c Client) Unpack(ctx context.Context, r Reference, dir string) error {
	raw, err := c.Manifest(ctx, r, r.Digest)
	if err != nil {
		return err
	}
	var m manifest
	if err := json.Unmarshal(raw, &m); err != nil {
		return fmt.Errorf("%s: not a manifest: %w", r, err)
	}
	if m.MediaType == mediaIndex || m.MediaType == mediaDockerList || (m.MediaType == "" && len(m.Manifests) > 0) {
		d, err := pick(m.Manifests)
		if err != nil {
			return fmt.Errorf("%s: %w", r, err)
		}
		raw, err = c.Manifest(ctx, r, d.Digest)
		if err != nil {
			return err
		}
		m = manifest{}
		if err := json.Unmarshal(raw, &m); err != nil {
			return fmt.Errorf("%s: not a manifest: %w", r, err)
		}
	}
	if m.MediaType != mediaManifest && m.MediaType != mediaDockerImage {
		return fmt.Errorf("%s: a manifest of type %q, not an image manifest", r, m.MediaType)
	}
	if len(m.Layers) == 0 {
		return fmt.Errorf("%s: no layer", r)
	}
	if err := os.Mkdir(dir, 0o755); err != nil {
		return err
	}
	u := &unpacker{root: dir}
	for _, l := range m.Layers {
		gz, ok := layerTypes[l.MediaType]
		if !ok {
			return fmt.Errorf("%s: a layer of type %q, not a tar layer", r, l.MediaType)
		}
		if !ValidDigest(l.Digest) || l.Size > MaxLayer {
			return fmt.Errorf("%s: layer %s is not one agentctl takes (at most %d bytes)", r, l.Digest, MaxLayer)
		}
		data, err := c.Blob(ctx, r, l.Digest, MaxLayer)
		if err != nil {
			return err
		}
		if err := u.layer(data, gz); err != nil {
			return fmt.Errorf("%s: layer %s: %w", r, l.Digest, err)
		}
	}
	if u.files == 0 {
		return fmt.Errorf("%s: no file", r)
	}
	return nil
}

func pick(ds []Descriptor) (Descriptor, error) {
	var first *Descriptor
	for i, d := range ds {
		if d.MediaType != mediaManifest && d.MediaType != mediaDockerImage {
			continue
		}
		if !ValidDigest(d.Digest) {
			return Descriptor{}, fmt.Errorf("an index entry with digest %q", d.Digest)
		}
		if d.Platform != nil && d.Platform.OS == "linux" && d.Platform.Architecture == "amd64" {
			return d, nil
		}
		if first == nil {
			first = &ds[i]
		}
	}
	if first == nil {
		return Descriptor{}, errors.New("an index with no image manifest")
	}
	return *first, nil
}

type unpacker struct {
	root  string
	files int
	bytes int64
}

func (u *unpacker) layer(data []byte, gz bool) error {
	var rd io.Reader = bytes.NewReader(data)
	if gz {
		z, err := gzip.NewReader(rd)
		if err != nil {
			return err
		}
		defer z.Close()
		rd = z
	}
	tr := tar.NewReader(rd)
	for {
		h, err := tr.Next()
		if errors.Is(err, io.EOF) {
			return nil
		}
		if err != nil {
			return err
		}
		name, err := Clean(h.Name)
		if err != nil {
			return err
		}
		if name == "" {
			continue
		}
		if strings.HasPrefix(path.Base(name), ".wh.") {
			return fmt.Errorf("%q: a whiteout, which a library artifact never holds", h.Name)
		}
		target := filepath.Join(u.root, filepath.FromSlash(name))
		switch h.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
		case tar.TypeReg:
			u.files++
			u.bytes += h.Size
			if u.files > MaxFiles || u.bytes > MaxUnpacked {
				return fmt.Errorf("more than %d files or %d bytes", MaxFiles, MaxUnpacked)
			}
			if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
				return err
			}
			if fi, err := os.Lstat(target); err == nil && !fi.Mode().IsRegular() {
				return fmt.Errorf("%q: a file over a directory", h.Name)
			}
			mode := os.FileMode(0o644)
			if h.Mode&0o111 != 0 {
				mode = 0o755
			}
			f, err := os.OpenFile(target, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, mode)
			if err != nil {
				return err
			}
			_, err = io.Copy(f, io.LimitReader(tr, h.Size))
			if cerr := f.Close(); err == nil {
				err = cerr
			}
			if err != nil {
				return err
			}
		default:
			return fmt.Errorf("%q: a %s, and a library artifact holds regular files and directories alone", h.Name, typeName(h.Typeflag))
		}
	}
}

func typeName(t byte) string {
	switch t {
	case tar.TypeSymlink:
		return "symbolic link"
	case tar.TypeLink:
		return "hard link"
	case tar.TypeChar, tar.TypeBlock:
		return "device file"
	case tar.TypeFifo:
		return "named pipe"
	}
	return fmt.Sprintf("tar entry of type %q", t)
}

// Clean turns a tar entry's name into a relative slash path inside the
// root, or refuses it: absolute, or with a .. segment. "" is the root.
func Clean(name string) (string, error) {
	n := strings.TrimPrefix(name, "./")
	if strings.HasPrefix(n, "/") || strings.Contains(n, "\\") {
		return "", fmt.Errorf("%q: not a relative path", name)
	}
	for _, seg := range strings.Split(n, "/") {
		if seg == ".." {
			return "", fmt.Errorf("%q: a .. segment", name)
		}
	}
	c := path.Clean(n)
	if c == "." {
		return "", nil
	}
	return c, nil
}

// capped writes at most left bytes, then discards, so a runaway command
// cannot fill the disk; the caller sees the excess as too large.
type capped struct {
	w    io.Writer
	left int64
}

func (c *capped) Write(p []byte) (int, error) {
	n := len(p)
	if c.left <= 0 {
		return n, nil
	}
	if int64(len(p)) > c.left {
		p = p[:c.left]
	}
	c.left -= int64(len(p))
	if _, err := c.w.Write(p); err != nil {
		return 0, err
	}
	return n, nil
}
