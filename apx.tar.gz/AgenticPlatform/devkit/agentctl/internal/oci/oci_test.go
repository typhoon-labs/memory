package oci

import (
	"archive/tar"
	"bytes"
	"compress/gzip"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/devkit/agentctl/internal/execx"
)

// registry is a fake oras over blobs by digest.
type registry struct {
	blobs map[string][]byte
	// serve replaces what is answered for a digest.
	serve map[string][]byte
}

func (r *registry) runner() *execx.Fake {
	return &execx.Fake{Handle: func(c execx.Cmd, _ []byte) (int, string, string, error) {
		ref := c.Args[len(c.Args)-1]
		_, d, ok := strings.Cut(ref, "@")
		if !ok {
			return 1, "", "by digest only", nil
		}
		if b, ok := r.serve[d]; ok {
			return 0, string(b), "", nil
		}
		b, ok := r.blobs[d]
		if !ok {
			return 1, "", "not found", nil
		}
		return 0, string(b), "", nil
	}}
}

func (r *registry) put(b []byte) string {
	d := Digest(b)
	r.blobs[d] = b
	return d
}

type entry struct {
	name string
	typ  byte
	body string
	link string
}

func layer(t *testing.T, entries ...entry) []byte {
	t.Helper()
	var buf bytes.Buffer
	z := gzip.NewWriter(&buf)
	tw := tar.NewWriter(z)
	for _, e := range entries {
		h := &tar.Header{Name: e.name, Typeflag: e.typ, Mode: 0o644, Size: int64(len(e.body)), Linkname: e.link}
		if e.typ != tar.TypeReg {
			h.Size = 0
		}
		if err := tw.WriteHeader(h); err != nil {
			t.Fatal(err)
		}
		if e.typ == tar.TypeReg {
			tw.Write([]byte(e.body))
		}
	}
	tw.Close()
	z.Close()
	return buf.Bytes()
}

// image pushes a scratch image of one layer, as an index of two
// platforms, and returns the index's digest.
func (r *registry) image(t *testing.T, l []byte) string {
	t.Helper()
	ld := r.put(l)
	cfg := r.put([]byte(`{"architecture":"amd64","os":"linux"}`))
	man := func(arch string) Descriptor {
		m, _ := json.Marshal(map[string]any{
			"schemaVersion": 2, "mediaType": mediaManifest,
			"config": map[string]any{"mediaType": "application/vnd.oci.image.config.v1+json", "digest": cfg, "size": 2},
			"layers": []map[string]any{{"mediaType": "application/vnd.oci.image.layer.v1.tar+gzip", "digest": ld, "size": len(l)}},
			"arch":   arch,
		})
		return Descriptor{MediaType: mediaManifest, Digest: r.put(m), Size: int64(len(m)), Platform: &Platform{OS: "linux", Architecture: arch}}
	}
	idx, _ := json.Marshal(map[string]any{"schemaVersion": 2, "mediaType": mediaIndex, "manifests": []Descriptor{man("arm64"), man("amd64")}})
	return r.put(idx)
}

func ref(d string) Reference {
	return Reference{Host: "floci:4566", Repository: "000000000000/us-east-1/library/skill/x", Digest: d}
}

func TestUnpack(t *testing.T) {
	r := &registry{blobs: map[string][]byte{}, serve: map[string][]byte{}}
	d := r.image(t, layer(t,
		entry{name: "./", typ: tar.TypeDir},
		entry{name: "SKILL.md", typ: tar.TypeReg, body: "# A skill\n"},
		entry{name: "references/", typ: tar.TypeDir},
		entry{name: "references/notes.md", typ: tar.TypeReg, body: "notes"},
	))
	dir := filepath.Join(t.TempDir(), "out")
	c := Client{Runner: r.runner()}
	if err := c.Unpack(t.Context(), ref(d), dir); err != nil {
		t.Fatal(err)
	}
	if b, _ := os.ReadFile(filepath.Join(dir, "SKILL.md")); string(b) != "# A skill\n" {
		t.Errorf("SKILL.md: %q", b)
	}
	if b, _ := os.ReadFile(filepath.Join(dir, "references", "notes.md")); string(b) != "notes" {
		t.Errorf("references/notes.md: %q", b)
	}
}

func TestUnpackRefuses(t *testing.T) {
	cases := map[string][]entry{
		"a symbolic link": {{name: "SKILL.md", typ: tar.TypeSymlink, link: "/etc/passwd"}},
		"a hard link":     {{name: "a", typ: tar.TypeReg, body: "x"}, {name: "b", typ: tar.TypeLink, link: "a"}},
		"a .. segment":    {{name: "../escape.md", typ: tar.TypeReg, body: "x"}},
		"a relative path": {{name: "/etc/cron.d/x", typ: tar.TypeReg, body: "x"}},
		"a device file":   {{name: "dev", typ: tar.TypeChar}},
		"a whiteout":      {{name: ".wh.SKILL.md", typ: tar.TypeReg}},
		"no file":         {{name: "empty/", typ: tar.TypeDir}},
		"a nested escape": {{name: "a/../../b", typ: tar.TypeReg, body: "x"}},
	}
	for name, entries := range cases {
		t.Run(name, func(t *testing.T) {
			r := &registry{blobs: map[string][]byte{}, serve: map[string][]byte{}}
			d := r.image(t, layer(t, entries...))
			parent := t.TempDir()
			err := Client{Runner: r.runner()}.Unpack(t.Context(), ref(d), filepath.Join(parent, "out"))
			if err == nil {
				t.Fatal("unpacked")
			}
			if _, err := os.Stat(filepath.Join(parent, "escape.md")); err == nil {
				t.Error("a file escaped the root")
			}
		})
	}
}

func TestUnpackRefusesOtherContent(t *testing.T) {
	r := &registry{blobs: map[string][]byte{}, serve: map[string][]byte{}}
	l := layer(t, entry{name: "SKILL.md", typ: tar.TypeReg, body: "# A skill\n"})
	d := r.image(t, l)
	// The registry answers the layer's digest with other bytes.
	r.serve[Digest(l)] = layer(t, entry{name: "SKILL.md", typ: tar.TypeReg, body: "# Changed\n"})
	err := Client{Runner: r.runner()}.Unpack(t.Context(), ref(d), filepath.Join(t.TempDir(), "out"))
	if !IsChanged(err) {
		t.Fatalf("a changed layer: %v", err)
	}
	// And the index's digest with another index.
	r.serve = map[string][]byte{d: []byte(`{"schemaVersion":2,"manifests":[]}`)}
	if err := (Client{Runner: r.runner()}).Unpack(t.Context(), ref(d), filepath.Join(t.TempDir(), "out")); !IsChanged(err) {
		t.Fatalf("a changed index: %v", err)
	}
}

func TestParseReference(t *testing.T) {
	good := "floci:4566/000000000000/us-east-1/library/skill/platform-conventions@sha256:" + strings.Repeat("a", 64)
	r, err := ParseReference(good)
	if err != nil || r.Host != "floci:4566" || r.Repository != "000000000000/us-east-1/library/skill/platform-conventions" || r.String() != good {
		t.Fatalf("%+v, %v", r, err)
	}
	for _, bad := range []string{
		"floci:4566/library/skill/x:v0.1.0",
		"floci:4566/library/skill/x@sha256:" + strings.Repeat("A", 64),
		"library/skill/x@sha256:" + strings.Repeat("a", 64)[:63],
	} {
		if _, err := ParseReference(bad); err == nil {
			t.Errorf("%q parsed", bad)
		}
	}
}

func TestPlainHTTP(t *testing.T) {
	f := &execx.Fake{Handle: func(execx.Cmd, []byte) (int, string, string, error) {
		return 0, "sha256:" + strings.Repeat("b", 64) + "\n", "", nil
	}}
	c := Client{Runner: f, PlainHTTP: func(h string) bool { return h == "floci:4566" }}
	if _, err := c.Resolve(t.Context(), "floci:4566", "library/skill/x", "v0.1.0"); err != nil {
		t.Fatal(err)
	}
	got := strings.Join(f.Calls()[0].Cmd.Args, " ")
	if got != "resolve --plain-http floci:4566/library/skill/x:v0.1.0" {
		t.Errorf("oras %s", got)
	}
}
