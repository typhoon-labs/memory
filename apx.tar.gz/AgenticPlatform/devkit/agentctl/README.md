# agentctl

The platform's developer CLI ([Distribution](../../architecture/design/distribution.md#agentctl-the-thin-organization-cli)), in Go. It wraps existing tools and services, and never holds more rights than the person running it. Build phase B5 brings its first commands ([the local build plan](../../architecture/plan/local-build.md#b5-in-detail)).

These links, and the others in this repository's documents, are relative to the workspace, which mirrors the GitLab group.

```text
agentctl/
├── cmd/agentctl/   # the command: one file per command
├── internal/       # what the commands use; spec/ holds the vendored copy of agent-sdk's spec
├── scripts/        # build.sh: the reproducible build
├── .gitlab-ci.yml
├── AGENTS.md
└── README.md
```

## Commands

| Command | Does |
| --- | --- |
| `harness setup`, `doctor` | Write Claude Code's managed settings for the platform's gateway, link the repository's skills and write its `.mcp.json`; check all of it, with the fix for each failure |
| `deploy request` | Opens the merge request in `environments` that deploys one release of a workload, with its pinned digests, its values from its project at the tag, and an access-file stub on a first deploy, as the person running it |
| `install`, `update`, `remove` | Install library artifacts from the signed index into a repository, by digest, after verifying their signature and provenance with the release key; move them to the release the index holds; remove them. `.agents/lock.yaml` records each |
| `catalog build`, `catalog publish`, `catalog drift` | Build the environment's signed catalog index from the registered projects, in `environments`' scheduled pipeline; apply it to Agentregistry as the `catalog-publisher` client; report where the registry differs from it |
| `conform` | Runs the conformance runner's image, pinned in `environments`' `versions.yaml`, against the deployment a configuration names |
| `local up`, `local down` | Builds the local platform with `environments`' bootstrap at a pinned commit, or deletes the cluster and stops floci |
| `login` | Signs in to the realm as the public client `agentctl` ([The realm](../../architecture/design/identity.md#the-realm)), by the device flow or by the authorization code on a loopback redirect, each with PKCE, asking for every route scope given with `-scope` (default `models`), and keeps the refresh token |
| `new` | Starts `workload-templates`' generation job as the person, waits for it and prints the new project's URL |
| `search`, `show` | Search the environment's signed catalog index, or print one entry of it, after verifying its signature with the environment's record key |
| `step run` | Runs one bounded workflow step with the SDK's step command |
| `token` | Prints an access token for one route scope (`-scope`, default `models`), for Claude Code's `apiKeyHelper` and the bounded step's token command; with `-ci`, a CI job's, by its GitLab ID token |
| `validate` | Checks `workload.yaml`, `artifact.yaml` or a step's definition against `agent-sdk`'s schemas |
| `version` | Prints the version, the commit, the Go toolchain and the vendored spec's commit |

Exit codes: 0 done, 1 the command failed, 2 `agentctl` could not run it (usage, setup). A command that runs another program passes its exit status through, as its help says.

## Signing in

`agentctl login` finds the realm's endpoints by OpenID Connect discovery from the issuer, `https://keycloak.agentic.internal/realms/agentic` locally (`-issuer` or `AGENTCTL_ISSUER`), and requires the document to name that issuer exactly, every endpoint to be HTTPS, and S256 among its PKCE methods. It trusts the system's roots, plus `-ca-file` or `AGENTCTL_CA_FILE`, and for an issuer under `agentic.internal` the local CA the bootstrap writes.

| Flow | When | How |
| --- | --- | --- |
| Device (RFC 8628) | `-flow device`, or by default over SSH or without a desktop | Prints the verification page and code, opens the page where a browser can open, and polls; Keycloak asks the person to grant access once signed in |
| Loopback (RFC 8252) | `-flow loopback`, or by default where a browser can open on this machine | Listens on `127.0.0.1` on a random port and opens the authorization URL in `$BROWSER`, `open` or `xdg-open`; the realm admits `http://127.0.0.1/*` on any port, never `localhost`. An answer naming another issuer (RFC 9207) is refused |

A refresh may only narrow the scope ([T20](../../architecture/research/2026-11-16-t20-keycloak-refresh-narrowing.md)), and the realm's metadata advertises no route scope, so `login` asks at once for every route scope the person will want tokens for: `agentctl login -scope models -scope mcp/jira-mcp`. `token` then refreshes with exactly one of them, and refuses one the sign-in was not granted.

**Where the refresh token is kept** ([D29](../../architecture/plan/open-items.md#close-by-decision)):

| Where | When | How |
| --- | --- | --- |
| The macOS keychain | macOS | `/usr/bin/security`, the token sent on its standard input, never on a command line |
| The Secret Service keyring | Linux with a D-Bus session and `secret-tool` | `secret-tool`, the token on its standard input |
| A file | Anywhere else: the build sandbox, CI | `credentials.json` in agentctl's configuration directory (`AGENTCTL_CONFIG_DIR`, else `agentctl` under `~/.config` or `~/Library/Application Support`), mode 0600 in a directory mode 0700, written to a new file and renamed over the old one. A file others can read or write is refused |

`AGENTCTL_TOKEN_STORE=file` or `keychain` forces one. Beside a keychain, the record without its token goes to `sign-in.json`.

**Rotation.** Each refresh token is usable once, and a reuse ends the session ([The realm](../../architecture/design/identity.md#the-realm)). `token` therefore takes an exclusive lock (`flock` on `agentctl.lock` in the configuration directory) before reading the refresh token and keeps it until the rotated one is saved; it saves before printing anything. Concurrent calls, as a harness may make, wait their turn.

`token` prints the access token alone, one line, and only when its one audience is the route's URL on the gateway (`-gateway` at login, or `AGENTCTL_GATEWAY`; `https://gateway.agentic.internal` locally). Nothing else agentctl prints holds a token. As Claude Code's credential helper, from B6:

```json
{"apiKeyHelper": "agentctl token --scope models"}
```

## Validating

`agentctl validate [FILE...]` checks each file against its schema in `agent-sdk`'s `spec/` ([Development](../../architecture/design/development.md#the-shared-sdk-agent-sdk)): `workload.yaml` against `schemas/workload.schema.json`, `artifact.yaml` against `schemas/artifact.schema.json`, and `step.yaml` or `<name>.step.yaml`, a bounded step's definition, against `step/step.schema.json`. Without arguments it checks the `workload.yaml` and `artifact.yaml` in the working directory; `-kind` names the schema for a file named otherwise. It prints each problem with its place in the file as a JSON pointer, and exits 1 when a file is invalid.

The files are YAML, checked as the JSON they parse to. One document per file, keys that are strings, and no unquoted dates: YAML reads `2027-03-31` as a timestamp, not the string the schemas' `format: date` asks for, so a date is written quoted, `"2027-03-31"`.

**The spec is a vendored copy,** `internal/spec/spec/`, embedded in the binary, with the `agent-sdk` commit and tag it came from in `internal/spec/SOURCE`; `agentctl version` names it. From B6 it is `spec/v0.3.0` (`122741f9`). `internal/spec/vendor.sh [AGENT_SDK_DIR] [REV]` refreshes it, as `delegation-sts`' `interop/contract/vendor.sh` does. `-spec DIR` checks against a working copy of `spec/` instead. The validator is `github.com/santhosh-tekuri/jsonschema/v6` v6.0.3, with format assertions on, as in `delegation-sts`' contract tests, and the tests run every example and invalid file of the vendored spec, as JSON and again written as YAML.

## The catalog index

`search`, `show`, `install`, `update` and `remove` read one environment's catalog index, `catalog.json` ([Distribution](../../architecture/design/distribution.md#the-distribution-design)), and trust nothing in it until its signature verifies: `cosign verify-blob` with the environment's record key, `alias/platform/record-signing` ([D37](../../architecture/plan/open-items.md#close-by-decision)), and the bundle beside the index, `catalog.json.sigstore.json`. Then the index must match `agent-sdk`'s `spec/schemas/catalog.schema.json`, be the environment's, name each entry once, and give each artifact the version its entry has. An index that fails any of these is refused, and nothing is printed from it.

| Flag | Default | Does |
| --- | --- | --- |
| `-environment` | `local` (`AGENTCTL_ENVIRONMENT`) | Which environment's index, registry and keys |
| `-index` | The environment's index bucket, `s3://agentic-catalog-index-local/indexes/` locally (`AGENTCTL_CATALOG_INDEX`) | A file; an `https://` URL of `catalog.json`, with the person's GitLab token sent to the GitLab instance alone; or an `s3://` location, read with the `aws` CLI and the person's own credentials. Under a prefix ending in `/`, the newest build, `indexes/<UTC time>/catalog.json`, whose signature verifies and whose signed `timestamp` is its prefix's time is read, and each newer one passed over is named |

Locally the `aws` CLI gets floci's endpoint, `http://floci:4566`, when `AWS_ENDPOINT_URL` is unset. How a developer reads dev's index is not settled yet: no role reads the bucket, and a read-only route or `environments`' package registry are the options.

**The keys** are the public halves of the environment's release and record keys, as KMS's `GetPublicKey` gave them when the environment was built, carried in `agentctl` (`internal/defaults/keys/<environment>/`), never fetched from where an index or an artifact comes from. `AGENTCTL_RELEASE_KEY` and `AGENTCTL_RECORD_KEY` name another, a PEM file or a KMS URI, as `cosign --key` takes it. Locally the keys change only when floci's KMS is built again; then `agentctl` is built again with the new halves.

`agentctl search [-kind K] [-owner TEAM] [-tier T] [-json] [TERM...]` lists the entries whose name, kind, owner or description holds every term, with their version, owner, support status and where they are: an artifact's tier, an agent's or MCP server's route on the developer deployment. It exits 1 when nothing matches. `agentctl show [-json] NAME` prints one entry: its source project, tag and commit, its digest, its route as a URL, what it requires, and `agentctl install NAME` for an artifact; it warns when the entry is deprecated.

## Claude Code

`agentctl harness setup [-ca-file FILE] [-otel-endpoint URL -team TEAM] [-mcp NAME]... [-dir REPO]` sets Claude Code up for the platform ([Harnesses](../../architecture/design/harnesses.md#making-it-work-through-the-gateway)). Managed settings are machine-wide, so it runs as root (`sudo`), or with `-managed-dir`, or `-skip-managed` for the repository's part alone. It writes:

- **Managed settings,** `managed-settings.d/50-agentic-platform.json` in Claude Code's system directory (`/etc/claude-code` on Linux, `/Library/Application Support/ClaudeCode` on macOS; `AGENTCTL_CLAUDE_MANAGED_DIR`), a drop-in that Claude Code merges after the machine's own `managed-settings.json`, which is never written:

  | Key | Value |
  | --- | --- |
  | `allowedProviders` | `["customEndpoint"]`: the gateway alone; a session on any other provider is refused |
  | `env.ANTHROPIC_BASE_URL` | The developer gateway (`-gateway`, `AGENTCTL_GATEWAY`), the pin `customEndpoint` needs |
  | `apiKeyHelper` | `<agentctl> token --scope models`, whose output Claude Code sends as `Authorization: Bearer` and `x-api-key`, and runs again on expiry and on a 401 |
  | `env.CLAUDE_CODE_API_KEY_HELPER_TTL_MS` | `240000`, under the 300 seconds a route token lives |
  | `env.ANTHROPIC_MODEL`, `env.ANTHROPIC_DEFAULT_OPUS_MODEL`, `_SONNET_`, `_HAIKU_` | The gateway's aliases, `reasoning-default` and `fast-default` |
  | `env.CLAUDE_CODE_AUTO_COMPACT_WINDOW` | The model route's window, the fake model's 200000 locally |
  | `env.CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC`, `skipWebFetchPreflight` | `1` and `true`: nothing goes to Anthropic around the gateway |
  | `env.NODE_EXTRA_CA_CERTS` | The CA file (`-ca-file`, `AGENTCTL_CA_FILE`, the local CA for `*.agentic.internal`) |
  | `env.CLAUDE_CODE_ENABLE_TELEMETRY`, `env.OTEL_*` | Only with `-otel-endpoint`: OTLP to the collector, `team=<team>`, and never `OTEL_LOG_USER_PROMPTS`, so prompts are redacted. The platform has no collector endpoint for workstations yet |

- **Skills' links:** each skill in `.agents/skills/<name>`, the repository's one copy, gets Claude Code's `.claude/skills/<name>`, a relative symbolic link; Codex reads `.agents/skills` itself. Anything else at that path is left and reported.
- **`.mcp.json`,** from one source: the MCP servers `workload.yaml`'s `requires.tools` names, and `-mcp` for more, each looked up in the signed catalog index and written as its route on the developer deployment, `{"type": "http", "url": "<gateway>/mcp/<name>", "oauth": {...}}`, signed in through the realm as its pre-registered `claude-code` client, `callbackPort` 33418, the route's scope alone and the realm's own metadata (`-issuer`), as [T6](../../architecture/research/2026-11-17-t6-mcp-sign-in.md) proved it: without the client, Claude Code tries dynamic registration, which the realm refuses. Other servers in `.mcp.json` stay as they are.

It writes no `CLAUDE.md`: `AGENTS.md` is the instructions file, which Claude Code reads natively, and it warns when a `CLAUDE.md`, `CLAUDE.local.md` or `.claude/CLAUDE.md` would stop that.

`agentctl doctor [-offline] [-dir REPO]` checks, and prints each result with its fix: Claude Code's version (at least 2.1.285, the pin 2.1.311); the managed settings as Claude Code merges them, every key above, `allowedProviders` exactly the gateway since managed lists combine; a provider variable (`CLAUDE_CODE_USE_BEDROCK` and the others), `ANTHROPIC_AUTH_TOKEN`, `ANTHROPIC_API_KEY`, a base URL, a helper or `OTEL_LOG_USER_PROMPTS` set in the environment or in the person's, project's or local settings; the helper, run as Claude Code runs it, its token never printed; the model route, asked to count a message's tokens with that token (`-offline` skips both); telemetry; and the repository's instructions, skills' links, lock file and `.mcp.json`. It exits 1 when a check fails; `warn` and `pending` do not.

**Never on this machine's own configuration.** The build sandbox's `~/.claude` is the build's own, and managed settings are machine-wide, so `harness setup` runs for real only in a throwaway container. Its integration test does that: the pinned Node.js image on the host network with no proxy variables, Claude Code installed with npm, `agentctl` built and mounted; `harness setup` as root inside it, then `claude -p` against a capture server of the test's own on loopback, which answers as the Messages API does. It checks that Claude Code sends the helper's output in both headers, an alias as the model and `x-claude-code-session-id`, that the managed base URL wins over the person's settings and environment, that `CLAUDE_CODE_USE_BEDROCK=1` is refused before anything is sent, and that `doctor` passes and then names the fix for a broken `allowedProviders`: `AGENTCTL_INTEGRATION_NODE_IMAGE=docker.io/library/node:24.22.3-trixie-slim@sha256:af02d57b57719b9657a45199a79264a9437940cd55b3c7b3fc99615654f124a0 go test -run TestHarnessRealClaudeCode ./cmd/agentctl` (`AGENTCTL_INTEGRATION_CLAUDE_CODE` for another version). The helper there is a stub, since nobody can sign in inside a test; signing in as a person, and the platform's gateway and fake model, are the B6 check in the plan.

## The catalog

`agentctl catalog build` builds one environment's index in `environments`' scheduled pipeline ([D41](../../architecture/plan/open-items.md#close-by-decision)), with the job's own token (`CI_JOB_TOKEN`, sent as `JOB-TOKEN`; a person's token outside CI). It reads:

- the registrations, `registrations/<environment>.yaml` of `aws-foundation` at `main` (`-foundation`, `-registrations FILE` for a checkout): the projects of `ci-workload-release` and `ci-library-release`, by ID. A project not registered is never read;
- `access/teams.yaml` (`-teams`), the owners allowed;
- from each workload project, its `vX.Y.Z` tags and `workload.yaml` at them; from each library, each artifact's `<kind>/<name>/vX.Y.Z` tags, `library.yaml` and `<kind>s/<name>/artifact.yaml` at them, through the raw-file and tags endpoints a job token may call. So each project's job token allowlist must admit `environments`, and **a registered project the job cannot read stops the build**: it exits 1 and publishes nothing, since leaving the project out would withdraw all its entries.

Each release must match the spec's schemas, be owned by a team in `teams.yaml`, and, from a team's library, be named with its prefix; a workload's tag resolves with ORAS to its digest in `workloads/<owner>/<name>`, an artifact's `v<X.Y.Z>` in `library/<kind>/<name>`, and the digest must carry the sign statement of the environment's release key, as `install` checks it (`-no-verify` skips that). An artifact's metadata is its own `artifact.yaml` as released, read from the artifact, whose provenance must name the tag's commit. The index takes, for each name, the newest release that passes: when the newest fails a check, a release not signed yet for instance, the one before it stays, and the newer one's failure is reported, so a release in flight never makes a live entry disappear. Only a withdrawal removes one: a workload whose newest passing release is `retired`, which no older release brings back. A workflow has no digest; agents and MCP servers get their routes on the developer deployment. One release of each name: a name two projects give is refused from both.

It writes `catalog.json`, checked against the schema, and `index.html`, a page generated from it, into `-out`. With `-sign-key` (the record key, `awskms:///alias/platform/record-signing`) it signs the index with `cosign sign-blob` and a signing config that names no service, and verifies the bundle with the record key consumers verify with, so an index signed with any other key is never published; with `-bucket` it puts the page, the bundle and the index, in that order, under `indexes/<UTC time>/` of the index bucket, a new prefix every build since Object Lock keeps every version. The build's provenance comes from `CI_PROJECT_URL`, `CI_COMMIT_SHA` and `CI_PIPELINE_ID`. It exits 0 when every source passed, 3 when it built and published the index but left some out, each named on standard error and on the page, and 1 when it published nothing.

`agentctl catalog publish` reads the newest index in the bucket whose signature verifies with the record key, and applies its agents and MCP servers to Agentregistry 0.4.0 through its write route (`-registry`, `AGENTCTL_REGISTRY_URL`; `https://workloads-gateway.agentic.internal/registry` locally) with `POST /v0/apply`, one `ar.dev/v1alpha1` document each ([D40](../../architecture/plan/open-items.md#close-by-decision)). Each is listed by its route: an `MCPServer` with `spec.remote`, an `Agent` with its description, both with the labels `agentic-platform/owner`, `agentic-platform/support` and `agentic-platform/kind` and the annotations `agentic-platform/digest`, `reference`, `route`, `source` and `index` (R3). Skills and prompts stay in the index alone, since 0.4.0 takes skills from public Git only. The write answers 200 whatever happens, so `publish` reads each document's result and exits 1 when any is not `created`, `configured` or `unchanged`. Agentregistry keeps one row per name and tag, so `publish` then deletes, with `DELETE /v0/apply`, every agent and MCP server the registry lists that the index does not hold, an older version or a dropped name: only the catalog job writes there (R2), and the registry converges on the index, rebuilt from it at will (R6). As a second guard it refuses an index that would delete more than half the rows the registry lists, unless `-force`. It signs in as the realm's `catalog-publisher` client by the client-credentials grant, authenticated with the CronJob's projected service-account token (`-assertion-file`, `AGENTCTL_ASSERTION_FILE`) for the write route's scope (`-scope`), and uses the token only when its one audience is the route. `-dry-run` prints the documents and signs in to nothing.

`agentctl catalog drift` reads the registry's agents and MCP servers the same way and reports each that is missing, extra, or differs from the index in its owner, support status, digest or route (R2), exiting 1 on any.

## A CI job's token

`agentctl token --ci [--scope SCOPE]` signs a CI job in as its workflow's own client (`-client-id`, else `AGENTCTL_CI_CLIENT_ID`, else `AGENTCTL_CLIENT_ID` as the `step` component exports it) by the client-credentials grant, authenticated with the job's GitLab ID token (the variable `-id-token-var` names, default `AGENTCTL_ID_TOKEN`, which the job's `id_tokens` names; else the file `-id-token-file` or `AGENTCTL_ID_TOKEN_FILE` names, as the component writes it), which the realm's `gitlab` provider checks against GitLab's keys and the token's `sub`, the project and protected ref ([D27](../../architecture/plan/open-items.md#close-by-decision)). It asks the realm for the route scope under the prefix `AGENTCTL_REALM_SCOPE_PREFIX` names, `workloads-models` for `models` with the prefix `workloads-`: scope names are realm-wide, and the realm's `models` gives the developer gateway's audience, so a route on the hosted-workloads deployment has a realm scope of its own. Unset, the route scope goes as it is; a person's sign-in never uses the prefix. The realm's `invalid_scope` is named with the scope asked for. It trusts `AGENTCTL_CA_FILE`, the local CA, or else `AGENTIC_CA_FILE`, and prints the access token only when its one audience is the route's on `AGENTCTL_GATEWAY`, else `AGENTIC_GATEWAY_URL`, the hosted-workloads deployment in a step job; it keeps nothing. In CI mode `agentctl step run` hands the step `agentctl token --ci` as its token command.

## Deploy requests

`agentctl deploy request --environment ENV --project PATH --tag TAG --workload NAME (--image REF | --definition REF)` opens the merge request in `environments` that deploys one release ([D39](../../architecture/plan/open-items.md#close-by-decision)). `ci-components`' `deploy-request` component prints the command, with the digest its release published, for the developer to run; it holds no token. `agentctl` runs it with the person's own GitLab token, found as `new` finds it, and never deploys anything itself: the merge request's review and `environments`' pipeline do.

1. It reads, at the tag, the project's `workload.yaml`, which must match the spec's schema and name `--workload`, and its `deploy/<chart>.yaml` for each chart and `deploy/access.yaml`. A container workload takes `app-base` and `agent-integration` and `--image`, its image index; a kagent agent takes `agent-integration` alone and `--definition`, its packaged definition; a workflow runs in its pipeline and is refused, as is a retired workload.
2. It reads, at `environments`' `main`, `clusters/<env>/platform/values.yaml`'s `registry.host`, under which the reference must be the workload's repository, `workloads/<owner>/<name>` (D4), by digest; `versions.yaml`'s chart pins; and what the environment already has of the workload.
3. It commits, on a new branch `feat/deploy-<name>-<tag>` from `main`, `clusters/<env>/workloads/<name>/release.yaml` (team, namespace, releases, each chart by the version and digest `versions.yaml` pins, the tag and digest), each chart's values with a line naming where they came from, and, on a first deploy, the access file `clusters/<env>/domains/<team>/<name>.yaml` as a stub from `deploy/access.yaml` for the platform's review. An existing access file is kept; a file already as it would be is left out, and when nothing would change it says so and opens nothing.
4. It opens the merge request, `feat(workloads): deploy <name> <tag>`, its description naming the source, the digests, the files and what to review, and prints its URL.

`--dry-run` reads everything and prints the branch, commit, merge request and files, writing nothing. It exits 0 when the merge request is opened or nothing would change, 1 when it refuses or GitLab fails, and 2 on a usage error or no GitLab token. The environment's setup must have made the workload's namespace; the pipeline makes none.

## Installing library artifacts

`agentctl install [-dir REPO] NAME[@VERSION|@sha256:DIGEST]...` installs skills, prompts, workflows and plugins from the global and team libraries into a repository ([Installing into local harnesses](../../architecture/design/distribution.md#installing-into-local-harnesses)). For each, in this order, and writing nothing until the checks before the fetch have passed:

1. The index is read and verified as above. The name must be an artifact's in it; a version or digest given must be the one the index holds, since it holds one release of each name: anything else is refused as not in the index.
2. What is already in the repository is left alone unless `.agents/lock.yaml` says `agentctl` put it there: a canonical copy the lock file does not name, or a `.claude/skills/<name>` that is not `agentctl`'s link, stops the install.
3. The signature: cosign's own sign statement, `https://sigstore.dev/cosign/sign/v1`, on the digest the index records, verified with the environment's release key as an attestation of that type whose subject is the digest. Never `cosign verify` alone: with cosign v3's bundles it takes any bundle the key made on the digest for the signature, an attestation included, so a release-key provenance or SBOM, or a conformance attestation with the conformance key, would pass. Then `cosign verify-attestation --type slsaprovenance1` with the same key, whose SLSA v1 provenance must name the commit the index gives as the release's source.
4. The artifact is fetched with ORAS by that digest alone, and every manifest and layer is checked against its digest by `agentctl` itself, so a registry that answers with other content is refused. A library artifact is a scratch image, an index of per-platform manifests with one tar layer ([D28](../../architecture/plan/open-items.md#close-by-decision)): the linux/amd64 manifest's layer is unpacked, regular files and directories alone, nothing outside its root.
5. The artifact's own `artifact.yaml`, at its root, must match the spec's schema and give the entry's kind, name and version; a skill must have its `SKILL.md`.
6. The canonical copy goes to `.agents/<kind>s/<name>`, replacing the earlier one in one rename; a skill gets Claude Code's link, `.claude/skills/<name>`, a relative symbolic link to it. Codex reads `.agents/skills` itself, and neither harness has a place for a prompt, so a skill's is the only link.
7. `.agents/lock.yaml` records the kind, name, version, reference by digest, canonical path and links, checked against `spec/schemas/lock.schema.json` before it is written, to a new file renamed over the old.

Commit `.agents/` and `.claude/skills/` with the repository. `agentctl update [NAME...]` installs the release the index now holds for each installed artifact whose digest differs, with the same checks; one that fails them keeps the installed release. `agentctl remove NAME...` removes the canonical copy, the links that are still `agentctl`'s, and the lock file's entry, and needs no index. A deprecated artifact installs with a warning.

ORAS and cosign are found on `PATH` (`AGENTCTL_ORAS`, `AGENTCTL_COSIGN`), and registries listed in `AGENTCTL_PLAIN_HTTP_REGISTRIES` (floci's `floci:4566` locally) are reached over plain HTTP. `AGENTCTL_REGISTRY` replaces the environment's `registry.host`, under which every reference must be.

Its integration test runs the real `oras` and `cosign` against a throwaway `registry:2` in Docker on a loopback port, with cosign keys made for the test, never floci or a platform key: `AGENTCTL_INTEGRATION_REGISTRY_IMAGE=registry:2.8.3@sha256:a3d8aaa63ed8681a604f1dea0aa03f100d5895b6a58ace528858a7b332415373 go test -run TestInstallRealTools ./cmd/agentctl`. It installs a signed skill, refuses one signed with another key, a digest not in the index and an index signed with the release key, and removes the skill. Without the variable it skips.

## Generating a project

`agentctl new -team T [-shared | -incubator] TEMPLATE NAME` starts the generation job of `devkit/workload-templates` ([Development](../../architecture/design/development.md#project-generation-and-updates)) with the person's own GitLab token: `GITLAB_TOKEN`, `GITLAB_ACCESS_TOKEN` or `OAUTH_TOKEN`, else glab's `config.yml`, sent as a Bearer token. The templates are `adk-agent`, `kagent-agent`, `mcp-server-python` and `workflow-pipeline`.

- It checks the name first ([Naming](../../architecture/design/repositories.md#naming)): lowercase kebab-case, at most 63 characters, the template's suffix (`-agent`, `-mcp`, `-workflow`), never `adk` or `kagent` as a word, and not taken.
- It starts a pipeline on the templates project's `main` with **pipeline inputs**, `template`, `name`, `team` and `placement` (`team`, `shared` or `incubator`), not variables: the templates project lets no one set pipeline variables. The requester is the pipeline's user.
- It waits for the pipeline, then reads the new project at `<root>/workloads/<team>/<name>`, `<root>/workloads/shared/<name>` or `<root>/incubator/<name>`, where `<root>` is the group above the templates project's `devkit`, and prints its URL. A failed job is named with its link.

Starting a pipeline on the protected `main` needs merge rights there, so in B5 a Maintainer runs it; how others do is [T17](../../architecture/plan/open-items.md#close-by-spike-local-or-dev). The job's own credential is [D8](../../architecture/plan/open-items.md#close-by-decision)'s.

## Conformance

`agentctl conform -config FILE [-junit FILE] [-json FILE] [-- -run REGEXP ...]` runs `platform/conformance-runner` at the digest `environments`' `versions.yaml` pins (from `-environments DIR`, or the checkout `local up` keeps), with `docker run`, against the deployment the configuration names ([Conformance](../../architecture/design/conformance.md)). The configuration is the runner's own, as its README in `ci-components` describes for a workstation; its `ca_file` and `sign_in.personas_file` are this machine's paths, which `agentctl` mounts into the container and rewrites.

- The image is pulled from `127.0.0.1:4566/000000000000/us-east-1` (`-registry`, `AGENTCTL_RUNNER_REGISTRY`): floci's registry by its loopback address, which the local Docker daemon reaches without its proxy, where `registry.host`'s `floci:4566` fails.
- The container runs on the host network as the person's user, with every proxy variable set empty, and with the platform's hostnames mapped to `127.0.0.1` where this machine maps them so.
- The runner's exit status is `agentctl`'s: 0 passed, 1 a case failed, 2 it could not run. When `docker run` cannot start the container, with its own statuses 125 to 127 (a mount it cannot make, an image it cannot pull, an entrypoint it cannot run), `agentctl` exits 2 as well; any other status is the runner's, passed through. Cases that need a position inside the cluster skip.
- Its integration tests run the real runner image with `docker`, through `conform` itself: `AGENTCTL_INTEGRATION_ENVIRONMENTS=<environments checkout> go test -run TestConformRealRunner ./cmd/agentctl`, pulling from `AGENTCTL_RUNNER_REGISTRY` or the default above. They check that the runner reads the configuration, CA and personas file where `agentctl` mounts them, that its reports come back, and the exit statuses: 0 and, strict, 1 for a case that skips; 2 for an image that cannot be pulled and for flags the runner refuses. Without the variable they skip; the pipeline does not set it.

## The local platform

`agentctl local up` runs `clusters/local/00-local/bootstrap.sh` from a checkout of `environments` at the commit `agentctl` pins (`internal/local`, `-commit` for another): its own checkout under its cache directory, cloned and moved to the pin as needed, or one given with `-environments`, which must be at the pin with no changes. The bootstrap gets `agentctl`'s environment unchanged, proxies included: it unsets them itself where kind needs it, and its GitLab and download steps may need them. It is idempotent, so `up` again changes nothing. Its OpenTofu step needs `aws-foundation` beside the checkout or in `AWS_FOUNDATION_DIR`.

`agentctl local down -yes` deletes the kind cluster `agentic-local` and stops floci with `docker compose -f clusters/local/00-local/floci/compose.yaml stop`, never `docker kill`, since floci's storage flushes on a clean shutdown. Without `-yes` it only says what it would do.

## A bounded step

`agentctl step run -input FILE [-output FILE] [-workload FILE] (-definition FILE | DEFINITION)` runs one bounded step ([Workflows](../../architecture/design/workflows.md#a-bounded-model-step)) with the SDK's step command, as `agent-sdk`'s `spec/step/command.json` describes. `agentctl` finds the command (`-step-command`, `AGENTCTL_STEP_COMMAND`, then `agentic-step` on `PATH`) and runs `agentic-step run --definition … --input … --output … [--workload …]` with absolute paths; `-input -` reads standard input, and a `workload.yaml` in the working directory is passed when `-workload` is not given. It gives the command's environment:

| Variable | Holds |
| --- | --- |
| `AGENTIC_GATEWAY_URL` | `-gateway`, else `AGENTIC_GATEWAY_URL` as it came, else `AGENTCTL_GATEWAY`, else the developer gateway |
| `AGENTIC_TOKEN_COMMAND` | `["<agentctl>", "token"]`, a person's sign-in, to which the step adds `--scope` and a route scope for each token it needs; in CI mode `["<agentctl>", "token", "--ci"]`, the job's own, whatever the environment held |
| `AGENTIC_CA_FILE` | `-ca-file`, else `AGENTIC_CA_FILE` as it came, else `AGENTCTL_CA_FILE` or the local CA, when there is one |
| `AGENTIC_TASK_ID` | `-task-id`, else `AGENTIC_TASK_ID` as it came, else a new UUID |
| `AGENTIC_WORKFLOW_NAME`, `AGENTIC_WORKFLOW_VERSION` | `-workflow-name` and `-workflow-version`, else as they came; both or neither, checked against `spec/headers/`' patterns |

**In a pipeline.** CI mode is on with `-ci`, or whenever `AGENTCTL_ID_TOKEN_FILE` is set, as `ci-components`' `step` component sets it. The component's command line, `step run --definition F --input F --output F [--workload F] [--step-command C]`, and its exports (`AGENTIC_GATEWAY_URL` of the hosted-workloads deployment, a task ID per pipeline, the workflow's name and version, the CA, `AGENTCTL_CLIENT_ID` and the ID token in `AGENTCTL_ID_TOKEN_FILE`) reach the step as the component set them; a test runs that exact command line and environment against a stub step command, and its token command against a fake realm.

The command's exit status is `agentctl`'s: 0 done, 1 failed with its failure path `stop`, 3 stopped by its limits, 4 failed with its failure path `human`, 5 invalid. On 3 `agentctl` checks the output against `spec/limits/error.schema.json` and prints the limit, its cap and what was used; on 1, 4 and 5 against `spec/step/failure.schema.json`. `agentctl` exits 2 when it cannot start the command.

## Building

`scripts/build.sh OUTDIR` builds the four binaries, `agentctl-<os>-<arch>` for Linux and macOS on amd64 and arm64, and their `SHA256SUMS`. The same commit and Go toolchain give the same bytes wherever they are built: the build trims paths, stamps no VCS state and no build ID, and links statically. The version is the release tag, or `sha-<12>` of the commit.

## The pipeline

Every job runs on the `build` runner (tag `local-build`):

| Job | Runs on | Does |
| --- | --- | --- |
| `go` | Merge requests, `main` | `gofmt`, `go vet`, `go test -race` |
| `build` | Merge requests, `main`, release tags | `scripts/build.sh`, twice, from two directories, and requires the same bytes |
| `sign` | Protected `vX.Y.Z` tags | `cosign sign-blob` of each binary and `SHA256SUMS` with the release key `alias/platform/release-signing` through KMS, as the role `ci-agentctl`, with a signing config that names no service, so nothing reaches a public log; each signature is verified with the key's public half |
| `publish` | Protected `vX.Y.Z` tags | Uploads the binaries, their bundles (`<file>.sigstore.json`), `SHA256SUMS` and `release-signing.pub` to the project's generic package registry as `agentic-agentctl` at the tag's version, once |

To check a downloaded binary: `cosign verify-blob --key release-signing.pub --insecure-ignore-tlog --bundle agentctl-linux-amd64.sigstore.json agentctl-linux-amd64`. When `ci-components`' `sign` component offers a blob mode, the `sign` job becomes that component (the comment above the job says how).

The Markdown check runs before committing, not in the pipeline ([AGENTS.md](AGENTS.md)).
