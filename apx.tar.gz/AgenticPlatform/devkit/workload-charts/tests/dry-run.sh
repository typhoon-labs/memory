#!/usr/bin/env bash
# Server-side dry runs of the renders tests/render.sh wrote, so that the
# cluster's admission rules judge them as they would the workload's
# releases. Run from a shell with the cluster's credentials, never in CI
# (the build runner cannot reach the cluster). Nothing is applied.
#
# Usage: tests/dry-run.sh <render dir> [<workload>...]
set -uo pipefail

dir="${1:?usage: tests/dry-run.sh <render dir> [<workload>...]}"
shift
names=("$@")
[ ${#names[@]} -gt 0 ] || names=($(cd "$dir" && ls))
status=0
for name in "${names[@]}"; do
  for f in "$dir/$name/app-base.yaml" "$dir/$name/agent-integration.yaml"; do
    [ -f "$f" ] || continue
    echo "-- $name $(basename "$f" .yaml)"
    kubectl apply --dry-run=server -f "$f" 2>&1 || status=1
  done
done
exit "$status"
