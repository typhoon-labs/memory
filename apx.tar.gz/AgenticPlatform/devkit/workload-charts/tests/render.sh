#!/usr/bin/env bash
# Renders both charts for every example workload under tests/values/<name>/
# with the local environment's platform values and its access file, as
# environments' workloads tree would install them: app-base as release <name>, agent-integration as
# <name>-integration, both in the workload's namespace (or the one given).
# Also renders each agent's STS policy entry, which is never installed.
#
# Usage: tests/render.sh <out dir> [<namespace>]
# Writes <out>/<name>/app-base.yaml, agent-integration.yaml and, for an
# agent that exchanges, sts-policy-entry.yaml.
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
out="${1:?usage: tests/render.sh <out dir> [<namespace>]}"
values="$root/tests/values"
platform=(-f "$values/platform-local.yaml")
integration=("${platform[@]}" -f "$values/platform-integration-local.yaml")

for dir in "$values"/*/; do
  name="$(basename "$dir")"
  ns="${2:-$name}"
  mkdir -p "$out/$name"
  if [ -f "$dir/app-base.yaml" ]; then
    # The access file too, as environments passes it to both charts.
    access=()
    [ -f "$dir/access.yaml" ] && access=(-f "$dir/access.yaml")
    helm template "$name" "$root/charts/app-base" -n "$ns" "${platform[@]}" \
      "${access[@]}" -f "$dir/app-base.yaml" > "$out/$name/app-base.yaml"
  fi
  if [ -f "$dir/agent-integration.yaml" ]; then
    args=("${integration[@]}" -f "$dir/access.yaml" -f "$dir/agent-integration.yaml")
    helm template "$name-integration" "$root/charts/agent-integration" -n "$ns" "${args[@]}" \
      > "$out/$name/agent-integration.yaml"
    if [ "$(yq '.stsPolicyEntry.targets // [] | length' "$dir/agent-integration.yaml")" != 0 ]; then
      helm template "$name-integration" "$root/charts/agent-integration" -n "$ns" "${args[@]}" \
        --set stsPolicyEntry.render=true --show-only templates/sts-policy-entry.yaml \
        > "$out/$name/sts-policy-entry.yaml"
    fi
  fi
  echo "rendered $name in $ns: $(cd "$out/$name" && ls | tr '\n' ' ')"
done
