#!/usr/bin/env bash
# Builds each chart's values.schema.json from schemas/workload-contract-v1.json
# and the chart's own part, schemas/charts/<chart>.json, so the contract is
# written once (design/charts.md, "The interface between the charts").
# With --check, fails if a committed values.schema.json differs from what
# it would build.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
status=0
for part in "$root"/schemas/charts/*.json; do
  chart="$(basename "$part" .json)"
  built="$(jq -S --tab -n \
    --slurpfile c "$root/schemas/workload-contract-v1.json" \
    --slurpfile p "$part" '
    {"$schema": $c[0]["$schema"],
     "title": ("'"$chart"' values"),
     "description": "Built by tests/schemas.sh from schemas/workload-contract-v1.json and schemas/charts/'"$chart"'.json; do not edit.",
     "type": "object",
     "required": $c[0].required,
     "properties": ($c[0].properties + $p[0].properties)}')"
  target="$root/charts/$chart/values.schema.json"
  if [ "${1:-}" = --check ]; then
    if [ "$built" != "$(cat "$target")" ]; then
      echo "FAIL $target is not what tests/schemas.sh builds; run it" >&2; status=1
    else
      echo "ok $chart values.schema.json"
    fi
  else
    printf '%s\n' "$built" > "$target"
  fi
done
exit "$status"
