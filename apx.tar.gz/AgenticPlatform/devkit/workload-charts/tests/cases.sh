#!/usr/bin/env bash
# Render cases: one value's effect on one rendered field, each with its
# expected result, for what the examples alone do not pin down.
#
# Usage: tests/cases.sh
set -euo pipefail

root="$(cd "$(dirname "$0")/.." && pwd)"
v="$root/tests/values"
failures=0

# env <workload> <variable> [helm args...]: the variable's value in the
# workload's app-base render, or <unset>.
env() {
  local w="$1" var="$2" access=()
  shift 2
  [ -f "$v/$w/access.yaml" ] && access=(-f "$v/$w/access.yaml")
  helm template "$w" "$root/charts/app-base" -n "$w" -f "$v/platform-local.yaml" "${access[@]}" -f "$v/$w/app-base.yaml" "$@" |
    yq ea -N "select(.kind == \"Deployment\") | .spec.template.spec.containers[0].env[] | select(.name == \"$var\") | .value" |
    grep . || echo "<unset>"
}

# expect <name> <want> <got>
expect() {
  if [ "$2" = "$3" ]; then
    echo "ok $1"
  else
    echo "FAIL $1: want $2, got $3" >&2
    failures=$((failures + 1))
  fi
}

# An MCP server's approval audience: by default its developer route's URL,
# which the approval route's people's tokens carry; a value overrides it;
# a workload of another protocol has none.
expect "approval audience, MCP server, default" \
  https://gateway.agentic.internal/mcp/reference-mcp \
  "$(env reference-mcp AGENTIC_APPROVAL_AUDIENCE)"
expect "approval audience, MCP server, given" \
  https://gateway.example.test/mcp/reference-mcp \
  "$(env reference-mcp AGENTIC_APPROVAL_AUDIENCE --set agentic.approvals.audience=https://gateway.example.test/mcp/reference-mcp)"
expect "approval audience, A2A agent" \
  "<unset>" \
  "$(env reference-agent AGENTIC_APPROVAL_AUDIENCE)"

# refused <name> <message part> <workload> [helm args...]: the app-base
# render fails, saying why.
refused() {
  local name="$1" want="$2" w="$3" access=() out
  shift 3
  [ -f "$v/$w/access.yaml" ] && access=(-f "$v/$w/access.yaml")
  if out="$(helm template "$w" "$root/charts/app-base" -n "$w" -f "$v/platform-local.yaml" "${access[@]}" \
      -f "$v/$w/app-base.yaml" "$@" 2>&1)"; then
    echo "FAIL $name: rendered, want a refusal" >&2; failures=$((failures + 1))
  elif grep -qF -- "$want" <<<"$out"; then
    echo "ok $name"
  else
    echo "FAIL $name: refused, but not for \"$want\": $out" >&2; failures=$((failures + 1))
  fi
}

# D30: an MCP server's route on Substrate's listener, from its access file.
# With it, Substrate's issuer with the route's atespaces, the listener's
# audience and the keys through the gateway; AGENTIC_SUBSTRATE_ROUTE the
# path prefix. Without it, neither.
expect "substrate route, MCP server bound to kagent agents" /substrate \
  "$(env reference-mcp AGENTIC_SUBSTRATE_ROUTE)"
expect "substrate trust entry" \
  '{"atespaces":["reference-notes-agent"],"audience":"https://workloads-gateway.agentic.internal/substrate","issuer":"https://idp.ate-system.svc","jwks_uri":"https://workloads-gateway.agentic.internal:9444/openid/v1/jwks","profile":"substrate-actor"}' \
  "$(env reference-mcp AGENTIC_TRUST | jq -c '.[] | select(.profile == "substrate-actor")')"
expect "substrate route, not bound" "<unset>" \
  "$(env reference-mcp AGENTIC_SUBSTRATE_ROUTE --set agentic.substrate.route=)"
expect "no substrate trust entry, not bound" "" \
  "$(env reference-mcp AGENTIC_TRUST --set agentic.substrate.route= | jq -c '.[] | select(.profile == "substrate-actor")')"
expect "substrate route, A2A agent" "<unset>" "$(env reference-agent AGENTIC_SUBSTRATE_ROUTE)"
refused "substrate route not in the access file" "is not a route of the access file" \
  reference-mcp --set agentic.substrate.route=reference-mcp-elsewhere
refused "substrate route on the other listener" "is not on workloads-gateway's listener substrate" \
  reference-mcp --set agentic.substrate.route=reference-mcp-workloads
refused "substrate route on the developer deployment" "is not on workloads-gateway's listener substrate" \
  reference-mcp --set agentic.substrate.route=reference-mcp
refused "substrate route with no atespaces" "names no atespaces" \
  reference-mcp --set-json 'routes.reference-mcp-substrate.atespaces=[]'
refused "substrate route of another server" "is not this server's route" \
  reference-mcp --set routes.reference-mcp-substrate.path=mcp/other-mcp
refused "substrate route on an A2A agent" "only an MCP server" \
  reference-mcp --set workload.protocol=a2a
refused "a full substrate-actor trust entry" "profile" \
  reference-mcp --set-json 'agentic.trust=[{"issuer":"https://idp.ate-system.svc","profile":"substrate-actor","jwks_uri":"https://x/jwks","audience":"https://x/substrate"}]'

[ "$failures" = 0 ] || { echo "$failures render case(s) failed" >&2; exit 1; }
