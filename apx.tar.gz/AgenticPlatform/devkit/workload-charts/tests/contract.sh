#!/usr/bin/env bash
# Checks the renders tests/render.sh wrote (design/charts.md, "The
# interface between the charts": validate in CI, never with Helm's lookup):
# - every backend agent-integration renders names a Service and port that
#   the workload's app-base render declares;
# - images are pinned by digest;
# - neither chart renders a kind the platform keeps to itself (CRDs, mesh
#   policy, Substrate's and kagent's runtime kinds, secret stores, model
#   backends);
# - every object carries the workload's label and namespace;
# - a route on the hosted-workloads deployment names its listener for
#   routes, never Substrate's;
# - every JWT provider verifies with a key-set backend in a gateway
#   deployment's namespace (D14), never inline keys or a URL.
#
# Usage: tests/contract.sh <dir tests/render.sh wrote>
set -euo pipefail

dir="${1:?usage: tests/contract.sh <render dir>}"
label=platform.example.com/workload
gateways='["gateway","workloads-gateway"]'
forbidden='["CustomResourceDefinition","WorkerPool","Harness","SandboxConfig","CSIDriverConfig","EgressPolicy",
  "PeerAuthentication","AuthorizationPolicy","DestinationRule","ServiceEntry","VirtualService","Sidecar",
  "EnvoyFilter","SecretStore","ClusterSecretStore","AgentgatewayModel","ReferenceGrant","Namespace"]'
failures=0
fail() { echo "FAIL $*" >&2; failures=$((failures + 1)); }

for wdir in "$dir"/*/; do
  name="$(basename "$wdir")"
  before=$failures
  base="$wdir/app-base.yaml"
  integ="$wdir/agent-integration.yaml"
  for f in "$base" "$integ"; do
    [ -f "$f" ] || continue
    chart="$(basename "$f" .yaml)"
    bad="$(yq ea -N "select(.kind as \$k | $forbidden | any_c(. == \$k)) | .kind + \"/\" + .metadata.name" "$f")"
    [ -z "$bad" ] || fail "$name $chart renders platform-only kinds: $bad"
    unlabelled="$(yq ea -N "select(.metadata.labels[\"$label\"] != \"$name\") | .kind + \"/\" + .metadata.name" "$f")"
    [ -z "$unlabelled" ] || fail "$name $chart: objects without $label=$name: $unlabelled"
    nons="$(yq ea -N 'select(.metadata.namespace == null or .metadata.namespace == "") | .kind + "/" + .metadata.name' "$f")"
    [ -z "$nons" ] || fail "$name $chart: objects without a namespace: $nons"
  done

  if [ -f "$base" ]; then
    unpinned="$(yq ea -N '((select(.kind == "Deployment") | .spec.template.spec.containers[].image),
      (select(.kind == "Cluster") | .spec.imageName)) | select(test("@sha256:[0-9a-f]{64}$") | not)' "$base")"
    [ -z "$unpinned" ] || fail "$name app-base: images not pinned by digest: $unpinned"
  fi

  if [ ! -f "$integ" ]; then
    [ "$failures" != "$before" ] || echo "ok $name"
    continue
  fi

  if [ -f "$base" ]; then
    # Service name:port pairs app-base declares.
    services="$(yq ea -N 'select(.kind == "Service") | .metadata.name + ":" + (.spec.ports[].port | tostring)' "$base")"
    # Every backend agent-integration renders: MCP targets, A2A hosts and
    # route rules that name a Service.
    wanted="$(yq ea -N '
      (select(.kind == "AgentgatewayBackend") | .spec.mcp.targets[]?.static | select(. != null) |
        .backendRef.name + ":" + (.port | tostring)),
      (select(.kind == "AgentgatewayBackend") | .spec.a2a | select(. != null) |
        (.host | split(".") | .[0]) + ":" + (.port | tostring)),
      (select(.kind == "HTTPRoute") | .spec.rules[].backendRefs[] |
        select((.kind // "Service") == "Service") | .name + ":" + (.port | tostring))' "$integ")"
    for w in $wanted; do
      grep -qxF "$w" <<<"$services" || fail "$name: agent-integration reaches Service $w, which app-base does not declare ($(echo $services))"
    done
    ns="$(yq ea -N 'select(.kind == "Service") | .metadata.namespace' "$base" | head -1)"
    hosts="$(yq ea -N 'select(.kind == "AgentgatewayBackend") | .spec.a2a.host | select(. != null)' "$integ")"
    for h in $hosts; do
      case "$h" in *."$ns".svc.cluster.local) ;; *) fail "$name: A2A host $h is not in the workload's namespace $ns" ;; esac
    done
  fi

  sections="$(yq ea -N '.spec.parentRefs[]? | select(.name == "workloads-gateway") |
    select((.sectionName // "") == "" or .sectionName == "substrate") | .name + "/" + (.sectionName // "<none>")' "$integ")"
  [ -z "$sections" ] || fail "$name: a hosted-workloads route without its listener for routes: $sections"

  keys="$(yq ea -N "select(.kind == \"AgentgatewayPolicy\") | .spec.traffic.jwtAuthentication.providers[]? |
    select(.jwks.inline != null or .jwks.remote.url != null or
      (.jwks.remote.backendRef.namespace as \$n | $gateways | any_c(. == \$n) | not) or
      .jwks.remote.backendRef.kind != \"AgentgatewayBackend\" or .jwks.remote.backendRef.group != \"agentgateway.dev\") |
    .issuer" "$integ")"
  [ -z "$keys" ] || fail "$name: JWT providers not on a platform key-set backend: $keys"

  [ "$failures" != "$before" ] || echo "ok $name"
done

[ "$failures" = 0 ] || { echo "$failures contract check(s) failed" >&2; exit 1; }
