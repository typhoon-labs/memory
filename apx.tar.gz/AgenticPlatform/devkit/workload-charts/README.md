# workload-charts

The platform's two workload charts ([Charts](../../architecture/design/charts.md)):

- [`app-base`](charts/app-base/README.md): a workload's Deployment, Service and ServiceAccount, with the platform's defaults: the projected STS actor token, the agentic environment, the local CA, and optionally an ExternalSecret and a one-instance CloudNativePG database.
- [`agent-integration`](charts/agent-integration/README.md): the workload's routes, backends and policies on the two gateway deployments, the approval route of an MCP server, and a kagent agent's Agent, ModelConfig and RemoteMCPServers.

A workload is installed as two releases from two separately versioned charts, `app-base` first, then `agent-integration`; uninstalled in the reverse order. A kagent agent has no Deployment and installs `agent-integration` alone. Agent instructions are in [AGENTS.md](AGENTS.md).

## Layout

```text
workload-charts/
├── charts/app-base/
├── charts/agent-integration/
├── schemas/workload-contract-v1.json   # the values contract, workloadContract v1
├── schemas/charts/                     # each chart's own part of its values.schema.json
├── compat/matrix.yaml                  # what each minor was tested against
├── tests/values/                       # example values: the three reference workloads
├── tests/refusals/                     # objects a workload release must never carry
├── tests/*.sh                          # schemas, render, contract, cases, dry-run
├── ci/push-chart.sh
└── .gitlab-ci.yml
```

## How environments installs a workload

From the workload's directory in `environments`' workloads tree, in its own namespace, which the environment's setup creates and labels with its team (`agentic-platform/owner`), and, for a kagent agent, `agentic-platform/runtime: kagent`:

| Release | Chart | Values, in order |
| --- | --- | --- |
| `<name>` | `app-base` | the platform values; its access file (`domains/<team>/<name>.yaml`); the workload's `app-base` values |
| `<name>-integration` | `agent-integration` | the platform values; its access file (`domains/<team>/<name>.yaml`); `access/quotas.yaml`; `platform/40-sts/policy.yaml`; the workload's `agent-integration` values |

The access file, the quotas and the STS policy are passed as they are: `agent-integration` reads `routes`, `quotas` and `agents` from them; `app-base` reads only the route on Substrate's listener that `agentic.substrate.route` names, for an MCP server bound to kagent agents (D30); an access file's `kagentAgents` is for the platform's `kagent-agents` release. Locally the platform values also carry `registry.skillsHost: localhost:4566/000000000000/us-east-1`, the name Substrate's atelet rewrites to floci (T29).

What the platform renders for a workload, not these charts: its namespace and NetworkPolicies, AuthorizationPolicies and PeerAuthentications (`network-boundaries`); the ReferenceGrants for the issuers' key sets (`platform-gateway`'s `keySetGrantees`); a kagent agent's WorkerPool and Harness (`kagent-agents`), its A2A routes and every route on Substrate's listener, from the same access files; the secret store an ExternalSecret names; and the workload's entry in the STS policy.

## Running the checks

From the repository root, with Helm 4, yq 4 and jq:

```sh
tests/schemas.sh --check                 # values.schema.json is what schemas/ builds
tests/render.sh /tmp/renders             # both charts for every tests/values/<name>/
tests/contract.sh /tmp/renders           # the contract between the renders
tests/cases.sh                           # single values' effects, with expected results
```

Server-side dry runs, from a shell with the local cluster's credentials, never in CI. The workloads' namespaces exist once `environments` creates them; until then, render into a scratch namespace labelled as theirs would be, and delete it after:

```sh
kubectl create namespace scratch-workloads
kubectl label namespace scratch-workloads agentic-platform/owner=reference istio-injection=enabled
tests/render.sh /tmp/renders scratch-workloads
tests/dry-run.sh /tmp/renders reference-agent reference-mcp
# a kagent agent's namespace: runtime kagent, outside the mesh
kubectl label namespace scratch-workloads istio-injection- agentic-platform/runtime=kagent
tests/dry-run.sh /tmp/renders reference-notes-agent
kubectl delete namespace scratch-workloads
```

`tests/refusals/` holds what the rules must refuse from a workload release: an EnvoyFilter (`mesh-floor`) and a kagent agent's own WorkerPool and Harness (`sandbox-privileges`). A dry run of each into the namespace above must fail.

## Pipeline

- **Every pipeline:** `charts` runs the schemas' check, `helm lint --strict` and `helm template` for each example, the contract check and the render cases; the renders are its artifact.
- **Protected `main`:** each chart pushed as `<version>-dev.<pipeline IID>` to `<registry>/platform/<chart>`, `<version>` being the one its `Chart.yaml` declares, or its next patch once that is released (`ci/dev-version.sh`), so a dev build sorts above the last release, as the project's role `ci-workload-charts` by web identity, locally with `AWS_ENDPOINT_URL` and `AWS_ENDPOINT_URL_STS` on floci. The job's report, `out/<chart>.pushed.json`, gives the chart, version, digest and commit that `environments`' `versions.yaml` takes.
- **Protected tags `app-base/vX.Y.Z` and `agent-integration/vX.Y.Z`:** that chart's release, `X.Y.Z`, which must be the version in its `Chart.yaml`. A version never moves: `ci/push-chart.sh` fails if the registry holds the version from another commit.

Two charts share the project, so their release tags carry the chart's name, as a workload added to an existing repository does ([Release tags](../../architecture/design/distribution.md#release-tags)).
