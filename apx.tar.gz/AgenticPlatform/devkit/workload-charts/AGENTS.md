# Agent instructions: workload-charts

This repository holds the platform's two workload charts, `app-base` and `agent-integration`, the values contract between them, their compatibility matrix and their tests. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. The design is in [Charts](../../architecture/design/charts.md), the layout in [Repositories](../../architecture/design/repositories.md#repository-layouts), and what B5 builds of it in the [local build plan](../../architecture/plan/local-build.md#b5-in-detail). How to run things is in the [README](README.md). The rules below are specific to this repository.

## Rules

- **Every render passes the platform's admission rules as a workload's release.** The rules are `environments`' `charts/kyverno-rules`; a chart never renders what they keep to the platform: CRDs, mesh policy (`PeerAuthentication`, `AuthorizationPolicy`, `DestinationRule`, `ServiceEntry`, `VirtualService`, `Sidecar`, `EnvoyFilter`), WorkerPools, Harnesses, SandboxConfigs, EgressPolicies, `AgentgatewayModel`s, secret stores, routes on Substrate's listener, or a kagent agent's routes. `tests/contract.sh` refuses those kinds.
- **One writer per object.** `agent-integration` never edits or patches `app-base`'s objects, and neither chart renders an object an `environments` release owns.
- **The contract is written once,** in `schemas/workload-contract-v1.json`. Each chart's `values.schema.json` is built from it and the chart's own part in `schemas/charts/` by `tests/schemas.sh`: edit those, never `values.schema.json` by hand.
- **Key sets come from the platform (D14).** A JWT provider names its issuer's key-set backend in the gateway deployment's namespace, by group, kind, namespace and name; never inline keys, a URL or a backend of the workload's own.
- **Images by digest.** A workload's image and its database's are `<registry>/<repository>@sha256:…`; the charts fail to render anything else.
- **Versions.** Each chart is versioned on its own (SemVer in its `Chart.yaml`). Once a version is released, a change to the chart's rendered output or values bumps its version in the same merge request; main's dev builds, `<version>-dev.<pipeline>`, carry each change, of the declared version while it is unreleased and of its next patch once it is released, so they sort above the last release. `agent-integration` takes a major version when an API it renders changes version, and `compat/matrix.yaml` records what each minor was tested against. Releases are tags `app-base/vX.Y.Z` and `agent-integration/vX.Y.Z`: tag only when asked.
- **Nothing in a test value is secret or real.** Example digests are placeholders until the workloads are built.
- **Never apply to a cluster.** Server-side dry runs (`tests/dry-run.sh`) are the only cluster calls this repository makes.

## Before committing

- `tests/schemas.sh --check` passes.
- `helm lint --strict` passes for each chart with each example under `tests/values/`, and `tests/render.sh <dir>`, `tests/contract.sh <dir>` and `tests/cases.sh` pass. A default that depends on another value gets a case in `tests/cases.sh`.
- `bash -n` on changed scripts.
- With the local cluster running and the change to a template: `tests/dry-run.sh` against renders in a namespace labelled as the workload's would be (README), and every render is admitted.
- `python3 ../../architecture/tools/check_docs.py .` reports no problems. It runs here, before committing, and not in CI: the pipeline has no architecture checkout to resolve the links against.
