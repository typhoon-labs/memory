{{- define "agent-integration.name" -}}
{{- $n := required "workload.name is required" .Values.workload.name -}}
{{- if not (regexMatch "^[a-z]([-a-z0-9]{0,61}[a-z0-9])?$" $n) -}}
{{- fail (printf "workload.name %q is not lowercase kebab-case of at most 63 characters" $n) -}}
{{- end -}}
{{- $n -}}
{{- end }}

{{- define "agent-integration.domain" -}}
{{- required "platform.domain is required" .Values.platform.domain -}}
{{- end }}

{{/*
The labels every object carries: the workload's, which route-claims and
gateway-policy-floor bind each route and policy to, and its team's.
*/}}
{{- define "agent-integration.labels" -}}
{{ .Values.labels.workload }}: {{ include "agent-integration.name" . }}
{{ .Values.labels.ownerTeam }}: {{ required "workload.ownerTeam is required" .Values.workload.ownerTeam }}
app.kubernetes.io/name: {{ include "agent-integration.name" . }}
app.kubernetes.io/component: integration
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{- end }}

{{/*
An issuer's URL: https://<host>.<domain><issuerPath>.
*/}}
{{- define "agent-integration.issuerURL" -}}
{{- printf "https://%s.%s%s" .issuer.host .domain .issuer.issuerPath -}}
{{- end }}

{{/*
The routes this release renders: the access file's, outside Substrate's
listener, none for a kagent agent (both are the platform's). Each path is
the workload's own, /mcp/<name> or /a2a/<name> by its protocol. As JSON:
{name: route}.
*/}}
{{- define "agent-integration.routes" -}}
{{- $name := include "agent-integration.name" . -}}
{{- $out := dict -}}
{{- if not .Values.kagent.enabled -}}
{{- range $r, $route := .Values.routes -}}
{{- if ne ($route.listener | default "") $.Values.substrateListener -}}
{{- if $route.listener -}}{{ fail (printf "route %s names listener %q; only Substrate's exists besides the default" $r $route.listener) }}{{- end -}}
{{- $path := required (printf "route %s has no path" $r) $route.path -}}
{{- $want := printf "%s/%s" $.Values.workload.protocol $name -}}
{{- if ne $path $want -}}{{ fail (printf "route %s's path %q is not the workload's own, %q" $r $path $want) }}{{- end -}}
{{- if not (hasKey $.Values.gateways ($route.gateway | default "")) -}}{{ fail (printf "route %s names gateway %q, which gateways does not" $r ($route.gateway | default "")) }}{{- end -}}
{{- $_ := set $out $r $route -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}
