# agent-integration

A workload's place on the platform: its routes on the two gateway deployments, their backends and policies, an MCP server's approval route, and a kagent agent's Agent, ModelConfig and RemoteMCPServers. It reads the workload's access file as `environments` holds it. Every value is in [values.yaml](values.yaml), with its reason.

## Values

| Value | What it sets |
| --- | --- |
| `workload.*` | The contract with `app-base` ([schema](../../schemas/workload-contract-v1.json)): the Service the routes reach is the workload's name, on `workload.port`; `protocol` decides the backend, `mcp` or `a2a` |
| `routes` | The access file's routes: per route `path`, `gateway`, and `roles`, `clients` on the developer deployment, `actors` on the hosted-workloads deployment, `tools` (tool: roles) for an MCP server. A route with `listener: substrate` is skipped (below) |
| `quotas`, `agents` | `access/quotas.yaml` and `platform/40-sts/policy.yaml` as they are: the per-person and per-agent request limits, and the actors' canonical names (`<cluster>/<namespace>/<service account>`) |
| `gateways`, `issuers` | Each deployment's namespace, issuer and listener for routes (`https` on `workloads-gateway`), and each issuer's key-set backend (D14) |
| `mcp.path` | The MCP server's endpoint on its Service, `/mcp` |
| `approvals.enabled` | The approval route; off until `route-claims` admits it |
| `stsPolicyEntry.*` | The STS policy entry, rendered on request only (below) |
| `kagent.*`, `registry.skillsHost` | A kagent agent (below) |

## What it renders, per route

For each route outside Substrate's listener, as `environments`' conformance fixtures' routes are:

- an `HTTPRoute` on the route's gateway deployment matching `/mcp/<name>` or `/a2a/<name>` alone, and on a developer MCP route the two MCP sign-in discovery paths; on `workloads-gateway` it names the listener for routes, `sectionName: https`, never Substrate's;
- an `AgentgatewayBackend`: an MCP target at the workload's Service and `mcp.path`, or an A2A host, the Service in its own namespace;
- an `AgentgatewayPolicy`: JWT authentication `Strict` with one provider, the deployment's issuer, the route's URL as its one audience, and the issuer's keys from the platform's key-set backend in the gateway deployment's namespace (`gateway/keycloak-jwks`, `workloads-gateway/delegation-sts-jwks`), which a ReferenceGrant there admits; on a developer MCP route the resource metadata for MCP sign-in; `Require` rules for one audience and, on the developer deployment, the subject, the client and a role, or on the hosted-workloads deployment the outermost actor; a local rate limit per person or per agent; the caller's token passed through; and the tools only some roles see.

The A2A backend forwards the path unchanged, so an agent serves its JSON-RPC at `/a2a/<name>` and its card at `/a2a/<name>/.well-known/agent-card.json`; the gateway's MCP backend answers MCP at any path under `/mcp/<name>` and calls the server at `mcp.path`.

## The approval route

With `approvals.enabled`, a developer MCP route gains a second rule: `/approvals/<name>`, to the workload's own Service, where a person approves a destructive tool's pending proposal with their own Keycloak token for the MCP route (`GET` and `POST /approvals/<name>/{id}`). The route's policy is the MCP route's, so only people holding a role the access file names reach it. It is never on the hosted-workloads deployment: agents never approve. `route-claims` admits the path once `environments` carries the change agreed for it; until then the value stays off.

## A kagent agent

With `kagent.enabled`, in the agent's own namespace, named after it (D18), and with no `app-base`:

- a `ModelConfig` named for the agent: the OpenAI provider, `kagent.model` (an alias), at `https://workloads-gateway.<domain>:8443/v1`, Substrate's listener, over HTTPS (D19);
- a `RemoteMCPServer` per `kagent.mcpServers` entry, at its route on the same listener;
- both with one actor token of the listener's audience, `https://workloads-gateway.<domain>/substrate`, for 300 seconds (K2, K5, D18), which `kagent-floor` requires;
- the `Agent`, on the platform's Harness named for it (`kagent.harness`), with its prompt, its tool bindings (the tools named, and those in `requireApproval` bound again with `requireApproval: true`, K3), and each skill a scratch image by digest on `registry.skillsHost`, locally `localhost:4566/…`, which atelet rewrites to floci (T29).

The agent's WorkerPool and Harness are the platform's `kagent-agents` release's, since `sandbox-privileges` admits them from platform releases alone. Its A2A routes, and every route on Substrate's listener, such as an MCP server's route for kagent agents' atespaces, are the platform's too, rendered from the same access files: a workload release may neither rewrite a path to kagent's controller nor attach to that listener. So this chart renders no route for a kagent agent and skips `listener: substrate` routes.

## The STS policy entry

The STS's policy is one reviewed file in `environments`, `platform/40-sts/policy.yaml` ([The STS policy](../../../../architecture/design/identity.md#the-sts-policy)), so this chart never installs it. For an agent that exchanges tokens, render its entry alone, then copy it into that file (the platform team does, or B6's deploy request):

```sh
helm template <name>-integration charts/agent-integration -n <namespace> \
  -f <platform values> -f <access file> -f <workload values> \
  --set stsPolicyEntry.render=true --show-only templates/sts-policy-entry.yaml
```

It gives `agents.<name>`: the actor, `<namespace>/<service account>`; its routes, the access file's routes outside Substrate's listener; `after` (`stsPolicyEntry.after`, `[person]` by default); and `targets` (`stsPolicyEntry.targets`, routes on the hosted-workloads deployment). The output is not a Kubernetes object, so an install with `stsPolicyEntry.render` set fails.
