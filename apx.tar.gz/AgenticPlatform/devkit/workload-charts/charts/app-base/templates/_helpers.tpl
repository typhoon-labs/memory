{{/*
The workload's name, checked against the naming rule: lowercase
kebab-case, at most 63 characters (design/repositories.md, "Naming").
*/}}
{{- define "app-base.name" -}}
{{- $n := required "workload.name is required" .Values.workload.name -}}
{{- if not (regexMatch "^[a-z]([-a-z0-9]{0,61}[a-z0-9])?$" $n) -}}
{{- fail (printf "workload.name %q is not lowercase kebab-case of at most 63 characters" $n) -}}
{{- end -}}
{{- $n -}}
{{- end }}

{{- define "app-base.serviceAccount" -}}
{{- .Values.workload.serviceAccount | default (include "app-base.name" .) -}}
{{- end }}

{{- define "app-base.domain" -}}
{{- required "platform.domain is required" .Values.platform.domain -}}
{{- end }}

{{/*
The labels every object carries: the workload's, which the admission rules
read, its team's, and Kubernetes' recommended ones.
*/}}
{{- define "app-base.labels" -}}
{{ .Values.labels.workload }}: {{ include "app-base.name" . }}
{{ .Values.labels.ownerTeam }}: {{ required "workload.ownerTeam is required" .Values.workload.ownerTeam }}
app.kubernetes.io/name: {{ include "app-base.name" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{- end }}

{{/*
The pods' selector: app.kubernetes.io/name, which network-boundaries
selects a workload's pods by.
*/}}
{{- define "app-base.selector" -}}
app.kubernetes.io/name: {{ include "app-base.name" . }}
{{- end }}

{{/*
The image, by digest only.
*/}}
{{- define "app-base.image" -}}
{{- $host := required "registry.host is required" .Values.registry.host -}}
{{- $repo := required "image.repository is required" .Values.image.repository -}}
{{- $digest := required "image.digest is required" .Values.image.digest -}}
{{- if not (regexMatch "^sha256:[0-9a-f]{64}$" $digest) -}}
{{- fail (printf "image.digest %q is not sha256:<64 hex>; images are pinned by digest" $digest) -}}
{{- end -}}
{{- printf "%s/%s@%s" $host $repo $digest -}}
{{- end }}

{{- define "app-base.dbName" -}}
{{- printf "%s-db" (include "app-base.name" .) -}}
{{- end }}

{{/*
AGENTIC_TRUST as JSON: each entry a route, <gateway>/<path>, expanded from
the issuer its gateway's routes carry, or a full entry as given.
*/}}
{{- define "app-base.trust" -}}
{{- $domain := include "app-base.domain" . -}}
{{- $a := .Values.agentic -}}
{{- $out := list -}}
{{- range $a.trust -}}
{{- if .route -}}
{{- $parts := splitList "/" .route -}}
{{- $gw := first $parts -}}
{{- $path := join "/" (rest $parts) -}}
{{- if or (lt (len $parts) 2) (not (regexMatch "^(mcp|a2a)/[a-z0-9-]+$" $path)) -}}
{{- fail (printf "agentic.trust route %q is not <gateway>/mcp|a2a/<name>" .route) -}}
{{- end -}}
{{- $issuerID := required (printf "agentic.gatewayIssuers has no gateway %q" $gw) (index $a.gatewayIssuers $gw) -}}
{{- $i := required (printf "agentic.issuers has no issuer %q" $issuerID) (index $a.issuers $issuerID) -}}
{{- $base := printf "https://%s.%s" $i.host $domain -}}
{{- $out = append $out (dict "issuer" (printf "%s%s" $base $i.issuerPath) "profile" $i.profile "jwks_uri" (printf "%s%s" $base $i.jwksPath) "audience" (printf "https://%s.%s/%s" $gw $domain $path)) -}}
{{- else -}}
{{- $out = append $out (dict "issuer" (required "agentic.trust: an entry without route needs issuer" .issuer) "profile" (required "agentic.trust: an entry without route needs profile" .profile) "jwks_uri" (required "agentic.trust: an entry without route needs jwks_uri" .jwks_uri) "audience" (required "agentic.trust: an entry without route needs audience" .audience)) -}}
{{- end -}}
{{- end -}}
{{- with $a.substrate.route -}}
{{- $out = append $out (include "app-base.substrateTrust" $ | fromJson) -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}

{{/*
D30: the AGENTIC_TRUST entry for Substrate's actor tokens, from the
workload's route on Substrate's listener in its access file
(agentic.substrate.route): Substrate's issuer, its keys through the
gateway's listener for them, the listener's one audience (D18), and the
route's atespaces. Fails unless the route is this MCP server's, on that
listener, with at least one atespace.
*/}}
{{- define "app-base.substrateTrust" -}}
{{- $name := include "app-base.name" . -}}
{{- $domain := include "app-base.domain" . -}}
{{- $s := .Values.agentic.substrate -}}
{{- $r := index (.Values.routes | default dict) $s.route -}}
{{- if not $r -}}{{- fail (printf "agentic.substrate.route %q is not a route of the access file (routes)" $s.route) -}}{{- end -}}
{{- if ne .Values.workload.protocol "mcp" -}}{{- fail "agentic.substrate.route: only an MCP server takes Substrate's actor tokens" -}}{{- end -}}
{{- if or (ne ($r.listener | default "") $s.listener) (ne $r.gateway $s.gateway) -}}
{{- fail (printf "agentic.substrate.route %q is not on %s's listener %s" $s.route $s.gateway $s.listener) -}}
{{- end -}}
{{- if ne $r.path (printf "mcp/%s" $name) -}}{{- fail (printf "agentic.substrate.route %q is not this server's route, mcp/%s" $s.route $name) -}}{{- end -}}
{{- if not $r.atespaces -}}{{- fail (printf "agentic.substrate.route %q names no atespaces, so it admits no agent" $s.route) -}}{{- end -}}
{{- $base := printf "https://%s.%s" $s.gateway $domain -}}
{{- toJson (dict "issuer" $s.issuer "profile" "substrate-actor"
  "jwks_uri" (printf "%s:%v%s" $base $s.keys.port $s.keys.path)
  "audience" (printf "%s/%s" $base $s.listener)
  "atespaces" $r.atespaces) -}}
{{- end }}
