# app-base

A workload's Deployment, Service and ServiceAccount, with the platform's defaults. Every value is in [values.yaml](values.yaml), with its reason; the schema is [values.schema.json](values.schema.json), built from the [workload contract](../../schemas/workload-contract-v1.json).

## Values

| Value | What it sets |
| --- | --- |
| `workload.name`, `port`, `protocol`, `serviceAccount`, `ownerTeam` | The contract with `agent-integration`: the Service and ServiceAccount, both named for the workload; the port, named `workload`; the labels `platform.example.com/workload` and `platform.example.com/owner-team`; `app.kubernetes.io/name` on the pods, which `network-boundaries` selects |
| `platform.domain`, `platform.caBundle`, `registry.host` | From the environment's platform values: hostnames, the ConfigMap with the local CA, the registry |
| `image.repository`, `image.digest` | The image, `<registry.host>/<repository>@<digest>`; nothing but a digest renders |
| `agentic.*` | The workload's environment, below |
| `telemetry.endpoint`, `serviceName` | `OTEL_EXPORTER_OTLP_ENDPOINT` (http/protobuf, the collector's general port 4318) and `OTEL_SERVICE_NAME` |
| `env`, `extraEnvFrom` | More environment; `env` may not repeat a variable the chart sets |
| `externalSecret.*` | An ExternalSecret from a store the platform makes, given to the container as environment |
| `database.*` | A one-instance CloudNativePG `Cluster`, `<name>-db`, with backups |
| `securityContext`, `readOnlyRootFilesystem`, `writablePaths`, `resources`, `probes`, `replicas` | The pod: non-root (65532 by default), seccomp `RuntimeDefault`, every capability dropped, no privilege escalation, a read-only root filesystem with an `emptyDir` per writable path (`/tmp`), `/healthz` and `/readyz` |

## The environment

The env-only surface the Python core reads (`agentic_sdk` `Runtime.from_env()`). An empty value leaves the variable unset, so the core's default applies.

| Variable | From |
| --- | --- |
| `AGENTIC_WORKLOAD_NAME` | `workload.name`, always: the core serves A2A and the approval route under it |
| `AGENTIC_LISTEN` | `agentic.listen`, default `0.0.0.0:<workload.port>` |
| `AGENTIC_GATEWAY_URL` | `agentic.gatewayUrl`, default `https://workloads-gateway.<domain>` |
| `AGENTIC_RESOURCE_BASE` | `agentic.resourceBase` |
| `AGENTIC_STS_TOKEN_ENDPOINT`, `AGENTIC_ACTOR_TOKEN_FILE` | With `agentic.sts.enabled`: `https://delegation-sts.<domain>:8443/token`, and the projected token at `/var/run/secrets/agentic/sts/token`, whose one audience is the STS's issuer, `https://delegation-sts.<domain>`, for 600 seconds ([Endpoints and audiences](../../../../architecture/design/identity.md#endpoints-and-audiences)) |
| `AGENTIC_TRUST` | `agentic.trust`: each entry a route, `<gateway>/<mcp or a2a>/<name>`, expanded to its gateway's issuer (Keycloak for `gateway`, the STS for `workloads-gateway`), that issuer's JWKS URL and the route's URL as audience; or a full entry, Keycloak's or the STS's profile. Substrate's comes from `agentic.substrate.route` alone (below) |
| `AGENTIC_CA_FILE` | `/etc/agentic/ca/ca.crt`, the `platform.caBundle` ConfigMap's `ca.crt`, when one is named |
| `AGENTIC_DATABASE_URL` | With `database.enabled`: the operator's Secret `<name>-db-app`, key `uri` |
| `AGENTIC_APPROVAL_AUDIENCE` | For an MCP server (`workload.protocol: mcp`), always: `agentic.approvals.audience`, by default its developer route's URL, `https://gateway.<domain>/mcp/<name>`, the audience of the people's tokens its approval route admits |
| `AGENTIC_APPROVAL_TTL_SECONDS` | `agentic.approvals.ttlSeconds` |
| `AGENTIC_LIMIT_MODEL_CALLS`, `_TOOL_CALLS`, `_TOKENS`, `_WALL_TIME_SECONDS` | `agentic.limits.*`: each may only lower what the image's `/etc/agentic/workload.yaml` declares |
| `AGENTIC_TOKEN_LEEWAY_SECONDS`, `AGENTIC_AUDIT_EXPORT_TIMEOUT_SECONDS` | `agentic.tokenLeewaySeconds`, `auditExportTimeoutSeconds` |
| `AGENTIC_SUBSTRATE_ROUTE`, and Substrate's entry in `AGENTIC_TRUST` | `agentic.substrate.route`, for an MCP server bound to kagent agents (D30): the name of its route on Substrate's listener in its access file (`routes`, which `environments` passes). The entry is Substrate's issuer, its keys through the hosted-workloads deployment's listener for them (`https://workloads-gateway.<domain>:9444/openid/v1/jwks`), the listener's one audience (`https://workloads-gateway.<domain>/substrate`, D18) and the route's `atespaces`; `AGENTIC_SUBSTRATE_ROUTE` is `agentic.substrate.pathPrefix`, `/substrate`, under which the platform's route calls the server. The render fails unless the route is the server's, on that listener, with at least one atespace. Empty, neither |

## The database

`database.enabled` renders the `Cluster` `<name>-db` (one instance, the database `app` owned by `app`, kept on uninstall), and with `database.backups.enabled` the `ObjectStore` `<name>-db-backups` from `database.backups.objectStore`, the environment's (locally `agentic-cnpg-backups-local` on floci, with the Secret `aws-static-credentials` the bootstrap writes), and the `ScheduledBackup` `<name>-db-daily`. The image is the environment's pinned `cnpg-postgresql`, by digest.

## What it never renders

A NetworkPolicy, an AuthorizationPolicy or a PeerAuthentication: the platform's `network-boundaries` opens a workload's namespace. A SecretStore: an ExternalSecret names the platform's. Routes or gateway policy: those are `agent-integration`'s.
