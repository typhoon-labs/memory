#!/usr/bin/env bash
# Packages charts/<chart> at <version> and pushes it to
# oci://<REGISTRY_HOST>/platform, as <REGISTRY_HOST>/platform/<chart>:<version>,
# with this job's AWS credentials (the push jobs' role). The package's
# appVersion is the commit it was built from. A version never changes:
# when the registry already holds it, the job succeeds only if it was
# built from this same commit (a retried job), and fails otherwise.
# Writes out/<chart>.pushed.json: {chart, version, digest, commit}.
#
# Usage: ci/push-chart.sh <chart> <version>
# Needs: bin/helm, the AWS CLI, jq; REGISTRY_HOST, REGISTRY_PLAIN_HTTP,
# CI_COMMIT_SHA.
set -euo pipefail

chart="${1:?usage: ci/push-chart.sh <chart> <version>}"
version="${2:?usage: ci/push-chart.sh <chart> <version>}"
helm=bin/helm
plain=()
if [ "${REGISTRY_PLAIN_HTTP:-false}" = true ]; then plain=(--plain-http); fi
registry="${REGISTRY_HOST%%/*}"
repo="oci://$REGISTRY_HOST/platform"
ref="$REGISTRY_HOST/platform/$chart:$version"
commit="${CI_COMMIT_SHA:?CI_COMMIT_SHA is not set}"

aws ecr get-login-password | "$helm" registry login "${plain[@]}" --username AWS --password-stdin "$registry"

mkdir -p out/charts
"$helm" package "charts/$chart" --version "$version" --app-version "$commit" -d out/charts >/dev/null
package="out/charts/$chart-$version.tgz"

if pushed="$("$helm" show chart "${plain[@]}" "$repo/$chart" --version "$version" 2>/dev/null)"; then
  have="$(sed -n 's/^appVersion: *//p' <<<"$pushed" | tr -d '"')"
  if [ "$have" != "$commit" ]; then
    echo "error: $ref already holds a build of $have; a version never moves" >&2
    exit 1
  fi
  echo "$ref already holds this commit's build"
  # helm prints the digest only when it pushes: ask the registry.
  digest="$(aws ecr describe-images --repository-name "platform/$chart" --image-ids imageTag="$version" \
    --query 'imageDetails[0].imageDigest' --output text)"
else
  out="$("$helm" push "$package" "$repo" "${plain[@]}" 2>&1)"
  echo "$out"
  digest="$(sed -n 's/^Digest: *//p' <<<"$out")"
fi
case "$digest" in sha256:*) ;; *) echo "error: no digest for $ref" >&2; exit 1 ;; esac

jq -n --arg chart "$REGISTRY_HOST/platform/$chart" --arg version "$version" --arg digest "$digest" \
  --arg commit "$commit" '{chart: $chart, version: $version, digest: $digest, commit: $commit}' |
  tee "out/$chart.pushed.json"
