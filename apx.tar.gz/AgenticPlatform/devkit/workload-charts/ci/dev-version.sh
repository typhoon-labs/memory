#!/usr/bin/env bash
# Prints the version of main's dev build of charts/<chart>:
# <version>-dev.<build>, where <version> is the version its Chart.yaml
# declares while that is unreleased, and once the registry holds it as a
# release, its next patch. A dev build so always sorts above the last
# release and below the next: after app-base 0.1.0, 0.1.1-dev.N, until a
# change bumps Chart.yaml (AGENTS.md, "Versions").
#
# Usage: ci/dev-version.sh <chart> <build>
# Needs: the AWS CLI, with this job's credentials; REGISTRY_HOST's
# repository platform/<chart>. Any answer but the release's digest or
# ImageNotFoundException stops it, so a failed lookup never yields a dev
# build that sorts below the release.
set -euo pipefail

chart="${1:?usage: ci/dev-version.sh <chart> <build>}"
build="${2:?usage: ci/dev-version.sh <chart> <build>}"
case "$build" in '' | *[!0-9]*) echo "error: build $build is not a number" >&2; exit 1 ;; esac

declared="$(sed -n 's/^version: *//p' "charts/$chart/Chart.yaml")"
if [[ ! "$declared" =~ ^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$ ]]; then
  echo "error: charts/$chart/Chart.yaml declares '$declared', not X.Y.Z" >&2
  exit 1
fi

err="$(mktemp)"
if aws ecr describe-images --repository-name "platform/$chart" --image-ids imageTag="$declared" \
  --query 'imageDetails[0].imageDigest' --output text >/dev/null 2>"$err"; then
  # Released: the next patch's dev build.
  version="${BASH_REMATCH[1]}.${BASH_REMATCH[2]}.$((BASH_REMATCH[3] + 1))"
elif grep -q ImageNotFoundException "$err"; then
  version="$declared"
else
  echo "error: looking up platform/$chart:$declared in the registry:" >&2
  cat "$err" >&2
  exit 1
fi
rm -f "$err"
echo "$version-dev.$build"
