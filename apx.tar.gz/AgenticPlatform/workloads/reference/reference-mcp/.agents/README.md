# .agents

Prompts and skills for the agents that work on reference-mcp, such as a coding
agent in this repository. An MCP server has no prompt of its own; its
tools' descriptions are its docstrings.
