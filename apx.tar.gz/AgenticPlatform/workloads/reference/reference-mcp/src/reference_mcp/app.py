"""reference-mcp's plumbing: an MCP server over streamable HTTP on the
platform's SDK, agent-sdk's `agentic_sdk`. The tools are in tools.py; this
file seldom changes.

- Every setting comes from the environment (`agentic_sdk.runtime.Runtime`),
  which app-base sets in a pod and the contract stage in CI; starting makes
  no network call.
- Each request's bearer token is verified against `AGENTIC_TRUST`'s issuers
  before the MCP endpoint sees it, and the request becomes an invocation:
  its caller, its token and its task (`agentic_sdk.context`).
- Each tool call goes through `ToolGuard`: idempotency by task ID for a
  tool that is not read-only, an approval for a destructive one, the
  workload's wall time, and one tool audit record per call.
- A tool's MCP annotations come from workload.yaml, where they are declared
  once; the build copies it to /etc/agentic/workload.yaml.
- The approval route, `/approvals/reference-mcp/<id>`, is served when a tool
  needs approvals; probes at `/healthz` and `/readyz`.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

import uvicorn
from mcp.server.mcpserver import MCPServer
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import CallToolResult, ToolAnnotations

from agentic_sdk.approvals import ApprovalRoute, Target, ToolGuard, ToolPolicy
from agentic_sdk.runtime import Runtime
from agentic_sdk.serve import prepare, workload_app

NAME = "reference-mcp"
MCP_PATH = "/mcp"

log = logging.getLogger(NAME)

Apply = Callable[[Any], Awaitable[dict[str, Any]]]
TargetReader = Callable[[Any], Awaitable[Target | None]]


def text(value: str, structured: Any = None) -> dict[str, Any]:
    """A tool's successful result: text for people and models, and the same
    as structured content when given."""
    out: dict[str, Any] = {"isError": False, "content": [{"type": "text", "text": value}]}
    if structured is not None:
        out["structuredContent"] = structured
    return out


class McpWorkload:
    """The MCP server, its guard and its tools' declarations."""

    def __init__(self, runtime: Runtime):
        self.runtime = runtime
        workload = runtime.workload
        if workload is None:
            raise SystemExit(f"no workload file at {runtime.workload_file}")
        self.declared = {t["name"]: t for t in workload.get("tools", [])}
        self.guard = ToolGuard(runtime.store, runtime.audit, caps=runtime.caps())
        self.mcp = MCPServer(NAME, instructions=workload.get("description"))
        self.registered: set[str] = set()

    # --- declaring tools ------------------------------------------------
    def annotations(self, tool: str) -> ToolAnnotations:
        """The tool's annotations as workload.yaml declares them."""
        if tool not in self.declared:
            raise SystemExit(f"{tool} is not declared in workload.yaml's tools")
        return ToolAnnotations(**self.declared[tool]["annotations"])

    def policy(self, tool: str) -> ToolPolicy:
        return ToolPolicy.from_annotations(tool, self.declared[tool]["annotations"])

    def tool(self, fn: Callable[..., Awaitable[CallToolResult]]) -> Callable[..., Awaitable[CallToolResult]]:
        """Registers fn as an MCP tool named after it, with its declared
        annotations; its docstring is its description."""
        self.mcp.tool(name=fn.__name__, annotations=self.annotations(fn.__name__))(fn)
        self.registered.add(fn.__name__)
        return fn

    async def call(self, tool: str, arguments: dict[str, Any], apply: Apply, *,
                   target: TargetReader | None = None) -> CallToolResult:
        """Runs one call through the guard: apply(tx) makes the change and
        returns the result; target(tx) reads the object a destructive call
        changes, with its version (tx is None before the transaction)."""
        result = await self.guard.call(self.policy(tool), arguments, apply, target=target)
        return CallToolResult.model_validate(result)

    async def current_target(self, tool: str, target_id: str) -> Target | None:
        """The approval route's view of a target's version now; a server
        whose destructive tools change objects overrides it."""
        return None

    # --- serving ----------------------------------------------------------
    def asgi(self):
        """The workload's ASGI app: probes, inbound authentication, the MCP
        endpoint and, when a tool needs one, the approval route."""
        missing = set(self.declared) - self.registered
        if missing:
            raise SystemExit(f"workload.yaml declares tools this server lacks: {', '.join(sorted(missing))}")
        # Stateless: each request runs in its own invocation, so a tool sees
        # the caller of the request it answers. DNS rebinding protection is
        # for servers a browser reaches on loopback; this one is reached
        # through the gateways and checks every token itself.
        mcp_app = self.mcp.streamable_http_app(
            streamable_http_path=MCP_PATH, stateless_http=True, json_response=True,
            transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False))
        approvals = None
        if any(self.policy(t).needs_approval for t in self.declared):
            approvals = ApprovalRoute(self.runtime.store, self.runtime.approval_verifier,
                                      name=self.runtime.require_workload_name(),
                                      lifetime=self.runtime.approval_lifetime,
                                      current_target=self.current_target)
        return workload_app(mcp_app, self.runtime.verifier, approvals=approvals)


def main(build: Callable[[Runtime], McpWorkload] | None = None) -> None:
    runtime = Runtime()
    # Settings checked, the SDK's log lines on stderr, tracing set up and
    # exported: without it the audit records carry no trace IDs.
    prepare(runtime)
    if build is None:
        from .tools import build
    workload = build(runtime)
    host, port = runtime.listen
    uvicorn.run(workload.asgi(), host=host, port=port, log_level="info", proxy_headers=False,
                server_header=False, timeout_graceful_shutdown=20)
