"""reference-mcp: An MCP server over streamable HTTP."""
