"""Starts reference-mcp: `python -m reference_mcp`."""

from .app import main

main()
