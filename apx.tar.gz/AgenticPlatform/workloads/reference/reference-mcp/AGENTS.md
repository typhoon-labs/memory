# Agent instructions: reference-mcp

reference-mcp is an MCP server of team `reference`, generated from the platform's
`mcp-server-python` template; `.copier-answers.yml` records which version.
How it is built and run is in the [README](README.md).

## Rules

- **Declare a tool in `workload.yaml` before writing it** in
  `src/reference_mcp/tools.py`: its name and annotations, `readOnlyHint` always
  and `destructiveHint` when it is not read-only. The server takes its
  annotations from there and refuses to start when the two differ.
- **Every tool runs its work through `w.call`,** so that the call is
  checked, deduplicated, approved when destructive, and audited.
- **Settings come from the environment** (`AGENTIC_*`, `OTEL_*`), never
  from files in the image or constants in code; no secret in the
  repository.
- **Dependencies:** `uv add`, then commit `uv.lock`. The platform's SDK
  comes from agent-sdk's registry alone.
- **Template updates** arrive as merge requests from `copier update`;
  never edit `.copier-answers.yml` by hand.

## Before committing

- `uv run --locked pytest` passes.
- `uv lock --check` passes.
