"""reference-mcp bound to kagent agents (D30): reference-notes-agent's
Substrate actor tokens are accepted on the server's route on Substrate's
listener, /substrate/mcp, and nowhere else; another atespace or audience is
refused; and add_note still needs a person's approval when an actor calls
it (K3: the tool's own approval, whoever calls)."""

from __future__ import annotations

import asyncio
import json
import time
import uuid

import httpx2
import pytest
from mcp import Client
from mcp.client.streamable_http import streamable_http_client

from agentic_sdk.audit import AuditEmitter
from agentic_sdk.runtime import Runtime
from conftest import AUDIENCE, ISSUER, NAME, ROOT, Issuer, b64, records, serving
from reference_mcp.notes import MemoryNotes, Note
from reference_mcp.tools import build

ATE = "https://idp.ate-system.svc"
LISTENER = "https://workloads-gateway.agentic.internal/substrate"
GRANTED, OTHER = "reference-notes-agent", "kagent-outsider"


class Substrate(Issuer):
    """Substrate's IdP's actor tokens, in the shape B4 minted them: typ JWT,
    aud an array, nbf five minutes back, actor.ate.dev."""

    def actor(self, atespace: str = GRANTED, aud: str = LISTENER) -> str:
        now, name = int(time.time()), f"session-{uuid.uuid4().hex[:8]}"
        head = b64(json.dumps({"alg": "ES256", "kid": self.kid, "typ": "JWT"}).encode())
        body = b64(json.dumps({"iss": self.iss, "sub": f"actor/{atespace}/{name}", "aud": [aud], "iat": now,
                               "nbf": now - 300, "exp": now + 300, "jti": uuid.uuid4().hex,
                               "actor.ate.dev": {"atespace": atespace, "actorName": name,
                                                 "actorUID": str(uuid.uuid4())}}).encode())
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

        r, s = decode_dss_signature(self.key.sign(f"{head}.{body}".encode(), ec.ECDSA(hashes.SHA256())))
        return f"{head}.{body}.{b64(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}"


@pytest.fixture(scope="module")
def substrate() -> Substrate:
    return Substrate(ATE, kid="ate-1")


@pytest.fixture
def runtime(issuer, substrate, audit) -> Runtime:
    from agentic_sdk.identity import StaticKeys

    trust = [{"issuer": ISSUER, "profile": "keycloak", "jwks_uri": "http://unused/jwks", "audience": AUDIENCE},
             {"issuer": ATE, "profile": "substrate-actor", "jwks_uri": "http://unused/ate-jwks",
              "audience": LISTENER, "atespaces": [GRANTED]}]
    rt = Runtime(environ={"AGENTIC_TRUST": json.dumps(trust), "AGENTIC_SUBSTRATE_ROUTE": "/substrate",
                          "AGENTIC_APPROVAL_AUDIENCE": AUDIENCE, "AGENTIC_WORKLOAD_NAME": NAME},
                 workload_file=str(ROOT / "workload.yaml"))
    rt.__dict__["_keys"] = {ISSUER: StaticKeys(issuer.jwks()), ATE: StaticKeys(substrate.jwks())}
    rt.__dict__["audit"] = AuditEmitter(NAME, stream=audit)
    return rt


async def call(base: str, path: str, token: str, tool: str, arguments: dict, task: str):
    headers = {"Authorization": f"Bearer {token}", "Agentic-Task-Id": task}
    http = httpx2.AsyncClient(headers=headers, trust_env=False, timeout=10)
    async with http, Client(streamable_http_client(f"{base}{path}", http_client=http)) as client:
        return await client.call_tool(tool, arguments)


def post(base: str, path: str, token: str | None) -> int:
    headers = {"Accept": "application/json, text/event-stream"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return httpx2.post(f"{base}{path}", headers=headers, trust_env=False,
                       json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"}).status_code


def test_actor_tokens_on_the_substrate_route_alone(runtime, issuer, substrate):
    with serving(runtime, build) as base:
        assert post(base, "/substrate/mcp", substrate.actor()) == 200           # the granted atespace
        assert post(base, "/mcp", substrate.actor()) == 401                     # not on the other routes
        assert post(base, "/substrate/mcp", substrate.actor(OTHER)) == 401      # another atespace
        assert post(base, "/substrate/mcp", substrate.actor(aud=AUDIENCE)) == 401  # another audience
        assert post(base, "/substrate/mcp", issuer.token("alice")) == 401       # a person's token there
        assert post(base, "/mcp", issuer.token("alice")) == 200                 # its twin, on /mcp


def test_add_note_from_an_actor_still_needs_a_persons_approval(runtime, issuer, substrate, audit):
    built = {}

    def keep(rt):
        built["w"] = build(rt)
        return built["w"]

    with serving(runtime, keep) as base:
        note = f"note-{uuid.uuid4().hex[:8]}"
        assert isinstance(built["w"].notes, MemoryNotes)
        asyncio.run(built["w"].notes.put(Note(note, "Ingest", "Restart the ingest job", 7)))
        actor = substrate.actor()
        args = {"note_id": note, "text": "Then check the lag."}
        r = asyncio.run(call(base, "/substrate/mcp", actor, "add_note", args, "k3"))
        assert r.is_error and r.structured_content["error"] == "approval_missing"
        aid = r.structured_content["approval_id"]
        # No agent approves: the actor's token is refused on the approval route.
        url = f"{base}/approvals/{NAME}/{aid}"
        assert httpx2.get(url, headers={"Authorization": f"Bearer {actor}"}, trust_env=False).status_code == 401
        # A person does; then the actor's call applies once.
        bob = {"Authorization": f"Bearer {issuer.token('bob')}"}
        got = httpx2.get(url, headers=bob, trust_env=False).json()
        ok = httpx2.post(url, headers=bob, trust_env=False,
                         json={"parameters_hash": got["parameters_hash"], "target_version": "7"})
        assert ok.status_code == 200
        r = asyncio.run(call(base, "/substrate/mcp", actor, "add_note", {**args, "approval_id": aid}, "k3"))
        assert not r.is_error and r.structured_content == {"id": note, "version": "8"}
    recs = [x for x in records(audit) if x.get("tool.name") == "add_note"]
    assert [x["tool.call.outcome"] for x in recs][-1] == "completed"
    assert all(x.get("actor.sub", "").startswith(f"actor/{GRANTED}/") and "user.id" not in x for x in recs)
