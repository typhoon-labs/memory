"""Test fixtures: a test issuer and its key set over HTTP, and the server
itself on a loopback port, configured through the environment as the
platform configures it."""

from __future__ import annotations

import base64
import contextlib
import io
import json
import secrets
import socket
import threading
import time
from collections.abc import Iterator
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest
import uvicorn
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from agentic_sdk.audit import AuditEmitter
from agentic_sdk.runtime import Runtime

ROOT = Path(__file__).resolve().parent.parent
NAME = "reference-mcp"
ISSUER = "https://keycloak.test/realms/agentic"
AUDIENCE = f"https://gateway.test/mcp/{NAME}"


def b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


class Issuer:
    """An ES256 key, its key set, and tokens signed with it, shaped as the
    platform's Keycloak issues them."""

    def __init__(self, iss: str = ISSUER, kid: str = "test-1"):
        self.iss, self.kid = iss, kid
        self.key = ec.generate_private_key(ec.SECP256R1())

    def jwks(self) -> dict:
        n = self.key.public_key().public_numbers()
        return {"keys": [{"kty": "EC", "crv": "P-256", "kid": self.kid, "alg": "ES256", "use": "sig",
                          "x": b64(n.x.to_bytes(32, "big")), "y": b64(n.y.to_bytes(32, "big"))}]}

    def token(self, sub: str, aud: str = AUDIENCE, typ: str = "at+jwt", **claims) -> str:
        now = int(time.time())
        body = {"iss": self.iss, "sub": sub, "aud": aud, "iat": now, "exp": now + 300,
                "jti": secrets.token_urlsafe(12), "client_id": "agentctl", "sid": f"s-{sub}", **claims}
        head = b64(json.dumps({"alg": "ES256", "kid": self.kid, "typ": typ}).encode())
        payload = b64(json.dumps(body).encode())
        r, s = decode_dss_signature(self.key.sign(f"{head}.{payload}".encode(), ec.ECDSA(hashes.SHA256())))
        return f"{head}.{payload}.{b64(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}"


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="session")
def issuer() -> Iterator[Issuer]:
    yield Issuer()


@pytest.fixture(scope="session")
def jwks_uri(issuer: Issuer) -> Iterator[str]:
    body = json.dumps(issuer.jwks()).encode()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_address[1]}/jwks"
    server.shutdown()
    server.server_close()


def environment(jwks_uri: str, **extra: str) -> dict[str, str]:
    return {
        "AGENTIC_TRUST": json.dumps([{"issuer": ISSUER, "profile": "keycloak", "jwks_uri": jwks_uri,
                                      "audience": AUDIENCE}]),
        "AGENTIC_APPROVAL_AUDIENCE": AUDIENCE,
        "AGENTIC_WORKLOAD_NAME": NAME,
        **extra,
    }


@contextlib.contextmanager
def serving(runtime: Runtime, build) -> Iterator[str]:
    """The workload built by build(runtime), served on a loopback port, the
    process prepared first as main() prepares it."""
    from agentic_sdk.serve import prepare

    prepare(runtime)
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(build(runtime).asgi(), host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(200):
        if server.started:
            break
        time.sleep(0.02)
    try:
        yield f"http://127.0.0.1:{port}"
    finally:
        server.should_exit = True
        thread.join(10)


@pytest.fixture
def audit() -> io.StringIO:
    return io.StringIO()


@pytest.fixture
def runtime(jwks_uri: str, audit: io.StringIO) -> Runtime:
    rt = Runtime(environ=environment(jwks_uri), workload_file=str(ROOT / "workload.yaml"))
    # Audit records to a buffer the tests read, as the collector would get them.
    rt.__dict__["audit"] = AuditEmitter(NAME, stream=audit)
    return rt


def records(audit: io.StringIO) -> list[dict]:
    return [json.loads(line) for line in audit.getvalue().splitlines() if line.strip()]
