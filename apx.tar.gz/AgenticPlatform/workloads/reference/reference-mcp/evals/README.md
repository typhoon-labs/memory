# Evaluations

reference-mcp's evaluations: datasets and their expected results, run in merge
requests once the platform's evaluation component exists. Their scores
and thresholds go to workload.yaml's `evaluation` when the workload
becomes `supported`.
