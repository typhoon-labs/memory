# reference-mcp

An MCP server over streamable HTTP.

An MCP server over streamable HTTP, owned by team `reference`, built on the
platform's SDK (`agentic_sdk`) from the `mcp-server-python` template.

```text
reference-mcp/
├── src/reference_mcp/tools.py    # the tools
├── src/reference_mcp/app.py      # the server: identity, guard, approvals, probes
├── tests/                 # the server over HTTP with a test issuer
├── deploy/                # app-base and agent-integration values, the access file
├── workload.yaml          # name, owner, tools and their annotations, limits
├── Dockerfile             # built by ci-components' build component
└── .gitlab-ci.yml         # ci-components' workload umbrella
```

## Run the tests

```sh
uv sync --locked
uv run --locked pytest
```

uv reads the SDK from agent-sdk's PyPI registry: give it a token with
`read_api`, for example `UV_INDEX_AGENTIC_USERNAME=<you>` and
`UV_INDEX_AGENTIC_PASSWORD=<token>`.

## What the platform gives it

| Variable | Holds |
| --- | --- |
| `AGENTIC_TRUST` | The issuers and audiences of the tokens it accepts |
| `AGENTIC_SUBSTRATE_ROUTE` | `/substrate`: where the platform's route on Substrate's listener calls it, the one place it accepts reference-notes-agent's actor tokens (D30; `deploy/app-base.yaml`'s `agentic.substrate.route`) |
| `AGENTIC_APPROVAL_AUDIENCE`, `AGENTIC_APPROVAL_TTL_SECONDS` | The approval route's audience and an approval's lifetime |
| `AGENTIC_DATABASE_URL` | Postgres for approvals, idempotency keys and the server's data; in memory when unset |
| `AGENTIC_LIMIT_WALL_TIME_SECONDS` | Lowers workload.yaml's limit, never raises it |
| `AGENTIC_LISTEN` | `0.0.0.0:8080` by default |
| `OTEL_*` | Traces and audit records over OTLP/HTTP |

The MCP endpoint is `/mcp`, and `/substrate/mcp` for kagent agents;
`/healthz` and `/readyz` answer without a token; the approval route serves `/approvals/reference-mcp/<id>` once a tool needs
approvals.

## Release

Tag `vX.Y.Z` on `main`: the pipeline builds the image for amd64 and arm64,
pushes it to ECR as `workloads/reference/reference-mcp` and signs it. Deploying it is a merge
request in `environments`.
