"""Starts reference-agent: `python -m reference_agent`."""

from .agent import main

main()
