"""reference-agent: An agent on Google ADK, served over A2A.

An agent on Google ADK, served over A2A by the platform's SDK
(`agentic_sdk_adk`):

- its model is an alias through the gateway's model route (`fast-default`),
  called with a token the STS exchanged for the person asking;
- its tools are the MCP servers workload.yaml's `requires.tools` names,
  each through the gateway with a token for that server's route alone,
  filtered to the tools named there, which the access file grants;
- each A2A message is a task with workload.yaml's limits, which the
  environment may lower, and a task they stop ends with the spec's error;
- people's tokens are verified against `AGENTIC_TRUST` before ADK sees a
  request, and the card is public at `/a2a/reference-agent/.well-known/agent-card.json`.
"""

from __future__ import annotations

from pathlib import Path

import agentic_sdk_adk  # noqa: F401  (ADK's settings, before ADK is imported)
from google.adk.agents import LlmAgent

from agentic_sdk.runtime import Runtime
from agentic_sdk_adk.models import gateway_openai
from agentic_sdk_adk.tools import gateway_mcp

MODEL = "fast-default"
PROMPT = Path(__file__).resolve().parents[2] / ".agents" / "prompts" / "system.md"


def build(runtime: Runtime) -> LlmAgent:
    requires = (runtime.workload or {}).get("requires", {})
    tools = [gateway_mcp(runtime, t["server"], tool_filter=t["tools"]) for t in requires.get("tools", [])]
    return LlmAgent(
        name="reference_agent",
        description="An agent on Google ADK, served over A2A.",
        model=gateway_openai(runtime, MODEL),
        instruction=PROMPT.read_text(),
        tools=tools,
    )


def sessions(runtime: Runtime):
    """ADK's sessions in Postgres when AGENTIC_DATABASE_URL is set, which
    app-base's database gives; in memory otherwise."""
    dsn = runtime.environ.get("AGENTIC_DATABASE_URL")
    if not dsn:
        return None
    from google.adk.sessions import DatabaseSessionService

    return DatabaseSessionService(db_url=dsn.replace("postgresql://", "postgresql+asyncpg://", 1))


def main() -> None:
    """Serves the agent; serve() prepares the process first: settings
    checked, the SDK's log lines on stderr, tracing set up and exported."""
    import asyncio

    from agentic_sdk_adk.a2a import serve

    runtime = Runtime()
    asyncio.run(serve(build(runtime), runtime, session_service=sessions(runtime)))
