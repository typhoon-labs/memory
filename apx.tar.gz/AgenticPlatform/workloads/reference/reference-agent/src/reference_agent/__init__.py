"""reference-agent: An agent on Google ADK, served over A2A."""
