# Skills

Skills for the agents that work on reference-agent, such as a coding agent in
this repository, one directory each with its `SKILL.md`.
