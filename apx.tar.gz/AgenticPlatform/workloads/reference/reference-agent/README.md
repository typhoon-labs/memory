# reference-agent

An agent on Google ADK, served over A2A.

An agent on Google ADK, served over A2A, owned by team `reference`, built on
the platform's SDK (`agentic_sdk_adk`) from the `adk-agent` template.

```text
reference-agent/
├── src/reference_agent/agent.py     # the agent: model, tools, prompt
├── .agents/prompts/system.md
├── tests/                  # the agent over A2A with stand-ins for the gateway and the STS
├── deploy/                 # app-base and agent-integration values, the access file
├── workload.yaml           # name, owner, tools it calls, limits
├── Dockerfile              # built by ci-components' build component
└── .gitlab-ci.yml          # ci-components' workload umbrella
```

## Run the tests

```sh
uv sync --locked
uv run --locked pytest
```

uv reads the SDK from agent-sdk's PyPI registry: give it a token with
`read_api`, for example `UV_INDEX_AGENTIC_USERNAME=<you>` and
`UV_INDEX_AGENTIC_PASSWORD=<token>`.

## What the platform gives it

| Variable | Holds |
| --- | --- |
| `AGENTIC_TRUST` | The issuers and audiences of the tokens it accepts |
| `AGENTIC_GATEWAY_URL`, `AGENTIC_RESOURCE_BASE` | Where the model and tools are, and the base of their audiences |
| `AGENTIC_STS_TOKEN_ENDPOINT`, `AGENTIC_ACTOR_TOKEN_FILE` | The STS, and the projected token it exchanges callers' tokens with |
| `AGENTIC_WORKLOAD_NAME` | The name in its paths, `/a2a/reference-agent` |
| `AGENTIC_DATABASE_URL` | Postgres for ADK's sessions; in memory when unset |
| `AGENTIC_LIMIT_*` | Lower workload.yaml's limits, never raise them |
| `OTEL_*` | Traces over OTLP/HTTP |

A2A's JSON-RPC is at `/a2a/reference-agent` and its card at
`/a2a/reference-agent/.well-known/agent-card.json`, without a token; `/healthz`
and `/readyz` too.

## Release

Tag `vX.Y.Z` on `main`: the pipeline builds the image for amd64 and arm64,
pushes it to ECR as `workloads/reference/reference-agent` and signs it. Deploying it is a merge
request in `environments`.
