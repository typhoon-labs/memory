# Agent instructions: reference-agent

reference-agent is an ADK agent of team `reference`, served over A2A, generated
from the platform's `adk-agent` template; `.copier-answers.yml` records which
version. How it is built and run is in the [README](README.md).

## Rules

- **Models only through the gateway,** by alias (`fast-default`), with
  `agentic_sdk_adk.models`; never a provider's SDK with a key.
- **Tools only through the gateway,** with `agentic_sdk_adk.tools`; declare
  each MCP server and its tools in `workload.yaml`'s `requires.tools`, and
  ask for the same grant in the access file.
- **The prompt is `.agents/prompts/system.md`;** a change to it is reviewed
  like code, and evaluations cover it.
- **Settings come from the environment** (`AGENTIC_*`, `OTEL_*`); no
  secret in the repository.
- **Dependencies:** `uv add`, then commit `uv.lock`. The platform's SDK
  comes from agent-sdk's registry alone.
- **Template updates** arrive as merge requests from `copier update`;
  never edit `.copier-answers.yml` by hand.

## Before committing

- `uv run --locked pytest` passes.
- `uv lock --check` passes.
