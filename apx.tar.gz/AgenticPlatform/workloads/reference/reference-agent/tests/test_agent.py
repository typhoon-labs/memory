"""reference-agent over A2A, with stand-ins for the gateway's model route and for
the STS: its card is public where the gateway forwards it, a message
without a valid token is refused, and a message is answered through the
model route with a token the STS exchanged for the person asking, each
person's under concurrent callers."""

from __future__ import annotations

import asyncio
import json
import uuid
from urllib.parse import parse_qsl

import httpx
import pytest

from conftest import ANSWER, NAME, NOT_GRANTED, RESOURCE_BASE, Issuer, claims

A2A = f"/a2a/{NAME}"


def message(text: str) -> dict:
    return {"jsonrpc": "2.0", "id": 1, "method": "SendMessage", "params": {"message": {
        "messageId": str(uuid.uuid4()), "role": "ROLE_USER", "parts": [{"text": text}]}}}


async def send(client: httpx.AsyncClient, base: str, token: str | None, text: str, task: str) -> httpx.Response:
    headers = {"A2A-Version": "1.0", "Agentic-Task-Id": task}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    return await client.post(base + A2A, json=message(text), headers=headers, timeout=60)


def answer_text(response: httpx.Response) -> tuple[str, str]:
    task = response.json()["result"]["task"]
    texts = [p.get("text", "") for a in task.get("artifacts", []) for p in a.get("parts", [])]
    texts += [p.get("text", "") for p in task["status"].get("message", {}).get("parts", [])]
    return task["status"]["state"], " ".join(t for t in texts if t)


@pytest.mark.parametrize("path", [f"{A2A}/.well-known/agent-card.json", "/.well-known/agent-card.json"])
def test_card_is_public(agent, path):
    r = httpx.get(agent + path, trust_env=False)
    assert r.status_code == 200
    assert r.json()["name"] == "reference_agent"


@pytest.mark.parametrize("token", [None, "not-a-token"])
def test_refuses_a_message_without_a_valid_token(agent, gateway, token):
    async def go():
        async with httpx.AsyncClient(trust_env=False) as c:
            return await send(c, agent, token, "hello", "t-refused")

    r = asyncio.run(go())
    assert r.status_code == 401 and r.headers["www-authenticate"].startswith("Bearer")
    assert gateway.model_calls() == []


def test_answers_through_the_model_route_as_each_caller(agent, gateway, sts, issuer: Issuer):
    people = [f"person-{i}" for i in range(6)]

    async def go():
        async with httpx.AsyncClient(trust_env=False) as c:
            return await asyncio.gather(*[send(c, agent, issuer.token(p), f"What do my notes say, {p}?", f"task-{p}")
                                          for p in people])

    responses = asyncio.run(go())
    for r in responses:
        assert r.status_code == 200, r.text
        state, text = answer_text(r)
        assert state == "TASK_STATE_COMPLETED", r.text
        assert ANSWER in text
    # Each model call carried a token the STS issued for the person whose
    # message it answers, for the model route alone, and offered no tool
    # beyond workload.yaml's.
    calls = gateway.model_calls()
    assert len(calls) >= len(people)
    for call in calls:
        req = json.loads(call["body"])
        c = claims(call["headers"]["authorization"].removeprefix("Bearer "))
        assert c["aud"] == f"{RESOURCE_BASE}/v1"
        asked = next(m["content"] for m in req["messages"] if m["role"] == "user")
        asked = asked if isinstance(asked, str) else " ".join(p.get("text", "") for p in asked)
        assert asked.endswith(f"{c['sub']}?")
        assert NOT_GRANTED not in {t["function"]["name"] for t in (req.get("tools") or [])}
    # Each tool call, a token for that server's route alone, for its caller.
    for server, tool, auth in gateway.mcp_calls:
        assert claims(auth.removeprefix("Bearer "))["aud"] == f"{RESOURCE_BASE}/mcp/{server}"
    subjects = {claims(dict(parse_qsl(s["body"].decode()))["subject_token"])["sub"] for s in sts.seen}
    assert subjects == set(people)


DATABASE = __import__("os").environ.get("AGENTIC_TEST_DATABASE_URL")


@pytest.mark.skipif(not DATABASE, reason="AGENTIC_TEST_DATABASE_URL names no throwaway database")
def test_sessions_in_postgres(agent_with, issuer: Issuer):
    """With AGENTIC_DATABASE_URL, as app-base's database gives it, ADK keeps
    its sessions in Postgres: the conversation is there after the answer."""
    import asyncpg

    with agent_with(AGENTIC_DATABASE_URL=DATABASE) as base:
        async def go():
            async with httpx.AsyncClient(trust_env=False) as c:
                return await send(c, base, issuer.token("dora"), "Remember this, dora?", "task-dora")

        r = asyncio.run(go())
    assert answer_text(r)[0] == "TASK_STATE_COMPLETED", r.text

    async def sessions():
        conn = await asyncpg.connect(DATABASE)
        try:
            return await conn.fetchval("select count(*) from sessions where user_id = 'dora'")
        finally:
            await conn.close()

    assert asyncio.run(sessions()) >= 1


def test_starts_while_its_database_is_unreachable(agent_with):
    """Starting makes no network call: a database still coming up delays
    the first task, never the start."""
    with agent_with(AGENTIC_DATABASE_URL="postgresql://nobody:nothing@127.0.0.1:9/none") as base:
        assert httpx.get(base + "/readyz", trust_env=False).status_code == 200
        assert httpx.get(base + f"{A2A}/.well-known/agent-card.json", trust_env=False).status_code == 200
