"""Test fixtures: a test issuer and its key set over HTTP, stand-ins for the
gateway's model route and for the STS, and the agent itself on a loopback
port, configured through the environment as the platform configures it."""

from __future__ import annotations

import base64
import contextlib
import json
import secrets
import socket
import threading
import time
from collections.abc import Iterator
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest
import uvicorn
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from agentic_sdk.runtime import Runtime

ROOT = Path(__file__).resolve().parent.parent
NAME = "reference-agent"
ISSUER = "https://keycloak.test/realms/agentic"
AUDIENCE = f"https://gateway.test/a2a/{NAME}"
RESOURCE_BASE = "https://workloads-gateway.test"


def b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


class Issuer:
    """An ES256 key, its key set, and tokens signed with it, shaped as the
    platform's Keycloak issues them."""

    def __init__(self, iss: str = ISSUER, kid: str = "test-1"):
        self.iss, self.kid = iss, kid
        self.key = ec.generate_private_key(ec.SECP256R1())

    def jwks(self) -> dict:
        n = self.key.public_key().public_numbers()
        return {"keys": [{"kty": "EC", "crv": "P-256", "kid": self.kid, "alg": "ES256", "use": "sig",
                          "x": b64(n.x.to_bytes(32, "big")), "y": b64(n.y.to_bytes(32, "big"))}]}

    def token(self, sub: str, aud: str = AUDIENCE, typ: str = "at+jwt", **claims) -> str:
        now = int(time.time())
        body = {"iss": self.iss, "sub": sub, "aud": aud, "iat": now, "exp": now + 300,
                "jti": secrets.token_urlsafe(12), "client_id": "agentctl", "sid": f"s-{sub}", **claims}
        head = b64(json.dumps({"alg": "ES256", "kid": self.kid, "typ": typ}).encode())
        payload = b64(json.dumps(body).encode())
        r, s = decode_dss_signature(self.key.sign(f"{head}.{payload}".encode(), ec.ECDSA(hashes.SHA256())))
        return f"{head}.{payload}.{b64(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}"


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="session")
def issuer() -> Iterator[Issuer]:
    yield Issuer()


@pytest.fixture(scope="session")
def jwks_uri(issuer: Issuer) -> Iterator[str]:
    body = json.dumps(issuer.jwks()).encode()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{server.server_address[1]}/jwks"
    server.shutdown()
    server.server_close()


def environment(jwks_uri: str, **extra: str) -> dict[str, str]:
    return {
        "AGENTIC_TRUST": json.dumps([{"issuer": ISSUER, "profile": "keycloak", "jwks_uri": jwks_uri,
                                      "audience": AUDIENCE}]),
        "AGENTIC_RESOURCE_BASE": RESOURCE_BASE,
        "AGENTIC_WORKLOAD_NAME": NAME,
        **extra,
    }


@contextlib.contextmanager
def serving(runtime: Runtime, port: int) -> Iterator[str]:
    """The agent, as its main() serves it, on a loopback port."""
    from agentic_sdk.serve import prepare
    from agentic_sdk_adk.a2a import a2a_app

    from reference_agent.agent import build, sessions

    prepare(runtime)
    app = a2a_app(build(runtime), runtime, session_service=sessions(runtime))
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", lifespan="on"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(200):
        if server.started:
            break
        time.sleep(0.02)
    try:
        yield f"http://127.0.0.1:{port}"
    finally:
        server.should_exit = True
        thread.join(10)


class Recorder(ThreadingHTTPServer):
    """An HTTP stand-in on a loopback port that records each request."""

    def __init__(self, answer):
        self.seen: list[dict] = []
        recorder = self

        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                body = self.rfile.read(int(self.headers.get("Content-Length") or 0))
                recorder.seen.append({"path": self.path, "headers": dict(self.headers), "body": body})
                status, ctype, out = answer(self.path, body)
                self.send_response(status)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(out)))
                self.end_headers()
                self.wfile.write(out)

            def log_message(self, *a):
                pass

        super().__init__(("127.0.0.1", 0), Handler)
        threading.Thread(target=self.serve_forever, daemon=True).start()

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.server_address[1]}"


def claims(token: str) -> dict:
    payload = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))


ANSWER = "Here is what I found."
NOT_GRANTED = "not_granted"


class Gateway:
    """The gateway's routes on one loopback port: the model route, OpenAI's
    chat completions, and each MCP server workload.yaml's requires.tools
    names, listing the tools named there and one more, not_granted, which
    the agent must never be offered. The model asks for the first offered
    tool on the first turn, then answers, quoting the tool's result."""

    def __init__(self):
        import yaml
        from mcp.server.mcpserver import MCPServer
        from mcp.server.transport_security import TransportSecuritySettings
        from mcp.types import ToolAnnotations

        self.seen: list[dict] = []
        self.mcp_calls: list[tuple[str, str, str]] = []  # (server, tool, authorization)
        self.routes = {}
        required = yaml.safe_load((ROOT / "workload.yaml").read_text()).get("requires", {}).get("tools", [])
        for entry in required:
            server = MCPServer(entry["server"])
            for tool in [*entry["tools"], NOT_GRANTED]:
                server.add_tool(self.stand_in(entry["server"], tool), name=tool, description=f"{tool}, a stand-in",
                                annotations=ToolAnnotations(readOnlyHint=tool != NOT_GRANTED))
            path = f"/mcp/{entry['server']}"
            self.routes[path] = server.streamable_http_app(
                streamable_http_path=path, stateless_http=True, json_response=True,
                transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False))
        self.port = free_port()
        self.server = uvicorn.Server(uvicorn.Config(self.app, host="127.0.0.1", port=self.port, log_level="warning", interface="asgi3",
                                                    lifespan="on" if self.routes else "off"))
        threading.Thread(target=self.server.run, daemon=True).start()
        for _ in range(200):
            if self.server.started:
                break
            time.sleep(0.02)

    @staticmethod
    def stand_in(server: str, tool: str):
        async def result() -> str:
            return f"{server} says: the result of {tool}"

        return result

    async def app(self, scope, receive, send):
        if scope["type"] == "lifespan":
            # Each MCP app's session manager runs for the server's life.
            async with contextlib.AsyncExitStack() as stack:
                for mcp_app in self.routes.values():
                    await stack.enter_async_context(mcp_app.router.lifespan_context(mcp_app))
                await receive()
                await send({"type": "lifespan.startup.complete"})
                await receive()
                await send({"type": "lifespan.shutdown.complete"})
            return
        headers = {k.decode().lower(): v.decode() for k, v in scope["headers"]}
        body = b""
        while True:
            m = await receive()
            body += m.get("body", b"")
            if not m.get("more_body"):
                break
        self.seen.append({"path": scope["path"], "headers": headers, "body": body})
        if scope["path"].startswith("/v1/"):
            out = self.model(json.loads(body))
            await send({"type": "http.response.start", "status": 200, "headers": [(b"content-type", b"application/json")]})
            await send({"type": "http.response.body", "body": out})
            return
        route = next((p for p in self.routes if scope["path"].startswith(p)), None)
        if route is None:
            await send({"type": "http.response.start", "status": 404, "headers": []})
            await send({"type": "http.response.body", "body": b""})
            return
        msg = json.loads(body) if body else None
        if isinstance(msg, dict) and msg.get("method") == "tools/call":
            self.mcp_calls.append((route.rsplit("/", 1)[1], msg["params"]["name"], headers.get("authorization", "")))
        replayed = False

        async def replay():
            nonlocal replayed
            if replayed:
                return await receive()
            replayed = True
            return {"type": "http.request", "body": body, "more_body": False}

        await self.routes[route](scope, replay, send)

    @staticmethod
    def model(req: dict) -> bytes:
        results = [m for m in req["messages"] if m.get("role") == "tool"]
        offered = [t["function"]["name"] for t in (req.get("tools") or [])]
        if offered and not results:
            message = {"role": "assistant", "content": None, "tool_calls": [
                {"id": "call-1", "type": "function", "function": {"name": offered[0], "arguments": "{}"}}]}
            finish = "tool_calls"
        else:
            quoted = " ".join(r["content"] if isinstance(r["content"], str) else json.dumps(r["content"]) for r in results)
            message, finish = {"role": "assistant", "content": f"{ANSWER} {quoted}".strip()}, "stop"
        return json.dumps({"id": "c1", "object": "chat.completion", "created": 0, "model": req["model"],
                           "choices": [{"index": 0, "message": message, "finish_reason": finish}],
                           "usage": {"prompt_tokens": 20, "completion_tokens": 10, "total_tokens": 30}}).encode()

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def model_calls(self) -> list[dict]:
        return [s for s in self.seen if s["path"].startswith("/v1/")]

    def stop(self):
        self.server.should_exit = True


@pytest.fixture(scope="session")
def sts_issuer() -> Issuer:
    return Issuer("https://delegation-sts.test", kid="sts-1")


@pytest.fixture
def sts(sts_issuer: Issuer) -> Iterator[Recorder]:
    """The STS: RFC 8693, a chain token for the subject and the resource asked."""
    from urllib.parse import parse_qsl

    def answer(path: str, body: bytes):
        form = dict(parse_qsl(body.decode()))
        sub = claims(form["subject_token"])["sub"]
        token = sts_issuer.token(sub, aud=form["resource"], act={"sub": "system:serviceaccount:test:" + NAME})
        return 200, "application/json", json.dumps({
            "access_token": token, "issued_token_type": "urn:ietf:params:oauth:token-type:access_token",
            "token_type": "Bearer", "expires_in": 300}).encode()

    server = Recorder(answer)
    yield server
    server.shutdown()
    server.server_close()


@pytest.fixture
def gateway() -> Iterator[Gateway]:
    gw = Gateway()
    yield gw
    gw.stop()


@pytest.fixture
def agent_with(jwks_uri, sts, gateway, tmp_path, issuer):
    """Starts the agent with more settings: `with agent_with(KEY=value) as base:`."""
    actor = tmp_path / "actor-token"
    actor.write_text(issuer.token("system:serviceaccount:test:" + NAME, aud="https://delegation-sts.test"))

    @contextlib.contextmanager
    def start(**extra: str) -> Iterator[str]:
        port = free_port()
        runtime = Runtime(environ=environment(jwks_uri, AGENTIC_GATEWAY_URL=gateway.url,
                                              AGENTIC_STS_TOKEN_ENDPOINT=f"{sts.url}/token",
                                              AGENTIC_ACTOR_TOKEN_FILE=str(actor), AGENTIC_LISTEN=f"127.0.0.1:{port}",
                                              **extra),
                          workload_file=str(ROOT / "workload.yaml"))
        with serving(runtime, port) as base:
            yield base

    return start


@pytest.fixture
def agent(agent_with) -> Iterator[str]:
    with agent_with() as base:
        yield base
