# reference-notes-agent

A declarative agent on kagent.

A declarative agent on kagent, owned by team `reference`, generated from
the `kagent-agent` template.

```text
reference-notes-agent/
├── config/agent.yaml        # the AgentTemplate: model, tool bindings
├── config/tools/            # each bound MCP server's tools/list
├── .agents/prompts/system.md
├── .agents/skills/<name>/   # each skill, packaged as a scratch image
├── deploy/                  # agent-integration's values, the access file
├── workload.yaml
└── .gitlab-ci.yml           # ci-components' workload umbrella, kagent mode
```

## Merge requests and releases

Each merge request runs kagent-package: the definition against kagent
1.0.1's schema, each bound tool against its server's listing, a
destructive tool without `requireApproval` refused, and each skill built
as an image from scratch. A protected `vX.Y.Z` tag publishes the skills
and the packaged definition to ECR as `workloads/reference/reference-notes-agent` and signs them.
Deploying it is an `agent-integration` release in `environments`; the
agent cannot run inside a CI job, so its evaluations run in the
environment.
