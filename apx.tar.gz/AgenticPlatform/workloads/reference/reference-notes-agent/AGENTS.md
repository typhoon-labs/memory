# Agent instructions: reference-notes-agent

reference-notes-agent is a declarative kagent agent of team `reference`, generated from
the platform's `kagent-agent` template; `.copier-answers.yml` records which
version. How it is packaged is in the [README](README.md).

## Rules

- **No code.** The agent is `config/agent.yaml`, its prompt
  `.agents/prompts/system.md` and its skills `.agents/skills/<name>/`.
- **The prompt lives in one place,** the prompt file; never also a
  `systemPrompt` in the definition.
- **Every bound server has its listing** in `config/tools/<server>.yaml`,
  and `workload.yaml`'s `requires.tools` names the same tools.
- **Read-only tools by default.** A destructive tool is bound with
  `requireApproval: true`, and the platform team reviews every grant: the
  agent calls tools as itself, not as the person asking.
- **Skills are directories,** each packaged as an image from scratch;
  never name a skill from git or a bucket.
