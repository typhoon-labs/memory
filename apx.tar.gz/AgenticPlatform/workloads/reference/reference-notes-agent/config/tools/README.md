# Tool listings

One file per MCP server the agent binds, `<server>.yaml`: the server's
`tools/list` result, or the server's own `workload.yaml`, whose `tools` have
that shape. kagent-package refuses a bound tool its server does not list,
and a destructive one bound without `requireApproval`.
