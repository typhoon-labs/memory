# Evaluations

reference-notes-agent's evaluations. A kagent agent cannot run inside a CI job, so its
evaluations and the kagent profile run on a temporary agent in the
environment (the platform's design, Repositories, "kagent agents").
