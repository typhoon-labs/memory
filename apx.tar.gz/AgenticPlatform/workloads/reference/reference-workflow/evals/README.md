# Evaluations

reference-workflow's evaluations: inputs and the outputs expected of each step, run
in merge requests once the platform's evaluation component exists.
