# reference-workflow

A workflow pipeline with a bounded model step.

A workflow of team `reference`, run as a GitLab pipeline, generated from the
`workflow-pipeline` template.

```text
reference-workflow/
├── steps/summarise-changes.step.yaml  # a bounded model step
├── scripts/collect_changes.py         # its input, from the commits
├── workload.yaml
└── .gitlab-ci.yml                     # collect, then ci-components' step
```

## The step

`collect-changes` writes the step's input; `step:summarise-changes` runs
`agentctl step run` with the definition and that input, through the
hosted-workloads gateway, and keeps its output in `out/step/summarise-changes/`.
Its exit status says how it ended: 0 a valid output, 1 failed, 3 stopped by
its limits, 4 failed and routed to a person.

The step is a manual job. On `main` it runs on the steps runner, whose job
pods alone reach the hosted-workloads gateway, as the realm's client for
this project's protected `main`, signed in by the job's GitLab ID token
(D27); that client matches `main`'s ID token alone, so a tag's pipeline
has no step. In a merge request it runs on the build runner, where the
realm refuses its ID token, which names the merge request's branch:
check 13's twin. Locally the gateway's models are the fake model, which
answers the inputs in `checks/` (its README).
