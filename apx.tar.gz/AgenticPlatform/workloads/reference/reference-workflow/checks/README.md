# Check 13's inputs

Inputs for the step, for the local build's check 13 (D27: a bounded step in
a pipeline). Locally the gateway's model aliases map to the fake model
server, which answers a fake-model directive written in the request's text
(ci-components' `conformance/fixtures/fake-model/README.md`); the input is
data the step sends in its user turn, so the directive reaches the model
there, as the SDK's own tests send it. A real model reads it as text.

| File | Directive | The step |
| --- | --- | --- |
| `step-completes.json` | `tool=submit_output`: the model calls `submit_output` with an input built from the output schema | writes a valid output and exits 0 |
| `step-over-token-limit.json` | `usage=50000`: one reply reports 50,000 output tokens, past the step's and `workload.yaml`'s 20,000 | stops with `limit_exceeded` (`spec/limits/`) and exits 3 |

Start a pipeline on `main` with the input `step-input` set to one of them,
then start its `step:summarise-changes` job. Each directive's `id` names the
fake model's records of its requests.
