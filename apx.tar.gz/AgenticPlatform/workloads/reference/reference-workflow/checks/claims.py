"""Reads one access token on standard input and prints only what check 13
records of it: the header's typ and the claims aud, exp minus iat,
client_id and team, as one JSON line after its label, then whether they
are what D27's client is given. Never prints the token or any other
claim. Standard library only, run as python3 -I.

    agentctl token --ci | python3 -I checks/claims.py <label>
"""

import base64
import json
import sys

WANT = {
    "aud": "https://workloads-gateway.agentic.internal/v1",
    "typ": "at+jwt",
    "lifetime": 300,
    "client_id": "reference-workflow",
    "team": "reference",
}


def part(segment: str) -> dict:
    return json.loads(base64.urlsafe_b64decode(segment + "=" * (-len(segment) % 4)))


def main() -> int:
    label = sys.argv[1] if len(sys.argv) > 1 else "token"
    segments = sys.stdin.read().strip().split(".")
    if len(segments) != 3:
        print(f"{label}: not a JWS compact token ({len(segments)} parts)")
        return 1
    header, claims = part(segments[0]), part(segments[1])
    aud = claims.get("aud")
    got = {
        "aud": aud[0] if isinstance(aud, list) and len(aud) == 1 else aud,
        "typ": header.get("typ"),
        "lifetime": claims["exp"] - claims["iat"] if isinstance(claims.get("exp"), int) and isinstance(claims.get("iat"), int) else None,
        "client_id": claims.get("client_id"),
        "team": claims.get("team"),
    }
    print(f"{label}: {json.dumps(got, sort_keys=True)}")
    wrong = sorted(k for k in WANT if got[k] != WANT[k])
    print(f"{label}: " + ("as D27's client is given" if not wrong else "differs in " + ", ".join(wrong)))
    return 1 if wrong else 0


if __name__ == "__main__":
    sys.exit(main())
