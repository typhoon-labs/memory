#!/bin/sh
# token-probes.sh: the platform's probes of D27's client, for check 13, run
# by the token-probes job on main's steps runner (.gitlab-ci.yml).
#
#   B1b: two agentctl token --ci requests with the same job ID token, about
#        10 s apart; both are expected to succeed.
#   B2:  one more with AGENTCTL_REALM_SCOPE_PREFIX unset, so the realm scope
#        is plain models; expected refused with invalid_scope.
#
# Each token goes straight to checks/claims.py, which logs only its aud,
# typ, exp - iat, client_id and team; no token is ever printed, and
# agentctl's errors are logged with anything shaped like a JWT redacted.
# Exits 0 when every probe ends as expected, else 1.
set -eu
echo "job pod: $(hostname 2>/dev/null || echo "${HOSTNAME:-unknown}"); image: ${CI_JOB_IMAGE:-unknown}; runner: ${CI_RUNNER_DESCRIPTION:-unknown} (${CI_RUNNER_TAGS:-})"
echo "realm scope prefix: '${AGENTCTL_REALM_SCOPE_PREFIX:-}'"

redact() { sed -E 's/eyJ[A-Za-z0-9_-]*(\.[A-Za-z0-9_-]*)*/<jwt redacted>/g'; }
failures=0
err=$(mktemp)

# probe <label> <expect: token|invalid_scope> [env -u NAME]...
probe() {
  label=$1 expect=$2
  shift 2
  started=$(date -u +%H:%M:%SZ)
  if token=$("$@" agentctl token --ci --scope models 2>"$err"); then
    echo "$label ($started): agentctl exit 0"
    if ! printf '%s' "$token" | python3 -I checks/claims.py "$label"; then failures=$((failures + 1)); fi
    token=
    [ "$expect" = token ] || { echo "$label: expected $expect, got a token"; failures=$((failures + 1)); }
  else
    status=$?
    token=
    echo "$label ($started): agentctl exit $status: $(redact < "$err")"
    if [ "$expect" = token ] || ! grep -q "$expect" "$err"; then
      echo "$label: expected $expect"
      failures=$((failures + 1))
    fi
  fi
}

probe B1b-1 token env
sleep 10
probe B1b-2 token env
probe B2 invalid_scope env -u AGENTCTL_REALM_SCOPE_PREFIX
rm -f "$err"
echo "probes ended: $failures not as expected"
[ "$failures" -eq 0 ]
