# Sandbox setup

The `agentic-platform` sandbox is declared in `sbxenv.yaml` in this folder. Run every command below on the host, from this folder.

## Prerequisites

- `sbx` installed and signed in (`sbx login`).
- The GitLab token stored in `pass` as `gitlab/agentic-platform` (see [Set up the GitLab secret](#set-up-the-gitlab-secret)).
- The SSH key for the GitLab account loaded in the host ssh-agent (`ssh-add -l`). The sandbox uses the host agent for `git push`.
- The `claude-defaults` kit in `~/.sbx/kits/claude-defaults/`. `~/.sbxenv.yaml` loads it for every sandbox created with `sbx env`.
- From build phase B1: the Okta API token stored in `pass` as `okta/agentic-platform`, and the Okta kit in `~/.sbx/kits/okta/` (see [Set up the Okta secret](#set-up-the-okta-secret)).

## Files outside this folder

| Path | Holds |
| --- | --- |
| `~/.sbxenv.yaml` | Defaults for every `sbx env` sandbox; loads the `claude-defaults` kit |
| `~/.sbx/kits/` | Our own kits: `claude-defaults` and `okta` |
| `~/.sbx/backups/agentic-platform/` | Conversation backups, one dated folder per backup |

`~/.sbx/kits/` and `~/.sbx/backups/` are our own choice, not a Docker convention, and both are private (`chmod 700`). `~/.sbx/` is also sbx's runtime folder: leave its own permissions alone. `sbx reset` removes all of sbx's state, cache and config directories, which likely includes `~/.sbx/`, so copy the kits and backups elsewhere before a reset.

## Create the sandbox

1. Unlock the GPG key, so sbx can read both tokens without a prompt. One key covers the whole password store:
   ```sh
   pass show gitlab/agentic-platform >/dev/null
   ```
2. Preview, then create and attach:
   ```sh
   sbx env plan
   sbx env run
   ```
   If `sbxenv.yaml` or a kit changed since the last create, `sbx env run` asks once to approve the plan.
3. Check inside the sandbox. Both should name the same GitLab account:
   ```sh
   glab api user
   ssh -T git@gitlab.com
   ```
   With the Okta kit, also run the check in step 7 of [Set up the Okta secret](#set-up-the-okta-secret).
4. Install the workstation tools inside the sandbox, from the workspace folder. Rerun it after every restart too:
   ```sh
   ./install-tools.sh
   ```
   Versions are in `mise.toml` and checksums in `mise.lock`. What else to know when working inside the sandbox (the model endpoint, the proxy, kind) is in `AGENTS.md`.

To reattach later: `sbx env run`.

## Remove the sandbox

Removing the sandbox deletes its secrets and its Claude conversations. It keeps the bindings in `~/.config/sbx/credentials.yaml`.

1. Back up the conversations into a dated folder:
   ```sh
   dest=~/.sbx/backups/agentic-platform/$(date +%Y%m%d-%H%M%S)
   mkdir -p "$dest"
   sbx cp agentic-platform:/home/agent/.claude/projects/ "$dest/"
   ```
2. Close any Claude session in the sandbox, then remove it:
   ```sh
   sbx env rm
   ```
   `sbx env rm --force` skips the confirmation and also removes a sandbox that is still in use, ending its session.

To resume an old conversation in a new sandbox, copy a backup back in, with `<date>` the backup's folder name, such as `20261115-211432`:

```sh
sbx cp ~/.sbx/backups/agentic-platform/<date>/projects/ agentic-platform:/home/agent/.claude/
```

Then run `claude --resume` inside the sandbox.

## Enlarge the sandbox's disks

A sandbox's two disks get their size at create, and nothing resizes them afterwards: `/var/lib/docker` from `DOCKER_SANDBOXES_DOCKER_SIZE`, or else the `sandbox.disk.dockerVolume` setting (`50g` here; `sbx settings get sandbox.disk.dockerVolume`), and `/` from `DOCKER_SANDBOXES_ROOT_SIZE`, 20 GB by default. `sbxenv.yaml` has no field for either: sbx rejects `sandboxOptions.dockerVolume` as an unknown field. To enlarge them, archive `/var/lib/docker`, create a sandbox with larger disks, and restore the archive into it: first into a test sandbox, then into the real one.

The disks are sparse files in `~/.local/state/sandboxes/` on the host's `/home`, so a larger size costs nothing until it is used. Space freed inside is not handed back: on 2026-11-19 the 50 GB Docker disk held 40 GB and took 50 GB on the host.

| What | How it moves |
| --- | --- |
| `/var/lib/docker`: the kind nodes, floci, the runners, every volume, `agentic-local-state` included | The archive below |
| The workspaces | Nothing to do: they stay on the host, and the new sandbox mounts them |
| The root filesystem: home, `/tmp`, `/etc/hosts`, the tools | Not moved. A restart loses it anyway, and the restart steps rebuild it (`AGENTS.md`, *Local build state outside Git*) |
| Claude conversations | The backup in [Remove the sandbox](#remove-the-sandbox) |
| Published ports (`sbx ports agentic-platform`) | Not moved: publish them again |

Done once, on 2026-11-10 with sbx v0.51.0, from 10 to 50 GB, with the kind cluster, its databases and its secrets intact. That run carried the root filesystem over with `sbx template save` instead. The archive, the checks and the restore below are as run then; the steps for what came later (the secrets, the kits, floci, the runners) follow `AGENTS.md` and the bootstrap, and have not been run as part of this procedure yet.

The old, the test and the new sandbox hold the same runner tokens and credentials: run only one of them at a time. Commands marked *in the sandbox* run in a shell opened with `sbx exec -it <sandbox> bash`, the others on the host. Start each shell with:

```sh
cd /mnt/data/rocket/Projects/Work/AgenticPlatform
M=$PWD/.sbx-migration
```

`M` is the staging folder; it is in the workspace, so the host and the sandbox see the same files.

1. Check the room. The archive needs as much free space on `/mnt/data` as `/var/lib/docker` uses (`df -h /var/lib/docker` in the sandbox), and the disk copy in step 6 as much as the Docker disk's size.
2. Pause the sandbox's runners in GitLab (the build runner, and the deploy, conformance and steps runners in the cluster), and let running jobs finish. The test sandbox starts the same runners with the same tokens; paused, they take no jobs.
3. *In the sandbox*: copy the state outside Git into `agentic-local-state`, as `AGENTS.md` describes. On the host, back up the conversations (step 1 of [Remove the sandbox](#remove-the-sandbox)). Then, *in the sandbox*, record what to compare against:
   ```sh
   mkdir -p "$M/before"
   k="docker exec agentic-local-control-plane kubectl --kubeconfig /etc/kubernetes/admin.conf"
   docker ps --format '{{.Names}}' | sort > "$M/before/running.txt"
   docker volume ls -q | sort > "$M/before/volumes.txt"
   $k get nodes --no-headers > "$M/before/nodes.txt"
   $k get pods -A --no-headers > "$M/before/pods.txt"
   $k get secrets -A --no-headers -o custom-columns=NS:.metadata.namespace,NAME:.metadata.name,UID:.metadata.uid > "$M/before/secrets.txt"
   ```
   Add row counts of the databases you rely on. A secret's UID shows whether it was kept or made anew.
4. *In the sandbox*: stop floci cleanly, then the Docker daemon, which stops the other containers as a restart does:
   ```sh
   docker compose -f infra/environments/clusters/local/00-local/floci/compose.yaml stop
   sudo kill -TERM "$(pgrep -x dockerd)"
   while pgrep -x dockerd >/dev/null || pgrep -x containerd >/dev/null; do sleep 1; done
   ```
   Do not `docker stop` the other containers: most restart `unless-stopped`, and would then stay down. The sandbox has no `pidof`.
5. *In the sandbox*: archive `/var/lib/docker`, then compare the archive with it:
   ```sh
   sudo tar --xattrs --xattrs-include='*' --acls --numeric-owner -cpSf "$M/docker.tar" -C /var/lib/docker .
   sudo tar --compare --xattrs --xattrs-include='*' --acls --numeric-owner -f "$M/docker.tar" -C /var/lib/docker; echo "exit $?"
   ```
   The compare must end with `exit 0` and print nothing but `socket ignored` lines: tar skips Unix sockets, which their services make again. The attribute flags keep what overlay2 and containerd need. Read the exit code from tar itself, never through a pipe. On 2026-11-10, 8 GB took about a minute each way.
6. On the host, stop the sandbox, and copy its Docker disk as a second backup, independent of tar:
   ```sh
   sbx stop agentic-platform
   cp --sparse=always ~/.local/state/sandboxes/sandboxes/sandboxd/containerd/root/com.docker.volume.driver.v1.block/images/agentic-platform-docker.img "$M/"
   e2fsck -fn "$M/agentic-platform-docker.img"
   ```
   It is a plain ext4 image. `sbx stop` leaves its journal unreplayed, so the read-only check reports wrong free counts and "still has errors"; passes 1 to 4 must report nothing.
7. Create the test sandbox with the larger disks, unlocking the GPG key first as in [Create the sandbox](#create-the-sandbox):
   ```sh
   pass show gitlab/agentic-platform >/dev/null
   DOCKER_SANDBOXES_DOCKER_SIZE=100g sbx env create --name agentic-platform-test
   ```
   Add `DOCKER_SANDBOXES_ROOT_SIZE=40g` for a larger `/`; step 8's `df` shows whether it applied. Pass no file to `sbx env`: a path skips `~/.sbxenv.yaml`, and with it the `claude-defaults` kit. Every `sbx env` command for this sandbox needs the same `--name`.
8. *In the test sandbox*: check the sizes, stop the Docker daemon, replace its empty store with the archive, and compare:
   ```sh
   df -h / /var/lib/docker
   sudo kill -TERM "$(pgrep -x dockerd)"
   while pgrep -x dockerd >/dev/null || pgrep -x containerd >/dev/null; do sleep 1; done
   sudo find /var/lib/docker -mindepth 1 -maxdepth 1 ! -name lost+found -exec rm -rf {} +
   sudo tar --xattrs --xattrs-include='*' --acls --numeric-owner -xpSf "$M/docker.tar" -C /var/lib/docker
   sudo tar --compare --xattrs --xattrs-include='*' --acls --numeric-owner -f "$M/docker.tar" -C /var/lib/docker; echo "exit $?"
   ```
   The `find` empties the new sandbox's store: run it only there. Then restart the test sandbox on the host, so the daemon starts as at boot and the containers come back by their restart policies:
   ```sh
   sbx stop agentic-platform-test
   sbx exec agentic-platform-test true
   ```
   *In the test sandbox*, start floci, and any container that was running before and is still down:
   ```sh
   docker compose -f infra/environments/clusters/local/00-local/floci/compose.yaml start
   comm -23 "$M/before/running.txt" <(docker ps --format '{{.Names}}' | sort) | xargs -r docker start
   ```
9. Check the test sandbox: record the lists of step 3 into `$M/after` and `diff` them with `$M/before` (for the pods, compare names and status: `awk '{print $1, $2, $4}'`), and check the row counts. Langfuse's worker adds its built-in dashboards and models when it starts, so more rows there are expected. Do not run the bootstrap in the test sandbox: its GitLab stage applies the group's settings and creates runners whose tokens are missing.
10. Remove the test sandbox, then the old one:
    ```sh
    sbx env rm --name agentic-platform-test
    sbx env rm
    ```
    `sbx env rm` deletes the old sandbox with its secrets and conversations: run it only once the test has passed. The backups of steps 3, 5 and 6 remain.
11. Create the sandbox again under its own name, with the same sizes, and restore into it as in step 8:
    ```sh
    DOCKER_SANDBOXES_DOCKER_SIZE=100g sbx env create
    ```
12. Put it back into use: publish its ports again (`sbx ports agentic-platform --publish 127.0.0.1:443:443`), attach with `sbx env run`, and run the restart steps in `AGENTS.md`: restore the state from `agentic-local-state`, `./install-tools.sh`, gcc, and the bootstrap. Copy the conversations back ([Remove the sandbox](#remove-the-sandbox)), check against `$M/before` as in step 9, and unpause the runners.
13. Once all is well, delete the staging folder: `rm -rf "$M"`.

## Set up the GitLab secret

1. Create a personal access token on gitlab.com: *Preferences → Access tokens → Add new token*. Set an expiry, and select these scopes:

   | Scope | For |
   | --- | --- |
   | `api` | `glab`, groups and projects, settings, merge requests |
   | `create_runner` | Creating the `build` and `deploy` runners |
   | `read_repository` | Cloning and fetching over HTTPS |
   | `write_repository` | Only if you push over HTTPS; pushes go over SSH by default |

   A runner created from inside the sandbox returns its `glrt-…` token there, in plain text. The proxy only hides the PAT.
2. Store it in `pass`:
   ```sh
   pass insert gitlab/agentic-platform
   ```
3. Declare it in `sbxenv.yaml`, with the `gitlab` kit that provides the service:
   ```yaml
   kits:
     - docker.io/sbx/gitlab-ssh:1.0.1
     - docker.io/sbx/gitlab:1.118.0
   secrets:
     gitlab:
       command: /usr/bin/pass show gitlab/agentic-platform | head -n 1
       snapshot: true
   bindings:
     gitlab:
       apiKey:
         domains:
           - gitlab.com
   ```
   The binding approves sending the token to `gitlab.com`. Without it, sbx stores the secret but does not inject it. sbx saves the binding to `~/.config/sbx/credentials.yaml`, shared by all sandboxes.
4. Recreate the sandbox: [remove it](#remove-the-sandbox), then [create it](#create-the-sandbox).
5. Confirm it is attached:
   ```sh
   sbx secret ls --sandbox agentic-platform
   ```

`snapshot: true` reads `pass` once, at create. The sandbox only ever sees a placeholder; the proxy adds the real token to requests to gitlab.com.

## Update the GitLab secret

For a new token, or a token with different scopes (GitLab cannot change the scopes of an existing token; pick them from the table in [Set up the GitLab secret](#set-up-the-gitlab-secret)):

1. Create the new token on gitlab.com.
2. Replace it in `pass`:
   ```sh
   pass edit gitlab/agentic-platform
   ```
3. Recreate the sandbox: [remove it](#remove-the-sandbox), then [create it](#create-the-sandbox). With `snapshot: true`, the new value is only read at create.
4. Check with `glab api user` inside the sandbox, then revoke the old token on gitlab.com.

## Set up the Okta secret

Needed from build phase B1. The Okta token reaches the sandbox the same way as the GitLab token, but no published kit provides an `okta` service, so it needs a small kit of its own. Okta expects `Authorization: SSWS <token>` rather than `Bearer`, which the kit sets. The kit names no org: `sbxenv.yaml` sets its `domain`. Checked on 2026-11-15 with sbx v0.53.0: the proxy sends the token as `SSWS`, and the check in step 7 returns the admin user.

1. Create the org: sign up for the Okta Integrator Free Plan at developer.okta.com with a business email (one org per email), confirm the email, and register two MFA authenticators for the admin account, so one lost device does not lock you out. Note the org's domain, written `<org>.okta.com` below. The org holds synthetic users only, never employee data.
2. Create an API token in the Admin Console: *Security → API → Tokens → Create token*, named `agentic-platform-sandbox`. If it asks which IPs may use the token, choose *Any IP*. Copy the value: Okta shows it only once. The token has the rights of the admin who created it, and Okta revokes it after 30 days without use.
3. Store it in `pass`:
   ```sh
   pass insert okta/agentic-platform
   ```
4. Create the kit's folder, then save the kit below in it as `spec.yaml`, unchanged:
   ```sh
   mkdir -p ~/.sbx/kits/okta
   chmod 700 ~/.sbx/kits
   ```
   Leave the `<org>.okta.com` default as it is. `sbxenv.yaml` sets the real domain in step 5, and a kit loaded without one fails instead of using the placeholder.
   ```yaml
   # syntax=docker/sandbox-kit:3
   schemaVersion: "3"
   displayName: Okta API token
   description: Proxy-injected Okta API token for one Okta org. The sandbox sees only a placeholder in OKTA_API_TOKEN; the proxy sends the real token to that org alone.
   kind: mixin
   version: "1.0.0"
   args:
       domain:
           default: "<org>.okta.com"
           description: "Okta org domain, e.g. integrator-1234567.okta.com"
           pattern: '^[A-Za-z0-9][A-Za-z0-9.-]*$'
           env: OKTA_DOMAIN
       service:
           default: "okta"
           description: "Credential service name to bind in sbxenv.yaml"
           pattern: '^[a-z0-9]([a-z0-9-]{0,62}[a-z0-9])?$'
   capabilities:
       - type: com.docker.sandbox/network-policy@1
         config:
           runtime:
               allow:
                   - ${{ kit.args.domain }}
       - type: com.docker.sandbox/credential@1
         description: Okta API token for one org. Stored on the host; the sandbox only sees a placeholder.
         config:
           service: ${{ kit.args.service }}
           phase: runtime
           apiKey:
               name: OKTA_API_TOKEN
               proxyManaged: true
               inject:
                   - domain: ${{ kit.args.domain }}
                     header: Authorization
                     format: SSWS %s
       - type: com.docker.sandbox/agent-context@1
         config:
           content: |
               `OKTA_API_TOKEN` is a proxy-managed placeholder for the Okta org at
               ${{ kit.args.domain }}. The proxy sends the real token, as
               `Authorization: SSWS <token>`, to that domain only. Call the API
               with `-H "Authorization: SSWS $OKTA_API_TOKEN"`; the Okta Terraform
               provider reads `OKTA_API_TOKEN` itself. The org holds synthetic
               users only.
   ```
   Check it with the org's domain:
   ```sh
   sbx kit validate ~/.sbx/kits/okta --kit-arg domain=<org>.okta.com
   ```
5. Declare it in `sbxenv.yaml`: add the kit to `kits:` with the org's domain, and these entries to the existing `secrets:` and `bindings:` blocks. Use the same domain in both places: the kit sends the token there, and the binding approves it. Add them only after step 3, since sbx runs the `command` at create:
   ```yaml
   kits:
     - source: /home/rocket/.sbx/kits/okta
       args:
         domain: <org>.okta.com
   secrets:
     okta:
       command: /usr/bin/pass show okta/agentic-platform | head -n 1
       snapshot: true
   bindings:
     okta:
       apiKey:
         domains:
           - <org>.okta.com
   ```
6. Recreate the sandbox: [remove it](#remove-the-sandbox), then [create it](#create-the-sandbox).
7. Check inside the sandbox, where the kit sets `OKTA_DOMAIN`. It should return the admin user, with `"status":"ACTIVE"`:
   ```sh
   curl -s "https://$OKTA_DOMAIN/api/v1/users/me" -H "Authorization: SSWS $OKTA_API_TOKEN"
   ```

To replace the token: create a new one, replace it with `pass edit okta/agentic-platform`, recreate the sandbox, check as in step 7, then revoke the old token under *Security → API → Tokens*.

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| `pass show` or `sbx env run` hangs | The GPG key is locked and sbx cannot show the passphrase prompt | Run `pass show gitlab/agentic-platform >/dev/null` in a terminal first, then retry |
| `sbx secret ls --sandbox agentic-platform` lists nothing | Secrets are applied only at create | Recreate the sandbox: [remove it](#remove-the-sandbox), then [create it](#create-the-sandbox) |
| Create prints `no binding authorizes gitlab — the credential was not injected` | The `bindings:` block is missing from `sbxenv.yaml` | Add it (see [Set up the GitLab secret](#set-up-the-gitlab-secret)) and recreate the sandbox |
| `glab api user` returns `401 Unauthorized` | The token expired, was revoked, or the sandbox still holds the old snapshot | Check the token on gitlab.com; after replacing it in `pass`, recreate the sandbox |
| `ssh -T git@gitlab.com` shows the wrong account, or `Permission denied` | The host ssh-agent holds a different key, or none | Check with `ssh-add -l` on the host; load the right key with `ssh-add`, remove others with `ssh-add -d` |
| `sbx cp` fails on the sandbox | The sandbox may need to be running | Start it with `sbx env run`, detach, then copy |
| A sandbox does not start: `workspace directory "…" no longer exists on the host` | A file given to `sbx env create` was deleted: sbx mounts every environment file into the sandbox, and needs it at each start | Put the file back, or remove the sandbox |
| Okta API calls return `401` | Okta revoked the token (30 days without use), the sandbox still holds the old snapshot, or the `domain` in `sbxenv.yaml` is not the org's | Check the token under *Security → API → Tokens* and the `domain` in `sbxenv.yaml`; after replacing the token in `pass`, recreate the sandbox |
| The Okta kit fails with `kit arg "domain": value "<org>.okta.com" does not match pattern` | The Okta kit entry in `sbxenv.yaml` sets no `domain` | Add `args.domain` to the entry, as in step 5 of [Set up the Okta secret](#set-up-the-okta-secret) |
