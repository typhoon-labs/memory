package interop

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"net/url"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/contract"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/fixture"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/jose"
)

// Every refusal case proves both halves: the request with one rule broken
// is refused with the exact error and reason, and the allowed twin next to
// it, the same request with nothing broken, is issued. So a case cannot pass
// because the STS refuses everything, or because another check came first.

// twin issues the baseline request: a fresh person token, the first agent,
// its target.
func twin(c *C) {
	resp, _ := c.First(c.Env.Roles.Target)
	c.Issued("allowed twin (the same request with nothing broken)", resp)
}

// refuse sends the baseline request changed by edit to the form, and
// expects reason.
func refuse(c *C, reason string, edit func(url.Values)) {
	r := c.Env.Roles
	subject, _ := c.Person(r.PersonRoute)
	agent := r.Chain[0]
	resp := c.Exchange(Req{Subject: subject, Actor: c.ActorFor(agent).Token, Resources: []string{r.Target}, Agent: agent, Edit: edit})
	c.Refused("refusal", resp, reason)
}

// requestCases derive the malformed-request cases from the contract's
// exchange profile: a required parameter left out, a fixed value changed,
// a forbidden parameter sent, a limited one repeated.
func requestCases(k *contract.Contract) []Case {
	var out []Case
	add := func(id, title, reason string, edit func(*C, url.Values)) {
		out = append(out, Case{ID: "refusals/request/" + id, Group: GroupRefusals, Title: title, Reasons: []string{reason}, Run: func(c *C) {
			refuse(c, reason, func(f url.Values) { edit(c, f) })
			twin(c)
		}})
	}
	for _, p := range k.Exchange.Request.Parameters {
		p := p
		switch p.Presence {
		case contract.PresenceRequired:
			add(p.Name+"-missing", "no "+p.Name, p.Refusal, func(_ *C, f url.Values) {
				f.Del(p.Name)
				f.Del(p.Name + "_type") // a type without its token is malformed too, so take both
			})
			if p.Value != "" {
				add(p.Name+"-wrong", p.Name+" other than "+p.Value, p.Refusal, func(_ *C, f url.Values) { f.Set(p.Name, wrongValue(p)) })
			}
			if p.Max > 0 {
				add(p.Name+"-repeated", "more than "+plural(p.Max, p.Name), p.MaxRefusal, func(c *C, f url.Values) {
					f.Del(p.Name)
					for _, t := range c.Env.Roles.Targets {
						f.Add(p.Name, t)
					}
				})
			}
		case contract.PresenceOptional:
			if p.Value != "" {
				add(p.Name+"-wrong", p.Name+" other than "+p.Value, p.Refusal, func(_ *C, f url.Values) { f.Set(p.Name, wrongValue(p)) })
			}
		case contract.PresenceForbid:
			add(p.Name+"-present", "a "+p.Name+" parameter", p.Refusal, func(c *C, f url.Values) { f.Set(p.Name, c.Env.Roles.Target) })
		}
	}
	return out
}

func wrongValue(p contract.Parameter) string {
	if p.Name == "grant_type" {
		return "client_credentials"
	}
	if p.Value == "urn:ietf:params:oauth:token-type:id_token" {
		return "urn:ietf:params:oauth:token-type:jwt"
	}
	return "urn:ietf:params:oauth:token-type:id_token"
}

// withActor sends the baseline request with another actor token.
func withActor(c *C, reason, actor string) {
	r := c.Env.Roles
	subject, _ := c.Person(r.PersonRoute)
	resp := c.Exchange(Req{Subject: subject, Actor: actor, Resources: []string{r.Target}, Agent: r.Chain[0]})
	c.Refused("refusal", resp, reason)
}

func actorCases() []Case {
	return []Case{
		{ID: "refusals/actor-audience", Group: GroupRefusals, Title: "an actor token for another audience", Reasons: []string{"actor_audience"}, Run: func(c *C) {
			sa := c.Env.ServiceAccount(c.Env.Roles.Chain[0])
			a, err := c.Env.Actors.Token(c, sa, c.Env.Cfg.Roles.ForeignActorAudience)
			if err != nil {
				c.Fatalf("actor token for %s: %v", c.Env.Cfg.Roles.ForeignActorAudience, err)
			}
			withActor(c, "actor_audience", a.Token)
			twin(c)
		}},
		{ID: "refusals/actor-expired", Group: GroupRefusals, Title: "an expired actor token", Reasons: []string{"actor_expired"}, Run: func(c *C) {
			if !c.Env.Actors.Caps().InstantExpiry && !c.Env.Cfg.Slow {
				c.Skipf("needs %s: %s waits for a real token to expire, about 11 minutes", NeedSlow, c.Env.Actors.Name())
			}
			tok, err := c.Env.Actors.Expired(c, c.Env.ServiceAccount(c.Env.Roles.Chain[0]), c.Env.Cfg.STS.Issuer)
			if err != nil {
				c.Fatalf("expired actor token: %v", err)
			}
			withActor(c, "actor_expired", tok)
			twin(c)
		}},
		{ID: "refusals/actor-forged", Group: GroupRefusals, Title: "an actor token TokenReview refuses: forged", Reasons: []string{"actor_rejected"}, Run: func(c *C) {
			good := c.ActorFor(c.Env.Roles.Chain[0])
			forged, err := forge(good.Token)
			if err != nil {
				c.Fatalf("forging: %v", err)
			}
			withActor(c, "actor_rejected", forged)
			twin(c)
		}},
		{ID: "refusals/actor-deleted-pod", Group: GroupRefusals, Title: "an actor token TokenReview refuses: its pod deleted", Needs: []Need{NeedPodDeletion}, Reasons: []string{"actor_rejected"}, Run: func(c *C) {
			r := c.Env.Roles
			agent := r.Chain[0]
			actor, deletePod, err := c.Env.Actors.Bound(c, c.Env.ServiceAccount(agent), c.Env.Cfg.STS.Issuer)
			if err != nil {
				c.Fatalf("pod-bound actor token: %v", err)
			}
			exchange := func() *Response {
				subject, _ := c.Person(r.PersonRoute)
				return c.Exchange(Req{Subject: subject, Actor: actor.Token, Resources: []string{r.Target}, Agent: agent})
			}
			c.MustIssue("allowed twin (the pod still running)", exchange())
			if err := deletePod(c); err != nil {
				c.Fatalf("deleting pod %s: %v", actor.Pod, err)
			}
			deleted := time.Now()
			bound := c.Env.Cfg.Timing.ActorRevocation.Duration
			for {
				resp := exchange()
				if resp.Status != 200 {
					c.Refused("after the pod's deletion", resp, "actor_rejected")
					c.Logf("refused %s after pod %s was deleted", time.Since(deleted).Round(time.Second), actor.Pod)
					return
				}
				if time.Since(deleted) > bound {
					c.Fatalf("still issued %s after pod %s was deleted; the STS must refuse within %s (no TokenReview cache by default, at most 10 seconds with one)", time.Since(deleted).Round(time.Second), actor.Pod, bound)
				}
				c.sleep(c.Env.Cfg.Timing.Poll.Duration)
			}
		}},
		{ID: "refusals/actor-unknown", Group: GroupRefusals, Title: "an actor the policy does not name", Reasons: []string{"actor_unknown"}, Run: func(c *C) {
			c.Require(RoleUnknown)
			a, err := c.Env.Actors.Token(c, c.Env.Roles.Unknown, c.Env.Cfg.STS.Issuer)
			if err != nil {
				c.Fatalf("actor token for %s: %v", c.Env.Roles.Unknown, err)
			}
			withActor(c, "actor_unknown", a.Token)
			twin(c)
		}},
	}
}

// forge re-signs a token's exact bytes with a fresh key of the same type.
func forge(token string) (string, error) {
	t, err := jose.Parse(token)
	if err != nil {
		return "", err
	}
	var key any
	if t.HeaderString("alg") == "ES256" {
		key, err = ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	} else {
		key, err = rsa.GenerateKey(rand.Reader, 2048)
	}
	if err != nil {
		return "", err
	}
	return jose.Resign(token, key)
}

// withSubject sends a subject token by the first agent for its target.
func withSubject(c *C, reason, subject string) {
	r := c.Env.Roles
	agent := r.Chain[0]
	resp := c.Exchange(Req{Subject: subject, Actor: c.ActorFor(agent).Token, Resources: []string{r.Target}, Agent: agent})
	c.Refused("refusal", resp, reason)
}

func subjectCases() []Case {
	signature := func(id, title string, build func(c *C) string) Case {
		return Case{ID: "refusals/subject-signature/" + id, Group: GroupRefusals, Title: "a subject with a bad signature: " + title, Reasons: []string{"subject_signature"}, Run: func(c *C) {
			withSubject(c, "subject_signature", build(c))
			twin(c)
		}}
	}
	trusted := func(c *C) *fixture.Issuer { return c.Env.Fixture.Trusted }
	return []Case{
		signature("tampered", "the payload changed under a valid signature", func(c *C) string {
			tok, claims := c.Person(c.Env.Roles.PersonRoute)
			claims["roles"] = []string{"platform-engineer"}
			out, err := jose.ReplaceClaims(tok, claims)
			if err != nil {
				c.Fatalf("%v", err)
			}
			return out
		}),
		signature("alg-none", "alg none", func(c *C) string {
			_, claims := c.Person(c.Env.Roles.PersonRoute)
			out, _ := jose.Sign(map[string]any{"alg": "none", "typ": "at+jwt", "kid": trusted(c).Kid()}, claims, nil)
			return out
		}),
		signature("hs256-public-key", "HS256 keyed with the issuer's public key", func(c *C) string {
			_, claims := c.Person(c.Env.Roles.PersonRoute)
			der, _ := x509.MarshalPKIXPublicKey(&trusted(c).Key().PublicKey)
			secret := pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: der})
			out, _ := jose.Sign(map[string]any{"alg": "HS256", "typ": "at+jwt", "kid": trusted(c).Kid()}, claims, secret)
			return out
		}),
		{ID: "refusals/subject-signature/forged-chain-token", Group: GroupRefusals, Title: "a subject with a bad signature: a chain token forged under the STS's own kid", Reasons: []string{"subject_signature"}, Run: func(c *C) {
			c.Require(RoleChain)
			r, e := c.Env.Roles, c.Env
			set, _, err := e.STS.FetchJWKS(c)
			if err != nil || len(set.Keys) == 0 {
				c.Fatalf("the STS's JWKS: %v", err)
			}
			k := set.Keys[0]
			alg := "ES256"
			if k.Kty == "RSA" {
				alg = "RS256"
			}
			person, _ := c.Person(r.PersonRoute)
			p, _ := jose.Parse(person)
			now := time.Now().Unix()
			first := e.ActorName(r.Chain[0])
			claims := map[string]any{
				"iss": e.Cfg.STS.Issuer, "sub": p.Claims["sub"], "aud": r.HopRoute[1], "client_id": first,
				"act": map[string]any{"sub": first}, "iat": now, "nbf": now, "exp": now + 300, "jti": jose.RandomID(16),
			}
			for _, name := range e.Policy.CarriedClaims {
				if v, ok := p.Claims[name]; ok {
					claims[name] = v
				}
			}
			var key any
			if alg == "ES256" {
				key, _ = ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
			} else {
				key, _ = rsa.GenerateKey(rand.Reader, 2048)
			}
			forged, err := jose.Sign(map[string]any{"alg": alg, "typ": "at+jwt", "kid": k.Kid}, claims, key)
			if err != nil {
				c.Fatalf("%v", err)
			}
			agent := r.Chain[1]
			resp := c.Exchange(Req{Subject: forged, Actor: c.ActorFor(agent).Token, Resources: []string{r.Final[1]}, Agent: agent})
			c.Refused("refusal", resp, "subject_signature")
			c.Chain(2, false) // the allowed twin: a genuine chain token, exchanged the same way
		}},
		{ID: "refusals/subject-issuer", Group: GroupRefusals, Title: "a subject from an untrusted issuer", Reasons: []string{"subject_issuer"}, Run: func(c *C) {
			tok, _ := c.Env.Fixture.Untrusted.Mint(fixture.Subject{Person: fixture.NewPerson(), Audience: c.Env.Roles.PersonRoute})
			withSubject(c, "subject_issuer", tok)
			twin(c)
		}},
		{ID: "refusals/subject-type/jwt", Group: GroupRefusals, Title: "a subject typed JWT, as an ID token is", Reasons: []string{"subject_type"}, Run: func(c *C) {
			tok, _ := c.Person(c.Env.Roles.PersonRoute, func(s *fixture.Subject) { s.Typ = "JWT" })
			withSubject(c, "subject_type", tok)
			twin(c)
		}},
		{ID: "refusals/subject-type/missing", Group: GroupRefusals, Title: "a subject without typ", Reasons: []string{"subject_type"}, Run: func(c *C) {
			tok, _ := c.Person(c.Env.Roles.PersonRoute, func(s *fixture.Subject) { s.Typ = fixture.NoTyp })
			withSubject(c, "subject_type", tok)
			twin(c)
		}},
		{ID: "refusals/subject-expired", Group: GroupRefusals, Title: "a subject expired beyond the leeway", Reasons: []string{"subject_expired"}, Run: func(c *C) {
			tok, _ := c.Person(c.Env.Roles.PersonRoute, func(s *fixture.Subject) { s.IssuedAt = time.Now().Add(-10 * time.Minute) })
			withSubject(c, "subject_expired", tok)
			twin(c)
		}},
		{ID: "refusals/subject-foreign-act", Group: GroupRefusals, Title: "a subject from Keycloak that carries act", Reasons: []string{"subject_foreign_act"}, Run: func(c *C) {
			tok, _ := c.Person(c.Env.Roles.PersonRoute, func(s *fixture.Subject) {
				s.Act = map[string]any{"sub": c.Env.ActorName(c.Env.Roles.Chain[len(c.Env.Roles.Chain)-1])}
			})
			withSubject(c, "subject_foreign_act", tok)
			twin(c)
		}},
		{ID: "refusals/subject-denied", Group: GroupRefusals, Title: "a subject whose sub is on the deny list", Needs: []Need{NeedDenyList}, Reasons: []string{"subject_denied"}, Run: func(c *C) {
			tok, _ := c.Person(c.Env.Roles.PersonRoute, func(s *fixture.Subject) { s.Sub = c.Env.Cfg.Roles.DeniedSubject })
			withSubject(c, "subject_denied", tok)
			twin(c)
		}},
		{ID: "refusals/subject-audience", Group: GroupRefusals, Title: "a subject for a route that is not the agent's own", Reasons: []string{"subject_audience"}, Run: func(c *C) {
			tok, _ := c.Person(c.Env.Roles.OtherRoute)
			withSubject(c, "subject_audience", tok)
			twin(c)
		}},
	}
}

func chainRefusalCases() []Case {
	return []Case{
		{ID: "refusals/chain-predecessor", Group: GroupRefusals, Title: "an agent whose after does not admit the subject's current actor", Reasons: []string{"chain_predecessor"}, Run: func(c *C) {
			c.Require(RolePredecessor)
			r := c.Env.Roles
			agent := r.Chain[1]
			subject, _ := c.Person(r.HopRoute[1]) // a person's token for the second agent, which admits only the first
			resp := c.Exchange(Req{Subject: subject, Actor: c.ActorFor(agent).Token, Resources: []string{r.Final[1]}, Agent: agent})
			c.Refused("refusal", resp, "chain_predecessor")
			c.Chain(2, false)
		}},
		{ID: "refusals/chain-repeat", Group: GroupRefusals, Title: "an agent already in the chain", Reasons: []string{"chain_repeat"}, Run: func(c *C) {
			c.Require(RoleRepeat)
			r := c.Env.Roles
			hop1 := c.Chain(1, true)[0] // the first agent's token for the second
			second := r.Chain[1]
			back := c.MustIssue("hop 2 (back to the first agent's route)", c.Exchange(Req{Subject: hop1.Raw, Actor: c.ActorFor(second).Token, Resources: []string{r.RepeatRoute}, Agent: second}))
			first := r.Chain[0]
			resp := c.Exchange(Req{Subject: back.Raw, Actor: c.ActorFor(first).Token, Resources: []string{r.Target}, Agent: first})
			c.Refused("hop 3 (the first agent again)", resp, "chain_repeat")
			if len(r.Chain) > 2 {
				c.Chain(3, false) // the allowed twin: a third agent, not yet in the chain, extends it
			}
		}},
		{ID: "refusals/chain-length", Group: GroupRefusals, Title: "a chain that would exceed max_chain", Reasons: []string{"chain_length"}, Run: func(c *C) {
			c.Require(RoleLength)
			r, n := c.Env.Roles, c.Env.Policy.MaxChain
			hops := c.Chain(n, true) // the allowed twin: max_chain agents, the last asking for the next agent's route
			next := r.Chain[n]
			resp := c.Exchange(Req{Subject: hops[n-1].Raw, Actor: c.ActorFor(next).Token, Resources: []string{r.Final[n]}, Agent: next})
			c.Refused(fmt.Sprintf("hop %d (%s)", n+1, next), resp, "chain_length")
		}},
	}
}

func resourceCases() []Case {
	return []Case{
		{ID: "refusals/resource-not-allowed", Group: GroupRefusals, Title: "a resource this agent may not ask for", Reasons: []string{"resource_not_allowed"}, Run: func(c *C) {
			resp, _ := c.First(c.Env.Roles.NotAllowed)
			c.Refused("refusal", resp, "resource_not_allowed")
			twin(c)
		}},
	}
}

// sleep waits, or ends the case if the run is cancelled.
func (c *C) sleep(d time.Duration) {
	select {
	case <-c.Done():
		c.Fatalf("cancelled: %v", c.Err())
	case <-time.After(d):
	}
}
