// Package interop is the delegation STS's black-box interoperability
// suite: the cases of Identity's "Tests a replacement STS must pass", run
// against an STS's token endpoint, metadata and JWKS, with the refusal and
// audit contracts loaded from agent-sdk's spec/.
//
// Cases are values (Cases), so the suite's own tests can run them against
// stand-in servers and assert that each detects wrong behaviour. TestInterop
// runs them against a configured STS; from the repository root:
//
//	go test ./interop -run TestInterop -skip 'TestInterop/(gateway|load)/' -v -timeout 45m -args -interop.config=$PWD/interop/config/local.yaml
//
// interop/local-run.sh builds and starts the STS of this repository first.
//
// The README describes the configuration and which cases need which
// environment.
package interop
