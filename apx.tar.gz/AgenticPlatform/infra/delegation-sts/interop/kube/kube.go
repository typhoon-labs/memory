// Package kube is the handful of Kubernetes API calls the suite makes in a
// cluster, on the standard library: TokenRequest for the fixture service
// accounts' actor tokens, listing and deleting their pods for the
// deleted-pod case, and reading the STS's logs for its audit records.
package kube

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"
)

// In-cluster locations of the pod's own credentials.
const (
	InClusterTokenFile = "/var/run/secrets/kubernetes.io/serviceaccount/token"
	InClusterCAFile    = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
)

// Client calls one API server with a bearer token read from a file, so a
// rotated projected token is picked up.
type Client struct {
	Server    string
	tokenFile string
	http      *http.Client
}

// New returns a client for server. Empty arguments take the in-cluster
// values: the KUBERNETES_SERVICE_HOST and _PORT address, and the pod's
// service-account token and CA.
func New(server, tokenFile, caFile string) (*Client, error) {
	if server == "" {
		host, port := os.Getenv("KUBERNETES_SERVICE_HOST"), os.Getenv("KUBERNETES_SERVICE_PORT")
		if host == "" || port == "" {
			return nil, errors.New("not in a cluster: KUBERNETES_SERVICE_HOST is unset and no API server is configured")
		}
		server = "https://" + net.JoinHostPort(host, port)
	}
	if tokenFile == "" {
		tokenFile = InClusterTokenFile
	}
	if caFile == "" {
		caFile = InClusterCAFile
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.Proxy = nil // the API server is never reached through a proxy
	if pem, err := os.ReadFile(caFile); err == nil {
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("%s holds no PEM certificate", caFile)
		}
		tr.TLSClientConfig = &tls.Config{RootCAs: pool, MinVersion: tls.VersionTLS12}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	return &Client{Server: strings.TrimRight(server, "/"), tokenFile: tokenFile, http: &http.Client{Transport: tr, Timeout: 30 * time.Second}}, nil
}

// Pod is what the suite needs to know about a pod.
type Pod struct {
	Name, UID, ServiceAccount, Phase string
	Deleting                         bool
}

// CreateToken asks the TokenRequest API for a token of namespace/name with
// the audiences and lifetime, bound to pod when it is not empty.
func (c *Client) CreateToken(ctx context.Context, namespace, name string, audiences []string, seconds int64, pod string) (string, time.Time, error) {
	spec := map[string]any{"audiences": audiences, "expirationSeconds": seconds}
	if pod != "" {
		spec["boundObjectRef"] = map[string]any{"kind": "Pod", "apiVersion": "v1", "name": pod}
	}
	body := map[string]any{"apiVersion": "authentication.k8s.io/v1", "kind": "TokenRequest", "spec": spec}
	var out struct {
		Status struct {
			Token               string    `json:"token"`
			ExpirationTimestamp time.Time `json:"expirationTimestamp"`
		} `json:"status"`
	}
	path := fmt.Sprintf("/api/v1/namespaces/%s/serviceaccounts/%s/token", url.PathEscape(namespace), url.PathEscape(name))
	if err := c.do(ctx, "POST", path, body, &out); err != nil {
		return "", time.Time{}, fmt.Errorf("TokenRequest for %s/%s: %w", namespace, name, err)
	}
	return out.Status.Token, out.Status.ExpirationTimestamp, nil
}

// ListPods lists the pods of namespace matching a label selector ("" for all).
func (c *Client) ListPods(ctx context.Context, namespace, selector string) ([]Pod, error) {
	q := url.Values{}
	if selector != "" {
		q.Set("labelSelector", selector)
	}
	var out struct {
		Items []struct {
			Metadata struct {
				Name              string  `json:"name"`
				UID               string  `json:"uid"`
				DeletionTimestamp *string `json:"deletionTimestamp"`
			} `json:"metadata"`
			Spec struct {
				ServiceAccountName string `json:"serviceAccountName"`
			} `json:"spec"`
			Status struct {
				Phase string `json:"phase"`
			} `json:"status"`
		} `json:"items"`
	}
	path := fmt.Sprintf("/api/v1/namespaces/%s/pods?%s", url.PathEscape(namespace), q.Encode())
	if err := c.do(ctx, "GET", path, nil, &out); err != nil {
		return nil, fmt.Errorf("listing pods in %s: %w", namespace, err)
	}
	pods := make([]Pod, 0, len(out.Items))
	for _, it := range out.Items {
		pods = append(pods, Pod{Name: it.Metadata.Name, UID: it.Metadata.UID, ServiceAccount: it.Spec.ServiceAccountName, Phase: it.Status.Phase, Deleting: it.Metadata.DeletionTimestamp != nil})
	}
	return pods, nil
}

// DeletePod deletes a pod at once, without a grace period.
func (c *Client) DeletePod(ctx context.Context, namespace, name string) error {
	path := fmt.Sprintf("/api/v1/namespaces/%s/pods/%s", url.PathEscape(namespace), url.PathEscape(name))
	body := map[string]any{"apiVersion": "v1", "kind": "DeleteOptions", "gracePeriodSeconds": 0}
	if err := c.do(ctx, "DELETE", path, body, nil); err != nil {
		return fmt.Errorf("deleting pod %s/%s: %w", namespace, name, err)
	}
	return nil
}

// PodLogs returns a pod's log since a time.
func (c *Client) PodLogs(ctx context.Context, namespace, name string, since time.Time) ([]byte, error) {
	q := url.Values{"sinceTime": {since.UTC().Format(time.RFC3339)}}
	path := fmt.Sprintf("/api/v1/namespaces/%s/pods/%s/log?%s", url.PathEscape(namespace), url.PathEscape(name), q.Encode())
	req, err := c.request(ctx, "GET", path, nil)
	if err != nil {
		return nil, err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(resp.Body)
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("logs of %s/%s: HTTP %d: %s", namespace, name, resp.StatusCode, snippet(data))
	}
	return data, err
}

func (c *Client) request(ctx context.Context, method, path string, body any) (*http.Request, error) {
	var r io.Reader
	if body != nil {
		raw, err := json.Marshal(body)
		if err != nil {
			return nil, err
		}
		r = bytes.NewReader(raw)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.Server+path, r)
	if err != nil {
		return nil, err
	}
	token, err := os.ReadFile(c.tokenFile)
	if err != nil {
		return nil, fmt.Errorf("reading the API token: %w", err)
	}
	req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(string(token)))
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	return req, nil
}

func (c *Client) do(ctx context.Context, method, path string, body, out any) error {
	req, err := c.request(ctx, method, path, body)
	if err != nil {
		return err
	}
	resp, err := c.http.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	if resp.StatusCode/100 != 2 {
		return fmt.Errorf("HTTP %d: %s", resp.StatusCode, snippet(data))
	}
	if out != nil {
		return json.Unmarshal(data, out)
	}
	return nil
}

func snippet(b []byte) string {
	s := strings.TrimSpace(string(b))
	if len(s) > 300 {
		s = s[:300] + "…"
	}
	return s
}
