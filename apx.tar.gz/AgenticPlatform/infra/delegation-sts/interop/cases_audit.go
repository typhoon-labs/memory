package interop

import (
	"fmt"
	"math"
	"net/http"
	"net/url"
	"slices"
	"sort"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/fixture"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/policy"
)

func loadCases() []Case {
	return []Case{
		{ID: "load/peak", Group: GroupLoad, Title: "p99 latency and error rate at the expected peak", Needs: []Need{NeedLoad}, Run: func(c *C) { runLoad(c, false) }},
		{ID: "load/one-replica-lost", Group: GroupLoad, Title: "p99 latency and error rate at the expected peak, with one replica lost", Needs: []Need{NeedLoad, NeedReplicaLoss}, Run: func(c *C) { runLoad(c, true) }},
	}
}

// runLoad sends valid exchanges at load.rate for load.duration, spread over
// every agent that admits a person so no actor meets its rate limit, from a
// pool of load.subjects people.
func runLoad(c *C, loseReplica bool) {
	e, cfg := c.Env, c.Env.Cfg.Load
	type target struct{ agent, route, resource, actor string }
	var targets []target
	for _, n := range e.Policy.AgentNames() {
		a := e.Policy.Agents[n]
		if n == e.Roles.Burst || !a.Admits(policy.Person) {
			continue
		}
		targets = append(targets, target{n, policy.RouteURL(a.Routes[0], e.Cfg.PlatformDomain), policy.RouteURL(a.Targets[0], e.Cfg.PlatformDomain), c.ActorFor(n).Token})
	}
	if len(targets) == 0 {
		c.Fatalf("no agent of the policy admits a person")
	}
	ceiling := float64(len(targets)*e.Policy.RateLimit.PerSecond*e.Cfg.STS.Replicas) * 0.8
	if cfg.Rate > ceiling {
		c.Fatalf("load.rate %.1f/s exceeds %.1f/s, 80%% of what the rate limit admits for %s on %s; add agents to the policy", cfg.Rate, ceiling, plural(len(targets), "agent"), plural(e.Cfg.STS.Replicas, "replica"))
	}
	people := make([]fixture.Person, cfg.Subjects)
	for i := range people {
		people[i] = fixture.NewPerson()
	}
	total := int(cfg.Rate * cfg.Duration.Seconds())
	interval := time.Duration(float64(time.Second) / cfg.Rate)
	var mu sync.Mutex
	var lat []time.Duration
	failures := map[string]int{}
	var wg sync.WaitGroup
	inflight := make(chan struct{}, 64)
	start := time.Now()
	killAt := start.Add(cfg.Duration.Duration / 3)
	killed := !loseReplica
	for i := 0; i < total; i++ {
		if !killed && time.Now().After(killAt) {
			killed = true
			killOne(c)
		}
		t := targets[i%len(targets)]
		p := people[i%len(people)]
		inflight <- struct{}{}
		wg.Add(1)
		go func() {
			defer wg.Done()
			defer func() { <-inflight }()
			subject, _ := e.Fixture.Trusted.Mint(fixture.Subject{Person: p, Audience: t.route})
			resp := c.exchangeOnce(Req{Subject: subject, Actor: t.actor, Resources: []string{t.resource}, NoRetry: true})
			mu.Lock()
			lat = append(lat, resp.Elapsed)
			if resp.Status != http.StatusOK {
				failures[resp.Summary()]++
			}
			mu.Unlock()
		}()
		time.Sleep(time.Until(start.Add(time.Duration(i+1) * interval)))
	}
	wg.Wait()
	sort.Slice(lat, func(i, j int) bool { return lat[i] < lat[j] })
	p := func(q float64) time.Duration { return lat[int(math.Ceil(q*float64(len(lat))))-1] }
	failed := 0
	for _, n := range failures {
		failed += n
	}
	rate := float64(failed) / float64(len(lat))
	c.Logf("%d exchanges in %s at %.1f/s: p50 %s, p99 %s, max %s, error rate %.4f %v", len(lat), time.Since(start).Round(time.Second), cfg.Rate, p(0.5), p(0.99), lat[len(lat)-1], rate, failures)
	if p(0.99) > cfg.P99.Duration {
		c.Errorf("p99 latency %s exceeds load.p99 %s", p(0.99), cfg.P99.Duration)
	}
	if rate > cfg.MaxErrorRate {
		c.Errorf("error rate %.4f exceeds load.max_error_rate %.4f: %v", rate, cfg.MaxErrorRate, failures)
	}
}

func killOne(c *C) {
	rl := c.Env.Cfg.Load.ReplicaLoss
	pods, err := c.Env.Kube.ListPods(c, rl.Namespace, rl.Selector)
	if err != nil {
		c.Fatalf("listing the STS's pods: %v", err)
	}
	for _, p := range pods {
		if p.Phase == "Running" && !p.Deleting {
			if err := c.Env.Kube.DeletePod(c, rl.Namespace, p.Name); err != nil {
				c.Fatalf("%v", err)
			}
			c.Logf("deleted STS pod %s at %s", p.Name, time.Now().Format(time.RFC3339))
			return
		}
	}
	c.Fatalf("no running STS pod matches %s in %s", rl.Selector, rl.Namespace)
}

func auditCases() []Case {
	return []Case{
		{ID: "audit/issued", Group: GroupAudit, Title: "each issuance produces a record with the audit fields", Needs: []Need{NeedAudit}, Run: func(c *C) {
			e, r := c.Env, c.Env.Roles
			person := fixture.NewPerson()
			subject, sclaims := e.Fixture.Trusted.Mint(fixture.Subject{Person: person, Audience: r.PersonRoute})
			first := r.Chain[0]
			actor := c.ActorFor(first)
			hop1 := c.MustIssue("hop 1", c.Exchange(Req{Subject: subject, Actor: actor.Token, Resources: []string{r.HopRoute[1]}, Agent: first}))
			second := r.Chain[1]
			actor2 := c.ActorFor(second)
			hop2 := c.MustIssue("hop 2", c.Exchange(Req{Subject: hop1.Raw, Actor: actor2.Token, Resources: []string{r.Final[1]}, Agent: second}))
			recs := records(c, hop1.Resp, hop2.Resp)
			for i, h := range []struct {
				is      *Issued
				actor   Actor
				chain   []string
				subject map[string]any
				iss     string
			}{
				{hop1, actor, []string{e.ActorName(first)}, sclaims, e.Fixture.Trusted.URL},
				{hop2, actor2, []string{e.ActorName(second), e.ActorName(first)}, hop1.Claims, e.Cfg.STS.Issuer},
			} {
				rec := recs[h.is.Resp.Trace]
				if rec == nil {
					continue
				}
				what := fmt.Sprintf("hop %d's record", i+1)
				want := map[string]any{
					"event.name": "sts.token.issued", "user.id": person.Sub, "user.team": person.Team, "session.id": person.Sid,
					"actor.sub": h.chain[0], "actor.chain": h.chain,
					"token.jti": h.is.Claims["jti"], "token.aud": h.is.Claims["aud"], "token.exp": h.is.Claims["exp"], "token.kid": h.is.Token.HeaderString("kid"),
					"subject.jti": h.subject["jti"], "subject.iss": h.iss, "request.resource": h.is.Resp.Form["resource"],
				}
				if h.actor.Pod != "" {
					want["actor.pod"] = h.actor.Pod
				}
				if h.is.Resp.Task != "" {
					want["task.id"] = h.is.Resp.Task
				}
				expectFields(c, what, rec, want)
			}
		}},
		{ID: "audit/refused", Group: GroupAudit, Title: "each refusal produces a record with the audit fields, at every stage", Needs: []Need{NeedAudit}, Reasons: []string{"request_malformed", "actor_unknown", "subject_issuer", "chain_predecessor", "resource_not_allowed"}, Run: func(c *C) {
			c.Require(RoleUnknown, RolePredecessor)
			e, r := c.Env, c.Env.Roles
			first, second := r.Chain[0], r.Chain[1]
			type refusal struct {
				stage, reason string
				resp          *Response
				actor         string // expected actor.sub; "" when the actor is not yet known
				user          string // expected user.id; "" when the subject is not yet verified
			}
			var cases []refusal
			send := func(stage, reason, agent string, subject string, claims map[string]any, actor string, resource string, edit func(url.Values)) {
				resp := c.Exchange(Req{Subject: subject, Actor: actor, Resources: []string{resource}, Agent: agent, Edit: func(f url.Values) {
					if edit != nil {
						edit(f)
					}
				}})
				ref := refusal{stage: stage, reason: reason, resp: resp}
				if stage != "request" && stage != "actor" {
					ref.actor = e.ActorName(agent)
				}
				if stage == "chain" || stage == "resource" {
					ref.user, _ = claims["sub"].(string)
				}
				cases = append(cases, ref)
			}
			p1, c1 := c.Person(r.PersonRoute)
			send("request", "request_malformed", first, p1, c1, c.ActorFor(first).Token, r.Target, func(f url.Values) { f["audience"] = []string{r.Target} })
			p2, c2 := c.Person(r.PersonRoute)
			unknown, err := e.Actors.Token(c, r.Unknown, e.Cfg.STS.Issuer)
			if err != nil {
				c.Fatalf("%v", err)
			}
			send("actor", "actor_unknown", first, p2, c2, unknown.Token, r.Target, nil)
			p3, c3 := e.Fixture.Untrusted.Mint(fixture.Subject{Person: fixture.NewPerson(), Audience: r.PersonRoute})
			send("subject", "subject_issuer", first, p3, c3, c.ActorFor(first).Token, r.Target, nil)
			p4, c4 := c.Person(r.HopRoute[1])
			send("chain", "chain_predecessor", second, p4, c4, c.ActorFor(second).Token, r.Final[1], nil)
			p5, c5 := c.Person(r.PersonRoute)
			send("resource", "resource_not_allowed", first, p5, c5, c.ActorFor(first).Token, r.NotAllowed, nil)

			var resps []*Response
			for _, x := range cases {
				if c.Refused(x.stage+" stage", x.resp, x.reason) {
					resps = append(resps, x.resp)
				}
			}
			recs := records(c, resps...)
			for _, x := range cases {
				rec := recs[x.resp.Trace]
				if rec == nil {
					continue
				}
				want := map[string]any{
					"event.name": "sts.token.refused", "refusal.error": x.resp.ErrorCode(), "refusal.reason": x.resp.Reason(),
					"request.resource": x.resp.Form["resource"],
				}
				if x.actor != "" {
					want["actor.sub"] = x.actor
				}
				if x.user != "" {
					want["user.id"] = x.user
					want["actor.chain"] = []string{} // a person's token: no chain yet
				}
				expectFields(c, x.stage+" stage's record", rec, want)
			}
		}},
		{ID: "audit/one-record-per-request", Group: GroupAudit, Title: "every request of the run has exactly one record, matching its response", Needs: []Need{NeedAudit}, Run: func(c *C) {
			own, _ := c.First(c.Env.Roles.Target) // one request of its own, issued or not, so the case means something alone
			var traces []string
			want := map[string]Exchanged{}
			for _, x := range c.Env.Exchanges() {
				if x.Status != 0 {
					traces = append(traces, x.Trace)
					want[x.Trace] = x
				}
			}
			if len(traces) == 0 {
				c.Fatalf("no request of the run got an HTTP response, so no record can be matched: %s", own.Summary())
			}
			by, err := c.Env.recordsFor(c, traces)
			if err != nil {
				c.Fatalf("reading audit records: %v", err)
			}
			var missing, extra, wrong []string
			for _, t := range traces {
				x, recs := want[t], by[t]
				switch {
				case len(recs) == 0:
					missing = append(missing, x.Case)
				case len(recs) > 1:
					extra = append(extra, fmt.Sprintf("%s (%d records)", x.Case, len(recs)))
				default:
					if msg := matches(c, recs[0], x); msg != "" {
						wrong = append(wrong, x.Case+": "+msg)
					}
				}
			}
			c.Logf("%d requests, %d records matched by trace_id", len(traces), len(traces)-len(missing))
			report := func(what string, list []string) {
				if len(list) > 0 {
					c.Errorf("%d of %d requests %s, for example from %v", len(list), len(traces), what, firstN(uniq(list), 5))
				}
			}
			report("have no audit record", missing)
			report("have more than one", extra)
			report("have a record that disagrees with the response or the schema", wrong)
		}},
	}
}

// records waits for the records of the responses and returns each response's
// single, schema-valid record by trace; it fails for any missing.
func records(c *C, resps ...*Response) map[string]map[string]any {
	var traces []string
	for _, r := range resps {
		traces = append(traces, r.Trace)
	}
	by, err := c.Env.recordsFor(c, traces)
	if err != nil {
		c.Fatalf("reading audit records: %v", err)
	}
	out := map[string]map[string]any{}
	for _, t := range traces {
		recs := by[t]
		if len(recs) != 1 {
			c.Errorf("trace %s: want exactly one audit record within %s, found %d", t, c.Env.Cfg.Timing.AuditDelay, len(recs))
			continue
		}
		if err := c.Env.Contract.ValidateAuditRecord(recs[0]); err != nil {
			c.Errorf("trace %s: the record does not match audit/sts-record.schema.json: %v", t, err)
		}
		out[t] = recs[0]
	}
	return out
}

func expectFields(c *C, what string, rec map[string]any, want map[string]any) {
	keys := make([]string, 0, len(want))
	for k := range want {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		got, ok := rec[k]
		if !ok {
			c.Errorf("%s lacks %s (want %s)", what, k, show(want[k]))
		} else if !same(got, want[k]) {
			c.Errorf("%s: %s is %s, want %s", what, k, show(got), show(want[k]))
		}
	}
	if h, _ := rec["sts.policy.hash"].(string); h == "" {
		c.Errorf("%s has no sts.policy.hash", what)
	}
}

// matches says how a record disagrees with its exchange, or "".
func matches(c *C, rec map[string]any, x Exchanged) string {
	if err := c.Env.Contract.ValidateAuditRecord(rec); err != nil {
		return "schema: " + err.Error()
	}
	event, _ := rec["event.name"].(string)
	switch {
	case x.Status == http.StatusOK && event != "sts.token.issued":
		return "issued, but the record says " + event
	case x.Status != http.StatusOK && event != "sts.token.refused":
		return fmt.Sprintf("HTTP %d, but the record says %s", x.Status, event)
	case x.Status != http.StatusOK && rec["refusal.reason"] != x.Reason:
		return fmt.Sprintf("refused %s, but the record says %s", x.Reason, show(rec["refusal.reason"]))
	}
	return ""
}

func uniq(xs []string) []string {
	var out []string
	for _, x := range xs {
		if !slices.Contains(out, x) {
			out = append(out, x)
		}
	}
	return out
}

func firstN(xs []string, n int) []string { return xs[:min(n, len(xs))] }
