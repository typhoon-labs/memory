package interop

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"os"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/kube"
)

// AuditSource reads the STS's audit records. Black-box at the token
// endpoint is not enough for the Audit row: the records go to the STS's
// standard output, so the suite reads them from a file or from the pods' logs.
type AuditSource interface {
	Records(ctx context.Context) ([]map[string]any, error)
}

// fileAudit reads JSON lines from a file, such as a local STS's redirected output.
type fileAudit struct{ path string }

func (f *fileAudit) Records(context.Context) ([]map[string]any, error) {
	raw, err := os.ReadFile(f.path)
	if errors.Is(err, os.ErrNotExist) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return parseRecords(raw), nil
}

// kubeAudit reads the logs of the STS's pods since the run started.
type kubeAudit struct {
	kube                *kube.Client
	namespace, selector string
	since               time.Time
}

func (k *kubeAudit) Records(ctx context.Context) ([]map[string]any, error) {
	pods, err := k.kube.ListPods(ctx, k.namespace, k.selector)
	if err != nil {
		return nil, err
	}
	var out []map[string]any
	for _, p := range pods {
		raw, err := k.kube.PodLogs(ctx, k.namespace, p.Name, k.since)
		if err != nil {
			return nil, err
		}
		out = append(out, parseRecords(raw)...)
	}
	return out, nil
}

// parseRecords keeps the lines that are JSON objects with an sts.token.*
// event name; other output, such as operational logs, is skipped.
func parseRecords(raw []byte) []map[string]any {
	var out []map[string]any
	sc := bufio.NewScanner(bytes.NewReader(raw))
	sc.Buffer(make([]byte, 64*1024), 1<<20)
	for sc.Scan() {
		line := bytes.TrimSpace(sc.Bytes())
		if len(line) == 0 || line[0] != '{' {
			continue
		}
		dec := json.NewDecoder(bytes.NewReader(line))
		dec.UseNumber()
		var m map[string]any
		if dec.Decode(&m) != nil {
			continue
		}
		if name, _ := m["event.name"].(string); strings.HasPrefix(name, "sts.token.") {
			out = append(out, m)
		}
	}
	return out
}

// recordsFor waits until every trace has at least one record, or the
// deadline passes, and returns the records by trace_id.
func (e *Env) recordsFor(ctx context.Context, traces []string) (map[string][]map[string]any, error) {
	deadline := time.Now().Add(e.Cfg.Timing.AuditDelay.Duration)
	for {
		recs, err := e.Audit.Records(ctx)
		if err != nil {
			return nil, err
		}
		by := map[string][]map[string]any{}
		for _, r := range recs {
			if t, _ := r["trace_id"].(string); t != "" {
				by[t] = append(by[t], r)
			}
		}
		complete := true
		for _, t := range traces {
			if len(by[t]) == 0 {
				complete = false
			}
		}
		if complete || time.Now().After(deadline) {
			return by, nil
		}
		select {
		case <-ctx.Done():
			return by, ctx.Err()
		case <-time.After(500 * time.Millisecond):
		}
	}
}
