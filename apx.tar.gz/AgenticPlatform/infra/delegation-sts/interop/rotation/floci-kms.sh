#!/bin/sh
# One step of the STS signing-key rotation in Identity's "Signing keys and
# JWKS", for the interop release's own aliases on floci (or any KMS):
#
#   init     create the first ECC_NIST_P256 key behind <prefix>, if the
#            alias does not exist yet
#   publish  create a new ECC_NIST_P256 key; point <prefix>-next at it
#   switch   point <prefix> at the -next key and <prefix>-previous at the old
#            one; remove -next
#   retire   remove <prefix>-previous; schedule the old key's deletion
#
# Usage: floci-kms.sh init|publish|switch|retire
# Environment: ALIAS_PREFIX (default alias/interop/sts-signing) and the AWS
# CLI's own: AWS_ENDPOINT_URL (http://floci:4566 locally), AWS_REGION and
# credentials. It never touches alias/platform/*.
set -eu
prefix=${ALIAS_PREFIX:-alias/interop/sts-signing}
case $prefix in alias/platform/*) echo "refusing to move $prefix" >&2; exit 2 ;; esac

key_of() { aws kms describe-key --key-id "$1" --query KeyMetadata.KeyId --output text; }
point() { # alias key: create the alias, or move it if it exists
  aws kms update-alias --alias-name "$1" --target-key-id "$2" 2>/dev/null ||
    aws kms create-alias --alias-name "$1" --target-key-id "$2"
}

new_key() {
  aws kms create-key --key-spec ECC_NIST_P256 --key-usage SIGN_VERIFY \
    --description "delegation-sts interop signing key" --query KeyMetadata.KeyId --output text
}

case ${1:-} in
init)
  if old=$(key_of "$prefix" 2>/dev/null); then
    echo "$prefix already names $old"
  else
    new=$(new_key)
    aws kms create-alias --alias-name "$prefix" --target-key-id "$new"
    echo "created $new as $prefix"
  fi
  ;;
publish)
  new=$(new_key)
  point "$prefix-next" "$new"
  echo "published $new as $prefix-next"
  ;;
switch)
  old=$(key_of "$prefix")
  new=$(key_of "$prefix-next")
  point "$prefix-previous" "$old"
  point "$prefix" "$new"
  aws kms delete-alias --alias-name "$prefix-next"
  echo "switched $prefix from $old to $new"
  ;;
retire)
  old=$(key_of "$prefix-previous")
  aws kms delete-alias --alias-name "$prefix-previous"
  aws kms schedule-key-deletion --key-id "$old" --pending-window-in-days 7 >/dev/null
  echo "retired $old"
  ;;
*)
  echo "usage: $0 init|publish|switch|retire" >&2
  exit 2
  ;;
esac
