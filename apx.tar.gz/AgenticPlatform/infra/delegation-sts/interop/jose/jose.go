// Package jose is the small part of JWS and JWK the interoperability suite
// needs, on the standard library alone: parse and verify compact JWS (ES256
// and RS256, the profile's allowlist), sign them, including deliberately
// wrong ones for refusal cases, and handle JWKs and RFC 7638 thumbprints.
package jose

import (
	"bytes"
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/hmac"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"strings"
)

// Allowed is the algorithm allowlist of the interoperability profile (RFC 8725 row).
var Allowed = []string{"ES256", "RS256"}

var b64 = base64.RawURLEncoding

// Token is a parsed compact JWS.
type Token struct {
	Raw          string
	Header       map[string]any // numbers as json.Number
	Claims       map[string]any // numbers as json.Number
	HeaderJSON   []byte
	ClaimsJSON   []byte
	SigningInput string
	Signature    []byte
}

// Parse decodes a compact JWS without verifying it.
func Parse(s string) (*Token, error) {
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("not a JWS compact serialization: expected 3 dot-separated parts, got %d", len(parts))
	}
	t := &Token{Raw: s, SigningInput: parts[0] + "." + parts[1]}
	var err error
	if t.HeaderJSON, err = b64.DecodeString(parts[0]); err != nil {
		return nil, fmt.Errorf("JWS header is not unpadded base64url: %v", err)
	}
	if t.ClaimsJSON, err = b64.DecodeString(parts[1]); err != nil {
		return nil, fmt.Errorf("JWS payload is not unpadded base64url: %v", err)
	}
	if t.Signature, err = b64.DecodeString(parts[2]); err != nil {
		return nil, fmt.Errorf("JWS signature is not unpadded base64url: %v", err)
	}
	if t.Header, err = decodeObject(t.HeaderJSON); err != nil {
		return nil, fmt.Errorf("JWS header is not a JSON object: %v", err)
	}
	if t.Claims, err = decodeObject(t.ClaimsJSON); err != nil {
		return nil, fmt.Errorf("JWS payload is not a JSON object: %v", err)
	}
	return t, nil
}

// HeaderString returns a string header parameter, or "" if absent or not a string.
func (t *Token) HeaderString(name string) string {
	s, _ := t.Header[name].(string)
	return s
}

// Verify checks the signature with key, for the token's alg, which must be
// in Allowed and match the key's type.
func (t *Token) Verify(key crypto.PublicKey) error {
	digest := sha256.Sum256([]byte(t.SigningInput))
	switch alg := t.HeaderString("alg"); alg {
	case "ES256":
		pub, ok := key.(*ecdsa.PublicKey)
		if !ok || pub.Curve != elliptic.P256() {
			return errors.New("alg ES256 but the key is not an EC P-256 key")
		}
		if len(t.Signature) != 64 {
			return fmt.Errorf("ES256 signature must be 64 bytes (R||S), got %d", len(t.Signature))
		}
		r := new(big.Int).SetBytes(t.Signature[:32])
		s := new(big.Int).SetBytes(t.Signature[32:])
		if !ecdsa.Verify(pub, digest[:], r, s) {
			return errors.New("ES256 signature does not verify")
		}
		return nil
	case "RS256":
		pub, ok := key.(*rsa.PublicKey)
		if !ok {
			return errors.New("alg RS256 but the key is not an RSA key")
		}
		if err := rsa.VerifyPKCS1v15(pub, crypto.SHA256, digest[:], t.Signature); err != nil {
			return errors.New("RS256 signature does not verify")
		}
		return nil
	default:
		return fmt.Errorf("alg %q is not in the allowlist %v", alg, Allowed)
	}
}

// Sign encodes header and claims and signs them. The algorithm is the
// header's alg: ES256 with an *ecdsa.PrivateKey, RS256 with an
// *rsa.PrivateKey, HS256 with a []byte secret, or none with a nil key. The
// last two exist only to build tokens a verifier must refuse.
func Sign(header map[string]any, claims any, key any) (string, error) {
	h, err := json.Marshal(header)
	if err != nil {
		return "", err
	}
	c, err := json.Marshal(claims)
	if err != nil {
		return "", err
	}
	input := b64.EncodeToString(h) + "." + b64.EncodeToString(c)
	alg, _ := header["alg"].(string)
	sig, err := signInput(alg, input, key)
	if err != nil {
		return "", err
	}
	return input + "." + b64.EncodeToString(sig), nil
}

func signInput(alg, input string, key any) ([]byte, error) {
	digest := sha256.Sum256([]byte(input))
	switch alg {
	case "ES256":
		k, ok := key.(*ecdsa.PrivateKey)
		if !ok {
			return nil, errors.New("ES256 needs an *ecdsa.PrivateKey")
		}
		r, s, err := ecdsa.Sign(rand.Reader, k, digest[:])
		if err != nil {
			return nil, err
		}
		sig := make([]byte, 64)
		r.FillBytes(sig[:32])
		s.FillBytes(sig[32:])
		return sig, nil
	case "RS256":
		k, ok := key.(*rsa.PrivateKey)
		if !ok {
			return nil, errors.New("RS256 needs an *rsa.PrivateKey")
		}
		return rsa.SignPKCS1v15(rand.Reader, k, crypto.SHA256, digest[:])
	case "HS256":
		secret, ok := key.([]byte)
		if !ok {
			return nil, errors.New("HS256 needs a []byte secret")
		}
		m := hmac.New(sha256.New, secret)
		m.Write([]byte(input))
		return m.Sum(nil), nil
	case "none":
		return nil, nil
	}
	return nil, fmt.Errorf("cannot sign alg %q", alg)
}

// ReplaceClaims returns raw with its payload replaced by claims and its
// signature kept: a token whose signature no longer matches.
func ReplaceClaims(raw string, claims any) (string, error) {
	parts := strings.Split(raw, ".")
	if len(parts) != 3 {
		return "", errors.New("not a compact JWS")
	}
	c, err := json.Marshal(claims)
	if err != nil {
		return "", err
	}
	return parts[0] + "." + b64.EncodeToString(c) + "." + parts[2], nil
}

// Resign returns raw's header and payload, unchanged, signed again with key
// under the same alg: a forgery that names the original kid.
func Resign(raw string, key any) (string, error) {
	t, err := Parse(raw)
	if err != nil {
		return "", err
	}
	sig, err := signInput(t.HeaderString("alg"), t.SigningInput, key)
	if err != nil {
		return "", err
	}
	return t.SigningInput + "." + b64.EncodeToString(sig), nil
}

// JWK is a JSON Web Key, public members plus the private ones a published
// set must never contain.
type JWK struct {
	Kty string `json:"kty"`
	Kid string `json:"kid,omitempty"`
	Use string `json:"use,omitempty"`
	Alg string `json:"alg,omitempty"`
	Crv string `json:"crv,omitempty"`
	X   string `json:"x,omitempty"`
	Y   string `json:"y,omitempty"`
	N   string `json:"n,omitempty"`
	E   string `json:"e,omitempty"`

	D  string `json:"d,omitempty"`
	P  string `json:"p,omitempty"`
	Q  string `json:"q,omitempty"`
	DP string `json:"dp,omitempty"`
	DQ string `json:"dq,omitempty"`
	QI string `json:"qi,omitempty"`
	K  string `json:"k,omitempty"`
}

// JWKS is a JSON Web Key Set.
type JWKS struct {
	Keys []JWK `json:"keys"`
}

// Key returns the key named kid.
func (s JWKS) Key(kid string) (JWK, bool) {
	for _, k := range s.Keys {
		if k.Kid == kid {
			return k, true
		}
	}
	return JWK{}, false
}

// Kids lists the set's key IDs.
func (s JWKS) Kids() []string {
	out := make([]string, 0, len(s.Keys))
	for _, k := range s.Keys {
		out = append(out, k.Kid)
	}
	return out
}

// PrivateMembers names the private-key members present in k.
func (k JWK) PrivateMembers() []string {
	var out []string
	for name, v := range map[string]string{"d": k.D, "p": k.P, "q": k.Q, "dp": k.DP, "dq": k.DQ, "qi": k.QI, "k": k.K} {
		if v != "" {
			out = append(out, name)
		}
	}
	return out
}

// PublicJWK describes pub as a JWK named kid, for alg.
func PublicJWK(pub crypto.PublicKey, kid, alg string) (JWK, error) {
	switch p := pub.(type) {
	case *ecdsa.PublicKey:
		x, y, err := ecPoint(p)
		if err != nil {
			return JWK{}, err
		}
		return JWK{Kty: "EC", Crv: "P-256", X: x, Y: y, Kid: kid, Alg: alg, Use: "sig"}, nil
	case *rsa.PublicKey:
		return JWK{Kty: "RSA", N: b64.EncodeToString(p.N.Bytes()), E: b64.EncodeToString(big.NewInt(int64(p.E)).Bytes()), Kid: kid, Alg: alg, Use: "sig"}, nil
	}
	return JWK{}, fmt.Errorf("unsupported key type %T", pub)
}

// Public returns k's public key.
func (k JWK) Public() (crypto.PublicKey, error) {
	switch k.Kty {
	case "EC":
		if k.Crv != "P-256" {
			return nil, fmt.Errorf("EC key %s: curve %q is not P-256", k.Kid, k.Crv)
		}
		x, err1 := b64.DecodeString(k.X)
		y, err2 := b64.DecodeString(k.Y)
		if err1 != nil || err2 != nil || len(x) != 32 || len(y) != 32 {
			return nil, fmt.Errorf("EC key %s: x and y must be 32-byte base64url values", k.Kid)
		}
		pub, err := ecdsa.ParseUncompressedPublicKey(elliptic.P256(), append(append([]byte{4}, x...), y...))
		if err != nil {
			return nil, fmt.Errorf("EC key %s: %v", k.Kid, err)
		}
		return pub, nil
	case "RSA":
		n, err1 := b64.DecodeString(k.N)
		e, err2 := b64.DecodeString(k.E)
		if err1 != nil || err2 != nil || len(n) == 0 || len(e) == 0 || len(e) > 4 {
			return nil, fmt.Errorf("RSA key %s: n and e must be base64url values", k.Kid)
		}
		return &rsa.PublicKey{N: new(big.Int).SetBytes(n), E: int(new(big.Int).SetBytes(e).Int64())}, nil
	}
	return nil, fmt.Errorf("key %s: unsupported kty %q", k.Kid, k.Kty)
}

// Thumbprint is the RFC 7638 JWK thumbprint of pub (SHA-256, base64url).
func Thumbprint(pub crypto.PublicKey) (string, error) {
	var canonical string
	switch p := pub.(type) {
	case *ecdsa.PublicKey:
		x, y, err := ecPoint(p)
		if err != nil {
			return "", err
		}
		canonical = fmt.Sprintf(`{"crv":"P-256","kty":"EC","x":"%s","y":"%s"}`, x, y)
	case *rsa.PublicKey:
		canonical = fmt.Sprintf(`{"e":"%s","kty":"RSA","n":"%s"}`, b64.EncodeToString(big.NewInt(int64(p.E)).Bytes()), b64.EncodeToString(p.N.Bytes()))
	default:
		return "", fmt.Errorf("unsupported key type %T", pub)
	}
	sum := sha256.Sum256([]byte(canonical))
	return b64.EncodeToString(sum[:]), nil
}

func ecPoint(p *ecdsa.PublicKey) (x, y string, err error) {
	raw, err := p.Bytes()
	if err != nil {
		return "", "", err
	}
	if len(raw) != 65 || raw[0] != 4 {
		return "", "", errors.New("only uncompressed P-256 points are supported")
	}
	return b64.EncodeToString(raw[1:33]), b64.EncodeToString(raw[33:]), nil
}

func decodeObject(raw []byte) (map[string]any, error) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	var m map[string]any
	if err := dec.Decode(&m); err != nil {
		return nil, err
	}
	if m == nil {
		return nil, errors.New("null")
	}
	if dec.More() {
		return nil, errors.New("trailing data")
	}
	return m, nil
}

// RandomID returns n random bytes, base64url-encoded.
func RandomID(n int) string {
	b := make([]byte, n)
	rand.Read(b)
	return b64.EncodeToString(b)
}

// B64 exposes the encoding JWS uses (base64url, no padding).
var B64 = b64
