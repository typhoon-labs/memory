package jose

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"strings"
	"testing"
)

func TestThumbprintRFC7638(t *testing.T) {
	// The example key and thumbprint of RFC 7638, section 3.1.
	k := JWK{Kty: "RSA", E: "AQAB", N: "0vx7agoebGcQSuuPiLJXZptN9nndrQmbXEps2aiAFbWhM78LhWx4cbbfAAtVT86zwu1RK7aPFFxuhDR1L6tSoc_BJECPebWKRXjBZCiFV4n3oknjhMstn64tZ_2W-5JsGY4Hc5n9yBXArwl93lqt7_RN5w6Cf0h4QyQ5v-65YGjQR0_FDW2QvzqY368QQMicAtaSqzs8KJZgnYb9c7d0zgdAZHzu6qMQvRL5hajrn1n91CbOpbISD08qNLyrdkt-bFTWhAI4vMQFh6WeZu0fM4lFd2NcRwr3XPksINHaQ-G_xBniIqbw0Ls1jF44-csFCur-kEgU8awapJzKnqDKgw"}
	pub, err := k.Public()
	if err != nil {
		t.Fatal(err)
	}
	got, err := Thumbprint(pub)
	if err != nil {
		t.Fatal(err)
	}
	if want := "NzbLsXh8uDCcd-6MNwXF4W_7noWXFZAfHkxZsRGC9Xs"; got != want {
		t.Errorf("Thumbprint = %s, want %s", got, want)
	}
}

func TestSignVerify(t *testing.T) {
	ec, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	rk, _ := rsa.GenerateKey(rand.Reader, 2048)
	other, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	claims := map[string]any{"sub": "u1", "n": 1700000000}
	for _, c := range []struct {
		alg  string
		priv any
		pub  any
	}{{"ES256", ec, &ec.PublicKey}, {"RS256", rk, &rk.PublicKey}} {
		t.Run(c.alg, func(t *testing.T) {
			raw, err := Sign(map[string]any{"alg": c.alg, "typ": "at+jwt", "kid": "k1"}, claims, c.priv)
			if err != nil {
				t.Fatal(err)
			}
			tok, err := Parse(raw)
			if err != nil {
				t.Fatal(err)
			}
			if tok.HeaderString("typ") != "at+jwt" || tok.Claims["sub"] != "u1" || tok.Claims["n"].(interface{ String() string }).String() != "1700000000" {
				t.Errorf("round trip lost data: %v %v", tok.Header, tok.Claims)
			}
			if err := tok.Verify(c.pub); err != nil {
				t.Errorf("Verify: %v", err)
			}
			jwk, err := PublicJWK(c.pub, "k1", c.alg)
			if err != nil {
				t.Fatal(err)
			}
			back, err := jwk.Public()
			if err != nil {
				t.Fatal(err)
			}
			if err := tok.Verify(back); err != nil {
				t.Errorf("Verify with the key from its JWK: %v", err)
			}
			if len(jwk.PrivateMembers()) != 0 {
				t.Errorf("public JWK has private members %v", jwk.PrivateMembers())
			}

			tampered, _ := ReplaceClaims(raw, map[string]any{"sub": "u2"})
			if tt, _ := Parse(tampered); tt.Verify(c.pub) == nil {
				t.Error("a token with a replaced payload verifies")
			}
		})
	}
	raw, _ := Sign(map[string]any{"alg": "ES256", "kid": "k1"}, claims, ec)
	forged, err := Resign(raw, other)
	if err != nil {
		t.Fatal(err)
	}
	ft, _ := Parse(forged)
	if ft.Verify(&ec.PublicKey) == nil {
		t.Error("a token re-signed with another key verifies with the original key")
	}
	if ft.Verify(&other.PublicKey) != nil || ft.SigningInput != strings.Join(strings.Split(raw, ".")[:2], ".") {
		t.Error("Resign changed the header or payload, or did not sign with the new key")
	}
	if ft.Verify(&rk.PublicKey) == nil {
		t.Error("an ES256 token verifies with an RSA key")
	}
}

func TestRefusedAlgorithms(t *testing.T) {
	ec, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	none, _ := Sign(map[string]any{"alg": "none"}, map[string]any{"sub": "u"}, nil)
	hs, _ := Sign(map[string]any{"alg": "HS256"}, map[string]any{"sub": "u"}, []byte("secret"))
	for _, raw := range []string{none, hs} {
		tok, err := Parse(raw)
		if err != nil {
			t.Fatal(err)
		}
		if err := tok.Verify(&ec.PublicKey); err == nil || !strings.Contains(err.Error(), "allowlist") {
			t.Errorf("alg %s: Verify = %v, want an allowlist error", tok.HeaderString("alg"), err)
		}
	}
}

func TestParseRefuses(t *testing.T) {
	for _, s := range []string{"not-a-jwt", "a.b", "a.b.c.d", "eyJhbGciOiJFUzI1NiJ9.e30=.", "W10.e30."} {
		if _, err := Parse(s); err == nil {
			t.Errorf("Parse(%q) succeeded", s)
		}
	}
}
