package interop

import (
	"fmt"
	"slices"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/fixture"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/policy"
)

// Roles maps the parts the cases need onto agents of the policy under test.
// Each refusal case must break exactly one rule, so the policy has to admit
// the request next to it; Roles works out those requests once, and records
// why a part cannot be played instead of failing the whole run.
//
// With roles.chain = [A, B, C, D] and max_chain = 3:
//
//   - A admits person; B admits A; C admits B; D admits C, and each agent's
//     route is one of the previous agent's targets (the hops);
//   - B does not admit person (chain_predecessor);
//   - A admits B, and one of A's routes is one of B's targets (chain_repeat);
//   - A, B, C is the longest chain; D after C would exceed it (chain_length).
type Roles struct {
	Chain []string // agent names, hop order

	PersonRoute string   // audience of a person token for Chain[0]
	Target      string   // a target of Chain[0]
	Targets     []string // two targets of Chain[0], or one twice
	HopRoute    []string // HopRoute[i], i ≥ 1: a route of Chain[i] that Chain[i-1] may ask for
	Final       []string // Final[i]: a target of Chain[i]
	RepeatRoute string   // a route of Chain[0] that Chain[1] may ask for
	NotAllowed  string   // a route Chain[0] may not ask for
	OtherRoute  string   // a route that is not one of Chain[0]'s own

	Burst       string
	BurstRoute  string
	BurstTarget string

	Unknown fixture.ServiceAccount

	problems map[string]string
}

// Role names, for Problem.
const (
	RoleChain       = "chain"
	RolePredecessor = "predecessor"
	RoleRepeat      = "repeat"
	RoleLength      = "length"
	RoleBurst       = "burst"
	RoleUnknown     = "unknown actor"
)

func resolveRoles(cfg *Config, p *policy.Policy) *Roles {
	r := &Roles{Chain: cfg.Roles.Chain, problems: map[string]string{}}
	url := func(route string) string { return policy.RouteURL(route, cfg.PlatformDomain) }
	agent := func(n string) (policy.Agent, bool) { a, ok := p.Agents[n]; return a, ok }

	var chainProblems []string
	for _, n := range r.Chain {
		if _, ok := agent(n); !ok {
			chainProblems = append(chainProblems, fmt.Sprintf("roles.chain names %s, which the policy lacks", n))
		}
	}
	if len(r.Chain) < 2 {
		chainProblems = append(chainProblems, "roles.chain needs at least two agents")
	}
	if len(chainProblems) > 0 {
		for _, role := range []string{RoleChain, RolePredecessor, RoleRepeat, RoleLength} {
			r.problems[role] = strings.Join(chainProblems, "; ")
		}
		return r.burst(cfg, p, url)
	}

	a0, _ := agent(r.Chain[0])
	r.PersonRoute = url(a0.Routes[0])
	r.Target = url(a0.Targets[0])
	r.Targets = []string{r.Target, r.Target}
	if len(a0.Targets) > 1 {
		r.Targets[1] = url(a0.Targets[1])
	}
	if !a0.Admits(policy.Person) {
		chainProblems = append(chainProblems, fmt.Sprintf("%s does not admit person", r.Chain[0]))
	}
	r.HopRoute = make([]string, len(r.Chain))
	r.Final = make([]string, len(r.Chain))
	for i, n := range r.Chain {
		a, _ := agent(n)
		r.Final[i] = url(a.Targets[0])
		if i == 0 {
			continue
		}
		prev, _ := agent(r.Chain[i-1])
		if !a.Admits(r.Chain[i-1]) {
			chainProblems = append(chainProblems, fmt.Sprintf("%s does not admit %s", n, r.Chain[i-1]))
		}
		if route, ok := common(a.Routes, prev.Targets); ok {
			r.HopRoute[i] = url(route)
		} else {
			chainProblems = append(chainProblems, fmt.Sprintf("no route of %s is a target of %s", n, r.Chain[i-1]))
		}
	}
	if len(chainProblems) > 0 {
		r.problems[RoleChain] = strings.Join(chainProblems, "; ")
	}

	a1, _ := agent(r.Chain[1])
	if a1.Admits(policy.Person) {
		r.problems[RolePredecessor] = fmt.Sprintf("%s admits person, so a person's token for it is no wrong predecessor", r.Chain[1])
	}
	if route, ok := common(a0.Routes, a1.Targets); !ok || !a0.Admits(r.Chain[1]) || p.MaxChain < 3 {
		r.problems[RoleRepeat] = fmt.Sprintf("needs %s to admit %s, a route of %s among %s's targets, and max_chain of at least 3", r.Chain[0], r.Chain[1], r.Chain[0], r.Chain[1])
	} else {
		r.RepeatRoute = url(route)
	}
	if len(r.Chain) != p.MaxChain+1 {
		r.problems[RoleLength] = fmt.Sprintf("roles.chain has %d agents; the length case needs max_chain+1 = %d", len(r.Chain), p.MaxChain+1)
	}
	if msg, ok := r.problems[RoleChain]; ok {
		for _, role := range []string{RolePredecessor, RoleRepeat, RoleLength} {
			if _, has := r.problems[role]; !has {
				r.problems[role] = msg
			}
		}
	}

	// A route A may not ask for, and one that is not A's own: prefer what
	// the policy names (other agents' targets, then routes), so the STS sees
	// a plausible request; invent one only if the policy has none.
	var targets, routes []string
	for _, n := range p.AgentNames() {
		targets = append(targets, p.Agents[n].Targets...)
		routes = append(routes, p.Agents[n].Routes...)
	}
	pick := func(candidates []string, ok func(string) bool, fallback string) string {
		for _, c := range candidates {
			if ok(c) {
				return url(c)
			}
		}
		return url(fallback)
	}
	r.NotAllowed = pick(slices.Concat(targets, routes), func(c string) bool {
		return strings.HasPrefix(c, "workloads-gateway/") && !slices.Contains(a0.Targets, c)
	}, "workloads-gateway/mcp/interop-not-a-target")
	r.OtherRoute = pick(slices.Concat(routes, targets), func(c string) bool {
		return !slices.Contains(a0.Routes, c)
	}, "workloads-gateway/a2a/interop-not-a-route")
	return r.burst(cfg, p, url)
}

func (r *Roles) burst(cfg *Config, p *policy.Policy, url func(string) string) *Roles {
	r.Burst = cfg.Roles.Burst
	if b, ok := p.Agents[r.Burst]; !ok {
		r.problems[RoleBurst] = fmt.Sprintf("roles.burst names %s, which the policy lacks", r.Burst)
	} else if !b.Admits(policy.Person) {
		r.problems[RoleBurst] = fmt.Sprintf("%s does not admit person", r.Burst)
	} else if slices.Contains(r.Chain, r.Burst) {
		r.problems[RoleBurst] = fmt.Sprintf("%s is also in roles.chain; the rate-limit case would starve the others", r.Burst)
	} else {
		r.BurstRoute, r.BurstTarget = url(b.Routes[0]), url(b.Targets[0])
	}
	sa, err := fixture.ParseServiceAccount(cfg.Roles.UnknownActor)
	if err != nil {
		r.problems[RoleUnknown] = err.Error()
	} else if n, ok := p.AgentByActor(sa.String()); ok {
		r.problems[RoleUnknown] = fmt.Sprintf("roles.unknown_actor %s is agent %s's actor", sa, n)
	}
	r.Unknown = sa
	return r
}

// Problem says why a role cannot be played, or "" if it can.
func (r *Roles) Problem(role string) string { return r.problems[role] }

func common(a, b []string) (string, bool) {
	for _, x := range a {
		if slices.Contains(b, x) {
			return x, true
		}
	}
	return "", false
}
