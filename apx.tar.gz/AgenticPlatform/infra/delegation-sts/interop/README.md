# interop

The delegation STS's black-box interoperability suite: the cases of [Identity: Tests a replacement STS must pass](../../../architecture/design/identity.md#tests-a-replacement-sts-must-pass), run against an STS's token endpoint, metadata and JWKS, with the refusal and audit contracts loaded from `agent-sdk`'s `spec/`. It is written before any STS exists ([B1 in detail](../../../architecture/plan/local-build.md#b1-in-detail), step 6). The WSO2 spike (T15) runs it, and the Go STS is written until it passes.

```text
interop/
├── *.go          # the suite: configuration, runner, cases, sources (package interop)
├── contract/     # the vendored spec/ and its loader
├── fixture/      # the subject issuer, the untrusted issuer, the fake TokenReview API
├── jose/         # JWS and JWK on the standard library
├── kube/         # the Kubernetes API calls made in a cluster
├── standin/      # deliberately wrong STSes, for the suite's own tests
├── config/       # the test policy and example configurations
├── rotation/     # the rotation hook for floci
└── Dockerfile    # the suite's image, for its Job in the cluster
```

## Running it

The suite runs as `TestInterop`, one subtest per case. Without a configuration it skips, so `go test ./...` passes where no STS runs. From the repository root:

```sh
go test ./interop -run TestInterop -skip 'TestInterop/(gateway|load)/' -v -timeout 45m -args -interop.config=$PWD/interop/config/local.yaml
```

`go test` runs in the package's directory, so a relative `-interop.config` resolves from `interop/`; paths inside the configuration resolve from the configuration's own directory. `STS_INTEROP_CONFIG` works in place of the flag. `-run 'TestInterop/refusals/'` selects cases by ID; `-skip` drops cases, matched level by level, so a slash inside parentheses does not start a level. `local.yaml` is strict, so the gateway and load cases, which need a gateway and dev, are skipped with `-skip`; `local-run.sh`, below, starts the STS and runs this command. For the Job, `go test -c ./interop` builds the binary, as `interop/Dockerfile` does. With `strict: true` a skipped case fails the run, which the B1 exit check ("STS interop suite green") needs.

**Without a cluster** (`config/local.yaml`). The suite starts its fixture on `fixture.listen` and prints what the STS under test must be configured with:

- the trusted issuer, where a real release names Keycloak: issuer, JWKS and introspection URLs, under `<public_url>/realms/interop`;
- a kubeconfig for the fixture's fake TokenReview API: `config/kubeconfig-local.yaml`, or one the fixture writes to `fixture.kubeconfig`;
- the test policy, `config/policy.yaml`, and `roles.denied_subject` on its deny list;
- its standard output redirected to `audit.path`, for the audit cases.

The fixture mints the actor tokens and reviews them, so every case runs except those in the table below that need more.

`local-run.sh` does all of this for the STS in this repository. It writes a throwaway CA and certificate under `/tmp/sts-local`, creates the floci key behind `alias/interop/sts-signing` if it is missing, builds and starts the STS with `config/sts-local.yaml`, and runs every case but gateway and load, strictly, with the 16-minute case and the floci rotation; it takes about 20 minutes. `interop/local-run.sh -quick` leaves the long case out, in about 5 minutes; further arguments go to `go test`. The STS's own tests also run the whole suite in process, with a fake KMS and tightened time bounds.

**In the cluster** (`config/cluster.yaml`). The suite runs as a Job in `sts-interop` against an STS release of its own there, as the plan describes: the chart's interop part (`chart/values.yaml`, `interop`) deploys both, and `config/cluster.yaml` names what it deploys. That release runs `config/policy.yaml` and `config/deny-local.yaml`, which the chart links to; serves at `https://delegation-sts.sts-interop.svc.cluster.local`; trusts the suite's fixture, at `http://sts-interop-fixture.sts-interop.svc.cluster.local:8090`, where a real release trusts Keycloak; and signs through `alias/interop/sts-signing*`. Actor tokens come from the TokenRequest API for the fixture service accounts (`interop-a` to `interop-d`, `interop-burst` and `interop-stranger`, each with a running pod), and audit records from the release's pod logs. The Job's service account needs `create` on `serviceaccounts/token` for those accounts, `list` and `delete` on `pods`, and `get` on `pods/log`, in `sts-interop` only; the environment's setup grants them, and TokenReview to the release's own account.

The Job is the release's Helm test, so a deploy never runs it and never moves the interop aliases. `helm test delegation-sts-interop -n sts-releases --timeout 90m` runs it, strictly and slowly, in about 31 minutes, and replaces the previous run's Job, whose log stays until then. Its image, built from `interop/Dockerfile`, holds the suite's test binary, `config/` and `rotation/` on the AWS CLI's image, since the rotation hook calls the AWS CLI. With `strict: true` a skipped case fails the run, so the Job leaves out with `-test.skip` the four cases a cluster cannot run: `gateway/replay-elsewhere` until build phase B2, `load/peak` and `load/one-replica-lost`, which need dev, and `fail-closed/token-review-unavailable`, since a cluster's API server is not the suite's to stop; that one runs without a cluster, against the fixture's fake TokenReview API.

## What each case needs

Every case runs against the STS and the fixture alone unless this table names more. A case whose need is unmet is skipped with a message that names it.

| Need | Cases | Where it is met |
| --- | --- | --- |
| None | Discovery, Issued token, Chains, every Refusals case below not listed here, Revocation, Clock, `fail-closed/rate-limit`, `fail-closed/introspection-unavailable` | Anywhere |
| `review-outage` | `fail-closed/token-review-unavailable` | The fixture's actor source only: a cluster's API server is not the suite's to stop |
| `pod-deletion` | `refusals/actor-deleted-pod` | Both actor sources: the fixture marks the pod deleted, the cluster source deletes a real pod |
| `slow` | `refusals/actor-expired` with the cluster source, which waits about 11 minutes for a real token to expire; `fail-closed/jwks-past-last-good`, which waits 16 | `slow: true` |
| `deny-list` | `refusals/subject-denied` | `roles.denied_subject` on the STS's deny list |
| `audit-source` | Audit | `audit.source`: a file locally, the pods' logs in a cluster |
| `kms-rotation` | `rotation/overlap-and-removal` | `rotation.*` commands; for floci, `rotation/floci-kms.sh`, which moves `alias/interop/sts-signing*` and refuses `alias/platform/*` |
| `gateway` | `gateway/replay-elsewhere` | `gateway.routes`, from build phase B2 |
| `load`, `replica-loss` | `load/peak`, `load/one-replica-lost` | `load.*`: the peak and objective the design leaves to dev; replica loss needs two or more replicas, so dev only |

Two rows reach past the token endpoint, metadata and JWKS that the design names: Audit reads the STS's standard output, and Gateway calls the gateway.

**Cases by row.** Each refusal case proves both halves: the request with one rule broken gets the exact `error` and `reason`, and its allowed twin, the same request with nothing broken, is issued.

| Row | Cases |
| --- | --- |
| Discovery | `discovery/metadata`, `issuer`, `jwks` (no private members, allowlisted algorithms), `token-exchange-grant`, `token-endpoint` |
| Issued token | `issued/response` (token types, `Cache-Control: no-store`), `header`, `claims` (against the spec's schema), `issuer`, `audience`, `subject-and-carried-claims`, `actor`, `unique-jti`, `lifetime` |
| Chains | `chains/second-hop`, `chains/full-length`; the order and length rules are the chain refusals |
| Refusals | `refusals/request/*`, generated from the spec's exchange profile (each parameter missing, wrong or forbidden, `resource` twice); `actor-audience`, `actor-expired`, `actor-forged`, `actor-deleted-pod`, `actor-unknown`; `subject-signature/` `tampered`, `alg-none`, `hs256-public-key`, `forged-chain-token`; `subject-issuer`, `subject-type/*`, `subject-expired`, `subject-foreign-act`, `subject-denied`, `subject-audience`; `chain-predecessor`, `chain-repeat`, `chain-length`; `resource-not-allowed` |
| Revocation | `revocation/inactive-subject`; `logout` and `user-disabled`, refused within `timing.revocation` (the 30-second introspection cache plus margin) |
| Rotation | `rotation/overlap-and-removal` |
| Clock | `clock/nbf-30s-ahead-accepted`, `clock/nbf-120s-ahead-refused` |
| Gateway | `gateway/replay-elsewhere` |
| Load | `load/peak`, `load/one-replica-lost` |
| Audit | `audit/issued`, `audit/refused` (one refusal per stage), `audit/one-record-per-request` (every request of the run) |
| Fail closed | `rate-limit`, `introspection-unavailable`, `token-review-unavailable`, `jwks-past-last-good`: the refusal table's last two rows, which the test table does not list |

## The contract

`contract/spec/` is a copy of the JSON files of `agent-sdk`'s `spec/` at the tag and commit `contract/SOURCE` names, `spec/v0.1.0` today, embedded in the suite's binary. The copy is vendored, not read from a path, because the Job has no checkout of `agent-sdk` beside it, and the plan pins the spec by tag. `contract/vendor.sh [AGENT_SDK_DIR] [REV]` refreshes it; vendor tags, not branches. A test compares the copy with `agent-sdk` at the pinned commit when a clone sits beside this repository in the workspace, or at `AGENT_SDK_DIR`. To check an `agent-sdk` change before committing it, from this repository's root:

```sh
STS_INTEROP_SPEC_DIR=$PWD/../../devkit/agent-sdk/spec go test ./interop/contract -run TestWorkingCopy -v
```

## Choices where the design is open

- **Which reason wins when one failure implies another.** A token from an untrusted issuer also fails signature checks against the trusted keys; an expired subject is also inactive at introspection; an expired or other-audience actor token also fails TokenReview. The suite expects the more specific reason: `subject_issuer`, `subject_expired`, `actor_expired`, `actor_audience`.
- **Bad signatures.** `alg: none` and HS256 keyed with the issuer's public key count as `subject_signature`, and every forgery names a `kid` the issuer publishes, so no case spends the STS's once-per-30-seconds JWKS refetch.
- **The actor token's type** is `urn:ietf:params:oauth:token-type:jwt`, fixed in the spec's exchange profile.
- **Matching audit records** uses `trace_id`: every request carries a fresh W3C `traceparent`, and its record must carry that trace ID. `task.id` is checked only when `task_header` names the agent's task header, which the design does not name.
- **Pacing.** The suite paces each agent's exchanges to 80% of the policy's rate limit, so only the rate-limit case meets a 429; a 429 elsewhere is waited out and logged.

## The suite's own tests

`standin_test.go` runs every case against the stand-ins in `standin/` and checks each verdict and its message: an STS that refuses everything, one that returns a token that is not a JWS, one that issues well-formed tokens for every request (with faults that break one property at a time), and one with broken discovery. Every case fails against at least one of them, the rotation, load and gateway cases in runs of their own, except `load/one-replica-lost` and `fail-closed/jwks-past-last-good`, which need a Kubernetes API or 16 minutes and are not run there. A scripted stand-in, which gives each case's expected refusal before it issues, shows that one case of each shape passes on the right answers. No stand-in is an STS, so these tests show that the cases detect wrong behaviour, not that a correct STS passes; the Go STS and T15 show that.

`suite_test.go` checks that every reason in the contract is asserted by some case, that every row of the design's table has one, and that the shipped configurations can play every role. `kube_sources_test.go` checks the cluster sources' API calls against a fake API server; the Job runs them against a real one.
