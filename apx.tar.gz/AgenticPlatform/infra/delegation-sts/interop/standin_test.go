package interop

import (
	"context"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"slices"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/jose"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/standin"
)

// The suite's own tests: run its cases against stand-ins that are wrong in
// known ways, and check each case reaches the right verdict for the right
// reason. No stand-in is an STS, so none can show that the suite passes a
// correct one; that is the job of the Go STS and of the WSO2 spike (T15).

const deniedSubject = "00000000-0000-4000-8000-00000000dead"

func standinEnv(t *testing.T, mode standin.Mode, faults standin.Faults, script ...standin.Step) *Env {
	t.Helper()
	audit := filepath.Join(t.TempDir(), "audit.jsonl")
	cfg := &Config{PlatformDomain: "agentic.internal", Cluster: "agentic-local", PolicyFile: "config/policy.yaml"}
	cfg.Roles.DeniedSubject = deniedSubject
	cfg.Fixture.Listen = "127.0.0.1:0"
	cfg.Audit.Source, cfg.Audit.Path = "file", audit
	cfg.Rotation.AliasRefresh.Duration, cfg.Rotation.Margin.Duration = time.Second, time.Second
	cfg.Timing.Revocation.Duration = time.Second
	cfg.Timing.ActorRevocation.Duration = time.Second
	cfg.Timing.AuditDelay.Duration = 300 * time.Millisecond
	cfg.Timing.Poll.Duration = 100 * time.Millisecond
	s := standin.Start(mode, standin.Options{Cluster: cfg.Cluster, TTL: 300, AuditPath: audit, Faults: faults, Script: script,
		Carried: []string{"idp_sub", "roles", "team", "sid", "preferred_username", "acr", "auth_time"}})
	t.Cleanup(s.Close)
	cfg.STS.Issuer, cfg.STS.TokenEndpoint = s.URL, s.URL+"/token"
	if err := cfg.Complete(); err != nil {
		t.Fatal(err)
	}
	opts := Options{STSClient: s.Client(), Unpaced: true}
	if mode == standin.Permissive {
		opts.Rotator = s
	}
	env, err := NewEnv(context.Background(), cfg, opts)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(env.Close)
	return env
}

// expectation is a case's verdict against a stand-in, and words its
// message must contain.
type expectation struct {
	status Status
	says   string
}

// expected gives each case's verdict per stand-in: by exact ID, then by
// prefix, then the mode's default.
var expected = map[standin.Mode]struct {
	byID     map[string]expectation
	byPrefix map[string]expectation
	others   expectation
}{
	standin.RefuseAll: {
		byID: map[string]expectation{
			"fail-closed/rate-limit":            {Fail, "none of"},
			"audit/one-record-per-request":      {Pass, ""},
			"refusals/request/audience-present": {Fail, "allowed twin (the same request with nothing broken): expected the exchange to be issued, got HTTP 400 invalid_request/request_malformed"},
			"refusals/actor-unknown":            {Fail, "expected HTTP 400 invalid_request/actor_unknown (Actor not in the policy), got HTTP 400 invalid_request/request_malformed: another check refused first"},
		},
		byPrefix: map[string]expectation{
			"discovery/": {Pass, ""},
			"issued/":    {Fail, "expected the exchange to be issued, got HTTP 400 invalid_request/request_malformed"},
			"chains/":    {Fail, "expected the exchange to be issued"},
		},
		others: expectation{Fail, "request_malformed"},
	},
	standin.MalformedToken: {
		byID: map[string]expectation{
			"fail-closed/rate-limit":       {Fail, "no 429"},
			"audit/one-record-per-request": {Fail, "have no audit record"},
			"audit/issued":                 {Fail, "the access_token is not a JWS"},
			"refusals/actor-deleted-pod":   {Fail, "the access_token is not a JWS"},
			"revocation/logout":            {Fail, "the access_token is not a JWS"},
			"revocation/user-disabled":     {Fail, "the access_token is not a JWS"},
			"refusals/chain-repeat":        {Fail, "hop 1 (interop-a for https://workloads-gateway.agentic.internal/a2a/interop-b): the access_token is not a JWS"},
			"refusals/chain-length":        {Fail, "the access_token is not a JWS"},
		},
		byPrefix: map[string]expectation{
			"discovery/":    {Pass, ""},
			"issued/":       {Fail, "the access_token is not a JWS: not a JWS compact serialization"},
			"chains/":       {Fail, "the access_token is not a JWS"},
			"clock/nbf-30s": {Fail, "the access_token is not a JWS"},
		},
		others: expectation{Fail, "got HTTP 200 with a token: the STS issued where it must refuse"},
	},
	standin.Permissive: {
		byID: map[string]expectation{
			"fail-closed/rate-limit": {Fail, "no 429"},
			// It writes an "issued" record even for a request with no subject, which the schema refuses.
			"audit/one-record-per-request": {Fail, "have a record that disagrees with the response or the schema"},
			"audit/issued":                 {Pass, ""},
			"clock/nbf-30s-ahead-accepted": {Pass, ""},
			"rotation/overlap-and-removal": {Pass, ""},
			"refusals/actor-deleted-pod":   {Fail, "still issued"},
			"revocation/logout":            {Fail, "still issued"},
			"revocation/user-disabled":     {Fail, "still issued"},
		},
		byPrefix: map[string]expectation{
			"discovery/": {Pass, ""},
			"issued/":    {Pass, ""},
			"chains/":    {Pass, ""},
		},
		others: expectation{Fail, "got HTTP 200 with a token: the STS issued where it must refuse"},
	},
	standin.BrokenDiscovery: {
		byID: map[string]expectation{
			"discovery/metadata":             {Fail, "the metadata lacks token_endpoint"},
			"discovery/issuer":               {Fail, "want exactly"},
			"discovery/jwks":                 {Fail, "publishes private-key members [d]"},
			"discovery/token-exchange-grant": {Fail, "it must include urn:ietf:params:oauth:grant-type:token-exchange"},
			"discovery/token-endpoint":       {Fail, "the metadata has no token_endpoint"},
			"fail-closed/rate-limit":         {Fail, "none of"},
			"audit/one-record-per-request":   {Pass, ""},
		},
		others: expectation{Fail, "request_malformed"},
	},
}

// skippedEverywhere are the cases no stand-in run meets the needs of.
var skippedEverywhere = []string{"gateway/replay-elsewhere", "load/peak", "load/one-replica-lost", "fail-closed/jwks-past-last-good"}

func (x expectation) String() string { return string(x.status) + " saying " + x.says }

func expectFor(mode standin.Mode, k Case) expectation {
	e := expected[mode]
	if slices.Contains(skippedEverywhere, k.ID) || (k.ID == "rotation/overlap-and-removal" && mode != standin.Permissive) {
		return expectation{Skip, "needs"}
	}
	if x, ok := e.byID[k.ID]; ok {
		return x
	}
	for p, x := range e.byPrefix {
		if strings.HasPrefix(k.ID, p) {
			return x
		}
	}
	return e.others
}

func TestStandins(t *testing.T) {
	if testing.Short() {
		t.Skip("runs the whole suite four times")
	}
	failedSomewhere := map[string]bool{}
	for _, mode := range []standin.Mode{standin.RefuseAll, standin.MalformedToken, standin.Permissive, standin.BrokenDiscovery} {
		t.Run(string(mode), func(t *testing.T) {
			env := standinEnv(t, mode, standin.Faults{})
			for _, k := range Cases() {
				r := env.Run(context.Background(), k)
				want := expectFor(mode, k)
				if r.Status == Fail {
					failedSomewhere[k.ID] = true
				}
				if r.Status != want.status || !strings.Contains(r.Message, want.says) {
					t.Errorf("%s: got %s:\n%s\nwant %s", k.ID, r.Status, indent(r.Message), want)
				}
			}
		})
	}
	t.Run("every runnable case fails against some stand-in", func(t *testing.T) {
		for _, k := range Cases() {
			if !slices.Contains(skippedEverywhere, k.ID) && !failedSomewhere[k.ID] && k.ID != "rotation/overlap-and-removal" {
				t.Errorf("%s fails against no stand-in: nothing shows it can detect wrong behaviour", k.ID)
			}
		}
	})
}

// TestFaults breaks one property of an otherwise well-formed issuance at a
// time, and checks the case for that property catches it.
func TestFaults(t *testing.T) {
	for _, f := range []struct {
		name   string
		faults standin.Faults
		cases  map[string]string // case → words its failure must contain
	}{
		{"claims passed through", standin.Faults{CopyAllClaims: true}, map[string]string{
			"issued/subject-and-carried-claims": "only sub and the policy's carried claims may pass",
			"issued/claims":                     "additional properties",
		}},
		{"TTL ignored", standin.Faults{IgnoreTTL: true}, map[string]string{
			"issued/lifetime": "at most the policy's token_ttl_seconds (300)",
		}},
		{"aud as a list", standin.Faults{AudList: true}, map[string]string{
			"issued/audience": "as a single string",
		}},
		{"typ JWT", standin.Faults{TypJWT: true}, map[string]string{
			"issued/header": "claims/chain-token-header.schema.json",
		}},
		{"jti reused", standin.Faults{ReuseJTI: true}, map[string]string{
			"issued/unique-jti": "got the same jti",
		}},
		{"chain replaced, not nested", standin.Faults{FlatAct: true}, map[string]string{
			"chains/second-hop":  "newest outermost",
			"chains/full-length": "act names",
		}},
		{"no Cache-Control", standin.Faults{NoCacheControl: true}, map[string]string{
			"issued/response": "no-store",
		}},
		{"wrong client_id", standin.Faults{WrongClientID: true}, map[string]string{
			"issued/actor":      "client_id is \"interop-standin\"",
			"chains/second-hop": "client_id",
		}},
		{"new key signs on publish", standin.Faults{SignOnPublish: true}, map[string]string{
			"rotation/overlap-and-removal": "must not sign before the switch",
		}},
		{"old key dropped at the switch", standin.Faults{DropOldOnSwitch: true}, map[string]string{
			"rotation/overlap-and-removal": "during the overlap the old key",
		}},
		{"audit record without token.kid", standin.Faults{AuditDropField: "token.kid"}, map[string]string{
			"audit/issued": "lacks token.kid",
		}},
		{"audit record without the trace", standin.Faults{AuditDropField: "trace_id"}, map[string]string{
			"audit/issued":                 "want exactly one audit record",
			"audit/one-record-per-request": "have no audit record",
		}},
		{"two audit records per request", standin.Faults{AuditTwice: true}, map[string]string{
			"audit/one-record-per-request": "have more than one",
		}},
	} {
		t.Run(f.name, func(t *testing.T) {
			env := standinEnv(t, standin.Permissive, f.faults)
			for _, k := range Cases() {
				says, ok := f.cases[k.ID]
				if !ok {
					continue
				}
				r := env.Run(context.Background(), k)
				if r.Status != Fail || !strings.Contains(r.Message, says) {
					t.Errorf("%s: got %s:\n%s\nwant a failure saying %q", k.ID, r.Status, indent(r.Message), says)
				}
			}
		})
	}
}

// TestLoadAndGateway runs the two cases no stand-in run configures: load
// against Permissive, and the gateway replay against a fake gateway that
// checks audiences and one that does not.
func TestLoadAndGateway(t *testing.T) {
	ctx := context.Background()
	env := standinEnv(t, standin.Permissive, standin.Faults{})
	load := env.Cfg.Load
	env.Cfg.Load.Rate, env.Cfg.Load.Duration.Duration, env.Cfg.Load.P99.Duration, env.Cfg.Load.Subjects = 6, 2*time.Second, 2*time.Second, 5
	if r := env.Run(ctx, caseByID(t, "load/peak")); r.Status != Pass {
		t.Errorf("load/peak against Permissive: %s\n%s", r.Status, indent(r.Message))
	}
	env.Cfg.Load.P99.Duration = time.Nanosecond
	if r := env.Run(ctx, caseByID(t, "load/peak")); r.Status != Fail || !strings.Contains(r.Message, "p99 latency") {
		t.Errorf("load/peak with an impossible p99: %s\n%s", r.Status, indent(r.Message))
	}
	env.Cfg.Load = load

	gateway := func(checks bool) string {
		srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			tok, err := jose.Parse(strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer "))
			if checks && (err != nil || tok.Claims["aud"] != "https://workloads-gateway.agentic.internal"+r.URL.Path) {
				w.WriteHeader(http.StatusUnauthorized)
				return
			}
			w.WriteHeader(http.StatusOK)
		}))
		t.Cleanup(srv.Close)
		return srv.URL
	}
	for _, g := range []struct {
		checks bool
		status Status
		says   string
	}{{true, Pass, ""}, {false, Fail, "want 401"}} {
		u := gateway(g.checks)
		env.Cfg.Gateway.Routes = map[string]string{
			"workloads-gateway/mcp/interop-mcp": u + "/mcp/interop-mcp",
			"workloads-gateway/a2a/interop-c":   u + "/a2a/interop-c",
		}
		if r := env.Run(ctx, caseByID(t, "gateway/replay-elsewhere")); r.Status != g.status || !strings.Contains(r.Message, g.says) {
			t.Errorf("gateway/replay-elsewhere, gateway checking audiences %v: %s\n%s", g.checks, r.Status, indent(r.Message))
		}
	}
}

// TestScripted shows that refusal-shaped cases can pass: Permissive,
// scripted to answer each case's expected refusal before it issues, passes
// one case of each shape. A script is no STS; it only shows the cases accept
// the right answers.
func TestScripted(t *testing.T) {
	refuse := func(status int, err, reason string) standin.Step {
		return standin.Step{Status: status, Error: err, Reason: reason}
	}
	issue := standin.Step{Status: 200}
	for _, s := range []struct {
		id     string
		script []standin.Step
	}{
		{"refusals/request/audience-present", []standin.Step{refuse(400, "invalid_request", "request_malformed")}},
		{"refusals/actor-unknown", []standin.Step{refuse(400, "invalid_request", "actor_unknown")}},
		{"refusals/resource-not-allowed", []standin.Step{refuse(400, "invalid_target", "resource_not_allowed")}},
		{"refusals/chain-repeat", []standin.Step{issue, issue, refuse(400, "invalid_request", "chain_repeat")}},
		{"clock/nbf-120s-ahead-refused", []standin.Step{refuse(400, "invalid_request", "subject_not_yet_valid")}},
		{"revocation/logout", []standin.Step{issue, issue, refuse(400, "invalid_request", "subject_inactive"), refuse(400, "invalid_request", "subject_inactive")}},
		{"fail-closed/introspection-unavailable", []standin.Step{refuse(503, "temporarily_unavailable", "dependency_unavailable")}},
		{"fail-closed/rate-limit", []standin.Step{{Status: 200, Count: 10}, {Status: 429, Error: "temporarily_unavailable", Reason: "rate_limited", RetryAfter: "1", Count: 70}}},
		{"audit/refused", []standin.Step{
			refuse(400, "invalid_request", "request_malformed"), refuse(400, "invalid_request", "actor_unknown"),
			refuse(400, "invalid_request", "subject_issuer"), refuse(400, "invalid_request", "chain_predecessor"),
			refuse(400, "invalid_target", "resource_not_allowed"),
		}},
	} {
		t.Run(s.id, func(t *testing.T) {
			env := standinEnv(t, standin.Permissive, standin.Faults{}, s.script...)
			if r := env.Run(context.Background(), caseByID(t, s.id)); r.Status != Pass {
				t.Errorf("%s scripted to answer as it expects: %s\n%s", s.id, r.Status, indent(r.Message))
			}
		})
	}
}
