package interop

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strings"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/contract"
)

// Groups: the rows of Identity's "Tests a replacement STS must pass", plus
// the refusal table's fail-closed rows, which that table does not list.
const (
	GroupDiscovery  = "Discovery"
	GroupIssued     = "Issued token"
	GroupChains     = "Chains"
	GroupRefusals   = "Refusals"
	GroupRevocation = "Revocation"
	GroupRotation   = "Rotation"
	GroupClock      = "Clock"
	GroupGateway    = "Gateway"
	GroupLoad       = "Load"
	GroupAudit      = "Audit"
	GroupFailClosed = "Fail closed"
)

// Cases returns every case, in the order they run: the quick ones first,
// then those that move keys, load the STS or wait, and the audit sweep last,
// so it covers every exchange the run made.
func Cases() []Case {
	k, err := contract.Load()
	if err != nil {
		panic(err) // the contract package's tests catch this first
	}
	var all []Case
	all = append(all, discoveryCases()...)
	all = append(all, issuedCases()...)
	all = append(all, chainCases()...)
	all = append(all, requestCases(k)...)
	all = append(all, actorCases()...)
	all = append(all, subjectCases()...)
	all = append(all, chainRefusalCases()...)
	all = append(all, resourceCases()...)
	all = append(all, revocationCases()...)
	all = append(all, clockCases()...)
	all = append(all, failClosedCases()...)
	all = append(all, gatewayCases()...)
	all = append(all, rotationCases()...)
	all = append(all, loadCases()...)
	all = append(all, slowCases()...)
	all = append(all, auditCases()...)
	return all
}

// fixedClaims are the chain token's claims besides the carried ones.
var fixedClaims = []string{"iss", "sub", "aud", "client_id", "act", "iat", "nbf", "exp", "jti"}

func num(v any) (int64, bool) {
	switch n := v.(type) {
	case json.Number:
		i, err := n.Int64()
		if err != nil {
			f, ferr := n.Float64()
			return int64(f), ferr == nil
		}
		return i, true
	case float64:
		return int64(n), true
	case int64:
		return n, true
	case int:
		return int64(n), true
	}
	return 0, false
}

// same compares two decoded JSON values, numbers by value.
func same(a, b any) bool {
	if x, ok := num(a); ok {
		y, ok := num(b)
		return ok && x == y
	}
	ra, _ := json.Marshal(a)
	rb, _ := json.Marshal(b)
	var na, nb any
	json.Unmarshal(ra, &na)
	json.Unmarshal(rb, &nb)
	return reflect.DeepEqual(na, nb)
}

// actChain lists the act.sub values of claims, outermost (newest) first.
func actChain(claims map[string]any) ([]string, error) {
	var out []string
	cur, ok := claims["act"]
	for depth := 0; ok && cur != nil; depth++ {
		m, isMap := cur.(map[string]any)
		if !isMap {
			return out, fmt.Errorf("act at depth %d is not an object: %v", depth+1, cur)
		}
		sub, _ := m["sub"].(string)
		if sub == "" {
			return out, fmt.Errorf("act at depth %d has no sub", depth+1)
		}
		out = append(out, sub)
		cur, ok = m["act"]
	}
	return out, nil
}

func show(v any) string {
	raw, _ := json.Marshal(v)
	return string(raw)
}

func plural(n int, word string) string {
	if n == 1 {
		return fmt.Sprintf("1 %s", word)
	}
	return fmt.Sprintf("%d %ss", n, word)
}

func joinOr(xs []string, empty string) string {
	if len(xs) == 0 {
		return empty
	}
	return strings.Join(xs, ", ")
}
