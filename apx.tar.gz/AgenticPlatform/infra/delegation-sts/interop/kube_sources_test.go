package interop

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/fixture"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/kube"
)

// fakeAPI answers the Kubernetes API calls the cluster sources make, and
// records them, so the request shapes are checked without a cluster.
type fakeAPI struct {
	mu       sync.Mutex
	requests []map[string]any
	deleted  []string
	since    string
}

func (f *fakeAPI) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Header.Get("Authorization") != "Bearer suite-token" {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	var body map[string]any
	json.NewDecoder(r.Body).Decode(&body)
	f.mu.Lock()
	defer f.mu.Unlock()
	switch {
	case r.Method == "POST" && strings.HasSuffix(r.URL.Path, "/token"):
		f.requests = append(f.requests, body)
		json.NewEncoder(w).Encode(map[string]any{"status": map[string]any{"token": "tok-" + r.URL.Path, "expirationTimestamp": time.Now().Add(10 * time.Minute).UTC().Format(time.RFC3339)}})
	case r.Method == "GET" && strings.HasSuffix(r.URL.Path, "/pods"):
		json.NewEncoder(w).Encode(map[string]any{"items": []any{
			map[string]any{"metadata": map[string]any{"name": "other", "uid": "1"}, "spec": map[string]any{"serviceAccountName": "interop-b"}, "status": map[string]any{"phase": "Running"}},
			map[string]any{"metadata": map[string]any{"name": "going", "uid": "2", "deletionTimestamp": "2026-11-16T00:00:00Z"}, "spec": map[string]any{"serviceAccountName": "interop-a"}, "status": map[string]any{"phase": "Running"}},
			map[string]any{"metadata": map[string]any{"name": "interop-a-1", "uid": "3"}, "spec": map[string]any{"serviceAccountName": "interop-a"}, "status": map[string]any{"phase": "Running"}},
		}})
	case r.Method == "DELETE":
		if body["gracePeriodSeconds"] != float64(0) {
			w.WriteHeader(http.StatusBadRequest)
			return
		}
		f.deleted = append(f.deleted, r.URL.Path)
		w.Write([]byte(`{}`))
	case r.Method == "GET" && strings.HasSuffix(r.URL.Path, "/log"):
		f.since = r.URL.Query().Get("sinceTime")
		w.Write([]byte("starting\n{\"level\":\"info\",\"msg\":\"ready\"}\n{\"event.name\":\"sts.token.issued\",\"trace_id\":\"" + strings.Repeat("a", 32) + "\"}\nnot json {\n"))
	default:
		w.WriteHeader(http.StatusNotFound)
	}
}

func TestKubernetesSources(t *testing.T) {
	ctx := context.Background()
	api := &fakeAPI{}
	srv := httptest.NewServer(api)
	defer srv.Close()
	tokenFile := filepath.Join(t.TempDir(), "token")
	os.WriteFile(tokenFile, []byte("suite-token\n"), 0o600)
	kc, err := kube.New(srv.URL, tokenFile, filepath.Join(t.TempDir(), "no-ca"))
	if err != nil {
		t.Fatal(err)
	}
	actors := &kubeActors{kube: kc, cache: map[string]cachedToken{}}
	sa := fixture.ServiceAccount{Namespace: "sts-interop", Name: "interop-a"}
	a, err := actors.Token(ctx, sa, "https://sts.example")
	if err != nil || !strings.Contains(a.Token, "/namespaces/sts-interop/serviceaccounts/interop-a/token") {
		t.Fatalf("Token: %v %v", a, err)
	}
	if _, err := actors.Token(ctx, sa, "https://sts.example"); err != nil || len(api.requests) != 1 {
		t.Errorf("a second token within its life was requested again (%d requests)", len(api.requests))
	}
	spec := api.requests[0]["spec"].(map[string]any)
	if spec["expirationSeconds"] != float64(600) || spec["audiences"].([]any)[0] != "https://sts.example" || spec["boundObjectRef"] != nil || api.requests[0]["kind"] != "TokenRequest" {
		t.Errorf("TokenRequest body %v", api.requests[0])
	}

	bound, del, err := actors.Bound(ctx, sa, "https://sts.example")
	if err != nil || bound.Pod != "interop-a-1" {
		t.Fatalf("Bound chose %q (%v); want the running, undeleted pod of the service account", bound.Pod, err)
	}
	if ref := api.requests[1]["spec"].(map[string]any)["boundObjectRef"].(map[string]any); ref["name"] != "interop-a-1" || ref["kind"] != "Pod" {
		t.Errorf("boundObjectRef %v", ref)
	}
	if err := del(ctx); err != nil || len(api.deleted) != 1 || api.deleted[0] != "/api/v1/namespaces/sts-interop/pods/interop-a-1" {
		t.Errorf("delete: %v %v", err, api.deleted)
	}

	since := time.Now().Add(-time.Minute)
	audit := &kubeAudit{kube: kc, namespace: "sts-interop", selector: "app=sts", since: since}
	recs, err := audit.Records(ctx)
	if err != nil || len(recs) != 3 { // one audit record from each of the three pods' logs
		t.Errorf("Records = %d records, %v; want the one sts.token line per pod", len(recs), err)
	}
	if api.since != since.UTC().Format(time.RFC3339) {
		t.Errorf("sinceTime = %q", api.since)
	}
}
