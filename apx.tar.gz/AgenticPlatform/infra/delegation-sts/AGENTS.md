# Agent instructions: delegation-sts

This repository holds the delegation STS and what proves it: the policy schema, the black-box interoperability suite and the Go STS now, the reconciliation job and the chart later. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. The design is in [Identity](../../architecture/design/identity.md), the layout in [Repositories](../../architecture/design/repositories.md#repository-layouts), and how to run the suite in [interop/README.md](interop/README.md). The rules below are specific to this repository.

## The suite

- **The suite is the specification.** Its cases come from Identity's tables, not from an implementation. Never change a case to make an STS pass: change the design or `agent-sdk`'s spec first, then the case.
- **Black box.** Cases reach the STS only through its token endpoint, metadata and JWKS, and through its audit output and the gateway where a row needs them. The suite imports no STS code.
- **The contract comes from `agent-sdk`.** `interop/contract/spec/` is a vendored copy: refresh it with `interop/contract/vendor.sh`, never by hand. A new refusal reason needs a case; `TestCoverage` fails until it has one.
- **Every refusal case has its allowed twin,** and its request breaks exactly one rule of the policy under test, respecting the check order.
- **Every case fails against some stand-in.** A new case gets an expectation in `interop/standin_test.go`, and a fault in `interop/standin/` if no stand-in breaks it.
- **A case that needs more than the STS and the fixture declares it** as a `Need`, so the suite still runs anywhere and says what it skipped.

## The STS and its policy

- **The STS passes the suite.** `internal/sts`'s tests run every case but gateway and load against it in process, strictly; `interop/local-run.sh` runs them against the built binary. A change that fails a case is wrong unless the design changed first.
- **The checks keep the contract's order:** request, actor, subject, chain, resource. Within the subject stage the issuer comes before any key lookup, and introspection after every local check.
- **Every time bound is capped at the design's value** in `internal/config`: configuration may tighten one, never loosen it. The policy schema does the same for the policy's limits.
- **Refusals say what, not why.** The body carries `error` and `reason` only; the detail goes to the log.
- **Never touch the platform's own STS, keys or aliases** from this repository's tests. The rotation hook moves only `alias/interop/sts-signing*`.
- **Dependencies:** the standard library first. A new module needs its reason in the commit message, and a pinned version.

## Before committing

- `gofmt -l .` prints nothing, and `go vet ./...` and `go test ./...` pass.
- `python3 ../../architecture/tools/check_docs.py .` reports no problems.
