# delegation-sts

The platform's delegation STS, its interoperability suite and its chart, and the Okta to Keycloak reconciliation job ([Repositories](../../architecture/design/repositories.md#repositories)). It holds the policy schema, the suite and the Go STS, written in that order as [B1 in detail](../../architecture/plan/local-build.md#b1-in-detail) asks, the STS's image, the reconciliation job, and the chart that deploys them.

The design is in [Identity](../../architecture/design/identity.md). These links, and the others in this repository's documents, are relative to the workspace, which mirrors the GitLab group.

```text
delegation-sts/
├── cmd/delegation-sts/  # the STS's binary, and the Dockerfile of its image
├── cmd/reconcile/       # the reconciliation job's binary and Dockerfile
├── internal/            # the STS: sts (the exchange), kms, keycloak, kube, store, audit, jwt, config
├── policy/              # schema.json, the STS policy's JSON Schema, and the package that validates a policy
├── interop/             # the black-box interoperability suite; its README says how to run it
├── chart/               # the chart: the STS, the reconciliation job and the suite's release, each enabled by its release
├── scripts/goproxy.sh   # the modules the images build from, into .goproxy/
├── keys/local/          # platform.pub, the platform image key's public key, which the pipeline verifies with
├── .gitlab-ci.yml       # the checks; on main, the images built, pushed, signed and verified
├── go.mod, go.sum
├── AGENTS.md
└── README.md
```

## The STS

**What it serves.** One RFC 8693 token endpoint, one RFC 8414 metadata document, one JWKS ([What the custom STS is](../../architecture/design/identity.md#what-the-custom-sts-is-and-is-not)).

| Listener | Default | Serves |
| --- | --- | --- |
| `listen.public` | `:443`, TLS | `/.well-known/oauth-authorization-server`, `/jwks` |
| `listen.token` | `:8443`, TLS | `/token` |
| `listen.ops` | `:9090`, plain HTTP | `/metrics` (Prometheus text), `/healthz`, `/readyz` (ready once the signing keys resolve) |

Audit records, one per request, go to standard output as JSON lines, or with `audit.endpoint` to the collector's platform port over OTLP ([Audit records](#audit-records)); logs, as JSON, go to standard error.

**Metrics** on `/metrics`: requests by outcome and refusal reason, and their total time; the policy's and the deny list's hashes and reload errors; KMS's last success; audit records written nowhere (`sts_audit_write_errors_total`) and, with `audit.endpoint`, those the collector took and those diverted to standard output (`sts_audit_exported_total`, `sts_audit_diverted_total`); and, for open item [T7](../../architecture/plan/open-items.md#close-by-spike-local-or-dev), the introspection cache's hits and misses (`sts_introspection_cache_total`), the time spent in introspection requests to Keycloak, and their errors. The cache's hit rate is hits over hits and misses, per replica.

**Configuration.** One YAML file, named by `-config` or `STS_CONFIG` (default `/etc/delegation-sts/config.yaml`); `-check-config` loads it and every file it names, then exits. `internal/config/config.go` documents each key, and [interop/config/sts-local.yaml](interop/config/sts-local.yaml) is a complete example. Relative paths resolve from the file's directory.

| Keys | Hold |
| --- | --- |
| `issuer`, `token_endpoint` | The issuer URL and the metadata's `token_endpoint`, both `https` |
| `platform_domain`, `cluster` | What policy routes and actors expand with |
| `tls.cert_file`, `tls.key_file` | The certificate for both TLS ports, reloaded when renewed |
| `policy_file`, `deny_list_file`, `reload_interval` | The policy (validated against `policy/schema.json`) and the deny list, hot-reloaded |
| `keycloak.*` | The subject issuer: `issuer`, `jwks_url` and `introspection_url` (defaulting to Keycloak's paths), `client_id`, `client_assertion_file` (a projected token for Keycloak's audience), `ca_file` |
| `kubernetes.kubeconfig` | Empty in a cluster; else a kubeconfig with a bearer token |
| `kms.alias`, `kms.endpoint`, `kms.region` | The signing alias (default `alias/platform/sts-signing`; `-next` and `-previous` follow from it), and the KMS endpoint and region, which default to `AWS_ENDPOINT_URL` and the SDK's chain |
| `timing.*` | Leeway, introspection cache, JWKS age, refetch, retry and last-good bound, alias refresh, KMS bound: each defaults to the design's value and can be tightened, never loosened |
| `task_header` | The agent's task header, recorded as `task.id`; the design does not name it yet |
| `audit.endpoint`, `audit.timeout` | The collector's platform port, `http://<host>:<port>`, OTLP over gRPC; empty, the default, keeps audit records on standard output. Each export's bound: 1 second by default, 100 milliseconds to 5 seconds |

Credentials for KMS come from the AWS SDK's default chain: static keys locally, Pod Identity or IRSA in dev.

**The deny list** is YAML: `entries`, each a `sub` and either `added`, from which it expires one token lifetime plus the leeway later, or an explicit `expires`.

**Choices the design leaves open.** No leeway on the subject's `exp`, since a chain token never outlives its subject; 60 seconds on `nbf` and on the actor token's `exp`. The subject's issuer is checked before any key lookup, and introspection comes after every local check. The design names client-go, go-jose and jwx; the STS uses a TokenReview client, JOSE and a JWKS cache of its own on the standard library instead, to stay a small binary with few dependencies (decision [Q8](../../architecture/decisions/Q08-sts-in-go.md)), and an OTLP client of its own (`internal/otlp`) for the same reason. The audit export's timeout, its 10-second cooldown and standard output as its fallback are this repository's choices.

### Audit records

One record per request, issued or refused ([Refusals and audit records](../../architecture/design/identity.md#refusals-and-audit-records)), with the fields of `agent-sdk`'s `spec/audit/`.

- **Without `audit.endpoint`,** as the interop suite's release runs, each record is a JSON line on standard output, written before the response.
- **With it,** each record goes to the collector before the response, as an OTel log record: its fields are the attributes, one to one under their dotted names, `event.name` among them, as the gateways send theirs; `trace_id` and `span_id` are also the log record's trace context; the severity is INFO, the time the record's, the resource's `service.name` `delegation-sts`. The client is the standard library's HTTP/2 without TLS, which the mesh's sidecar wraps in mutual TLS, so the module gains no dependency.
- **When the collector does not take a record,** because it is unreachable, answers an error, rejects the record or does not answer within `audit.timeout`, the record goes to standard output as the same JSON line, so it is never lost and the exchange is never refused for it. For the next 10 seconds every record goes straight to standard output; then one export tries the collector again while the others keep going to standard output, and once it succeeds records go to the collector again. Delivery is at least once: a record the collector took but answered too late is on standard output as well, and one whose call broke after the collector took it reaches the collector twice, through the client's one retry; the copies share their trace and span IDs.

The design lists the dependencies whose outage refuses an exchange (Keycloak, the Kubernetes API, KMS and the JWKS), and the collector is not among them: the STS is tier 0 and the telemetry pipelines tier 1, which may degrade for hours ([Operations](../../architecture/design/operations.md#ownership-and-support)). The cost is a gap in the SIEM and the `audit` bucket while the collector fails, recoverable from the pods' logs; `sts_audit_diverted_total` measures it.

## The chart

`chart/` deploys each part a release enables. It renders no RBAC: the environment's setup grants what its accounts need (decision [D11](../../architecture/plan/open-items.md#close-by-decision)). `environments` passes `platform.domain`, `platform.cluster`, `platform.caBundle` and `registry.host` with its platform values.

| Part | Enabled by | Deploys |
| --- | --- | --- |
| The reconciliation job | `reconciler.enabled` | The CronJob in Keycloak's namespace, every 5 minutes, and the roles and teams it compares with Okta's groups |
| The STS | `sts.enabled` | A Deployment of `sts.replicas` serving 443, 8443 and 9090 as UID 65532, with the pod's unprivileged ports starting at 0 and every capability dropped; its configuration, policy and deny-list ConfigMaps; its ServiceAccount, whose own token calls TokenReview and whose projected token, for Keycloak's realm, authenticates introspection; a Service whose two TLS ports Istio passes through inside its mTLS; and an AuthorizationPolicy and a NetworkPolicy that admit 443 from every namespace and 8443 only from the namespaces of the policy's actors |
| The interop suite's release | `sts.enabled` and `interop.enabled` | The STS as the suite's own, on the suite's test policy and deny list, trusting the suite's fixture and signing through `alias/interop/sts-signing*`; the fixture agents' accounts and pods; the fixture's Service; and the suite's Job as a Helm test, which only `helm test` runs ([interop/README.md](interop/README.md)) |

- **The policy** is `sts.policy`, the policy file's text. The STS validates it against `policy/schema.json` at start and at every reload.
- **The deny list belongs to the kill-switch runbook.** The chart creates its ConfigMap empty, then renders whatever the ConfigMap holds, so a deploy keeps the runbook's entries, and never deletes it (`helm.sh/resource-policy: keep`). Helm and the runbook then both own the field, so the runbook writes with `--force-conflicts` or a plain update.
- **AWS:** `sts.aws.credentials` is `static` (the Secret `sts.aws.staticSecret`, which the environment creates), `podIdentity` or `irsa` (with `sts.aws.roleArn`); `sts.aws.endpoint` names floci locally.
- **TLS:** the Secret `sts.tlsSecret`, for the issuer's host, comes from the environment's setup.
- **Audit records:** `sts.audit.endpoint` and `reconciler.audit.endpoint` name the collector's platform port, `http://<host>:<port>`, OTLP over gRPC, for the STS's `audit.endpoint` and the job's `AUDIT_OTLP_ENDPOINT`; `sts.audit.timeout` sets the STS's `audit.timeout`. Empty, the default, the records stay on standard output ([Audit records](#audit-records)). The job exports only its audit records, of the users it disables and the sessions it ends ([The reconciliation job](../../architecture/design/identity.md#the-reconciliation-job)), and its anomalies (`reconcile.anomaly`, also on standard output), and not those of a dry run; its run summaries stay on standard output. A fault anomaly, part of a run's work it could not do (`missing_group`, `disable_failed`, `end_sessions_failed`, `read_failed`), makes the job exit 2 after its summary, so the failed Job alerts apart from the SIEM; a data anomaly (`two_teams`) leaves the exit at 0. A failed read or action exits 1. The interop suite's release ignores `sts.audit`, since the suite reads its STS's records from the pods' logs. The chart refuses an endpoint of another form. The STS's account and the job's, `delegation-sts` in `delegation-sts` and `okta-reconciler` in `keycloak`, are those the environment's network boundaries admit to the port.
- **Publishing.** Images are `<registry.host>/<repository>@<digest>`. The STS's image, the suite's image and the chart share the repository `platform/delegation-sts`, the images tagged `sha-<commit>` and `interop-sha-<commit>` of a commit on `main`; the reconciliation job's image is `platform/okta-reconciler`, tagged `sha-<commit>`. A pushed tag or chart version never changes, so every chart change bumps the version.
- **The pipeline** (`.gitlab-ci.yml`) builds the three images on protected `main`, multi-arch (`linux/amd64` and `linux/arm64`) with rootless BuildKit, so that a rebuild of the commit gives the same digest; pushes them by digest; attests an SPDX SBOM per platform and their SLSA provenance and signs them with the platform image key, `alias/platform/platform-signing` ([D36](../../architecture/plan/open-items.md#close-by-decision)), through `ci-components`' sign component, as this project's own role, `ci-delegation-sts`; then verifies each signature as the sign statement, `https://sigstore.dev/cosign/sign/v1`, its SBOM and its provenance with `keys/local/platform.pub`, the key's public key as admission holds it. Each push job's report, `out/<image>.pushed.json`, and the verify job's, `out/verify/images.txt`, give the digests `environments` pins. Merge requests run the checks, and build the images whose inputs changed, without pushing.
- **Images come from the pipeline alone:** admission's platform policy wants the platform key's signature, which only the pipeline makes. The Dockerfiles take the modules from `.goproxy/`, a module proxy directory that `scripts/goproxy.sh` writes, since CI's BuildKit gives `RUN` steps no network. A workstation build, for a look at an image, and the chart's push, still by hand, run from the repository root, with `REGISTRY` the environment's registry (`floci:4566/000000000000/us-east-1` locally):

  ```sh
  scripts/goproxy.sh
  docker buildx build --platform linux/amd64,linux/arm64 -f cmd/delegation-sts/Dockerfile -o type=oci,dest=/tmp/sts,tar=false .
  helm package chart -d /tmp && helm push /tmp/delegation-sts-<version>.tgz "oci://$REGISTRY/platform" --plain-http
  ```

## Go and checks

**Go** at the version in [Versions](../../architecture/reference/versions.md); dependencies are pinned in `go.mod` and `go.sum`. Beyond the standard library the module uses `go.yaml.in/yaml/v3` (YAML), `github.com/santhosh-tekuri/jsonschema/v6` (JSON Schema draft 2020-12), and the AWS SDK for Go v2 (`aws-sdk-go-v2`, its `config`, and `service/kms`).

**Checks:** `go vet ./...` and `go test ./...`. `internal/sts`'s tests run the whole interop suite against the STS in process, strictly, in about 20 seconds; the suite's own tests run it against stand-ins in about 15. `go test -short ./...` skips both. Running the suite against the built binary is described in [interop/README.md](interop/README.md).
