// Package policy loads and validates the delegation STS's policy file.
//
// The file's shape is schema.json, embedded here so the STS and its
// interoperability suite validate a policy the same way. Parse adds the
// cross-references a JSON Schema cannot express.
package policy

import (
	"bytes"
	_ "embed"
	"encoding/json"
	"fmt"
	"slices"
	"sort"
	"strings"

	"github.com/santhosh-tekuri/jsonschema/v6"
	"go.yaml.in/yaml/v3"
)

// Schema is the policy's JSON Schema (draft 2020-12).
//
//go:embed schema.json
var Schema []byte

// Person is the after entry that admits a person's token, which has no act.
const Person = "person"

// Policy is one environment's STS policy.
type Policy struct {
	Version         int              `yaml:"version"`
	MaxChain        int              `yaml:"max_chain"`
	TokenTTLSeconds int              `yaml:"token_ttl_seconds"`
	CarriedClaims   []string         `yaml:"carried_claims"`
	RateLimit       RateLimit        `yaml:"rate_limit"`
	Agents          map[string]Agent `yaml:"agents"`
}

// RateLimit is the per-actor, per-replica exchange limit.
type RateLimit struct {
	PerSecond int `yaml:"per_second"`
	Burst     int `yaml:"burst"`
}

// Agent is one agent the STS may issue chain tokens to.
type Agent struct {
	Actor   string   `yaml:"actor"`
	Routes  []string `yaml:"routes"`
	After   []string `yaml:"after"`
	Targets []string `yaml:"targets"`
}

var compiled = func() *jsonschema.Schema {
	doc, err := jsonschema.UnmarshalJSON(bytes.NewReader(Schema))
	if err != nil {
		panic(fmt.Sprintf("policy: schema.json does not parse: %v", err))
	}
	c := jsonschema.NewCompiler()
	c.AssertFormat()
	if err := c.AddResource("policy/schema.json", doc); err != nil {
		panic(err)
	}
	s, err := c.Compile("policy/schema.json")
	if err != nil {
		panic(fmt.Sprintf("policy: schema.json does not compile: %v", err))
	}
	return s
}()

// Parse reads a policy file (YAML), validates it against Schema, checks its
// cross-references and returns it.
func Parse(data []byte) (*Policy, error) {
	var doc any
	if err := yaml.Unmarshal(data, &doc); err != nil {
		return nil, fmt.Errorf("policy: not YAML: %w", err)
	}
	// Round-trip through JSON so the validator sees JSON types only.
	raw, err := json.Marshal(doc)
	if err != nil {
		return nil, fmt.Errorf("policy: not representable as JSON: %w", err)
	}
	inst, err := jsonschema.UnmarshalJSON(bytes.NewReader(raw))
	if err != nil {
		return nil, fmt.Errorf("policy: %w", err)
	}
	if err := compiled.Validate(inst); err != nil {
		return nil, fmt.Errorf("policy: does not match policy/schema.json:\n%s", describe(err))
	}
	var p Policy
	if err := yaml.Unmarshal(data, &p); err != nil {
		return nil, fmt.Errorf("policy: %w", err)
	}
	if err := p.check(); err != nil {
		return nil, err
	}
	return &p, nil
}

// check verifies what the schema cannot: every after entry names person or
// an agent of this policy, no agent admits itself, and each actor belongs to
// one agent only, so a TokenReview result maps to exactly one entry.
func (p *Policy) check() error {
	var problems []string
	actors := map[string]string{}
	for _, name := range p.AgentNames() {
		a := p.Agents[name]
		for _, prev := range a.After {
			switch {
			case prev == name:
				problems = append(problems, fmt.Sprintf("agent %s: after names the agent itself, which the chain rules always refuse", name))
			case prev != Person:
				if _, ok := p.Agents[prev]; !ok {
					problems = append(problems, fmt.Sprintf("agent %s: after names %q, which is neither person nor an agent of this policy", name, prev))
				}
			}
		}
		if other, ok := actors[a.Actor]; ok {
			problems = append(problems, fmt.Sprintf("agents %s and %s share the actor %s", other, name, a.Actor))
		}
		actors[a.Actor] = name
	}
	if len(problems) > 0 {
		return fmt.Errorf("policy: %s", strings.Join(problems, "; "))
	}
	return nil
}

// AgentNames returns the agents' names in sorted order.
func (p *Policy) AgentNames() []string {
	names := make([]string, 0, len(p.Agents))
	for n := range p.Agents {
		names = append(names, n)
	}
	sort.Strings(names)
	return names
}

// AgentByActor returns the agent whose actor is namespace/serviceAccount.
func (p *Policy) AgentByActor(actor string) (string, bool) {
	for _, n := range p.AgentNames() {
		if p.Agents[n].Actor == actor {
			return n, true
		}
	}
	return "", false
}

// Admits reports whether agent's after list admits prev (an agent name or Person).
func (a Agent) Admits(prev string) bool { return slices.Contains(a.After, prev) }

// RouteURL expands a policy route, <gateway>/<route>, into the audience the
// STS compares exactly: https://<gateway>.<domain>/<route>.
func RouteURL(route, domain string) string {
	gateway, path, _ := strings.Cut(route, "/")
	return "https://" + gateway + "." + domain + "/" + path
}

// CanonicalActor expands a policy actor, <namespace>/<service account>, into
// the canonical workload name <cluster>/<namespace>/<service account>.
func CanonicalActor(actor, cluster string) string { return cluster + "/" + actor }

func describe(err error) string {
	ve, ok := err.(*jsonschema.ValidationError)
	if !ok {
		return err.Error()
	}
	var lines []string
	for _, u := range ve.BasicOutput().Errors {
		if u.Error == nil {
			continue
		}
		loc := u.InstanceLocation
		if loc == "" {
			loc = "/"
		}
		lines = append(lines, fmt.Sprintf("  at %s: %s", loc, u.Error))
	}
	return strings.Join(lines, "\n")
}
