package policy

import (
	"strings"
	"testing"
)

// designExample is the example policy from the identity design.
const designExample = `
version: 1
max_chain: 3
token_ttl_seconds: 300
carried_claims: [idp_sub, roles, team, sid, preferred_username, acr, auth_time]
rate_limit: {per_second: 10, burst: 50}
agents:
  incident-agent:
    actor: sre-agents/incident-agent
    routes: [gateway/a2a/incident-agent]
    after: [person]
    targets: [workloads-gateway/mcp/jira-mcp, workloads-gateway/a2a/comms-agent]
  comms-agent:
    actor: sre-agents/comms-agent
    routes: [workloads-gateway/a2a/comms-agent]
    after: [incident-agent]
    targets: [workloads-gateway/mcp/slack-mcp]
`

func TestParseDesignExample(t *testing.T) {
	p, err := Parse([]byte(designExample))
	if err != nil {
		t.Fatalf("the design's example policy must be valid: %v", err)
	}
	if p.MaxChain != 3 || p.TokenTTLSeconds != 300 || p.RateLimit.Burst != 50 {
		t.Errorf("limits not read: %+v", p)
	}
	if got := p.AgentNames(); strings.Join(got, ",") != "comms-agent,incident-agent" {
		t.Errorf("AgentNames = %v", got)
	}
	if !p.Agents["comms-agent"].Admits("incident-agent") || p.Agents["comms-agent"].Admits(Person) {
		t.Errorf("Admits wrong for comms-agent")
	}
	if n, ok := p.AgentByActor("sre-agents/comms-agent"); !ok || n != "comms-agent" {
		t.Errorf("AgentByActor = %q, %v", n, ok)
	}
}

func TestParseRefuses(t *testing.T) {
	cases := []struct {
		name, from, to, want string
	}{
		{"max_chain above the cap", "max_chain: 3", "max_chain: 4", "/max_chain"},
		{"ttl above the cap", "token_ttl_seconds: 300", "token_ttl_seconds: 301", "/token_ttl_seconds"},
		{"rate above the cap", "per_second: 10", "per_second: 11", "/rate_limit/per_second"},
		{"burst above the cap", "burst: 50", "burst: 51", "/rate_limit/burst"},
		{"a claim that never passes", "carried_claims: [idp_sub,", "carried_claims: [scope, idp_sub,", "/carried_claims/0"},
		{"a target on the developer gateway", "targets: [workloads-gateway/mcp/slack-mcp]", "targets: [gateway/mcp/slack-mcp]", "/agents/comms-agent/targets/0"},
		{"a route with a full URL", "routes: [gateway/a2a/incident-agent]", "routes: [https://gateway.agentic.internal/a2a/incident-agent]", "/agents/incident-agent/routes/0"},
		{"an actor without a namespace", "actor: sre-agents/comms-agent", "actor: comms-agent", "/agents/comms-agent/actor"},
		{"an unknown field", "version: 1", "version: 1\nmax_hops: 2", "max_hops"},
		{"an unknown predecessor", "after: [incident-agent]", "after: [triage-agent]", `"triage-agent"`},
		{"an agent after itself", "after: [incident-agent]", "after: [comms-agent]", "after names the agent itself"},
		{"two agents with one actor", "actor: sre-agents/comms-agent", "actor: sre-agents/incident-agent", "share the actor"},
		{"an agent named person", "  comms-agent:\n", "  person:\n", "'person'"},
		{"a second version", "version: 1", "version: 2", "/version"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if !strings.Contains(designExample, c.from) {
				t.Fatalf("test bug: %q not in the example", c.from)
			}
			_, err := Parse([]byte(strings.Replace(designExample, c.from, c.to, 1)))
			if err == nil {
				t.Fatalf("Parse accepted a policy with %s", c.name)
			}
			if !strings.Contains(err.Error(), c.want) {
				t.Errorf("error does not name %q:\n%v", c.want, err)
			}
		})
	}
}

func TestParseRefusesDuplicateKeys(t *testing.T) {
	if _, err := Parse([]byte(designExample + "max_chain: 2\n")); err == nil {
		t.Fatal("Parse accepted a policy with max_chain twice")
	}
}

func TestExpansion(t *testing.T) {
	if got := RouteURL("workloads-gateway/mcp/jira-mcp", "agentic.internal"); got != "https://workloads-gateway.agentic.internal/mcp/jira-mcp" {
		t.Errorf("RouteURL = %s", got)
	}
	if got := RouteURL("gateway/v1", "agentic.internal"); got != "https://gateway.agentic.internal/v1" {
		t.Errorf("RouteURL = %s", got)
	}
	if got := CanonicalActor("sre-agents/incident-agent", "agentic-local"); got != "agentic-local/sre-agents/incident-agent" {
		t.Errorf("CanonicalActor = %s", got)
	}
}
