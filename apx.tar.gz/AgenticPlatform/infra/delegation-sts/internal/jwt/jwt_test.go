package jwt

import (
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/asn1"
	"encoding/json"
	"math/big"
	"testing"
)

func TestES256FromDER(t *testing.T) {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	input, _ := SigningInput(map[string]any{"alg": "ES256", "typ": "at+jwt"}, map[string]any{"sub": "u"})
	digest := sha256.Sum256([]byte(input))
	short := 0
	// Over many signatures R and S come out shorter than 32 bytes, and DER
	// adds a leading zero when the top bit is set: both must convert.
	for i := 0; i < 2000; i++ {
		der, err := ecdsa.SignASN1(rand.Reader, key, digest[:])
		if err != nil {
			t.Fatal(err)
		}
		if len(der) < 70 {
			short++
		}
		sig, err := ES256FromDER(der)
		if err != nil {
			t.Fatalf("signature %d: %v", i, err)
		}
		tok, err := Parse(Compact(input, sig))
		if err != nil {
			t.Fatal(err)
		}
		if err := tok.Verify(&key.PublicKey); err != nil {
			t.Fatalf("signature %d (DER %d bytes) does not verify after conversion: %v", i, len(der), err)
		}
	}
	if short == 0 {
		t.Log("no short integers met in 2000 signatures")
	}
	for _, bad := range [][]byte{nil, {0x30, 0x00}, append(mustDER(t, big.NewInt(1), big.NewInt(1)), 0)} {
		if _, err := ES256FromDER(bad); err == nil {
			t.Errorf("ES256FromDER(%x) succeeded", bad)
		}
	}
	n := elliptic.P256().Params().N
	if _, err := ES256FromDER(mustDER(t, n, big.NewInt(1))); err == nil {
		t.Error("R equal to the group order converted")
	}
	if _, err := ES256FromDER(mustDER(t, big.NewInt(0), big.NewInt(1))); err == nil {
		t.Error("zero R converted")
	}
	small, err := ES256FromDER(mustDER(t, big.NewInt(1), big.NewInt(2)))
	if err != nil || small[31] != 1 || small[63] != 2 || small[0] != 0 {
		t.Errorf("small values not left-padded: %x %v", small, err)
	}
}

func mustDER(t *testing.T, r, s *big.Int) []byte {
	der, err := asn1.Marshal(struct{ R, S *big.Int }{r, s})
	if err != nil {
		t.Fatal(err)
	}
	return der
}

func TestThumbprint(t *testing.T) {
	// RFC 7638, section 3.1.
	k := JWK{Kty: "RSA", E: "AQAB", N: "0vx7agoebGcQSuuPiLJXZptN9nndrQmbXEps2aiAFbWhM78LhWx4cbbfAAtVT86zwu1RK7aPFFxuhDR1L6tSoc_BJECPebWKRXjBZCiFV4n3oknjhMstn64tZ_2W-5JsGY4Hc5n9yBXArwl93lqt7_RN5w6Cf0h4QyQ5v-65YGjQR0_FDW2QvzqY368QQMicAtaSqzs8KJZgnYb9c7d0zgdAZHzu6qMQvRL5hajrn1n91CbOpbISD08qNLyrdkt-bFTWhAI4vMQFh6WeZu0fM4lFd2NcRwr3XPksINHaQ-G_xBniIqbw0Ls1jF44-csFCur-kEgU8awapJzKnqDKgw"}
	pub, err := k.PublicKey()
	if err != nil {
		t.Fatal(err)
	}
	if got, _ := Thumbprint(pub); got != "NzbLsXh8uDCcd-6MNwXF4W_7noWXFZAfHkxZsRGC9Xs" {
		t.Errorf("Thumbprint = %s", got)
	}
	ec, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	j, err := ECJWK(&ec.PublicKey)
	if err != nil {
		t.Fatal(err)
	}
	tp, _ := Thumbprint(&ec.PublicKey)
	if j.Kid != tp || j.Alg != "ES256" || j.Crv != "P-256" {
		t.Errorf("ECJWK = %+v, kid must be the thumbprint %s", j, tp)
	}
	back, err := j.PublicKey()
	if err != nil || !back.(*ecdsa.PublicKey).Equal(&ec.PublicKey) {
		t.Errorf("round trip through the JWK lost the key: %v", err)
	}
}

func TestVerify(t *testing.T) {
	rk, _ := rsa.GenerateKey(rand.Reader, 2048)
	weak, _ := rsa.GenerateKey(rand.Reader, 1024)
	ec, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	sign := func(alg string, key any) string {
		input, _ := SigningInput(map[string]any{"alg": alg}, map[string]any{"sub": "u", "exp": 1700000000})
		d := sha256.Sum256([]byte(input))
		var sig []byte
		switch k := key.(type) {
		case *rsa.PrivateKey:
			sig, _ = rsa.SignPKCS1v15(rand.Reader, k, crypto.SHA256, d[:])
		case *ecdsa.PrivateKey:
			der, _ := ecdsa.SignASN1(rand.Reader, k, d[:])
			sig, _ = ES256FromDER(der)
		}
		return Compact(input, sig)
	}
	ok := func(raw string, key crypto.PublicKey) error {
		tok, err := Parse(raw)
		if err != nil {
			return err
		}
		return tok.Verify(key)
	}
	if err := ok(sign("RS256", rk), &rk.PublicKey); err != nil {
		t.Errorf("RS256: %v", err)
	}
	if err := ok(sign("ES256", ec), &ec.PublicKey); err != nil {
		t.Errorf("ES256: %v", err)
	}
	if ok(sign("RS256", weak), &weak.PublicKey) == nil {
		t.Error("a 1024-bit RSA key verified")
	}
	if ok(sign("ES256", ec), &rk.PublicKey) == nil {
		t.Error("ES256 verified with an RSA key")
	}
	none, _ := SigningInput(map[string]any{"alg": "none"}, map[string]any{"sub": "u"})
	if ok(none+".", &ec.PublicKey) == nil {
		t.Error("alg none verified")
	}
	tok, _ := Parse(sign("ES256", ec))
	if n, ok := Int(tok.Claims["exp"]); !ok || n != 1700000000 {
		t.Errorf("Int(exp) = %d %v", n, ok)
	}
	if _, isNum := tok.Claims["exp"].(json.Number); !isNum {
		t.Error("numbers are not json.Number")
	}
}

func TestParseRefuses(t *testing.T) {
	for _, s := range []string{"", "a.b", "a.b.c.d", "e30.e30=.", "W10.e30.", "e30.e30.e30 ", string(make([]byte, MaxTokenBytes+1))} {
		if _, err := Parse(s); err == nil {
			t.Errorf("Parse(%.20q) succeeded", s)
		}
	}
}

func TestAudiences(t *testing.T) {
	if a, ok := Audiences("x"); !ok || len(a) != 1 {
		t.Error("string aud")
	}
	if a, ok := Audiences([]any{"x", "y"}); !ok || len(a) != 2 {
		t.Error("list aud")
	}
	if _, ok := Audiences([]any{"x", 1}); ok {
		t.Error("mixed aud accepted")
	}
	if _, ok := Audiences(nil); ok {
		t.Error("missing aud accepted")
	}
}
