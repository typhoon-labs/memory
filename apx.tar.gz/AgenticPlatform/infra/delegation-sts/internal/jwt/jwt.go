// Package jwt is the JOSE the STS needs, on the standard library: parse and
// verify compact JWS for the profile's allowlist (ES256, RS256), encode a
// signing input, turn a KMS DER signature into the R‖S form JWS requires,
// and describe keys as JWKs named by their RFC 7638 thumbprint.
//
// It is deliberately separate from the interoperability suite's own JOSE
// code, so a bug in one cannot hide behind the same bug in the other.
package jwt

import (
	"bytes"
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/asn1"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"strings"
)

// MaxTokenBytes bounds what Parse accepts.
const MaxTokenBytes = 16 << 10

var b64 = base64.RawURLEncoding

// Token is a parsed, unverified compact JWS.
type Token struct {
	Header       map[string]any // numbers as json.Number
	Claims       map[string]any // numbers as json.Number
	SigningInput string
	Signature    []byte
}

// Parse decodes a compact JWS without verifying it.
func Parse(s string) (*Token, error) {
	if len(s) > MaxTokenBytes {
		return nil, errors.New("token too large")
	}
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return nil, errors.New("not a compact JWS")
	}
	h, err1 := b64.DecodeString(parts[0])
	c, err2 := b64.DecodeString(parts[1])
	sig, err3 := b64.DecodeString(parts[2])
	if err := errors.Join(err1, err2, err3); err != nil {
		return nil, fmt.Errorf("not unpadded base64url: %w", err)
	}
	t := &Token{SigningInput: parts[0] + "." + parts[1], Signature: sig}
	var err error
	if t.Header, err = object(h); err != nil {
		return nil, fmt.Errorf("header: %w", err)
	}
	if t.Claims, err = object(c); err != nil {
		return nil, fmt.Errorf("claims: %w", err)
	}
	return t, nil
}

// Str returns a header parameter or claim as a string, or "".
func Str(m map[string]any, name string) string {
	s, _ := m[name].(string)
	return s
}

// Verify checks the signature with key for the token's alg, which must be
// ES256 with a P-256 key or RS256 with an RSA key of at least 2048 bits.
func (t *Token) Verify(key crypto.PublicKey) error {
	digest := sha256.Sum256([]byte(t.SigningInput))
	switch alg := Str(t.Header, "alg"); alg {
	case "ES256":
		pub, ok := key.(*ecdsa.PublicKey)
		if !ok || pub.Curve != elliptic.P256() {
			return errors.New("ES256 needs a P-256 key")
		}
		if len(t.Signature) != 64 {
			return errors.New("ES256 signature is not 64 bytes")
		}
		r := new(big.Int).SetBytes(t.Signature[:32])
		s := new(big.Int).SetBytes(t.Signature[32:])
		if !ecdsa.Verify(pub, digest[:], r, s) {
			return errors.New("bad signature")
		}
	case "RS256":
		pub, ok := key.(*rsa.PublicKey)
		if !ok || pub.N.BitLen() < 2048 {
			return errors.New("RS256 needs an RSA key of 2048 bits or more")
		}
		if rsa.VerifyPKCS1v15(pub, crypto.SHA256, digest[:], t.Signature) != nil {
			return errors.New("bad signature")
		}
	default:
		return fmt.Errorf("alg %q is not allowed", alg)
	}
	return nil
}

// SigningInput encodes header and claims as base64url(header).base64url(claims).
func SigningInput(header, claims any) (string, error) {
	h, err := json.Marshal(header)
	if err != nil {
		return "", err
	}
	c, err := json.Marshal(claims)
	if err != nil {
		return "", err
	}
	return b64.EncodeToString(h) + "." + b64.EncodeToString(c), nil
}

// Compact joins a signing input and a signature.
func Compact(signingInput string, sig []byte) string {
	return signingInput + "." + b64.EncodeToString(sig)
}

// ES256FromDER converts an ASN.1 DER ECDSA-Sig-Value, as KMS returns it,
// into the 64-byte R‖S form of RFC 7518, section 3.4.
func ES256FromDER(der []byte) ([]byte, error) {
	var sig struct{ R, S *big.Int }
	rest, err := asn1.Unmarshal(der, &sig)
	if err != nil {
		return nil, fmt.Errorf("signature is not DER: %w", err)
	}
	if len(rest) > 0 {
		return nil, errors.New("trailing bytes after the DER signature")
	}
	n := elliptic.P256().Params().N
	for _, v := range []*big.Int{sig.R, sig.S} {
		if v.Sign() <= 0 || v.Cmp(n) >= 0 {
			return nil, errors.New("signature value out of range for P-256")
		}
	}
	out := make([]byte, 64)
	sig.R.FillBytes(out[:32])
	sig.S.FillBytes(out[32:])
	return out, nil
}

// JWK is a public JSON Web Key.
type JWK struct {
	Kty string `json:"kty"`
	Kid string `json:"kid,omitempty"`
	Use string `json:"use,omitempty"`
	Alg string `json:"alg,omitempty"`
	Crv string `json:"crv,omitempty"`
	X   string `json:"x,omitempty"`
	Y   string `json:"y,omitempty"`
	N   string `json:"n,omitempty"`
	E   string `json:"e,omitempty"`
}

// JWKS is a JSON Web Key Set.
type JWKS struct {
	Keys []JWK `json:"keys"`
}

// ECJWK describes a P-256 public key for ES256, named by its thumbprint.
func ECJWK(pub *ecdsa.PublicKey) (JWK, error) {
	x, y, err := point(pub)
	if err != nil {
		return JWK{}, err
	}
	kid, err := Thumbprint(pub)
	if err != nil {
		return JWK{}, err
	}
	return JWK{Kty: "EC", Crv: "P-256", X: x, Y: y, Kid: kid, Alg: "ES256", Use: "sig"}, nil
}

// PublicKey returns the key a JWK describes; RSA and P-256 only.
func (k JWK) PublicKey() (crypto.PublicKey, error) {
	switch k.Kty {
	case "EC":
		if k.Crv != "P-256" {
			return nil, fmt.Errorf("curve %q", k.Crv)
		}
		x, err1 := b64.DecodeString(k.X)
		y, err2 := b64.DecodeString(k.Y)
		if err1 != nil || err2 != nil || len(x) != 32 || len(y) != 32 {
			return nil, errors.New("bad EC coordinates")
		}
		return ecdsa.ParseUncompressedPublicKey(elliptic.P256(), append(append([]byte{4}, x...), y...))
	case "RSA":
		n, err1 := b64.DecodeString(k.N)
		e, err2 := b64.DecodeString(k.E)
		if err1 != nil || err2 != nil || len(n) == 0 || len(e) == 0 || len(e) > 4 {
			return nil, errors.New("bad RSA parameters")
		}
		return &rsa.PublicKey{N: new(big.Int).SetBytes(n), E: int(new(big.Int).SetBytes(e).Int64())}, nil
	}
	return nil, fmt.Errorf("kty %q", k.Kty)
}

// Thumbprint is the RFC 7638 SHA-256 thumbprint of a P-256 or RSA public key.
func Thumbprint(pub crypto.PublicKey) (string, error) {
	var canonical string
	switch p := pub.(type) {
	case *ecdsa.PublicKey:
		x, y, err := point(p)
		if err != nil {
			return "", err
		}
		canonical = `{"crv":"P-256","kty":"EC","x":"` + x + `","y":"` + y + `"}`
	case *rsa.PublicKey:
		canonical = `{"e":"` + b64.EncodeToString(big.NewInt(int64(p.E)).Bytes()) + `","kty":"RSA","n":"` + b64.EncodeToString(p.N.Bytes()) + `"}`
	default:
		return "", fmt.Errorf("unsupported key %T", pub)
	}
	sum := sha256.Sum256([]byte(canonical))
	return b64.EncodeToString(sum[:]), nil
}

func point(p *ecdsa.PublicKey) (x, y string, err error) {
	if p.Curve != elliptic.P256() {
		return "", "", errors.New("not a P-256 key")
	}
	raw, err := p.Bytes()
	if err != nil {
		return "", "", err
	}
	return b64.EncodeToString(raw[1:33]), b64.EncodeToString(raw[33:65]), nil
}

// Int reads a NumericDate claim; JSON numbers only, fractions truncated.
func Int(v any) (int64, bool) {
	n, ok := v.(json.Number)
	if !ok {
		return 0, false
	}
	if i, err := n.Int64(); err == nil {
		return i, true
	}
	f, err := n.Float64()
	return int64(f), err == nil
}

// Audiences reads aud, a string or an array of strings.
func Audiences(v any) ([]string, bool) {
	switch a := v.(type) {
	case string:
		return []string{a}, true
	case []any:
		out := make([]string, 0, len(a))
		for _, x := range a {
			s, ok := x.(string)
			if !ok {
				return nil, false
			}
			out = append(out, s)
		}
		return out, true
	}
	return nil, false
}

func object(raw []byte) (map[string]any, error) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	var m map[string]any
	if err := dec.Decode(&m); err != nil {
		return nil, err
	}
	if m == nil || dec.More() {
		return nil, errors.New("not a single JSON object")
	}
	return m, nil
}
