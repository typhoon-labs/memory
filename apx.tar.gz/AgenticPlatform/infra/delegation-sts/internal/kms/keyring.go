// Package kms holds the STS's signing keys: asymmetric P-256 keys in AWS
// KMS behind three aliases, as Identity's "Signing keys and JWKS" sets out.
// The signing alias signs; -next is published before it signs; -previous
// stays published after its last signature. Each replica re-resolves the
// aliases on a timer, names each key by its RFC 7638 thumbprint, and stops
// signing and publishing once KMS has failed for longer than its bound.
package kms

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/sha256"
	"crypto/x509"
	"errors"
	"fmt"
	"log/slog"
	"sync"
	"sync/atomic"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/jwt"
)

// KeySpec is the only key spec the STS signs with.
const KeySpec = "ECC_NIST_P256"

var (
	// ErrNotFound reports a missing alias or key.
	ErrNotFound = errors.New("kms: not found")
	// ErrUnavailable reports that no current set of keys is known.
	ErrUnavailable = errors.New("kms: signing keys unavailable")
)

// API is the part of KMS the keyring uses.
type API interface {
	// ResolveAlias returns the ID of the key an alias names, or ErrNotFound.
	ResolveAlias(ctx context.Context, alias string) (string, error)
	// PublicKey returns a key's DER SubjectPublicKeyInfo and its key spec.
	PublicKey(ctx context.Context, keyID string) ([]byte, string, error)
	// SignDigest signs a SHA-256 digest with ECDSA_SHA_256 and returns the
	// DER signature.
	SignDigest(ctx context.Context, keyID string, digest []byte) ([]byte, error)
}

// Key is one published key.
type Key struct {
	ID  string // the KMS key ID
	Kid string // the RFC 7638 thumbprint
	Pub *ecdsa.PublicKey
	JWK jwt.JWK
}

// Snapshot is one resolution of the aliases: the key that signs, and every
// key to publish, deduplicated by kid, the signing key first.
type Snapshot struct {
	Signing   *Key
	Published []*Key
	Resolved  time.Time
}

// Keyring resolves the aliases and signs.
type Keyring struct {
	api                     API
	signing, next, previous string
	refresh, lastGood       time.Duration
	log                     *slog.Logger
	now                     func() time.Time

	// Deadlines for KMS calls, so a KMS that hangs rather than fails costs
	// one bounded wait: per signature, and per resolution of the aliases.
	SignTimeout, RefreshTimeout time.Duration

	mu     sync.Mutex
	byID   map[string]*Key // key material never changes for a key ID
	snap   atomic.Pointer[Snapshot]
	lastOK atomic.Int64 // unix nanoseconds of the last complete resolution
}

// New returns a keyring for the signing alias and its -next and -previous
// companions.
func New(api API, signing, next, previous string, refresh, lastGood time.Duration, log *slog.Logger) *Keyring {
	return &Keyring{api: api, signing: signing, next: next, previous: previous, refresh: refresh, lastGood: lastGood,
		log: log, now: time.Now, byID: map[string]*Key{}, SignTimeout: 5 * time.Second, RefreshTimeout: 10 * time.Second}
}

// Refresh resolves the three aliases. A missing -next or -previous is
// normal; a missing signing alias or any KMS error fails the refresh and
// keeps the last snapshot.
func (k *Keyring) Refresh(ctx context.Context) error {
	ctx, cancel := context.WithTimeout(ctx, k.RefreshTimeout)
	defer cancel()
	signing, err := k.resolve(ctx, k.signing)
	if errors.Is(err, ErrNotFound) {
		return fmt.Errorf("signing alias %s: %w", k.signing, err)
	}
	if err != nil {
		return err
	}
	snap := &Snapshot{Signing: signing, Published: []*Key{signing}, Resolved: k.now()}
	for _, alias := range []string{k.next, k.previous} {
		key, err := k.resolve(ctx, alias)
		if errors.Is(err, ErrNotFound) {
			continue
		}
		if err != nil {
			return err
		}
		dup := false
		for _, p := range snap.Published {
			dup = dup || p.Kid == key.Kid
		}
		if !dup {
			snap.Published = append(snap.Published, key)
		}
	}
	if prev := k.snap.Swap(snap); prev == nil || prev.Signing.Kid != snap.Signing.Kid || len(prev.Published) != len(snap.Published) {
		kids := make([]string, len(snap.Published))
		for i, p := range snap.Published {
			kids[i] = p.Kid
		}
		k.log.Info("signing keys resolved", "signing_kid", snap.Signing.Kid, "signing_key", snap.Signing.ID, "published", kids)
	}
	k.lastOK.Store(snap.Resolved.UnixNano())
	return nil
}

func (k *Keyring) resolve(ctx context.Context, alias string) (*Key, error) {
	id, err := k.api.ResolveAlias(ctx, alias)
	if err != nil {
		return nil, fmt.Errorf("resolving %s: %w", alias, err)
	}
	k.mu.Lock()
	key, ok := k.byID[id]
	k.mu.Unlock()
	if ok {
		return key, nil
	}
	der, spec, err := k.api.PublicKey(ctx, id)
	if err != nil {
		return nil, fmt.Errorf("public key of %s (%s): %w", alias, id, err)
	}
	if spec != KeySpec {
		return nil, fmt.Errorf("%s (%s) is a %s key; the STS signs only with %s", alias, id, spec, KeySpec)
	}
	parsed, err := x509.ParsePKIXPublicKey(der)
	pub, ok := parsed.(*ecdsa.PublicKey)
	if err != nil || !ok || pub.Curve != elliptic.P256() {
		return nil, fmt.Errorf("public key of %s (%s) is not a P-256 key: %v", alias, id, err)
	}
	j, err := jwt.ECJWK(pub)
	if err != nil {
		return nil, err
	}
	key = &Key{ID: id, Kid: j.Kid, Pub: pub, JWK: j}
	k.mu.Lock()
	k.byID[id] = key
	k.mu.Unlock()
	return key, nil
}

// Run refreshes every refresh interval until ctx ends.
func (k *Keyring) Run(ctx context.Context) {
	t := time.NewTicker(k.refresh)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			if err := k.Refresh(ctx); err != nil {
				k.log.Warn("resolving signing keys failed; keeping the last set", "err", err, "last_success", k.LastSuccess())
			}
		}
	}
}

// Current returns the last snapshot while it is within the last-good bound.
func (k *Keyring) Current() (*Snapshot, error) {
	snap := k.snap.Load()
	if snap == nil {
		return nil, fmt.Errorf("%w: never resolved", ErrUnavailable)
	}
	if age := k.now().Sub(k.LastSuccess()); age > k.lastGood {
		return nil, fmt.Errorf("%w: last resolved %s ago, beyond the %s bound", ErrUnavailable, age.Round(time.Second), k.lastGood)
	}
	return snap, nil
}

// LastSuccess is when the aliases last resolved completely.
func (k *Keyring) LastSuccess() time.Time {
	if n := k.lastOK.Load(); n != 0 {
		return time.Unix(0, n)
	}
	return time.Time{}
}

// Sign signs claims as an ES256 JWS with the current signing key, naming
// it in the header's kid, and checks the signature before returning it.
func (k *Keyring) Sign(ctx context.Context, header map[string]any, claims any) (token, kid string, err error) {
	snap, err := k.Current()
	if err != nil {
		return "", "", err
	}
	key := snap.Signing
	h := map[string]any{"alg": "ES256", "kid": key.Kid}
	for name, v := range header {
		if name != "alg" && name != "kid" {
			h[name] = v
		}
	}
	input, err := jwt.SigningInput(h, claims)
	if err != nil {
		return "", "", err
	}
	digest := sha256.Sum256([]byte(input))
	ctx, cancel := context.WithTimeout(ctx, k.SignTimeout)
	defer cancel()
	der, err := k.api.SignDigest(ctx, key.ID, digest[:])
	if err != nil {
		return "", "", fmt.Errorf("signing with %s: %w", key.ID, err)
	}
	sig, err := jwt.ES256FromDER(der)
	if err != nil {
		return "", "", fmt.Errorf("signature from %s: %w", key.ID, err)
	}
	token = jwt.Compact(input, sig)
	tok, err := jwt.Parse(token)
	if err == nil {
		err = tok.Verify(key.Pub)
	}
	if err != nil {
		return "", "", fmt.Errorf("the signature from %s does not verify with its public key: %w", key.ID, err)
	}
	return token, key.Kid, nil
}

// Key returns the published key named kid, to verify the STS's own tokens.
func (k *Keyring) Key(kid string) (*ecdsa.PublicKey, bool, error) {
	snap, err := k.Current()
	if err != nil {
		return nil, false, err
	}
	for _, p := range snap.Published {
		if p.Kid == kid {
			return p.Pub, true, nil
		}
	}
	return nil, false, nil
}

// JWKS is the set to publish.
func (k *Keyring) JWKS() (jwt.JWKS, error) {
	snap, err := k.Current()
	if err != nil {
		return jwt.JWKS{}, err
	}
	set := jwt.JWKS{Keys: make([]jwt.JWK, 0, len(snap.Published))}
	for _, p := range snap.Published {
		set.Keys = append(set.Keys, p.JWK)
	}
	return set, nil
}
