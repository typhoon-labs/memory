package kms_test

import (
	"context"
	"errors"
	"io"
	"log/slog"
	"os"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/jwt"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kms"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kms/kmsfake"
)

const (
	signing  = "alias/interop/sts-signing"
	next     = signing + "-next"
	previous = signing + "-previous"
)

var quiet = slog.New(slog.NewTextHandler(io.Discard, nil))

func kids(t *testing.T, k *kms.Keyring) []string {
	t.Helper()
	set, err := k.JWKS()
	if err != nil {
		t.Fatal(err)
	}
	var out []string
	for _, j := range set.Keys {
		out = append(out, j.Kid)
	}
	return out
}

func sign(t *testing.T, ctx context.Context, k *kms.Keyring) (*jwt.Token, string) {
	t.Helper()
	raw, kid, err := k.Sign(ctx, map[string]any{"typ": "at+jwt", "alg": "none", "kid": "ignored"}, map[string]any{"sub": "u"})
	if err != nil {
		t.Fatal(err)
	}
	tok, err := jwt.Parse(raw)
	if err != nil {
		t.Fatal(err)
	}
	return tok, kid
}

func TestRotation(t *testing.T) {
	ctx := context.Background()
	f := kmsfake.New()
	old := f.CreateKey()
	f.SetAlias(signing, old)
	k := kms.New(f, signing, next, previous, time.Hour, time.Hour, quiet)
	if _, err := k.Current(); !errors.Is(err, kms.ErrUnavailable) {
		t.Errorf("before the first refresh Current = %v", err)
	}
	if err := k.Refresh(ctx); err != nil {
		t.Fatal(err)
	}
	tok, oldKid := sign(t, ctx, k)
	pub, ok, _ := k.Key(oldKid)
	if !ok || tok.Verify(pub) != nil {
		t.Fatal("a signed token does not verify with its published key")
	}
	if jwt.Str(tok.Header, "alg") != "ES256" || jwt.Str(tok.Header, "kid") != oldKid || jwt.Str(tok.Header, "typ") != "at+jwt" {
		t.Errorf("header %v: alg and kid are the keyring's, other members the caller's", tok.Header)
	}
	if tp, _ := jwt.Thumbprint(pub); tp != oldKid {
		t.Errorf("kid %s is not the key's RFC 7638 thumbprint %s", oldKid, tp)
	}

	// Publish: the new key is published but does not sign.
	nw := f.CreateKey()
	f.SetAlias(next, nw)
	k.Refresh(ctx)
	if got := kids(t, k); len(got) != 2 || got[0] != oldKid {
		t.Errorf("after publish JWKS %v", got)
	}
	if _, kid := sign(t, ctx, k); kid != oldKid {
		t.Error("the -next key signs before the switch")
	}
	newKid := kids(t, k)[1]

	// Mid-switch, two aliases name one key: it is published once.
	f.SetAlias(signing, nw)
	k.Refresh(ctx)
	if got := kids(t, k); len(got) != 1 || got[0] != newKid {
		t.Errorf("with signing and -next on one key JWKS %v, want it once", got)
	}
	f.SetAlias(previous, old)
	f.DeleteAlias(next)
	k.Refresh(ctx)
	if got := kids(t, k); len(got) != 2 || got[0] != newKid || got[1] != oldKid {
		t.Errorf("after switch JWKS %v", got)
	}
	if _, kid := sign(t, ctx, k); kid != newKid {
		t.Error("after the switch the old key still signs")
	}
	if pub, ok, _ := k.Key(oldKid); !ok || tok.Verify(pub) != nil {
		t.Error("during the overlap the old token no longer verifies")
	}

	// Retire.
	f.DeleteAlias(previous)
	k.Refresh(ctx)
	if got := kids(t, k); len(got) != 1 || got[0] != newKid {
		t.Errorf("after retire JWKS %v", got)
	}
	if _, ok, _ := k.Key(oldKid); ok {
		t.Error("the retired key is still found")
	}
}

func TestLastGoodBound(t *testing.T) {
	ctx := context.Background()
	f := kmsfake.New()
	f.SetAlias(signing, f.CreateKey())
	k := kms.New(f, signing, next, previous, time.Hour, 200*time.Millisecond, quiet)
	if err := k.Refresh(ctx); err != nil {
		t.Fatal(err)
	}
	f.Fail(errors.New("kms down"))
	if err := k.Refresh(ctx); err == nil {
		t.Error("a failing KMS refreshed")
	}
	if _, err := k.JWKS(); err != nil {
		t.Errorf("inside the bound the last good set must be served: %v", err)
	}
	time.Sleep(250 * time.Millisecond)
	if _, err := k.JWKS(); !errors.Is(err, kms.ErrUnavailable) {
		t.Errorf("past the bound JWKS = %v, want ErrUnavailable", err)
	}
	if _, _, err := k.Sign(ctx, nil, map[string]any{}); !errors.Is(err, kms.ErrUnavailable) {
		t.Errorf("past the bound Sign = %v", err)
	}
	f.Fail(nil)
	if err := k.Refresh(ctx); err != nil {
		t.Fatal(err)
	}
	if _, err := k.JWKS(); err != nil {
		t.Errorf("after recovery: %v", err)
	}
}

func TestRefusedKeys(t *testing.T) {
	ctx := context.Background()
	f := kmsfake.New()
	k := kms.New(f, signing, next, previous, time.Hour, time.Hour, quiet)
	if err := k.Refresh(ctx); !errors.Is(err, kms.ErrNotFound) {
		t.Errorf("with no signing alias Refresh = %v", err)
	}
	f.SetAlias(signing, f.CreateRSAKey())
	if err := k.Refresh(ctx); err == nil {
		t.Error("an RSA key was accepted")
	}
	f.SetAlias(signing, f.CreateKey())
	if err := k.Refresh(ctx); err != nil {
		t.Errorf("missing -next and -previous must not fail a refresh: %v", err)
	}
}

// TestFloci runs the keyring against a real KMS API, such as floci's, when
// STS_KMS_TEST_ALIAS names an alias/interop/* signing alias there.
func TestFloci(t *testing.T) {
	alias := os.Getenv("STS_KMS_TEST_ALIAS")
	if alias == "" {
		t.Skip("STS_KMS_TEST_ALIAS not set")
	}
	if len(alias) < 14 || alias[:14] != "alias/interop/" {
		t.Fatalf("refusing %s: tests use alias/interop/* only", alias)
	}
	ctx := context.Background()
	api, err := kms.NewAWS(ctx, os.Getenv("AWS_ENDPOINT_URL"), "")
	if err != nil {
		t.Fatal(err)
	}
	k := kms.New(api, alias, alias+"-next", alias+"-previous", time.Minute, time.Minute, quiet)
	if err := k.Refresh(ctx); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 20; i++ {
		tok, kid := sign(t, ctx, k)
		pub, ok, _ := k.Key(kid)
		if !ok || tok.Verify(pub) != nil {
			t.Fatalf("signature %d from KMS does not verify", i)
		}
	}
	t.Logf("published %v", kids(t, k))
}

func TestHangingKMS(t *testing.T) {
	ctx := context.Background()
	f := kmsfake.New()
	f.SetAlias(signing, f.CreateKey())
	k := kms.New(f, signing, next, previous, time.Hour, time.Hour, quiet)
	k.SignTimeout, k.RefreshTimeout = 100*time.Millisecond, 100*time.Millisecond
	if err := k.Refresh(ctx); err != nil {
		t.Fatal(err)
	}
	f.Hang(true)
	start := time.Now()
	if _, _, err := k.Sign(ctx, nil, map[string]any{}); err == nil || time.Since(start) > time.Second {
		t.Errorf("Sign against a hanging KMS: %v after %s, want an error at the deadline", err, time.Since(start))
	}
	start = time.Now()
	if err := k.Refresh(ctx); err == nil || time.Since(start) > time.Second {
		t.Errorf("Refresh against a hanging KMS: %v after %s", err, time.Since(start))
	}
	f.Hang(false)
	if _, _, err := k.Sign(ctx, nil, map[string]any{}); err != nil {
		t.Errorf("after the KMS answers again: %v", err)
	}
}
