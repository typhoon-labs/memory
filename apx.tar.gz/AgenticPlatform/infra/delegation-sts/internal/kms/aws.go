package kms

import (
	"context"
	"errors"
	"fmt"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	awskms "github.com/aws/aws-sdk-go-v2/service/kms"
	"github.com/aws/aws-sdk-go-v2/service/kms/types"
)

// AWS is API on the AWS SDK. Credentials come from the SDK's default chain:
// static keys locally, Pod Identity or IRSA in dev.
type AWS struct{ client *awskms.Client }

// NewAWS returns a client for endpoint (empty: AWS_ENDPOINT_URL, or AWS
// itself) and region (empty: the SDK's default chain).
func NewAWS(ctx context.Context, endpoint, region string) (*AWS, error) {
	var opts []func(*config.LoadOptions) error
	if region != "" {
		opts = append(opts, config.WithRegion(region))
	}
	cfg, err := config.LoadDefaultConfig(ctx, opts...)
	if err != nil {
		return nil, fmt.Errorf("aws configuration: %w", err)
	}
	return &AWS{client: awskms.NewFromConfig(cfg, func(o *awskms.Options) {
		if endpoint != "" {
			o.BaseEndpoint = aws.String(endpoint)
		}
	})}, nil
}

// ResolveAlias implements API with DescribeKey, which also refuses keys
// that are not enabled signing keys.
func (a *AWS) ResolveAlias(ctx context.Context, alias string) (string, error) {
	out, err := a.client.DescribeKey(ctx, &awskms.DescribeKeyInput{KeyId: aws.String(alias)})
	if err != nil {
		var nf *types.NotFoundException
		if errors.As(err, &nf) {
			return "", ErrNotFound
		}
		return "", err
	}
	m := out.KeyMetadata
	if m == nil || m.KeyId == nil {
		return "", fmt.Errorf("DescribeKey %s: no key metadata", alias)
	}
	if m.KeyState != types.KeyStateEnabled || m.KeyUsage != types.KeyUsageTypeSignVerify {
		return "", fmt.Errorf("%s names key %s in state %s with usage %s; it must be an enabled SIGN_VERIFY key", alias, *m.KeyId, m.KeyState, m.KeyUsage)
	}
	return *m.KeyId, nil
}

// PublicKey implements API with GetPublicKey.
func (a *AWS) PublicKey(ctx context.Context, keyID string) ([]byte, string, error) {
	out, err := a.client.GetPublicKey(ctx, &awskms.GetPublicKeyInput{KeyId: aws.String(keyID)})
	if err != nil {
		return nil, "", err
	}
	return out.PublicKey, string(out.KeySpec), nil
}

// SignDigest implements API with Sign over a SHA-256 digest.
func (a *AWS) SignDigest(ctx context.Context, keyID string, digest []byte) ([]byte, error) {
	out, err := a.client.Sign(ctx, &awskms.SignInput{
		KeyId:            aws.String(keyID),
		Message:          digest,
		MessageType:      types.MessageTypeDigest,
		SigningAlgorithm: types.SigningAlgorithmSpecEcdsaSha256,
	})
	if err != nil {
		return nil, err
	}
	return out.Signature, nil
}
