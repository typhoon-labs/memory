// Package kmsfake is an in-memory KMS for tests: P-256 keys, aliases, and
// DER signatures as KMS returns them.
package kmsfake

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"fmt"
	"sync"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kms"
)

// KMS implements kms.API.
type KMS struct {
	mu      sync.Mutex
	keys    map[string]any // *ecdsa.PrivateKey or *rsa.PrivateKey
	aliases map[string]string
	fail    error
	hang    bool
	n       int
	Signs   int
}

// New returns an empty KMS.
func New() *KMS { return &KMS{keys: map[string]any{}, aliases: map[string]string{}} }

// CreateKey creates a P-256 signing key and returns its ID.
func (f *KMS) CreateKey() string {
	k, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	return f.add(k)
}

// CreateRSAKey creates a key of the wrong spec.
func (f *KMS) CreateRSAKey() string {
	k, _ := rsa.GenerateKey(rand.Reader, 2048)
	return f.add(k)
}

func (f *KMS) add(k any) string {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.n++
	id := fmt.Sprintf("key-%d", f.n)
	f.keys[id] = k
	return id
}

// SetAlias points alias at a key.
func (f *KMS) SetAlias(alias, id string) { f.mu.Lock(); f.aliases[alias] = id; f.mu.Unlock() }

// DeleteAlias removes an alias.
func (f *KMS) DeleteAlias(alias string) { f.mu.Lock(); delete(f.aliases, alias); f.mu.Unlock() }

// Alias returns the key an alias names, or "".
func (f *KMS) Alias(alias string) string { f.mu.Lock(); defer f.mu.Unlock(); return f.aliases[alias] }

// Fail makes every call fail with err, or succeed again with nil.
func (f *KMS) Fail(err error) { f.mu.Lock(); f.fail = err; f.mu.Unlock() }

// Hang makes every call block until its context ends, as a KMS that never
// answers does, or answer again with false.
func (f *KMS) Hang(on bool) { f.mu.Lock(); f.hang = on; f.mu.Unlock() }

// stall blocks while hanging is on; it reports the context's error.
func (f *KMS) stall(ctx context.Context) error {
	f.mu.Lock()
	on := f.hang
	f.mu.Unlock()
	if !on {
		return nil
	}
	<-ctx.Done()
	return ctx.Err()
}

// ResolveAlias implements kms.API.
func (f *KMS) ResolveAlias(ctx context.Context, alias string) (string, error) {
	if err := f.stall(ctx); err != nil {
		return "", err
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.fail != nil {
		return "", f.fail
	}
	id, ok := f.aliases[alias]
	if !ok {
		return "", kms.ErrNotFound
	}
	return id, nil
}

// PublicKey implements kms.API.
func (f *KMS) PublicKey(ctx context.Context, id string) ([]byte, string, error) {
	if err := f.stall(ctx); err != nil {
		return nil, "", err
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.fail != nil {
		return nil, "", f.fail
	}
	switch k := f.keys[id].(type) {
	case *ecdsa.PrivateKey:
		der, err := x509.MarshalPKIXPublicKey(&k.PublicKey)
		return der, kms.KeySpec, err
	case *rsa.PrivateKey:
		der, err := x509.MarshalPKIXPublicKey(&k.PublicKey)
		return der, "RSA_2048", err
	}
	return nil, "", kms.ErrNotFound
}

// SignDigest implements kms.API.
func (f *KMS) SignDigest(ctx context.Context, id string, digest []byte) ([]byte, error) {
	if err := f.stall(ctx); err != nil {
		return nil, err
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.fail != nil {
		return nil, f.fail
	}
	k, ok := f.keys[id].(*ecdsa.PrivateKey)
	if !ok {
		return nil, kms.ErrNotFound
	}
	f.Signs++
	return ecdsa.SignASN1(rand.Reader, k, digest)
}
