// Package config reads the STS's configuration file. The chart renders it
// from its values; every environment difference is a value here, never a
// code path. Each time bound defaults to the design's value and may be
// tightened, never loosened.
package config

import (
	"bytes"
	"errors"
	"fmt"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"go.yaml.in/yaml/v3"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
)

// Config is the STS's configuration.
type Config struct {
	// Issuer is the STS's issuer URL, https://delegation-sts.<platform.domain>.
	Issuer string `yaml:"issuer"`
	// TokenEndpoint is the metadata's token_endpoint, exactly as clients
	// reach it: the issuer's host on the token port.
	TokenEndpoint  string `yaml:"token_endpoint"`
	PlatformDomain string `yaml:"platform_domain"` // policy routes expand to https://<gateway>.<platform_domain>/<route>
	Cluster        string `yaml:"cluster"`         // the <cluster> of canonical actor names

	Listen struct {
		Public string `yaml:"public"` // metadata and JWKS, TLS; default :443
		Token  string `yaml:"token"`  // /token, TLS; default :8443
		Ops    string `yaml:"ops"`    // metrics and health, plain HTTP; default :9090
	} `yaml:"listen"`
	TLS struct {
		CertFile string `yaml:"cert_file"`
		KeyFile  string `yaml:"key_file"`
	} `yaml:"tls"`

	PolicyFile     string   `yaml:"policy_file"`
	DenyListFile   string   `yaml:"deny_list_file"`  // optional
	ReloadInterval Duration `yaml:"reload_interval"` // default 10s
	TaskHeader     string   `yaml:"task_header"`     // the agent's task header, for task.id; optional

	Keycloak struct {
		Issuer              string `yaml:"issuer"`                // compared exactly
		JWKSURL             string `yaml:"jwks_url"`              // default <issuer>/protocol/openid-connect/certs
		IntrospectionURL    string `yaml:"introspection_url"`     // default <issuer>/protocol/openid-connect/token/introspect
		ClientID            string `yaml:"client_id"`             // default delegation-sts
		ClientAssertionFile string `yaml:"client_assertion_file"` // a projected token for Keycloak's audience; optional
		CAFile              string `yaml:"ca_file"`               // optional; the system pool otherwise
	} `yaml:"keycloak"`

	Kubernetes struct {
		Kubeconfig string `yaml:"kubeconfig"` // empty: in-cluster
	} `yaml:"kubernetes"`

	// Audit is where the audit records go: empty, standard output; else the
	// collector's platform port, OTLP over gRPC, http://<host>:<port>, with
	// standard output for each record the collector does not take.
	Audit struct {
		Endpoint string   `yaml:"endpoint"`
		Timeout  Duration `yaml:"timeout"` // each export's bound; 100ms to 5s, default 1s
	} `yaml:"audit"`

	KMS struct {
		Alias    string `yaml:"alias"`    // the signing alias; -next and -previous are derived; default alias/platform/sts-signing
		Endpoint string `yaml:"endpoint"` // empty: AWS_ENDPOINT_URL, or AWS itself
		Region   string `yaml:"region"`   // empty: the SDK's default chain
	} `yaml:"kms"`

	Timing struct {
		Leeway             Duration `yaml:"leeway"`              // clock leeway for nbf and actor exp; at most 60s
		IntrospectionCache Duration `yaml:"introspection_cache"` // at most 30s
		JWKSMaxAge         Duration `yaml:"jwks_max_age"`        // at most 5m
		JWKSRefetch        Duration `yaml:"jwks_refetch"`        // unknown-kid refetch interval; at least 30s
		JWKSRetry          Duration `yaml:"jwks_retry"`          // retry after a failed fetch; 1s to 30s, default 5s
		JWKSLastGood       Duration `yaml:"jwks_last_good"`      // at most 15m
		AliasRefresh       Duration `yaml:"alias_refresh"`       // at most 60s
		KMSLastGood        Duration `yaml:"kms_last_good"`       // at most 15m
	} `yaml:"timing"`
}

// Duration reads Go duration strings.
type Duration struct{ time.Duration }

// UnmarshalYAML implements yaml.Unmarshaler.
func (d *Duration) UnmarshalYAML(n *yaml.Node) error {
	v, err := time.ParseDuration(n.Value)
	if err != nil {
		return fmt.Errorf("line %d: %w", n.Line, err)
	}
	d.Duration = v
	return nil
}

// Load reads, completes and validates a configuration file. Relative file
// paths in it resolve from the file's directory.
func Load(path string) (*Config, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var c Config
	dec := yaml.NewDecoder(bytes.NewReader(raw))
	dec.KnownFields(true)
	if err := dec.Decode(&c); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	dir := filepath.Dir(path)
	for _, p := range []*string{&c.TLS.CertFile, &c.TLS.KeyFile, &c.PolicyFile, &c.DenyListFile, &c.Keycloak.ClientAssertionFile, &c.Keycloak.CAFile, &c.Kubernetes.Kubeconfig} {
		if *p != "" && !filepath.IsAbs(*p) {
			*p = filepath.Join(dir, *p)
		}
	}
	if err := c.Complete(); err != nil {
		return nil, fmt.Errorf("%s: %w", path, err)
	}
	return &c, nil
}

// Complete fills defaults and validates.
func (c *Config) Complete() error {
	def(&c.Listen.Public, ":443")
	def(&c.Listen.Token, ":8443")
	def(&c.Listen.Ops, ":9090")
	def(&c.Keycloak.ClientID, "delegation-sts")
	def(&c.KMS.Alias, "alias/platform/sts-signing")
	issuer := strings.TrimRight(c.Keycloak.Issuer, "/")
	def(&c.Keycloak.JWKSURL, issuer+"/protocol/openid-connect/certs")
	def(&c.Keycloak.IntrospectionURL, issuer+"/protocol/openid-connect/token/introspect")
	defDur(&c.ReloadInterval, 10*time.Second)
	defDur(&c.Audit.Timeout, time.Second)
	t := &c.Timing
	defDur(&t.Leeway, 60*time.Second)
	defDur(&t.IntrospectionCache, 30*time.Second)
	defDur(&t.JWKSMaxAge, 5*time.Minute)
	defDur(&t.JWKSRefetch, 30*time.Second)
	defDur(&t.JWKSRetry, 5*time.Second)
	defDur(&t.JWKSLastGood, 15*time.Minute)
	defDur(&t.AliasRefresh, 60*time.Second)
	defDur(&t.KMSLastGood, 15*time.Minute)
	return c.validate()
}

func (c *Config) validate() error {
	var problems []string
	need := func(name, v string) {
		if v == "" {
			problems = append(problems, name+" is required")
		}
	}
	need("issuer", c.Issuer)
	need("token_endpoint", c.TokenEndpoint)
	need("platform_domain", c.PlatformDomain)
	need("cluster", c.Cluster)
	need("policy_file", c.PolicyFile)
	need("tls.cert_file", c.TLS.CertFile)
	need("tls.key_file", c.TLS.KeyFile)
	need("keycloak.issuer", c.Keycloak.Issuer)
	for name, v := range map[string]string{"issuer": c.Issuer, "token_endpoint": c.TokenEndpoint} {
		if u, err := url.Parse(v); v != "" && (err != nil || u.Scheme != "https" || u.Host == "" || u.RawQuery != "" || u.Fragment != "") {
			problems = append(problems, name+" must be an https URL without query or fragment")
		}
	}
	if c.Keycloak.Issuer == c.Issuer && c.Issuer != "" {
		problems = append(problems, "keycloak.issuer must differ from issuer")
	}
	if c.Audit.Endpoint != "" {
		if _, err := otlp.ParseEndpoint(c.Audit.Endpoint); err != nil {
			problems = append(problems, "audit.endpoint: "+err.Error())
		}
	}
	if strings.HasSuffix(c.KMS.Alias, "-next") || strings.HasSuffix(c.KMS.Alias, "-previous") || !strings.HasPrefix(c.KMS.Alias, "alias/") {
		problems = append(problems, "kms.alias must be the signing alias, such as alias/platform/sts-signing")
	}
	t := c.Timing
	for _, b := range []struct {
		name     string
		v        time.Duration
		min, max time.Duration
	}{
		{"timing.leeway", t.Leeway.Duration, 0, 60 * time.Second},
		{"timing.introspection_cache", t.IntrospectionCache.Duration, 0, 30 * time.Second},
		{"timing.jwks_max_age", t.JWKSMaxAge.Duration, time.Second, 5 * time.Minute},
		{"timing.jwks_refetch", t.JWKSRefetch.Duration, 30 * time.Second, time.Hour},
		{"timing.jwks_retry", t.JWKSRetry.Duration, 100 * time.Millisecond, 30 * time.Second},
		{"timing.jwks_last_good", t.JWKSLastGood.Duration, time.Second, 15 * time.Minute},
		{"timing.alias_refresh", t.AliasRefresh.Duration, 100 * time.Millisecond, 60 * time.Second},
		{"timing.kms_last_good", t.KMSLastGood.Duration, time.Second, 15 * time.Minute},
		{"reload_interval", c.ReloadInterval.Duration, 100 * time.Millisecond, 5 * time.Minute},
		{"audit.timeout", c.Audit.Timeout.Duration, 100 * time.Millisecond, 5 * time.Second},
	} {
		if b.v < b.min || b.v > b.max {
			problems = append(problems, fmt.Sprintf("%s is %s; the design allows %s to %s", b.name, b.v, b.min, b.max))
		}
	}
	if len(problems) > 0 {
		return errors.New(strings.Join(problems, "; "))
	}
	return nil
}

// JWKSURI is where the STS publishes its keys: /jwks on the issuer.
func (c *Config) JWKSURI() string { return strings.TrimRight(c.Issuer, "/") + "/jwks" }

// Aliases are the signing alias and its -next and -previous companions.
func (c *Config) Aliases() (signing, next, previous string) {
	return c.KMS.Alias, c.KMS.Alias + "-next", c.KMS.Alias + "-previous"
}

func def(s *string, v string) {
	if *s == "" {
		*s = v
	}
}

func defDur(d *Duration, v time.Duration) {
	if d.Duration == 0 {
		d.Duration = v
	}
}
