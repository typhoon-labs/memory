package config

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const minimal = `
issuer: https://delegation-sts.agentic.internal
token_endpoint: https://delegation-sts.agentic.internal:8443/token
platform_domain: agentic.internal
cluster: agentic-local
policy_file: policy.yaml
tls: {cert_file: tls/tls.crt, key_file: /abs/tls.key}
keycloak:
  issuer: https://keycloak.agentic.internal/realms/agentic
`

func write(t *testing.T, body string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "config.yaml")
	if err := os.WriteFile(p, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	return p
}

func TestDefaults(t *testing.T) {
	p := write(t, minimal)
	c, err := Load(p)
	if err != nil {
		t.Fatal(err)
	}
	dir := filepath.Dir(p)
	if c.PolicyFile != filepath.Join(dir, "policy.yaml") || c.TLS.CertFile != filepath.Join(dir, "tls/tls.crt") || c.TLS.KeyFile != "/abs/tls.key" {
		t.Errorf("paths not resolved from the file's directory: %s %s %s", c.PolicyFile, c.TLS.CertFile, c.TLS.KeyFile)
	}
	if c.Listen.Public != ":443" || c.Listen.Token != ":8443" || c.Listen.Ops != ":9090" {
		t.Errorf("listen defaults %+v", c.Listen)
	}
	if c.Keycloak.JWKSURL != "https://keycloak.agentic.internal/realms/agentic/protocol/openid-connect/certs" ||
		c.Keycloak.IntrospectionURL != "https://keycloak.agentic.internal/realms/agentic/protocol/openid-connect/token/introspect" ||
		c.Keycloak.ClientID != "delegation-sts" {
		t.Errorf("keycloak defaults %+v", c.Keycloak)
	}
	tm := c.Timing
	if tm.Leeway.Duration != time.Minute || tm.IntrospectionCache.Duration != 30*time.Second || tm.JWKSMaxAge.Duration != 5*time.Minute ||
		tm.JWKSRefetch.Duration != 30*time.Second || tm.JWKSLastGood.Duration != 15*time.Minute || tm.AliasRefresh.Duration != time.Minute || tm.KMSLastGood.Duration != 15*time.Minute {
		t.Errorf("timing defaults %+v", tm)
	}
	s, n, prev := c.Aliases()
	if s != "alias/platform/sts-signing" || n != s+"-next" || prev != s+"-previous" {
		t.Errorf("aliases %s %s %s", s, n, prev)
	}
	if c.JWKSURI() != "https://delegation-sts.agentic.internal/jwks" {
		t.Errorf("JWKSURI %s", c.JWKSURI())
	}
	if c.Audit.Endpoint != "" || c.Audit.Timeout.Duration != time.Second {
		t.Errorf("audit defaults %+v: want standard output and 1s", c.Audit)
	}
}

func TestAuditEndpoint(t *testing.T) {
	c, err := Load(write(t, minimal+"audit: {endpoint: http://collector.telemetry.svc.cluster.local:4319, timeout: 500ms}\n"))
	if err != nil {
		t.Fatal(err)
	}
	if c.Audit.Endpoint != "http://collector.telemetry.svc.cluster.local:4319" || c.Audit.Timeout.Duration != 500*time.Millisecond {
		t.Errorf("audit %+v", c.Audit)
	}
}

func TestRefuses(t *testing.T) {
	for _, c := range []struct{ name, extra, want string }{
		{"a loosened introspection cache", "timing: {introspection_cache: 31s}", "timing.introspection_cache"},
		{"a loosened leeway", "timing: {leeway: 2m}", "timing.leeway"},
		{"a loosened JWKS age", "timing: {jwks_max_age: 6m}", "timing.jwks_max_age"},
		{"a faster unknown-kid refetch", "timing: {jwks_refetch: 5s}", "timing.jwks_refetch"},
		{"a loosened last-good bound", "timing: {jwks_last_good: 16m}", "timing.jwks_last_good"},
		{"a slower alias refresh", "timing: {alias_refresh: 2m}", "timing.alias_refresh"},
		{"a loosened KMS bound", "timing: {kms_last_good: 1h}", "timing.kms_last_good"},
		{"the -next alias as the signing alias", "kms: {alias: alias/platform/sts-signing-next}", "kms.alias"},
		{"an unknown field", "max_hops: 3", "max_hops"},
		{"an https audit endpoint", "audit: {endpoint: https://collector:4319}", "audit.endpoint"},
		{"an audit endpoint with a path", "audit: {endpoint: http://collector:4318/v1/logs}", "audit.endpoint"},
		{"an audit endpoint without a port", "audit: {endpoint: http://collector}", "audit.endpoint"},
		{"a loosened audit timeout", "audit: {endpoint: http://collector:4319, timeout: 10s}", "audit.timeout"},
	} {
		t.Run(c.name, func(t *testing.T) {
			_, err := Load(write(t, minimal+c.extra+"\n"))
			if err == nil || !strings.Contains(err.Error(), c.want) {
				t.Errorf("Load = %v, want an error naming %s", err, c.want)
			}
		})
	}
	for _, drop := range []string{"issuer: https://delegation-sts", "token_endpoint:", "policy_file:", "cluster:", "  issuer: https://keycloak"} {
		var kept []string
		for _, l := range strings.Split(minimal, "\n") {
			if !strings.HasPrefix(l, drop) {
				kept = append(kept, l)
			}
		}
		if _, err := Load(write(t, strings.Join(kept, "\n"))); err == nil {
			t.Errorf("Load accepted a configuration without %q", drop)
		}
	}
	if _, err := Load(write(t, strings.Replace(minimal, "https://delegation-sts.agentic.internal\n", "http://delegation-sts.agentic.internal\n", 1))); err == nil {
		t.Error("Load accepted a plain-HTTP issuer")
	}
	tight, err := Load(write(t, minimal+"timing: {introspection_cache: 1s, jwks_last_good: 2s, alias_refresh: 200ms}\n"))
	if err != nil || tight.Timing.IntrospectionCache.Duration != time.Second {
		t.Errorf("tightened bounds refused: %v", err)
	}
}
