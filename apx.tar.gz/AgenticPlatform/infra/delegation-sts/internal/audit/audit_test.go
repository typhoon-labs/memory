package audit

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"strings"
	"sync"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp/otlpfake"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/contract"
)

func TestRecordsMatchTheSpec(t *testing.T) {
	k, err := contract.Load()
	if err != nil {
		t.Fatal(err)
	}
	var buf bytes.Buffer
	w := NewWriter(&buf)
	early := Record{"event.name": Refused, "refusal.error": "invalid_request", "refusal.reason": "actor_missing",
		"sts.policy.hash": "sha256:x", "trace_id": strings.Repeat("a", 32), "span_id": strings.Repeat("b", 16)}
	early.List("request.resource", nil)
	early.Str("user.id", "")
	early.Str("task.id", "")
	issued := Record{"event.name": Issued, "sts.policy.hash": "sha256:x", "trace_id": strings.Repeat("c", 32), "span_id": strings.Repeat("d", 16)}
	issued.Str("user.id", "u1")
	issued.Str("actor.sub", "agentic-local/ns/a")
	issued.List("actor.chain", []string{"agentic-local/ns/a"})
	issued.List("request.resource", []string{"https://workloads-gateway.agentic.internal/mcp/m"})
	issued.Str("token.jti", "Zr4cJ0m1x9bQ2vXyN8kq3A")
	issued.Str("token.aud", "https://workloads-gateway.agentic.internal/mcp/m")
	issued.Int("token.exp", 1794830700)
	issued.Str("token.kid", "kid")
	issued.Str("subject.jti", "j")
	issued.Str("subject.iss", "https://keycloak.agentic.internal/realms/agentic")
	for _, r := range []Record{early, issued} {
		if err := w.Write(r); err != nil {
			t.Fatal(err)
		}
	}
	sc := bufio.NewScanner(&buf)
	n := 0
	for sc.Scan() {
		n++
		var v map[string]any
		dec := json.NewDecoder(strings.NewReader(sc.Text()))
		dec.UseNumber()
		if err := dec.Decode(&v); err != nil {
			t.Fatal(err)
		}
		if err := k.ValidateAuditRecord(v); err != nil {
			t.Errorf("record %d does not match the spec: %v\n%s", n, err, sc.Text())
		}
		for key, val := range v {
			if val == nil {
				t.Errorf("record %d: %s is null", n, key)
			}
		}
	}
	if n != 2 {
		t.Fatalf("%d lines", n)
	}
	if strings.Contains(buf.String(), `"user.id":""`) {
		t.Error("an empty field was written")
	}
}

func TestConcurrentWritesStayLines(t *testing.T) {
	var buf bytes.Buffer
	w := NewWriter(&buf)
	var wg sync.WaitGroup
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			r := Record{"event.name": Issued}
			r.List("request.resource", []string{strings.Repeat("x", 4096)})
			w.Write(r)
		}()
	}
	wg.Wait()
	for i, l := range strings.Split(strings.TrimSpace(buf.String()), "\n") {
		if !json.Valid([]byte(l)) {
			t.Fatalf("line %d is not JSON: records interleaved", i)
		}
	}
}

func discard() *slog.Logger { return slog.New(slog.NewTextHandler(io.Discard, nil)) }

func exporter(t *testing.T, fake *otlpfake.Server, timeout time.Duration, out io.Writer) *Writer {
	t.Helper()
	c, err := otlp.New(fake.URL, "delegation-sts", timeout)
	if err != nil {
		t.Fatal(err)
	}
	return NewExporter(c, out, discard())
}

// specRecords are a refusal before the actor is known and an issuance.
func specRecords() []Record {
	early := Record{"event.name": Refused, "refusal.error": "invalid_request", "refusal.reason": "actor_missing",
		"sts.policy.hash": "sha256:x", "trace_id": strings.Repeat("a", 32), "span_id": strings.Repeat("b", 16)}
	early.List("request.resource", nil)
	early.Str("user.id", "")
	issued := Record{"event.name": Issued, "sts.policy.hash": "sha256:x", "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736", "span_id": "00f067aa0ba902b7"}
	issued.Str("user.id", "u1")
	issued.Str("actor.sub", "agentic-local/ns/a")
	issued.List("actor.chain", []string{"agentic-local/ns/a", "agentic-local/ns/b"})
	issued.List("request.resource", []string{"https://workloads-gateway.agentic.internal/mcp/m"})
	issued.Str("token.jti", "Zr4cJ0m1x9bQ2vXyN8kq3A")
	issued.Str("token.aud", "https://workloads-gateway.agentic.internal/mcp/m")
	issued.Int("token.exp", 1794830700)
	issued.Str("token.kid", "kid")
	issued.Str("subject.jti", "j")
	issued.Str("subject.iss", "https://keycloak.agentic.internal/realms/agentic")
	return []Record{early, issued}
}

// The collector gets each record as an OTel log record whose attributes
// are the record's fields one to one, so the attributes alone match the
// spec; nothing goes to standard output.
func TestExportedRecordsMatchTheSpec(t *testing.T) {
	k, err := contract.Load()
	if err != nil {
		t.Fatal(err)
	}
	fake := otlpfake.New()
	defer fake.Close()
	var out bytes.Buffer
	w := exporter(t, fake, time.Second, &out)
	if !w.Exporting() || NewWriter(&out).Exporting() {
		t.Fatal("Exporting is wrong")
	}
	before := time.Now()
	for _, r := range specRecords() {
		if err := w.Write(r); err != nil {
			t.Fatal(err)
		}
	}
	if out.Len() != 0 {
		t.Errorf("standard output got %q", out.String())
	}
	if p := fake.Problems(); len(p) > 0 {
		t.Fatalf("protocol problems: %v", p)
	}
	logs := fake.Logs()
	if len(logs) != 2 || w.Exported() != 2 || w.Diverted() != 0 {
		t.Fatalf("%d records arrived, %d exported, %d diverted", len(logs), w.Exported(), w.Diverted())
	}
	for i, l := range logs {
		if err := k.ValidateAuditRecord(l.Attributes); err != nil {
			t.Errorf("record %d's attributes do not match the spec: %v\n%v", i, err, l.Attributes)
		}
		if l.Service != "delegation-sts" || l.SeverityNumber != 9 || l.SeverityText != "INFO" {
			t.Errorf("record %d: service %q, severity %d %q", i, l.Service, l.SeverityNumber, l.SeverityText)
		}
		if l.TraceID != l.Attributes["trace_id"] || l.SpanID != l.Attributes["span_id"] {
			t.Errorf("record %d: trace context %s/%s, attributes %v/%v", i, l.TraceID, l.SpanID, l.Attributes["trace_id"], l.Attributes["span_id"])
		}
		if l.Time.Before(before.Add(-time.Second)) || l.Time.After(time.Now()) {
			t.Errorf("record %d: time %v", i, l.Time)
		}
		for _, key := range []string{"timestamp", "severity_text"} {
			if _, ok := l.Attributes[key]; ok {
				t.Errorf("record %d: the line's %s is an attribute", i, key)
			}
		}
		for key, v := range l.Attributes {
			if v == nil {
				t.Errorf("record %d: %s is null", i, key)
			}
		}
	}
	if got, ok := logs[0].Attributes["request.resource"].([]any); !ok || len(got) != 0 {
		t.Errorf("an empty request.resource arrived as %#v, want an empty list", logs[0].Attributes["request.resource"])
	}
	if _, ok := logs[0].Attributes["user.id"]; ok {
		t.Error("an empty field was sent")
	}
	if logs[1].Attributes["token.exp"] != int64(1794830700) {
		t.Errorf("token.exp arrived as %#v, want an integer", logs[1].Attributes["token.exp"])
	}
}

// When the collector does not take a record, it goes to standard output,
// as a line the spec accepts, and the exchange is not refused for it.
func TestFailingCollectorDivertsToStandardOutput(t *testing.T) {
	k, err := contract.Load()
	if err != nil {
		t.Fatal(err)
	}
	for _, mode := range []otlpfake.Mode{otlpfake.HTTPUnavailable, otlpfake.Unavailable, otlpfake.Reject, otlpfake.Hang, -1} {
		fake := otlpfake.New()
		fake.SetMode(mode)
		if mode == -1 { // nothing listening
			fake.Close()
		}
		var out bytes.Buffer
		w := exporter(t, fake, 200*time.Millisecond, &out)
		start := time.Now()
		if err := w.Write(specRecords()[1]); err != nil {
			t.Errorf("mode %d: %v", mode, err)
		}
		if d := time.Since(start); d > 2*time.Second {
			t.Errorf("mode %d: the write took %s", mode, d)
		}
		lines := strings.Split(strings.TrimSpace(out.String()), "\n")
		if len(lines) != 1 {
			t.Fatalf("mode %d: %d lines, want 1", mode, len(lines))
		}
		v, err := contract.Decode([]byte(lines[0]))
		if err != nil {
			t.Fatal(err)
		}
		if err := k.ValidateAuditRecord(v); err != nil {
			t.Errorf("mode %d: the line does not match the spec: %v", mode, err)
		}
		if w.Diverted() != 1 || w.Exported() != 0 || len(fake.Logs()) != 0 {
			t.Errorf("mode %d: %d diverted, %d exported, %d kept", mode, w.Diverted(), w.Exported(), len(fake.Logs()))
		}
		fake.Close()
	}
}

// After a failure, records go straight to standard output for the
// cooldown, then one export tries the collector again; once it takes a
// record, records go to it again.
func TestCooldownThenRecovery(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	fake.SetMode(otlpfake.Unavailable)
	var out bytes.Buffer
	w := exporter(t, fake, time.Second, &out)
	w.cooldown = 300 * time.Millisecond
	rec := func() Record { return specRecords()[1] }
	w.Write(rec())
	w.Write(rec())
	if fake.Calls() != 1 {
		t.Errorf("%d calls during the cooldown, want the first alone", fake.Calls())
	}
	fake.SetMode(otlpfake.Accept)
	time.Sleep(350 * time.Millisecond)
	w.Write(rec())
	w.Write(rec())
	if fake.Calls() != 3 || len(fake.Logs()) != 2 {
		t.Errorf("%d calls, %d records kept; want 3 and 2", fake.Calls(), len(fake.Logs()))
	}
	if n := strings.Count(out.String(), "\n"); n != 2 || w.Diverted() != 2 || w.Exported() != 2 {
		t.Errorf("%d lines, %d diverted, %d exported; want 2, 2, 2", n, w.Diverted(), w.Exported())
	}
}

// While the one export that tries the collector again waits, other
// records go to standard output at once.
func TestOneProbeAtATime(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	var out bytes.Buffer
	w := exporter(t, fake, 400*time.Millisecond, &out)
	w.cooldown = 50 * time.Millisecond
	fake.SetMode(otlpfake.Unavailable)
	w.Write(specRecords()[1])
	time.Sleep(60 * time.Millisecond)
	fake.SetMode(otlpfake.Hang)
	done := make(chan struct{})
	go func() { w.Write(specRecords()[1]); close(done) }()
	for fake.Calls() < 2 {
		time.Sleep(5 * time.Millisecond)
	}
	start := time.Now()
	w.Write(specRecords()[1])
	if d := time.Since(start); d > 100*time.Millisecond {
		t.Errorf("a write during the probe took %s", d)
	}
	<-done
	if fake.Calls() != 2 || w.Diverted() != 3 {
		t.Errorf("%d calls, %d diverted; want 2 and 3", fake.Calls(), w.Diverted())
	}
}

type brokenWriter struct{}

func (brokenWriter) Write([]byte) (int, error) { return 0, errors.New("broken pipe") }

// A record neither the collector nor standard output took is an error,
// which the STS counts.
func TestWrittenNowhereIsAnError(t *testing.T) {
	fake := otlpfake.New()
	fake.SetMode(otlpfake.Unavailable)
	defer fake.Close()
	if err := exporter(t, fake, time.Second, brokenWriter{}).Write(specRecords()[1]); err == nil {
		t.Error("a record written nowhere returned no error")
	}
}

func TestConcurrentExports(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	var out bytes.Buffer
	w := exporter(t, fake, 2*time.Second, &out)
	var wg sync.WaitGroup
	for i := 0; i < 50; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			w.Write(specRecords()[1])
		}()
	}
	wg.Wait()
	if len(fake.Logs()) != 50 || out.Len() != 0 {
		t.Errorf("%d records arrived, %d bytes on standard output", len(fake.Logs()), out.Len())
	}
}

// A collector that stopped answering, then recovers: once the cooldown
// has passed, the export after the timed-out one reaches it.
func TestRecoversAfterAHang(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	var out bytes.Buffer
	w := exporter(t, fake, 200*time.Millisecond, &out)
	w.cooldown = 50 * time.Millisecond
	fake.SetMode(otlpfake.Hang)
	w.Write(specRecords()[1])
	fake.SetMode(otlpfake.Accept)
	time.Sleep(60 * time.Millisecond)
	if err := w.Write(specRecords()[1]); err != nil {
		t.Fatal(err)
	}
	if len(fake.Logs()) != 1 || w.Exported() != 1 || w.Diverted() != 1 || strings.Count(out.String(), "\n") != 1 {
		t.Errorf("%d records kept, %d exported, %d diverted, %d lines; want 1 each", len(fake.Logs()), w.Exported(), w.Diverted(), strings.Count(out.String(), "\n"))
	}
}
