// Package audit writes the STS's audit records: one per token-exchange
// request, issued or refused, never sampled, with the attributes of
// agent-sdk's spec/audit/sts-record.schema.json under their dotted names.
// A field whose value is unknown is left out, never null.
//
// A Writer from NewWriter writes each record as one JSON object per line,
// on standard output. One from NewExporter sends each record to the
// collector as an OTel log record whose attributes are the record's
// fields, one to one, and writes the line only when the collector does not
// take the record, so no record is lost. Delivery is at least once: a
// record the collector took but answered too late is on the line as well,
// and one whose call broke after the collector took it reaches it twice.
package audit

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"io"
	"log/slog"
	"sync"
	"sync/atomic"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
)

// Event names.
const (
	Issued  = "sts.token.issued"
	Refused = "sts.token.refused"
)

// Record is one audit record being built.
type Record map[string]any

// Str sets a string field, unless it is empty.
func (r Record) Str(key, v string) {
	if v != "" {
		r[key] = v
	}
}

// List sets a list field, always present, empty rather than null.
func (r Record) List(key string, v []string) {
	out := make([]string, len(v))
	copy(out, v)
	r[key] = out
}

// Int sets an integer field.
func (r Record) Int(key string, v int64) { r[key] = v }

// Exporter sends log records to the collector: *otlp.Client.
type Exporter interface {
	Export(ctx context.Context, recs ...otlp.Record) error
}

// Cooldown is how long records go straight to the line after an export
// fails, so that a collector that does not answer delays one exchange per
// cooldown, not every exchange. Then one export tries the collector again
// while the others still go to the line.
const Cooldown = 10 * time.Second

// Writer writes records, one at a time; lines from concurrent requests
// never interleave.
type Writer struct {
	mu sync.Mutex
	w  io.Writer

	exp      Exporter // nil: lines only
	log      *slog.Logger
	cooldown time.Duration

	state     sync.Mutex
	downUntil time.Time // zero while the collector takes records
	probing   bool

	exported, diverted atomic.Int64
}

// NewWriter writes lines to w, normally os.Stdout.
func NewWriter(w io.Writer) *Writer { return &Writer{w: w} }

// NewExporter sends records through exp, and writes the line to fallback,
// normally os.Stdout, for each record exp does not take. It logs each
// failed export to log.
func NewExporter(exp Exporter, fallback io.Writer, log *slog.Logger) *Writer {
	return &Writer{w: fallback, exp: exp, log: log, cooldown: Cooldown}
}

// Exporting reports whether the Writer sends records to the collector.
func (w *Writer) Exporting() bool { return w != nil && w.exp != nil }

// Exported is how many records the collector took.
func (w *Writer) Exported() int64 { return w.exported.Load() }

// Diverted is how many records went to the line because the collector did
// not take them, or was failing when they were written.
func (w *Writer) Diverted() int64 { return w.diverted.Load() }

// Write adds the timestamp and writes the record. It returns once the
// collector has taken the record or the line is written; the error is the
// line's.
func (w *Writer) Write(r Record) error {
	now := time.Now().UTC()
	if w.exp != nil && w.export(now, r) {
		return nil
	}
	r["timestamp"] = now.Format(time.RFC3339Nano)
	r["severity_text"] = "INFO"
	line, err := json.Marshal(r)
	if err != nil {
		return err
	}
	line = append(line, '\n')
	w.mu.Lock()
	defer w.mu.Unlock()
	_, err = w.w.Write(line)
	return err
}

// export sends r unless the collector failed within the cooldown, and
// reports whether the collector took it. It never holds the line's lock,
// and never uses a request's context, so a client that goes away cannot
// cancel its record.
func (w *Writer) export(now time.Time, r Record) bool {
	w.state.Lock()
	if now.Before(w.downUntil) || w.probing {
		w.state.Unlock()
		w.diverted.Add(1)
		return false
	}
	probe := !w.downUntil.IsZero()
	w.probing = probe
	w.state.Unlock()

	err := w.exp.Export(context.Background(), toOTLP(now, r))

	w.state.Lock()
	if probe {
		w.probing = false
	}
	if err != nil {
		w.downUntil = time.Now().Add(w.cooldown)
	} else {
		w.downUntil = time.Time{}
	}
	w.state.Unlock()
	if err != nil {
		w.diverted.Add(1)
		w.log.Error("the collector did not take an audit record; writing records to standard output", "err", err, "for", w.cooldown.String())
		return false
	}
	w.exported.Add(1)
	return true
}

// toOTLP makes r an OTel log record: its fields are the attributes, and
// its trace_id and span_id are also the log record's trace context.
func toOTLP(now time.Time, r Record) otlp.Record {
	attrs := make(map[string]any, len(r))
	for k, v := range r {
		attrs[k] = v
	}
	rec := otlp.Record{Time: now, Attributes: attrs}
	if s, ok := r["trace_id"].(string); ok {
		rec.TraceID, _ = hex.DecodeString(s)
	}
	if s, ok := r["span_id"].(string); ok {
		rec.SpanID, _ = hex.DecodeString(s)
	}
	return rec
}
