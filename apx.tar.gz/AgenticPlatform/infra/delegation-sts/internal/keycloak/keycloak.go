// Package keycloak is what the STS asks of its subject issuer: the signing
// keys, under the JWKS cache rules of Identity's "Caching", and RFC 7662
// introspection of each person's token, cached by token hash for at most
// 30 seconds and never past the token's exp.
package keycloak

import (
	"context"
	"crypto"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/jwt"
)

var (
	// ErrUnavailable reports that the issuer cannot be used: its JWKS is
	// past the last-good bound, or introspection failed.
	ErrUnavailable = errors.New("keycloak: unavailable")
	// ErrUnknownKey reports a kid the issuer does not publish.
	ErrUnknownKey = errors.New("keycloak: unknown key")
)

// HTTPClient returns a client that trusts caFile, if set, besides the system pool.
func HTTPClient(caFile string, timeout time.Duration) (*http.Client, error) {
	tr := http.DefaultTransport.(*http.Transport).Clone()
	if caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return nil, err
		}
		pool, err := x509.SystemCertPool()
		if err != nil {
			pool = x509.NewCertPool()
		}
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("%s holds no PEM certificate", caFile)
		}
		tr.TLSClientConfig = &tls.Config{RootCAs: pool, MinVersion: tls.VersionTLS12}
	}
	return &http.Client{Transport: tr, Timeout: timeout}, nil
}

// JWKS caches an issuer's keys:
//
//   - a set older than MaxAge is refetched;
//   - an unknown kid refetches at most once per Refetch, so random key IDs
//     cannot cause a fetch flood;
//   - each fetch replaces the set, so removed keys are dropped;
//   - after a failed fetch the set is served until LastGood after the last
//     successful one, retrying every Retry, then nothing is.
//
// Fetches never hold the lock, and run one at a time. While a usable set
// exists a stale one is refreshed in the background and served meanwhile,
// so a hanging issuer delays no exchange; a caller waits for a fetch only
// when there is no usable set, or for a kid it has not seen.
type JWKS struct {
	URL                              string
	Client                           *http.Client
	MaxAge, Refetch, Retry, LastGood time.Duration
	Log                              *slog.Logger

	mu          sync.Mutex
	keys        map[string]crypto.PublicKey
	lastSuccess time.Time
	lastAttempt time.Time
	lastFailed  bool
	lastUnknown time.Time
	fetches     int
	inflight    chan struct{}
}

// Key returns the issuer's key named kid.
func (j *JWKS) Key(ctx context.Context, kid string) (crypto.PublicKey, error) {
	j.mu.Lock()
	now := time.Now()
	stale := j.lastSuccess.IsZero() || now.Sub(j.lastSuccess) >= j.MaxAge
	if stale && (!j.lastFailed || now.Sub(j.lastAttempt) >= j.Retry) {
		done := j.start(now)
		if !j.usable(now) {
			j.wait(ctx, done)
			now = time.Now()
		}
	}
	if !j.usable(now) {
		j.mu.Unlock()
		return nil, fmt.Errorf("%w: no JWKS fetched from %s within %s", ErrUnavailable, j.URL, j.LastGood)
	}
	if k, ok := j.keys[kid]; ok {
		j.mu.Unlock()
		return k, nil
	}
	if j.inflight != nil || now.Sub(j.lastUnknown) >= j.Refetch {
		if j.inflight == nil {
			j.lastUnknown = now
		}
		j.wait(ctx, j.start(now))
		if k, ok := j.keys[kid]; ok {
			j.mu.Unlock()
			return k, nil
		}
	}
	j.mu.Unlock()
	return nil, ErrUnknownKey
}

// usable reports whether the set is within the last-good bound. Holds mu.
func (j *JWKS) usable(now time.Time) bool {
	return !j.lastSuccess.IsZero() && now.Sub(j.lastSuccess) <= j.LastGood
}

// start begins a fetch unless one is running, and returns a channel closed
// when it ends. Holds mu.
func (j *JWKS) start(now time.Time) chan struct{} {
	if j.inflight != nil {
		return j.inflight
	}
	done := make(chan struct{})
	j.inflight = done
	j.fetches++
	j.lastAttempt = now
	go func() {
		keys, err := j.get(context.Background())
		j.mu.Lock()
		if err != nil {
			j.lastFailed = true
			j.Log.Warn("fetching the subject issuer's JWKS failed", "url", j.URL, "err", err, "last_success", j.lastSuccess)
		} else {
			j.keys, j.lastSuccess, j.lastFailed = keys, time.Now(), false
		}
		j.inflight = nil
		j.mu.Unlock()
		close(done)
	}()
	return done
}

// wait releases mu until the fetch ends or ctx does, then takes it again.
func (j *JWKS) wait(ctx context.Context, done chan struct{}) {
	j.mu.Unlock()
	select {
	case <-done:
	case <-ctx.Done():
	}
	j.mu.Lock()
}

// Fetches counts the fetches started, for tests and metrics.
func (j *JWKS) Fetches() int { j.mu.Lock(); defer j.mu.Unlock(); return j.fetches }

func (j *JWKS) get(ctx context.Context) (map[string]crypto.PublicKey, error) {
	req, err := http.NewRequestWithContext(ctx, "GET", j.URL, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Accept", "application/json")
	resp, err := j.Client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	var set jwt.JWKS
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&set); err != nil {
		return nil, fmt.Errorf("not a JWKS: %w", err)
	}
	keys := map[string]crypto.PublicKey{}
	for _, k := range set.Keys {
		if k.Kid == "" || (k.Use != "" && k.Use != "sig") {
			continue
		}
		if pub, err := k.PublicKey(); err == nil {
			keys[k.Kid] = pub
		}
	}
	return keys, nil
}

// Introspector asks the issuer whether a person's token is still active.
// It authenticates as ClientID with a client assertion read from
// AssertionFile on every call, so a rotated projected token is picked up.
type Introspector struct {
	URL           string
	ClientID      string
	AssertionFile string
	Client        *http.Client
	TTL           time.Duration

	mu    sync.Mutex
	cache map[[32]byte]entry
	calls int
	stats Stats
}

// Stats are an Introspector's counts since it started, for the STS's
// metrics: open item T7 weighs introspection's cost against the cache's
// hit rate.
type Stats struct {
	Hits     int64   // answers from the cache
	Misses   int64   // answers that needed a request to the issuer
	Requests int64   // requests to the issuer that ended, failed ones included
	Errors   int64   // requests that failed: no answer, or not a usable one
	Seconds  float64 // time spent in the requests that ended
}

type entry struct {
	active bool
	until  time.Time
}

// Active reports whether token is active, from the cache while its entry is
// younger than TTL and the token unexpired. Inactive answers are cached too.
func (i *Introspector) Active(ctx context.Context, token string, exp time.Time) (bool, error) {
	key := sha256.Sum256([]byte(token))
	now := time.Now()
	i.mu.Lock()
	e, ok := i.cache[key]
	if ok && now.Before(e.until) {
		i.stats.Hits++
		i.mu.Unlock()
		return e.active, nil
	}
	i.stats.Misses++
	i.mu.Unlock()
	start := time.Now()
	active, err := i.ask(ctx, token)
	took := time.Since(start)
	i.mu.Lock()
	defer i.mu.Unlock()
	i.stats.Requests++
	i.stats.Seconds += took.Seconds()
	if err != nil {
		i.stats.Errors++
		return false, fmt.Errorf("%w: introspection at %s: %v", ErrUnavailable, i.URL, err)
	}
	until := now.Add(i.TTL)
	if exp.Before(until) {
		until = exp
	}
	if i.cache == nil || len(i.cache) > 100_000 {
		i.evict(now)
	}
	if until.After(now) {
		i.cache[key] = entry{active, until}
	}
	return active, nil
}

// Calls counts the introspection requests made.
func (i *Introspector) Calls() int { i.mu.Lock(); defer i.mu.Unlock(); return i.calls }

// Stats returns the counts since start.
func (i *Introspector) Stats() Stats { i.mu.Lock(); defer i.mu.Unlock(); return i.stats }

func (i *Introspector) evict(now time.Time) {
	if i.cache == nil {
		i.cache = map[[32]byte]entry{}
		return
	}
	for k, e := range i.cache {
		if !now.Before(e.until) {
			delete(i.cache, k)
		}
	}
	if len(i.cache) > 100_000 {
		i.cache = map[[32]byte]entry{}
	}
}

func (i *Introspector) ask(ctx context.Context, token string) (bool, error) {
	form := url.Values{"token": {token}, "token_type_hint": {"access_token"}, "client_id": {i.ClientID}}
	if i.AssertionFile != "" {
		assertion, err := os.ReadFile(i.AssertionFile)
		if err != nil {
			return false, fmt.Errorf("client assertion: %w", err)
		}
		form.Set("client_assertion_type", "urn:ietf:params:oauth:client-assertion-type:jwt-bearer")
		form.Set("client_assertion", strings.TrimSpace(string(assertion)))
	}
	req, err := http.NewRequestWithContext(ctx, "POST", i.URL, strings.NewReader(form.Encode()))
	if err != nil {
		return false, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")
	i.mu.Lock()
	i.calls++
	i.mu.Unlock()
	resp, err := i.Client.Do(req)
	if err != nil {
		return false, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return false, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	var body struct {
		Active *bool `json:"active"`
	}
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&body); err != nil || body.Active == nil {
		return false, errors.New("the answer has no boolean active")
	}
	return *body.Active, nil
}
