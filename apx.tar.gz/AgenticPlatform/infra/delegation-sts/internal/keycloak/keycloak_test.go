package keycloak

import (
	"context"
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/jwt"
)

type issuer struct {
	mu       sync.Mutex
	keys     map[string]*rsa.PrivateKey
	down     bool
	active   map[string]bool
	seenAuth []string
}

func (s *issuer) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.down {
		w.WriteHeader(http.StatusServiceUnavailable)
		return
	}
	switch r.URL.Path {
	case "/certs":
		var set jwt.JWKS
		for kid, k := range s.keys {
			set.Keys = append(set.Keys, jwt.JWK{Kty: "RSA", Kid: kid, N: b64(k.N.Bytes()), E: "AQAB"})
		}
		json.NewEncoder(w).Encode(set)
	case "/introspect":
		r.ParseForm()
		s.seenAuth = append(s.seenAuth, r.PostForm.Get("client_id")+" "+r.PostForm.Get("client_assertion"))
		json.NewEncoder(w).Encode(map[string]any{"active": s.active[r.PostForm.Get("token")]})
	}
}

func b64(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }

var quiet = slog.New(slog.NewTextHandler(io.Discard, nil))

func key() *rsa.PrivateKey { k, _ := rsa.GenerateKey(rand.Reader, 2048); return k }

func TestJWKSCache(t *testing.T) {
	ctx := context.Background()
	is := &issuer{keys: map[string]*rsa.PrivateKey{"k1": key()}}
	srv := httptest.NewServer(is)
	defer srv.Close()
	j := &JWKS{URL: srv.URL + "/certs", Client: srv.Client(), MaxAge: 300 * time.Millisecond, Refetch: 200 * time.Millisecond,
		Retry: 50 * time.Millisecond, LastGood: 600 * time.Millisecond, Log: quiet}

	if _, err := j.Key(ctx, "k1"); err != nil || j.Fetches() != 1 {
		t.Fatalf("first key: %v after %d fetches", err, j.Fetches())
	}
	j.Key(ctx, "k1")
	if j.Fetches() != 1 {
		t.Error("a cached key was fetched again")
	}
	if _, err := j.Key(ctx, "nope"); !errors.Is(err, ErrUnknownKey) || j.Fetches() != 2 {
		t.Errorf("unknown kid: %v after %d fetches, want one refetch", err, j.Fetches())
	}
	for i := 0; i < 5; i++ {
		j.Key(ctx, "random-"+string(rune('a'+i)))
	}
	if j.Fetches() != 2 {
		t.Errorf("random kids caused %d fetches within the refetch interval", j.Fetches()-2)
	}

	is.mu.Lock()
	is.keys = map[string]*rsa.PrivateKey{"k2": key()}
	is.mu.Unlock()
	time.Sleep(350 * time.Millisecond) // past MaxAge: the next call refreshes in the background
	if _, err := j.Key(ctx, "k2"); err != nil {
		t.Errorf("the new key, after waiting for the refresh it started: %v", err)
	}
	if _, err := j.Key(ctx, "k1"); !errors.Is(err, ErrUnknownKey) {
		t.Errorf("a removed key is still served: %v", err)
	}

	is.mu.Lock()
	is.down = true
	is.mu.Unlock()
	time.Sleep(350 * time.Millisecond) // stale, inside LastGood
	if _, err := j.Key(ctx, "k2"); err != nil {
		t.Errorf("inside the last-good bound the last set must be served: %v", err)
	}
	time.Sleep(400 * time.Millisecond) // past LastGood
	if _, err := j.Key(ctx, "k2"); !errors.Is(err, ErrUnavailable) {
		t.Errorf("past the last-good bound: %v, want ErrUnavailable", err)
	}
	before := j.Fetches()
	j.Key(ctx, "k2")
	if j.Fetches() != before {
		t.Error("a failed fetch was retried at once, not after Retry")
	}
	is.mu.Lock()
	is.down = false
	is.mu.Unlock()
	time.Sleep(60 * time.Millisecond)
	if _, err := j.Key(ctx, "k2"); err != nil {
		t.Errorf("after recovery and one retry interval: %v", err)
	}
}

func TestIntrospection(t *testing.T) {
	ctx := context.Background()
	is := &issuer{active: map[string]bool{"live": true}}
	srv := httptest.NewServer(is)
	defer srv.Close()
	assertion := filepath.Join(t.TempDir(), "token")
	os.WriteFile(assertion, []byte("sa-token-1\n"), 0o600)
	in := &Introspector{URL: srv.URL + "/introspect", ClientID: "delegation-sts", AssertionFile: assertion, Client: srv.Client(), TTL: 200 * time.Millisecond}
	far := time.Now().Add(time.Hour)

	for i := 0; i < 3; i++ {
		if ok, err := in.Active(ctx, "live", far); !ok || err != nil {
			t.Fatalf("live: %v %v", ok, err)
		}
	}
	if in.Calls() != 1 {
		t.Errorf("%d calls for one token inside the TTL", in.Calls())
	}
	in.Active(ctx, "dead", far)
	in.Active(ctx, "dead", far)
	if in.Calls() != 2 {
		t.Error("an inactive answer was not cached")
	}
	is.mu.Lock()
	is.active["live"] = false
	is.mu.Unlock()
	os.WriteFile(assertion, []byte("sa-token-2\n"), 0o600)
	time.Sleep(220 * time.Millisecond)
	if ok, _ := in.Active(ctx, "live", far); ok {
		t.Error("after the TTL the token is still active")
	}
	if got := is.seenAuth[len(is.seenAuth)-1]; got != "delegation-sts sa-token-2" {
		t.Errorf("client authentication %q: the assertion must be re-read on every call", got)
	}
	soon := time.Now().Add(30 * time.Millisecond)
	in.Active(ctx, "short", soon)
	time.Sleep(40 * time.Millisecond)
	in.Active(ctx, "short", soon)
	if in.Calls() != 5 {
		t.Errorf("%d calls: a cache entry outlived its token's exp", in.Calls())
	}
	is.mu.Lock()
	is.down = true
	is.mu.Unlock()
	if _, err := in.Active(ctx, "other", far); !errors.Is(err, ErrUnavailable) {
		t.Errorf("introspection down: %v", err)
	}
	// Three live, two dead, one live after the TTL, two short, one other:
	// the requests are the misses, the rest came from the cache.
	st := in.Stats()
	if st.Hits != 3 || st.Misses != 6 || st.Errors != 1 || st.Seconds <= 0 {
		t.Errorf("stats %+v: want 3 hits, 6 misses, 1 error and the time spent", st)
	}
	if st.Misses != int64(in.Calls()) || st.Requests != st.Misses {
		t.Errorf("%d misses, %d requests ended, %d made: want the same", st.Misses, st.Requests, in.Calls())
	}
}

// TestJWKSHangingIssuer checks that an issuer that never answers delays no
// exchange while a usable set exists, and fails closed without one.
func TestJWKSHangingIssuer(t *testing.T) {
	var hang atomic.Bool
	k := key()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if hang.Load() {
			select {
			case <-r.Context().Done():
			case <-time.After(3 * time.Second):
			}
			return
		}
		json.NewEncoder(w).Encode(jwt.JWKS{Keys: []jwt.JWK{{Kty: "RSA", Kid: "k1", N: b64(k.N.Bytes()), E: "AQAB"}}})
	}))
	defer srv.Close()
	client := srv.Client()
	client.Timeout = 2 * time.Second
	j := &JWKS{URL: srv.URL, Client: client, MaxAge: 100 * time.Millisecond, Refetch: time.Hour, Retry: 50 * time.Millisecond, LastGood: time.Hour, Log: quiet}
	ctx := context.Background()
	if _, err := j.Key(ctx, "k1"); err != nil {
		t.Fatal(err)
	}
	hang.Store(true)
	time.Sleep(150 * time.Millisecond)
	for i := 0; i < 20; i++ {
		start := time.Now()
		if _, err := j.Key(ctx, "k1"); err != nil {
			t.Fatalf("call %d with a hanging issuer: %v", i, err)
		}
		if d := time.Since(start); d > 100*time.Millisecond {
			t.Fatalf("call %d waited %s for a hanging issuer while a usable set exists", i, d)
		}
	}
	if j.Fetches() > 2 {
		t.Errorf("%d fetches: a hanging fetch must not be started again while it runs", j.Fetches())
	}
	empty := &JWKS{URL: srv.URL, Client: client, MaxAge: time.Minute, Refetch: time.Hour, Retry: time.Second, LastGood: time.Hour, Log: quiet}
	short, cancel := context.WithTimeout(ctx, 200*time.Millisecond)
	defer cancel()
	start := time.Now()
	if _, err := empty.Key(short, "k1"); !errors.Is(err, ErrUnavailable) || time.Since(start) > time.Second {
		t.Errorf("no usable set and a hanging issuer: %v after %s, want ErrUnavailable at the caller's deadline", err, time.Since(start))
	}
}
