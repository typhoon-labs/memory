// Package sts is the delegation STS: one RFC 8693 token endpoint that adds
// an agent to a person's delegated token, one RFC 8414 metadata document,
// one JWKS and one reviewed policy, as Identity's "What the custom STS is,
// and is not" describes. It has no users, clients, sessions or sign-in pages.
package sts

import (
	"context"
	"crypto"
	"fmt"
	"io"
	"log/slog"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/audit"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/config"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/keycloak"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kms"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/store"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/policy"
)

// Reviewer reviews actor tokens (kube.Reviewer).
type Reviewer interface {
	Review(ctx context.Context, token string, audiences []string) (kube.Result, error)
}

// SubjectKeys returns the subject issuer's keys (keycloak.JWKS).
type SubjectKeys interface {
	Key(ctx context.Context, kid string) (crypto.PublicKey, error)
}

// Introspector says whether a person's token is active (keycloak.Introspector).
type Introspector interface {
	Active(ctx context.Context, token string, exp time.Time) (bool, error)
}

// introspectionStats is an Introspector that counts its cache's hits and
// misses (keycloak.Introspector); /metrics reports them when it does.
type introspectionStats interface {
	Stats() keycloak.Stats
}

// Service is a running STS.
type Service struct {
	cfg        *config.Config
	policy     *store.Watched[*policy.Policy]
	deny       *store.Watched[*store.DenyList]
	keys       *kms.Keyring
	subjects   SubjectKeys
	introspect Introspector
	review     Reviewer
	audit      *audit.Writer
	log        *slog.Logger
	limits     limiter
	metrics    metrics
}

// Deps are the parts a Service is built from.
type Deps struct {
	Config     *config.Config
	Policy     *store.Watched[*policy.Policy]
	Deny       *store.Watched[*store.DenyList]
	Keys       *kms.Keyring
	Subjects   SubjectKeys
	Introspect Introspector
	Review     Reviewer
	Audit      *audit.Writer
	Log        *slog.Logger
}

// New returns a Service over deps.
func New(d Deps) *Service {
	s := &Service{cfg: d.Config, policy: d.Policy, deny: d.Deny, keys: d.Keys, subjects: d.Subjects,
		introspect: d.Introspect, review: d.Review, audit: d.Audit, log: d.Log}
	s.metrics.init()
	return s
}

// Assemble builds a Service from its configuration: it loads the policy
// and deny list, which must be valid at start, and connects KMS through
// api, Keycloak and the Kubernetes API. Audit records go to auditOut, or,
// with audit.endpoint, to the collector, and to auditOut only when the
// collector does not take them.
func Assemble(cfg *config.Config, api kms.API, auditOut io.Writer, log *slog.Logger) (*Service, error) {
	pol, err := store.Open("policy", cfg.PolicyFile, policy.Parse, log)
	if err != nil {
		return nil, err
	}
	deny := store.Static("deny list", store.Empty())
	if cfg.DenyListFile != "" {
		if deny, err = store.Open("deny list", cfg.DenyListFile, store.ParseDenyList, log); err != nil {
			return nil, err
		}
	}
	client, err := keycloak.HTTPClient(cfg.Keycloak.CAFile, 5*time.Second)
	if err != nil {
		return nil, fmt.Errorf("keycloak.ca_file: %w", err)
	}
	t := cfg.Timing
	jwks := &keycloak.JWKS{URL: cfg.Keycloak.JWKSURL, Client: client, MaxAge: t.JWKSMaxAge.Duration, Refetch: t.JWKSRefetch.Duration,
		Retry: t.JWKSRetry.Duration, LastGood: t.JWKSLastGood.Duration, Log: log}
	intro := &keycloak.Introspector{URL: cfg.Keycloak.IntrospectionURL, ClientID: cfg.Keycloak.ClientID,
		AssertionFile: cfg.Keycloak.ClientAssertionFile, Client: client, TTL: t.IntrospectionCache.Duration}
	review, err := kube.New(cfg.Kubernetes.Kubeconfig)
	if err != nil {
		return nil, fmt.Errorf("kubernetes: %w", err)
	}
	signing, next, previous := cfg.Aliases()
	keys := kms.New(api, signing, next, previous, t.AliasRefresh.Duration, t.KMSLastGood.Duration, log)
	records := audit.NewWriter(auditOut)
	if cfg.Audit.Endpoint != "" {
		client, err := otlp.New(cfg.Audit.Endpoint, "delegation-sts", cfg.Audit.Timeout.Duration)
		if err != nil {
			return nil, fmt.Errorf("audit.endpoint: %w", err)
		}
		records = audit.NewExporter(client, auditOut, log)
	}
	return New(Deps{Config: cfg, Policy: pol, Deny: deny, Keys: keys, Subjects: jwks, Introspect: intro, Review: review,
		Audit: records, Log: log}), nil
}

// CheckFiles loads what a configuration names on disk, the policy, the deny
// list, the Keycloak CA and any kubeconfig, without connecting to KMS,
// Keycloak or the Kubernetes API, so a pipeline can check a rendered
// configuration anywhere.
func CheckFiles(cfg *config.Config, log *slog.Logger) error {
	if _, err := store.Open("policy", cfg.PolicyFile, policy.Parse, log); err != nil {
		return err
	}
	if cfg.DenyListFile != "" {
		if _, err := store.Open("deny list", cfg.DenyListFile, store.ParseDenyList, log); err != nil {
			return err
		}
	}
	if _, err := keycloak.HTTPClient(cfg.Keycloak.CAFile, time.Second); err != nil {
		return fmt.Errorf("keycloak.ca_file: %w", err)
	}
	if cfg.Kubernetes.Kubeconfig != "" {
		if _, err := kube.New(cfg.Kubernetes.Kubeconfig); err != nil {
			return fmt.Errorf("kubernetes: %w", err)
		}
	}
	return nil
}

// Keys is the service's keyring.
func (s *Service) Keys() *kms.Keyring { return s.keys }

// Run keeps the service's state current until ctx ends: it resolves the
// signing keys, retrying every second until the first success, then on
// the alias-refresh timer, and reloads the policy and deny list.
func (s *Service) Run(ctx context.Context) {
	go s.policy.Run(ctx, s.cfg.ReloadInterval.Duration)
	go s.deny.Run(ctx, s.cfg.ReloadInterval.Duration)
	for {
		err := s.keys.Refresh(ctx)
		if err == nil {
			break
		}
		s.log.Warn("signing keys not resolved yet; exchanges are refused until they are", "err", err)
		select {
		case <-ctx.Done():
			return
		case <-time.After(time.Second):
		}
	}
	s.keys.Run(ctx)
}

// Ready reports whether the service can issue: a policy is loaded and the
// signing keys are current.
func (s *Service) Ready() error {
	_, err := s.keys.Current()
	return err
}
