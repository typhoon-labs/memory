package sts_test

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/config"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kms/kmsfake"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/sts"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/fixture"
)

const (
	alias      = "alias/interop/sts-signing"
	denied     = "00000000-0000-4000-8000-00000000dead"
	taskHeader = "X-Interop-Task"
)

// rotator moves the fake KMS's aliases as interop/rotation/floci-kms.sh
// moves floci's.
type rotator struct{ f *kmsfake.KMS }

func (r rotator) Step(_ context.Context, step string) error {
	switch step {
	case interop.StepPublish:
		r.f.SetAlias(alias+"-next", r.f.CreateKey())
	case interop.StepSwitch:
		old, nw := r.f.Alias(alias), r.f.Alias(alias+"-next")
		r.f.SetAlias(alias+"-previous", old)
		r.f.SetAlias(alias, nw)
		r.f.DeleteAlias(alias + "-next")
	case interop.StepRetire:
		r.f.DeleteAlias(alias + "-previous")
	}
	return nil
}

// harness is the STS in process, its three ports on httptest servers, and
// the interop suite's Env, whose fixture is the STS's Keycloak and its
// Kubernetes API. KMS is the in-memory fake, and every time bound is
// tightened so a run takes seconds.
type harness struct {
	env               *interop.Env
	svc               *sts.Service
	kms               *kmsfake.KMS
	pub, tok, ops     *httptest.Server
	auditPath, policy string
	issuer, tokenURL  string
}

func newHarness(t *testing.T, ctx context.Context, tune func(*config.Config)) *harness {
	t.Helper()
	dir := t.TempDir()
	h := &harness{auditPath: filepath.Join(dir, "audit.jsonl"), kms: kmsfake.New()}
	h.policy, _ = filepath.Abs("../../interop/config/policy.yaml")

	var svc atomic.Pointer[sts.Service]
	serve := func(pick func(*sts.Service) http.Handler) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) { pick(svc.Load()).ServeHTTP(w, r) }
	}
	h.pub = httptest.NewTLSServer(serve((*sts.Service).PublicHandler))
	h.tok = httptest.NewTLSServer(serve((*sts.Service).TokenHandler))
	h.ops = httptest.NewServer(serve((*sts.Service).OpsHandler))
	t.Cleanup(func() { h.pub.Close(); h.tok.Close(); h.ops.Close() })
	h.issuer, h.tokenURL = h.pub.URL, h.tok.URL+"/token"
	h.kms.SetAlias(alias, h.kms.CreateKey())

	s := &interop.Config{PlatformDomain: "agentic.internal", Cluster: "agentic-local", PolicyFile: h.policy, Slow: true, Strict: true, TaskHeader: taskHeader}
	s.STS.Issuer, s.STS.TokenEndpoint = h.issuer, h.tokenURL
	s.Roles.DeniedSubject = denied
	s.Fixture.Listen = "127.0.0.1:0"
	s.Audit.Source, s.Audit.Path = "file", h.auditPath
	s.Rotation.AliasRefresh.Duration, s.Rotation.Margin.Duration = time.Second, time.Second
	s.Timing.Revocation.Duration = 3 * time.Second
	s.Timing.ActorRevocation.Duration = 3 * time.Second
	s.Timing.AuditDelay.Duration = time.Second
	s.Timing.JWKSLastGood.Duration = 3 * time.Second
	s.Timing.Poll.Duration = 100 * time.Millisecond
	if err := s.Complete(); err != nil {
		t.Fatal(err)
	}
	var err error
	if h.env, err = interop.NewEnv(ctx, s, interop.Options{STSClient: h.pub.Client(), Rotator: rotator{h.kms}}); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(h.env.Close)

	kubeconfig := filepath.Join(dir, "kubeconfig")
	if err := h.env.Fixture.WriteKubeconfig(kubeconfig, ""); err != nil {
		t.Fatal(err)
	}
	denyPath := filepath.Join(dir, "deny.yaml")
	os.WriteFile(denyPath, []byte("entries:\n- sub: "+denied+"\n  expires: 2099-01-01T00:00:00Z\n"), 0o600)
	c := &config.Config{Issuer: h.issuer, TokenEndpoint: h.tokenURL, PlatformDomain: "agentic.internal", Cluster: "agentic-local",
		PolicyFile: h.policy, DenyListFile: denyPath, TaskHeader: taskHeader}
	c.TLS.CertFile, c.TLS.KeyFile = "served by httptest", "served by httptest"
	c.Keycloak.Issuer = h.env.Fixture.Trusted.URL
	c.Kubernetes.Kubeconfig = kubeconfig
	c.KMS.Alias = alias
	c.Timing.IntrospectionCache.Duration = time.Second
	c.Timing.JWKSMaxAge.Duration = time.Second
	c.Timing.JWKSRetry.Duration = 200 * time.Millisecond
	c.Timing.JWKSLastGood.Duration = 2 * time.Second
	c.Timing.AliasRefresh.Duration = 200 * time.Millisecond
	if tune != nil {
		tune(c)
	}
	if err := c.Complete(); err != nil {
		t.Fatal(err)
	}
	out, err := os.OpenFile(h.auditPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { out.Close() })
	if h.svc, err = sts.Assemble(c, h.kms, out, slog.New(slog.NewTextHandler(io.Discard, nil))); err != nil {
		t.Fatal(err)
	}
	svc.Store(h.svc)
	go h.svc.Run(ctx)
	for deadline := time.Now().Add(5 * time.Second); h.svc.Ready() != nil; time.Sleep(20 * time.Millisecond) {
		if time.Now().After(deadline) {
			t.Fatalf("not ready: %v", h.svc.Ready())
		}
	}
	return h
}

// TestInteropSuite runs every case of the black-box suite against the STS,
// strictly, except those that need a gateway or load targets, which the STS
// alone cannot provide.
func TestInteropSuite(t *testing.T) {
	if testing.Short() {
		t.Skip("runs the whole interop suite")
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	h := newHarness(t, ctx, nil)
	ran := 0
	for _, k := range interop.Cases() {
		if strings.HasPrefix(k.ID, "gateway/") || strings.HasPrefix(k.ID, "load/") {
			continue
		}
		ran++
		t.Run(k.ID, func(t *testing.T) {
			r := h.env.Run(ctx, k)
			if r.Status != interop.Pass {
				t.Errorf("%s:\n%s", r.Status, r.Message)
			}
		})
	}
	if ran != len(interop.Cases())-3 {
		t.Errorf("ran %d cases; the filter must drop exactly the gateway and two load cases", ran)
	}

	raw, _ := os.ReadFile(h.policy)
	sum := sha256.Sum256(raw)
	metrics := get(t, h.ops.Client(), h.ops.URL+"/metrics", http.StatusOK)
	for _, want := range []string{
		`sts_policy_info{hash="sha256:` + hex.EncodeToString(sum[:]) + `"} 1`,
		`sts_requests_total{outcome="issued",reason=""}`,
		`sts_requests_total{outcome="refused",reason="rate_limited"}`,
		`sts_deny_list_info{hash="sha256:`,
		`sts_introspection_cache_total{result="hit"}`,
		`sts_introspection_cache_total{result="miss"}`,
		`sts_introspection_request_duration_seconds_count`,
	} {
		if !strings.Contains(metrics, want) {
			t.Errorf("/metrics lacks %s:\n%s", want, metrics)
		}
	}
	// The suite exchanges the same subjects many times within 30 seconds,
	// so the cache answers some of them; with no exchange in flight, every
	// miss is a request that ended, which the summary counts.
	hits, misses := metricValue(t, metrics, `sts_introspection_cache_total{result="hit"}`), metricValue(t, metrics, `sts_introspection_cache_total{result="miss"}`)
	if hits == 0 || misses == 0 || misses != metricValue(t, metrics, "sts_introspection_request_duration_seconds_count") {
		t.Errorf("introspection cache: %v hits, %v misses; want both, and a request per miss", hits, misses)
	}
}

// metricValue returns the value of the sample named exactly name.
func metricValue(t *testing.T, metrics, name string) float64 {
	t.Helper()
	for _, line := range strings.Split(metrics, "\n") {
		if v, ok := strings.CutPrefix(line, name+" "); ok {
			f, err := strconv.ParseFloat(v, 64)
			if err != nil {
				t.Fatalf("%s: %v", line, err)
			}
			return f
		}
	}
	t.Fatalf("/metrics has no sample %s", name)
	return 0
}

// TestKMSUnavailable takes KMS away past the last-good bound: the JWKS,
// the token endpoint and readiness fail closed, with an audit record for
// the refusal, and all recover once KMS answers.
func TestKMSUnavailable(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	h := newHarness(t, ctx, func(c *config.Config) { c.Timing.KMSLastGood.Duration = time.Second })
	client := h.pub.Client()
	exchange := func() (int, map[string]any, string) {
		r := h.env.Roles
		sa, _ := fixture.ParseServiceAccount(h.env.Policy.Agents[r.Chain[0]].Actor)
		subject, _ := h.env.Fixture.Trusted.Mint(fixture.Subject{Person: fixture.NewPerson(), Audience: r.PersonRoute})
		actor, _ := h.env.Fixture.Kube.Mint(fixture.SAToken{ServiceAccount: sa, Audiences: []string{h.issuer}})
		b := make([]byte, 16)
		rand.Read(b)
		trace := hex.EncodeToString(b)
		req, _ := http.NewRequest("POST", h.tokenURL, strings.NewReader(h.env.Form(subject, actor, []string{r.Target}).Encode()))
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		req.Header.Set("traceparent", "00-"+trace+"-0102030405060708-01")
		resp, err := client.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		var body map[string]any
		json.NewDecoder(resp.Body).Decode(&body)
		return resp.StatusCode, body, trace
	}
	if status, _, _ := exchange(); status != http.StatusOK {
		t.Fatalf("before the outage: HTTP %d", status)
	}

	h.kms.Fail(errors.New("kms unreachable"))
	time.Sleep(1500 * time.Millisecond)
	get(t, client, h.issuer+"/jwks", http.StatusServiceUnavailable)
	get(t, h.ops.Client(), h.ops.URL+"/readyz", http.StatusServiceUnavailable)
	status, body, trace := exchange()
	if status != http.StatusServiceUnavailable || body["error"] != "temporarily_unavailable" || body["reason"] != "dependency_unavailable" {
		t.Errorf("an exchange past the KMS bound: HTTP %d %v", status, body)
	}
	if rec := record(t, h.auditPath, trace); rec["event.name"] != "sts.token.refused" || rec["refusal.reason"] != "dependency_unavailable" {
		t.Errorf("the refusal's audit record: %v", rec)
	}

	h.kms.Fail(nil)
	time.Sleep(500 * time.Millisecond)
	get(t, client, h.issuer+"/jwks", http.StatusOK)
	get(t, h.ops.Client(), h.ops.URL+"/readyz", http.StatusOK)
	if status, _, _ := exchange(); status != http.StatusOK {
		t.Errorf("after KMS recovered: HTTP %d", status)
	}
}

func get(t *testing.T, c *http.Client, url string, want int) string {
	t.Helper()
	resp, err := c.Get(url)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != want {
		t.Errorf("GET %s: HTTP %d, want %d: %s", url, resp.StatusCode, want, body)
	}
	return string(body)
}

func record(t *testing.T, path, trace string) map[string]any {
	t.Helper()
	f, err := os.Open(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var m map[string]any
		if json.Unmarshal(sc.Bytes(), &m) == nil && m["trace_id"] == trace {
			return m
		}
	}
	t.Fatalf("no audit record for trace %s", trace)
	return nil
}
