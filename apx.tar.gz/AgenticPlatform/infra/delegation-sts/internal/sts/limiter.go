package sts

import (
	"math"
	"sync"
	"time"
)

// limiter is a token bucket per actor, in memory per replica, so the
// ceiling across replicas is the replica count times the policy's limit.
type limiter struct {
	mu      sync.Mutex
	buckets map[string]*bucket
}

type bucket struct {
	rate, burst, tokens float64
	last                time.Time
}

// allow takes one token from key's bucket, or says how long until one is
// available.
func (l *limiter) allow(key string, perSecond, burst int, now time.Time) (bool, time.Duration) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.buckets == nil {
		l.buckets = map[string]*bucket{}
	}
	b, ok := l.buckets[key]
	if !ok || b.rate != float64(perSecond) || b.burst != float64(burst) {
		b = &bucket{rate: float64(perSecond), burst: float64(burst), tokens: float64(burst), last: now}
		l.buckets[key] = b
	}
	b.tokens = math.Min(b.burst, b.tokens+now.Sub(b.last).Seconds()*b.rate)
	b.last = now
	if b.tokens >= 1 {
		b.tokens--
		return true, 0
	}
	return false, time.Duration((1 - b.tokens) / b.rate * float64(time.Second))
}
