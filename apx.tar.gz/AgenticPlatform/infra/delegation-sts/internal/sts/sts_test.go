package sts

import (
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/interop/contract"
)

// TestRefusalsMatchTheContract checks the table in code against agent-sdk's
// spec/refusals/refusals.json, as vendored: every reason, error and status.
func TestRefusalsMatchTheContract(t *testing.T) {
	k, err := contract.Load()
	if err != nil {
		t.Fatal(err)
	}
	if len(refusals) != len(k.Catalogue.Refusals) {
		t.Errorf("the STS knows %d reasons, the contract %d", len(refusals), len(k.Catalogue.Refusals))
	}
	for _, want := range k.Catalogue.Refusals {
		got, ok := refusals[want.Reason]
		if !ok || got.Error != want.Error || got.Status != want.Status {
			t.Errorf("%s: the STS has %+v, the contract %s/%d", want.Reason, got, want.Error, want.Status)
		}
	}
}

func TestTraceContext(t *testing.T) {
	in := "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"
	trace, span := traceContext(in)
	if trace != "4bf92f3577b34da6a3ce929d0e0e4736" || len(span) != 16 || span == "00f067aa0ba902b7" {
		t.Errorf("continued %s as %s/%s; want the trace kept and a new span", in, trace, span)
	}
	for _, bad := range []string{"", "01-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01", "00-" + strings.Repeat("0", 32) + "-00f067aa0ba902b7-01", "00-4BF92F3577B34DA6A3CE929D0E0E4736-00f067aa0ba902b7-01"} {
		if trace, _ := traceContext(bad); trace == "4bf92f3577b34da6a3ce929d0e0e4736" || len(trace) != 32 || trace == strings.Repeat("0", 32) {
			t.Errorf("traceparent %q gave trace %s; want a fresh one", bad, trace)
		}
	}
}

func TestLimiter(t *testing.T) {
	var l limiter
	now := time.Now()
	for i := 0; i < 5; i++ {
		if ok, _ := l.allow("a", 2, 5, now); !ok {
			t.Fatalf("request %d inside the burst refused", i)
		}
	}
	ok, wait := l.allow("a", 2, 5, now)
	if ok || wait != 500*time.Millisecond {
		t.Errorf("past the burst: %v, wait %s", ok, wait)
	}
	if ok, _ := l.allow("b", 2, 5, now); !ok {
		t.Error("another actor shares the bucket")
	}
	if ok, _ := l.allow("a", 2, 5, now.Add(500*time.Millisecond)); !ok {
		t.Error("no refill after half a second at 2/s")
	}
	if ok, _ := l.allow("a", 2, 10, now.Add(500*time.Millisecond)); !ok {
		t.Error("a changed limit did not start a fresh bucket")
	}
}
