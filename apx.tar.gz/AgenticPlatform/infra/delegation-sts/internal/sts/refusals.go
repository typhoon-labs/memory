package sts

import (
	"net/http"
	"time"
)

// refusal is one row of the refusal table in agent-sdk's
// spec/refusals/refusals.json. The table is kept in code, so the STS needs
// no spec at run time; a test checks it against the vendored spec.
type refusal struct {
	Status int
	Error  string
	Reason string
	// RetryAfter, for rate_limited, becomes the Retry-After header.
	RetryAfter time.Duration
	// detail is logged, never returned: refusals say what, not why.
	detail string
}

const (
	errRequest = "invalid_request"
	errTarget  = "invalid_target"
	errUnavail = "temporarily_unavailable"
)

var refusals = map[string]refusal{}

func row(status int, err, reason string) string {
	refusals[reason] = refusal{Status: status, Error: err, Reason: reason}
	return reason
}

// Reasons.
var (
	requestMalformed      = row(http.StatusBadRequest, errRequest, "request_malformed")
	actorMissing          = row(http.StatusBadRequest, errRequest, "actor_missing")
	actorAudience         = row(http.StatusBadRequest, errRequest, "actor_audience")
	actorExpired          = row(http.StatusBadRequest, errRequest, "actor_expired")
	actorRejected         = row(http.StatusBadRequest, errRequest, "actor_rejected")
	actorUnknown          = row(http.StatusBadRequest, errRequest, "actor_unknown")
	subjectSignature      = row(http.StatusBadRequest, errRequest, "subject_signature")
	subjectIssuer         = row(http.StatusBadRequest, errRequest, "subject_issuer")
	subjectType           = row(http.StatusBadRequest, errRequest, "subject_type")
	subjectExpired        = row(http.StatusBadRequest, errRequest, "subject_expired")
	subjectNotYetValid    = row(http.StatusBadRequest, errRequest, "subject_not_yet_valid")
	subjectForeignAct     = row(http.StatusBadRequest, errRequest, "subject_foreign_act")
	subjectInactive       = row(http.StatusBadRequest, errRequest, "subject_inactive")
	subjectDenied         = row(http.StatusBadRequest, errRequest, "subject_denied")
	subjectAudience       = row(http.StatusBadRequest, errRequest, "subject_audience")
	chainPredecessor      = row(http.StatusBadRequest, errRequest, "chain_predecessor")
	chainRepeat           = row(http.StatusBadRequest, errRequest, "chain_repeat")
	chainLength           = row(http.StatusBadRequest, errRequest, "chain_length")
	resourceMissing       = row(http.StatusBadRequest, errTarget, "resource_missing")
	resourceMultiple      = row(http.StatusBadRequest, errTarget, "resource_multiple")
	resourceNotAllowed    = row(http.StatusBadRequest, errTarget, "resource_not_allowed")
	rateLimited           = row(http.StatusTooManyRequests, errUnavail, "rate_limited")
	dependencyUnavailable = row(http.StatusServiceUnavailable, errUnavail, "dependency_unavailable")
)

// refuse returns the refusal for reason, with a detail for the logs.
func refuse(reason, detail string) *refusal {
	r := refusals[reason]
	r.detail = detail
	return &r
}
