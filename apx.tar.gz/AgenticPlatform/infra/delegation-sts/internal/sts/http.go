package sts

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/audit"
)

// PublicHandler serves port 443: the RFC 8414 metadata and the JWKS, which
// every verifier in the mesh fetches.
func (s *Service) PublicHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /.well-known/oauth-authorization-server", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Cache-Control", "public, max-age=300")
		writeJSON(w, http.StatusOK, map[string]any{
			"issuer":                                s.cfg.Issuer,
			"token_endpoint":                        s.cfg.TokenEndpoint,
			"jwks_uri":                              s.cfg.JWKSURI(),
			"grant_types_supported":                 []string{grantTokenExchange},
			"response_types_supported":              []string{},
			"token_endpoint_auth_methods_supported": []string{"none"},
		})
	})
	mux.HandleFunc("GET /jwks", func(w http.ResponseWriter, _ *http.Request) {
		set, err := s.keys.JWKS()
		if err != nil {
			s.log.Error("not serving the JWKS", "err", err)
			writeJSON(w, http.StatusServiceUnavailable, map[string]any{"error": errUnavail})
			return
		}
		w.Header().Set("Cache-Control", "public, max-age=300")
		writeJSON(w, http.StatusOK, set)
	})
	return mux
}

// TokenHandler serves port 8443: /token, reachable only from the policy's
// actors' namespaces (the chart's AuthorizationPolicy and NetworkPolicy).
func (s *Service) TokenHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/token", s.token)
	return mux
}

func (s *Service) token(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	trace, span := traceContext(r.Header.Get("traceparent"))
	loaded := s.policy.Get()
	rec := audit.Record{"trace_id": trace, "span_id": span, "sts.policy.hash": loaded.Hash}
	if h := s.cfg.TaskHeader; h != "" {
		rec.Str("task.id", r.Header.Get(h))
	}
	body, ref := s.exchange(r.Context(), r, rec, loaded.Value)
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Pragma", "no-cache")
	if ref != nil {
		rec["event.name"] = audit.Refused
		rec["refusal.error"], rec["refusal.reason"] = ref.Error, ref.Reason
		s.write(rec)
		s.log.Info("refused", "reason", ref.Reason, "detail", ref.detail, "actor", rec["actor.sub"], "trace_id", trace)
		if ref.RetryAfter > 0 {
			w.Header().Set("Retry-After", strconv.Itoa(int(math.Ceil(ref.RetryAfter.Seconds()))))
		}
		writeJSON(w, ref.Status, map[string]any{"error": ref.Error, "reason": ref.Reason})
		s.metrics.observe("refused", ref.Reason, time.Since(start))
		return
	}
	rec["event.name"] = audit.Issued
	s.write(rec)
	writeJSON(w, http.StatusOK, body)
	s.metrics.observe("issued", "", time.Since(start))
}

func (s *Service) write(rec audit.Record) {
	if err := s.audit.Write(rec); err != nil {
		s.metrics.auditErrors.Add(1)
		s.log.Error("writing an audit record failed", "err", err)
	}
}

// traceContext continues a W3C traceparent, or starts a trace, and returns
// the trace ID and a new span ID for this request.
func traceContext(header string) (trace, span string) {
	span = hex.EncodeToString(random(8))
	p := strings.Split(strings.TrimSpace(header), "-")
	if len(p) == 4 && p[0] == "00" && isHex(p[1], 32) && isHex(p[2], 16) && isHex(p[3], 2) && strings.Trim(p[1], "0") != "" {
		return p[1], span
	}
	return hex.EncodeToString(random(16)), span
}

func isHex(s string, n int) bool {
	if len(s) != n {
		return false
	}
	for _, c := range s {
		if !strings.ContainsRune("0123456789abcdef", c) {
			return false
		}
	}
	return true
}

func random(n int) []byte {
	b := make([]byte, n)
	rand.Read(b)
	return b
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// OpsHandler serves the operations port: Prometheus metrics, liveness and
// readiness.
func (s *Service) OpsHandler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, _ *http.Request) { w.Write([]byte("ok\n")) })
	mux.HandleFunc("GET /readyz", func(w http.ResponseWriter, _ *http.Request) {
		if err := s.Ready(); err != nil {
			http.Error(w, err.Error(), http.StatusServiceUnavailable)
			return
		}
		w.Write([]byte("ok\n"))
	})
	mux.HandleFunc("GET /metrics", s.writeMetrics)
	return mux
}

type metrics struct {
	mu          sync.Mutex
	requests    map[[2]string]int64
	seconds     float64
	count       int64
	auditErrors atomicCounter
}

type atomicCounter struct {
	mu sync.Mutex
	n  int64
}

func (a *atomicCounter) Add(n int64) { a.mu.Lock(); a.n += n; a.mu.Unlock() }
func (a *atomicCounter) Load() int64 { a.mu.Lock(); defer a.mu.Unlock(); return a.n }

func (m *metrics) init() { m.requests = map[[2]string]int64{} }

func (m *metrics) observe(outcome, reason string, d time.Duration) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.requests[[2]string{outcome, reason}]++
	m.seconds += d.Seconds()
	m.count++
}

func (s *Service) writeMetrics(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "text/plain; version=0.0.4")
	m := &s.metrics
	m.mu.Lock()
	keys := make([][2]string, 0, len(m.requests))
	for k := range m.requests {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool { return keys[i][0]+keys[i][1] < keys[j][0]+keys[j][1] })
	fmt.Fprintln(w, "# HELP sts_requests_total Token-exchange requests by outcome and refusal reason.")
	fmt.Fprintln(w, "# TYPE sts_requests_total counter")
	for _, k := range keys {
		fmt.Fprintf(w, "sts_requests_total{outcome=%q,reason=%q} %d\n", k[0], k[1], m.requests[k])
	}
	fmt.Fprintln(w, "# TYPE sts_request_duration_seconds summary")
	fmt.Fprintf(w, "sts_request_duration_seconds_sum %g\nsts_request_duration_seconds_count %d\n", m.seconds, m.count)
	m.mu.Unlock()
	pol, deny := s.policy.Get(), s.deny.Get()
	fmt.Fprintln(w, "# HELP sts_policy_info The policy in force, by hash.")
	fmt.Fprintln(w, "# TYPE sts_policy_info gauge")
	fmt.Fprintf(w, "sts_policy_info{hash=%q} 1\n", pol.Hash)
	fmt.Fprintln(w, "# TYPE sts_policy_reload_errors_total counter")
	fmt.Fprintf(w, "sts_policy_reload_errors_total %d\n", s.policy.Errors())
	fmt.Fprintln(w, "# TYPE sts_deny_list_info gauge")
	fmt.Fprintf(w, "sts_deny_list_info{hash=%q} %d\n", deny.Hash, deny.Value.Len())
	fmt.Fprintln(w, "# TYPE sts_deny_list_reload_errors_total counter")
	fmt.Fprintf(w, "sts_deny_list_reload_errors_total %d\n", s.deny.Errors())
	fmt.Fprintln(w, "# TYPE sts_kms_last_success_timestamp_seconds gauge")
	fmt.Fprintf(w, "sts_kms_last_success_timestamp_seconds %d\n", s.keys.LastSuccess().Unix())
	fmt.Fprintln(w, "# TYPE sts_audit_write_errors_total counter")
	fmt.Fprintf(w, "sts_audit_write_errors_total %d\n", m.auditErrors.Load())
	if s.audit.Exporting() {
		fmt.Fprintln(w, "# HELP sts_audit_exported_total Audit records the collector took.")
		fmt.Fprintln(w, "# TYPE sts_audit_exported_total counter")
		fmt.Fprintf(w, "sts_audit_exported_total %d\n", s.audit.Exported())
		fmt.Fprintln(w, "# HELP sts_audit_diverted_total Audit records written to standard output because the collector did not take them or was failing.")
		fmt.Fprintln(w, "# TYPE sts_audit_diverted_total counter")
		fmt.Fprintf(w, "sts_audit_diverted_total %d\n", s.audit.Diverted())
	}
	if is, ok := s.introspect.(introspectionStats); ok {
		st := is.Stats()
		fmt.Fprintln(w, "# HELP sts_introspection_cache_total Subject-token introspections by whether the cache answered (hit) or Keycloak was asked (miss).")
		fmt.Fprintln(w, "# TYPE sts_introspection_cache_total counter")
		fmt.Fprintf(w, "sts_introspection_cache_total{result=\"hit\"} %d\n", st.Hits)
		fmt.Fprintf(w, "sts_introspection_cache_total{result=\"miss\"} %d\n", st.Misses)
		fmt.Fprintln(w, "# HELP sts_introspection_request_duration_seconds Introspection requests to Keycloak, failed ones included.")
		fmt.Fprintln(w, "# TYPE sts_introspection_request_duration_seconds summary")
		fmt.Fprintf(w, "sts_introspection_request_duration_seconds_sum %g\nsts_introspection_request_duration_seconds_count %d\n", st.Seconds, st.Requests)
		fmt.Fprintln(w, "# TYPE sts_introspection_request_errors_total counter")
		fmt.Fprintf(w, "sts_introspection_request_errors_total %d\n", st.Errors)
	}
}
