package sts

import (
	"context"
	"crypto"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"fmt"
	"mime"
	"net/http"
	"net/url"
	"slices"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/audit"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/jwt"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/keycloak"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/kube"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/policy"
)

// RFC 8693 and the exchange profile in agent-sdk's spec/exchange.
const (
	grantTokenExchange = "urn:ietf:params:oauth:grant-type:token-exchange"
	typeAccessToken    = "urn:ietf:params:oauth:token-type:access_token"
	typeJWT            = "urn:ietf:params:oauth:token-type:jwt"
	maxBody            = 64 << 10
	maxChainDepth      = 16 // act nesting the STS reads before calling a chain too long
)

// request is one exchange as it passes the checks.
type request struct {
	form      url.Values
	pol       *policy.Policy
	now       time.Time
	name      string // the agent's name in the policy
	agent     policy.Agent
	canonical string // <cluster>/<namespace>/<service account>
	subject   *jwt.Token
	raw       string // the subject token
	own       bool   // the subject is one of the STS's own chain tokens
	chain     []string
	exp       int64
	target    string
}

// exchange runs the checks in the contract's fixed order, request, actor,
// subject, chain, resource, and issues if all pass. It returns the
// response body, or the first refusal, and fills rec as it learns.
// The policy is the one whose hash the audit record carries, so a reload
// mid-request cannot make the record name another.
func (s *Service) exchange(ctx context.Context, r *http.Request, rec audit.Record, pol *policy.Policy) (map[string]any, *refusal) {
	q := &request{pol: pol, now: time.Now()}
	if ref := s.checkRequest(r, q, rec); ref != nil {
		return nil, ref
	}
	if ref := s.checkActor(ctx, q, rec); ref != nil {
		return nil, ref
	}
	if ref := s.checkSubject(ctx, q, rec); ref != nil {
		return nil, ref
	}
	if ref := s.checkChain(q); ref != nil {
		return nil, ref
	}
	if ref := s.checkResource(q); ref != nil {
		return nil, ref
	}
	return s.issue(ctx, q, rec)
}

func (s *Service) checkRequest(r *http.Request, q *request, rec audit.Record) *refusal {
	rec.List("request.resource", nil)
	if r.Method != http.MethodPost {
		return refuse(requestMalformed, "method "+r.Method)
	}
	if ct, _, err := mime.ParseMediaType(r.Header.Get("Content-Type")); err != nil || ct != "application/x-www-form-urlencoded" {
		return refuse(requestMalformed, "content type "+r.Header.Get("Content-Type"))
	}
	r.Body = http.MaxBytesReader(nil, r.Body, maxBody)
	if err := r.ParseForm(); err != nil {
		return refuse(requestMalformed, "form: "+err.Error())
	}
	q.form = r.PostForm
	rec.List("request.resource", q.form["resource"])
	for _, name := range []string{"grant_type", "subject_token", "subject_token_type", "actor_token", "actor_token_type", "requested_token_type", "audience"} {
		if len(q.form[name]) > 1 {
			return refuse(requestMalformed, name+" repeated")
		}
	}
	get := q.form.Get
	switch {
	case get("grant_type") != grantTokenExchange:
		return refuse(requestMalformed, "grant_type "+get("grant_type"))
	case get("subject_token") == "":
		return refuse(requestMalformed, "no subject_token")
	case get("subject_token_type") != typeAccessToken:
		return refuse(requestMalformed, "subject_token_type "+get("subject_token_type"))
	case q.form.Has("actor_token_type") != q.form.Has("actor_token"):
		return refuse(requestMalformed, "actor_token_type without actor_token, or the reverse")
	case q.form.Has("actor_token_type") && get("actor_token_type") != typeJWT:
		return refuse(requestMalformed, "actor_token_type "+get("actor_token_type"))
	case q.form.Has("requested_token_type") && get("requested_token_type") != typeAccessToken:
		return refuse(requestMalformed, "requested_token_type "+get("requested_token_type"))
	case q.form.Has("audience"):
		return refuse(requestMalformed, "audience parameter; send resource")
	}
	return nil
}

// checkActor identifies the agent. Its token is decoded unverified only to
// tell an expired or misdirected token from a forged one; identity comes
// from TokenReview alone.
func (s *Service) checkActor(ctx context.Context, q *request, rec audit.Record) *refusal {
	token := q.form.Get("actor_token")
	if token == "" {
		return refuse(actorMissing, "")
	}
	issuer := s.cfg.Issuer
	if t, err := jwt.Parse(token); err == nil {
		if aud, ok := jwt.Audiences(t.Claims["aud"]); ok && !slices.Contains(aud, issuer) {
			return refuse(actorAudience, fmt.Sprintf("aud %v", aud))
		}
		if exp, ok := jwt.Int(t.Claims["exp"]); ok && q.now.Unix() > exp+int64(s.cfg.Timing.Leeway.Seconds()) {
			return refuse(actorExpired, fmt.Sprintf("expired %ds ago", q.now.Unix()-exp))
		}
	}
	res, err := s.review.Review(ctx, token, []string{issuer})
	if err != nil {
		return refuse(dependencyUnavailable, "TokenReview: "+err.Error())
	}
	if !res.Authenticated || !slices.Contains(res.Audiences, issuer) {
		return refuse(actorRejected, "TokenReview: "+res.Error)
	}
	sa, ok := kube.ServiceAccount(res.Username)
	if !ok {
		return refuse(actorRejected, "not a service account: "+res.Username)
	}
	q.canonical = policy.CanonicalActor(sa, s.cfg.Cluster)
	rec.Str("actor.sub", q.canonical)
	rec.Str("actor.pod", res.Pod)
	if q.name, ok = q.pol.AgentByActor(sa); !ok {
		return refuse(actorUnknown, sa)
	}
	q.agent = q.pol.Agents[q.name]
	if ok, wait := s.limits.allow(q.name, q.pol.RateLimit.PerSecond, q.pol.RateLimit.Burst, q.now); !ok {
		ref := refuse(rateLimited, q.name)
		ref.RetryAfter = wait
		return ref
	}
	return nil
}

// checkSubject verifies the subject token: its issuer first, so an
// untrusted one costs no key lookup, then its signature, type and times,
// then the agent's routes and the deny list, and last, for Keycloak's
// tokens, introspection, the one call that costs Keycloak.
func (s *Service) checkSubject(ctx context.Context, q *request, rec audit.Record) *refusal {
	q.raw = q.form.Get("subject_token")
	t, err := jwt.Parse(q.raw)
	if err != nil {
		return refuse(subjectSignature, "unparseable: "+err.Error())
	}
	q.subject = t
	iss := jwt.Str(t.Claims, "iss")
	rec.Str("subject.iss", iss)
	rec.Str("subject.jti", jwt.Str(t.Claims, "jti"))
	switch iss {
	case s.cfg.Issuer:
		q.own = true
	case s.cfg.Keycloak.Issuer:
	default:
		return refuse(subjectIssuer, iss)
	}
	kid := jwt.Str(t.Header, "kid")
	var key crypto.PublicKey
	if q.own {
		pub, found, err := s.keys.Key(kid)
		if err != nil {
			return refuse(dependencyUnavailable, "own keys: "+err.Error())
		}
		if !found {
			return refuse(subjectSignature, "unknown own kid "+kid)
		}
		key = pub
	} else {
		key, err = s.subjects.Key(ctx, kid)
		if errors.Is(err, keycloak.ErrUnavailable) {
			return refuse(dependencyUnavailable, err.Error())
		}
		if err != nil {
			return refuse(subjectSignature, "kid "+kid+": "+err.Error())
		}
	}
	if err := t.Verify(key); err != nil {
		return refuse(subjectSignature, err.Error())
	}
	if typ := strings.ToLower(jwt.Str(t.Header, "typ")); typ != "at+jwt" && typ != "application/at+jwt" {
		return refuse(subjectType, "typ "+typ)
	}
	sub := jwt.Str(t.Claims, "sub")
	exp, hasExp := jwt.Int(t.Claims["exp"])
	if sub == "" || !hasExp {
		return refuse(subjectType, "no sub or exp")
	}
	q.exp = exp
	// No leeway on exp: the chain token's exp is the subject's at most, so
	// a subject past its exp could only yield a token dead on arrival.
	if q.now.Unix() >= exp {
		return refuse(subjectExpired, fmt.Sprintf("expired %ds ago", q.now.Unix()-exp))
	}
	if nbf, ok := jwt.Int(t.Claims["nbf"]); ok && nbf > q.now.Unix()+int64(s.cfg.Timing.Leeway.Seconds()) {
		return refuse(subjectNotYetValid, fmt.Sprintf("nbf %ds ahead", nbf-q.now.Unix()))
	}
	rec.Str("user.id", sub)
	rec.Str("user.team", jwt.Str(t.Claims, "team"))
	rec.Str("session.id", jwt.Str(t.Claims, "sid"))
	_, hasAct := t.Claims["act"]
	switch {
	case !q.own && hasAct:
		return refuse(subjectForeignAct, "")
	case q.own:
		if q.chain, err = actChain(t.Claims["act"]); err != nil || len(q.chain) == 0 {
			return refuse(chainLength, fmt.Sprintf("own token's act: %v", err))
		}
	}
	rec.List("actor.chain", q.chain)
	aud, ok := jwt.Audiences(t.Claims["aud"])
	if !ok || len(aud) != 1 || !slices.Contains(s.urls(q.agent.Routes), aud[0]) {
		return refuse(subjectAudience, fmt.Sprintf("aud %v for %s", t.Claims["aud"], q.name))
	}
	if s.deny.Get().Value.Denied(sub, q.now, time.Duration(q.pol.TokenTTLSeconds)*time.Second, s.cfg.Timing.Leeway.Duration) {
		return refuse(subjectDenied, "")
	}
	if !q.own {
		active, err := s.introspect.Active(ctx, q.raw, time.Unix(exp, 0))
		if err != nil {
			return refuse(dependencyUnavailable, err.Error())
		}
		if !active {
			return refuse(subjectInactive, "")
		}
	}
	return nil
}

// checkChain applies the order rules: the subject's current actor must be
// in the agent's after, the agent must not be in the chain yet, and the
// new chain must fit max_chain.
func (s *Service) checkChain(q *request) *refusal {
	current := policy.Person
	if q.own {
		current = ""
		for _, n := range q.pol.AgentNames() {
			if policy.CanonicalActor(q.pol.Agents[n].Actor, s.cfg.Cluster) == q.chain[0] {
				current = n
			}
		}
	}
	if current == "" || !q.agent.Admits(current) {
		return refuse(chainPredecessor, fmt.Sprintf("%s after %q", q.name, current))
	}
	if slices.Contains(q.chain, q.canonical) {
		return refuse(chainRepeat, q.canonical)
	}
	if len(q.chain)+1 > q.pol.MaxChain {
		return refuse(chainLength, fmt.Sprintf("%d agents", len(q.chain)+1))
	}
	return nil
}

func (s *Service) checkResource(q *request) *refusal {
	res := q.form["resource"]
	switch {
	case len(res) == 0:
		return refuse(resourceMissing, "")
	case len(res) > 1:
		return refuse(resourceMultiple, fmt.Sprintf("%d", len(res)))
	case !slices.Contains(s.urls(q.agent.Targets), res[0]):
		return refuse(resourceNotAllowed, res[0])
	}
	q.target = res[0]
	return nil
}

// issue signs the chain token: the person in sub, the agent as the
// outermost act with the subject's chain nested inside it unchanged, the
// one resource as aud, and the policy's carried claims copied unchanged.
func (s *Service) issue(ctx context.Context, q *request, rec audit.Record) (map[string]any, *refusal) {
	now := q.now.Unix()
	exp := min(now+int64(q.pol.TokenTTLSeconds), q.exp)
	act := map[string]any{"sub": q.canonical}
	if q.own {
		act["act"] = q.subject.Claims["act"]
	}
	jti := make([]byte, 16)
	if _, err := rand.Read(jti); err != nil {
		return nil, refuse(dependencyUnavailable, "random: "+err.Error())
	}
	claims := map[string]any{
		"iss": s.cfg.Issuer, "sub": q.subject.Claims["sub"], "aud": q.target, "client_id": q.canonical, "act": act,
		"iat": now, "nbf": now, "exp": exp, "jti": base64.RawURLEncoding.EncodeToString(jti),
	}
	for _, name := range q.pol.CarriedClaims {
		if v, ok := q.subject.Claims[name]; ok {
			claims[name] = v
		}
	}
	token, kid, err := s.keys.Sign(ctx, map[string]any{"typ": "at+jwt"}, claims)
	if err != nil {
		return nil, refuse(dependencyUnavailable, "signing: "+err.Error())
	}
	rec.List("actor.chain", append([]string{q.canonical}, q.chain...))
	rec.Str("token.jti", claims["jti"].(string))
	rec.Str("token.aud", q.target)
	rec.Int("token.exp", exp)
	rec.Str("token.kid", kid)
	return map[string]any{
		"access_token":      token,
		"issued_token_type": typeAccessToken,
		"token_type":        "Bearer",
		"expires_in":        exp - now,
	}, nil
}

// urls expands policy routes into the audiences the STS compares exactly.
func (s *Service) urls(routes []string) []string {
	out := make([]string, len(routes))
	for i, r := range routes {
		out[i] = policy.RouteURL(r, s.cfg.PlatformDomain)
	}
	return out
}

// actChain lists the act.sub values outermost first.
func actChain(v any) ([]string, error) {
	var out []string
	for v != nil {
		if len(out) == maxChainDepth {
			return out, errors.New("act nested too deep")
		}
		m, ok := v.(map[string]any)
		if !ok {
			return out, errors.New("act is not an object")
		}
		sub, _ := m["sub"].(string)
		if sub == "" {
			return out, errors.New("act without sub")
		}
		out = append(out, sub)
		v = m["act"]
	}
	return out, nil
}
