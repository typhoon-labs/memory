package otlp

import (
	"context"
	"errors"
	"net/http"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp/otlpfake"
)

// failing fails the first n round trips before any response, as a
// connection the collector's restart closed does.
type failing struct {
	n    int
	next http.RoundTripper
}

func (f *failing) RoundTrip(r *http.Request) (*http.Response, error) {
	if f.n > 0 {
		f.n--
		return nil, errors.New("write: broken pipe")
	}
	return f.next.RoundTrip(r)
}

func TestRetriesOnceBeforeAResponse(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	c, err := New(fake.URL, "s", time.Second)
	if err != nil {
		t.Fatal(err)
	}
	c.http.Transport = &failing{n: 1, next: c.http.Transport}
	if err := c.Export(context.Background(), Record{Attributes: map[string]any{"a": "b"}}); err != nil {
		t.Fatalf("one failure before a response: %v", err)
	}
	if len(fake.Logs()) != 1 {
		t.Fatalf("%d records arrived, want 1", len(fake.Logs()))
	}
	c.http.Transport = &failing{n: 2, next: c.http.Transport.(*failing).next}
	if err := c.Export(context.Background(), Record{}); err == nil {
		t.Fatal("two failures in a row succeeded")
	}
	if fake.Calls() != 1 {
		t.Errorf("%d calls reached the fake, want 1", fake.Calls())
	}
	// A failure with a response is the collector's answer, never retried.
	fake.SetMode(otlpfake.Unavailable)
	c.http.Transport = c.http.Transport.(*failing).next
	if err := c.Export(context.Background(), Record{}); err == nil {
		t.Fatal("grpc-status 14 succeeded")
	}
	if fake.Calls() != 2 {
		t.Errorf("%d calls reached the fake, want 2: a gRPC error was retried", fake.Calls())
	}
}
