// Package otlp exports log records to an OpenTelemetry collector over OTLP
// with gRPC, the protocol of the collector's platform port, 4319
// (plan/local-build.md, "B3 in detail"), with the standard library alone.
//
// One Export is one unary call of the logs service's Export method: the
// request is ExportLogsServiceRequest, encoded by hand in protobuf's wire
// format, framed as gRPC frames a message, and sent over HTTP/2 without TLS
// (prior knowledge, as gRPC does), since the mesh's sidecars add mutual
// TLS. The call succeeds only when the response is HTTP 200 with
// grpc-status 0 and the collector rejected no record.
package otlp

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"
)

// ExportPath is the logs service's Export method.
const ExportPath = "/opentelemetry.proto.collector.logs.v1.LogsService/Export"

// Record is one log record. Its severity is always INFO.
type Record struct {
	// Time is when the event happened.
	Time time.Time
	// TraceID and SpanID are the record's trace context, 16 and 8 bytes,
	// or nil when it has none.
	TraceID, SpanID []byte
	// Attributes are the record's attributes. A value is a string, a bool,
	// an integer, a float, json.Number, a []string, a []any or a
	// map[string]any; a nil value is left out, and any other type is sent
	// as its JSON text.
	Attributes map[string]any
}

// Client exports log records to one endpoint.
type Client struct {
	url     string
	agent   string
	timeout time.Duration
	http    *http.Client
	head    []byte // the encoded Resource and InstrumentationScope's prefix
}

// ParseEndpoint checks an endpoint: http://<host>:<port>, with no path,
// query, fragment or user. TLS is the mesh's, so https is refused.
func ParseEndpoint(endpoint string) (*url.URL, error) {
	u, err := url.Parse(endpoint)
	if err != nil {
		return nil, err
	}
	if u.Scheme != "http" || u.Hostname() == "" || u.Port() == "" || u.User != nil ||
		(u.Path != "" && u.Path != "/") || u.RawQuery != "" || u.Fragment != "" {
		return nil, fmt.Errorf("%q must be http://<host>:<port> with no path, query or user", endpoint)
	}
	return u, nil
}

// New returns a client for endpoint (see ParseEndpoint) that names service
// as the records' service.name and bounds each export by timeout.
func New(endpoint, service string, timeout time.Duration) (*Client, error) {
	u, err := ParseEndpoint(endpoint)
	if err != nil {
		return nil, err
	}
	if timeout <= 0 {
		return nil, errors.New("the export timeout must be positive")
	}
	protocols := new(http.Protocols)
	protocols.SetUnencryptedHTTP2(true)
	transport := &http.Transport{
		Protocols:   protocols,
		Proxy:       nil, // a pod's collector is never behind a proxy
		DialContext: (&net.Dialer{Timeout: timeout, KeepAlive: 30 * time.Second}).DialContext,
	}
	return &Client{
		url:     "http://" + u.Host + ExportPath,
		agent:   service,
		timeout: timeout,
		http:    &http.Client{Transport: transport},
		head:    encodeHead(service),
	}, nil
}

// Export sends the records in one call. It returns an error when the
// collector did not accept every record, or did not answer within the
// client's timeout. A call that fails before any response, as one on a
// connection the collector's restart closed does, is made once more within
// the same timeout, so the collector may get a record twice when the first
// call reached it.
func (c *Client) Export(ctx context.Context, recs ...Record) error {
	ctx, cancel := context.WithTimeout(ctx, c.timeout)
	defer cancel()
	msg := encodeRequest(c.head, recs)
	frame := make([]byte, 5, 5+len(msg))
	binary.BigEndian.PutUint32(frame[1:], uint32(len(msg)))
	frame = append(frame, msg...)
	var resp *http.Response
	for attempt := 0; ; attempt++ {
		req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.url, bytes.NewReader(frame))
		if err != nil {
			return err
		}
		req.Header.Set("Content-Type", "application/grpc")
		req.Header.Set("Te", "trailers")
		req.Header.Set("Grpc-Timeout", strconv.FormatInt(max(c.timeout.Milliseconds(), 1), 10)+"m")
		req.Header.Set("User-Agent", c.agent)
		resp, err = c.http.Do(req)
		if err == nil {
			break
		}
		if attempt > 0 || ctx.Err() != nil {
			return fmt.Errorf("otlp export: %w", err)
		}
	}
	defer resp.Body.Close()
	// The trailers arrive only once the body is read to its end.
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return fmt.Errorf("otlp export: reading the response: %w", err)
	}
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("otlp export: HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(body[:min(len(body), 200)])))
	}
	status := resp.Trailer.Get("Grpc-Status")
	message := resp.Trailer.Get("Grpc-Message")
	if status == "" { // a trailers-only response carries them as headers
		status, message = resp.Header.Get("Grpc-Status"), resp.Header.Get("Grpc-Message")
	}
	if status == "" {
		return errors.New("otlp export: the response carries no grpc-status")
	}
	if status != "0" {
		if m, err := url.PathUnescape(message); err == nil {
			message = m
		}
		return fmt.Errorf("otlp export: grpc-status %s: %s", status, message)
	}
	rejected, reason, err := decodeResponse(body)
	if err != nil {
		return fmt.Errorf("otlp export: %w", err)
	}
	if rejected > 0 {
		return fmt.Errorf("otlp export: the collector rejected %d of %d records: %s", rejected, len(recs), reason)
	}
	return nil
}

// Protobuf field numbers of opentelemetry-proto's logs, common and
// resource messages, and of the collector's logs service.
const (
	requestResourceLogs = 1 // ExportLogsServiceRequest.resource_logs

	resourceLogsResource  = 1 // ResourceLogs.resource
	resourceLogsScopeLogs = 2 // ResourceLogs.scope_logs

	resourceAttributes = 1 // Resource.attributes

	scopeLogsScope   = 1 // ScopeLogs.scope
	scopeLogsRecords = 2 // ScopeLogs.log_records

	scopeName = 1 // InstrumentationScope.name

	logTime           = 1  // LogRecord.time_unix_nano, fixed64
	logSeverityNumber = 2  // LogRecord.severity_number
	logSeverityText   = 3  // LogRecord.severity_text
	logAttributes     = 6  // LogRecord.attributes
	logTraceID        = 9  // LogRecord.trace_id
	logSpanID         = 10 // LogRecord.span_id
	logObservedTime   = 11 // LogRecord.observed_time_unix_nano, fixed64

	keyValueKey   = 1 // KeyValue.key
	keyValueValue = 2 // KeyValue.value

	anyString = 1 // AnyValue.string_value
	anyBool   = 2 // AnyValue.bool_value
	anyInt    = 3 // AnyValue.int_value
	anyDouble = 4 // AnyValue.double_value
	anyArray  = 5 // AnyValue.array_value
	anyKVList = 6 // AnyValue.kvlist_value

	listValues = 1 // ArrayValue.values and KeyValueList.values

	responsePartialSuccess = 1 // ExportLogsServiceResponse.partial_success
	partialRejected        = 1 // ExportLogsPartialSuccess.rejected_log_records
	partialMessage         = 2 // ExportLogsPartialSuccess.error_message

	severityInfo = 9 // SeverityNumber SEVERITY_NUMBER_INFO
)

// Protobuf wire types.
const (
	wireVarint  = 0
	wireFixed64 = 1
	wireBytes   = 2
	wireFixed32 = 5
)

type pb []byte

func (b *pb) varint(v uint64) { *b = binary.AppendUvarint(*b, v) }

func (b *pb) tag(field, wire int) { b.varint(uint64(field)<<3 | uint64(wire)) }

func (b *pb) bytes(field int, p []byte) {
	b.tag(field, wireBytes)
	b.varint(uint64(len(p)))
	*b = append(*b, p...)
}

func (b *pb) string(field int, s string) {
	b.tag(field, wireBytes)
	b.varint(uint64(len(s)))
	*b = append(*b, s...)
}

func (b *pb) uvarint(field int, v uint64) {
	b.tag(field, wireVarint)
	b.varint(v)
}

func (b *pb) fixed64(field int, v uint64) {
	b.tag(field, wireFixed64)
	*b = binary.LittleEndian.AppendUint64(*b, v)
}

// encodeHead encodes what every request repeats: the ResourceLogs'
// resource, with service.name.
func encodeHead(service string) []byte {
	var res pb
	res.bytes(resourceAttributes, encodeKeyValue("service.name", service))
	var head pb
	head.bytes(resourceLogsResource, res)
	return head
}

// encodeRequest encodes an ExportLogsServiceRequest: one ResourceLogs, the
// head, with one ScopeLogs, named audit, holding recs.
func encodeRequest(head []byte, recs []Record) []byte {
	var scope pb
	scope.string(scopeName, "audit")
	var scopeLogs pb
	scopeLogs.bytes(scopeLogsScope, scope)
	for _, r := range recs {
		scopeLogs.bytes(scopeLogsRecords, encodeRecord(r))
	}
	resourceLogs := append(pb(nil), head...)
	resourceLogs.bytes(resourceLogsScopeLogs, scopeLogs)
	var req pb
	req.bytes(requestResourceLogs, resourceLogs)
	return req
}

func encodeRecord(r Record) []byte {
	var b pb
	if !r.Time.IsZero() {
		b.fixed64(logTime, uint64(r.Time.UnixNano()))
	}
	b.uvarint(logSeverityNumber, severityInfo)
	b.string(logSeverityText, "INFO")
	keys := make([]string, 0, len(r.Attributes))
	for k, v := range r.Attributes {
		if v != nil {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	for _, k := range keys {
		b.bytes(logAttributes, encodeKeyValue(k, r.Attributes[k]))
	}
	if len(r.TraceID) == 16 {
		b.bytes(logTraceID, r.TraceID)
	}
	if len(r.SpanID) == 8 {
		b.bytes(logSpanID, r.SpanID)
	}
	b.fixed64(logObservedTime, uint64(time.Now().UnixNano()))
	return b
}

func encodeKeyValue(key string, v any) []byte {
	var b pb
	b.string(keyValueKey, key)
	b.bytes(keyValueValue, encodeAny(v))
	return b
}

// encodeAny encodes an AnyValue. A nil value is an AnyValue with no value
// set; an empty list is an empty ArrayValue, present.
func encodeAny(v any) []byte {
	var b pb
	switch x := v.(type) {
	case nil:
	case string:
		b.string(anyString, x)
	case bool:
		var n uint64
		if x {
			n = 1
		}
		b.uvarint(anyBool, n)
	case int:
		b.uvarint(anyInt, uint64(int64(x)))
	case int32:
		b.uvarint(anyInt, uint64(int64(x)))
	case int64:
		b.uvarint(anyInt, uint64(x))
	case uint32:
		b.uvarint(anyInt, uint64(x))
	case float64:
		b.fixed64(anyDouble, math.Float64bits(x))
	case float32:
		b.fixed64(anyDouble, math.Float64bits(float64(x)))
	case json.Number:
		if n, err := x.Int64(); err == nil {
			return encodeAny(n)
		}
		if f, err := x.Float64(); err == nil {
			return encodeAny(f)
		}
		b.string(anyString, x.String())
	case []string:
		var list pb
		for _, s := range x {
			list.bytes(listValues, encodeAny(s))
		}
		b.bytes(anyArray, list)
	case []any:
		var list pb
		for _, e := range x {
			list.bytes(listValues, encodeAny(e))
		}
		b.bytes(anyArray, list)
	case map[string]any:
		keys := make([]string, 0, len(x))
		for k := range x {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		var list pb
		for _, k := range keys {
			list.bytes(listValues, encodeKeyValue(k, x[k]))
		}
		b.bytes(anyKVList, list)
	default:
		text, err := json.Marshal(x)
		if err != nil {
			text = []byte(fmt.Sprint(x))
		}
		b.string(anyString, string(text))
	}
	return b
}

// decodeResponse reads the gRPC frames of an ExportLogsServiceResponse and
// returns its partial success: how many records the collector rejected,
// and why.
func decodeResponse(body []byte) (rejected int64, reason string, err error) {
	for len(body) > 0 {
		if len(body) < 5 {
			return 0, "", errors.New("a truncated gRPC frame")
		}
		if body[0] != 0 {
			return 0, "", errors.New("a compressed gRPC frame, which was not asked for")
		}
		n := binary.BigEndian.Uint32(body[1:5])
		if uint64(len(body)-5) < uint64(n) {
			return 0, "", errors.New("a truncated gRPC frame")
		}
		msg := body[5 : 5+n]
		body = body[5+n:]
		err := walk(msg, func(field int, v uint64, p []byte) error {
			if field != responsePartialSuccess || p == nil {
				return nil
			}
			return walk(p, func(field int, v uint64, p []byte) error {
				switch {
				case field == partialRejected && p == nil:
					rejected = int64(v)
				case field == partialMessage && p != nil:
					reason = string(p)
				}
				return nil
			})
		})
		if err != nil {
			return 0, "", err
		}
	}
	return rejected, reason, nil
}

// walk calls fn for each field of a protobuf message: v for a varint or
// fixed field, p (non-nil) for a length-delimited one.
func walk(msg []byte, fn func(field int, v uint64, p []byte) error) error {
	for len(msg) > 0 {
		key, n := binary.Uvarint(msg)
		if n <= 0 {
			return errors.New("a malformed protobuf key")
		}
		msg = msg[n:]
		field := int(key >> 3)
		switch key & 7 {
		case wireVarint:
			v, n := binary.Uvarint(msg)
			if n <= 0 {
				return errors.New("a malformed protobuf varint")
			}
			msg = msg[n:]
			if err := fn(field, v, nil); err != nil {
				return err
			}
		case wireFixed64:
			if len(msg) < 8 {
				return errors.New("a truncated protobuf fixed64")
			}
			v := binary.LittleEndian.Uint64(msg)
			msg = msg[8:]
			if err := fn(field, v, nil); err != nil {
				return err
			}
		case wireFixed32:
			if len(msg) < 4 {
				return errors.New("a truncated protobuf fixed32")
			}
			v := binary.LittleEndian.Uint32(msg)
			msg = msg[4:]
			if err := fn(field, uint64(v), nil); err != nil {
				return err
			}
		case wireBytes:
			l, n := binary.Uvarint(msg)
			if n <= 0 || uint64(len(msg)-n) < l {
				return errors.New("a truncated protobuf field")
			}
			p := msg[n : n+int(l)]
			msg = msg[n+int(l):]
			if p == nil {
				p = []byte{}
			}
			if err := fn(field, 0, p); err != nil {
				return err
			}
		default:
			return fmt.Errorf("an unsupported protobuf wire type %d", key&7)
		}
	}
	return nil
}
