// Package otlpfake is a fake OpenTelemetry collector for tests: an OTLP
// logs endpoint over gRPC, on HTTP/2 without TLS only, as the collector's
// platform port takes it. It decodes each request from protobuf's wire
// format on its own, written from opentelemetry-proto's messages rather
// than from package otlp's encoder, and can be told to fail as a collector
// or its sidecar does.
package otlpfake

import (
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"math"
	"net/http"
	"net/http/httptest"
	"sync"
	"time"
)

// Mode is how the fake answers.
type Mode int

const (
	// Accept takes every record.
	Accept Mode = iota
	// HTTPUnavailable answers HTTP 503, as a sidecar with no healthy
	// upstream does.
	HTTPUnavailable
	// Unavailable answers grpc-status 14 in a trailers-only response.
	Unavailable
	// Reject accepts the call but rejects every record (partial success).
	Reject
	// Hang answers only once the caller gives up.
	Hang
)

// Log is one record as the fake decoded it.
type Log struct {
	Service        string // the resource's service.name
	Scope          string // the instrumentation scope's name
	Time           time.Time
	ObservedTime   time.Time
	SeverityNumber int
	SeverityText   string
	TraceID        string // lowercase hex, empty when absent
	SpanID         string
	HasBody        bool
	// Attributes hold string, bool, int64, float64, []any (an
	// ArrayValue, never nil), map[string]any (a KeyValueList) or nil (an
	// AnyValue with nothing set).
	Attributes map[string]any
}

// Server is the fake. Its URL is http://127.0.0.1:<port>.
type Server struct {
	URL string
	srv *httptest.Server

	mu       sync.Mutex
	mode     Mode
	calls    int
	logs     []Log
	problems []string
}

// Path is the logs service's Export method.
const Path = "/opentelemetry.proto.collector.logs.v1.LogsService/Export"

// New starts a fake that accepts every record.
func New() *Server {
	s := &Server{}
	s.srv = httptest.NewUnstartedServer(http.HandlerFunc(s.serve))
	s.srv.Config.Protocols = new(http.Protocols)
	s.srv.Config.Protocols.SetUnencryptedHTTP2(true)
	s.srv.Start()
	s.URL = s.srv.URL
	return s
}

// Close stops the fake; later calls find nothing listening.
func (s *Server) Close() { s.srv.CloseClientConnections(); s.srv.Close() }

// SetMode changes how the fake answers.
func (s *Server) SetMode(m Mode) { s.mu.Lock(); s.mode = m; s.mu.Unlock() }

// Calls is how many calls reached the fake, whatever it answered.
func (s *Server) Calls() int { s.mu.Lock(); defer s.mu.Unlock(); return s.calls }

// Logs are the records of the calls the fake accepted.
func (s *Server) Logs() []Log {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]Log(nil), s.logs...)
}

// Problems are the ways calls broke the protocol: a wrong method, path,
// header or framing, or a message that does not decode.
func (s *Server) Problems() []string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return append([]string(nil), s.problems...)
}

func (s *Server) problem(format string, args ...any) {
	s.mu.Lock()
	s.problems = append(s.problems, fmt.Sprintf(format, args...))
	s.mu.Unlock()
}

func (s *Server) serve(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	s.calls++
	mode := s.mode
	s.mu.Unlock()
	if r.ProtoMajor != 2 {
		s.problem("HTTP/%d.%d, not HTTP/2", r.ProtoMajor, r.ProtoMinor)
	}
	if r.Method != http.MethodPost || r.URL.Path != Path {
		s.problem("%s %s", r.Method, r.URL.Path)
		grpcStatus(w, 12, "unknown method")
		return
	}
	if ct := r.Header.Get("Content-Type"); ct != "application/grpc" && ct != "application/grpc+proto" {
		s.problem("content-type %q", ct)
	}
	if te := r.Header.Get("Te"); te != "trailers" {
		s.problem("te %q", te)
	}
	body, err := io.ReadAll(r.Body)
	if err != nil {
		s.problem("reading the body: %v", err)
		return
	}
	switch mode {
	case HTTPUnavailable:
		http.Error(w, "no healthy upstream", http.StatusServiceUnavailable)
		return
	case Unavailable:
		grpcStatus(w, 14, "the collector is shutting down")
		return
	case Hang:
		<-r.Context().Done()
		return
	}
	logs, err := decodeFrames(body)
	if err != nil {
		s.problem("decoding the request: %v", err)
		grpcStatus(w, 13, err.Error())
		return
	}
	var resp []byte
	if mode == Reject {
		var partial []byte
		partial = appendVarintField(partial, 1, uint64(len(logs)))
		partial = appendBytesField(partial, 2, []byte("rejected by the fake"))
		resp = appendBytesField(nil, 1, partial)
	} else {
		s.mu.Lock()
		s.logs = append(s.logs, logs...)
		s.mu.Unlock()
	}
	w.Header().Set("Content-Type", "application/grpc")
	w.Header().Set("Trailer", "Grpc-Status, Grpc-Message")
	w.WriteHeader(http.StatusOK)
	frame := make([]byte, 5, 5+len(resp))
	binary.BigEndian.PutUint32(frame[1:], uint32(len(resp)))
	w.Write(append(frame, resp...))
	w.Header().Set("Grpc-Status", "0")
	w.Header().Set("Grpc-Message", "")
}

// grpcStatus writes a trailers-only response.
func grpcStatus(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/grpc")
	w.Header().Set("Grpc-Status", fmt.Sprint(code))
	w.Header().Set("Grpc-Message", msg)
	w.WriteHeader(http.StatusOK)
}

func appendVarintField(b []byte, field int, v uint64) []byte {
	b = binary.AppendUvarint(b, uint64(field)<<3)
	return binary.AppendUvarint(b, v)
}

func appendBytesField(b []byte, field int, p []byte) []byte {
	b = binary.AppendUvarint(b, uint64(field)<<3|2)
	b = binary.AppendUvarint(b, uint64(len(p)))
	return append(b, p...)
}

func decodeFrames(body []byte) ([]Log, error) {
	var logs []Log
	frames := 0
	for len(body) > 0 {
		if len(body) < 5 {
			return nil, errors.New("truncated frame header")
		}
		if body[0] != 0 {
			return nil, errors.New("compressed frame")
		}
		n := int(binary.BigEndian.Uint32(body[1:5]))
		if len(body)-5 < n {
			return nil, errors.New("truncated frame")
		}
		got, err := decodeRequest(body[5 : 5+n])
		if err != nil {
			return nil, err
		}
		logs = append(logs, got...)
		body = body[5+n:]
		frames++
	}
	if frames != 1 {
		return nil, fmt.Errorf("%d frames in a unary call", frames)
	}
	return logs, nil
}

// field is one decoded protobuf field.
type field struct {
	num  int
	wire int
	v    uint64 // varint, fixed64 or fixed32
	p    []byte // length-delimited
}

func fields(msg []byte) ([]field, error) {
	var out []field
	for len(msg) > 0 {
		key, n := binary.Uvarint(msg)
		if n <= 0 {
			return nil, errors.New("bad key")
		}
		msg = msg[n:]
		f := field{num: int(key >> 3), wire: int(key & 7)}
		switch f.wire {
		case 0:
			f.v, n = binary.Uvarint(msg)
			if n <= 0 {
				return nil, errors.New("bad varint")
			}
			msg = msg[n:]
		case 1:
			if len(msg) < 8 {
				return nil, errors.New("short fixed64")
			}
			f.v, msg = binary.LittleEndian.Uint64(msg), msg[8:]
		case 5:
			if len(msg) < 4 {
				return nil, errors.New("short fixed32")
			}
			f.v, msg = uint64(binary.LittleEndian.Uint32(msg)), msg[4:]
		case 2:
			l, n := binary.Uvarint(msg)
			if n <= 0 || uint64(len(msg)-n) < l {
				return nil, errors.New("short bytes")
			}
			f.p, msg = msg[n:n+int(l)], msg[n+int(l):]
		default:
			return nil, fmt.Errorf("wire type %d", f.wire)
		}
		out = append(out, f)
	}
	return out, nil
}

// want checks a field's wire type against the proto's.
func want(f field, wire int, what string) error {
	if f.wire != wire {
		return fmt.Errorf("%s (field %d) has wire type %d, want %d", what, f.num, f.wire, wire)
	}
	return nil
}

// ExportLogsServiceRequest { repeated ResourceLogs resource_logs = 1; }
func decodeRequest(msg []byte) ([]Log, error) {
	fs, err := fields(msg)
	if err != nil {
		return nil, err
	}
	var logs []Log
	for _, f := range fs {
		if f.num != 1 {
			return nil, fmt.Errorf("unexpected request field %d", f.num)
		}
		if err := want(f, 2, "resource_logs"); err != nil {
			return nil, err
		}
		got, err := decodeResourceLogs(f.p)
		if err != nil {
			return nil, err
		}
		logs = append(logs, got...)
	}
	return logs, nil
}

// ResourceLogs { Resource resource = 1; repeated ScopeLogs scope_logs = 2; }
// Resource { repeated KeyValue attributes = 1; }
// ScopeLogs { InstrumentationScope scope = 1; repeated LogRecord log_records = 2; }
// InstrumentationScope { string name = 1; }
func decodeResourceLogs(msg []byte) ([]Log, error) {
	fs, err := fields(msg)
	if err != nil {
		return nil, err
	}
	service := ""
	var scopes [][]byte
	for _, f := range fs {
		switch f.num {
		case 1:
			if err := want(f, 2, "resource"); err != nil {
				return nil, err
			}
			attrs, err := decodeAttributes(f.p, 1)
			if err != nil {
				return nil, err
			}
			service, _ = attrs["service.name"].(string)
		case 2:
			if err := want(f, 2, "scope_logs"); err != nil {
				return nil, err
			}
			scopes = append(scopes, f.p)
		default:
			return nil, fmt.Errorf("unexpected ResourceLogs field %d", f.num)
		}
	}
	var logs []Log
	for _, sl := range scopes {
		fs, err := fields(sl)
		if err != nil {
			return nil, err
		}
		scope := ""
		for _, f := range fs {
			switch f.num {
			case 1:
				if err := want(f, 2, "scope"); err != nil {
					return nil, err
				}
				sf, err := fields(f.p)
				if err != nil {
					return nil, err
				}
				for _, s := range sf {
					if s.num == 1 && s.wire == 2 {
						scope = string(s.p)
					}
				}
			case 2:
				if err := want(f, 2, "log_records"); err != nil {
					return nil, err
				}
				l, err := decodeLogRecord(f.p)
				if err != nil {
					return nil, err
				}
				l.Service = service
				logs = append(logs, l)
			default:
				return nil, fmt.Errorf("unexpected ScopeLogs field %d", f.num)
			}
		}
		for i := len(logs) - 1; i >= 0 && logs[i].Scope == ""; i-- {
			logs[i].Scope = scope
		}
	}
	return logs, nil
}

// LogRecord { fixed64 time_unix_nano = 1; SeverityNumber severity_number = 2;
// string severity_text = 3; AnyValue body = 5; repeated KeyValue attributes = 6;
// bytes trace_id = 9; bytes span_id = 10; fixed64 observed_time_unix_nano = 11; }
func decodeLogRecord(msg []byte) (Log, error) {
	l := Log{Attributes: map[string]any{}}
	fs, err := fields(msg)
	if err != nil {
		return l, err
	}
	var attrs []byte
	for _, f := range fs {
		var err error
		switch f.num {
		case 1:
			if err = want(f, 1, "time_unix_nano"); err == nil {
				l.Time = time.Unix(0, int64(f.v)).UTC()
			}
		case 2:
			if err = want(f, 0, "severity_number"); err == nil {
				l.SeverityNumber = int(f.v)
			}
		case 3:
			if err = want(f, 2, "severity_text"); err == nil {
				l.SeverityText = string(f.p)
			}
		case 5:
			err = want(f, 2, "body")
			l.HasBody = true
		case 6:
			if err = want(f, 2, "attributes"); err == nil {
				attrs = appendBytesField(attrs, 1, f.p)
			}
		case 9:
			if err = want(f, 2, "trace_id"); err == nil {
				l.TraceID = hex.EncodeToString(f.p)
			}
		case 10:
			if err = want(f, 2, "span_id"); err == nil {
				l.SpanID = hex.EncodeToString(f.p)
			}
		case 11:
			if err = want(f, 1, "observed_time_unix_nano"); err == nil {
				l.ObservedTime = time.Unix(0, int64(f.v)).UTC()
			}
		default:
			err = fmt.Errorf("unexpected LogRecord field %d", f.num)
		}
		if err != nil {
			return l, err
		}
	}
	a, err := decodeAttributes(attrs, 1)
	if err != nil {
		return l, err
	}
	for k, v := range a {
		l.Attributes[k] = v
	}
	return l, nil
}

// decodeAttributes reads the repeated KeyValue field num of msg.
// KeyValue { string key = 1; AnyValue value = 2; }
func decodeAttributes(msg []byte, num int) (map[string]any, error) {
	fs, err := fields(msg)
	if err != nil {
		return nil, err
	}
	out := map[string]any{}
	for _, f := range fs {
		if f.num != num {
			continue
		}
		if err := want(f, 2, "KeyValue"); err != nil {
			return nil, err
		}
		kv, err := fields(f.p)
		if err != nil {
			return nil, err
		}
		key, haveKey := "", false
		var value any
		for _, x := range kv {
			switch x.num {
			case 1:
				if err := want(x, 2, "key"); err != nil {
					return nil, err
				}
				key, haveKey = string(x.p), true
			case 2:
				if err := want(x, 2, "value"); err != nil {
					return nil, err
				}
				if value, err = decodeAnyValue(x.p); err != nil {
					return nil, err
				}
			}
		}
		if !haveKey {
			return nil, errors.New("a KeyValue without a key")
		}
		if _, dup := out[key]; dup {
			return nil, fmt.Errorf("attribute %q twice", key)
		}
		out[key] = value
	}
	return out, nil
}

// AnyValue { oneof value { string string_value = 1; bool bool_value = 2;
// int64 int_value = 3; double double_value = 4; ArrayValue array_value = 5;
// KeyValueList kvlist_value = 6; bytes bytes_value = 7; } }
// ArrayValue { repeated AnyValue values = 1; }
// KeyValueList { repeated KeyValue values = 1; }
func decodeAnyValue(msg []byte) (any, error) {
	fs, err := fields(msg)
	if err != nil {
		return nil, err
	}
	if len(fs) > 1 {
		return nil, fmt.Errorf("an AnyValue with %d values set", len(fs))
	}
	if len(fs) == 0 {
		return nil, nil
	}
	f := fs[0]
	switch f.num {
	case 1:
		return string(f.p), want(f, 2, "string_value")
	case 2:
		return f.v != 0, want(f, 0, "bool_value")
	case 3:
		return int64(f.v), want(f, 0, "int_value")
	case 4:
		return math.Float64frombits(f.v), want(f, 1, "double_value")
	case 5:
		if err := want(f, 2, "array_value"); err != nil {
			return nil, err
		}
		items, err := fields(f.p)
		if err != nil {
			return nil, err
		}
		list := []any{}
		for _, it := range items {
			if it.num != 1 {
				return nil, fmt.Errorf("unexpected ArrayValue field %d", it.num)
			}
			v, err := decodeAnyValue(it.p)
			if err != nil {
				return nil, err
			}
			list = append(list, v)
		}
		return list, nil
	case 6:
		if err := want(f, 2, "kvlist_value"); err != nil {
			return nil, err
		}
		return decodeAttributes(f.p, 1)
	case 7:
		return f.p, want(f, 2, "bytes_value")
	}
	return nil, fmt.Errorf("unexpected AnyValue field %d", f.num)
}
