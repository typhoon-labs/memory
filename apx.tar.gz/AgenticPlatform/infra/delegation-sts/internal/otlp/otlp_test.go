package otlp_test

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"reflect"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp/otlpfake"
)

func client(t *testing.T, url string, timeout time.Duration) *otlp.Client {
	t.Helper()
	c, err := otlp.New(url, "delegation-sts", timeout)
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func TestRecordShape(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	at := time.Date(2026, 11, 16, 10, 0, 0, 123456789, time.UTC)
	trace, _ := hex.DecodeString("4bf92f3577b34da6a3ce929d0e0e4736")
	span, _ := hex.DecodeString("00f067aa0ba902b7")
	rec := otlp.Record{Time: at, TraceID: trace, SpanID: span, Attributes: map[string]any{
		"event.name":       "sts.token.issued",
		"actor.chain":      []string{"agentic-local/a/one", "agentic-local/b/two"},
		"request.resource": []string{},
		"roles":            []string(nil),
		"token.exp":        int64(1794830700),
		"count":            3,
		"ratio":            0.5,
		"dry_run":          false,
		"number":           json.Number("42"),
		"mixed":            []any{"a", int64(2), true, nil},
		"nested":           map[string]any{"k": "v", "n": 1},
		"left.out":         nil,
		"other":            struct{ A string }{"x"},
	}}
	before := time.Now()
	if err := client(t, fake.URL, time.Second).Export(context.Background(), rec, otlp.Record{Attributes: map[string]any{"event.name": "second"}}); err != nil {
		t.Fatal(err)
	}
	if p := fake.Problems(); len(p) > 0 {
		t.Fatalf("protocol problems: %v", p)
	}
	logs := fake.Logs()
	if len(logs) != 2 {
		t.Fatalf("%d records arrived, want 2", len(logs))
	}
	got := logs[0]
	if got.Service != "delegation-sts" || got.Scope != "audit" {
		t.Errorf("service %q, scope %q", got.Service, got.Scope)
	}
	if !got.Time.Equal(at) || got.ObservedTime.Before(before) {
		t.Errorf("time %v, observed %v", got.Time, got.ObservedTime)
	}
	if got.SeverityNumber != 9 || got.SeverityText != "INFO" || got.HasBody {
		t.Errorf("severity %d %q, body %v", got.SeverityNumber, got.SeverityText, got.HasBody)
	}
	if got.TraceID != "4bf92f3577b34da6a3ce929d0e0e4736" || got.SpanID != "00f067aa0ba902b7" {
		t.Errorf("trace context %s %s", got.TraceID, got.SpanID)
	}
	want := map[string]any{
		"event.name":       "sts.token.issued",
		"actor.chain":      []any{"agentic-local/a/one", "agentic-local/b/two"},
		"request.resource": []any{},
		"roles":            []any{},
		"token.exp":        int64(1794830700),
		"count":            int64(3),
		"ratio":            0.5,
		"dry_run":          false,
		"number":           int64(42),
		"mixed":            []any{"a", int64(2), true, nil},
		"nested":           map[string]any{"k": "v", "n": int64(1)},
		"other":            `{"A":"x"}`,
	}
	if !reflect.DeepEqual(got.Attributes, want) {
		t.Errorf("attributes\n got %#v\nwant %#v", got.Attributes, want)
	}
	if second := logs[1]; second.TraceID != "" || second.SpanID != "" || !second.Time.IsZero() || second.Attributes["event.name"] != "second" {
		t.Errorf("second record %+v", second)
	}
}

func TestExportFailures(t *testing.T) {
	for _, tc := range []struct {
		mode otlpfake.Mode
		want string
	}{
		{otlpfake.HTTPUnavailable, "HTTP 503"},
		{otlpfake.Unavailable, "grpc-status 14: the collector is shutting down"},
		{otlpfake.Reject, "rejected 1 of 1 records: rejected by the fake"},
		{otlpfake.Hang, "deadline exceeded"},
	} {
		fake := otlpfake.New()
		fake.SetMode(tc.mode)
		start := time.Now()
		err := client(t, fake.URL, 200*time.Millisecond).Export(context.Background(), otlp.Record{Time: time.Now()})
		if err == nil || !strings.Contains(err.Error(), tc.want) {
			t.Errorf("mode %d: got %v, want %q", tc.mode, err, tc.want)
		}
		if d := time.Since(start); d > 2*time.Second {
			t.Errorf("mode %d: took %s", tc.mode, d)
		}
		if len(fake.Logs()) != 0 {
			t.Errorf("mode %d: records kept", tc.mode)
		}
		fake.Close()
	}
	fake := otlpfake.New()
	fake.Close()
	if err := client(t, fake.URL, time.Second).Export(context.Background(), otlp.Record{}); err == nil {
		t.Error("an export to nothing listening succeeded")
	}
}

func TestEndpoints(t *testing.T) {
	for _, ok := range []string{"http://collector.telemetry.svc.cluster.local:4319", "http://127.0.0.1:4319/"} {
		if _, err := otlp.ParseEndpoint(ok); err != nil {
			t.Errorf("%s: %v", ok, err)
		}
	}
	for _, bad := range []string{"", "collector:4319", "https://collector:4319", "http://collector", "http://collector:4319/v1/logs",
		"http://u:p@collector:4319", "http://collector:4319?x=1", "grpc://collector:4319"} {
		if _, err := otlp.ParseEndpoint(bad); err == nil {
			t.Errorf("%q accepted", bad)
		}
	}
	if _, err := otlp.New("http://collector:4319", "s", 0); err == nil {
		t.Error("a zero timeout accepted")
	}
}
