package reconcile

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math/big"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp/otlpfake"
)

func verifyES256(t *testing.T, pub *ecdsa.PublicKey, jws string) map[string]any {
	t.Helper()
	parts := strings.Split(jws, ".")
	if len(parts) != 3 {
		t.Fatalf("not a JWS: %q", jws)
	}
	sig, _ := base64.RawURLEncoding.DecodeString(parts[2])
	digest := sha256.Sum256([]byte(parts[0] + "." + parts[1]))
	if len(sig) != 64 || !ecdsa.Verify(pub, digest[:], new(big.Int).SetBytes(sig[:32]), new(big.Int).SetBytes(sig[32:])) {
		t.Fatal("assertion does not verify with the public key")
	}
	raw, _ := base64.RawURLEncoding.DecodeString(parts[1])
	var claims map[string]any
	_ = json.Unmarshal(raw, &claims)
	return claims
}

type fakeKeycloak struct {
	mu       sync.Mutex
	disabled []string
	logouts  []string
	putBody  map[string]any
}

func TestRun(t *testing.T) {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	var oktaURL string
	okta := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.URL.Path == "/oauth2/v1/token":
			_ = r.ParseForm()
			claims := verifyES256(t, &key.PublicKey, r.PostForm.Get("client_assertion"))
			if claims["iss"] != "0oa-reconciler" || claims["aud"] != oktaURL+"/oauth2/v1/token" || r.PostForm.Get("scope") != "okta.users.read okta.groups.read" {
				t.Errorf("token request: claims %v, scope %q", claims, r.PostForm.Get("scope"))
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "okta-at", "token_type": "Bearer"})
		case r.Header.Get("Authorization") != "Bearer okta-at":
			w.WriteHeader(http.StatusUnauthorized)
		case r.URL.Path == "/api/v1/users" && strings.Contains(r.URL.RawQuery, "DEPROVISIONED"):
			_, _ = w.Write([]byte(`[{"id":"00u-leaver","status":"DEPROVISIONED"}]`))
		case r.URL.Path == "/api/v1/users" && r.URL.Query().Get("after") == "":
			w.Header().Set("Link", `<`+oktaURL+`/api/v1/users?limit=200&after=x>; rel="next"`)
			_, _ = w.Write([]byte(`[{"id":"00u-dev","status":"ACTIVE"}]`))
		case r.URL.Path == "/api/v1/users":
			_, _ = w.Write([]byte(`[{"id":"00u-moved","status":"ACTIVE"}]`))
		case r.URL.Path == "/api/v1/groups":
			name := r.URL.Query().Get("q")
			_, _ = w.Write([]byte(`[{"id":"g-` + name + `","profile":{"name":"` + name + `"}}]`))
		case strings.HasPrefix(r.URL.Path, "/api/v1/groups/g-"):
			members := map[string]string{
				"agentic-developer":         `[{"id":"00u-dev"},{"id":"00u-moved"}]`,
				"agentic-platform-engineer": `[{"id":"00u-moved"}]`,
				"agentic-team-payments":     `[{"id":"00u-dev"},{"id":"00u-moved"}]`,
			}[strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/api/v1/groups/g-"), "/users")]
			if members == "" {
				members = "[]"
			}
			_, _ = w.Write([]byte(members))
		default:
			t.Errorf("okta: unexpected %s %s", r.Method, r.URL)
			w.WriteHeader(http.StatusNotFound)
		}
	}))
	defer okta.Close()
	oktaURL = okta.URL

	fk := &fakeKeycloak{}
	users := map[string]string{"kc-dev": "00u-dev", "kc-leaver": "00u-leaver", "kc-moved": "00u-moved"}
	keycloak := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fk.mu.Lock()
		defer fk.mu.Unlock()
		p := strings.TrimPrefix(r.URL.Path, "/admin/realms/agentic")
		switch {
		case r.URL.Path == "/realms/agentic/protocol/openid-connect/token":
			_ = r.ParseForm()
			if r.PostForm.Get("client_assertion") != "projected-sa-token" {
				t.Errorf("keycloak token: assertion %q", r.PostForm.Get("client_assertion"))
			}
			_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "kc-at", "scope": "kc-admin-api"})
		case r.Header.Get("Authorization") != "Bearer kc-at":
			w.WriteHeader(http.StatusUnauthorized)
		case p == "/users" && r.URL.Query().Get("idpAlias") == "okta":
			_, _ = w.Write([]byte(`[{"id":"kc-dev","username":"dev","enabled":true},{"id":"kc-leaver","username":"leaver","enabled":true},
				{"id":"kc-moved","username":"moved","enabled":true},{"id":"kc-off","username":"off","enabled":false}]`))
		case strings.HasSuffix(p, "/federated-identity"):
			id := strings.Split(p, "/")[2]
			_, _ = w.Write([]byte(`[{"identityProvider":"okta","userId":"` + users[id] + `"}]`))
		case strings.HasSuffix(p, "/role-mappings/realm"):
			_, _ = w.Write([]byte(`[{"name":"developer"},{"name":"default-roles-agentic"}]`))
		case strings.HasSuffix(p, "/groups"):
			_, _ = w.Write([]byte(`[{"path":"/teams/payments"}]`))
		case strings.HasSuffix(p, "/sessions"):
			_, _ = w.Write([]byte(`[{"id":"s1"}]`))
		case strings.HasSuffix(p, "/logout") && r.Method == http.MethodPost:
			fk.logouts = append(fk.logouts, strings.Split(p, "/")[2])
			w.WriteHeader(http.StatusNoContent)
		case strings.HasPrefix(p, "/users/") && r.Method == http.MethodGet:
			_, _ = w.Write([]byte(`{"id":"kc-leaver","username":"leaver","enabled":true,"attributes":{"idp_sub":["00u-leaver"]}}`))
		case strings.HasPrefix(p, "/users/") && r.Method == http.MethodPut:
			_ = json.NewDecoder(r.Body).Decode(&fk.putBody)
			fk.disabled = append(fk.disabled, strings.Split(p, "/")[2])
			w.WriteHeader(http.StatusNoContent)
		default:
			t.Errorf("keycloak: unexpected %s %s", r.Method, r.URL)
			w.WriteHeader(http.StatusNotFound)
		}
	}))
	defer keycloak.Close()

	dir := t.TempDir()
	write := func(name, s string) string {
		path := filepath.Join(dir, name)
		if err := os.WriteFile(path, []byte(s), 0o600); err != nil {
			t.Fatal(err)
		}
		return path
	}
	cfg := Config{AccessFile: write("access.json", `{
	  "roles": [{"name": "developer", "group": "agentic-developer"}, {"name": "platform-engineer", "group": "agentic-platform-engineer"}],
	  "teams": [{"slug": "payments", "group": "agentic-team-payments"}]}`)}
	o := &Okta{Org: okta.URL, ClientID: "0oa-reconciler", Kid: "k1", Key: key, HTTP: okta.Client()}
	k := &Keycloak{URL: keycloak.URL, Realm: "agentic", IdPAlias: "okta", TokenFile: write("token", "projected-sa-token\n"), HTTP: keycloak.Client()}
	var log bytes.Buffer
	if err := Run(context.Background(), cfg, o, k, Audit{W: &log}); err != nil {
		t.Fatalf("Run: %v\n%s", err, log.String())
	}
	if strings.Join(fk.disabled, ",") != "kc-leaver" {
		t.Errorf("disabled %v, want the leaver alone", fk.disabled)
	}
	if fk.putBody["enabled"] != false || fk.putBody["attributes"] == nil {
		t.Errorf("disable kept no representation: %v", fk.putBody)
	}
	if strings.Join(fk.logouts, ",") != "kc-leaver,kc-moved" {
		t.Errorf("sessions ended for %v, want the leaver and the promoted user", fk.logouts)
	}
	for _, want := range []string{`"event":"keycloak.user_disabled"`, `"reason":"okta_deprovisioned"`, `"reason":"roles_or_team_changed"`, `"event":"reconcile.run"`} {
		if !strings.Contains(log.String(), want) {
			t.Errorf("audit lacks %s:\n%s", want, log.String())
		}
	}
	lines := strings.Count(log.String(), "\n")

	// With a collector, the same run sends its audit records there, the
	// event as event.name, and its summary to stdout. With one that fails,
	// the run acts the same and succeeds, and its records go to stdout
	// from the first one the collector did not take, after one try.
	for _, mode := range []otlpfake.Mode{otlpfake.Accept, otlpfake.Unavailable} {
		fake := otlpfake.New()
		fake.SetMode(mode)
		c, err := otlp.New(fake.URL, "okta-reconciler", time.Second)
		if err != nil {
			t.Fatal(err)
		}
		fk.mu.Lock()
		fk.disabled, fk.logouts = nil, nil
		fk.mu.Unlock()
		var out, errs bytes.Buffer
		if err := Run(context.Background(), cfg, o, k, Audit{W: &out, OTLP: c, Errs: &errs}); err != nil {
			t.Fatalf("mode %d: Run: %v", mode, err)
		}
		if strings.Join(fk.disabled, ",") != "kc-leaver" || strings.Join(fk.logouts, ",") != "kc-leaver,kc-moved" {
			t.Errorf("mode %d: disabled %v, sessions ended for %v", mode, fk.disabled, fk.logouts)
		}
		switch mode {
		case otlpfake.Accept:
			logs := fake.Logs()
			if len(logs) != 3 || strings.Count(out.String(), "\n") != lines-3 || !strings.Contains(out.String(), `"event":"reconcile.run"`) || errs.Len() != 0 {
				t.Errorf("%d records at the collector, want 3; stdout %q; errors %q", len(logs), out.String(), errs.String())
			}
			events := map[string]int{}
			for _, l := range logs {
				events[l.Attributes["event.name"].(string)]++
				if _, ok := l.Attributes["event"]; ok || l.Service != "okta-reconciler" || l.Time.IsZero() {
					t.Errorf("record %+v", l)
				}
			}
			if len(events) != 2 || events["keycloak.user_disabled"] != 1 || events["keycloak.sessions_ended"] != 2 {
				t.Errorf("events %v", events)
			}
			if logs[0].Attributes["reason"] != "okta_deprovisioned" || logs[0].Attributes["dry_run"] != false {
				t.Errorf("first record %v", logs[0].Attributes)
			}
		case otlpfake.Unavailable:
			if fake.Calls() != 1 || strings.Count(out.String(), "\n") != lines || !strings.Contains(errs.String(), "grpc-status 14") {
				t.Errorf("%d calls, %d lines on stdout (want 1 and %d); errors %q", fake.Calls(), strings.Count(out.String(), "\n"), lines, errs.String())
			}
		}
		fake.Close()
	}
}

// Only the job's audit records reach the collector: a disabled user, ended
// sessions and every anomaly, which stays on stdout as well, as the run's
// log. The run's summary and a dry run's records stay on stdout, even
// while the collector takes records.
func TestOnlyAuditRecordsReachTheCollector(t *testing.T) {
	fake := otlpfake.New()
	defer fake.Close()
	c, err := otlp.New(fake.URL, "okta-reconciler", time.Second)
	if err != nil {
		t.Fatal(err)
	}
	var out bytes.Buffer
	a := Audit{W: &out, OTLP: c}
	who := func(dry bool) map[string]any {
		return map[string]any{"user_id": "kc-1", "username": "u", "idp_user_id": "00u-1", "reason": "okta_deprovisioned", "dry_run": dry}
	}
	a.Record("reconcile.anomaly", map[string]any{"kind": "two_teams", "user_id": "kc-2", "dry_run": false})
	a.Record("reconcile.anomaly", map[string]any{"kind": "missing_group", "team": "t", "group": "g", "dry_run": false})
	a.Record("reconcile.anomaly", map[string]any{"kind": "missing_group", "team": "t", "group": "g", "dry_run": true})
	a.Record("keycloak.user_disabled", who(false))
	a.Record("keycloak.sessions_ended", who(false))
	a.Record("keycloak.user_disabled", who(true))
	a.Record("keycloak.sessions_ended", who(true))
	a.Record("reconcile.run", map[string]any{"disabled": 1, "dry_run": false})
	var exported []string
	for _, l := range fake.Logs() {
		exported = append(exported, l.Attributes["event.name"].(string))
		if l.Attributes["dry_run"] != false {
			t.Errorf("a record of no action the run took reached the collector: %v", l.Attributes)
		}
	}
	if strings.Join(exported, ",") != "reconcile.anomaly,reconcile.anomaly,keycloak.user_disabled,keycloak.sessions_ended" || fake.Calls() != 4 {
		t.Errorf("the collector got %v in %d calls, want the two anomalies, the disable and the ended sessions", exported, fake.Calls())
	}
	if logs := fake.Logs(); len(logs) < 2 || logs[0].Attributes["kind"] != "two_teams" || logs[1].Attributes["kind"] != "missing_group" {
		t.Errorf("the collector got %v, want the two teams' anomaly, then the missing group's", logs)
	}
	var stdout []string
	for _, line := range strings.Split(strings.TrimSpace(out.String()), "\n") {
		var rec map[string]any
		if err := json.Unmarshal([]byte(line), &rec); err != nil {
			t.Fatalf("%q: %v", line, err)
		}
		stdout = append(stdout, fmt.Sprint(rec["event"], "/", rec["dry_run"]))
	}
	if want := "reconcile.anomaly/false,reconcile.anomaly/false,reconcile.anomaly/true,keycloak.user_disabled/true,keycloak.sessions_ended/true,reconcile.run/false"; strings.Join(stdout, ",") != want {
		t.Errorf("stdout got %v, want %s", stdout, want)
	}
}

func TestConfigFromEnv(t *testing.T) {
	for name, v := range map[string]string{"OKTA_ORG_URL": "https://org.okta.com", "OKTA_CLIENT_ID": "c", "OKTA_KEY_FILE": "/k",
		"KEYCLOAK_URL": "https://keycloak", "KEYCLOAK_REALM": "agentic", "KEYCLOAK_IDP_ALIAS": "okta",
		"KEYCLOAK_TOKEN_FILE": "/t", "ACCESS_FILE": "/a"} {
		t.Setenv(name, v)
	}
	t.Setenv("AUDIT_OTLP_ENDPOINT", "")
	if c, err := ConfigFromEnv(); err != nil || c.AuditEndpoint != "" {
		t.Errorf("without AUDIT_OTLP_ENDPOINT: %+v, %v", c, err)
	}
	t.Setenv("AUDIT_OTLP_ENDPOINT", "http://collector.telemetry.svc.cluster.local:4319")
	if c, err := ConfigFromEnv(); err != nil || c.AuditEndpoint != "http://collector.telemetry.svc.cluster.local:4319" {
		t.Errorf("with AUDIT_OTLP_ENDPOINT: %+v, %v", c, err)
	}
	t.Setenv("AUDIT_OTLP_ENDPOINT", "https://collector:4319")
	if _, err := ConfigFromEnv(); err == nil {
		t.Error("an https endpoint accepted")
	}
}

func TestRunRefusesAnEmptyOkta(t *testing.T) {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	okta := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/oauth2/v1/token" {
			_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "okta-at"})
			return
		}
		_, _ = w.Write([]byte(`[]`))
	}))
	defer okta.Close()
	keycloak := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		t.Errorf("keycloak called: %s %s", r.Method, r.URL)
	}))
	defer keycloak.Close()
	access := filepath.Join(t.TempDir(), "access.json")
	_ = os.WriteFile(access, []byte(`{"roles":[],"teams":[]}`), 0o600)
	err := Run(context.Background(), Config{AccessFile: access},
		&Okta{Org: okta.URL, ClientID: "c", Kid: "k", Key: key, HTTP: okta.Client()},
		&Keycloak{URL: keycloak.URL, Realm: "agentic", IdPAlias: "okta", HTTP: keycloak.Client()}, Audit{W: &bytes.Buffer{}})
	if err == nil || !strings.Contains(err.Error(), "refusing to act") {
		t.Errorf("got %v, want a refusal", err)
	}
}

func TestAssertionExpiresInFiveMinutes(t *testing.T) {
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	o := &Okta{ClientID: "c", Kid: "k", Key: key}
	now := time.Unix(1_800_000_000, 0)
	jws, err := o.Assertion("https://org.okta.com/oauth2/v1/token", now)
	if err != nil {
		t.Fatal(err)
	}
	c := verifyES256(t, &key.PublicKey, jws)
	if c["exp"].(float64)-c["iat"].(float64) != 300 || c["sub"] != "c" {
		t.Errorf("claims %v", c)
	}
}
