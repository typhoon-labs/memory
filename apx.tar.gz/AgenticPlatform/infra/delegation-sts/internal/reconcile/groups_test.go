package reconcile

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"strings"
	"sync"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp/otlpfake"
)

// These tests run the job against a fake Okta whose groups can be missing
// or unreadable: the leavers, and a kill switch's target that Okta has
// deactivated, never wait on the groups that roles.yaml and teams.yaml
// name (design/identity.md, "The reconciliation job").

// groupsAccess names a role and a team whose groups the fixtures' Okta may
// lack: incident-manager and reference.
const groupsAccess = `{
  "roles": [{"name": "developer", "group": "agentic-developer"}, {"name": "incident-manager", "group": "agentic-incident-manager"}],
  "teams": [{"slug": "payments", "group": "agentic-team-payments"}, {"slug": "platform", "group": "agentic-team-platform"},
            {"slug": "reference", "group": "agentic-team-reference"}]}`

type fakeUser struct {
	id, oktaID   string
	enabled      bool
	roles, teams []string
	session      bool
}

// fixture is a fake Okta and Keycloak. A group absent from members is one
// Okta does not have; one in failing answers 500. Keycloak keeps what the
// job changes: a disabled user stays disabled and an ended session ends,
// so a second run sees the first one's work. A user in failDisable answers
// 500 to the job's disable, one in failLogout to its logout, and a read in
// failRead, a user ID and the path's last part such as
// "kc-x/federated-identity", answers 500. The request cancelOn, such as
// "PUT /users/kc-x", cancels the run's context as it arrives, as the job's
// deadline or a SIGTERM would; cancelAfter, such as "POST
// /users/kc-x/logout", cancels it once the job has Keycloak's answer.
type fixture struct {
	t           *testing.T
	statuses    map[string]string   // Okta user ID to status
	members     map[string][]string // Okta group name to its members' user IDs
	failing     map[string]bool
	users       []fakeUser // Keycloak's users linked to okta
	failDisable map[string]bool
	failLogout  map[string]bool
	failRead    map[string]bool
	cancelOn    string
	cancelAfter string
	cancel      context.CancelFunc

	mu       sync.Mutex
	listed   map[string]bool // the users the run found enabled
	calls    []string        // Okta's group reads and Keycloak's changes, in order
	disabled []string
	logouts  []string
}

func (f *fixture) call(c string) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.calls = append(f.calls, c)
}

func (f *fixture) okta(w http.ResponseWriter, r *http.Request) {
	switch {
	case r.URL.Path == "/oauth2/v1/token":
		_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "okta-at"})
	case r.Header.Get("Authorization") != "Bearer okta-at":
		w.WriteHeader(http.StatusUnauthorized)
	case r.URL.Path == "/api/v1/users":
		deprovisioned := strings.Contains(r.URL.Query().Get("filter"), "DEPROVISIONED")
		page := []map[string]string{}
		for id, status := range f.statuses {
			if (status == "DEPROVISIONED") == deprovisioned {
				page = append(page, map[string]string{"id": id, "status": status})
			}
		}
		sort.Slice(page, func(i, j int) bool { return page[i]["id"] < page[j]["id"] })
		_ = json.NewEncoder(w).Encode(page)
	case r.URL.Path == "/api/v1/groups":
		name := r.URL.Query().Get("q")
		f.call("okta group " + name)
		if f.failing[name] {
			w.WriteHeader(http.StatusInternalServerError)
			_, _ = w.Write([]byte(`{"errorCode":"E0000009"}`))
			return
		}
		page := []map[string]any{}
		if _, ok := f.members[name]; ok {
			page = append(page, map[string]any{"id": "g-" + name, "profile": map[string]string{"name": name}})
		}
		_ = json.NewEncoder(w).Encode(page)
	case strings.HasPrefix(r.URL.Path, "/api/v1/groups/g-") && strings.HasSuffix(r.URL.Path, "/users"):
		name := strings.TrimSuffix(strings.TrimPrefix(r.URL.Path, "/api/v1/groups/g-"), "/users")
		f.call("okta members " + name)
		page := []map[string]string{}
		for _, id := range f.members[name] {
			page = append(page, map[string]string{"id": id})
		}
		_ = json.NewEncoder(w).Encode(page)
	default:
		f.t.Errorf("okta: unexpected %s %s", r.Method, r.URL)
		w.WriteHeader(http.StatusNotFound)
	}
}

func (f *fixture) keycloak(w http.ResponseWriter, r *http.Request) {
	f.mu.Lock()
	defer f.mu.Unlock()
	p := strings.TrimPrefix(r.URL.Path, "/admin/realms/agentic")
	switch {
	case r.URL.Path == "/realms/agentic/protocol/openid-connect/token":
		_ = json.NewEncoder(w).Encode(map[string]any{"access_token": "kc-at"})
		return
	case r.Header.Get("Authorization") != "Bearer kc-at":
		w.WriteHeader(http.StatusUnauthorized)
		return
	case p == "/users" && r.URL.Query().Get("idpAlias") == "okta":
		page := []map[string]any{}
		if r.URL.Query().Get("first") == "0" {
			f.listed = map[string]bool{}
			for _, u := range f.users {
				page = append(page, map[string]any{"id": u.id, "username": strings.TrimPrefix(u.id, "kc-"), "enabled": u.enabled})
				f.listed[u.id] = u.enabled
			}
		}
		_ = json.NewEncoder(w).Encode(page)
		return
	}
	id, sub, _ := strings.Cut(strings.TrimPrefix(p, "/users/"), "/")
	i := slices.IndexFunc(f.users, func(u fakeUser) bool { return u.id == id })
	if !strings.HasPrefix(p, "/users/") || i < 0 {
		f.t.Errorf("keycloak: unexpected %s %s", r.Method, r.URL)
		w.WriteHeader(http.StatusNotFound)
		return
	}
	u := &f.users[i]
	if f.cancelOn != "" && f.cancelOn == r.Method+" "+p {
		f.cancel()
	}
	if !f.listed[id] {
		f.t.Errorf("keycloak: %s %s of a user the run did not find enabled", r.Method, r.URL)
	}
	if r.Method == http.MethodGet && f.failRead[id+"/"+sub] {
		w.WriteHeader(http.StatusInternalServerError)
		_, _ = w.Write([]byte(`{"error":"unknown_error"}`))
		return
	}
	switch {
	case sub == "federated-identity":
		_ = json.NewEncoder(w).Encode([]map[string]string{{"identityProvider": "okta", "userId": u.oktaID}})
	case sub == "role-mappings/realm":
		roles := []map[string]string{{"name": "default-roles-agentic"}}
		for _, name := range u.roles {
			roles = append(roles, map[string]string{"name": name})
		}
		_ = json.NewEncoder(w).Encode(roles)
	case sub == "groups":
		groups := []map[string]string{}
		for _, slug := range u.teams {
			groups = append(groups, map[string]string{"path": "/teams/" + slug})
		}
		_ = json.NewEncoder(w).Encode(groups)
	case sub == "sessions":
		sessions := []map[string]string{}
		if u.session {
			sessions = append(sessions, map[string]string{"id": "s-" + id})
		}
		_ = json.NewEncoder(w).Encode(sessions)
	case sub == "logout" && r.Method == http.MethodPost && f.failLogout[id]:
		w.WriteHeader(http.StatusInternalServerError)
		_, _ = w.Write([]byte(`{"error":"unknown_error"}`))
	case sub == "logout" && r.Method == http.MethodPost:
		f.calls = append(f.calls, "keycloak logout "+id)
		f.logouts = append(f.logouts, id)
		u.session = false
		w.WriteHeader(http.StatusNoContent)
	case sub == "" && r.Method == http.MethodGet:
		_ = json.NewEncoder(w).Encode(map[string]any{"id": id, "enabled": u.enabled})
	case sub == "" && r.Method == http.MethodPut:
		var rep map[string]any
		_ = json.NewDecoder(r.Body).Decode(&rep)
		if rep["enabled"] != false {
			f.t.Errorf("keycloak: PUT %s with enabled %v", id, rep["enabled"])
		}
		if f.failDisable[id] {
			w.WriteHeader(http.StatusInternalServerError)
			_, _ = w.Write([]byte(`{"error":"unknown_error"}`))
			return
		}
		f.calls = append(f.calls, "keycloak disable "+id)
		f.disabled = append(f.disabled, id)
		u.enabled = false
		w.WriteHeader(http.StatusNoContent)
	default:
		f.t.Errorf("keycloak: unexpected %s %s", r.Method, r.URL)
		w.WriteHeader(http.StatusNotFound)
	}
}

// run runs the job once against the fixture.
func (f *fixture) run(cfg Config, audit Audit) error {
	f.t.Helper()
	key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	okta := httptest.NewServer(http.HandlerFunc(f.okta))
	defer okta.Close()
	keycloak := httptest.NewServer(http.HandlerFunc(f.keycloak))
	defer keycloak.Close()
	dir := f.t.TempDir()
	cfg.AccessFile = filepath.Join(dir, "access.json")
	token := filepath.Join(dir, "token")
	if err := os.WriteFile(cfg.AccessFile, []byte(groupsAccess), 0o600); err != nil {
		f.t.Fatal(err)
	}
	if err := os.WriteFile(token, []byte("projected-sa-token\n"), 0o600); err != nil {
		f.t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	f.cancel = cancel
	client := keycloak.Client()
	if f.cancelAfter != "" {
		client.Transport = cancelAfter{base: client.Transport, request: f.cancelAfter, cancel: cancel}
	}
	return Run(ctx, cfg,
		&Okta{Org: okta.URL, ClientID: "0oa-reconciler", Kid: "k1", Key: key, HTTP: okta.Client()},
		&Keycloak{URL: keycloak.URL, Realm: "agentic", IdPAlias: "okta", TokenFile: token, HTTP: client}, audit)
}

// cancelAfter cancels the run's context once a request, its method and
// path below the realm's admin API, has had its answer: the call has
// succeeded, and the context ends before the job's next step.
type cancelAfter struct {
	base    http.RoundTripper
	request string
	cancel  context.CancelFunc
}

func (c cancelAfter) RoundTrip(r *http.Request) (*http.Response, error) {
	resp, err := c.base.RoundTrip(r)
	if err == nil && r.Method+" "+strings.TrimPrefix(r.URL.Path, "/admin/realms/agentic") == c.request {
		c.cancel()
	}
	return resp, err
}

// records parses the job's stdout, one JSON record per line.
func records(t *testing.T, out string) []map[string]any {
	t.Helper()
	var recs []map[string]any
	for _, line := range strings.Split(strings.TrimSpace(out), "\n") {
		var rec map[string]any
		if err := json.Unmarshal([]byte(line), &rec); err != nil {
			t.Fatalf("%q: %v", line, err)
		}
		recs = append(recs, rec)
	}
	return recs
}

func only(t *testing.T, recs []map[string]any, event string) map[string]any {
	t.Helper()
	var found []map[string]any
	for _, r := range recs {
		if r["event"] == event {
			found = append(found, r)
		}
	}
	if len(found) != 1 {
		t.Fatalf("%d records of %s, want one: %v", len(found), event, recs)
	}
	return found[0]
}

// withTeamsAheadOfOkta is an Okta that has every group but the reference
// team's and the incident-manager role's, which roles.yaml and teams.yaml
// name ahead of them.
func withTeamsAheadOfOkta(t *testing.T) *fixture {
	return &fixture{t: t,
		statuses: map[string]string{"00u-dev": "ACTIVE", "00u-leaver": "SUSPENDED", "00u-moved": "ACTIVE", "00u-ref": "ACTIVE"},
		members: map[string][]string{
			"agentic-developer":     {"00u-dev", "00u-leaver", "00u-moved", "00u-ref"},
			"agentic-team-payments": {"00u-dev", "00u-leaver"},
			"agentic-team-platform": {"00u-moved"},
		},
		users: []fakeUser{
			{id: "kc-dev", oktaID: "00u-dev", enabled: true, roles: []string{"developer"}, teams: []string{"payments"}, session: true},
			{id: "kc-leaver", oktaID: "00u-leaver", enabled: true, roles: []string{"developer"}, teams: []string{"payments"}, session: true},
			// Moved from payments to platform in Okta: another team.
			{id: "kc-moved", oktaID: "00u-moved", enabled: true, roles: []string{"developer"}, teams: []string{"payments"}, session: true},
			// Holds the reference team from before Okta lost its group.
			{id: "kc-ref", oktaID: "00u-ref", enabled: true, roles: []string{"developer"}, teams: []string{"reference"}, session: true},
		},
	}
}

// A team or role whose group Okta lacks is skipped alone: the leaver is
// disabled and loses their sessions, the person whose team changed loses
// their sessions, and the run succeeds. The missing group holds no one, so
// nobody keeps or gains its team: the person who holds the reference team
// from before loses their sessions, and their next sign-in drops it.
func TestRunSkipsOnlyTheTeamWhoseGroupIsMissing(t *testing.T) {
	f := withTeamsAheadOfOkta(t)
	f.members["agentic-incident-manager"] = []string{} // only the team's group is missing
	var out bytes.Buffer
	if err := f.run(Config{}, Audit{W: &out}); exitCode(err) != 2 {
		t.Fatalf("Run: %v, exit %d, want 2 for the missing group\n%s", err, exitCode(err), out.String())
	}
	if strings.Join(f.disabled, ",") != "kc-leaver" {
		t.Errorf("disabled %v, want the leaver alone", f.disabled)
	}
	if strings.Join(f.logouts, ",") != "kc-leaver,kc-moved,kc-ref" {
		t.Errorf("sessions ended for %v, want the leaver, the person who moved team and the reference team's holder", f.logouts)
	}
	recs := records(t, out.String())
	for _, r := range recs {
		if r["event"] == "keycloak.sessions_ended" && r["user_id"] == "kc-ref" {
			if r["reason"] != "roles_or_team_changed" || r["want_teams"] != nil {
				t.Errorf("kc-ref's record %v, want roles_or_team_changed and no team", r)
			}
		}
	}
	sum := only(t, recs, "reconcile.run")
	if sum["disabled"] != 1.0 || sum["sessions_ended"] != 3.0 || sum["errors"] != 0.0 {
		t.Errorf("summary %v", sum)
	}
}

// A missing group is an anomaly the SIEM sees: one record per role or team
// whose group Okta lacks, naming both, on stdout as the run's log and at
// the collector as an audit record, and counted in the run's summary.
func TestRunRecordsAMissingGroup(t *testing.T) {
	want := map[string]map[string]any{
		"agentic-team-reference":   {"kind": "missing_group", "team": "reference", "group": "agentic-team-reference", "dry_run": false},
		"agentic-incident-manager": {"kind": "missing_group", "role": "incident-manager", "group": "agentic-incident-manager", "dry_run": false},
	}
	check := func(where string, got []map[string]any) {
		t.Helper()
		if len(got) != len(want) {
			t.Errorf("%s: %d missing-group records, want %d: %v", where, len(got), len(want), got)
		}
		for _, g := range got {
			w := want[g["group"].(string)]
			for k, v := range w {
				if g[k] != v {
					t.Errorf("%s: record %v, want %s %v", where, g, k, v)
				}
			}
			for _, k := range []string{"user_id", "username", "idp_user_id"} {
				if _, ok := g[k]; ok {
					t.Errorf("%s: record %v names a user", where, g)
				}
			}
		}
	}
	missingGroups := func(recs []map[string]any) []map[string]any {
		var out []map[string]any
		for _, r := range recs {
			if r["kind"] == "missing_group" {
				out = append(out, r)
			}
		}
		return out
	}

	var out bytes.Buffer
	if err := withTeamsAheadOfOkta(t).run(Config{}, Audit{W: &out}); exitCode(err) != 2 {
		t.Fatalf("Run: %v, exit %d, want 2\n%s", err, exitCode(err), out.String())
	}
	recs := records(t, out.String())
	for _, r := range missingGroups(recs) {
		if r["event"] != "reconcile.anomaly" {
			t.Errorf("record %v, want event reconcile.anomaly", r)
		}
	}
	check("stdout", missingGroups(recs))
	if sum := only(t, recs, "reconcile.run"); sum["anomalies"] != 2.0 {
		t.Errorf("summary %v, want 2 anomalies", sum)
	}

	fake := otlpfake.New()
	defer fake.Close()
	c, err := otlp.New(fake.URL, "okta-reconciler", time.Second)
	if err != nil {
		t.Fatal(err)
	}
	out.Reset()
	if err := withTeamsAheadOfOkta(t).run(Config{}, Audit{W: &out, OTLP: c}); exitCode(err) != 2 {
		t.Fatalf("Run with a collector: %v, exit %d, want 2\n%s", err, exitCode(err), out.String())
	}
	var exported []map[string]any
	for _, l := range fake.Logs() {
		if l.Attributes["event.name"] == "reconcile.anomaly" {
			exported = append(exported, l.Attributes)
		}
	}
	check("collector", missingGroups(exported))
	check("stdout with a collector", missingGroups(records(t, out.String())))
}

// The kill switch's target, whom on-call has deactivated in Okta while
// the runbook's Keycloak steps are still to come, is disabled and loses
// their sessions though a team's group is missing; a person the runbook
// has disabled already is left as they are, never re-enabled.
func TestRunKillSwitchWithAMissingGroup(t *testing.T) {
	f := withTeamsAheadOfOkta(t)
	f.members["agentic-incident-manager"] = []string{} // only the team's group is missing
	f.statuses["00u-target"] = "DEPROVISIONED"
	f.statuses["00u-switched"] = "DEPROVISIONED"
	f.members["agentic-developer"] = append(f.members["agentic-developer"], "00u-target", "00u-switched")
	f.users = append(f.users,
		fakeUser{id: "kc-target", oktaID: "00u-target", enabled: true, roles: []string{"developer"}, teams: []string{"payments"}, session: true},
		fakeUser{id: "kc-switched", oktaID: "00u-switched", enabled: false, roles: []string{"developer"}, teams: []string{"payments"}})
	var out bytes.Buffer
	if err := f.run(Config{}, Audit{W: &out}); exitCode(err) != 2 {
		t.Fatalf("Run: %v, exit %d, want 2 for the missing group\n%s", err, exitCode(err), out.String())
	}
	if !slices.Contains(f.disabled, "kc-target") || !slices.Contains(f.logouts, "kc-target") {
		t.Errorf("disabled %v, sessions ended for %v: want the kill switch's target in both", f.disabled, f.logouts)
	}
	if slices.Contains(f.disabled, "kc-switched") || slices.Contains(f.logouts, "kc-switched") {
		t.Errorf("the job acted on a person the kill switch disabled: disabled %v, sessions ended for %v", f.disabled, f.logouts)
	}
	if !strings.Contains(out.String(), `"reason":"okta_deprovisioned"`) {
		t.Errorf("no audit record of the target's disable:\n%s", out.String())
	}
}

// When Okta cannot list a group, the leavers are disabled and lose their
// sessions before any group is read. Nobody's sessions end for a change of
// roles or team, since the groups' members are unknown, and the run fails
// after its summary.
func TestRunActsOnLeaversBeforeReadingGroups(t *testing.T) {
	f := withTeamsAheadOfOkta(t)
	f.failing = map[string]bool{"agentic-developer": true}
	var out bytes.Buffer
	err := f.run(Config{}, Audit{W: &out})
	if exitCode(err) != 1 || !strings.Contains(err.Error(), "agentic-developer") {
		t.Errorf("Run: %v, exit %d, want 1 for the failed read of agentic-developer", err, exitCode(err))
	}
	if strings.Join(f.disabled, ",") != "kc-leaver" || strings.Join(f.logouts, ",") != "kc-leaver" {
		t.Errorf("disabled %v, sessions ended for %v: want the leaver alone in both", f.disabled, f.logouts)
	}
	firstGroup := slices.IndexFunc(f.calls, func(c string) bool { return strings.HasPrefix(c, "okta ") })
	for i, c := range f.calls {
		if strings.HasPrefix(c, "keycloak ") && (firstGroup < 0 || i > firstGroup) {
			t.Errorf("%q came after Okta's first group read: %v", c, f.calls)
		}
	}
	sum := only(t, records(t, out.String()), "reconcile.run")
	if sum["disabled"] != 1.0 || sum["sessions_ended"] != 1.0 || sum["errors"] != 1.0 {
		t.Errorf("summary %v, want 1 disabled, 1 sessions ended, 1 error", sum)
	}
}

// exitCode is the code cmd/reconcile exits with for Run's error: 0 for
// none, the error's own code for one that has it, else 1.
func exitCode(err error) int {
	if err == nil {
		return 0
	}
	var coded interface{ ExitCode() int }
	if errors.As(err, &coded) {
		return coded.ExitCode()
	}
	return 1
}

// withAllGroups is an Okta that has every group Access names.
func withAllGroups(t *testing.T) *fixture {
	f := withTeamsAheadOfOkta(t)
	f.members["agentic-team-reference"] = []string{}
	f.members["agentic-incident-manager"] = []string{}
	return f
}

// anomalies are the run's anomaly records of one kind, by user ID.
func anomalies(recs []map[string]any, kind string) map[string]map[string]any {
	out := map[string]map[string]any{}
	for _, r := range recs {
		if r["event"] == "reconcile.anomaly" && r["kind"] == kind {
			out[fmt.Sprint(r["user_id"])] = r
		}
	}
	return out
}

// A leaver whose disable fails still loses their sessions, the failure is
// a fault anomaly naming them, and the next leaver is handled as usual.
func TestRunEndsSessionsWhenADisableFails(t *testing.T) {
	f := withAllGroups(t)
	f.statuses["00u-leaver2"] = "DEPROVISIONED"
	f.users = append(f.users, fakeUser{id: "kc-leaver2", oktaID: "00u-leaver2", enabled: true, session: true})
	f.failDisable = map[string]bool{"kc-leaver": true}
	var out bytes.Buffer
	err := f.run(Config{}, Audit{W: &out})
	if exitCode(err) != 2 {
		t.Errorf("Run: %v, exit %d, want 2 for the failed disable", err, exitCode(err))
	}
	if !slices.Contains(f.logouts, "kc-leaver") || !slices.Contains(f.logouts, "kc-leaver2") {
		t.Errorf("sessions ended for %v, want both leavers", f.logouts)
	}
	if strings.Join(f.disabled, ",") != "kc-leaver2" {
		t.Errorf("disabled %v, want the second leaver", f.disabled)
	}
	recs := records(t, out.String())
	a := anomalies(recs, "disable_failed")["kc-leaver"]
	if a == nil || a["idp_user_id"] != "00u-leaver" || !strings.Contains(fmt.Sprint(a["error"]), "500") {
		t.Errorf("no disable_failed anomaly for kc-leaver with the error: %v", recs)
	}
	for _, r := range recs {
		if r["event"] == "keycloak.user_disabled" && r["user_id"] == "kc-leaver" {
			t.Errorf("a disable record for the user whose disable failed: %v", r)
		}
	}
	sum := only(t, recs, "reconcile.run")
	if sum["disabled"] != 1.0 || sum["anomalies"] != 1.0 || sum["errors"] != 0.0 {
		t.Errorf("summary %v, want 1 disabled, 1 anomaly, no error", sum)
	}
}

// One user whose Keycloak link cannot be read is a fault anomaly, never a
// leaver, and every other leaver is still disabled and loses their
// sessions. The leaver path reads only the link, so a leaver whose
// sessions cannot be read is handled too; a person whose roles cannot be
// read is an anomaly, and their sessions are not ended for a change.
func TestRunSurvivesAnUnreadableUser(t *testing.T) {
	f := withAllGroups(t)
	f.statuses["00u-broken"] = "ACTIVE"
	f.users = append([]fakeUser{{id: "kc-broken", oktaID: "00u-broken", enabled: true, session: true}}, f.users...)
	f.users = append(f.users, fakeUser{id: "kc-gone", oktaID: "00u-gone", enabled: true, session: true})
	f.failRead = map[string]bool{"kc-broken/federated-identity": true, "kc-gone/sessions": true, "kc-moved/role-mappings/realm": true}
	var out bytes.Buffer
	err := f.run(Config{}, Audit{W: &out})
	if exitCode(err) != 2 {
		t.Errorf("Run: %v, exit %d, want 2 for the unreadable users", err, exitCode(err))
	}
	if strings.Join(f.disabled, ",") != "kc-leaver,kc-gone" {
		t.Errorf("disabled %v, want the two leavers alone", f.disabled)
	}
	if strings.Join(f.logouts, ",") != "kc-leaver,kc-gone,kc-ref" {
		t.Errorf("sessions ended for %v, want the two leavers, then the reference team's holder", f.logouts)
	}
	recs := records(t, out.String())
	failed := anomalies(recs, "read_failed")
	if len(failed) != 2 || failed["kc-broken"] == nil || failed["kc-moved"] == nil {
		t.Errorf("read_failed anomalies %v, want kc-broken and kc-moved", failed)
	}
	if sum := only(t, recs, "reconcile.run"); sum["anomalies"] != 2.0 || sum["errors"] != 0.0 {
		t.Errorf("summary %v, want 2 anomalies, no error", sum)
	}
}

// A run after a partial one does only what is left: the leaver whose
// disable failed is disabled, and nothing else is done again. A third run
// does nothing. So a run after a failed Job, a retry or the next schedule,
// is idempotent.
func TestRunAgainAfterAPartialRun(t *testing.T) {
	f := withAllGroups(t)
	f.failDisable = map[string]bool{"kc-leaver": true}
	var out bytes.Buffer
	if err := f.run(Config{}, Audit{W: &out}); exitCode(err) != 2 {
		t.Fatalf("first run: %v, exit %d, want 2", err, exitCode(err))
	}
	if strings.Join(f.disabled, ",") != "" || strings.Join(f.logouts, ",") != "kc-leaver,kc-moved,kc-ref" {
		t.Fatalf("first run: disabled %v, sessions ended for %v", f.disabled, f.logouts)
	}
	f.failDisable = nil
	for i, want := range []struct{ disabled, logouts string }{{"kc-leaver", "kc-leaver"}, {"", ""}} {
		f.disabled, f.logouts = nil, nil
		out.Reset()
		if err := f.run(Config{}, Audit{W: &out}); err != nil {
			t.Errorf("run %d: %v\n%s", i+2, err, out.String())
		}
		if strings.Join(f.disabled, ",") != want.disabled || strings.Join(f.logouts, ",") != want.logouts {
			t.Errorf("run %d: disabled %v, sessions ended for %v; want %q and %q", i+2, f.disabled, f.logouts, want.disabled, want.logouts)
		}
	}
}

// A run whose context ends, at the job's deadline or a SIGTERM, stops and
// fails: what it could not do then is not the fault of each user it had
// left, so it records no read or disable failure for any of them.
func TestRunStopsWhenCancelled(t *testing.T) {
	for _, at := range []string{"GET /users/kc-dev/federated-identity", "PUT /users/kc-leaver"} {
		f := withAllGroups(t)
		f.cancelOn = at
		var out bytes.Buffer
		err := f.run(Config{}, Audit{W: &out})
		if exitCode(err) != 1 || !errors.Is(err, context.Canceled) {
			t.Errorf("cancelled at %s: Run %v, exit %d, want 1 and the cancellation", at, err, exitCode(err))
		}
		if strings.Contains(out.String(), `"event":"reconcile.anomaly"`) {
			t.Errorf("cancelled at %s: anomalies recorded:\n%s", at, out.String())
		}
		if len(f.logouts) != 0 {
			t.Errorf("cancelled at %s: sessions ended for %v after the cancellation", at, f.logouts)
		}
	}
}

// A user whose logout fails is a fault anomaly naming them, so the SIEM
// sees it, and the run goes on: the leaver is still disabled, and the
// next user handled. A disabled user can no longer refresh or pass
// introspection, which Keycloak refuses for a disabled user, so the
// leaver's remaining exposure is their last access token's life.
func TestRunRecordsAFailedLogout(t *testing.T) {
	f := withAllGroups(t)
	f.failLogout = map[string]bool{"kc-leaver": true}
	var out bytes.Buffer
	err := f.run(Config{}, Audit{W: &out})
	if exitCode(err) != 2 {
		t.Errorf("Run: %v, exit %d, want 2 for the failed logout", err, exitCode(err))
	}
	if strings.Join(f.disabled, ",") != "kc-leaver" || strings.Join(f.logouts, ",") != "kc-moved,kc-ref" {
		t.Errorf("disabled %v, sessions ended for %v: want the leaver disabled, and the others' sessions ended", f.disabled, f.logouts)
	}
	recs := records(t, out.String())
	a := anomalies(recs, "end_sessions_failed")["kc-leaver"]
	if a == nil || a["reason"] != "okta_suspended" || !strings.Contains(fmt.Sprint(a["error"]), "500") {
		t.Errorf("no end_sessions_failed anomaly for kc-leaver with its reason and error: %v", recs)
	}
	if sum := only(t, recs, "reconcile.run"); sum["anomalies"] != 1.0 || sum["faults"] != 1.0 || sum["errors"] != 0.0 || sum["sessions_ended"] != 2.0 {
		t.Errorf("summary %v, want 1 fault, no error, 2 sessions ended", sum)
	}
}

// Every user Keycloak disabled or logged out has exactly one record of it,
// and nobody else has one: also when the run's context ends just after
// Keycloak answered a disable or a logout, so the job took the action
// and then stopped.
func TestRunRecordsEveryActionItTook(t *testing.T) {
	for _, after := range []string{"", "PUT /users/kc-leaver", "POST /users/kc-leaver/logout", "POST /users/kc-moved/logout"} {
		f := withAllGroups(t)
		f.cancelAfter = after
		var out bytes.Buffer
		err := f.run(Config{}, Audit{W: &out})
		if want := map[bool]int{true: 0, false: 1}[after == ""]; exitCode(err) != want {
			t.Errorf("cancelled after %q: Run %v, exit %d, want %d", after, err, exitCode(err), want)
		}
		for event, done := range map[string][]string{"keycloak.user_disabled": f.disabled, "keycloak.sessions_ended": f.logouts} {
			recorded := map[string]int{}
			for _, r := range records(t, out.String()) {
				if r["event"] == event {
					recorded[fmt.Sprint(r["user_id"])]++
				}
			}
			for _, id := range done {
				if recorded[id] != 1 {
					t.Errorf("cancelled after %q: %s has %d %s records, want 1:\n%s", after, id, recorded[id], event, out.String())
				}
				delete(recorded, id)
			}
			if len(recorded) != 0 {
				t.Errorf("cancelled after %q: %s records of no action Keycloak took: %v", after, event, recorded)
			}
		}
	}
}
