package reconcile

import (
	"context"
	"crypto/ecdsa"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

// OktaKey is the okta-reconciler app's private key, as stacks/okta-local's
// reconciler-key.sh stores it in Secrets Manager.
type OktaKey struct {
	Kid        string `json:"kid"`
	PrivateKey string `json:"private_key"`
}

// Okta reads users and group members with the okta-reconciler API service
// app: client credentials with private_key_jwt, scopes okta.users.read and
// okta.groups.read, through the org authorization server (decision Q1).
type Okta struct {
	Org      string // https://<org>.okta.com
	ClientID string
	Kid      string
	Key      *ecdsa.PrivateKey
	HTTP     *http.Client
	token    string
}

// ParseOktaKey reads the PKCS#8 EC P-256 key of an OktaKey.
func ParseOktaKey(k OktaKey) (*ecdsa.PrivateKey, error) {
	block, _ := pem.Decode([]byte(k.PrivateKey))
	if block == nil {
		return nil, errors.New("okta key: no PEM block")
	}
	parsed, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return nil, fmt.Errorf("okta key: %w", err)
	}
	key, ok := parsed.(*ecdsa.PrivateKey)
	if !ok || key.Curve.Params().BitSize != 256 {
		return nil, errors.New("okta key: not an EC P-256 key")
	}
	return key, nil
}

// Assertion is the client assertion of RFC 7523, signed ES256, for audience
// aud.
func (o *Okta) Assertion(aud string, now time.Time) (string, error) {
	b64 := base64.RawURLEncoding.EncodeToString
	header, _ := json.Marshal(map[string]string{"alg": "ES256", "kid": o.Kid, "typ": "JWT"})
	jti := make([]byte, 16)
	if _, err := rand.Read(jti); err != nil {
		return "", err
	}
	claims, _ := json.Marshal(map[string]any{
		"iss": o.ClientID, "sub": o.ClientID, "aud": aud,
		"iat": now.Unix(), "exp": now.Add(5 * time.Minute).Unix(), "jti": b64(jti),
	})
	input := b64(header) + "." + b64(claims)
	digest := sha256.Sum256([]byte(input))
	r, s, err := ecdsa.Sign(rand.Reader, o.Key, digest[:])
	if err != nil {
		return "", err
	}
	sig := make([]byte, 64) // JWS: R and S, 32 bytes each (RFC 7518, 3.4)
	r.FillBytes(sig[:32])
	s.FillBytes(sig[32:])
	return input + "." + b64(sig), nil
}

// Authenticate gets an access token for the Okta API.
func (o *Okta) Authenticate(ctx context.Context) error {
	endpoint := o.Org + "/oauth2/v1/token"
	assertion, err := o.Assertion(endpoint, time.Now())
	if err != nil {
		return err
	}
	form := url.Values{
		"grant_type":            {"client_credentials"},
		"scope":                 {"okta.users.read okta.groups.read"},
		"client_assertion_type": {"urn:ietf:params:oauth:client-assertion-type:jwt-bearer"},
		"client_assertion":      {assertion},
	}
	var t struct {
		AccessToken string `json:"access_token"`
		Error       string `json:"error"`
		Description string `json:"error_description"`
	}
	if err := postForm(ctx, o.HTTP, endpoint, form, &t); err != nil {
		return fmt.Errorf("okta token: %w", err)
	}
	if t.AccessToken == "" {
		return fmt.Errorf("okta token: %s: %s", t.Error, t.Description)
	}
	o.token = t.AccessToken
	return nil
}

var nextLink = regexp.MustCompile(`<([^>]+)>;\s*rel="next"`)

// list GETs every page of an Okta collection, following its Link headers.
func (o *Okta) list(ctx context.Context, path string, each func(json.RawMessage) error) error {
	next := o.Org + path
	for next != "" {
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, next, nil)
		if err != nil {
			return err
		}
		req.Header.Set("Authorization", "Bearer "+o.token)
		req.Header.Set("Accept", "application/json")
		resp, err := o.HTTP.Do(req)
		if err != nil {
			return err
		}
		var page []json.RawMessage
		err = decode(resp, &page)
		if err != nil {
			return fmt.Errorf("okta %s: %w", path, err)
		}
		for _, item := range page {
			if err := each(item); err != nil {
				return err
			}
		}
		next = ""
		for _, l := range resp.Header.Values("Link") {
			if m := nextLink.FindStringSubmatch(l); m != nil {
				next = m[1]
			}
		}
	}
	return nil
}

// Users returns every Okta user's status by user ID. Okta's default list
// leaves deprovisioned users out, so they are listed apart.
func (o *Okta) Users(ctx context.Context) (map[string]OktaUser, error) {
	users := map[string]OktaUser{}
	add := func(raw json.RawMessage) error {
		var u struct {
			ID     string `json:"id"`
			Status string `json:"status"`
		}
		if err := json.Unmarshal(raw, &u); err != nil {
			return err
		}
		users[u.ID] = OktaUser{Status: u.Status}
		return nil
	}
	if err := o.list(ctx, "/api/v1/users?limit=200", add); err != nil {
		return nil, err
	}
	if err := o.list(ctx, "/api/v1/users?limit=200&filter="+url.QueryEscape(`status eq "DEPROVISIONED"`), add); err != nil {
		return nil, err
	}
	return users, nil
}

// AddGroups records, for each user, which of the named groups hold it, and
// returns the names Okta has no group for, in the order given: such a group
// holds no one. It stops at the first group it cannot read, with the names
// found missing until then.
func (o *Okta) AddGroups(ctx context.Context, users map[string]OktaUser, names []string) ([]string, error) {
	var missing []string
	for _, name := range names {
		var id string
		err := o.list(ctx, "/api/v1/groups?q="+url.QueryEscape(name), func(raw json.RawMessage) error {
			var g struct {
				ID      string `json:"id"`
				Profile struct {
					Name string `json:"name"`
				} `json:"profile"`
			}
			if err := json.Unmarshal(raw, &g); err != nil {
				return err
			}
			if g.Profile.Name == name {
				id = g.ID
			}
			return nil
		})
		if err != nil {
			return missing, err
		}
		if id == "" {
			missing = append(missing, name)
			continue
		}
		err = o.list(ctx, "/api/v1/groups/"+id+"/users?limit=200", func(raw json.RawMessage) error {
			var u struct {
				ID string `json:"id"`
			}
			if err := json.Unmarshal(raw, &u); err != nil {
				return err
			}
			if x, ok := users[u.ID]; ok {
				x.Groups = append(x.Groups, name)
				users[u.ID] = x
			}
			return nil
		})
		if err != nil {
			return missing, err
		}
	}
	return missing, nil
}

func postForm(ctx context.Context, c *http.Client, endpoint string, form url.Values, out any) error {
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, strings.NewReader(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")
	resp, err := c.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return json.NewDecoder(resp.Body).Decode(out)
}

// decode reads a JSON body, or an error with the status for any other.
func decode(resp *http.Response, out any) error {
	defer resp.Body.Close()
	if resp.StatusCode/100 != 2 {
		var e map[string]any
		_ = json.NewDecoder(resp.Body).Decode(&e)
		return fmt.Errorf("HTTP %d: %v", resp.StatusCode, e)
	}
	if out == nil {
		return nil
	}
	return json.NewDecoder(resp.Body).Decode(out)
}
