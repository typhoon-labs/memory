package reconcile

import (
	"encoding/json"
	"testing"
)

func testAccess(t *testing.T) Access {
	t.Helper()
	var a Access
	if err := json.Unmarshal([]byte(`{
	  "roles": [{"name": "developer", "group": "agentic-developer"}, {"name": "platform-engineer", "group": "agentic-platform-engineer"}],
	  "teams": [{"slug": "payments", "group": "agentic-team-payments"}, {"slug": "platform", "group": "agentic-team-platform"}]}`), &a); err != nil {
		t.Fatal(err)
	}
	return a
}

// plan is one run's decisions: the leavers, then the changes of roles or
// team, as Run takes them.
func plan(access Access, okta map[string]OktaUser, users []KeycloakUser) ([]Action, []Anomaly) {
	changes, anomalies := Changes(access, okta, users)
	return append(Leavers(okta, users), changes...), anomalies
}

func TestPlan(t *testing.T) {
	a := testAccess(t)
	dev := []string{"agentic-developer", "agentic-team-payments"}
	okta := map[string]OktaUser{
		"00u-active":      {Status: "ACTIVE", Groups: dev},
		"00u-suspended":   {Status: "SUSPENDED", Groups: dev},
		"00u-deprov":      {Status: "DEPROVISIONED"},
		"00u-locked":      {Status: "LOCKED_OUT", Groups: dev},
		"00u-moved":       {Status: "ACTIVE", Groups: []string{"agentic-developer", "agentic-team-platform"}},
		"00u-promoted":    {Status: "ACTIVE", Groups: append([]string{"agentic-platform-engineer"}, dev...)},
		"00u-two-teams":   {Status: "ACTIVE", Groups: []string{"agentic-developer", "agentic-team-payments", "agentic-team-platform"}},
		"00u-moved-quiet": {Status: "ACTIVE", Groups: []string{"agentic-team-platform"}},
	}
	user := func(id string, session bool) KeycloakUser {
		return KeycloakUser{ID: "kc-" + id, OktaID: id, Roles: []string{"developer"}, Teams: []string{"payments"}, HasSession: session}
	}
	users := []KeycloakUser{
		user("00u-active", true), user("00u-suspended", true), user("00u-deprov", false), user("00u-gone", true),
		user("00u-locked", true), user("00u-moved", true), user("00u-promoted", true), user("00u-two-teams", true),
		user("00u-moved-quiet", false),
	}
	actions, anomalies := plan(a, okta, users)
	got := map[string]Action{}
	for _, x := range actions {
		got[x.User.OktaID] = x
	}
	want := map[string]struct {
		disable bool
		reason  string
	}{
		"00u-suspended": {true, "okta_suspended"},
		"00u-deprov":    {true, "okta_deprovisioned"},
		"00u-gone":      {true, "okta_user_gone"},
		"00u-moved":     {false, "roles_or_team_changed"},
		"00u-promoted":  {false, "roles_or_team_changed"},
		"00u-two-teams": {false, "roles_or_team_changed"},
	}
	if len(got) != len(want) {
		t.Errorf("got %d actions, want %d: %+v", len(got), len(want), actions)
	}
	for id, w := range want {
		g, ok := got[id]
		if !ok {
			t.Errorf("%s: no action, want %+v", id, w)
			continue
		}
		if g.Disable != w.disable || g.Reason != w.reason || !g.EndSessions {
			t.Errorf("%s: got disable=%v reason=%s end=%v, want disable=%v reason=%s end=true", id, g.Disable, g.Reason, g.EndSessions, w.disable, w.reason)
		}
	}
	for _, id := range []string{"00u-active", "00u-locked", "00u-moved-quiet"} {
		if _, ok := got[id]; ok {
			t.Errorf("%s: unexpected action %+v", id, got[id])
		}
	}
	if len(anomalies) != 1 || anomalies[0].User.OktaID != "00u-two-teams" || anomalies[0].Kind != "two_teams" {
		t.Errorf("anomalies: got %+v, want one two_teams for 00u-two-teams", anomalies)
	}
}

func TestPlanNeverReenables(t *testing.T) {
	// Plan sees enabled users only and has no action that enables one.
	for _, x := range func() []Action {
		a, _ := plan(testAccess(t), map[string]OktaUser{"x": {Status: "ACTIVE"}}, []KeycloakUser{{OktaID: "x", HasSession: true, Roles: []string{"developer"}}})
		return a
	}() {
		if !x.EndSessions || x.Disable {
			t.Errorf("unexpected action %+v", x)
		}
	}
}

func TestGrants(t *testing.T) {
	roles, teams := Grants(testAccess(t), []string{"agentic-team-platform", "agentic-platform-engineer", "other"})
	if !same(roles, []string{"platform-engineer"}) || !same(teams, []string{"platform"}) {
		t.Errorf("got roles %v teams %v", roles, teams)
	}
}

// Each kind of anomaly has its class: a person in two team groups is
// data, which leaves the exit at 0; what the run could not do is a fault,
// which makes it 2; and a kind no one classed counts as a fault.
func TestKinds(t *testing.T) {
	for kind, want := range map[string]Class{TwoTeams: Data, MissingGroup: Fault, DisableFailed: Fault, EndSessionsFailed: Fault, ReadFailed: Fault, "a_new_kind": Fault} {
		if Kinds[kind] != want {
			t.Errorf("%s: class %d, want %d", kind, Kinds[kind], want)
		}
	}
	if len(Kinds) != 5 {
		t.Errorf("Kinds has %d kinds, want 5: a new kind needs its class here and a case above", len(Kinds))
	}
}
