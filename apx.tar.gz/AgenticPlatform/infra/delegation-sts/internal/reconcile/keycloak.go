package reconcile

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"strings"
)

// Keycloak reads and changes the realm's users through the Admin API as the
// okta-reconciler client, which authenticates with the job's projected
// service-account token (federated client authentication). Its token holds
// the kc-admin-api scope and the realm-management roles query-users,
// view-users and manage-users.
type Keycloak struct {
	URL       string // https://keycloak.<platform.domain>
	Realm     string
	IdPAlias  string // the realm's alias for Okta
	TokenFile string // the projected service-account token
	HTTP      *http.Client
	token     string
}

// Authenticate gets an access token with the service-account token as the
// client assertion. The file is read on every run: the kubelet rotates it.
func (k *Keycloak) Authenticate(ctx context.Context) error {
	sa, err := os.ReadFile(k.TokenFile)
	if err != nil {
		return err
	}
	form := url.Values{
		"grant_type":            {"client_credentials"},
		"client_assertion_type": {"urn:ietf:params:oauth:client-assertion-type:jwt-bearer"},
		"client_assertion":      {strings.TrimSpace(string(sa))},
	}
	var t struct {
		AccessToken string `json:"access_token"`
		Scope       string `json:"scope"`
		Error       string `json:"error"`
		Description string `json:"error_description"`
	}
	if err := postForm(ctx, k.HTTP, k.URL+"/realms/"+k.Realm+"/protocol/openid-connect/token", form, &t); err != nil {
		return fmt.Errorf("keycloak token: %w", err)
	}
	if t.AccessToken == "" {
		return fmt.Errorf("keycloak token: %s: %s", t.Error, t.Description)
	}
	k.token = t.AccessToken
	return nil
}

func (k *Keycloak) do(ctx context.Context, method, path string, body, out any) error {
	var r *bytes.Reader
	if body != nil {
		b, err := json.Marshal(body)
		if err != nil {
			return err
		}
		r = bytes.NewReader(b)
	} else {
		r = bytes.NewReader(nil)
	}
	req, err := http.NewRequestWithContext(ctx, method, k.URL+"/admin/realms/"+k.Realm+path, r)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+k.token)
	req.Header.Set("Accept", "application/json")
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp, err := k.HTTP.Do(req)
	if err != nil {
		return err
	}
	if err := decode(resp, out); err != nil {
		return fmt.Errorf("keycloak %s %s: %w", method, path, err)
	}
	return nil
}

// LinkedUsers returns the enabled users linked to the identity provider,
// with their Okta user IDs: all that the leaver path needs. A user whose
// link cannot be read comes back with Err set and no OktaID, and the others
// are read as usual; only a failed page of the user list, or the end of
// ctx, fails the call.
func (k *Keycloak) LinkedUsers(ctx context.Context) ([]KeycloakUser, error) {
	var out []KeycloakUser
	const page = 100
	for first := 0; ; first += page {
		var users []struct {
			ID       string `json:"id"`
			Username string `json:"username"`
			Enabled  bool   `json:"enabled"`
		}
		q := url.Values{"idpAlias": {k.IdPAlias}, "briefRepresentation": {"true"}, "first": {fmt.Sprint(first)}, "max": {fmt.Sprint(page)}}
		if err := k.do(ctx, http.MethodGet, "/users?"+q.Encode(), nil, &users); err != nil {
			return nil, err
		}
		for _, u := range users {
			if !u.Enabled {
				continue
			}
			ku := KeycloakUser{ID: u.ID, Username: u.Username}
			var links []struct {
				IdentityProvider string `json:"identityProvider"`
				UserID           string `json:"userId"`
			}
			if err := k.do(ctx, http.MethodGet, "/users/"+u.ID+"/federated-identity", nil, &links); err != nil {
				if ctx.Err() != nil {
					return nil, ctx.Err()
				}
				ku.Err = err
				out = append(out, ku)
				continue
			}
			for _, l := range links {
				if l.IdentityProvider == k.IdPAlias {
					ku.OktaID = l.UserID
				}
			}
			if ku.OktaID != "" {
				out = append(out, ku)
			}
		}
		if len(users) < page {
			return out, nil
		}
	}
}

// AddAccess reads, for each user with an Okta user ID and no Err, the
// roles and teams Access names and whether it holds a session. A failure
// sets that user's Err and leaves the others to be read; the end of ctx
// stops it, with ctx's error.
func (k *Keycloak) AddAccess(ctx context.Context, access Access, users []KeycloakUser) error {
	roleNames := map[string]bool{}
	for _, r := range access.Roles {
		roleNames[r.Name] = true
	}
	teamPaths := map[string]string{}
	for _, t := range access.Teams {
		teamPaths["/teams/"+t.Slug] = t.Slug
	}
	for i := range users {
		if err := ctx.Err(); err != nil {
			return err
		}
		ku := &users[i]
		if ku.OktaID == "" || ku.Err != nil {
			continue
		}
		var roles []struct {
			Name string `json:"name"`
		}
		var groups []struct {
			Path string `json:"path"`
		}
		var sessions []json.RawMessage
		err := k.do(ctx, http.MethodGet, "/users/"+ku.ID+"/role-mappings/realm", nil, &roles)
		if err == nil {
			err = k.do(ctx, http.MethodGet, "/users/"+ku.ID+"/groups", nil, &groups)
		}
		if err == nil {
			err = k.do(ctx, http.MethodGet, "/users/"+ku.ID+"/sessions", nil, &sessions)
		}
		if ctx.Err() != nil {
			return ctx.Err()
		}
		if err != nil {
			ku.Err = err
			continue
		}
		for _, r := range roles {
			if roleNames[r.Name] {
				ku.Roles = append(ku.Roles, r.Name)
			}
		}
		for _, g := range groups {
			if slug, ok := teamPaths[g.Path]; ok {
				ku.Teams = append(ku.Teams, slug)
			}
		}
		ku.HasSession = len(sessions) > 0
	}
	return nil
}

// Disable disables a user, keeping the rest of its representation.
func (k *Keycloak) Disable(ctx context.Context, id string) error {
	var rep map[string]any
	if err := k.do(ctx, http.MethodGet, "/users/"+id, nil, &rep); err != nil {
		return err
	}
	rep["enabled"] = false
	return k.do(ctx, http.MethodPut, "/users/"+id, rep, nil)
}

// EndSessions ends every session of a user.
func (k *Keycloak) EndSessions(ctx context.Context, id string) error {
	return k.do(ctx, http.MethodPost, "/users/"+id+"/logout", nil, nil)
}
