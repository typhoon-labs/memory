package reconcile

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"slices"
	"strings"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/internal/otlp"
)

// Config is the job's environment.
type Config struct {
	OktaOrg, OktaClientID, OktaKeyFile         string
	KeycloakURL, Realm, IdPAlias, KeycloakFile string
	AccessFile, CAFile                         string
	DryRun                                     bool
	// AuditEndpoint is the collector's platform port, OTLP over gRPC,
	// http://<host>:<port>; empty, the audit records go to stdout.
	AuditEndpoint string
}

// ConfigFromEnv reads the Config from the job's environment variables.
func ConfigFromEnv() (Config, error) {
	c := Config{
		OktaOrg: os.Getenv("OKTA_ORG_URL"), OktaClientID: os.Getenv("OKTA_CLIENT_ID"), OktaKeyFile: os.Getenv("OKTA_KEY_FILE"),
		KeycloakURL: os.Getenv("KEYCLOAK_URL"), Realm: os.Getenv("KEYCLOAK_REALM"), IdPAlias: os.Getenv("KEYCLOAK_IDP_ALIAS"),
		KeycloakFile: os.Getenv("KEYCLOAK_TOKEN_FILE"), AccessFile: os.Getenv("ACCESS_FILE"), CAFile: os.Getenv("CA_FILE"),
		DryRun: os.Getenv("DRY_RUN") == "true", AuditEndpoint: os.Getenv("AUDIT_OTLP_ENDPOINT"),
	}
	var missing []string
	for name, v := range map[string]string{"OKTA_ORG_URL": c.OktaOrg, "OKTA_CLIENT_ID": c.OktaClientID, "OKTA_KEY_FILE": c.OktaKeyFile,
		"KEYCLOAK_URL": c.KeycloakURL, "KEYCLOAK_REALM": c.Realm, "KEYCLOAK_IDP_ALIAS": c.IdPAlias,
		"KEYCLOAK_TOKEN_FILE": c.KeycloakFile, "ACCESS_FILE": c.AccessFile} {
		if v == "" {
			missing = append(missing, name)
		}
	}
	if len(missing) > 0 {
		return c, fmt.Errorf("missing environment: %s", strings.Join(missing, ", "))
	}
	if c.AuditEndpoint != "" {
		if _, err := otlp.ParseEndpoint(c.AuditEndpoint); err != nil {
			return c, fmt.Errorf("AUDIT_OTLP_ENDPOINT: %w", err)
		}
	}
	return c, nil
}

// HTTPClient trusts the system's roots and, if named, the platform's CA.
func HTTPClient(caFile string) (*http.Client, error) {
	pool, err := x509.SystemCertPool()
	if err != nil || pool == nil {
		pool = x509.NewCertPool()
	}
	if caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return nil, err
		}
		if !pool.AppendCertsFromPEM(pem) {
			return nil, fmt.Errorf("%s holds no certificate", caFile)
		}
	}
	return &http.Client{Timeout: 30 * time.Second, Transport: &http.Transport{
		TLSClientConfig: &tls.Config{RootCAs: pool, MinVersion: tls.VersionTLS12}, Proxy: nil}}, nil
}

// AuditTimeout bounds each export of an audit record.
const AuditTimeout = 5 * time.Second

// Exporter sends log records to the collector: *otlp.Client.
type Exporter interface {
	Export(ctx context.Context, recs ...otlp.Record) error
}

// Exported says whether a record is one of the job's audit records, the
// only records it exports: one for each user it disables and one for each
// user whose sessions it ends (design/identity.md, "The reconciliation
// job", step 5), and each anomaly, so that the SIEM sees what the run could
// not do or found wrong. A dry run's records and the run's summary stay on
// stdout.
func Exported(event string, fields map[string]any) bool {
	if dryRun, _ := fields["dry_run"].(bool); dryRun {
		return false
	}
	switch event {
	case "keycloak.user_disabled", "keycloak.sessions_ended", "reconcile.anomaly":
		return true
	}
	return false
}

// Audit writes the job's records, one JSON record per line on W. With
// OTLP, an audit record (Exported) goes to the collector instead, as an
// OTel log record whose attributes are its fields and event.name its
// event; an anomaly goes to W as well, as the run's log. A dry run's
// records stay on W, since the audit bucket keeps what it is given. Once
// an export has failed, the run's later records go to W too. A failed
// export never fails the run, so the leaver path never waits on telemetry.
type Audit struct {
	W    io.Writer
	OTLP Exporter  // optional
	Errs io.Writer // where a failed export is reported; optional
	down bool
}

// Faults is Run's error when it did all the work it could and recorded
// faults (Kinds), and nothing failed outright.
type Faults struct{ N int }

func (f Faults) Error() string {
	return fmt.Sprintf("%d faults recorded: see the run's anomalies", f.N)
}

// ExitCode is the job's exit code for a run that recorded faults.
func (Faults) ExitCode() int { return 2 }

// Record writes one audit record.
func (a *Audit) Record(event string, fields map[string]any) {
	now := time.Now().UTC()
	if a.OTLP != nil && !a.down && Exported(event, fields) {
		attrs := make(map[string]any, len(fields)+1)
		for k, v := range fields {
			attrs[k] = v
		}
		attrs["event.name"] = event
		err := a.OTLP.Export(context.Background(), otlp.Record{Time: now, Attributes: attrs})
		switch {
		case err != nil:
			a.down = true
			if a.Errs != nil {
				fmt.Fprintf(a.Errs, "reconcile: the collector did not take an audit record; the run's records go to stdout: %v\n", err)
			}
		case event != "reconcile.anomaly":
			return
		}
	}
	rec := map[string]any{"time": now.Format(time.RFC3339Nano), "event": event}
	for k, v := range fields {
		rec[k] = v
	}
	b, _ := json.Marshal(rec)
	fmt.Fprintln(a.W, string(b))
}

// Run is one reconciliation: read Okta's users and each Keycloak user's
// link to Okta, disable the leavers and end their sessions, then read the
// members of Okta's groups and each remaining user's roles, team and
// sessions, and end the sessions of people whose roles or team changed. It
// changes nothing unless both lists of users can be read, and refuses to
// act on an Okta that returns no users, which would read as everyone having
// left.
//
// The leavers never wait on the groups. What fails for one user, a team
// or a role is an anomaly, never the end of the run: a group Okta does
// not have holds no one, so nobody gains its role or team; a user whose
// link cannot be read is never taken for a leaver, and one whose roles,
// team or sessions cannot be read never for a change; a leaver Keycloak
// will not disable still loses their sessions, and a user Keycloak will
// not log out is recorded and passed over. A group Okta cannot read
// leaves everyone's roles and team unknown, so the run then ends no
// session for a change, and fails. A run whose context ends, at the
// job's deadline or a SIGTERM, stops and fails, and blames no user for
// it.
//
// After its summary, Run returns the errors of what failed outright, or
// else Faults if it recorded a fault, or else nil: the job exits 1, 2 or
// 0.
func Run(ctx context.Context, cfg Config, okta *Okta, kc *Keycloak, audit Audit) error {
	start := time.Now()
	raw, err := os.ReadFile(cfg.AccessFile)
	if err != nil {
		return err
	}
	var access Access
	if err := json.Unmarshal(raw, &access); err != nil {
		return fmt.Errorf("%s: %w", cfg.AccessFile, err)
	}
	if err := okta.Authenticate(ctx); err != nil {
		return err
	}
	users, err := okta.Users(ctx)
	if err != nil {
		return err
	}
	if len(users) == 0 {
		return errors.New("okta returned no users: refusing to act")
	}
	if err := kc.Authenticate(ctx); err != nil {
		return err
	}
	linked, err := kc.LinkedUsers(ctx)
	if err != nil {
		return err
	}
	var failed []error
	disabled, ended, anomalies, faults := 0, 0, 0, 0
	anomaly := func(kind string, fields map[string]any) {
		anomalies++
		if Kinds[kind] == Fault {
			faults++
		}
		fields["kind"], fields["dry_run"] = kind, cfg.DryRun
		audit.Record("reconcile.anomaly", fields)
	}
	userAnomaly := func(kind string, u KeycloakUser, fields map[string]any) {
		fields["user_id"], fields["username"] = u.ID, u.Username
		if u.OktaID != "" {
			fields["idp_user_id"] = u.OktaID
		}
		anomaly(kind, fields)
	}
	unread := func(users []KeycloakUser) {
		for _, u := range users {
			if u.Err != nil {
				userAnomaly(ReadFailed, u, map[string]any{"error": u.Err.Error()})
			}
		}
	}
	// act stops at the end of ctx, the job's deadline or a SIGTERM: what is
	// left undone then is the run's failure, not each user's. A call that
	// succeeded is recorded first, even after ctx ended: Keycloak took the
	// action, so the audit trail must hold it.
	act := func(actions []Action) {
		for _, a := range actions {
			if err := ctx.Err(); err != nil {
				failed = append(failed, err)
				return
			}
			who := map[string]any{"user_id": a.User.ID, "username": a.User.Username, "idp_user_id": a.User.OktaID,
				"reason": a.Reason, "dry_run": cfg.DryRun}
			if a.Disable {
				var err error
				if !cfg.DryRun {
					err = kc.Disable(ctx, a.User.ID)
				}
				switch {
				case err == nil:
					disabled++
					audit.Record("keycloak.user_disabled", who)
				case ctx.Err() != nil:
					failed = append(failed, ctx.Err())
					return
				default:
					// The sessions still end: they are what the person
					// could use, and the next run tries the disable again.
					userAnomaly(DisableFailed, a.User, map[string]any{"reason": a.Reason, "error": err.Error()})
				}
			}
			if a.EndSessions {
				var err error
				if !cfg.DryRun {
					err = kc.EndSessions(ctx, a.User.ID)
				}
				switch {
				case err == nil:
				case ctx.Err() != nil:
					failed = append(failed, ctx.Err())
					return
				default:
					// A leaver stays disabled, which Keycloak's refresh and
					// introspection refuse; a change is tried again next run.
					userAnomaly(EndSessionsFailed, a.User, map[string]any{"reason": a.Reason, "error": err.Error()})
					continue
				}
				ended++
				if a.WantRoles != nil || a.WantTeams != nil || !a.Disable {
					who["roles"], who["want_roles"], who["teams"], who["want_teams"] = a.User.Roles, a.WantRoles, a.User.Teams, a.WantTeams
				}
				audit.Record("keycloak.sessions_ended", who)
			}
		}
	}
	unread(linked)
	act(Leavers(users, linked))

	var groups []string
	for _, r := range access.Roles {
		groups = append(groups, r.Group)
	}
	for _, t := range access.Teams {
		groups = append(groups, t.Group)
	}
	missing, err := okta.AddGroups(ctx, users, groups)
	report := func(grant, name, group string) {
		if slices.Contains(missing, group) {
			anomaly(MissingGroup, map[string]any{grant: name, "group": group})
		}
	}
	for _, r := range access.Roles {
		report("role", r.Name, r.Group)
	}
	for _, t := range access.Teams {
		report("team", t.Slug, t.Group)
	}
	if err != nil {
		failed = append(failed, err)
	} else {
		staying := slices.DeleteFunc(slices.Clone(linked), func(u KeycloakUser) bool {
			_, gone := left(users, u)
			return gone || u.Err != nil
		})
		if err := kc.AddAccess(ctx, access, staying); err != nil {
			failed = append(failed, err)
		} else {
			unread(staying)
			changes, found := Changes(access, users, staying)
			for _, a := range found {
				userAnomaly(a.Kind, a.User, map[string]any{"detail": a.Detail})
			}
			act(changes)
		}
	}
	audit.Record("reconcile.run", map[string]any{"okta_users": len(users), "keycloak_users": len(linked),
		"disabled": disabled, "sessions_ended": ended, "anomalies": anomalies, "faults": faults, "errors": len(failed),
		"duration_ms": time.Since(start).Milliseconds(), "dry_run": cfg.DryRun})
	switch {
	case len(failed) > 0:
		return errors.Join(failed...)
	case faults > 0:
		return Faults{N: faults}
	}
	return nil
}
