// Package reconcile is the Okta-to-Keycloak reconciliation job
// (design/identity.md, "The reconciliation job"): every few minutes it
// reads Okta and ends what Okta no longer allows in Keycloak. It matches
// people by their Okta user ID, the user ID of their link to the okta
// identity provider, never by email or username. It disables leavers and
// ends their sessions, ends the sessions of people whose roles or team
// changed so their next sign-in applies the change, and never re-enables
// or deletes anyone.
package reconcile

import (
	"slices"
	"sort"
	"strings"
)

// Access is the platform's roles and teams, each granted by one Okta group:
// environments' access/roles.yaml and access/teams.yaml.
type Access struct {
	Roles []struct {
		Name  string `json:"name"`
		Group string `json:"group"`
	} `json:"roles"`
	Teams []struct {
		Slug  string `json:"slug"`
		Group string `json:"group"`
	} `json:"teams"`
}

// OktaUser is what the job knows of one Okta user.
type OktaUser struct {
	Status string
	Groups []string // names of the Okta groups Access names that hold the user
}

// KeycloakUser is an enabled Keycloak user linked to Okta.
type KeycloakUser struct {
	ID         string
	Username   string
	OktaID     string   // the user ID of the user's link to the okta identity provider
	Roles      []string // realm roles, of those Access names
	Teams      []string // team slugs, from groups /teams/<slug>
	HasSession bool
	// Err is the failure to read the user. Without an OktaID, its link
	// could not be read, so the job cannot tell whether the person left;
	// with one, its roles, teams or sessions are unknown, so it may still
	// be a leaver but never a change.
	Err error
}

// Leaving statuses: Okta's own, for a person who must lose access.
var leaving = map[string]bool{"SUSPENDED": true, "DEPROVISIONED": true}

// Action is what the job does to one Keycloak user.
type Action struct {
	User        KeycloakUser
	Disable     bool
	EndSessions bool
	Reason      string
	WantRoles   []string
	WantTeams   []string
}

// Anomaly is reported, never acted on.
type Anomaly struct {
	User   KeycloakUser
	Kind   string
	Detail []string
}

// The kinds of anomaly the job records.
const (
	TwoTeams          = "two_teams"           // a person in two team groups
	MissingGroup      = "missing_group"       // a role or team whose group Okta does not have
	DisableFailed     = "disable_failed"      // a leaver Keycloak would not disable
	EndSessionsFailed = "end_sessions_failed" // a user whose sessions Keycloak would not end
	ReadFailed        = "read_failed"         // a Keycloak user who could not be read
)

// Class says what an anomaly means for the run. A fault is part of the
// run's work it could not do: the job exits 2 after its summary, so the
// failed Job alerts apart from the SIEM. A data anomaly is something in
// Okta or Keycloak for a person to look at, which the run handled: the
// exit stays 0, or the Job would fail every run until it is fixed.
type Class int

const (
	Fault Class = iota // the zero value: a kind absent from Kinds is a fault
	Data
)

// Kinds gives each kind of anomaly its class.
var Kinds = map[string]Class{
	TwoTeams:          Data,
	MissingGroup:      Fault,
	DisableFailed:     Fault,
	EndSessionsFailed: Fault,
	ReadFailed:        Fault,
}

// Leavers decides which Keycloak users have left: their Okta user is gone,
// SUSPENDED or DEPROVISIONED. Each is disabled and loses its sessions. okta
// maps Okta user IDs to users; Leavers reads their statuses alone, never
// their groups, so the leaver path never depends on Okta's groups. A user
// whose link could not be read is never taken for one who left.
func Leavers(okta map[string]OktaUser, users []KeycloakUser) []Action {
	var actions []Action
	for _, u := range users {
		if u.OktaID == "" {
			continue
		}
		if reason, gone := left(okta, u); gone {
			actions = append(actions, Action{User: u, Disable: true, EndSessions: true, Reason: reason})
		}
	}
	return actions
}

// Changes decides, for each Keycloak user who has not left and was read
// whole, whether the roles and team the mappers would give from the
// person's Okta groups differ from the user's, and reports a person in two
// team groups. A group Okta does not have holds no one, so nobody keeps or
// gains its role or team.
func Changes(access Access, okta map[string]OktaUser, users []KeycloakUser) ([]Action, []Anomaly) {
	var actions []Action
	var anomalies []Anomaly
	for _, u := range users {
		if _, gone := left(okta, u); gone || u.Err != nil || u.OktaID == "" {
			continue
		}
		roles, teams := Grants(access, okta[u.OktaID].Groups)
		if len(teams) > 1 {
			anomalies = append(anomalies, Anomaly{User: u, Kind: TwoTeams, Detail: teams})
		}
		if u.HasSession && (!same(roles, u.Roles) || !same(teams, u.Teams)) {
			actions = append(actions, Action{User: u, EndSessions: true, Reason: "roles_or_team_changed", WantRoles: roles, WantTeams: teams})
		}
	}
	return actions, anomalies
}

// left says whether a Keycloak user's Okta user has left, and why.
func left(okta map[string]OktaUser, u KeycloakUser) (string, bool) {
	o, found := okta[u.OktaID]
	switch {
	case !found:
		return "okta_user_gone", true
	case leaving[o.Status]:
		return "okta_" + strings.ToLower(o.Status), true
	}
	return "", false
}

// Grants is what the identity provider's mappers give a person with these
// Okta groups: the roles and team slugs whose group is among them.
func Grants(access Access, groups []string) (roles, teams []string) {
	for _, r := range access.Roles {
		if slices.Contains(groups, r.Group) {
			roles = append(roles, r.Name)
		}
	}
	for _, t := range access.Teams {
		if slices.Contains(groups, t.Group) {
			teams = append(teams, t.Slug)
		}
	}
	return sorted(roles), sorted(teams)
}

func same(a, b []string) bool { return slices.Equal(sorted(a), sorted(b)) }

func sorted(s []string) []string {
	out := slices.Clone(s)
	sort.Strings(out)
	return out
}
