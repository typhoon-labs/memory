package store

import (
	"io"
	"log/slog"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gitlab.com/typhoon_labs/agentic-platform-sandbox/infra/delegation-sts/policy"
)

var quiet = slog.New(slog.NewTextHandler(io.Discard, nil))

const pol = `version: 1
max_chain: 3
token_ttl_seconds: 300
carried_claims: [sid]
rate_limit: {per_second: 10, burst: 50}
agents:
  a:
    actor: ns/a
    routes: [gateway/a2a/a]
    after: [person]
    targets: [workloads-gateway/mcp/m]
`

func TestPolicyReload(t *testing.T) {
	path := filepath.Join(t.TempDir(), "policy.yaml")
	os.WriteFile(path, []byte(pol), 0o600)
	w, err := Open("policy", path, policy.Parse, quiet)
	if err != nil {
		t.Fatal(err)
	}
	first := w.Get()
	if first.Value.MaxChain != 3 || !strings.HasPrefix(first.Hash, "sha256:") {
		t.Fatalf("loaded %+v", first)
	}
	if changed, err := w.Reload(); changed || err != nil {
		t.Errorf("an unchanged file reloaded: %v %v", changed, err)
	}
	os.WriteFile(path, []byte(strings.Replace(pol, "max_chain: 3", "max_chain: 2", 1)), 0o600)
	if changed, err := w.Reload(); !changed || err != nil || w.Get().Value.MaxChain != 2 || w.Get().Hash == first.Hash {
		t.Errorf("a valid change was not swapped in: %v %v", changed, err)
	}
	good := w.Get()
	os.WriteFile(path, []byte(strings.Replace(pol, "max_chain: 3", "max_chain: 9", 1)), 0o600)
	if _, err := w.Reload(); err == nil {
		t.Error("a policy above the schema's caps was accepted")
	}
	if w.Get() != good || w.Errors() != 1 {
		t.Errorf("a bad reload replaced the last good policy, or was not counted (%d)", w.Errors())
	}
	os.Remove(path)
	if _, err := w.Reload(); err == nil || w.Get() != good {
		t.Error("a missing file replaced the last good policy")
	}
	if _, err := Open("policy", path, policy.Parse, quiet); err == nil {
		t.Error("Open accepted a missing file")
	}
}

func TestDenyList(t *testing.T) {
	d, err := ParseDenyList([]byte(`entries:
- sub: runbook
  added: 2026-11-16T10:00:00Z
- sub: test
  expires: 2027-01-01T00:00:00Z
`))
	if err != nil {
		t.Fatal(err)
	}
	ttl, leeway := 300*time.Second, 60*time.Second
	at := func(s string) time.Time { v, _ := time.Parse(time.RFC3339, s); return v }
	for _, c := range []struct {
		sub, now string
		want     bool
	}{
		{"runbook", "2026-11-16T10:05:59Z", true},
		{"runbook", "2026-11-16T10:06:00Z", false},
		{"test", "2026-12-31T23:59:59Z", true},
		{"test", "2027-01-01T00:00:00Z", false},
		{"other", "2026-11-16T10:00:00Z", false},
	} {
		if got := d.Denied(c.sub, at(c.now), ttl, leeway); got != c.want {
			t.Errorf("Denied(%s, %s) = %v", c.sub, c.now, got)
		}
	}
	for _, bad := range []string{"entries: [{added: 2026-11-16T10:00:00Z}]", "entries: [{sub: x}]", "entries: [{sub: x, added: 2026-11-16T10:00:00Z, expires: 2027-01-01T00:00:00Z}]", "entries: [{sub: x, until: 2027-01-01T00:00:00Z}]"} {
		if _, err := ParseDenyList([]byte(bad)); err == nil {
			t.Errorf("ParseDenyList(%q) succeeded", bad)
		}
	}
	if d, err := ParseDenyList([]byte("\n")); err != nil || d.Len() != 0 {
		t.Errorf("an empty file: %v", err)
	}
}
