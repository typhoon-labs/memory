// Package store holds the STS's hot-reloaded files: the policy and the
// deny list, each mounted from a ConfigMap. A file is re-read on a timer;
// a changed one is validated and swapped in atomically, and a bad one is
// logged and counted while the last good value stays in force. Each value
// carries the SHA-256 of the bytes it came from, which the audit records
// and metrics expose.
package store

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"log/slog"
	"os"
	"sync/atomic"
	"time"

	"go.yaml.in/yaml/v3"
)

// Loaded is a value and the file content it came from.
type Loaded[T any] struct {
	Value  T
	Hash   string // sha256:<hex> of the file's bytes
	Loaded time.Time
}

// Watched is a file's last good value.
type Watched[T any] struct {
	name, path string
	parse      func([]byte) (T, error)
	log        *slog.Logger
	cur        atomic.Pointer[Loaded[T]]
	errors     atomic.Int64
}

// Open loads a file, which must be valid, and returns it watched.
func Open[T any](name, path string, parse func([]byte) (T, error), log *slog.Logger) (*Watched[T], error) {
	w := &Watched[T]{name: name, path: path, parse: parse, log: log}
	if _, err := w.Reload(); err != nil {
		return nil, err
	}
	return w, nil
}

// Static returns a value that never changes, for an optional file left unset.
func Static[T any](name string, v T) *Watched[T] {
	w := &Watched[T]{name: name}
	w.cur.Store(&Loaded[T]{Value: v, Hash: "none", Loaded: time.Now()})
	return w
}

// Get returns the value in force.
func (w *Watched[T]) Get() *Loaded[T] { return w.cur.Load() }

// Errors counts the reloads refused since start.
func (w *Watched[T]) Errors() int64 { return w.errors.Load() }

// Reload re-reads the file. An unchanged file is not parsed again; a bad
// one leaves the last good value in force and returns the error.
func (w *Watched[T]) Reload() (bool, error) {
	if w.path == "" {
		return false, nil
	}
	raw, err := os.ReadFile(w.path)
	if err != nil {
		return false, w.refuse(err)
	}
	sum := sha256.Sum256(raw)
	hash := "sha256:" + hex.EncodeToString(sum[:])
	if cur := w.cur.Load(); cur != nil && cur.Hash == hash {
		return false, nil
	}
	v, err := w.parse(raw)
	if err != nil {
		return false, w.refuse(err)
	}
	w.cur.Store(&Loaded[T]{Value: v, Hash: hash, Loaded: time.Now()})
	if w.log != nil {
		w.log.Info(w.name+" loaded", "path", w.path, "hash", hash)
	}
	return true, nil
}

func (w *Watched[T]) refuse(err error) error {
	err = fmt.Errorf("%s %s: %w", w.name, w.path, err)
	if w.cur.Load() != nil {
		w.errors.Add(1)
		if w.log != nil {
			w.log.Error(w.name+" refused; the last good one stays in force", "err", err, "hash", w.cur.Load().Hash)
		}
	}
	return err
}

// Run reloads every interval until ctx ends.
func (w *Watched[T]) Run(ctx context.Context, interval time.Duration) {
	if w.path == "" {
		return
	}
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			w.Reload()
		}
	}
}

// DenyList is the kill switch's list of refused subjects. The runbook adds
// an entry with the time it was added; it expires one token lifetime plus
// the clock leeway later, when no chain token for that sub can still be
// valid. An entry may name its expiry instead, as a test release's does.
//
//	entries:
//	- sub: 6f1c2a9e-3b7d-4c55-9a0e-8d2f41b7c3a1
//	  added: 2026-11-16T10:00:00Z
//	- sub: 00000000-0000-4000-8000-00000000dead
//	  expires: 2027-01-01T00:00:00Z
type DenyList struct {
	entries map[string]denyEntry
}

type denyEntry struct{ added, expires time.Time }

// ParseDenyList reads a deny list; an empty file is an empty list.
func ParseDenyList(raw []byte) (*DenyList, error) {
	var doc struct {
		Entries []struct {
			Sub     string    `yaml:"sub"`
			Added   time.Time `yaml:"added"`
			Expires time.Time `yaml:"expires"`
		} `yaml:"entries"`
	}
	if len(bytes.TrimSpace(raw)) > 0 {
		dec := yaml.NewDecoder(bytes.NewReader(raw))
		dec.KnownFields(true)
		if err := dec.Decode(&doc); err != nil {
			return nil, err
		}
	}
	d := &DenyList{entries: map[string]denyEntry{}}
	for i, e := range doc.Entries {
		if e.Sub == "" {
			return nil, fmt.Errorf("entry %d has no sub", i)
		}
		if e.Added.IsZero() == e.Expires.IsZero() {
			return nil, fmt.Errorf("entry %d (%s) needs exactly one of added and expires", i, e.Sub)
		}
		d.entries[e.Sub] = denyEntry{e.Added, e.Expires}
	}
	return d, nil
}

// Empty is a deny list without entries.
func Empty() *DenyList { return &DenyList{entries: map[string]denyEntry{}} }

// Denied reports whether sub is on the list at now, for tokens that live
// ttl with leeway of clock skew.
func (d *DenyList) Denied(sub string, now time.Time, ttl, leeway time.Duration) bool {
	e, ok := d.entries[sub]
	if !ok {
		return false
	}
	until := e.expires
	if until.IsZero() {
		until = e.added.Add(ttl + leeway)
	}
	return now.Before(until)
}

// Len is the number of entries.
func (d *DenyList) Len() int { return len(d.entries) }
