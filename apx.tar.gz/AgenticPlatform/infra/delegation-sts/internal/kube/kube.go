// Package kube reviews actor tokens with the Kubernetes TokenReview API,
// the one Kubernetes call the STS makes. It reads in-cluster credentials or
// a kubeconfig, and supports the kubeconfig forms a bearer token needs
// (token, tokenFile, a CA file or data, or insecure-skip-tls-verify);
// client certificates and exec plugins are refused. Token files are re-read
// on every call, since projected tokens rotate.
//
// The STS has no TokenReview cache: that is what refuses a deleted pod's
// token within seconds.
package kube

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"go.yaml.in/yaml/v3"
)

// In-cluster credential locations.
const (
	tokenFile = "/var/run/secrets/kubernetes.io/serviceaccount/token"
	caFile    = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
)

// Reviewer calls TokenReview on one API server.
type Reviewer struct {
	server    string
	token     string
	tokenFile string
	client    *http.Client
}

// Result is a TokenReview's status.
type Result struct {
	Authenticated bool
	Username      string
	Audiences     []string
	Pod           string // authentication.kubernetes.io/pod-name, if the token is bound to a pod
	Error         string
}

// New returns a reviewer from a kubeconfig, or from the pod's in-cluster
// credentials when kubeconfig is empty.
func New(kubeconfig string) (*Reviewer, error) {
	if kubeconfig != "" {
		return fromKubeconfig(kubeconfig)
	}
	host, port := os.Getenv("KUBERNETES_SERVICE_HOST"), os.Getenv("KUBERNETES_SERVICE_PORT")
	if host == "" || port == "" {
		return nil, errors.New("not in a cluster (KUBERNETES_SERVICE_HOST unset) and no kubeconfig configured")
	}
	pem, err := os.ReadFile(caFile)
	if err != nil {
		return nil, err
	}
	tr, err := transport(pem, false)
	if err != nil {
		return nil, err
	}
	return &Reviewer{server: "https://" + net.JoinHostPort(host, port), tokenFile: tokenFile, client: &http.Client{Transport: tr, Timeout: 5 * time.Second}}, nil
}

type kubeconfig struct {
	CurrentContext string `yaml:"current-context"`
	Clusters       []struct {
		Name    string `yaml:"name"`
		Cluster struct {
			Server   string `yaml:"server"`
			CA       string `yaml:"certificate-authority"`
			CAData   string `yaml:"certificate-authority-data"`
			Insecure bool   `yaml:"insecure-skip-tls-verify"`
		} `yaml:"cluster"`
	} `yaml:"clusters"`
	Users []struct {
		Name string         `yaml:"name"`
		User map[string]any `yaml:"user"`
	} `yaml:"users"`
	Contexts []struct {
		Name    string `yaml:"name"`
		Context struct {
			Cluster string `yaml:"cluster"`
			User    string `yaml:"user"`
		} `yaml:"context"`
	} `yaml:"contexts"`
}

func fromKubeconfig(path string) (*Reviewer, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var kc kubeconfig
	if err := yaml.Unmarshal(raw, &kc); err != nil {
		return nil, fmt.Errorf("kubeconfig %s: %w", path, err)
	}
	var clusterName, userName string
	for _, c := range kc.Contexts {
		if c.Name == kc.CurrentContext {
			clusterName, userName = c.Context.Cluster, c.Context.User
		}
	}
	if clusterName == "" {
		return nil, fmt.Errorf("kubeconfig %s: no context %q", path, kc.CurrentContext)
	}
	r := &Reviewer{}
	var pem []byte
	insecure := false
	for _, c := range kc.Clusters {
		if c.Name != clusterName {
			continue
		}
		r.server = strings.TrimRight(c.Cluster.Server, "/")
		insecure = c.Cluster.Insecure
		switch {
		case c.Cluster.CAData != "":
			if pem, err = base64.StdEncoding.DecodeString(c.Cluster.CAData); err != nil {
				return nil, fmt.Errorf("kubeconfig %s: certificate-authority-data: %w", path, err)
			}
		case c.Cluster.CA != "":
			ca := c.Cluster.CA
			if !filepath.IsAbs(ca) {
				ca = filepath.Join(filepath.Dir(path), ca)
			}
			if pem, err = os.ReadFile(ca); err != nil {
				return nil, err
			}
		}
	}
	if r.server == "" {
		return nil, fmt.Errorf("kubeconfig %s: cluster %q has no server", path, clusterName)
	}
	for _, u := range kc.Users {
		if u.Name != userName {
			continue
		}
		for k, v := range u.User {
			switch k {
			case "token":
				r.token, _ = v.(string)
			case "tokenFile":
				r.tokenFile, _ = v.(string)
				if r.tokenFile != "" && !filepath.IsAbs(r.tokenFile) {
					r.tokenFile = filepath.Join(filepath.Dir(path), r.tokenFile)
				}
			default:
				return nil, fmt.Errorf("kubeconfig %s: user %q uses %s; only token and tokenFile are supported", path, userName, k)
			}
		}
	}
	tr, err := transport(pem, insecure)
	if err != nil {
		return nil, err
	}
	r.client = &http.Client{Transport: tr, Timeout: 5 * time.Second}
	return r, nil
}

func transport(pem []byte, insecure bool) (*http.Transport, error) {
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.Proxy = nil // the API server is never reached through a proxy
	cfg := &tls.Config{MinVersion: tls.VersionTLS12, InsecureSkipVerify: insecure}
	if len(pem) > 0 {
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(pem) {
			return nil, errors.New("the API server's CA holds no PEM certificate")
		}
		cfg.RootCAs = pool
	}
	tr.TLSClientConfig = cfg
	return tr, nil
}

// Review asks whether token authenticates for audiences.
func (r *Reviewer) Review(ctx context.Context, token string, audiences []string) (Result, error) {
	body, _ := json.Marshal(map[string]any{
		"apiVersion": "authentication.k8s.io/v1", "kind": "TokenReview",
		"spec": map[string]any{"token": token, "audiences": audiences},
	})
	req, err := http.NewRequestWithContext(ctx, "POST", r.server+"/apis/authentication.k8s.io/v1/tokenreviews", bytes.NewReader(body))
	if err != nil {
		return Result{}, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	bearer := r.token
	if r.tokenFile != "" {
		raw, err := os.ReadFile(r.tokenFile)
		if err != nil {
			return Result{}, fmt.Errorf("reading the API token: %w", err)
		}
		bearer = strings.TrimSpace(string(raw))
	}
	if bearer != "" {
		req.Header.Set("Authorization", "Bearer "+bearer)
	}
	resp, err := r.client.Do(req)
	if err != nil {
		return Result{}, err
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusCreated {
		return Result{}, fmt.Errorf("TokenReview: HTTP %d", resp.StatusCode)
	}
	var out struct {
		Status struct {
			Authenticated bool     `json:"authenticated"`
			Audiences     []string `json:"audiences"`
			Error         string   `json:"error"`
			User          struct {
				Username string              `json:"username"`
				Extra    map[string][]string `json:"extra"`
			} `json:"user"`
		} `json:"status"`
	}
	if err := json.Unmarshal(data, &out); err != nil {
		return Result{}, fmt.Errorf("TokenReview: %w", err)
	}
	st := out.Status
	res := Result{Authenticated: st.Authenticated, Username: st.User.Username, Audiences: st.Audiences, Error: st.Error}
	if p := st.User.Extra["authentication.kubernetes.io/pod-name"]; len(p) == 1 {
		res.Pod = p[0]
	}
	return res, nil
}

// ServiceAccount splits a service account's user name,
// system:serviceaccount:<namespace>:<name>, into namespace/name.
func ServiceAccount(username string) (string, bool) {
	rest, ok := strings.CutPrefix(username, "system:serviceaccount:")
	if !ok {
		return "", false
	}
	ns, name, ok := strings.Cut(rest, ":")
	if !ok || ns == "" || name == "" || strings.Contains(name, ":") {
		return "", false
	}
	return ns + "/" + name, true
}
