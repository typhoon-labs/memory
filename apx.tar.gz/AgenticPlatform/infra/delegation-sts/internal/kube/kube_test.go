package kube

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func api(t *testing.T, status int, seen *[]string) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Kind string `json:"kind"`
			Spec struct {
				Token     string   `json:"token"`
				Audiences []string `json:"audiences"`
			} `json:"spec"`
		}
		json.NewDecoder(r.Body).Decode(&req)
		*seen = append(*seen, r.URL.Path+" "+r.Header.Get("Authorization")+" "+req.Kind+" "+strings.Join(req.Spec.Audiences, ","))
		w.WriteHeader(status)
		json.NewEncoder(w).Encode(map[string]any{"status": map[string]any{
			"authenticated": req.Spec.Token == "good", "audiences": req.Spec.Audiences,
			"user": map[string]any{"username": "system:serviceaccount:sts-interop:interop-a",
				"extra": map[string]any{"authentication.kubernetes.io/pod-name": []string{"interop-a-1"}}},
		}})
	}))
	t.Cleanup(srv.Close)
	return srv
}

func writeKubeconfig(t *testing.T, server, user string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "kubeconfig")
	os.WriteFile(p, []byte(`apiVersion: v1
kind: Config
clusters:
- name: c
  cluster:
    server: `+server+`
users:
- name: u
  user:
`+user+`
contexts:
- name: ctx
  context: {cluster: c, user: u}
current-context: ctx
`), 0o600)
	return p
}

func TestReview(t *testing.T) {
	var seen []string
	srv := api(t, http.StatusCreated, &seen)
	dir := t.TempDir()
	tokenPath := filepath.Join(dir, "token")
	os.WriteFile(tokenPath, []byte("first\n"), 0o600)
	r, err := New(writeKubeconfig(t, srv.URL, "    tokenFile: "+tokenPath))
	if err != nil {
		t.Fatal(err)
	}
	res, err := r.Review(context.Background(), "good", []string{"https://sts"})
	if err != nil || !res.Authenticated || res.Username != "system:serviceaccount:sts-interop:interop-a" || res.Pod != "interop-a-1" || res.Audiences[0] != "https://sts" {
		t.Fatalf("Review = %+v, %v", res, err)
	}
	os.WriteFile(tokenPath, []byte("second\n"), 0o600)
	if res, _ := r.Review(context.Background(), "bad", []string{"https://sts"}); res.Authenticated {
		t.Error("a bad token authenticated")
	}
	if seen[0] != "/apis/authentication.k8s.io/v1/tokenreviews Bearer first TokenReview https://sts" || !strings.Contains(seen[1], "Bearer second") {
		t.Errorf("requests %q: the token file must be re-read on every call", seen)
	}

	r2, err := New(writeKubeconfig(t, srv.URL, "    token: static"))
	if err != nil {
		t.Fatal(err)
	}
	r2.Review(context.Background(), "good", nil)
	if !strings.Contains(seen[2], "Bearer static") {
		t.Errorf("static token not sent: %q", seen[2])
	}
}

func TestReviewFailures(t *testing.T) {
	var seen []string
	down := api(t, http.StatusServiceUnavailable, &seen)
	r, err := New(writeKubeconfig(t, down.URL, "    token: x"))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := r.Review(context.Background(), "good", nil); err == nil {
		t.Error("a 503 from the API server is not an error")
	}
	if _, err := New(writeKubeconfig(t, down.URL, "    client-certificate: /c.crt")); err == nil || !strings.Contains(err.Error(), "client-certificate") {
		t.Errorf("client certificates: %v", err)
	}
	t.Setenv("KUBERNETES_SERVICE_HOST", "")
	if _, err := New(""); err == nil {
		t.Error("in-cluster outside a cluster succeeded")
	}
}

func TestServiceAccount(t *testing.T) {
	if sa, ok := ServiceAccount("system:serviceaccount:ns:name"); !ok || sa != "ns/name" {
		t.Errorf("%s %v", sa, ok)
	}
	for _, bad := range []string{"system:serviceaccount:ns", "system:serviceaccount::n", "user:x", "system:serviceaccount:a:b:c"} {
		if _, ok := ServiceAccount(bad); ok {
			t.Errorf("%s accepted", bad)
		}
	}
}
