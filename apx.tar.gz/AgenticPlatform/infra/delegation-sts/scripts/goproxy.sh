#!/bin/sh
# Writes .goproxy/, a Go module proxy directory (GOPROXY=file://) holding
# the modules go.mod needs, for the images' builds: the Dockerfiles copy
# it into their build stage and download from it, since CI's rootless
# BuildKit gives RUN steps no network. go.sum checks every module there.
# Run from anywhere; it needs network, through GOPROXY as go env names it.
set -eu
cd "$(dirname "$0")/.."
cache="$(mktemp -d)"
trap 'rm -rf "$cache"' EXIT
GOFLAGS=-modcacherw GOMODCACHE="$cache" go mod download
rm -rf .goproxy
cp -R "$cache/cache/download" .goproxy
echo ".goproxy: $(find .goproxy -name '*.zip' | wc -l) modules"
