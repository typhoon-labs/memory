# aws-foundation

The agentic platform's AWS foundation in OpenTofu: modules, one stack per environment, and the registrations, the GitLab project IDs that CI trust policies admit. Its pipeline runs with its own AWS role, so nothing in `environments` can change IAM ([Repositories](../../architecture/design/repositories.md#gitlab-groups), decisions [Q14](../../architecture/decisions/Q14-repository-structure.md) and [Q15](../../architecture/decisions/Q15-opentofu.md)).

| Path | Holds |
| --- | --- |
| `modules/iam` | GitLab's OIDC provider, the CI roles `ci-aws-foundation`, `ci-environments` and `ci-ci-components`, B5's `ci-workload-charts`, `ci-agentctl` and `ci-workload-release`, B6's `ci-conformance`, `ci-library-release`, `ci-catalog`, `ci-environments-deploy` and `ci-delegation-sts`, and the workload roles `platform-delegation-sts` and `platform-external-secrets`, `platform-gateway` where a stack sets `gateway_bedrock`, B3's `platform-langfuse`, `platform-cnpg-backups` and `platform-telemetry-audit` and B4's `platform-kagent-snapshots` where it sets `data_buckets` |
| `modules/ecr` | ECR repositories with immutable tags, or mutable where a stack says so, and for scratch repositories a lifecycle policy that expires every image some days after its push |
| `modules/kms` | Asymmetric signing keys behind one alias and its `-next` and `-previous` twins, so each rotation step is a change of values |
| `modules/bucket` | An S3 bucket with a symmetric KMS key of its own behind `alias/platform/s3-<purpose>`, default SSE-KMS with it, public access blocked, and the versioning, lifecycle and Object Lock its purpose needs |
| `modules/rds` | A PostgreSQL instance whose master password RDS keeps in its own secret, and an entry with its endpoint and user name |
| `modules/scp` | The service control policy that keeps Bedrock model invocation to the gateway's role, attached to the targets given; no stack calls it yet ([D3](../../architecture/plan/open-items.md#close-by-decision)) |
| `modules/parameters` | SSM parameters under one path: the outputs `environments` reads at deploy time |
| `stacks/local` | The local build's stack, applied to floci; `ci.env` tells the pipeline which role to assume |
| `stacks/okta-local` | The Okta app of the local build, in the Integrator org: applied from a workstation only, never by CI ([D2](../../architecture/plan/open-items.md#close-by-decision)); the identity team owns it |
| `stacks/dev` | Lands at the swap to dev ([its README](stacks/dev/README.md)) |
| `registrations/` | The project IDs each CI role trusts, one file per stack |
| `checks/` | `okta-base-tier.sh`, which refuses custom authorization servers in the Okta configuration ([Q1](../../architecture/decisions/Q01-okta-base-tier.md)); CI runs it |
| `.gitlab-ci.yml` | Plan on merge requests; apply on protected `main`, then a plan that must be clean |

Each AWS resource arrives in the build phase that first needs it ([local build plan](../../architecture/plan/local-build.md#b0-in-detail)). B0's stack holds the OIDC provider, the two CI roles and the `platform/pull-check` repository for the exit check's image. B1 adds, for Keycloak and the delegation STS ([B1 in detail](../../architecture/plan/local-build.md#b1-in-detail)):

| Resource | Name | Notes |
| --- | --- | --- |
| STS signing key | `alias/platform/sts-signing` | `ECC_NIST_P256`, `SIGN_VERIFY`; keys are labelled by the month they were made |
| Keycloak's database | DB instance `keycloak`, PostgreSQL 18 | RDS keeps the master password in an `rds!db-…` secret of its own, so it is never in OpenTofu's state |
| Its connection entry | `platform/keycloak/db` | Engine, host, port, database and user name; no password |
| ECR repositories | `platform/delegation-sts`, `platform/okta-reconciler` | The images `infra/delegation-sts` builds: the STS's and its interop suite's, beside the chart, and the reconciliation job's. From B6 its pipeline pushes them, as `ci-delegation-sts` |
| Workload roles | `platform-delegation-sts`, `platform-external-secrets` | The STS signs only with the keys behind `sts-signing` and `sts-signing-previous`; External Secrets Operator reads only the plan's four entries and the RDS-managed secret |
| SSM parameters | `/platform/keycloak/db-password-secret-arn`, `/platform/delegation-sts/role-arn`, `/platform/external-secrets/role-arn` | What `environments` cannot derive |

The other three entries of the plan's Names table are not in this stack: `platform/keycloak/okta-broker` comes from the `okta-local` stack, and `platform/keycloak/bootstrap-admin` and `platform/delegation-sts/okta-reconciler-key` are created from a workstation with the AWS CLI, so secrets that no system generates never enter OpenTofu's state.

B2 adds, for the gateway and the platform-controls suites ([B2 in detail](../../architecture/plan/local-build.md#b2-in-detail)):

| Resource | Name | Notes |
| --- | --- | --- |
| ECR repositories | `platform/fake-model`, `platform/conformance-fixtures`, `platform/conformance-runner` | The images `devkit/ci-components` builds: the fake model server, the suites' fixtures (one image for `capture-mcp`, `relay-agent` and `outsider-agent`) and the conformance runner |
| CI role | `ci-ci-components` | Trusts `devkit/ci-components` (project 88996242) under the same conditions as the other CI roles, and may push to and pull from the three repositories above and nothing else |
| External Secrets Operator's reads | `platform/ratelimit/valkey`, `platform/conformance/personas` | Created from a workstation by `environments`' bootstrap, never by this stack |

The gateway's role, `platform-gateway`, and the SCP in `modules/scp` are written here but applied by no stack: `stacks/local` leaves `gateway_bedrock` unset, since its model provider is the fake model server, and locally only the `floci-iam` rehearsal applies both, to a member account of an organization it creates and removes.

B3 adds, for telemetry and data ([B3 in detail](../../architecture/plan/local-build.md#b3-in-detail)):

| Resource | Name | Notes |
| --- | --- | --- |
| Buckets, each with its own key | `agentic-cnpg-backups-local` (`alias/platform/s3-cnpg-backups`) | Versioned; noncurrent versions expire after 7 days, incomplete multipart uploads are aborted after a day. No Object Lock: the Barman Cloud plugin's retention deletes obsolete backups |
| | `agentic-langfuse-events-local` (`alias/platform/s3-langfuse-events`), `agentic-langfuse-media-local` (`alias/platform/s3-langfuse-media`) | Unversioned, since Langfuse would leave delete markers; objects expire after a day, the smallest unit of a lifecycle rule (30 days in dev, 90 in prod) |
| | `agentic-audit-local` (`alias/platform/s3-audit`) | Object Lock in COMPLIANCE mode, default retention a day (the security policy's period in dev); versioned, as Object Lock requires; noncurrent versions expire after the same day |
| Workload roles | `platform-langfuse`, `platform-cnpg-backups`, `platform-telemetry-audit` | Langfuse reads, writes and deletes objects in its two buckets; the plugin writes, prunes and reads backups, and the restore drill reads them with it; the collector's audit exporter may only put objects in `audit`. Each also uses its bucket's key: the audit role only generates data keys. Locally every pod reaches floci with the static credentials, so the roles are first proven in dev |
| External Secrets Operator's reads | `platform/langfuse/app`, `platform/langfuse/clickhouse`, `platform/langfuse/valkey`, `platform/langfuse/sso`, `platform/langfuse/projects`, `platform/langfuse/restore-drill`, `platform/usage/clickhouse` | Created from a workstation by `environments`' bootstrap, never by this stack |
| SSM parameters | `/platform/langfuse/role-arn`, `/platform/cnpg-backups/role-arn`, `/platform/telemetry-audit/role-arn`, `/platform/buckets/<purpose>` | What `environments` cannot derive: the roles' ARNs and the buckets' names |

B4 adds, for kagent and Agent Substrate ([B4 in detail](../../architecture/plan/local-build.md#b4-in-detail)):

| Resource | Name | Notes |
| --- | --- | --- |
| Buckets, each with its own key | `agentic-kagent-snapshots-local` (`alias/platform/s3-kagent-snapshots`) | kagent's session snapshots, which Substrate writes on suspend. Unversioned; no expiry of current objects, since Substrate deletes the snapshots it releases and golden snapshots live as long as their template; incomplete multipart uploads are aborted after a day |
| | `agentic-sandbox-assets-local` (`alias/platform/s3-sandbox-assets`) | gVisor's release tarballs, which the `environments` bootstrap mirrors from the public bucket once and atelet reads by `s3://` URL and SHA-256. Nothing expires: an old release stays while snapshots taken on it remain; incomplete uploads are aborted after a day |
| Workload role | `platform-kagent-snapshots` | Substrate's object-store plugins write, read and delete objects in the snapshot bucket and only read the asset bucket, with each bucket's key. Locally every pod reaches floci with the static credentials, so the role is first proven in dev |
| External Secrets Operator's reads | `platform/kagent/db`, `platform/kagent/oauth2-proxy` | The four logins of kagent's database, and `oauth2-proxy`'s client and cookie secrets for kagent's UI; generated by `environments`' bootstrap where missing, never by this stack |
| SSM parameters | `/platform/kagent-snapshots/role-arn`, `/platform/buckets/kagent-snapshots`, `/platform/buckets/sandbox-assets` | What `environments` cannot derive |

B5 adds, for the devkit's releases ([B5 in detail](../../architecture/plan/local-build.md#b5-in-detail)):

| Resource | Name | Notes |
| --- | --- | --- |
| Release key | `alias/platform/release-signing` | `ECC_NIST_P256`, `SIGN_VERIFY`, so cosign's KMS signer has one algorithm, `ECDSA_SHA_256`; keys are labelled by the month they were made, as the STS's are |
| Bucket, with its own key | `agentic-artifacts-local` (`alias/platform/s3-artifacts`) | Bounded model steps' outputs. Unversioned; no retention is decided yet, so only incomplete multipart uploads are aborted, after a day. No role writes it yet |
| ECR repositories | `platform/app-base`, `platform/agent-integration` | The charts `devkit/workload-charts` releases, by version. A reference workload's repository comes with its registration (D4) |
| CI roles | `ci-workload-charts` | Trusts `devkit/workload-charts` (project 89082546); pushes to and pulls from the two chart repositories, and signs with the release key |
| | `ci-agentctl` | Trusts `devkit/agentctl` (project 89082550); signs with the release key, since its binaries go to the project's own package registry |
| | `ci-workload-release` | Trusts every project registered for it, from protected tags alone (`ref_type` `tag`); pushes to the registered workloads' repositories and signs with the release key. None is registered yet, so its trust policy is a single `Deny` and nobody may assume it; each workload's registration adds its project ID and its repository (D4). One role serves every workload, so it cannot hold a project to its own repository |
| SSM parameter | `/platform/buckets/artifacts` | |
| Scratch repositories, local only | `ci-scratch/devkit-ci-components` | One per project whose merge request pipelines run the contract stage, `ci-scratch/<path under the group root, slashes as hyphens>`, each added with its project (a workload's with its registration, D4). Mutable; every image expires a day after its push, a lifecycle policy floci 2.4.0 stores and never applies. The stage copies the merge request's image there and starts it from floci, since the sandbox's Docker daemon cannot pull from GitLab's registry through the sandbox's proxy. In dev the stage starts it from GitLab's registry and no merge request pipeline writes to ECR |

**Locally every repository's tags are mutable** (`image_tag_mutability = "MUTABLE"` in `stacks/local`), a departure from the design's immutable tags: floci's registry has no OCI referrers API, so cosign keeps a digest's signature and attestations in a fallback index tagged `sha256-<hex>`, which it rewrites on each sign and attest, and an immutable repository refuses every write after the first (B5's spike). Deploys pin digests, so a moved tag never changes what runs. Dev keeps the default, `IMMUTABLE`.

Each role that signs may only describe the keys behind `release-signing` and `release-signing-previous`, read their public keys, and call `Sign` with `MessageType` `DIGEST` and `ECDSA_SHA_256`, as cosign's KMS signer does. `devkit/workload-templates` (89082549) has no role: nothing in it calls AWS. floci evaluates neither the trust conditions nor the policies, so the roles are first proven in dev.

`ci-aws-foundation` may change the settings of those nine buckets, by name, and never their objects. floci stores a bucket's default KMS key without applying it ([B3 desk check](../../architecture/research/2026-11-17-b3-desk-check.md#floci-240s-s3)), so locally the keys are checked as configuration, in the plan, and dev checks them on the objects. In dev, apply the CI role's new rights before the buckets, as `modules/iam/policies.tf` says.

B6 adds, for distribution ([B6 in detail](../../architecture/plan/local-build.md#b6-in-detail)):

| Resource | Name | Notes |
| --- | --- | --- |
| Platform image key | `alias/platform/platform-signing` | `ECC_NIST_P256`, `SIGN_VERIFY`. Signs the platform's own images (the fake model, the suites' runner and fixtures, the STS's); only `ci-ci-components` and `ci-delegation-sts` may use it, each for the images its own pipeline builds, never a workload's role, and admission verifies the platform namespaces' images with it |
| Conformance key | `alias/platform/conformance-signing` | `ECC_NIST_P256`, `SIGN_VERIFY`, as the release key. `infra/conformance` alone signs conformance attestations with it, so an attestation always means the suites ran (TM13) |
| Record key | `alias/platform/record-signing` | `ECC_NIST_P256`, `SIGN_VERIFY`. Signs the catalog index and the release records; only the catalog pipeline's role and `environments`' deploy job may use it, never a workload's release role (D37) |
| Buckets, each with its own key | `agentic-release-records-local` (`alias/platform/s3-release-records`) | One release record per workload release `environments`' deploy job applies, signed with the record key. Versioned, under Object Lock in COMPLIANCE mode for a day locally, as the audit archive; noncurrent versions expire after a day |
| | `agentic-catalog-index-local` (`alias/platform/s3-catalog-index`) | The signed catalog index (`catalog.json`, its bundle and static pages), written by the catalog's scheduled pipeline. Versioned, under Object Lock in COMPLIANCE mode for a day locally; a replaced version expires a day after |
| SSM parameters | `/platform/buckets/release-records`, `/platform/buckets/catalog-index` | |
| ECR repository | `platform/step` | The bounded step's image (D27), which a workflow's step job runs, built and pushed by `ci-ci-components` from its main, signed with the platform image key |
| ECR repository | `platform/conformance-admission-fixtures` | `ci-components`' long-lived admission fixtures, one image in each state the admission rule's bypass cases need, pushed by `ci-ci-components` from its main. No lifecycle policy, so the lifecycle applier never touches it |
| ECR repositories | `library/skill/platform-conventions`, `library/prompt/summarise-changes` | The global library's first artifacts, one repository per artifact, `library/<kind>/<name>`, each added with its artifact (D41). Mutable locally, as every repository here |
| CI roles | `ci-conformance` | Trusts the project registered for it, `infra/conformance`, at most one, on its protected `main` alone (`ref_type` `branch`, `ref` `main`); pulls the registered workloads' images and the two chart repositories, pushes to the workloads' repositories only for cosign's attestation, and signs with the conformance key alone. Registered: `infra/conformance` (project 89131951) |
| | `ci-conformance`, its contract stage | Lists the repositories' names and the workloads' and incubator's images, to find a digest's repository, and pushes to and deletes from its own scratch repository, `ci-scratch/infra-conformance` |
| | `ci-library-release` | Trusts every library project registered for it, from protected tags alone; pushes to the `library/*` repositories and signs with the release key. Registered: `agent-library` (project 89131952) |
| | `ci-catalog` | Trusts `infra/environments` (project 88996235) on `main`, in scheduled pipelines alone (`pipeline_source` `schedule`); signs with the record key and puts objects in the index bucket, and reads, lists and deletes nothing there; reads the registered workloads' and the library's images and tags in ECR, as dev's catalog will |
| | `ci-environments-deploy` | The deploy job's own role: trusts `infra/environments` (project 88996235) on `main` in a job that declares the environment `local` (the ID token's `environment` claim, which GitLab sets on Free when a job specifies an environment; protected environments are Premium); signs with the record key and puts objects in the records bucket, for the release records, and reads, lists and deletes nothing there; it also has `ci-environments`' reads (ECR pull, the SSM parameters), since the deploy job and its record jobs run as this role alone. With `ci-catalog`, the only role that may use the record key (D37); `ci-environments`, which any protected job of the project may assume, may not |
| | `ci-delegation-sts` | Trusts the project registered for it, `infra/delegation-sts`, at most one, on its protected `main` alone (`ref_type` `branch`, `ref` `main`); pushes to and pulls from `platform/delegation-sts` and `platform/okta-reconciler` and nothing else, and signs and attests what it pushed with the platform image key (D36). Its key statements grant `DescribeKey` and `GetPublicKey` beside `Sign`, since cosign's KMS signer reads the key's metadata before it signs, as every signing role's do. Registered: `infra/delegation-sts` (project 88999944) |

The stack's outputs are `ci_role_arns`, `workload_role_arns`, `gitlab_oidc_provider_arn`, `ecr_repositories`, `sts_signing`, `release_signing`, `platform_signing`, `conformance_signing`, `record_signing`, `keycloak_db`, `buckets` and `ssm_parameters`.

## Applying

The `environments` bootstrap creates the state bucket and applies `stacks/local` once from the workstation; from then on this repository's pipeline applies it. To look at the local stack by hand, with floci running:

```sh
export AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test   # floci's static credentials
tofu -chdir=stacks/local init
tofu -chdir=stacks/local plan
```

### The Okta app

`stacks/okta-local` is applied from a workstation with the Integrator org's API token in `OKTA_API_TOKEN`, and floci running ([B1 in detail](../../architecture/plan/local-build.md#b1-in-detail), step 2). Its state is in the same bucket as `stacks/local`, under `aws-foundation/okta-local.tfstate`. It holds the broker app's client secret, as the Okta provider keeps it there; no other secret enters it. Run from the repository root, in this order:

```sh
export AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test   # floci's static credentials
stacks/okta-local/reconciler-key.sh       # the reconciler's key pair, where missing
tofu -chdir=stacks/okta-local init
tofu -chdir=stacks/okta-local apply
stacks/okta-local/personas.sh             # activates the personas; passwords outside Git
stacks/okta-local/personas-totp.sh        # enrolls each persona's TOTP factor
```

- `reconciler-key.sh` stores the `okta-reconciler` app's private key in `platform/delegation-sts/okta-reconciler-key` and writes its public key to `stacks/okta-local/keys/`, which Git keeps. After floci's volume is lost it makes a new pair: commit the new public key and apply.
- The apply writes the broker app's client ID and secret to `platform/keycloak/okta-broker`.
- `personas.sh` sets each staged persona's password and activates it without email. The passwords go to `~/.local/share/agentic-platform/okta/personas.json`, mode 600. The stack ignores the personas' status, which the leaver and kill-switch checks change by hand.
- The platform's groups sign in to the broker with a password and TOTP (`mfa.tf`): their own enrollment policy, and a sign-on policy for `agentic-keycloak` whose other users are refused. `personas-totp.sh` enrolls each active persona's TOTP factor through Okta's API and keeps its secret in the same file, beside the password, so scripts can sign the personas in.

The checks to run before committing are in [AGENTS.md](AGENTS.md#before-committing).
