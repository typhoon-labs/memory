# Stack outputs that environments reads at deploy time, as SSM parameters
# under one path (design/repositories.md: "OpenTofu outputs as SSM
# parameters, read by environments"). Only values environments cannot
# derive belong here; none is secret.

resource "aws_ssm_parameter" "this" {
  for_each = var.parameters

  name  = "${var.path}${each.key}"
  type  = "String"
  value = each.value
}
