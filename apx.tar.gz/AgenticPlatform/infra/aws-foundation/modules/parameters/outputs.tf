output "names" {
  description = "Full name of each parameter, keyed by its name under path."
  value       = { for name, parameter in aws_ssm_parameter.this : name => parameter.name }
}
