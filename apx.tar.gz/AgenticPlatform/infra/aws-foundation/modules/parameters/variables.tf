variable "path" {
  description = "Path of the parameters, with leading and trailing slashes, such as /platform/. ci-environments may read it."
  type        = string

  validation {
    condition     = can(regex("^/([A-Za-z0-9_.-]+/)+$", var.path))
    error_message = "path must start and end with a slash, such as /platform/."
  }
}

variable "parameters" {
  description = "Value of each parameter, keyed by its name under path, such as keycloak/db-password-secret-arn."
  type        = map(string)

  validation {
    condition     = alltrue([for name in keys(var.parameters) : can(regex("^[A-Za-z0-9_.-]+(/[A-Za-z0-9_.-]+)*$", name))])
    error_message = "Each name is one or more segments of letters, digits, _, . and -, separated by slashes, without a leading or trailing slash."
  }
}
