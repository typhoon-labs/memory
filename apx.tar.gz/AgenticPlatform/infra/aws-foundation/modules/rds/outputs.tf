output "arn" {
  description = "ARN of the DB instance."
  value       = aws_db_instance.this.arn
}

output "address" {
  description = "Host name of the instance's endpoint."
  value       = aws_db_instance.this.address
}

output "port" {
  description = "Port of the instance's endpoint."
  value       = aws_db_instance.this.port
}

output "connection_secret_arn" {
  description = "ARN of the entry with the endpoint and user name."
  value       = aws_secretsmanager_secret.connection.arn
}

output "master_user_secret_arn" {
  description = "ARN of the secret RDS manages for the master user. Read only its username and password keys: floci adds others that AWS may not."
  value       = aws_db_instance.this.master_user_secret[0].secret_arn
}
