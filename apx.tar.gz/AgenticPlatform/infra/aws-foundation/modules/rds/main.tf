# A PostgreSQL instance for one platform service, and a Secrets Manager
# entry that tells the service where it is. RDS keeps the master password
# in a secret of its own (manage_master_user_password), so the password is
# never in OpenTofu's state or plan. The connection entry holds only what
# is not secret: engine, host, port, database and user name.
#
# The same resource serves floci and AWS; Multi-AZ, the subnet group and
# security groups are values that only dev sets.

resource "aws_db_instance" "this" {
  identifier     = var.identifier
  engine         = "postgres"
  engine_version = var.engine_version
  instance_class = var.instance_class

  allocated_storage     = var.allocated_storage
  max_allocated_storage = var.max_allocated_storage
  storage_type          = "gp3"
  storage_encrypted     = true

  db_name                     = var.db_name
  username                    = var.username
  manage_master_user_password = true

  multi_az               = var.multi_az
  db_subnet_group_name   = var.db_subnet_group_name
  vpc_security_group_ids = var.vpc_security_group_ids
  publicly_accessible    = false

  auto_minor_version_upgrade = true
  backup_retention_period    = var.backup_retention_period
  copy_tags_to_snapshot      = true
  deletion_protection        = var.deletion_protection
  skip_final_snapshot        = var.skip_final_snapshot
  final_snapshot_identifier  = var.skip_final_snapshot ? null : "${var.identifier}-final"
}

resource "aws_secretsmanager_secret" "connection" {
  name        = var.connection_secret_name
  description = "Where ${var.identifier}'s database is: engine, host, port, dbname and username. The password is in the RDS-managed secret."
}

resource "aws_secretsmanager_secret_version" "connection" {
  secret_id = aws_secretsmanager_secret.connection.id
  secret_string = jsonencode({
    engine   = aws_db_instance.this.engine
    host     = aws_db_instance.this.address
    port     = aws_db_instance.this.port
    dbname   = aws_db_instance.this.db_name
    username = aws_db_instance.this.username
  })
}
