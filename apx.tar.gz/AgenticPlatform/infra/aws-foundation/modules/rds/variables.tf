variable "identifier" {
  description = "The DB instance identifier, such as keycloak."
  type        = string
}

variable "engine_version" {
  description = "PostgreSQL major version, such as 18. A major version alone lets RDS apply minor versions; floci runs postgres:<version>-alpine."
  type        = string
}

variable "instance_class" {
  description = "The DB instance class, such as db.t4g.micro."
  type        = string
}

variable "allocated_storage" {
  description = "Storage at create, in GiB."
  type        = number
  default     = 20
}

variable "max_allocated_storage" {
  description = "Upper bound for storage autoscaling, in GiB, or null for none."
  type        = number
  default     = null
}

variable "db_name" {
  description = "The database created with the instance."
  type        = string
}

variable "username" {
  description = "The master user's name. RDS generates its password and keeps it in a secret of its own."
  type        = string
}

variable "multi_az" {
  description = "A standby in a second availability zone (dev and later; floci has none)."
  type        = bool
  default     = false
}

variable "db_subnet_group_name" {
  description = "The DB subnet group, or null for the account's default (floci)."
  type        = string
  default     = null
}

variable "vpc_security_group_ids" {
  description = "Security groups of the instance, or null for the VPC's default (floci)."
  type        = set(string)
  default     = null
}

variable "backup_retention_period" {
  description = "Days of automated backups."
  type        = number
  default     = 7
}

variable "deletion_protection" {
  description = "Refuse deletion of the instance."
  type        = bool
  default     = true
}

variable "skip_final_snapshot" {
  description = "Delete without a final snapshot. When false, the final snapshot is <identifier>-final."
  type        = bool
  default     = false
}

variable "connection_secret_name" {
  description = "Name of the Secrets Manager entry that holds the instance's endpoint and user name, such as platform/keycloak/db."
  type        = string
}
