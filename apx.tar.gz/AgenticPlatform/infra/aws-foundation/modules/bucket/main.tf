# One bucket for one purpose, with a KMS key of its own behind
# alias/platform/s3-<purpose> (plan/local-build.md, "B0 in detail", Names,
# and "B3 in detail", Buckets): default SSE-KMS with that key, public
# access blocked, and the lifecycle and Object Lock the purpose needs. What
# differs between environments, the retention periods, is a variable.
#
# No key policy is set, so the key has KMS's default policy: the account
# administers it, and IAM policies grant its use to the bucket's writers
# and readers (modules/iam). No bucket policy either: the roles' own
# policies name the bucket.

resource "aws_kms_key" "this" {
  description              = "Default encryption of the bucket ${var.name}: ${var.description}"
  customer_master_key_spec = "SYMMETRIC_DEFAULT"
  key_usage                = "ENCRYPT_DECRYPT"
  enable_key_rotation      = true
  deletion_window_in_days  = var.kms_deletion_window_in_days
}

resource "aws_kms_alias" "this" {
  name          = var.kms_alias
  target_key_id = aws_kms_key.this.key_id
}

# Object Lock can only be turned on when a bucket is created, and needs
# versioning.
resource "aws_s3_bucket" "this" {
  bucket              = var.name
  object_lock_enabled = var.object_lock != null
}

resource "aws_s3_bucket_public_access_block" "this" {
  bucket = aws_s3_bucket.this.id

  block_public_acls       = true
  ignore_public_acls      = true
  block_public_policy     = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "this" {
  bucket = aws_s3_bucket.this.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.this.arn
    }
    # One data key per bucket rather than per object: fewer KMS calls.
    bucket_key_enabled = true
  }
}

# Unversioned buckets get no versioning resource: a bucket starts
# unversioned, and a suspended one would still keep its old versions.
resource "aws_s3_bucket_versioning" "this" {
  count = var.versioning ? 1 : 0

  bucket = aws_s3_bucket.this.id

  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_object_lock_configuration" "this" {
  count = var.object_lock == null ? 0 : 1

  bucket = aws_s3_bucket.this.id

  rule {
    default_retention {
      mode  = var.object_lock.mode
      days  = var.object_lock.days
      years = var.object_lock.years
    }
  }

  depends_on = [aws_s3_bucket_versioning.this]
}

# One rule for the whole bucket. Its filter is an empty prefix: on S3 an
# AbortIncompleteMultipartUpload action needs a rule without tags, and
# floci applies it only under a plain prefix.
resource "aws_s3_bucket_lifecycle_configuration" "this" {
  count = (
    var.lifecycle_rules.expiration_days == null &&
    var.lifecycle_rules.noncurrent_expiration_days == null &&
    var.lifecycle_rules.abort_incomplete_multipart_days == null
  ) ? 0 : 1

  bucket = aws_s3_bucket.this.id

  rule {
    id     = "retention"
    status = "Enabled"

    filter {
      prefix = ""
    }

    dynamic "expiration" {
      for_each = var.lifecycle_rules.expiration_days == null ? [] : [var.lifecycle_rules.expiration_days]
      content {
        days = expiration.value
      }
    }

    dynamic "noncurrent_version_expiration" {
      for_each = var.lifecycle_rules.noncurrent_expiration_days == null ? [] : [var.lifecycle_rules.noncurrent_expiration_days]
      content {
        noncurrent_days = noncurrent_version_expiration.value
      }
    }

    dynamic "abort_incomplete_multipart_upload" {
      for_each = var.lifecycle_rules.abort_incomplete_multipart_days == null ? [] : [var.lifecycle_rules.abort_incomplete_multipart_days]
      content {
        days_after_initiation = abort_incomplete_multipart_upload.value
      }
    }
  }

  # A lifecycle rule on noncurrent versions needs versioning first.
  depends_on = [aws_s3_bucket_versioning.this]
}
