variable "name" {
  description = "The bucket's name, agentic-<purpose>-<environment> (plan/local-build.md, \"B0 in detail\", Names)."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$", var.name))
    error_message = "name must be 3 to 63 lowercase letters, digits and hyphens, starting and ending with a letter or digit."
  }
}

variable "description" {
  description = "What the bucket holds; the key's description names the bucket and adds this."
  type        = string
}

variable "kms_alias" {
  description = "The alias of the bucket's own key, alias/platform/s3-<purpose>: the same name in every environment."
  type        = string

  validation {
    condition     = can(regex("^alias/[A-Za-z0-9/_-]+$", var.kms_alias)) && !startswith(var.kms_alias, "alias/aws/")
    error_message = "kms_alias must start with alias/, hold only letters, digits, /, _ and -, and not be under alias/aws/."
  }
}

variable "versioning" {
  description = "Whether the bucket keeps object versions, which Object Lock and noncurrent_expiration_days need."
  type        = bool
  default     = false
}

variable "lifecycle_rules" {
  description = "The bucket's lifecycle, in days, each null for none: expiration_days expires current versions, noncurrent_expiration_days deletes versions that have been noncurrent that long, abort_incomplete_multipart_days aborts unfinished multipart uploads."
  type = object({
    expiration_days                 = optional(number)
    noncurrent_expiration_days      = optional(number)
    abort_incomplete_multipart_days = optional(number)
  })
  default = {}

  validation {
    condition = alltrue([
      for d in [
        var.lifecycle_rules.expiration_days,
        var.lifecycle_rules.noncurrent_expiration_days,
        var.lifecycle_rules.abort_incomplete_multipart_days,
      ] : d == null ? true : d >= 1 && floor(d) == d
    ])
    error_message = "Each lifecycle period must be null or a whole number of days, at least 1: a day is the smallest unit of an S3 lifecycle rule."
  }

  validation {
    condition     = var.lifecycle_rules.noncurrent_expiration_days == null || var.versioning
    error_message = "noncurrent_expiration_days needs versioning."
  }
}

variable "object_lock" {
  description = "The bucket's default Object Lock retention, or null for none: mode GOVERNANCE or COMPLIANCE, and days or years. Object Lock is set only when the bucket is created; changing this to or from null replaces the bucket."
  type = object({
    mode  = string
    days  = optional(number)
    years = optional(number)
  })
  default = null

  validation {
    condition     = var.object_lock == null || contains(["GOVERNANCE", "COMPLIANCE"], try(var.object_lock.mode, ""))
    error_message = "object_lock.mode must be GOVERNANCE or COMPLIANCE."
  }

  validation {
    condition     = var.object_lock == null || ((try(var.object_lock.days, null) == null) != (try(var.object_lock.years, null) == null))
    error_message = "object_lock needs exactly one of days and years."
  }

  validation {
    condition     = var.object_lock == null || var.versioning
    error_message = "Object Lock needs versioning: set versioning = true with it."
  }
}

variable "kms_deletion_window_in_days" {
  description = "Days between the key's removal and its deletion, during which the deletion can be cancelled."
  type        = number
  default     = 30
}
