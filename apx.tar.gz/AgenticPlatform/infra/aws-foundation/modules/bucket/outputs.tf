output "name" {
  description = "The bucket's name."
  value       = aws_s3_bucket.this.id
}

output "arn" {
  description = "The bucket's ARN."
  value       = aws_s3_bucket.this.arn
}

output "kms_key_arn" {
  description = "The ARN of the bucket's key."
  value       = aws_kms_key.this.arn
}

output "kms_alias" {
  description = "The alias of the bucket's key."
  value       = aws_kms_alias.this.name
}
