# What each CI role may do. Each statement names the actions the stack's
# resources need, on those resources only, except where AWS allows no
# narrower resource (ecr:GetAuthorizationToken, kms:CreateKey) or the role
# owns a resource type across the account (ECR repositories, KMS keys,
# whose IDs are unknown before they exist). Resources are named, never
# read from other modules' attributes, so the policy is known at plan time.
#
# floci evaluates none of this. In dev, an apply that adds a resource of a
# new kind may create it before this policy grows: grant the permission in
# an earlier apply.

locals {
  ssm_path = trimsuffix(var.ssm_parameter_path, "/")
}

data "aws_iam_policy_document" "ci_aws_foundation" {
  # State: this stack's key and its lock file, nothing else in the bucket.
  statement {
    sid       = "StateBucket"
    actions   = ["s3:ListBucket"]
    resources = ["arn:${local.partition}:s3:::${var.state.bucket}"]
  }

  statement {
    sid     = "StateObject"
    actions = ["s3:GetObject", "s3:PutObject"]
    resources = [
      "arn:${local.partition}:s3:::${var.state.bucket}/${var.state.key}",
    ]
  }

  statement {
    sid     = "StateLock"
    actions = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"]
    resources = [
      "arn:${local.partition}:s3:::${var.state.bucket}/${var.state.key}.tflock",
    ]
  }

  # The CI and workload roles this module defines, including this role
  # itself.
  statement {
    sid = "Roles"
    actions = [
      "iam:CreateRole",
      "iam:DeleteRole",
      "iam:GetRole",
      "iam:UpdateRole",
      "iam:UpdateRoleDescription",
      "iam:UpdateAssumeRolePolicy",
      "iam:TagRole",
      "iam:UntagRole",
      "iam:ListRoleTags",
      "iam:PutRolePolicy",
      "iam:GetRolePolicy",
      "iam:DeleteRolePolicy",
      "iam:ListRolePolicies",
      "iam:ListAttachedRolePolicies",
      "iam:ListInstanceProfilesForRole",
    ]
    resources = [
      for name in concat(keys(local.roles), keys(local.workload_roles)) :
      "arn:${local.partition}:iam::${local.account}:role/${name}"
    ]
  }

  statement {
    sid = "GitLabOidcProvider"
    actions = [
      "iam:CreateOpenIDConnectProvider",
      "iam:GetOpenIDConnectProvider",
      "iam:DeleteOpenIDConnectProvider",
      "iam:AddClientIDToOpenIDConnectProvider",
      "iam:RemoveClientIDFromOpenIDConnectProvider",
      "iam:UpdateOpenIDConnectProviderThumbprint",
      "iam:TagOpenIDConnectProvider",
      "iam:UntagOpenIDConnectProvider",
      "iam:ListOpenIDConnectProviderTags",
    ]
    resources = [
      "arn:${local.partition}:iam::${local.account}:oidc-provider/${local.issuer_host}",
    ]
  }

  # Repository settings only: no image push, pull or delete. A lifecycle
  # policy deletes images, but only those of the scratch repositories that
  # carry one.
  statement {
    sid = "EcrRepositories"
    actions = [
      "ecr:CreateRepository",
      "ecr:DeleteRepository",
      "ecr:DescribeRepositories",
      "ecr:PutImageTagMutability",
      "ecr:PutLifecyclePolicy",
      "ecr:GetLifecyclePolicy",
      "ecr:DeleteLifecyclePolicy",
      "ecr:TagResource",
      "ecr:UntagResource",
      "ecr:ListTagsForResource",
    ]
    resources = [
      "arn:${local.partition}:ecr:${local.region}:${local.account}:repository/*",
    ]
  }

  # KMS: CreateKey and ListAliases take no resource. A key's ID is unknown
  # before it exists, so the key actions name every key in the account;
  # aliases are limited to the stack's prefix. Moving an alias needs the
  # alias actions on both the alias and the keys. No key policy actions:
  # the keys keep KMS's default policy.
  statement {
    sid       = "KmsCreate"
    actions   = ["kms:CreateKey", "kms:ListAliases"]
    resources = ["*"]
  }

  statement {
    sid = "KmsKeys"
    actions = [
      "kms:DescribeKey",
      "kms:GetKeyPolicy",
      "kms:GetKeyRotationStatus",
      "kms:ListResourceTags",
      "kms:TagResource",
      "kms:UntagResource",
      "kms:UpdateKeyDescription",
      "kms:EnableKey",
      "kms:DisableKey",
      "kms:EnableKeyRotation",
      "kms:DisableKeyRotation",
      "kms:ScheduleKeyDeletion",
      "kms:CancelKeyDeletion",
      "kms:CreateAlias",
      "kms:UpdateAlias",
      "kms:DeleteAlias",
    ]
    resources = [
      "arn:${local.partition}:kms:${local.region}:${local.account}:key/*",
    ]
  }

  statement {
    sid     = "KmsAliases"
    actions = ["kms:CreateAlias", "kms:UpdateAlias", "kms:DeleteAlias"]
    resources = [
      "arn:${local.partition}:kms:${local.region}:${local.account}:${var.managed.kms_alias_prefix}*",
    ]
  }

  # The stack's buckets, by name: their settings only, never their
  # objects. The reads are those OpenTofu makes when it refreshes a
  # bucket; a delete fails while a bucket holds objects.
  dynamic "statement" {
    for_each = length(var.managed.buckets) > 0 ? [1] : []
    content {
      sid = "Buckets"
      actions = [
        "s3:CreateBucket",
        "s3:DeleteBucket",
        "s3:ListBucket",
        "s3:GetBucketLocation",
        "s3:GetBucketAcl",
        "s3:GetBucketCORS",
        "s3:GetBucketWebsite",
        "s3:GetBucketLogging",
        "s3:GetBucketRequestPayment",
        "s3:GetAccelerateConfiguration",
        "s3:GetReplicationConfiguration",
        "s3:GetBucketPolicy",
        "s3:GetBucketOwnershipControls",
        "s3:GetBucketTagging",
        "s3:PutBucketTagging",
        "s3:GetBucketVersioning",
        "s3:PutBucketVersioning",
        "s3:GetEncryptionConfiguration",
        "s3:PutEncryptionConfiguration",
        "s3:GetLifecycleConfiguration",
        "s3:PutLifecycleConfiguration",
        "s3:GetBucketObjectLockConfiguration",
        "s3:PutBucketObjectLockConfiguration",
        "s3:GetBucketPublicAccessBlock",
        "s3:PutBucketPublicAccessBlock",
      ]
      resources = [
        for name in var.managed.buckets : "arn:${local.partition}:s3:::${name}"
      ]
    }
  }

  statement {
    sid = "DbInstances"
    actions = [
      "rds:CreateDBInstance",
      "rds:DeleteDBInstance",
      "rds:ModifyDBInstance",
      "rds:RebootDBInstance",
      "rds:DescribeDBInstances",
      "rds:AddTagsToResource",
      "rds:RemoveTagsFromResource",
      "rds:ListTagsForResource",
    ]
    resources = [
      for id in var.managed.db_instances :
      "arn:${local.partition}:rds:${local.region}:${local.account}:db:${id}"
    ]
  }

  # Creating or changing an instance is authorized on the parameter, option
  # and subnet groups it uses too, which the stack references and never
  # changes.
  statement {
    sid     = "DbInstanceGroups"
    actions = ["rds:CreateDBInstance", "rds:ModifyDBInstance"]
    resources = [
      "arn:${local.partition}:rds:${local.region}:${local.account}:pg:*",
      "arn:${local.partition}:rds:${local.region}:${local.account}:og:*",
      "arn:${local.partition}:rds:${local.region}:${local.account}:subgrp:*",
    ]
  }

  # RDS's service-linked role, created with an account's first instance.
  statement {
    sid       = "RdsServiceLinkedRole"
    actions   = ["iam:CreateServiceLinkedRole"]
    resources = ["arn:${local.partition}:iam::${local.account}:role/aws-service-role/rds.amazonaws.com/AWSServiceRoleForRDS"]

    condition {
      test     = "StringEquals"
      variable = "iam:AWSServiceName"
      values   = ["rds.amazonaws.com"]
    }
  }

  # With manage_master_user_password, RDS creates the password's secret as
  # the caller (RDS User Guide, "Password management with Amazon RDS and
  # AWS Secrets Manager"). It also describes Secrets Manager's own KMS key,
  # which KmsKeys allows. This role never reads that secret.
  statement {
    sid       = "RdsManagedSecrets"
    actions   = ["secretsmanager:CreateSecret", "secretsmanager:TagResource"]
    resources = ["arn:${local.partition}:secretsmanager:${local.region}:${local.account}:secret:rds!*"]
  }

  # The entries the stack creates, by name: an entry's ARN ends in a hyphen
  # and six random characters.
  statement {
    sid = "Secrets"
    actions = [
      "secretsmanager:CreateSecret",
      "secretsmanager:DeleteSecret",
      "secretsmanager:DescribeSecret",
      "secretsmanager:GetResourcePolicy",
      "secretsmanager:GetSecretValue",
      "secretsmanager:PutSecretValue",
      "secretsmanager:UpdateSecret",
      "secretsmanager:UpdateSecretVersionStage",
      "secretsmanager:ListSecretVersionIds",
      "secretsmanager:TagResource",
      "secretsmanager:UntagResource",
    ]
    resources = [
      for name in var.managed.secrets :
      "arn:${local.partition}:secretsmanager:${local.region}:${local.account}:secret:${name}-??????"
    ]
  }

  # The parameters the stack publishes for environments. DescribeParameters
  # takes no resource.
  statement {
    sid = "SsmParameters"
    actions = [
      "ssm:PutParameter",
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:DeleteParameter",
      "ssm:AddTagsToResource",
      "ssm:RemoveTagsFromResource",
      "ssm:ListTagsForResource",
    ]
    resources = [
      "arn:${local.partition}:ssm:${local.region}:${local.account}:parameter${local.ssm_path}/*",
    ]
  }

  statement {
    sid       = "SsmDescribe"
    actions   = ["ssm:DescribeParameters"]
    resources = ["*"]
  }
}

data "aws_iam_policy_document" "ci_environments" {
  # GetAuthorizationToken has no resource-level permissions.
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPull"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
      "ecr:DescribeImages",
    ]
    resources = var.ecr_pull_repository_arns
  }

  # The parameters the foundation publishes for environments' deploys.
  statement {
    sid = "SsmRead"
    actions = [
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:GetParametersByPath",
    ]
    resources = [
      "arn:${local.partition}:ssm:${local.region}:${local.account}:parameter${local.ssm_path}",
      "arn:${local.partition}:ssm:${local.region}:${local.account}:parameter${local.ssm_path}/*",
    ]
  }
}

# devkit/ci-components pushes the images it builds (the fake model server,
# the suites' fixtures and the conformance runner, and from B6 the
# admission fixtures) to its own repositories and pulls them back, and
# from B6 signs them with the platform image key; nothing else: no
# repository settings, no other repository, no delete.
data "aws_iam_policy_document" "ci_ci_components" {
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPush"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:InitiateLayerUpload",
      "ecr:UploadLayerPart",
      "ecr:CompleteLayerUpload",
      "ecr:PutImage",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
      "ecr:DescribeImages",
    ]
    resources = var.ci_components_push_repository_arns
  }

  # B6: it signs and attests the platform's own images with the platform
  # image key, as cosign's KMS signer does; of the other roles, only
  # ci-delegation-sts may use it.
  statement {
    sid       = "PlatformKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.platform_signing_key_arns
  }

  statement {
    sid       = "PlatformSigning"
    actions   = ["kms:Sign"]
    resources = var.platform_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# B6 (D36): infra/delegation-sts, on its protected main alone, pushes the
# images it builds (the STS's and its interop suite's to
# platform/delegation-sts, the reconciliation job's to
# platform/okta-reconciler) and pulls them back, and signs and attests
# them with the platform image key; nothing else: no repository settings,
# no other repository, no delete, no other key. The pushes and cosign's
# writes (each digest's signature and attestations, in the fallback index
# tagged sha256-<hex> locally) need the registry API's actions alone, so
# not DescribeImages. cosign's KMS signer reads the key's metadata as
# well as its public key before it signs, so the key statements grant
# DescribeKey and GetPublicKey beside Sign, as every other signing role's
# do. floci evaluates none of this, so the policy is first proven in dev.
data "aws_iam_policy_document" "ci_delegation_sts" {
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPush"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:InitiateLayerUpload",
      "ecr:UploadLayerPart",
      "ecr:CompleteLayerUpload",
      "ecr:PutImage",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
    ]
    resources = var.delegation_sts_push_repository_arns
  }

  statement {
    sid       = "PlatformKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.platform_signing_key_arns
  }

  statement {
    sid       = "PlatformSigning"
    actions   = ["kms:Sign"]
    resources = var.platform_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# B5: the roles that sign with the release key
# (alias/platform/release-signing), B6's ci-library-release among them,
# do it as cosign's KMS signer does: the
# key's description and public key (ReleaseKeyRead), and Sign over a
# digest with ECDSA_SHA_256, the one algorithm an ECC_NIST_P256 key offers
# (ReleaseSigning). Only the keys behind the alias and its -previous twin,
# and no other key.

# devkit/workload-charts pushes app-base and agent-integration to their own
# repositories by version, pulls them back, and signs them; nothing else.
data "aws_iam_policy_document" "ci_workload_charts" {
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPush"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:InitiateLayerUpload",
      "ecr:UploadLayerPart",
      "ecr:CompleteLayerUpload",
      "ecr:PutImage",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
      "ecr:DescribeImages",
    ]
    resources = var.workload_charts_push_repository_arns
  }

  statement {
    sid       = "ReleaseKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.release_signing_key_arns
  }

  statement {
    sid       = "ReleaseSigning"
    actions   = ["kms:Sign"]
    resources = var.release_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# devkit/agentctl signs the binaries it releases with cosign sign-blob and
# uploads them to its own GitLab package registry: the release key alone.
data "aws_iam_policy_document" "ci_agentctl" {
  statement {
    sid       = "ReleaseKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.release_signing_key_arns
  }

  statement {
    sid       = "ReleaseSigning"
    actions   = ["kms:Sign"]
    resources = var.release_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# A registered workload's release pipeline pushes its image to the
# workloads' repositories and signs it with the release key. One role
# serves every workload project, so this policy cannot hold a project to
# its own repository: each may push to any registered workload's. Until
# the first workload registers there is no repository, and the role may
# only sign, though its trust admits no one.
data "aws_iam_policy_document" "ci_workload_release" {
  dynamic "statement" {
    for_each = length(var.workload_release_push_repository_arns) > 0 ? [1] : []
    content {
      sid       = "EcrLogin"
      actions   = ["ecr:GetAuthorizationToken"]
      resources = ["*"]
    }
  }

  dynamic "statement" {
    for_each = length(var.workload_release_push_repository_arns) > 0 ? [1] : []
    content {
      sid = "EcrPush"
      actions = [
        "ecr:BatchCheckLayerAvailability",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:PutImage",
        "ecr:BatchGetImage",
        "ecr:GetDownloadUrlForLayer",
        "ecr:DescribeImages",
      ]
      resources = var.workload_release_push_repository_arns
    }
  }

  statement {
    sid       = "ReleaseKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.release_signing_key_arns
  }

  statement {
    sid       = "ReleaseSigning"
    actions   = ["kms:Sign"]
    resources = var.release_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# B6: infra/conformance's pipeline, on its protected main alone, reads the
# workload under test (its image, for /etc/agentic/workload.yaml, and the
# charts it deploys by digest), then signs the conformance attestation on
# the image's digest with the conformance key. cosign writes the
# attestation into the workload's repository: locally a new manifest and
# the rewritten sha256-<hex> fallback tag, in dev a referrer by digest.
# So it may push to the registered workloads' repositories, as
# ci-workload-release may, but sign only with the conformance key.
data "aws_iam_policy_document" "ci_conformance" {
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPull"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
      "ecr:DescribeImages",
    ]
    resources = concat(var.workload_release_push_repository_arns, var.workload_charts_push_repository_arns)
  }

  # B6: infra/conformance finds the digest's repository by listing the
  # workloads' and incubator's repositories and their images. Listing
  # repositories with no names given is authorized on every repository,
  # and returns names alone.
  statement {
    sid       = "EcrListRepositories"
    actions   = ["ecr:DescribeRepositories"]
    resources = ["arn:${local.partition}:ecr:${local.region}:${local.account}:repository/*"]
  }

  statement {
    sid     = "EcrListImages"
    actions = ["ecr:DescribeImages", "ecr:ListImages"]
    resources = [
      "arn:${local.partition}:ecr:${local.region}:${local.account}:repository/workloads/*",
      "arn:${local.partition}:ecr:${local.region}:${local.account}:repository/incubator/*",
    ]
  }

  # B6: its contract stage copies the image under test to its own scratch
  # repository, starts it from there and deletes it after.
  dynamic "statement" {
    for_each = length(var.conformance_scratch_repository_arns) > 0 ? [1] : []
    content {
      sid = "EcrScratch"
      actions = [
        "ecr:BatchCheckLayerAvailability",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:PutImage",
        "ecr:BatchGetImage",
        "ecr:GetDownloadUrlForLayer",
        "ecr:DescribeImages",
        "ecr:ListImages",
        "ecr:BatchDeleteImage",
      ]
      resources = var.conformance_scratch_repository_arns
    }
  }

  dynamic "statement" {
    for_each = length(var.workload_release_push_repository_arns) > 0 ? [1] : []
    content {
      sid = "EcrAttest"
      actions = [
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:PutImage",
      ]
      resources = var.workload_release_push_repository_arns
    }
  }

  statement {
    sid       = "ConformanceKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.conformance_signing_key_arns
  }

  statement {
    sid       = "ConformanceSigning"
    actions   = ["kms:Sign"]
    resources = var.conformance_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# B6 (D41): a registered library project's release, from a protected
# <kind>/<name>/vX.Y.Z tag, pushes its artifact with ORAS to the
# library's repositories and signs and attests it with the release key,
# as a workload's release does. One role serves every library project,
# so it cannot hold a project to its own artifacts' repositories.
data "aws_iam_policy_document" "ci_library_release" {
  dynamic "statement" {
    for_each = length(var.library_release_push_repository_arns) > 0 ? [1] : []
    content {
      sid       = "EcrLogin"
      actions   = ["ecr:GetAuthorizationToken"]
      resources = ["*"]
    }
  }

  dynamic "statement" {
    for_each = length(var.library_release_push_repository_arns) > 0 ? [1] : []
    content {
      sid = "EcrPush"
      actions = [
        "ecr:BatchCheckLayerAvailability",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:PutImage",
        "ecr:BatchGetImage",
        "ecr:GetDownloadUrlForLayer",
        "ecr:DescribeImages",
      ]
      resources = var.library_release_push_repository_arns
    }
  }

  statement {
    sid       = "ReleaseKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.release_signing_key_arns
  }

  statement {
    sid       = "ReleaseSigning"
    actions   = ["kms:Sign"]
    resources = var.release_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }
}

# B6 (D37, D41): the catalog's scheduled pipeline in environments signs
# catalog.json with cosign sign-blob and the record key, and puts the index,
# its bundle and its static pages in the index bucket, which Object Lock
# keeps. It reads the registrations and the registered projects through
# GitLab, not AWS, and may read, list or delete nothing in the bucket. A
# data key encrypts each upload; the index is far below the multipart
# threshold, so no kms:Decrypt.
data "aws_iam_policy_document" "ci_catalog" {
  # B6: the catalog reads each registered workload's and library
  # artifact's images and tags (dev's catalog reads them from ECR).
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid       = "EcrListRepositories"
    actions   = ["ecr:DescribeRepositories"]
    resources = ["arn:${local.partition}:ecr:${local.region}:${local.account}:repository/*"]
  }

  dynamic "statement" {
    for_each = length(concat(var.workload_release_push_repository_arns, var.library_pull_repository_arns)) > 0 ? [1] : []
    content {
      sid = "EcrRead"
      actions = [
        "ecr:BatchCheckLayerAvailability",
        "ecr:BatchGetImage",
        "ecr:GetDownloadUrlForLayer",
        "ecr:DescribeImages",
        "ecr:ListImages",
      ]
      resources = concat(var.workload_release_push_repository_arns, var.library_pull_repository_arns)
    }
  }

  statement {
    sid       = "RecordKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.record_signing_key_arns
  }

  statement {
    sid       = "RecordSigning"
    actions   = ["kms:Sign"]
    resources = var.record_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }

  statement {
    sid       = "CatalogIndex"
    actions   = ["s3:PutObject"]
    resources = ["arn:${local.partition}:s3:::${var.catalog_index_bucket.name}/*"]
  }

  statement {
    sid       = "CatalogIndexKey"
    actions   = ["kms:GenerateDataKey"]
    resources = [var.catalog_index_bucket.kms_key_arn]
  }
}

# B6 (D37): environments' deploy job, alone among the project's jobs, signs
# one release record per workload release it applies with the record key,
# as cosign's KMS signer does, and puts it in the records bucket, which
# Object Lock keeps. It may read, list, overwrite or delete nothing there;
# a data key encrypts each upload, and a record is far below the multipart
# threshold, so no kms:Decrypt. The job runs as this role alone, so it
# also has ci-environments' reads.
data "aws_iam_policy_document" "ci_environments_deploy" {
  # The deploy job's reads, as ci-environments has them: the images it
  # deploys and the parameters the foundation publishes, which its
  # renders read (ref+awsssm), since the job runs as this role alone.
  statement {
    sid       = "EcrLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "EcrPull"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:BatchGetImage",
      "ecr:GetDownloadUrlForLayer",
      "ecr:DescribeImages",
    ]
    resources = var.ecr_pull_repository_arns
  }

  statement {
    sid = "SsmRead"
    actions = [
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:GetParametersByPath",
    ]
    resources = [
      "arn:${local.partition}:ssm:${local.region}:${local.account}:parameter${local.ssm_path}",
      "arn:${local.partition}:ssm:${local.region}:${local.account}:parameter${local.ssm_path}/*",
    ]
  }

  statement {
    sid       = "RecordKeyRead"
    actions   = ["kms:DescribeKey", "kms:GetPublicKey"]
    resources = var.record_signing_key_arns
  }

  statement {
    sid       = "RecordSigning"
    actions   = ["kms:Sign"]
    resources = var.record_signing_key_arns

    condition {
      test     = "StringEquals"
      variable = "kms:MessageType"
      values   = ["DIGEST"]
    }

    condition {
      test     = "StringEquals"
      variable = "kms:SigningAlgorithm"
      values   = ["ECDSA_SHA_256"]
    }
  }

  statement {
    sid       = "ReleaseRecords"
    actions   = ["s3:PutObject"]
    resources = ["arn:${local.partition}:s3:::${var.release_records_bucket.name}/*"]
  }

  statement {
    sid       = "ReleaseRecordsKey"
    actions   = ["kms:GenerateDataKey"]
    resources = [var.release_records_bucket.kms_key_arn]
  }
}
