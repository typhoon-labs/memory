# GitLab's OIDC provider and one role per pipeline. Jobs assume a role with
# AssumeRoleWithWebIdentity and a GitLab ID token; the trust conditions are
# those in the design's "CI identity to AWS" (design/repositories.md). The
# workloads' roles are in workloads.tf.

data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}
data "aws_region" "current" {}

locals {
  # The prefix of GitLab's condition keys: the issuer without its scheme.
  issuer_host = trimprefix(var.gitlab_url, "https://")

  account   = data.aws_caller_identity.current.account_id
  partition = data.aws_partition.current.partition
  region    = data.aws_region.current.region

  # One role per pipeline (the plan's Names tables), except
  # ci-workload-release, which every registered workload project's release
  # assumes (plan/local-build.md, "B5 in detail"). The policies are kept
  # apart from the names because ci-aws-foundation's policy lists the roles.
  roles = {
    ci-aws-foundation   = "CI of infra/aws-foundation: plans and applies this repository's stacks"
    ci-environments     = "CI of infra/environments: reads what its deploys need"
    ci-ci-components    = "CI of devkit/ci-components: pushes the images it builds"
    ci-workload-charts  = "CI of devkit/workload-charts: pushes the charts it releases and signs them with the release key"
    ci-agentctl         = "CI of devkit/agentctl: signs the binaries it releases with the release key"
    ci-workload-release = "Releases of registered workload projects, from protected tags: push to their ECR repositories and sign with the release key"
    ci-conformance      = "CI of infra/conformance, its protected main alone: reads the workload under test and signs its conformance attestation with the conformance key"
    ci-library-release  = "Releases of registered library projects, from protected tags: push to the library's ECR repositories and sign with the release key"
    ci-catalog          = "The catalog's scheduled pipeline in infra/environments, on main: signs the catalog index with the record key and writes it to the index bucket"
    # B6 (D37): the deploy job's own role, so that the record key is the
    # deploy job's alone and not every protected job's of the project.
    ci-environments-deploy = "The deploy job of infra/environments, on main, in its declared environment: signs release records with the record key and writes them to the records bucket"
    # B6 (D36): the STS's own image builds, so that its images are signed
    # in its pipeline with the platform image key.
    ci-delegation-sts = "CI of infra/delegation-sts, its protected main alone: pushes the images it builds and signs them with the platform image key"
  }

  policies = {
    ci-aws-foundation      = data.aws_iam_policy_document.ci_aws_foundation.json
    ci-environments        = data.aws_iam_policy_document.ci_environments.json
    ci-ci-components       = data.aws_iam_policy_document.ci_ci_components.json
    ci-workload-charts     = data.aws_iam_policy_document.ci_workload_charts.json
    ci-agentctl            = data.aws_iam_policy_document.ci_agentctl.json
    ci-workload-release    = data.aws_iam_policy_document.ci_workload_release.json
    ci-conformance         = data.aws_iam_policy_document.ci_conformance.json
    ci-library-release     = data.aws_iam_policy_document.ci_library_release.json
    ci-catalog             = data.aws_iam_policy_document.ci_catalog.json
    ci-environments-deploy = data.aws_iam_policy_document.ci_environments_deploy.json
    ci-delegation-sts      = data.aws_iam_policy_document.ci_delegation_sts.json
  }

  # Roles that only release pipelines assume: protected tags, never a
  # protected branch (design/distribution.md, "Release tags").
  tag_only_roles = ["ci-workload-release", "ci-library-release"]

  # B6: roles that only a project's protected main assumes, never a tag
  # or another protected branch: infra/conformance's pipeline runs on main
  # alone (design/conformance.md, "How conformance runs in CI"), the
  # catalog is built on environments' main, and delegation-sts' images
  # are built and signed on its main.
  main_only_roles = ["ci-conformance", "ci-catalog", "ci-environments-deploy", "ci-delegation-sts"]

  # B6: roles that only a scheduled pipeline assumes (pipeline_source
  # schedule): the catalog is rebuilt on a schedule, never by a push or a
  # merge request; a person runs it early by playing the schedule.
  schedule_only_roles = ["ci-catalog"]

  # B6 (D37): roles that only a job declaring a GitLab environment assumes,
  # by the ID token's environment claim, which GitLab sets when the job
  # specifies an environment (Free included); the claim is the job's own
  # declaration, so it tells the deploy job from the project's other jobs
  # on main. Protected environments, which would let GitLab refuse
  # another job the environment, are a Premium feature.
  environment_roles = {
    ci-environments-deploy = var.deploy_environment
  }
}

resource "aws_iam_openid_connect_provider" "gitlab" {
  url            = var.gitlab_url
  client_id_list = [var.gitlab_audience]
  # No thumbprint_list: AWS validates GitLab's certificate against its own
  # trusted CAs, and floci does not validate thumbprints at all.
}

data "aws_iam_policy_document" "trust" {
  for_each = local.roles

  # A role with no registered project yet, which only ci-workload-release,
  # ci-conformance and ci-library-release may be (var.registrations),
  # admits no one: a trust policy needs a statement, and this one denies
  # every GitLab job.
  dynamic "statement" {
    for_each = length(var.registrations[each.key]) == 0 ? [1] : []
    content {
      sid     = "NoProjectRegistered"
      effect  = "Deny"
      actions = ["sts:AssumeRoleWithWebIdentity"]

      principals {
        type        = "Federated"
        identifiers = [aws_iam_openid_connect_provider.gitlab.arn]
      }
    }
  }

  dynamic "statement" {
    for_each = length(var.registrations[each.key]) > 0 ? [1] : []
    content {
      sid     = "GitLabCi"
      effect  = "Allow"
      actions = ["sts:AssumeRoleWithWebIdentity"]

      principals {
        type        = "Federated"
        identifiers = [aws_iam_openid_connect_provider.gitlab.arn]
      }

      condition {
        test     = "StringEquals"
        variable = "${local.issuer_host}:aud"
        values   = [var.gitlab_audience]
      }

      # Registered projects only, by ID: IDs survive renames and transfers.
      condition {
        test     = "StringEquals"
        variable = "${local.issuer_host}:project_id"
        values   = var.registrations[each.key]
      }

      # The same projects through sub, which every project starts with
      # project_id (ci_id_token_sub_claim_components). The colon after the ID
      # stops 123 from matching 1234.
      condition {
        test     = "StringLike"
        variable = "${local.issuer_host}:sub"
        values   = [for id in var.registrations[each.key] : "project_id:${id}:*"]
      }

      # Protected branches and tags only.
      condition {
        test     = "StringEquals"
        variable = "${local.issuer_host}:ref_protected"
        values   = ["true"]
      }

      # Never GitLab-hosted runners.
      condition {
        test     = "StringEquals"
        variable = "${local.issuer_host}:runner_environment"
        values   = ["self-hosted"]
      }

      # Releases only: a protected tag, never a branch.
      dynamic "condition" {
        for_each = contains(local.tag_only_roles, each.key) ? [1] : []
        content {
          test     = "StringEquals"
          variable = "${local.issuer_host}:ref_type"
          values   = ["tag"]
        }
      }

      # Main only: the branch main, never a tag or another protected
      # branch.
      dynamic "condition" {
        for_each = contains(local.main_only_roles, each.key) ? [1] : []
        content {
          test     = "StringEquals"
          variable = "${local.issuer_host}:ref_type"
          values   = ["branch"]
        }
      }

      dynamic "condition" {
        for_each = contains(local.main_only_roles, each.key) ? [1] : []
        content {
          test     = "StringEquals"
          variable = "${local.issuer_host}:ref"
          values   = ["main"]
        }
      }

      # The deploy job only: a job that declares the environment.
      dynamic "condition" {
        for_each = contains(keys(local.environment_roles), each.key) ? [1] : []
        content {
          test     = "StringEquals"
          variable = "${local.issuer_host}:environment"
          values   = [local.environment_roles[each.key]]
        }
      }

      # Scheduled pipelines only.
      dynamic "condition" {
        for_each = contains(local.schedule_only_roles, each.key) ? [1] : []
        content {
          test     = "StringEquals"
          variable = "${local.issuer_host}:pipeline_source"
          values   = ["schedule"]
        }
      }
    }
  }
}

resource "aws_iam_role" "ci" {
  for_each = local.roles

  name               = each.key
  description        = each.value
  assume_role_policy = data.aws_iam_policy_document.trust[each.key].json
}

resource "aws_iam_role_policy" "ci" {
  for_each = local.roles

  name   = each.key
  role   = aws_iam_role.ci[each.key].id
  policy = local.policies[each.key]
}
