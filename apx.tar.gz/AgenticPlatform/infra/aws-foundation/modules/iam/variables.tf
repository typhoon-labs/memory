variable "gitlab_url" {
  description = "Issuer of the GitLab ID tokens, without a trailing slash, such as https://gitlab.com."
  type        = string

  validation {
    condition     = can(regex("^https://[^/]+$", var.gitlab_url))
    error_message = "gitlab_url must be an https URL with a host and no path or trailing slash."
  }
}

variable "gitlab_audience" {
  description = "The aud claim CI jobs request in id_tokens. It is the OIDC provider's only client ID and must equal the aud in .gitlab-ci.yml."
  type        = string
}

variable "registrations" {
  description = "Numeric GitLab project IDs that each CI role trusts, keyed by role name. Only ci-workload-release, ci-conformance and ci-library-release may have none, until their first project registers; each then admits no one."
  type        = map(list(string))

  validation {
    condition = (
      length(setsubtract(keys(var.registrations), ["ci-aws-foundation", "ci-environments", "ci-ci-components", "ci-workload-charts", "ci-agentctl", "ci-workload-release", "ci-conformance", "ci-library-release", "ci-catalog", "ci-environments-deploy", "ci-delegation-sts"])) == 0 &&
      length(setsubtract(["ci-aws-foundation", "ci-environments", "ci-ci-components", "ci-workload-charts", "ci-agentctl", "ci-workload-release", "ci-conformance", "ci-library-release", "ci-catalog", "ci-environments-deploy", "ci-delegation-sts"], keys(var.registrations))) == 0
    )
    error_message = "registrations must have exactly the roles this module defines: ci-aws-foundation, ci-environments, ci-ci-components, ci-workload-charts, ci-agentctl, ci-workload-release, ci-conformance, ci-library-release, ci-catalog, ci-environments-deploy and ci-delegation-sts."
  }

  validation {
    condition = alltrue([
      for role, ids in var.registrations :
      (length(ids) > 0 || contains(["ci-workload-release", "ci-conformance", "ci-library-release"], role)) && alltrue([for id in ids : can(regex("^[0-9]+$", id))])
    ])
    error_message = "Each role but ci-workload-release, ci-conformance and ci-library-release needs at least one project, and every project is given by its numeric project ID."
  }

  validation {
    condition     = length(lookup(var.registrations, "ci-conformance", [])) <= 1
    error_message = "ci-conformance trusts infra/conformance alone: register at most one project."
  }

  validation {
    condition     = length(lookup(var.registrations, "ci-delegation-sts", [])) <= 1
    error_message = "ci-delegation-sts trusts infra/delegation-sts alone: register at most one project."
  }
}

variable "state" {
  description = "The S3 bucket and key of the stack's state, which ci-aws-foundation reads and writes. The lock file is the key plus .tflock."
  type = object({
    bucket = string
    key    = string
  })
}

variable "ecr_pull_repository_arns" {
  description = "ARNs of the ECR repositories ci-environments may pull from."
  type        = list(string)
}

variable "ci_components_push_repository_arns" {
  description = "ARNs of the ECR repositories ci-ci-components may push to: the images devkit/ci-components builds."
  type        = list(string)
}

variable "delegation_sts_push_repository_arns" {
  description = "B6: ARNs of the ECR repositories ci-delegation-sts may push to: the images infra/delegation-sts builds, the STS's and its interop suite's, and the reconciliation job's."
  type        = list(string)

  validation {
    condition     = length(var.delegation_sts_push_repository_arns) > 0
    error_message = "delegation_sts_push_repository_arns needs at least one repository."
  }
}

variable "workload_charts_push_repository_arns" {
  description = "ARNs of the ECR repositories ci-workload-charts may push to: the charts devkit/workload-charts releases."
  type        = list(string)

  validation {
    condition     = length(var.workload_charts_push_repository_arns) > 0
    error_message = "workload_charts_push_repository_arns needs at least one repository."
  }
}

variable "workload_release_push_repository_arns" {
  description = "ARNs of the ECR repositories ci-workload-release may push to: one per registered workload, each added by its registration (D4). Empty until the first workload registers."
  type        = list(string)
  default     = []
}

variable "release_signing_key_arns" {
  description = "ARNs of the release keys a signer may sign with: those behind alias/platform/release-signing and its -previous twin."
  type        = list(string)

  validation {
    condition     = length(var.release_signing_key_arns) > 0
    error_message = "release_signing_key_arns needs at least one key."
  }
}

variable "platform_signing_key_arns" {
  description = "B6: ARNs of the platform image keys ci-ci-components and ci-delegation-sts may sign with: those behind alias/platform/platform-signing and its -previous twin. No workload role may use them."
  type        = list(string)

  validation {
    condition     = length(var.platform_signing_key_arns) > 0
    error_message = "platform_signing_key_arns needs at least one key."
  }
}

variable "conformance_signing_key_arns" {
  description = "B6: ARNs of the conformance keys ci-conformance may sign with: those behind alias/platform/conformance-signing and its -previous twin."
  type        = list(string)

  validation {
    condition     = length(var.conformance_signing_key_arns) > 0
    error_message = "conformance_signing_key_arns needs at least one key."
  }
}

variable "conformance_scratch_repository_arns" {
  description = "B6: ARNs of infra/conformance's contract stage's scratch repositories, which ci-conformance pushes the image under test to and deletes it from."
  type        = list(string)
  default     = []
}

variable "library_pull_repository_arns" {
  description = "B6 (D41): ARNs of the library's repositories, which ci-catalog reads."
  type        = list(string)
  default     = []
}

variable "record_signing_key_arns" {
  description = "B6 (D37): ARNs of the record keys ci-catalog and ci-environments-deploy may sign with: those behind alias/platform/record-signing and its -previous twin. No other role may use them."
  type        = list(string)

  validation {
    condition     = length(var.record_signing_key_arns) > 0
    error_message = "record_signing_key_arns needs at least one key."
  }
}

variable "library_release_push_repository_arns" {
  description = "B6: ARNs of the ECR repositories ci-library-release may push to: one per library artifact, library/<kind>/<name>."
  type        = list(string)
  default     = []
}

variable "release_records_bucket" {
  description = "B6 (D37): the bucket ci-environments-deploy writes release records to, by name, and the ARN of its own KMS key."
  type = object({
    name        = string
    kms_key_arn = string
  })
}

variable "deploy_environment" {
  description = "B6 (D37): the GitLab environment infra/environments' deploy job declares (environment:name), which ci-environments-deploy trusts in the ID token's environment claim, such as local."
  type        = string

  validation {
    condition     = can(regex("^[a-z0-9][a-z0-9-]*$", var.deploy_environment))
    error_message = "deploy_environment must be a lowercase environment name, such as local."
  }
}

variable "catalog_index_bucket" {
  description = "B6 (D37, D41): the bucket ci-catalog writes the signed catalog index to, by name, and the ARN of its own KMS key."
  type = object({
    name        = string
    kms_key_arn = string
  })
}

variable "ssm_parameter_path" {
  description = "Path of the SSM parameters the stack publishes, which ci-aws-foundation writes and ci-environments reads, with leading and trailing slashes, such as /platform/."
  type        = string

  validation {
    condition     = can(regex("^/([A-Za-z0-9_.-]+/)+$", var.ssm_parameter_path))
    error_message = "ssm_parameter_path must start and end with a slash, such as /platform/."
  }
}

variable "workload_trust" {
  description = "Who may assume the workload roles: aws lists IAM principals (locally floci's account root, for its static credentials); services lists service principals (pods.eks.amazonaws.com for EKS Pod Identity)."
  type = object({
    aws      = optional(list(string), [])
    services = optional(list(string), [])
  })

  validation {
    condition     = length(var.workload_trust.aws) + length(var.workload_trust.services) > 0
    error_message = "workload_trust needs at least one principal."
  }
}

variable "sts_signing_keys" {
  description = "ARNs of the delegation STS's KMS keys: sign, the keys behind sts-signing and sts-signing-previous; publish, those behind all three aliases."
  type = object({
    sign    = list(string)
    publish = list(string)
  })
}

variable "external_secrets" {
  description = "The Secrets Manager entries External Secrets Operator may read: names, entries known by name whoever creates them; arns, entries known only by ARN, such as an RDS-managed secret."
  type = object({
    names = list(string)
    arns  = optional(list(string), [])
  })
}

variable "managed" {
  description = "What else the stack manages, by name, so ci-aws-foundation's policy names it before it exists: db_instances, DB instance identifiers; secrets, the names of the Secrets Manager entries the stack creates; kms_alias_prefix, the prefix of its KMS aliases, such as alias/platform/; buckets, the names of its S3 buckets."
  type = object({
    db_instances     = list(string)
    secrets          = list(string)
    kms_alias_prefix = string
    buckets          = optional(list(string), [])
  })

  validation {
    condition     = can(regex("^alias/([A-Za-z0-9_-]+/)+$", var.managed.kms_alias_prefix))
    error_message = "kms_alias_prefix must start with alias/ and end with a slash, such as alias/platform/."
  }
}

variable "gateway_bedrock" {
  description = "What the gateway, platform-gateway, may invoke on Bedrock, or null where the gateway calls no Bedrock and the role is not created, such as an environment whose model provider is the fake model server. model_arns: the foundation models and inference profiles it invokes through Bedrock Runtime; mantle_project_arns: the Mantle projects it runs inference in."
  type = object({
    model_arns          = list(string)
    mantle_project_arns = optional(list(string), [])
  })
  default = null

  validation {
    condition     = var.gateway_bedrock == null || length(try(var.gateway_bedrock.model_arns, [])) + length(try(var.gateway_bedrock.mantle_project_arns, [])) > 0
    error_message = "gateway_bedrock needs at least one model or Mantle project ARN, or null."
  }
}

variable "data_buckets" {
  description = "The buckets of build phases B3's and B4's workloads, each given by name and by the ARN of its own KMS key, and each role created only where the stack has its buckets: langfuse, the event and media buckets platform-langfuse reads and writes; cnpg_backups, the bucket platform-cnpg-backups writes backups to, prunes and restores from; audit, the bucket platform-telemetry-audit may only put objects in; kagent, the snapshot bucket platform-kagent-snapshots writes, reads and deletes in, and the asset bucket it only reads."
  type = object({
    langfuse = optional(list(object({
      name        = string
      kms_key_arn = string
    })), [])
    cnpg_backups = optional(object({
      name        = string
      kms_key_arn = string
    }))
    audit = optional(object({
      name        = string
      kms_key_arn = string
    }))
    kagent = optional(object({
      snapshots = object({
        name        = string
        kms_key_arn = string
      })
      assets = object({
        name        = string
        kms_key_arn = string
      })
    }))
  })
  default = {}
}
