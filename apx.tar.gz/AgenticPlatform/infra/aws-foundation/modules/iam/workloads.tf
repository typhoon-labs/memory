# One role per platform workload that calls AWS from the cluster. Who may
# assume them is a value (var.workload_trust): locally floci's account
# root, which its static test credentials stand for; in dev, EKS Pod
# Identity. Each policy names its actions on its resources only.

locals {
  # The gateway's role exists only where the gateway calls Bedrock
  # (var.gateway_bedrock), and B3's and B4's data roles only where the
  # stack has their buckets (var.data_buckets).
  workload_roles = merge(
    {
      platform-delegation-sts   = "Delegation STS: signs tokens with its KMS keys and publishes their public keys"
      platform-external-secrets = "External Secrets Operator: reads the platform's Secrets Manager entries"
    },
    var.gateway_bedrock == null ? {} : {
      platform-gateway = "agentgateway: the one principal that invokes Bedrock models (design/gateway.md, \"Bypass prevention\")"
    },
    length(var.data_buckets.langfuse) == 0 ? {} : {
      platform-langfuse = "Langfuse: reads and writes its event and media buckets"
    },
    var.data_buckets.cnpg_backups == null ? {} : {
      platform-cnpg-backups = "CloudNativePG's Barman Cloud plugin: writes and prunes the backups, and the restore drill reads them"
    },
    var.data_buckets.audit == null ? {} : {
      platform-telemetry-audit = "The collector's audit exporter: puts objects in the audit bucket and does nothing else"
    },
    var.data_buckets.kagent == null ? {} : {
      platform-kagent-snapshots = "Substrate's object-store plugins: write, read and delete kagent's session snapshots, and read the sandbox assets"
    },
  )

  workload_policies = merge(
    {
      platform-delegation-sts   = data.aws_iam_policy_document.delegation_sts.json
      platform-external-secrets = data.aws_iam_policy_document.external_secrets.json
    },
    var.gateway_bedrock == null ? {} : {
      platform-gateway = data.aws_iam_policy_document.gateway[0].json
    },
    length(var.data_buckets.langfuse) == 0 ? {} : {
      platform-langfuse = data.aws_iam_policy_document.langfuse[0].json
    },
    var.data_buckets.cnpg_backups == null ? {} : {
      platform-cnpg-backups = data.aws_iam_policy_document.cnpg_backups[0].json
    },
    var.data_buckets.audit == null ? {} : {
      platform-telemetry-audit = data.aws_iam_policy_document.telemetry_audit[0].json
    },
    var.data_buckets.kagent == null ? {} : {
      platform-kagent-snapshots = data.aws_iam_policy_document.kagent_snapshots[0].json
    },
  )
}

data "aws_iam_policy_document" "workload_trust" {
  statement {
    sid = "Workload"
    # TagSession: Pod Identity tags each session with the cluster,
    # namespace and service account, and External Secrets Operator may
    # tag sessions with its store.
    actions = ["sts:AssumeRole", "sts:TagSession"]

    dynamic "principals" {
      for_each = length(var.workload_trust.aws) > 0 ? [var.workload_trust.aws] : []
      content {
        type        = "AWS"
        identifiers = principals.value
      }
    }

    dynamic "principals" {
      for_each = length(var.workload_trust.services) > 0 ? [var.workload_trust.services] : []
      content {
        type        = "Service"
        identifiers = principals.value
      }
    }
  }
}

resource "aws_iam_role" "workload" {
  for_each = local.workload_roles

  name               = each.key
  description        = each.value
  assume_role_policy = data.aws_iam_policy_document.workload_trust.json
}

resource "aws_iam_role_policy" "workload" {
  for_each = local.workload_roles

  name   = each.key
  role   = aws_iam_role.workload[each.key].id
  policy = local.workload_policies[each.key]
}

# design/identity.md, "Signing keys and JWKS": sign only with the keys
# behind sts-signing and sts-signing-previous; read the public key and
# metadata of the keys behind all three aliases. Both lists follow the
# aliases in the same apply that moves them.
data "aws_iam_policy_document" "delegation_sts" {
  statement {
    sid       = "Sign"
    actions   = ["kms:Sign"]
    resources = var.sts_signing_keys.sign
  }

  statement {
    sid       = "Publish"
    actions   = ["kms:GetPublicKey", "kms:DescribeKey"]
    resources = var.sts_signing_keys.publish
  }
}

# The read actions of External Secrets Operator's documented policy, on the
# named entries only. Without ListSecrets the operator cannot search, so
# every ExternalSecret names its entry.
data "aws_iam_policy_document" "external_secrets" {
  statement {
    sid = "ReadPlatformSecrets"
    actions = [
      "secretsmanager:GetSecretValue",
      "secretsmanager:DescribeSecret",
      "secretsmanager:GetResourcePolicy",
      "secretsmanager:ListSecretVersionIds",
    ]
    # An entry's ARN ends in a hyphen and six random characters, so -??????
    # matches the named entry alone, whoever created it.
    resources = concat(
      [
        for name in var.external_secrets.names :
        "arn:${local.partition}:secretsmanager:${local.region}:${local.account}:secret:${name}-??????"
      ],
      var.external_secrets.arns,
    )
  }
}

# design/gateway.md, "Bypass prevention": only the gateway invokes models,
# through Bedrock Runtime (InvokeModel, and Converse, which IAM authorizes as
# InvokeModel) or Mantle's native APIs, on the models and projects named.
# The SCP in modules/scp denies the same actions to every other principal.
data "aws_iam_policy_document" "gateway" {
  count = var.gateway_bedrock == null ? 0 : 1

  dynamic "statement" {
    for_each = length(var.gateway_bedrock.model_arns) > 0 ? [1] : []
    content {
      sid       = "InvokeModels"
      actions   = ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"]
      resources = var.gateway_bedrock.model_arns
    }
  }

  dynamic "statement" {
    for_each = length(var.gateway_bedrock.mantle_project_arns) > 0 ? [1] : []
    content {
      sid       = "MantleInference"
      actions   = ["bedrock-mantle:CreateInference", "bedrock-mantle:CountTokens"]
      resources = var.gateway_bedrock.mantle_project_arns
    }
  }
}

# Langfuse's event and media buckets (plan/local-build.md, "B3 in detail",
# Langfuse): it writes events and media, reads them back, and deletes them
# when a project or trace is deleted. Browsers use presigned URLs, which
# act with this role's rights. The keys encrypt and decrypt the objects.
data "aws_iam_policy_document" "langfuse" {
  count = length(var.data_buckets.langfuse) == 0 ? 0 : 1

  statement {
    sid       = "ListBuckets"
    actions   = ["s3:ListBucket"]
    resources = [for b in var.data_buckets.langfuse : "arn:${local.partition}:s3:::${b.name}"]
  }

  statement {
    sid       = "Objects"
    actions   = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"]
    resources = [for b in var.data_buckets.langfuse : "arn:${local.partition}:s3:::${b.name}/*"]
  }

  statement {
    sid       = "Keys"
    actions   = ["kms:GenerateDataKey", "kms:Decrypt"]
    resources = [for b in var.data_buckets.langfuse : b.kms_key_arn]
  }
}

# The Barman Cloud plugin's documented rights on its bucket: WAL and base
# backups go up in parts, the retention policy deletes obsolete backups,
# and a restore, the restore drill's among them, reads them back.
data "aws_iam_policy_document" "cnpg_backups" {
  count = var.data_buckets.cnpg_backups == null ? 0 : 1

  statement {
    sid       = "Bucket"
    actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = ["arn:${local.partition}:s3:::${var.data_buckets.cnpg_backups.name}"]
  }

  statement {
    sid = "Objects"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:AbortMultipartUpload",
    ]
    resources = ["arn:${local.partition}:s3:::${var.data_buckets.cnpg_backups.name}/*"]
  }

  statement {
    sid       = "Key"
    actions   = ["kms:GenerateDataKey", "kms:Decrypt"]
    resources = [var.data_buckets.cnpg_backups.kms_key_arn]
  }
}

# The audit archive (design/observability.md, "Audit and usage records"):
# the collector puts each batch of audit records as an object of its own,
# which Object Lock keeps, and may read, list, overwrite or delete nothing.
# A data key encrypts each upload. No kms:Decrypt: an upload above the
# transfer manager's part size would need it for a multipart upload, and a
# minute's batch of records is far below that.
data "aws_iam_policy_document" "telemetry_audit" {
  count = var.data_buckets.audit == null ? 0 : 1

  statement {
    sid       = "PutObjects"
    actions   = ["s3:PutObject"]
    resources = ["arn:${local.partition}:s3:::${var.data_buckets.audit.name}/*"]
  }

  statement {
    sid       = "Key"
    actions   = ["kms:GenerateDataKey"]
    resources = [var.data_buckets.audit.kms_key_arn]
  }
}

# kagent's snapshots and gVisor's mirrored assets (plan/local-build.md,
# "B4 in detail"): Substrate's object-store plugins, the API server's and
# atelet's, write each session's snapshot of /data in parts, read it back
# on resume, and delete the one a suspend releases; atelet reads gVisor's
# release tarballs from the asset bucket and writes nothing there, since
# the workstation mirrors them. The keys encrypt and decrypt the objects.
data "aws_iam_policy_document" "kagent_snapshots" {
  count = var.data_buckets.kagent == null ? 0 : 1

  statement {
    sid     = "Buckets"
    actions = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = [
      "arn:${local.partition}:s3:::${var.data_buckets.kagent.snapshots.name}",
      "arn:${local.partition}:s3:::${var.data_buckets.kagent.assets.name}",
    ]
  }

  statement {
    sid = "Snapshots"
    actions = [
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:AbortMultipartUpload",
    ]
    resources = ["arn:${local.partition}:s3:::${var.data_buckets.kagent.snapshots.name}/*"]
  }

  statement {
    sid       = "Assets"
    actions   = ["s3:GetObject"]
    resources = ["arn:${local.partition}:s3:::${var.data_buckets.kagent.assets.name}/*"]
  }

  statement {
    sid       = "SnapshotsKey"
    actions   = ["kms:GenerateDataKey", "kms:Decrypt"]
    resources = [var.data_buckets.kagent.snapshots.kms_key_arn]
  }

  statement {
    sid       = "AssetsKey"
    actions   = ["kms:Decrypt"]
    resources = [var.data_buckets.kagent.assets.kms_key_arn]
  }
}
