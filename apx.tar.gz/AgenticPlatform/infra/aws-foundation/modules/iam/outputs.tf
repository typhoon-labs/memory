output "role_arns" {
  description = "ARN of each CI role, keyed by role name."
  value       = { for name, role in aws_iam_role.ci : name => role.arn }
}

output "oidc_provider_arn" {
  description = "ARN of GitLab's OIDC provider."
  value       = aws_iam_openid_connect_provider.gitlab.arn
}

output "workload_role_arns" {
  description = "ARN of each workload role, keyed by role name."
  value       = { for name, role in aws_iam_role.workload : name => role.arn }
}
