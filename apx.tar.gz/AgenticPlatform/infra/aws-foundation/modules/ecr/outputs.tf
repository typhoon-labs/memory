output "repositories" {
  description = "ARN and URL of each repository, keyed by repository name. The URL is the repositoryUri as ECR's API returns it."
  value = {
    for name, repo in aws_ecr_repository.this : name => {
      arn = repo.arn
      url = repo.repository_url
    }
  }
}
