# ECR repositories. Tags are immutable unless a stack says otherwise: a tag,
# once pushed, never moves, and every consumer pins a digest
# (design/distribution.md). A stack may also expire every image some days
# after its push, for scratch repositories.

resource "aws_ecr_repository" "this" {
  for_each = var.repositories

  name                 = each.key
  image_tag_mutability = var.image_tag_mutability
}

resource "aws_ecr_lifecycle_policy" "this" {
  for_each = var.expire_after_days == null ? toset([]) : var.repositories

  repository = aws_ecr_repository.this[each.key].name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Expire every image ${var.expire_after_days} days after its push"
      selection = {
        tagStatus   = "any"
        countType   = "sinceImagePushed"
        countUnit   = "days"
        countNumber = var.expire_after_days
      }
      action = { type = "expire" }
    }]
  })
}
