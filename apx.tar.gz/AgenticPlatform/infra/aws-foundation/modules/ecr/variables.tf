variable "repositories" {
  description = "Names of the ECR repositories to create, such as platform/pull-check."
  type        = set(string)
}

variable "image_tag_mutability" {
  description = "IMMUTABLE, so that a pushed tag never moves, or MUTABLE where cosign must rewrite its fallback tag sha256-<hex> on each sign and attest because the registry has no referrers API, as floci's has not (plan/local-build.md, \"B5 in detail\"). Deploys pin digests either way."
  type        = string
  default     = "IMMUTABLE"

  validation {
    condition     = contains(["IMMUTABLE", "MUTABLE"], var.image_tag_mutability)
    error_message = "image_tag_mutability must be IMMUTABLE or MUTABLE."
  }
}

variable "expire_after_days" {
  description = "Days after its push when every image expires, or null for never: for scratch repositories."
  type        = number
  default     = null

  validation {
    condition     = var.expire_after_days == null || (try(var.expire_after_days >= 1, false) && try(floor(var.expire_after_days) == var.expire_after_days, false))
    error_message = "expire_after_days must be null or a whole number of days, at least 1."
  }
}
