output "policy_id" {
  description = "The SCP's ID."
  value       = aws_organizations_policy.this.id
}
