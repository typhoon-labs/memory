variable "name" {
  description = "The policy's name in AWS Organizations."
  type        = string
  default     = "platform-bedrock-through-gateway"
}

variable "allowed_principal_arns" {
  description = "IAM principals that may still invoke Bedrock models: the gateway's role, and any exception named in a decision. Compared with aws:PrincipalArn, so a role is named by its role ARN, not a session's."
  type        = list(string)

  validation {
    condition     = length(var.allowed_principal_arns) > 0 && alltrue([for arn in var.allowed_principal_arns : can(regex("^arn:[a-z-]+:iam::[0-9]{12}:role/", arn))])
    error_message = "allowed_principal_arns needs at least one role ARN, such as arn:aws:iam::<account>:role/platform-gateway."
  }
}

variable "target_ids" {
  description = "The organization's roots, organizational units or accounts the policy is attached to (r-..., ou-... or a 12-digit account ID)."
  type        = list(string)

  validation {
    condition     = length(var.target_ids) > 0 && alltrue([for id in var.target_ids : can(regex("^(r-[0-9a-z]{4,32}|ou-[0-9a-z]{4,32}-[a-z0-9]{8,32}|[0-9]{12})$", id))])
    error_message = "target_ids needs at least one root (r-...), organizational unit (ou-...) or 12-digit account ID."
  }
}
