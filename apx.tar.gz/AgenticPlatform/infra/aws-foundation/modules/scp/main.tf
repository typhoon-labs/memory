# The service control policy that keeps Bedrock to the gateway
# (design/gateway.md, "Bypass prevention"): every principal in the accounts
# it is attached to is denied model invocation, through Bedrock Runtime or
# Mantle, unless it is the gateway's role or a named exception. An SCP grants
# nothing; the gateway still needs its own role's policy (modules/iam).
#
# Whether the platform team or the organization's owners attach SCPs is
# open (D3). SCPs never bound an organization's management account, so the
# accounts that run the platform must be members.

data "aws_iam_policy_document" "this" {
  statement {
    sid    = "BedrockOnlyThroughTheGateway"
    effect = "Deny"
    actions = [
      "bedrock:InvokeModel",
      "bedrock:InvokeModelWithResponseStream",
      "bedrock-mantle:CreateInference",
      "bedrock-mantle:CountTokens",
    ]
    resources = ["*"]

    condition {
      test     = "ArnNotLike"
      variable = "aws:PrincipalArn"
      values   = var.allowed_principal_arns
    }
  }
}

resource "aws_organizations_policy" "this" {
  name        = var.name
  description = "Bedrock model invocation only through the platform gateway's role"
  type        = "SERVICE_CONTROL_POLICY"
  content     = data.aws_iam_policy_document.this.minified_json
}

resource "aws_organizations_policy_attachment" "this" {
  for_each = toset(var.target_ids)

  policy_id = aws_organizations_policy.this.id
  target_id = each.value
}
