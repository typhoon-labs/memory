# Asymmetric signing keys behind one alias and its -next and -previous
# twins (design/identity.md, "Signing keys and JWKS"). KMS cannot rotate
# asymmetric keys, so a rotation adds a key and moves the aliases, one
# aws-foundation change per step:
#
#   1 publish  add a key to keys; set next to it
#   2 switch   set current to it, previous to the old key; unset next
#   3 retire   unset previous; drop the old key from keys, which
#              schedules its deletion
#
# No key policy is set, so each key has KMS's default policy: the account
# administers it, and IAM policies grant its use.

locals {
  # Alias name => the label of the key behind it, for the aliases that
  # exist now.
  aliases = {
    for suffix, label in {
      ""          = var.current
      "-next"     = var.next
      "-previous" = var.previous
    } : "${var.alias}${suffix}" => label if label != null
  }
}

resource "aws_kms_key" "this" {
  for_each = var.keys

  description              = "${var.description} (key ${each.key})"
  customer_master_key_spec = var.key_spec
  key_usage                = "SIGN_VERIFY"
  deletion_window_in_days  = var.deletion_window_in_days
}

resource "aws_kms_alias" "this" {
  for_each = local.aliases

  name          = each.key
  target_key_id = aws_kms_key.this[each.value].key_id
}
