variable "alias" {
  description = "The alias that signs, such as alias/platform/sts-signing. During a rotation the module also creates <alias>-next and <alias>-previous."
  type        = string

  validation {
    condition     = can(regex("^alias/[A-Za-z0-9/_-]+$", var.alias)) && !startswith(var.alias, "alias/aws/")
    error_message = "alias must start with alias/, hold only letters, digits, /, _ and -, and not be under alias/aws/."
  }
}

variable "description" {
  description = "What the keys sign; each key's description adds its label."
  type        = string
}

variable "keys" {
  description = "Labels of the keys that exist, one key each, such as the month each was created (2026-11). Removing a label schedules that key's deletion."
  type        = set(string)

  validation {
    condition     = length(var.keys) > 0 && alltrue([for k in var.keys : can(regex("^[a-z0-9-]+$", k))])
    error_message = "keys needs at least one label of lowercase letters, digits and hyphens."
  }
}

variable "current" {
  description = "The label of the key behind the alias itself: the key that signs."
  type        = string

  validation {
    condition     = contains(var.keys, var.current)
    error_message = "current must be a label in keys."
  }
}

variable "next" {
  description = "The label of the key behind <alias>-next, published before it signs (rotation step 1), or null."
  type        = string
  default     = null

  validation {
    condition     = var.next == null || (contains(var.keys, coalesce(var.next, "-")) && var.next != var.current)
    error_message = "next must be null, or a label in keys other than current."
  }
}

variable "previous" {
  description = "The label of the key behind <alias>-previous, still published after its last signature (rotation step 2), or null."
  type        = string
  default     = null

  validation {
    condition = var.previous == null || (
      contains(var.keys, coalesce(var.previous, "-")) &&
      var.previous != var.current && var.previous != var.next
    )
    error_message = "previous must be null, or a label in keys other than current and next."
  }
}

variable "key_spec" {
  description = "The KMS key spec. ECC_NIST_P256 signs ES256 (ECDSA_SHA_256)."
  type        = string
  default     = "ECC_NIST_P256"
}

variable "deletion_window_in_days" {
  description = "Days between a key's removal from keys and its deletion, during which the deletion can be cancelled."
  type        = number
  default     = 30
}
