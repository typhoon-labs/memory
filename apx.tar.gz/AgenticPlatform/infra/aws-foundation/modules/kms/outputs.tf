output "key_arns" {
  description = "ARN of each key, keyed by label."
  value       = { for label, key in aws_kms_key.this : label => key.arn }
}

output "aliases" {
  description = "ARN of the key behind each alias that exists, keyed by alias name."
  value       = { for name, label in local.aliases : name => aws_kms_key.this[label].arn }
}

output "signing_key_arns" {
  description = "ARNs of the keys a signer may sign with: those behind the alias and <alias>-previous, since a signer may still hold the previous key for one alias refresh after a switch."
  value = [
    for label in compact([var.current, var.previous]) : aws_kms_key.this[label].arn
  ]
}

output "published_key_arns" {
  description = "ARNs of the keys a signer publishes in its JWKS: those behind all three aliases."
  value       = [for label in values(local.aliases) : aws_kms_key.this[label].arn]
}
