# Multi-factor sign-in for the platform's people (plan section 2.1: MFA is
# part of the base tier). The personas sign in with a password and a TOTP
# code, which scripts can compute, so B1's checks run without a browser.
# Only the platform's groups and the agentic-keycloak app are affected; the
# org's default policies stay as they are.

# TOTP (RFC 6238), Okta's Google Authenticator.
resource "okta_authenticator" "google_otp" {
  key    = "google_otp"
  name   = "Google Authenticator"
  status = "ACTIVE"
}

# What the platform's groups enroll: a password and TOTP, nothing else.
# Persona TOTP factors are enrolled through Okta's API by personas-totp.sh.
resource "okta_policy_mfa" "platform" {
  name            = "agentic-platform"
  description     = "The platform's groups enroll a password and TOTP only; written by aws-foundation's stacks/okta-local"
  status          = "ACTIVE"
  is_oie          = true
  priority        = 1
  groups_included = [for group in okta_group.platform : group.id]

  okta_password = { enroll = "REQUIRED" }
  google_otp    = { enroll = "REQUIRED" }
  okta_verify   = { enroll = "NOT_ALLOWED" }
  webauthn      = { enroll = "NOT_ALLOWED" }
  okta_email    = { enroll = "NOT_ALLOWED" }

  depends_on = [okta_authenticator.google_otp]
}

resource "okta_policy_rule_mfa" "platform" {
  policy_id = okta_policy_mfa.platform.id
  name      = "agentic-platform"
  status    = "ACTIVE"
  # Ask for enrollment when a required authenticator is missing.
  enroll = "CHALLENGE"
}

# The broker's sign-on policy: the platform's groups sign in with a password
# and a possession factor, which TOTP is; everyone else is refused. There is
# no password-only rule.
resource "okta_app_signon_policy" "keycloak" {
  name        = "agentic-keycloak"
  description = "Sign-on to the Keycloak broker: password and a possession factor; written by aws-foundation's stacks/okta-local"
  # The catch-all rule denies.
  catch_all = false
}

resource "okta_app_signon_policy_rule" "keycloak" {
  policy_id       = okta_app_signon_policy.keycloak.id
  name            = "platform groups: password and TOTP"
  priority        = 1
  status          = "ACTIVE"
  access          = "ALLOW"
  factor_mode     = "2FA"
  groups_included = [for group in okta_group.platform : group.id]
  # One Okta sign-in per working day: Keycloak's session lasts at most 10
  # hours (design/identity.md, "Lifetimes").
  re_authentication_frequency = "PT10H"
  constraints = [jsonencode({
    knowledge = {
      required = true
      types    = ["password"]
    }
    possession = {
      required = true
    }
  })]
}
