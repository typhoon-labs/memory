terraform {
  required_version = "1.13.9"

  required_providers {
    okta = {
      source  = "okta/okta"
      version = "7.1.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = "6.73.0"
    }
  }

  # The same bucket as stacks/local, under a key of its own, which no CI
  # role may write: only a workstation applies this stack. Locking and the
  # floci settings are as in stacks/local/versions.tf.
  backend "s3" {
    bucket       = local.state.bucket
    key          = local.state.key
    region       = local.region
    use_lockfile = true

    endpoints = {
      s3  = local.aws_endpoint
      sts = local.aws_endpoint
    }
    use_path_style = true

    skip_credentials_validation = true
    skip_region_validation      = true
    skip_requesting_account_id  = true
    skip_metadata_api_check     = true
    skip_s3_checksum            = true
  }
}
