# The Okta app of the local build (plan/local-build.md, "B1 in detail",
# step 2), in the Integrator org: the broker's OIDC web app, the
# reconciliation job's API service app, the platform's groups and the
# personas of plan section 2.1. Applied from a workstation only, never by
# CI, which holds no Okta credentials (D2); the identity team owns this
# path. At the swap the identity team creates the same apps in the company
# Okta, and only the org, the group names and the personas change.
#
# Base tier only (decision Q1): everything here uses the org authorization
# server. checks/okta-base-tier.sh refuses custom authorization servers.

locals {
  okta = {
    org_name = "integrator-4652689"
    base_url = "okta.com"
  }
  # The org authorization server's issuer, which Keycloak brokers.
  issuer = "https://${local.okta.org_name}.${local.okta.base_url}"

  aws_endpoint = "http://floci:4566"
  region       = "us-east-1"

  state = {
    bucket = "agentic-tofu-state-local"
    key    = "aws-foundation/okta-local.tfstate"
  }

  # Keycloak's broker endpoint for this IdP (plan, B1's Names table).
  broker_endpoint = "https://keycloak.agentic.internal/realms/agentic/broker/okta/endpoint"

  # The groups claim carries only the platform's groups: those whose name
  # starts with this prefix.
  group_prefix = "agentic-"

  # One group per role and one per team. These are the names that
  # environments' access/roles.yaml and access/teams.yaml map to realm
  # roles and /teams/<slug> groups; keep the two in step.
  roles = ["developer", "incident-manager", "platform-engineer"]
  teams = ["platform", "payments", "conformance", "reference"]

  groups = merge(
    { for role in local.roles : "${local.group_prefix}${role}" => "Platform role ${role}: the realm role ${role}" },
    { for team in local.teams : "${local.group_prefix}team-${team}" => "Platform team ${team}: the team claim ${team}" },
  )

  # Synthetic users for the local build's checks (plan section 2.1): the
  # leaver and the kill-switch target are deactivated by hand during B1's
  # exit measurements. The spares are the platform-controls suites' (plan,
  # "How the suites run locally"): spare-1 in the team conformance, whose
  # token limit is low, and spare-2 in no team.
  personas = {
    "developer"            = ["developer", "team-payments"]
    "incident-manager"     = ["incident-manager", "team-payments"]
    "platform-engineer"    = ["platform-engineer", "team-platform"]
    "developer-other-team" = ["developer", "team-platform"]
    "leaver"               = ["developer", "team-payments"]
    "kill-switch-target"   = ["developer", "team-payments"]
    "spare-1"              = ["developer", "team-conformance"]
    "spare-2"              = ["developer"]
  }
  persona_domain = "example.com"

  reconciler_jwk = jsondecode(file("${path.module}/keys/okta-reconciler.jwk.json"))
}

resource "okta_group" "platform" {
  for_each = local.groups

  name        = each.key
  description = each.value
}

# --- The broker's OIDC web app ----------------------------------------------

resource "okta_app_oauth" "keycloak" {
  label = "agentic-keycloak"
  type  = "web"

  grant_types    = ["authorization_code"]
  response_types = ["code"]
  redirect_uris  = [local.broker_endpoint]
  # Keycloak's broker sends people back here after an Okta logout.
  post_logout_redirect_uris = ["${local.broker_endpoint}/logout_response"]

  token_endpoint_auth_method = "client_secret_post"
  pkce_required              = true
  consent_method             = "TRUSTED"
  issuer_mode                = "ORG_URL"

  # The org authorization server puts groups in the ID token only, which is
  # what Keycloak's broker reads (plan section 2.1, F6). okta/okta 7.1.0
  # deprecates groups_claim in favour of okta_auth_server_claim, which
  # needs a custom authorization server, which Q1 refuses: this filter is
  # the base tier's only groups claim. It needs an SSWS API token, which
  # this stack uses.
  groups_claim {
    type        = "FILTER"
    filter_type = "STARTS_WITH"
    name        = "groups"
    value       = local.group_prefix
  }

  # Sign-in starts at Keycloak, never at an Okta dashboard tile.
  hide_ios = true
  hide_web = true

  # Password and TOTP for the platform's groups (mfa.tf).
  authentication_policy = okta_app_signon_policy.keycloak.id
}

# Only members of the platform's groups may sign in through the broker.
resource "okta_app_group_assignments" "keycloak" {
  app_id = okta_app_oauth.keycloak.id

  dynamic "group" {
    for_each = okta_group.platform
    content {
      id = group.value.id
    }
  }
}

# The broker's client ID and secret, which External Secrets Operator gives
# Keycloak. The secret is also in this stack's state, as the Okta provider
# keeps it there.
resource "aws_secretsmanager_secret" "okta_broker" {
  name        = "platform/keycloak/okta-broker"
  description = "The agentic-keycloak Okta app's client ID and secret, for Keycloak's okta identity provider; written by stacks/okta-local"
}

resource "aws_secretsmanager_secret_version" "okta_broker" {
  secret_id = aws_secretsmanager_secret.okta_broker.id
  secret_string = jsonencode({
    client_id     = okta_app_oauth.keycloak.client_id
    client_secret = okta_app_oauth.keycloak.client_secret
  })
}

# --- The reconciliation job's API service app --------------------------------

# Client credentials with private_key_jwt, the only method Okta allows for
# service apps. The private key is in Secrets Manager, put there by
# reconciler-key.sh; only its public key is here.
resource "okta_app_oauth" "reconciler" {
  label = "okta-reconciler"
  type  = "service"

  grant_types                = ["client_credentials"]
  response_types             = ["token"]
  token_endpoint_auth_method = "private_key_jwt"
  pkce_required              = false
  # The job sends no DPoP proof.
  dpop_bound_access_tokens = false

  jwks {
    kty = local.reconciler_jwk.kty
    kid = local.reconciler_jwk.kid
    x   = local.reconciler_jwk.x
    y   = local.reconciler_jwk.y
  }
}

# Read-only access to users and groups, granted by the org authorization
# server.
resource "okta_app_oauth_api_scope" "reconciler" {
  app_id = okta_app_oauth.reconciler.id
  issuer = local.issuer
  scopes = ["okta.users.read", "okta.groups.read"]
}

# Okta requires an admin role for every service app; this is the narrowest.
resource "okta_app_oauth_role_assignment" "reconciler" {
  client_id = okta_app_oauth.reconciler.client_id
  type      = "READ_ONLY_ADMIN"
}

# --- Personas ---------------------------------------------------------------

# Created staged, without a password: personas.sh activates them and keeps
# their passwords outside Git and state. Their status is then the checks'
# to change (the leaver, the kill switch), never this stack's.
resource "okta_user" "persona" {
  for_each = local.personas

  login      = "agentic.${each.key}@${local.persona_domain}"
  email      = "agentic.${each.key}@${local.persona_domain}"
  first_name = "Persona"
  last_name  = each.key
  status     = "STAGED"

  lifecycle {
    ignore_changes = [status]
  }
}

resource "okta_group_memberships" "platform" {
  for_each = local.groups

  group_id = okta_group.platform[each.key].id
  users = [
    for persona, groups in local.personas : okta_user.persona[persona].id
    if contains([for g in groups : "${local.group_prefix}${g}"], each.key)
  ]
}
