#!/usr/bin/env bash
# Enrolls a TOTP factor (Okta's Google Authenticator, mfa.tf) for each active
# persona, through Okta's Factors API, and activates it with a code computed
# from its secret. Run from the workstation after personas.sh; idempotent: a
# persona whose TOTP factor is active and whose secret is recorded is skipped.
#
# Secrets go to ~/.local/share/agentic-platform/okta/personas.json (mode
# 600), beside each persona's password, never to Git or OpenTofu's state. A
# factor whose secret is not recorded, or that never became active, is
# deleted and enrolled again. A persona that is not active (the leaver or
# the kill-switch target after a check) is left alone.
#
# Needs OKTA_API_TOKEN, and OKTA_DOMAIN naming the stack's org.
# Usage: stacks/okta-local/personas-totp.sh
set -euo pipefail

here="$(cd "$(dirname "$0")" && pwd)"
out="$HOME/.local/share/agentic-platform/okta/personas.json"

: "${OKTA_API_TOKEN:?OKTA_API_TOKEN is not set}"
issuer="$(tofu -chdir="$here" output -raw issuer)"
[ "https://${OKTA_DOMAIN:-}" = "$issuer" ] ||
  { echo "personas-totp: OKTA_DOMAIN (${OKTA_DOMAIN:-unset}) is not the stack's org ($issuer)" >&2; exit 1; }
[ -f "$out" ] || { echo "personas-totp: $out is missing: run personas.sh first" >&2; exit 1; }
logins="$(tofu -chdir="$here" output -json personas)"

python3 -I - "$issuer" "$out" "$logins" <<'PY'
import base64, hashlib, hmac, json, os, struct, sys, time, urllib.error, urllib.parse, urllib.request

issuer, out, logins = sys.argv[1], sys.argv[2], json.loads(sys.argv[3])
token = os.environ["OKTA_API_TOKEN"]

def call(method, path, body=None):
    req = urllib.request.Request(issuer + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "SSWS " + token, "Accept": "application/json", "Content-Type": "application/json"})
    with urllib.request.urlopen(req) as r:
        text = r.read()
        return json.loads(text) if text else {}

def totp(secret, at=None):
    # RFC 6238: HMAC-SHA1, 30-second steps, six digits.
    key = base64.b32decode(secret.upper() + "=" * (-len(secret) % 8))
    mac = hmac.new(key, struct.pack(">Q", int((at or time.time()) // 30)), hashlib.sha1).digest()
    n = struct.unpack(">I", mac[(mac[-1] & 15):(mac[-1] & 15) + 4])[0] & 0x7FFFFFFF
    return f"{n % 1000000:06d}"

store = json.load(open(out))
store = {k: ({"password": v} if isinstance(v, str) else v) for k, v in store.items()}

def save():
    fd = os.open(out + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(store, f, indent=2, sort_keys=True)
    os.replace(out + ".tmp", out)

for persona, login in sorted(logins.items()):
    user = call("GET", "/api/v1/users/" + urllib.parse.quote(login, safe=""))
    if user["status"] != "ACTIVE":
        print(f"personas-totp: {persona}: {user['status']}, left alone")
        continue
    uid, entry = user["id"], store.setdefault(login, {})
    factors = [f for f in call("GET", f"/api/v1/users/{uid}/factors")
               if f["factorType"] == "token:software:totp" and f["provider"] == "GOOGLE"]
    if any(f["status"] == "ACTIVE" for f in factors) and entry.get("totp"):
        print(f"personas-totp: {persona}: enrolled, skipped")
        continue
    for f in factors:
        call("DELETE", f"/api/v1/users/{uid}/factors/{f['id']}")
        print(f"personas-totp: {persona}: deleted a {f['status']} TOTP factor without a recorded secret")
    f = call("POST", f"/api/v1/users/{uid}/factors", {"factorType": "token:software:totp", "provider": "GOOGLE"})
    entry["totp"] = f["_embedded"]["activation"]["sharedSecret"]
    save()
    r = call("POST", f"/api/v1/users/{uid}/factors/{f['id']}/lifecycle/activate", {"passCode": totp(entry["totp"])})
    print(f"personas-totp: {persona}: TOTP enrolled, factor {r.get('status')}")
save()
os.chmod(out, 0o600)
print(f"personas-totp: secrets in {out}")
PY
