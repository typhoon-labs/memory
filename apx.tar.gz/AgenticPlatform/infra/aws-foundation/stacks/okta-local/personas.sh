#!/usr/bin/env bash
# Activates the personas this stack creates staged (main.tf), each with a
# random password, without sending email. Run from the workstation after
# applying the stack; idempotent.
#
# Passwords go to ~/.local/share/agentic-platform/okta/personas.json (mode
# 600), never to Git or OpenTofu's state, and never onto a command line.
# Each persona's entry there is an object: its password, and the TOTP
# secret personas-totp.sh adds.
# A persona that is active but missing from that file gets a new password,
# and so does a reactivated one: Okta leaves it PROVISIONED, without the
# password its deactivation removed.
# A persona in any other status (the leaver or the kill-switch target after
# a check) is left alone.
#
# Needs OKTA_API_TOKEN, and OKTA_DOMAIN naming the stack's org. It reads
# the stack's outputs from its OpenTofu state in floci's S3, with floci's
# static credentials unless the caller sets others.
# Usage: stacks/okta-local/personas.sh
set -euo pipefail

here="$(cd "$(dirname "$0")" && pwd)"
out_dir="$HOME/.local/share/agentic-platform/okta"
out="$out_dir/personas.json"

: "${OKTA_API_TOKEN:?OKTA_API_TOKEN is not set}"
export AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-test}" AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-test}"
export AWS_REGION="${AWS_REGION:-us-east-1}"
issuer="$(tofu -chdir="$here" output -raw issuer)"
[ "https://${OKTA_DOMAIN:-}" = "$issuer" ] ||
  { echo "personas: OKTA_DOMAIN (${OKTA_DOMAIN:-unset}) is not the stack's org ($issuer)" >&2; exit 1; }

(umask 077 && mkdir -p "$out_dir")
chmod 700 "$out_dir"
logins="$(tofu -chdir="$here" output -json personas)"

python3 -I - "$issuer" "$out" "$logins" <<'PY'
import json, os, secrets, string, sys, urllib.parse, urllib.request

issuer, out, logins = sys.argv[1], sys.argv[2], json.loads(sys.argv[3])
token = os.environ["OKTA_API_TOKEN"]

def call(method, path, body=None):
    req = urllib.request.Request(issuer + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Authorization": "SSWS " + token, "Accept": "application/json",
                 "Content-Type": "application/json"})
    with urllib.request.urlopen(req) as r:
        text = r.read()
        return json.loads(text) if text else {}

def new_password():
    # Okta's default policy: upper, lower, digit; no part of the login.
    alphabet = string.ascii_letters + string.digits
    core = "".join(secrets.choice(alphabet) for _ in range(28))
    return "Pw" + core + "9!"

store = json.load(open(out)) if os.path.exists(out) else {}
# An entry was once the password alone.
store = {k: ({"password": v} if isinstance(v, str) else v) for k, v in store.items()}

def save():
    fd = os.open(out + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(store, f, indent=2, sort_keys=True)
    os.replace(out + ".tmp", out)

for persona, login in sorted(logins.items()):
    user = call("GET", "/api/v1/users/" + urllib.parse.quote(login, safe=""))
    status, uid = user["status"], user["id"]
    if status in ("STAGED", "PROVISIONED") or (status == "ACTIVE" and "password" not in store.get(login, {})):
        password = new_password()
        call("POST", f"/api/v1/users/{uid}", {"credentials": {"password": {"value": password}}})
        store[login] = {**store.get(login, {}), "password": password}
        save()
        if status == "STAGED":
            call("POST", f"/api/v1/users/{uid}/lifecycle/activate?sendEmail=false")
        status = call("GET", f"/api/v1/users/{uid}")["status"]
        print(f"personas: {persona}: password set, status {status}")
    else:
        print(f"personas: {persona}: {status}, left alone")
save()
os.chmod(out, 0o600)
print(f"personas: passwords in {out}")
PY
