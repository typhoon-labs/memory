# This file is maintained automatically by "tofu init".
# Manual edits may be lost in future updates.

provider "registry.opentofu.org/hashicorp/aws" {
  version     = "6.73.0"
  constraints = "6.73.0"
  hashes = [
    "h1:1zQPP8XHNYS2m7MnhPd19nR6xjWk3p/e08X+B7GGx7I=",
    "h1:IdAE6YFUBZvlLDzcKe+khHpceC+cZMJy8DOsuFV1iLs=",
    "h1:KLd1R0RCfFNyhJ8fBLI7KuCI8VvV8fMZh2+Bt4/5UEk=",
    "h1:NE8f7fV/bAVTxhVOuQSIRcG0/NTNMrrrZTFJ863U3v8=",
    "h1:PLSysFV+jYgBuI42kYv4AMGMDusaKj6o4MfKz7+AD2w=",
    "h1:PirCmCZao9jd4snXgOlO+OrG4HtPKQVyiu37vmoM6Y8=",
    "h1:ZDDEyufl0zfy5gWdRkfFrDj/K7Dt9oym+FTrKTyzPmY=",
    "h1:cqILWB/Kxr0AYCi+pJj9A8d5KzsXEOrKxbFHh3VfKsQ=",
    "h1:iUIwaluxZuApYxl8C5Xpwo5mb/9OkEMn6tAzLKVTxag=",
    "h1:jjsA3nBL/NmNYeG0bmVhHv1ruFBH2ucdkW9VH1iE5Tw=",
    "h1:mKUNC7il3hHVi93ZyWogDKWTCwuhorndZf629rHqElQ=",
    "h1:miKdeCwqPUV/IPN+HCS0ZZquE4ENjb18UhOO612M+AY=",
    "h1:mrSvOTfc0Uwurvpyj9uEhbGLUqUWA1p3VAAK+qA8OXs=",
    "h1:pOp3kyT/dPNiMXzc7CtQqFrPhIFR7gqtgX5iepQJczs=",
    "h1:q5MABxUl6HoEzLYB21WOLdH+EZzioo0n9/8pkKYweF0=",
    "zh:01a4a08962eb85b35c9912e715df1a5124e5064cd60792b37c82ebe8898489b8",
    "zh:3efa54bad2af67c07547f6682bfe2b419c9f018c63008dc7d8a1e4691fd35569",
    "zh:432944bc45558e48a526e522b559dc74b70dc37cfe460420ed48527d36563531",
    "zh:6e06ddd0fa7f5c9b88c428abb18ae8d8ee9749a773ca52b2ee5010d8ce697eca",
    "zh:7efbfba3b2daed43b0ee0322b62cfd0c9102b2320cac74878e950b5d02ffc979",
    "zh:8866298c36a45b7867415119289a8f680f32d54f5553f738880ffcc0561c6907",
    "zh:9dcde5077f648b6231eef6de019a5dd89ba7ec393767be4f6cbde7e420a5a874",
    "zh:9fd52591011b1066036a47a4e677cad00d63956579a200cb57c9228f1dfb4a1a",
    "zh:a61f8e114e5233e63b8d2b034b1ad59a220e532fa34aaaa63eec6bad73a0ca21",
    "zh:ba50cb9245a579285169565995e20bebb410e7f4d4181dc7de1205877fe04728",
    "zh:c2eb24eedab492b3e42f78632b0dd6a8d23f3021b080fee2137e91765629a9e1",
    "zh:cac7953f04c637c303f212b87e96089950bb95856ffbeb2719c5138299a64787",
    "zh:d7929af6ee61fb8c7d6ec5d3a0ff9cf8554f01d0b470b3787d7e7882e6df3946",
    "zh:d7f889bcdbf6b5889ca2252ce517241a2723e61927b2826683d01b648ea91f9a",
    "zh:ff4c4ca563e044561e3c3836f51b24dca034879574ca7e334b27a49b25d1df51",
  ]
}

provider "registry.opentofu.org/okta/okta" {
  version     = "7.1.0"
  constraints = "7.1.0"
  hashes = [
    "h1:/JJITfLEEPK6H4UsZvSob06qlCLomaQwYFdPbt6eMdk=",
    "h1:13/X4g94zgt7EN8E5u7nuTIgfeeuzmOLvALoNYdsfso=",
    "h1:3IS4iZe7zeQM3qamFTbc4dIILuY9pe6b7C8KWCaB3k0=",
    "h1:4DLNvCGZxy+qVJrUZUgJzbXFlbiy85wCEap0P4ObEo0=",
    "h1:6bFz92+0/82f94wm7DzynFdsq4c4Oib3wo+1lfpHDHA=",
    "h1:8H/bbuqTWsLysoRU0EZ0Cbko0Pr9aCAqrWa16BocDxU=",
    "h1:CykZe4jsKgpIJhEWqadOj3Va4+yu3SvDhkYTzEyHYGY=",
    "h1:LIRVL1Ex38No1GfneK02+dKkDrjjy4XrHFxXVsREntQ=",
    "h1:NBYVVrNxu+6daEUPd2JpHVEESHPM1Lu48PIiL2BdKAk=",
    "h1:PSIQmF0HOpQ03VKYHKmWXguG51ebVLoTfnUbu9UdtIY=",
    "h1:WAuamV8mA2aIWXsuOlygZ2WB0zSkY4lL9FEZbJyHRE0=",
    "h1:YY7nGfe82Awe6H6F77dih2jkeN8/Li5JN6fHIIn26ME=",
    "h1:q33Go8lwktTpuDjoLEsJQbt1f8HxwUadU+m3HJ+vjKk=",
    "zh:018afd28bf7e96f6f01b6c74691943aacaad71b063a35da2a499b32b018f7856",
    "zh:05a57d35e02bee24ade5dea5e10bd91f59bdca9ba1a95faa2735a8aaf82fb007",
    "zh:0b2a3996a3066a9491dac7ef2aabe0202071b41f44a0e8ca1cece4a6d0f93c9f",
    "zh:3bf71717a25760ed470bd4fd40c925e23f591246c749947f282b8ad8062dd670",
    "zh:4b5ff8b3f897485ff9b69a3c00e30cde955f373f672d5fa6bccd0e85f6a34436",
    "zh:6bac7541281d6dcfe75e3550cae07c0b6cfef72279576412b962955ff0b336f9",
    "zh:6de60e9100eceeaa2ec1a08ac27e867613712f3371001761a40d05e4e58216af",
    "zh:8672138c61fe7fef59ff4fa3ec696766b1ab41b057e64061fcd3bef6fdf77a2d",
    "zh:9157093c9275131a87c3d30927db7b7137f67dba85d5c2491124ea21bb3db59b",
    "zh:b969c918e1cf610392430aab87e5572b36030ea230cd1627dc24ee973e62ebbb",
    "zh:d92512519a7e9aba7cc7c7556aea8f81a4d03a94ff35a3ee78c17aa023f3bd65",
    "zh:eb376f93555945d7ad86cd5ae6bcd37292c8f85961a787537b93052975fa5e21",
    "zh:f195fcb6c9b09feaa00f98dd6891198f6c5ec1fb576d8477f881c5311e5bd2d0",
  ]
}
