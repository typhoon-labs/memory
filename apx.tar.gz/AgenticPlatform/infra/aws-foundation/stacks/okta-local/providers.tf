# The Okta Integrator org of the local build. The provider reads its API
# token from OKTA_API_TOKEN; the org is named here, never taken from the
# shell, so this stack cannot be applied to another org by mistake.
provider "okta" {
  org_name = local.okta.org_name
  base_url = local.okta.base_url
}

# floci, for the broker app's entry in Secrets Manager. On the workstation
# the credentials are floci's static test credentials.
provider "aws" {
  region = local.region

  endpoints {
    secretsmanager = local.aws_endpoint
    sts            = local.aws_endpoint
  }

  default_tags {
    tags = {
      managed-by = "opentofu"
      repository = "infra/aws-foundation"
      stack      = "okta-local"
    }
  }
}
