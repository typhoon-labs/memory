output "issuer" {
  description = "The org authorization server's issuer, which Keycloak's okta identity provider names."
  value       = local.issuer
}

output "broker_client_id" {
  description = "Client ID of the agentic-keycloak app; with its secret in platform/keycloak/okta-broker."
  value       = okta_app_oauth.keycloak.client_id
}

output "reconciler_client_id" {
  description = "Client ID of the okta-reconciler service app."
  value       = okta_app_oauth.reconciler.client_id
}

output "groups" {
  description = "ID of each platform group, keyed by name."
  value       = { for name, group in okta_group.platform : name => group.id }
}

output "personas" {
  description = "Login of each persona, keyed by persona."
  value       = { for persona, user in okta_user.persona : persona => user.login }
}
