#!/usr/bin/env bash
# The okta-reconciler app's key pair (design/identity.md, "The
# reconciliation job"). Run from the workstation before applying this
# stack; idempotent.
#
# Where the Secrets Manager entry platform/delegation-sts/okta-reconciler-key
# is missing, it generates an EC P-256 key pair, stores the private key
# there with the AWS CLI, and writes the public key, as a JWK whose kid is
# its RFC 7638 thumbprint, to keys/okta-reconciler.jwk.json, which the stack
# reads and Git keeps. The private key never enters Git or OpenTofu's
# state, and is on disk only in a private temporary directory, removed on
# exit. Where the entry exists, it checks that the entry's kid tag matches
# the file.
#
# Usage: stacks/okta-local/reconciler-key.sh
set -euo pipefail

here="$(cd "$(dirname "$0")" && pwd)"
jwk_file="$here/keys/okta-reconciler.jwk.json"
secret=platform/delegation-sts/okta-reconciler-key
aws=(env AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test AWS_REGION=us-east-1
  aws --endpoint-url http://floci:4566)

die() { printf 'reconciler-key: %s\n' "$*" >&2; exit 1; }

# The entry's kid tag names its key, so this check never reads the key.
if kid="$("${aws[@]}" secretsmanager describe-secret --secret-id "$secret" \
  --query "Tags[?Key=='kid'].Value | [0]" --output text 2>/dev/null)"; then
  [ -n "$kid" ] && [ "$kid" != None ] || die "$secret has no kid tag"
  [ -f "$jwk_file" ] || die "$secret exists but $jwk_file is missing: restore it from Git, or delete the entry to make a new key"
  have="$(python3 -I -c 'import json, sys; print(json.load(open(sys.argv[1]))["kid"])' "$jwk_file")"
  [ "$have" = "$kid" ] || die "$secret holds key $kid but $jwk_file names $have"
  echo "reconciler-key: $secret and $jwk_file agree on kid $kid"
  exit 0
fi

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
chmod 700 "$tmp"
(umask 077 && openssl genpkey -algorithm EC -pkeyopt ec_paramgen_curve:P-256 -out "$tmp/key.pem")
openssl pkey -in "$tmp/key.pem" -pubout -outform DER -out "$tmp/pub.der"

# The JWK, its thumbprint, and the entry's JSON, from the public key's DER
# (SubjectPublicKeyInfo ends with the uncompressed point 04 || x || y).
python3 -I - "$tmp/pub.der" "$tmp/key.pem" "$tmp/jwk.json" "$tmp/secret.json" <<'PY'
import base64, hashlib, json, sys
der, pem, jwk_out, secret_out = sys.argv[1:5]
point = open(der, "rb").read()[-65:]
assert point[0] == 4, "not an uncompressed P-256 point"
b64 = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
jwk = {"crv": "P-256", "kty": "EC", "x": b64(point[1:33]), "y": b64(point[33:])}
kid = b64(hashlib.sha256(json.dumps(jwk, separators=(",", ":"), sort_keys=True).encode()).digest())
json.dump({"kid": kid, "alg": "ES256", "use": "sig", **jwk}, open(jwk_out, "w"), indent=2, sort_keys=True)
open(jwk_out, "a").write("\n")
json.dump({"kid": kid, "alg": "ES256", "private_key": open(pem).read()}, open(secret_out, "w"))
PY

"${aws[@]}" secretsmanager create-secret --name "$secret" \
  --description "Private key of the okta-reconciler Okta app (private_key_jwt); created by stacks/okta-local/reconciler-key.sh" \
  --secret-string "file://$tmp/secret.json" \
  --tags "Key=kid,Value=$(python3 -I -c 'import json, sys; print(json.load(open(sys.argv[1]))["kid"])' "$tmp/jwk.json")" >/dev/null
mkdir -p "$(dirname "$jwk_file")"
cp "$tmp/jwk.json" "$jwk_file"
echo "reconciler-key: stored a new key in $secret; its public key is in $jwk_file: commit it"
