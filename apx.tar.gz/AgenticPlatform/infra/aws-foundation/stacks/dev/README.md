# stacks/dev

The dev stack is not written yet. It lands at the swap to dev, after the local build's exit ([local build plan](../../../../architecture/plan/local-build.md#6-phased-local-build)), because the values it needs do not exist before then: the dev account and its region, dev's state bucket, and the project IDs of the real GitLab group.

What it will hold:

- The same module calls as [`stacks/local`](../local/main.tf), with no `endpoints` block in the provider.
- The same S3 backend with `use_lockfile`, against dev's state bucket, without the `endpoints`, `use_path_style` and `skip_*` settings.
- A registrations file of its own, `registrations/dev.yaml`, with the real group's project IDs. Sandbox project IDs are never trusted in dev ([Repositories](../../../../architecture/design/repositories.md#ci-identity-to-aws)).
- A `ci.env` naming dev's `ci-aws-foundation` role and no endpoint; the real group's pipeline sets `STACK` to `dev`.
- The modules floci cannot host, such as VPC, EKS and Karpenter, applied only here ([local build plan](../../../../architecture/plan/local-build.md#5-designing-for-the-swap)).

Its first check is the exit to dev's: every module that ran on floci also plans cleanly against the dev account.
