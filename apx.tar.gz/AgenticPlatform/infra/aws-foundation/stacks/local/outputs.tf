output "ci_role_arns" {
  description = "ARN of each CI role, keyed by role name: the role each pipeline assumes."
  value       = module.iam.role_arns
}

output "workload_role_arns" {
  description = "ARN of each workload role, keyed by role name."
  value       = module.iam.workload_role_arns
}

output "gitlab_oidc_provider_arn" {
  description = "ARN of GitLab's OIDC provider."
  value       = module.iam.oidc_provider_arn
}

output "ecr_repositories" {
  description = "ARN and URL of each ECR repository, the contract stage's scratch repositories among them, keyed by repository name. On floci the URL is localhost:4566/..., which pods cannot reach: never pass it to a chart. Images are pulled as floci:4566/000000000000/us-east-1/<repo>@sha256:..., with registry.host set in environments."
  value       = merge(module.ecr.repositories, module.ecr_scratch.repositories)
}

output "sts_signing" {
  description = "The STS's signing key: the ARN of each key by label, and of the key behind each alias that exists."
  value = {
    key_arns = module.sts_signing.key_arns
    aliases  = module.sts_signing.aliases
  }
}

output "release_signing" {
  description = "B5's release key: the ARN of each key by label, and of the key behind each alias that exists."
  value = {
    key_arns = module.release_signing.key_arns
    aliases  = module.release_signing.aliases
  }
}

output "platform_signing" {
  description = "B6's platform image key: the ARN of each key by label, and of the key behind each alias that exists."
  value = {
    key_arns = module.platform_signing.key_arns
    aliases  = module.platform_signing.aliases
  }
}

output "conformance_signing" {
  description = "B6's conformance key: the ARN of each key by label, and of the key behind each alias that exists."
  value = {
    key_arns = module.conformance_signing.key_arns
    aliases  = module.conformance_signing.aliases
  }
}

output "record_signing" {
  description = "B6's record key (D37), for the catalog index and the release records: the ARN of each key by label, and of the key behind each alias that exists."
  value = {
    key_arns = module.record_signing.key_arns
    aliases  = module.record_signing.aliases
  }
}

output "keycloak_db" {
  description = "Keycloak's database: its endpoint, the entry that holds the endpoint and user name, and the RDS-managed secret that holds the password."
  value = {
    address                = module.keycloak_db.address
    port                   = module.keycloak_db.port
    connection_secret_arn  = module.keycloak_db.connection_secret_arn
    master_user_secret_arn = module.keycloak_db.master_user_secret_arn
  }
}

output "ssm_parameters" {
  description = "Full name of each SSM parameter environments reads, keyed by its name under /platform/."
  value       = module.parameters.names
}

output "buckets" {
  description = "B3's, B4's, B5's and B6's buckets, keyed by purpose: each one's name and ARN, and its key's ARN and alias."
  value = {
    cnpg-backups     = module.cnpg_backups_bucket
    langfuse-events  = module.langfuse_events_bucket
    langfuse-media   = module.langfuse_media_bucket
    audit            = module.audit_bucket
    kagent-snapshots = module.kagent_snapshots_bucket
    sandbox-assets   = module.sandbox_assets_bucket
    artifacts        = module.artifacts_bucket
    release-records  = module.release_records_bucket
    catalog-index    = module.catalog_index_bucket
  }
}
