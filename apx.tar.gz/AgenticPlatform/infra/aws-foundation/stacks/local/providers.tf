# No credentials here. On the workstation the bootstrap exports floci's
# static test credentials; CI jobs assume ci-aws-foundation with their
# GitLab ID token (.gitlab-ci.yml).
provider "aws" {
  region = local.region

  # floci serves every AWS API on one endpoint, and S3 by path only
  # (plan/local-build.md, section 2.3). These are the only differences from
  # dev's provider, which leaves both out.
  s3_use_path_style = true

  # S3 buckets' tags are read through S3 Control, which dials the account
  # ID before the host: 000000000000.floci, an alias floci has for this
  # alone (environments' clusters/local/00-local/floci). Without s3control
  # here, those requests went to AWS itself.
  endpoints {
    ecr            = local.aws_endpoint
    iam            = local.aws_endpoint
    kms            = local.aws_endpoint
    rds            = local.aws_endpoint
    s3             = local.aws_endpoint
    s3control      = local.aws_endpoint
    secretsmanager = local.aws_endpoint
    ssm            = local.aws_endpoint
    sts            = local.aws_endpoint
  }

  default_tags {
    tags = {
      managed-by = "opentofu"
      repository = "infra/aws-foundation"
      stack      = "local"
    }
  }
}
