# The local stack, applied to floci. Each AWS resource is created in the
# build phase that first needs it: B0 holds GitLab's OIDC provider, the two
# CI roles and one ECR repository for the exit check's image; B1 adds what
# Keycloak and the delegation STS need; B2 what the gateway and the
# platform-controls suites need; B3 the buckets of telemetry and data; B4
# kagent's snapshot bucket and the sandbox assets' bucket; B5 the release
# key, the bounded steps' bucket, the build pipelines' roles and the
# workload charts' repositories; B6 the platform image, conformance and
# record keys, the buckets of release records and the catalog index, and
# the global library's and the admission fixtures' repositories. The
# state bucket is not here: the bootstrap creates it with the AWS CLI.

locals {
  # floci's container name. The workstation's /etc/hosts maps it to
  # 127.0.0.1, and CI jobs resolve it on the kind Docker network.
  aws_endpoint = "http://floci:4566"
  region       = "us-east-1"

  state = {
    bucket = "agentic-tofu-state-local"
    key    = "aws-foundation/local.tfstate"
  }

  # Where the stack publishes what environments reads; ci-environments may
  # read it.
  ssm_parameter_path = "/platform/"

  # Names that both the resources and ci-aws-foundation's policy use, which
  # names them before they exist.
  kms_alias_prefix = "alias/platform/"
  keycloak_db = {
    identifier        = "keycloak"
    connection_secret = "platform/keycloak/db"
  }

  # B2: the images devkit/ci-components builds and its pipeline pushes: the
  # fake model server, the platform-controls suites' fixtures (one image for
  # capture-mcp, relay-agent and outsider-agent) and the conformance runner
  # (plan/local-build.md, "B2 in detail").
  ci_components_images = [
    "platform/fake-model",
    "platform/conformance-fixtures",
    "platform/conformance-runner",
    # B6: the admission rule's long-lived fixtures, one image in each
    # state the bypass cases need (unsigned, signed only, another key's,
    # a conformance attestation by the release key, below its level,
    # full), published by ci-components' main. No lifecycle policy, so
    # the lifecycle applier never touches it.
    "platform/conformance-admission-fixtures",
    # B6 (D27): the bounded step's image, which reference-workflow's step
    # job runs (AGENTIC_STEP_IMAGE), built on ci-components' main and
    # signed with the platform image key.
    "platform/step",
  ]

  # B1: the images infra/delegation-sts builds: the STS's and its interop
  # suite's, which share platform/delegation-sts with the chart, and the
  # Okta reconciliation job's. From B6 its own pipeline pushes them and
  # signs them with the platform image key (D36).
  delegation_sts_images = [
    "platform/delegation-sts",
    "platform/okta-reconciler",
  ]

  # B5: the charts devkit/workload-charts releases, each in a repository
  # of its own, pushed by version (plan/local-build.md, "B5 in detail").
  workload_charts = [
    "platform/app-base",
    "platform/agent-integration",
  ]

  # B5: one repository per registered workload, which ci-workload-release
  # pushes to; each workload's registration merge request adds its own
  # (D4).
  workload_images = [
    "workloads/reference/reference-agent",
    "workloads/reference/reference-mcp",
    "workloads/reference/reference-notes-agent",
  ]

  # B6 (D41): the global library's artifacts, one repository each,
  # library/<kind>/<name>, which ci-library-release pushes to by a
  # <kind>/<name>/vX.Y.Z tag of a registered library project. Each new
  # artifact adds its own (plan/local-build.md, "B6 in detail", step 3).
  library_artifacts = [
    "library/skill/platform-conventions",
    "library/prompt/summarise-changes",
  ]

  # B5, local only: the projects whose merge request pipelines run the
  # contract stage, each with a scratch repository
  # ci-scratch/<path under the group root, slashes as hyphens>. The stage
  # copies the merge request's image there from the project's GitLab
  # registry and starts it as a service from floci, since this sandbox's
  # Docker daemon pulls registry.gitlab.com through the sandbox's proxy,
  # which refuses it. In dev the stage starts the image from the GitLab
  # registry and no merge request pipeline writes to ECR. Each workload's
  # registration merge request adds its project here (D4).
  scratch_projects = [
    "devkit/ci-components",
    "workloads/reference/reference-agent",
    "workloads/reference/reference-mcp",
    # B6: infra/conformance runs the contract stage itself, on the image
    # under test, from its protected main (D38).
    "infra/conformance",
  ]

  # B3's buckets (plan/local-build.md, "B3 in detail", Buckets), B4's, B5's
  # and B6's (their Names tables), named agentic-<purpose>-<environment>, each
  # with its own key behind alias/platform/s3-<purpose>. Named here, not
  # read from the bucket modules, so that ci-aws-foundation's policy is
  # known at plan time.
  buckets = {
    for purpose in [
      "cnpg-backups", "langfuse-events", "langfuse-media", "audit",
      "kagent-snapshots", "sandbox-assets", "artifacts",
      "release-records", "catalog-index",
    ] :
    purpose => "agentic-${purpose}-local"
  }

  registrations = {
    for role, projects in yamldecode(file("${path.module}/../../registrations/local.yaml")) :
    role => [for project in projects : tostring(project.id)]
  }
}

# Locally every repository's tags are mutable: floci's registry has no OCI
# referrers API, so cosign keeps its signature and attestations in a
# fallback index tagged sha256-<hex>, which it rewrites on each sign and
# attest, and an immutable repository refuses every write after the first
# (the B5 spike). Deploys pin digests, so a moved tag never changes what
# runs. Dev keeps IMMUTABLE, where ECR answers the referrers API.
module "ecr" {
  source = "../../modules/ecr"

  image_tag_mutability = "MUTABLE"
  repositories = concat([
    # The image a pod pulls by digest in B0's exit check.
    "platform/pull-check",
  ], local.delegation_sts_images, local.ci_components_images, local.workload_charts, local.workload_images, local.library_artifacts)
}

# B5: the contract stage's scratch repositories (local.scratch_projects),
# mutable, every image expiring a day after its push. floci 2.4.0 stores
# a lifecycle policy and never applies it, so locally nothing expires.
module "ecr_scratch" {
  source = "../../modules/ecr"

  image_tag_mutability = "MUTABLE"
  expire_after_days    = 1
  repositories = [
    for path in local.scratch_projects : "ci-scratch/${replace(path, "/", "-")}"
  ]
}

# The delegation STS signs ES256 with this key (design/identity.md,
# "Signing keys and JWKS"). Keys are labelled by the month they were made.
module "sts_signing" {
  source = "../../modules/kms"

  alias       = "${local.kms_alias_prefix}sts-signing"
  description = "Delegation STS token signing (ES256)"
  keys        = ["2026-11"]
  current     = "2026-11"
}

# B5: the release key. cosign signs and attests images, charts and
# agentctl's binaries with it, never keyless (design/distribution.md, "The
# distribution design"). ECC_NIST_P256 offers one signing algorithm,
# ECDSA_SHA_256, so cosign's KMS signer has one to choose
# (plan/local-build.md, "B5 in detail").
module "release_signing" {
  source = "../../modules/kms"

  alias       = "${local.kms_alias_prefix}release-signing"
  description = "Release signing: cosign signatures and attestations (ECDSA P-256)"
  keys        = ["2026-11"]
  current     = "2026-11"
  key_spec    = "ECC_NIST_P256"
}

# B6: the platform image key. The platform's own images (the fake model,
# the suites' runner and fixtures, the STS's) are signed with it, and
# admission verifies the platform namespaces' images with it; only
# ci-ci-components and ci-delegation-sts, each for the images its own
# pipeline builds, may sign with it, never a workload's role, by D37's
# reasoning: the release key is every workload's, so a platform image
# signed with it could come from any workload's pipeline.
module "platform_signing" {
  source = "../../modules/kms"

  alias       = "${local.kms_alias_prefix}platform-signing"
  description = "The platform's own images, signed by its build pipelines alone (ECDSA P-256)"
  keys        = ["2026-11"]
  current     = "2026-11"
  key_spec    = "ECC_NIST_P256"
}

# B6: the conformance key. infra/conformance alone signs the conformance
# attestation with it, after running the integration stage on the digest,
# so an attestation always means the suites ran (design/conformance.md,
# TM13). No workload's role may use it. P-256, as the release key, so
# cosign's KMS signer has one algorithm.
module "conformance_signing" {
  source = "../../modules/kms"

  alias       = "${local.kms_alias_prefix}conformance-signing"
  description = "Conformance attestations, signed by infra/conformance alone (ECDSA P-256)"
  keys        = ["2026-11"]
  current     = "2026-11"
  key_spec    = "ECC_NIST_P256"
}

# B6 (D37): the platform's record key. It signs the catalog index and the
# release records, and only the catalog pipeline's role and environments'
# deploy job may use it, never a workload's release role, so a record or
# an index signed with it cannot come from a workload's pipeline.
module "record_signing" {
  source = "../../modules/kms"

  alias       = "${local.kms_alias_prefix}record-signing"
  description = "The catalog index and release records, signed by the platform alone (ECDSA P-256)"
  keys        = ["2026-11"]
  current     = "2026-11"
  key_spec    = "ECC_NIST_P256"
}

# Keycloak's database (plan/local-build.md, "B1 in detail"). RDS keeps the
# master password in its own secret; platform/keycloak/db holds the rest.
# On floci the instance is a postgres container behind floci's proxy, with
# no snapshots worth keeping, so it may be deleted without one.
module "keycloak_db" {
  source = "../../modules/rds"

  identifier             = local.keycloak_db.identifier
  engine_version         = "18"
  instance_class         = "db.t4g.micro"
  db_name                = "keycloak"
  username               = "keycloak"
  connection_secret_name = local.keycloak_db.connection_secret

  backup_retention_period = 1
  deletion_protection     = false
  skip_final_snapshot     = true
}

# B3: CloudNativePG's backups, through the Barman Cloud plugin. The
# plugin's retention policy deletes obsolete backups, so no Object Lock;
# versioning keeps a deleted or overwritten object for a week.
module "cnpg_backups_bucket" {
  source = "../../modules/bucket"

  name        = local.buckets["cnpg-backups"]
  description = "CloudNativePG's base backups and WAL"
  kms_alias   = "${local.kms_alias_prefix}s3-cnpg-backups"
  versioning  = true
  lifecycle_rules = {
    noncurrent_expiration_days      = 7
    abort_incomplete_multipart_days = 1
  }
}

# B3: Langfuse's raw events and media. Unversioned, since Langfuse would
# leave delete markers; objects expire after the retention, a day locally,
# the smallest unit of a lifecycle rule (30 days in dev, 90 in prod).
module "langfuse_events_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["langfuse-events"]
  description     = "Langfuse's raw events"
  kms_alias       = "${local.kms_alias_prefix}s3-langfuse-events"
  lifecycle_rules = { expiration_days = 1 }
}

module "langfuse_media_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["langfuse-media"]
  description     = "Langfuse's media, which browsers reach through presigned URLs"
  kms_alias       = "${local.kms_alias_prefix}s3-langfuse-media"
  lifecycle_rules = { expiration_days = 1 }
}

# B3: the audit archive, under Object Lock in COMPLIANCE mode, so no one
# deletes a version before its retention ends: a day locally, the security
# policy's period in dev (a year or more). Noncurrent versions expire
# after the same period.
module "audit_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["audit"]
  description     = "The platform's audit records"
  kms_alias       = "${local.kms_alias_prefix}s3-audit"
  versioning      = true
  lifecycle_rules = { noncurrent_expiration_days = 1 }
  object_lock = {
    mode = "COMPLIANCE"
    days = 1
  }
}

# B4: kagent's session snapshots, which Substrate writes when an idle
# session's actor suspends. No expiry of current objects: Substrate deletes
# the snapshots it releases, and golden snapshots live as long as their
# template (design/runtime.md, "Sizing the sandbox NodePool"). Unversioned,
# so a released snapshot is gone; incomplete uploads are aborted after a
# day.
module "kagent_snapshots_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["kagent-snapshots"]
  description     = "kagent's session snapshots, written by Agent Substrate"
  kms_alias       = "${local.kms_alias_prefix}s3-kagent-snapshots"
  lifecycle_rules = { abort_incomplete_multipart_days = 1 }
}

# B4: gVisor's release tarballs, mirrored by the environments bootstrap
# from the public bucket once, after checking each against the SHA-256
# Substrate pins, and read by atelet through Substrate's S3 plugin
# (plan/local-build.md, "B4 in detail", gVisor's assets). An old release
# stays while snapshots taken on it remain, so nothing expires.
module "sandbox_assets_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["sandbox-assets"]
  description     = "Agent Substrate's sandbox assets: gVisor's release tarballs"
  kms_alias       = "${local.kms_alias_prefix}s3-sandbox-assets"
  lifecycle_rules = { abort_incomplete_multipart_days = 1 }
}

# B5: the outputs of bounded model steps (design/workflows.md, "A bounded
# model step"). Unversioned; no retention is decided yet, so nothing
# expires but incomplete uploads, after a day.
module "artifacts_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["artifacts"]
  description     = "Bounded model steps' outputs"
  kms_alias       = "${local.kms_alias_prefix}s3-artifacts"
  lifecycle_rules = { abort_incomplete_multipart_days = 1 }
}

# B6 (D37): the release records, one in-toto statement per workload
# release environments' deploy job applies, signed with the record key.
# Under Object Lock in COMPLIANCE mode, as the audit archive: a day
# locally, the security policy's period in dev. A record is never
# overwritten, so noncurrent versions are rare; they expire after the
# same period.
module "release_records_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["release-records"]
  description     = "The release records environments' deploy job writes"
  kms_alias       = "${local.kms_alias_prefix}s3-release-records"
  versioning      = true
  lifecycle_rules = { noncurrent_expiration_days = 1 }
  object_lock = {
    mode = "COMPLIANCE"
    days = 1
  }
}

# B6 (D37, D41): the signed catalog index, catalog.json, its bundle and
# its static pages, which the catalog's scheduled pipeline writes and
# Agentregistry's publisher reads. Each build writes a new version, which
# Object Lock keeps for a day locally; a replaced version expires a day
# after.
module "catalog_index_bucket" {
  source = "../../modules/bucket"

  name            = local.buckets["catalog-index"]
  description     = "The signed catalog index the catalog pipeline builds"
  kms_alias       = "${local.kms_alias_prefix}s3-catalog-index"
  versioning      = true
  lifecycle_rules = { noncurrent_expiration_days = 1 }
  object_lock = {
    mode = "COMPLIANCE"
    days = 1
  }
}

module "iam" {
  source = "../../modules/iam"

  gitlab_url = "https://gitlab.com"
  # Must equal id_tokens.aud in .gitlab-ci.yml.
  gitlab_audience = "sts.amazonaws.com"
  registrations   = local.registrations

  state                    = local.state
  ecr_pull_repository_arns = [for repo in values(module.ecr.repositories) : repo.arn]
  ci_components_push_repository_arns = [
    for name in local.ci_components_images : module.ecr.repositories[name].arn
  ]
  delegation_sts_push_repository_arns = [
    for name in local.delegation_sts_images : module.ecr.repositories[name].arn
  ]
  workload_charts_push_repository_arns = [
    for name in local.workload_charts : module.ecr.repositories[name].arn
  ]
  workload_release_push_repository_arns = [
    for name in local.workload_images : module.ecr.repositories[name].arn
  ]
  release_signing_key_arns = module.release_signing.signing_key_arns
  ssm_parameter_path       = local.ssm_parameter_path

  # B6: the conformance key for ci-conformance alone; the record key for
  # ci-catalog and the deploy job's ci-environments-deploy alone (D37),
  # the deploy job known by the environment it declares; the library's
  # repositories; the records and index buckets.
  deploy_environment           = "local"
  platform_signing_key_arns    = module.platform_signing.signing_key_arns
  conformance_signing_key_arns = module.conformance_signing.signing_key_arns
  conformance_scratch_repository_arns = [
    module.ecr_scratch.repositories["ci-scratch/infra-conformance"].arn
  ]
  library_pull_repository_arns = [
    for name in local.library_artifacts : module.ecr.repositories[name].arn
  ]
  record_signing_key_arns = module.record_signing.signing_key_arns
  library_release_push_repository_arns = [
    for name in local.library_artifacts : module.ecr.repositories[name].arn
  ]
  release_records_bucket = {
    name        = module.release_records_bucket.name
    kms_key_arn = module.release_records_bucket.kms_key_arn
  }
  catalog_index_bucket = {
    name        = module.catalog_index_bucket.name
    kms_key_arn = module.catalog_index_bucket.kms_key_arn
  }

  managed = {
    db_instances     = [local.keycloak_db.identifier]
    secrets          = [local.keycloak_db.connection_secret]
    kms_alias_prefix = local.kms_alias_prefix
    buckets = [
      local.buckets["cnpg-backups"],
      local.buckets["langfuse-events"],
      local.buckets["langfuse-media"],
      local.buckets["audit"],
      local.buckets["kagent-snapshots"],
      local.buckets["sandbox-assets"],
      local.buckets["artifacts"],
      local.buckets["release-records"],
      local.buckets["catalog-index"],
    ]
  }

  # B3's roles and B4's. Locally every pod reaches floci with the static
  # credentials, so these are first proven in dev.
  data_buckets = {
    langfuse = [
      { name = local.buckets["langfuse-events"], kms_key_arn = module.langfuse_events_bucket.kms_key_arn },
      { name = local.buckets["langfuse-media"], kms_key_arn = module.langfuse_media_bucket.kms_key_arn },
    ]
    cnpg_backups = { name = local.buckets["cnpg-backups"], kms_key_arn = module.cnpg_backups_bucket.kms_key_arn }
    audit        = { name = local.buckets["audit"], kms_key_arn = module.audit_bucket.kms_key_arn }
    kagent = {
      snapshots = { name = local.buckets["kagent-snapshots"], kms_key_arn = module.kagent_snapshots_bucket.kms_key_arn }
      assets    = { name = local.buckets["sandbox-assets"], kms_key_arn = module.sandbox_assets_bucket.kms_key_arn }
    }
  }

  # Workloads reach floci with its static test credentials, which stand
  # for the account root. Dev trusts EKS Pod Identity instead.
  workload_trust = {
    aws = ["arn:aws:iam::000000000000:root"]
  }

  sts_signing_keys = {
    sign    = module.sts_signing.signing_key_arns
    publish = module.sts_signing.published_key_arns
  }

  # The entries of the plan's Names tables (plan/local-build.md, "B1 in
  # detail" and "B2 in detail"), whoever creates them: this stack creates
  # platform/keycloak/db, the okta-local stack the broker's, and a
  # workstation the others with the AWS CLI, since no system generates
  # them. Keycloak's password is in the secret RDS manages.
  external_secrets = {
    names = [
      local.keycloak_db.connection_secret,
      "platform/keycloak/okta-broker",
      "platform/keycloak/realm-config",
      "platform/delegation-sts/okta-reconciler-key",
      # B2: the rate-limit service's Valkey password, and the personas the
      # platform-controls suites sign in as.
      "platform/ratelimit/valkey",
      "platform/conformance/personas",
      # B3: Langfuse's salt, encryption key and session secret, its
      # ClickHouse's and Valkey's passwords, its Keycloak client's secret,
      # the conformance project's keys and initial user's password, and the
      # restore drill's role on langfuse-db; the usage table's writer's and
      # reader's passwords.
      "platform/langfuse/app",
      "platform/langfuse/clickhouse",
      "platform/langfuse/valkey",
      "platform/langfuse/sso",
      "platform/langfuse/projects",
      "platform/langfuse/restore-drill",
      "platform/usage/clickhouse",
      # B4: the four logins of kagent's database, kagent's and Substrate's
      # owners and read-write roles, oauth2-proxy's client and cookie
      # secrets for kagent's UI, and the restore drill's role on kagent-db.
      # The environments bootstrap generates each where missing.
      "platform/kagent/db",
      "platform/kagent/oauth2-proxy",
      "platform/kagent/restore-drill",
    ]
    arns = [module.keycloak_db.master_user_secret_arn]
  }
}

# What environments reads at deploy time and cannot derive: the ARN of the
# secret RDS manages, the workload roles, whose account differs per
# environment, and from B3 the buckets' names, whose suffix does; B4 adds
# its role and its two buckets, B5 its bucket, B6 its two buckets.
module "parameters" {
  source = "../../modules/parameters"

  path = local.ssm_parameter_path
  parameters = {
    "keycloak/db-password-secret-arn" = module.keycloak_db.master_user_secret_arn
    "delegation-sts/role-arn"         = module.iam.workload_role_arns["platform-delegation-sts"]
    "external-secrets/role-arn"       = module.iam.workload_role_arns["platform-external-secrets"]
    "langfuse/role-arn"               = module.iam.workload_role_arns["platform-langfuse"]
    "cnpg-backups/role-arn"           = module.iam.workload_role_arns["platform-cnpg-backups"]
    "telemetry-audit/role-arn"        = module.iam.workload_role_arns["platform-telemetry-audit"]
    "buckets/cnpg-backups"            = module.cnpg_backups_bucket.name
    "buckets/langfuse-events"         = module.langfuse_events_bucket.name
    "buckets/langfuse-media"          = module.langfuse_media_bucket.name
    "buckets/audit"                   = module.audit_bucket.name
    "kagent-snapshots/role-arn"       = module.iam.workload_role_arns["platform-kagent-snapshots"]
    "buckets/kagent-snapshots"        = module.kagent_snapshots_bucket.name
    "buckets/sandbox-assets"          = module.sandbox_assets_bucket.name
    "buckets/artifacts"               = module.artifacts_bucket.name
    "buckets/release-records"         = module.release_records_bucket.name
    "buckets/catalog-index"           = module.catalog_index_bucket.name
  }
}
