terraform {
  required_version = "1.13.9"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.73.0"
    }
  }

  # State in the bootstrap's bucket on floci, locked by a lock file beside
  # it (use_lockfile, no DynamoDB table). Dev runs the same backend against
  # a real bucket, without the endpoints and the skip flags. The values are
  # locals (main.tf), which OpenTofu evaluates before the backend starts.
  backend "s3" {
    bucket       = local.state.bucket
    key          = local.state.key
    region       = local.region
    use_lockfile = true

    # sts too: in CI the backend assumes the role with the job's ID token,
    # and that call must reach floci, never AWS.
    endpoints = {
      s3  = local.aws_endpoint
      sts = local.aws_endpoint
    }
    use_path_style = true

    # floci is not AWS: no region list, no account lookup, no instance
    # metadata, and no upload checksums.
    skip_credentials_validation = true
    skip_region_validation      = true
    skip_requesting_account_id  = true
    skip_metadata_api_check     = true
    skip_s3_checksum            = true
  }
}
