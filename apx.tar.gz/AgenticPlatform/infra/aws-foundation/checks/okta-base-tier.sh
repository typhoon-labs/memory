#!/bin/sh
# Decision Q1: Okta at a base tier, without API Access Management. Refuses
# any Okta configuration in this repository that uses a custom
# authorization server:
#   - an okta_auth_server* resource or data source;
#   - an issuer_mode other than ORG_URL;
#   - a URL under /oauth2/<server>/, the custom servers' path (the org
#     server's endpoints are /oauth2/v1/...).
# Run from the repository root; CI runs it on every merge request.
set -eu

files=$(find stacks modules -name '*.tf' -exec grep -l 'okta' {} + 2>/dev/null || true)
[ -n "$files" ] || { echo "okta-base-tier: no Okta configuration"; exit 0; }

findings=$(mktemp)
trap 'rm -f "$findings"' EXIT
for f in $files; do
  grep -nE '^[[:space:]]*(resource|data)[[:space:]]+"okta_auth_server' "$f" |
    sed "s|^|$f:|; s|\$|  <- custom authorization servers are refused|" >>"$findings" || true
  grep -nE 'issuer_mode[[:space:]]*=' "$f" | grep -vE '"ORG_URL"' |
    sed "s|^|$f:|; s|\$|  <- issuer_mode must be ORG_URL|" >>"$findings" || true
  grep -nE '/oauth2/[^v"/][^/"]*/|/oauth2/v[^1/][^/"]*/' "$f" |
    sed "s|^|$f:|; s|\$|  <- a custom authorization server's URL|" >>"$findings" || true
done

if [ -s "$findings" ]; then
  echo "okta-base-tier: Q1 allows the org authorization server only:" >&2
  cat "$findings" >&2
  exit 1
fi
echo "okta-base-tier: $(echo "$files" | wc -w | tr -d ' ') file(s) use the org authorization server only"
