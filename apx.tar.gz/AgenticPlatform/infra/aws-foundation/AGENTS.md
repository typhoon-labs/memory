# Agent instructions: aws-foundation

This repository holds the platform's AWS foundation in OpenTofu: modules, one stack per environment, and the registrations that CI trust policies read. Follow the [project standards](../../architecture/standards.md) for branches, commits, merges and when to ask before acting. The layout is in [Repositories](../../architecture/design/repositories.md#repository-layouts), the trust rules in [CI identity to AWS](../../architecture/design/repositories.md#ci-identity-to-aws), and what each build phase adds in the [local build plan](../../architecture/plan/local-build.md#6-phased-local-build).

## Rules for this repository

- **OpenTofu only** ([Q15](../../architecture/decisions/Q15-opentofu.md)): run `tofu`, never `terraform`.
- **A resource arrives in the phase that first needs it,** never ahead of it ([B0 in detail](../../architecture/plan/local-build.md#b0-in-detail)).
- **Local and dev differ only in values.** Modules never ask which environment they run in; floci appears only in `stacks/local`: the provider's `endpoints`, the backend's settings and `ci.env`.
- **Registrations are explicit project IDs,** one file per stack. Never register a sandbox project ID for dev, stage or prod.
- **Least privilege, untested locally.** A role's policy names the actions its stack's resources need, on those resources. floci evaluates neither IAM policies nor GitLab's trust conditions, so both are first proven in dev.
- **Pins:** each stack pins OpenTofu and `hashicorp/aws` exactly and commits its `.terraform.lock.hcl`; images are pinned by digest. Their versions are recorded in [Versions](../../architecture/reference/versions.md).
- **The pipeline applies.** Never run `tofu apply` from a workstation unless asked; the bootstrap's first apply is the only exception.
- **Every CI job has a runner tag** (`local-build` in the local build), so GitLab-hosted runners never pick one up.

## Before committing

Run from the repository root; each must succeed:

- `tofu fmt -check -recursive`
- In each module and stack that has `.tf` files: `tofu -chdir=<dir> init -backend=false` and `tofu -chdir=<dir> validate`. After a provider change, commit the stack's updated lock file.
- `python3 ../../architecture/tools/check_docs.py .` for the Markdown links.
