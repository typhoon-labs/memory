# Agentic platform workspace

This folder mirrors the `<company>/agentic-platform` GitLab group: each repository is its own folder at its path in that group, starting with `architecture/`. Until the swap to dev, the local build's repositories (`infra/`, `devkit/`, `workloads/`) live in the sibling group `<company>/agentic-platform-sandbox`, which is their `origin`. The folder itself is not a git repository, and this file is not versioned; the files it loads live in the repositories, and the paths inside each are relative to its repository's folder.

@architecture/standards.md

@architecture/AGENTS.md

@infra/environments/AGENTS.md

@infra/aws-foundation/AGENTS.md

@infra/delegation-sts/AGENTS.md

@infra/conformance/AGENTS.md

@devkit/ci-components/AGENTS.md

@devkit/agent-sdk/AGENTS.md

@devkit/agentctl/AGENTS.md

@devkit/workload-charts/AGENTS.md

@devkit/workload-templates/AGENTS.md

@agent-library/AGENTS.md

@workloads/reference/reference-agent/AGENTS.md

@workloads/reference/reference-mcp/AGENTS.md

@workloads/reference/reference-notes-agent/AGENTS.md

@workloads/reference/reference-workflow/AGENTS.md

## Inside the sandbox

Facts about the `agentic-platform` sandbox, checked on 2026-11-16. How it is created is in `SETUP.md`.

| Topic | What to know |
| --- | --- |
| Tools | `./install-tools.sh` installs them: versions in `mise.toml`, checksums in `mise.lock`. Rerun it after the sandbox is recreated or restarted. If a tool is missing from `PATH` in a session, run `source /etc/sandbox-persistent.sh`. gcc, which Go's race detector needs, was installed with apt on 2026-11-16 and is not in the script: a recreated sandbox needs `sudo apt-get install -y gcc` |
| Model endpoint | The host's Anthropic Messages API answers at `http://host.docker.internal:7070`, from the shell and from containers. `localhost:7070` is the sandbox itself. No key; send `anthropic-version: 2023-06-01`. Pods reach it through `host-model`, a socat relay on the kind network at `http://host-model:7070` (`infra/environments/clusters/local/00-local/host-model/`), since `host.docker.internal` is link-local there (spike T23, `architecture/research/2026-11-16-t23-host-model-relay.md`) |
| Credentials from the shell | The proxy replaces the `Authorization` header on every request to gitlab.com and to the Okta org with the sandbox's token, whatever you send. Only GitLab's `PRIVATE-TOKEN` header passes through. So every Okta call from the shell runs as super admin: test a narrower credential from a container. gitlabform works with the gitlab kit's placeholder `GITLAB_TOKEN` as it is |
| Containers | Reach the internet directly, with real certificates and no injected credentials. They do not trust the proxy's CA, so never give a container the proxy variables |
| kind | Needs two workarounds. Mount `/dev/null` at each node's `/dev/kmsg`: the sandbox has no usable `/dev/kmsg` and the kubelet will not start without it (the cost: nodes report no out-of-memory kills). Create clusters with `HTTP_PROXY`, `HTTPS_PROXY` and `NO_PROXY` unset: kind copies them into the nodes, and image pulls then fail on the proxy's CA. The local bootstrap (`infra/environments/clusters/local/00-local/bootstrap.sh`) applies both, and raises the inotify limits kind needs, which a restart resets |
| NetworkPolicy | Enforced, by Calico 3.33.1 in its iptables dataplane, which replaced kindnet in B1 (spike T21, `architecture/research/2026-11-16-t21-networkpolicy-engine.md`; `infra/environments/clusters/local/00-local/charts/calico`): kindnet's policy controller needs nftables' `queue` expression, which this kernel lacks. The bypass suite's NetworkPolicy cases pass (checked 2026-11-17) |
| arm64 images | `install-tools.sh` mounts `binfmt_misc` and registers QEMU for arm64; both are lost on restart. Its check leaves the local `alpine:3` tag on the arm64 image, so pass `--platform` or a digest |
| gVisor | Works in kind here on its `systrap` and `ptrace` platforms, both as a node RuntimeClass and nested in a pod with Substrate's worker settings, checkpoint and restore included; there is no `/dev/kvm`, so not on `kvm` (checked 2026-11-17, `architecture/research/2026-11-17-b4-desk-check.md`). It needs seccomp and AppArmor `Unconfined`. The kernel has no PSI, so one actor's OOM can restart its worker, and no core scheduling; `kubectl port-forward` does not reach a gVisor pod. `kernel.dmesg_restrict=0`, so ordinary pods can read the kernel log |
| floci and platform hostnames from the shell | `/etc/hosts` maps `floci`, `000000000000.floci` (the host S3 Control dials, for OpenTofu's bucket tags), and `keycloak`, `gateway` and `langfuse` under `.agentic.internal` to 127.0.0.1, and `/etc/sandbox-persistent.sh` adds `floci` and `.agentic.internal` to `NO_PROXY`, so `http://floci:4566` and `https://keycloak.agentic.internal` (with `--cacert ~/.local/share/agentic-platform/ca/ca.crt`) work here as in pods (added 2026-11-16; the S3 Control and Langfuse entries 2026-11-17). A recreated sandbox likely loses the hosts entries; the bootstrap's preflight then stops and prints them |
| Local build state outside Git | `~/.local/share/agentic-platform/`: the local CA, the nodes' `certs.d`, the two runners' tokens, and `okta/personas.json`, the synthetic personas' passwords and TOTP seeds, which exist nowhere else (all mode 600). **A restart loses it, not only removing the sandbox:** the root filesystem is an overlay whose writable layer the sandbox VM keeps outside the workspace (`/run/bundles/…/upper` in the VM; on disk, not in RAM: `free` shows no shared memory, checked 2026-11-18), so home, `/tmp`, `/etc/hosts` and installed tools are wiped; only the workspace (virtiofs) and `/var/lib/docker` (ext4, so the kind cluster and floci's volumes) persist (checked 2026-11-17). Copies are in the Docker volume `agentic-local-state`, one directory per copy (the latest `2026-11-19-b6-close/`: this directory and `/tmp/b1-watch`, which holds the build's logs and the shared `ship.sh` and `mr.py`, without downloadable caches). **No container mounts that volume, so never run `docker volume prune --all` or `docker system prune --volumes` here: either deletes it** (plain `docker volume prune` and the disk guard leave it alone). Before a restart, copy again, and afterwards restore with `docker run --rm -v agentic-local-state:/state -v /:/host alpine:3 cp -a /state/<date>/home/agent/.local/share/agentic-platform /host/home/agent/.local/share/` (as root, then `chown -R agent`, keeping the runner's root-owned `.runner_system_id`). Without it, the CA must be trusted again, the runners deleted on GitLab before the bootstrap creates new ones, and the personas given new passwords and factors (`aws-foundation/stacks/okta-local`'s scripts) |
| Secrets in floci | floci's Secrets Manager holds the Okta broker's client secret, the reconciler's private key and `realm-config`'s secret; the broker secret is also in the `okta-local` OpenTofu state in floci's S3. All are local-build secrets for the synthetic Integrator org |
| Disk | `/var/lib/docker` is 49 GB (the kind nodes, floci, CI images and caches) and `/` is 20 GB (home, `/tmp`, agents' worktrees). kind sets the kubelet's image GC to 100% and eviction to 0%, so nothing frees space on its own: the `disk-guard` container (`infra/environments/clusters/local/00-local/`) checks every 60 s and above 85% prunes the build cache, idle runner caches and unused floci images on the nodes, above 90% also every unused image (the user approved pruning unused images, 2026-11-18). It runs `guard.sh` from `~/.local/share/agentic-platform/disk-guard`, which a restart wipes, so after a restart it stays stopped until the bootstrap runs again. The guard also removes exited CI job containers older than an hour, with their anonymous volumes. floci's registry is expired by the lifecycle applier, whose hourly run only reports; real deletes and floci's garbage collection run only through `clusters/local/00-local/disk-guard/maintenance.sh` in `environments`, which fetches every repository first and pauses the build runner through GitLab's API. **Never set the runner's `concurrent` to 0: gitlab-runner refuses it and crash-loops** (2026-11-19). One multi-arch image build needs about 6 GB of headroom (measured 2026-11-19); B6's builds peaked at 98% before builds ran one at a time. Measured 2026-11-18: B0 to B5's builds peaked at 95% before the guard existed |
| Memory | 31 GiB. Containers use 8.05 GiB with B0 to B2 and 13.48 GiB right after B3's deploy (B3 adds 5.43 GiB), 14.3 GiB after its exit checks (`docker stats`, measured 2026-11-17); the sandbox then uses 10.9 of 31.4 GiB (`free`, page cache excluded). All of B3 runs on `agentic-local-worker`, since worker2 is the tainted sandbox pool. B4 added 0.42 GiB with no actor running (15.70 GiB at idle). With B5's three reference workloads deployed, containers use 16.1 GiB and the sandbox 14.0 of 31.4 GiB (measured 2026-11-18); with five CI jobs at once they peak at 18.3 GiB and 16.3 GiB. The build runner runs four jobs at once since 2026-11-19 (five and six pushed `/var/lib/docker` past 90% repeatedly). With all of B6 deployed and nothing running, containers use 17.0 GiB (the worker node 11.9, the control plane 3.7, worker2 0.5) and the sandbox 14.7 of 31.4 GiB (measured 2026-11-19 15:21Z), against the plan's estimate of 40 to 48 GiB for the full platform |
